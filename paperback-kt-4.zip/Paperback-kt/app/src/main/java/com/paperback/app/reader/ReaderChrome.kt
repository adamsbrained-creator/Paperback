package com.paperback.app.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Stats
import com.paperback.app.ui.BookmarkGlyph
import com.paperback.app.ui.ListGlyph
import com.paperback.app.ui.theme.PbSerif

/** The reader's controls follow the page theme (light / sepia / dark), not the phone's theme. */
class ReaderColors(val card: Color, val ink: Color, val chip: Color, val page: Color)

fun readerColors(themeIndex: Int): ReaderColors = when (themeIndex) {
    1 -> ReaderColors(card = Color(0xFFEADFC6), ink = Color(0xFF5B4636), chip = Color(0xFFF6EEDC), page = Color(0xFFFAF4E8))
    2 -> ReaderColors(card = Color(0xFF1C1C1C), ink = Color(0xFFF2F2F2), chip = Color(0xFF2C2C2C), page = Color(0xFF000000))
    else -> ReaderColors(card = Color(0xFFF3F3F3), ink = Color(0xFF111111), chip = Color.White, page = Color.White)
}

/**
 * The reader's controls, drawn over the Readium page. Everything is transparent except the two bars,
 * so taps anywhere else fall through to the book underneath.
 *
 * The bars are positioned with the *ignoring visibility* insets: the reader keeps the phone's status and
 * navigation bars hidden, and using the plain insets made the header jump whenever they appeared.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderChrome(
    title: String,
    visible: Boolean,
    position: Int,
    totalPositions: Int,
    progress: Float,
    secondsPerPage: Double?,
    fontSize: Double,
    themeIndex: Int,
    bookmarked: Boolean,
    onBack: () -> Unit,
    onToggleBookmark: () -> Unit,
    onOpenPanel: () -> Unit,
    onSeek: (Float) -> Unit,
    onFontSize: (Double) -> Unit,
    onTheme: (Int) -> Unit,
) {
    val c = readerColors(themeIndex)

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundButton(c, onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.ink)
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    text = title,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(c.card)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    color = c.ink,
                    fontFamily = PbSerif,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.width(10.dp))
                RoundButton(c, onToggleBookmark) {
                    BookmarkGlyph(filled = bookmarked, color = if (bookmarked) MaterialTheme.colorScheme.primary else c.ink)
                }
                Spacer(Modifier.width(10.dp))
                RoundButton(c, onOpenPanel) { ListGlyph(color = c.ink) }
            }
        }

        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomStart),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .padding(16.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(c.card)
                    .padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                val left = if (secondsPerPage != null && totalPositions > 0) {
                    Stats.duration(((totalPositions - position).coerceAtLeast(0) * secondsPerPage).toLong()) + " left"
                } else null
                val label = buildString {
                    if (totalPositions > 0) append("Page $position of $totalPositions · ")
                    append("${(progress * 100).toInt().coerceIn(0, 100)}%")
                    if (left != null) append(" · $left")
                }
                Text(label, color = c.ink, fontSize = 14.sp)

                var drag by remember { mutableStateOf<Float?>(null) }
                Slider(
                    value = drag ?: progress.coerceIn(0f, 1f),
                    onValueChange = { drag = it },
                    onValueChangeFinished = {
                        drag?.let(onSeek)
                        drag = null
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = c.ink.copy(alpha = 0.15f),
                    ),
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Pill(c, "A−") { onFontSize(-0.1) }
                        Spacer(Modifier.width(8.dp))
                        Text("${(fontSize * 100).toInt()}%", color = c.ink, fontSize = 13.sp)
                        Spacer(Modifier.width(8.dp))
                        Pill(c, "A+") { onFontSize(0.1) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        listOf("Light", "Sepia", "Dark").forEachIndexed { i, name ->
                            if (i > 0) Spacer(Modifier.width(6.dp))
                            Pill(c, name, selected = themeIndex == i) { onTheme(i) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundButton(c: ReaderColors, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(c.card).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun Pill(c: ReaderColors, text: String, selected: Boolean = false, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primary else c.chip
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else c.ink
    Text(
        text = text,
        color = fg,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
    )
}
