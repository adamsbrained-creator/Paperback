package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import java.time.LocalDate

@Composable
fun HomeScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    onOpen: (Book) -> Unit,
    onImport: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val today = LocalDate.now()
    val byDay = remember(sessions) { Stats.secondsByDay(sessions) }
    val pace = remember(sessions) { Stats.paceSecondsPerPosition(sessions) }
    val todaySeconds = byDay[today] ?: 0L
    val streak = Stats.currentStreak(byDay, today)

    val next = remember(books) {
        books.filter { it.isReading }.maxByOrNull { it.lastOpenedAt } ?: books.firstOrNull { !it.finished }
    }
    val recent = remember(books, next) {
        books.filter { it.lastOpenedAt > 0 && it.id != next?.id }.sortedByDescending { it.lastOpenedAt }.take(10)
    }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Eyebrow("Continue reading")
        Spacer(Modifier.height(12.dp))

        if (next == null) {
            Text("Your library is empty.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onImport, shape = RoundedCornerShape(28.dp)) { Text("Import books") }
        } else {
            Row(Modifier.fillMaxWidth()) {
                BookCover(next, Modifier.width(132.dp).clickable { onOpen(next) })
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        next.title,
                        fontFamily = PbSerif,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (next.author.isNotBlank()) {
                        Text(next.author, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(14.dp))
                    if (next.position > 0 && next.totalPositions > 0) {
                        Text("Page ${next.position} of ${next.totalPositions}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    ProgressTrack(next.progress)
                    Spacer(Modifier.height(8.dp))
                    val left = Stats.timeLeftSeconds(next, pace)?.let { " · ${Stats.duration(it)} left" } ?: ""
                    Text("${next.percent}%$left", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = { onOpen(next) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            ) { Text(if (next.isReading) "Resume reading" else "Start reading", fontSize = 16.sp) }
        }

        Spacer(Modifier.height(28.dp))
        Eyebrow("Today")
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Read today", Stats.duration(todaySeconds), Modifier.weight(1f))
            StatTile("Streak", if (streak == 1) "1 day" else "$streak days", Modifier.weight(1f))
        }

        if (recent.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            Eyebrow("Recently read")
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
                items(recent, key = { it.id }) { b ->
                    BookCover(b, Modifier.width(96.dp).clickable { onOpen(b) })
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
