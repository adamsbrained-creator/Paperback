package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.ui.theme.pbTokens

/** Every screen of the app. Home, Library and Stats are the tabs; the rest open on top and Back returns. */
enum class Dest(val isTab: Boolean) {
    Home(true),
    Library(true),
    Stats(true),
    Settings(false),
    AppStyle(false),
    About(false),
    Appearance(false),
    Goals(false),
    ReaderDefaults(false),
    Import(false),
    Backup(false),
}

private class MenuItemDef(val name: String, val icon: PbIconName, val dest: Dest?)

// The menu from the design: seven destinations. Discover, Collections and Bookmarks are not built in the Kotlin app yet.
private val MAIN = listOf(
    MenuItemDef("Home", PbIconName.Home, Dest.Home),
    MenuItemDef("Library", PbIconName.Library, Dest.Library),
    MenuItemDef("Discover", PbIconName.Discover, null),
    MenuItemDef("Collections", PbIconName.Collections, null),
    MenuItemDef("Bookmarks", PbIconName.Bookmark, null),
    MenuItemDef("Stats", PbIconName.Stats, Dest.Stats),
    MenuItemDef("Settings", PbIconName.Settings, Dest.Settings),
)

/** Pages that count as "being in" Settings (the row is highlighted on them). */
private val SETTINGS_PAGES = setOf(Dest.Settings, Dest.AppStyle, Dest.About, Dest.Appearance, Dest.ReaderDefaults, Dest.Backup, Dest.Import)

private fun isIn(current: Dest, item: MenuItemDef): Boolean = when (item.dest) {
    null -> false
    Dest.Settings -> current in SETTINGS_PAGES
    Dest.Stats -> current == Dest.Stats || current == Dest.Goals
    else -> current == item.dest
}

private val MenuDot = Color(0xFFF2674A)

/**
 * The menu button's pop-up: a card above the round menu button, over a dimmed screen. The button turns into
 * a close button while it is open (components/paperback/MenuSheet.tsx).
 */
@Composable
fun MenuOverlay(
    open: Boolean,
    current: Dest,
    onClose: () -> Unit,
    onGo: (Dest) -> Unit,
    onSoon: () -> Unit,
    onMore: () -> Unit,
) {
    if (!open) return
    val t = pbTokens()
    Box(Modifier.fillMaxSize()) {
        Scrim(onClose)
        Column(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 20.dp, bottom = 100.dp)
                .width(264.dp)
                .shadow(18.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(t.menuBg)
                .padding(8.dp),
        ) {
            MAIN.forEach { item ->
                val on = isIn(current, item)
                MenuRow(
                    icon = item.icon,
                    name = item.name,
                    on = on,
                    soon = item.dest == null,
                    onClick = {
                        val d = item.dest
                        if (d == null) onSoon() else onGo(d)
                    },
                )
            }
            MenuRow(icon = PbIconName.Dots, name = "More", on = false, soon = false, onClick = onMore)
        }
        MenuFab(
            onClick = onClose,
            close = true,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 24.dp),
        )
    }
}

@Composable
private fun Scrim(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(pbTokens().scrim)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
    )
}

@Composable
private fun MenuRow(icon: PbIconName, name: String, on: Boolean, soon: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (on) t.menuOn else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PbIcon(icon, size = 22.dp, tint = t.ink)
        Spacer(Modifier.width(14.dp))
        Text(
            name,
            modifier = Modifier.weight(1f),
            color = t.ink,
            fontSize = 16.sp,
            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium,
        )
        if (on) Box(Modifier.size(8.dp).clip(CircleShape).background(MenuDot))
        if (soon) Text("Soon", color = t.sub, fontSize = 12.sp)
    }
}

private class PageLink(val name: String, val dest: Dest?)
private class PageGroup(val label: String, val items: List<PageLink>)

// "More": Paperback's other pages (the old app's full list). The ones with no destination are still to be built.
private val GROUPS = listOf(
    PageGroup(
        "Reading",
        listOf(PageLink("Currently reading", null), PageLink("Recently read", null), PageLink("Finished", null), PageLink("Authors", null)),
    ),
    PageGroup(
        "Your notes",
        listOf(PageLink("Notes & highlights", null), PageLink("Bookmarks", null), PageLink("Search", Dest.Library), PageLink("Dictionary", null)),
    ),
    PageGroup(
        "Shelves",
        listOf(PageLink("Favorites", null), PageLink("Wishlist", null), PageLink("Collections", null), PageLink("Genres", null)),
    ),
    PageGroup("Get books", listOf(PageLink("Discover", null), PageLink("Import", Dest.Import))),
    PageGroup(
        "App",
        listOf(
            PageLink("Reading history", Dest.Stats),
            PageLink("Settings", Dest.Settings),
            PageLink("Backup & restore", Dest.Backup),
            PageLink("About", Dest.About),
        ),
    ),
)

/** A bottom sheet over a dimmed screen with every page in the app (the menu's "More"). */
@Composable
fun AllPagesSheet(
    open: Boolean,
    onClose: () -> Unit,
    onGo: (Dest) -> Unit,
    onSoon: () -> Unit,
) {
    if (!open) return
    val t = pbTokens()
    Box(Modifier.fillMaxSize()) {
        Scrim(onClose)
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            val maxSheet = maxHeight * 0.84f
            Column(
                Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .heightIn(max = maxSheet)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(t.bg)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 28.dp),
            ) {
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .width(44.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0x66808080)),
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("All pages", modifier = Modifier.weight(1f), color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                        PbIcon(PbIconName.Close, size = 20.dp, tint = t.ink, contentDescription = "Close")
                    }
                }
                GROUPS.forEach { group ->
                    Text(
                        group.label.uppercase(),
                        modifier = Modifier.padding(top = 10.dp, bottom = 12.dp),
                        color = t.sub,
                        fontSize = 12.sp,
                        letterSpacing = 0.1.em,
                    )
                    group.items.forEachIndexed { i, link ->
                        if (i > 0) Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(t.card)
                                .clickable {
                                    val d = link.dest
                                    if (d == null) onSoon() else onGo(d)
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                link.name,
                                modifier = Modifier.weight(1f).padding(start = 6.dp, top = 6.dp, bottom = 6.dp),
                                color = t.ink,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                            if (link.dest == null) {
                                Text("Soon", color = t.sub, fontSize = 12.sp)
                                Spacer(Modifier.width(10.dp))
                            }
                            PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.ink)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                }
            }
        }
    }
}
