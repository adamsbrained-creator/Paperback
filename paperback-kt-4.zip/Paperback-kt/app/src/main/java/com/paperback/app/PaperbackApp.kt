package com.paperback.app

import android.app.Application
import com.paperback.app.data.AppPrefs
import com.paperback.app.data.Book
import com.paperback.app.data.PaperbackDb
import com.paperback.app.data.Readium
import com.paperback.app.data.ReaderSettings
import com.paperback.app.data.Repository
import com.paperback.app.reader.ReaderSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.readium.r2.navigator.epub.EpubNavigatorFactory
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication
import org.readium.r2.shared.publication.services.positions
import java.io.File

class PaperbackApp : Application() {
    lateinit var graph: Graph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = Graph(this)
    }
}

/** The app's long-lived objects, created once. */
class Graph(app: Application) {
    /** For work that must finish even if the screen that started it is gone (saving a reading session). */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val db = PaperbackDb(app)
    val readium = Readium(app)
    val repo = Repository(app, db, readium)
    val settings = ReaderSettings(app)
    val prefs = AppPrefs(app)

    /** The book being read right now. Set by [openReader], used by ReaderActivity. */
    @Volatile
    var readerSession: ReaderSession? = null

    suspend fun openReader(book: Book): Boolean = withContext(Dispatchers.IO) {
        val file = File(book.filePath)
        if (!file.exists()) return@withContext false

        val publication = readium.open(file) ?: return@withContext false
        if (!publication.conformsTo(Publication.Profile.EPUB)) {
            publication.close()
            return@withContext false
        }

        val total = if (book.totalPositions > 0) book.totalPositions else publication.positions().size
        val initial: Locator? = book.locatorJson?.let { json ->
            runCatching { Locator.fromJSON(JSONObject(json)) }.getOrNull()
        }

        readerSession?.publication?.close()
        readerSession = ReaderSession(
            book = book,
            publication = publication,
            navigatorFactory = EpubNavigatorFactory(publication = publication),
            initialLocator = initial,
            totalPositions = total,
        )
        repo.markOpened(book.id)
        true
    }

    fun closeReader() {
        readerSession?.publication?.close()
        readerSession = null
    }
}
