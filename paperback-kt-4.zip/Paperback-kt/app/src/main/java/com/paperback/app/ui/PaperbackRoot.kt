package com.paperback.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.AppViewModel
import com.paperback.app.data.Book
import com.paperback.app.data.Stats
import java.time.LocalDate
import kotlin.math.roundToInt

@Composable
fun PaperbackRoot(
    vm: AppViewModel,
    onPickBooks: () -> Unit,
    onOpenReader: () -> Unit,
    onSaveBackup: () -> Unit,
    onPickBackup: () -> Unit,
) {
    val books by vm.books.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val headerSize by vm.headerSize.collectAsStateWithLifecycle()
    val themeMode by vm.themeMode.collectAsStateWithLifecycle()
    val goals by vm.goals.collectAsStateWithLifecycle()
    val backupCounts by vm.backupCounts.collectAsStateWithLifecycle()
    val pendingBackup by vm.pendingBackup.collectAsStateWithLifecycle()

    // Where we are: a stack of screens, kept as text so it survives rotation. The first is a tab.
    var stackRaw by rememberSaveable { mutableStateOf(Dest.Home.name) }
    val stack = remember(stackRaw) {
        stackRaw.split(',').mapNotNull { name -> Dest.values().firstOrNull { it.name == name } }.ifEmpty { listOf(Dest.Home) }
    }
    val current = stack.last()
    var menuOpen by rememberSaveable { mutableStateOf(false) }
    var allOpen by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.consumeMessage()
        }
    }
    LaunchedEffect(current) {
        if (current == Dest.Backup) vm.refreshBackupCounts()
    }

    val open: (Book) -> Unit = { book -> vm.open(book, onOpenReader) }

    // Tabs replace each other; every other screen is pushed on top so Back returns to where you were.
    val navigate: (Dest) -> Unit = { dest ->
        menuOpen = false
        allOpen = false
        when {
            dest.isTab -> stackRaw = dest.name
            dest == current -> Unit
            stack.contains(dest) -> stackRaw = stack.take(stack.indexOf(dest) + 1).joinToString(",") { it.name }
            else -> stackRaw = "$stackRaw,${dest.name}"
        }
    }
    val soon: () -> Unit = {
        menuOpen = false
        allOpen = false
        vm.say("Coming soon")
    }
    val openMenu: () -> Unit = { menuOpen = true }
    val search: () -> Unit = { navigate(Dest.Library) }

    BackHandler(enabled = menuOpen || allOpen || stack.size > 1) {
        when {
            allOpen -> allOpen = false
            menuOpen -> menuOpen = false
            else -> stackRaw = stack.dropLast(1).joinToString(",") { it.name }
        }
    }

    val today = LocalDate.now()
    val secondsToday = remember(sessions) { Stats.secondsByDay(sessions)[today] ?: 0L }
    val reader = vm.readerSettings

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                if (current.isTab) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.background) {
                        val colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        NavigationBarItem(
                            selected = current == Dest.Home, onClick = { navigate(Dest.Home) }, colors = colors,
                            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                            label = { Text("Home") },
                        )
                        NavigationBarItem(
                            selected = current == Dest.Library, onClick = { navigate(Dest.Library) }, colors = colors,
                            icon = {
                                LibraryGlyph(
                                    if (current == Dest.Library) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            },
                            label = { Text("Library") },
                        )
                        NavigationBarItem(
                            selected = current == Dest.Stats, onClick = { navigate(Dest.Stats) }, colors = colors,
                            icon = {
                                StatsGlyph(
                                    if (current == Dest.Stats) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            },
                            label = { Text("Stats") },
                        )
                    }
                }
            },
        ) { inner ->
            Box(Modifier.fillMaxSize().padding(inner)) {
                when (current) {
                    Dest.Home, Dest.Library, Dest.Stats -> Column(Modifier.fillMaxSize()) {
                        PageHeader(
                            label = when (current) {
                                Dest.Home -> "Home"
                                Dest.Library -> "Library"
                                else -> "Stats"
                            },
                            size = headerSize,
                            chip = if (current == Dest.Library) "${books.size} ${if (books.size == 1) "book" else "books"}" else null,
                            onMenu = openMenu,
                            onSearch = search,
                            modifier = Modifier.padding(horizontal = 20.dp).padding(top = 4.dp),
                        )
                        Box(Modifier.weight(1f)) {
                            when (current) {
                                Dest.Home -> HomeScreen(books, sessions, onOpen = open, onImport = onPickBooks)
                                Dest.Library -> LibraryScreen(
                                    books = books,
                                    onOpen = open,
                                    onImport = onPickBooks,
                                    onToggleFavorite = vm::toggleFavorite,
                                    onToggleFinished = vm::toggleFinished,
                                    onRemove = vm::remove,
                                )
                                else -> StatsScreen(books, sessions)
                            }
                        }
                    }

                    Dest.Settings -> SettingsScreen(
                        headerSize = headerSize,
                        secondsToday = secondsToday,
                        goalMinutes = goals.minutesPerDay,
                        readerValue = "${listOf("Light", "Sepia", "Dark")[reader.theme.coerceIn(0, 2)]} · ${(reader.fontSize * 100).roundToInt()}%",
                        appearanceValue = themeMode.label,
                        version = rememberAppVersion(),
                        onMenu = openMenu,
                        onSearch = search,
                        onOpen = navigate,
                    )

                    Dest.AppStyle -> AppStyleScreen(headerSize, vm::setHeaderSize, openMenu, search)

                    Dest.About -> AboutScreen(headerSize, rememberAppVersion(), openMenu, search)

                    Dest.Appearance -> AppearanceScreen(headerSize, themeMode, vm::setThemeMode, openMenu, search)

                    Dest.Goals -> GoalsScreen(headerSize, goals, books, sessions, vm::setGoals, openMenu, search)

                    Dest.ReaderDefaults -> ReaderDefaultsScreen(
                        headerSize = headerSize,
                        fontSize = reader.fontSize,
                        theme = reader.theme,
                        onFontSize = { reader.fontSize = it },
                        onTheme = { reader.theme = it },
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Import -> ImportScreen(
                        headerSize = headerSize,
                        busy = busy,
                        onPick = onPickBooks,
                        onDiscover = soon,
                        onLibrary = { navigate(Dest.Library) },
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Backup -> BackupScreen(
                        headerSize = headerSize,
                        counts = backupCounts,
                        pending = pendingBackup,
                        onSave = onSaveBackup,
                        onPick = onPickBackup,
                        onApply = vm::applyBackup,
                        onCancel = vm::cancelBackup,
                        onMenu = openMenu,
                        onSearch = search,
                    )
                }
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }

        // Screens that are not tabs get the round menu button at the bottom right, like the old app's Settings.
        if (!current.isTab && !menuOpen) {
            MenuFab(
                onClick = openMenu,
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 24.dp),
            )
        }

        MenuOverlay(
            open = menuOpen,
            current = current,
            onClose = { menuOpen = false },
            onGo = navigate,
            onSoon = soon,
            onMore = {
                menuOpen = false
                allOpen = true
            },
        )
        AllPagesSheet(open = allOpen, onClose = { allOpen = false }, onGo = navigate, onSoon = soon)
    }
}
