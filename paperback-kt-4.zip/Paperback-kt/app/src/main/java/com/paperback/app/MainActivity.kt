package com.paperback.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.data.Backup
import com.paperback.app.data.ThemeMode
import com.paperback.app.reader.ReaderActivity
import com.paperback.app.ui.PaperbackRoot
import com.paperback.app.ui.theme.PaperbackTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val pickBooks =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.importBooks(uris)
        }

    private val saveBackup =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) vm.saveBackup(uri)
        }

    private val pickBackup =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.readBackup(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Settings → Appearance can force light or dark whatever the phone is set to.
            val mode by vm.themeMode.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            val dark = when (mode) {
                ThemeMode.System -> systemDark
                ThemeMode.Light -> false
                ThemeMode.Dark -> true
            }
            // Keep the status and navigation bar icons readable on the chosen theme.
            DisposableEffect(dark) {
                this@MainActivity.enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                )
                onDispose { }
            }
            PaperbackTheme(dark = dark) {
                PaperbackRoot(
                    vm = vm,
                    // "*/*": some file pickers don't label .epub files as application/epub+zip.
                    onPickBooks = { pickBooks.launch(arrayOf("*/*")) },
                    onOpenReader = { startActivity(Intent(this, ReaderActivity::class.java)) },
                    onSaveBackup = { saveBackup.launch(Backup.filename()) },
                    onPickBackup = { pickBackup.launch(arrayOf("*/*")) },
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.refresh() // picks up progress and reading time saved by the reader
    }
}
