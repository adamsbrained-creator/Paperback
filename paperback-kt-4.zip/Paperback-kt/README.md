# Paperback 2 (Kotlin)

Paperback rebuilt natively: Kotlin, Jetpack Compose, and the Readium toolkit for EPUB (instead of Readest).
Android only. Package id `com.paperback.app`, so it installs next to the old TypeScript Paperback.

## What works in this first step
- Import EPUBs (copied into the app, deduplicated by file hash, cover and page count read from the book)
- Home (continue reading, today, streak, recently read), Library (search, filters, favorite / finished / remove), Stats (today, week, streaks, last 7 days, most read)
- Reader: page turns by tapping the screen edges, tap the middle for controls (slider, font size, light / sepia / dark), position saved on every page turn
- Reading time and pages counted per session (idle time is capped, like Readest)

### Added in round 2
- Bookmarks: bookmark button at the top of the reader, list in the notes panel
- Highlights and notes: select text, choose Highlight or Note; tap a highlight to edit it (note, colour, delete)
- Panel (button next to the bookmark) lists all bookmarks and notes of the book; tap one to jump there
- Reader controls now follow the page theme (light / sepia / dark)
- Fixed: the reader header jumped and lagged when the controls toggled. The phone's status and navigation bars now stay hidden
  for the whole reading session (swipe from the edge to peek), so nothing resizes when you tap the page

### Added in round 3: Settings (copied from the TypeScript app)
- **Settings page** exactly as in `app/(paperback)/settings/page.tsx`: daily-goal card (ring, minutes today, Edit), then READING (Reading goals, Reading stats, Reader defaults), LOOK (Appearance, App style), LIBRARY (Library & import, Backup & restore) and About, with the round menu button at the bottom right
- **Page header** in the three sizes (Compact / Regular / Large) on every screen, with the menu and search buttons; Library shows its book-count chip
- **Menu**: the pop-up card above the round button (Home, Library, Discover, Collections, Bookmarks, Stats, Settings, More) and the "All pages" sheet. Pages that are not built yet say "Soon"
- **App style** (header size with a live sample of each), **About** (logo tile, Credits, Open-source licenses), **Appearance** (Light / Dark / Match system), **Reading goals** (books this year, pages, minutes, streak, editable)
- **Reader defaults** (font size and page colors) and **Library & import**, both real, not placeholders
- **Backup & restore**: one JSON file with progress, favorites, ratings, bookmarks, highlights, reading history, goals and settings. Restore matches books by hash and never moves reading progress backwards
- The icons are the TypeScript app's own SVG paths (`PbIcons.kt`), so they are identical
- Navigation is now a small back stack in `PaperbackRoot.kt` (Back returns; tabs replace each other)

Not copied yet: Appearance's **Home layout** (Pile) and **Navigation** style (dock, header switch, off), because the Kotlin Home and tab bar have only one layout.
Outfit is not bundled yet (the font could not be downloaded); text uses the system sans. To add it, put Outfit-Regular/Medium/SemiBold.ttf in `app/src/main/res/font/` and point `PbSans` in `ui/theme/Theme.kt` at them.

## Not done yet (in the old app, planned in this order)
PDF and comics, notes browser across all books, collections, ratings screen, wishlist, dictionary, read aloud, milestones, Discover (OPDS), Outfit and Newsreader fonts.

## Layout
- `app/src/main/java/com/paperback/app/data` database, import, stats maths (`Stats.kt` is the port of statsAggregate.ts)
- `.../reader` ReaderActivity (hosts Readium's fragment), the controls overlay, reading-time tracker
- `.../ui` Home, Library, Stats screens and the theme (same coral / black / white as before)

## Building
Upload the zip next to `.github/workflows/apk-kotlin-from-one-zip.yml` and run the workflow. Versions are in `gradle/libs.versions.toml`.
If Gradle can't find a version, change it there.
