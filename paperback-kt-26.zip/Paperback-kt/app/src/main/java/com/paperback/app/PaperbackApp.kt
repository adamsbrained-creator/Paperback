package com.paperback.app

import android.app.Application
import com.paperback.app.data.AppPrefs
import com.paperback.app.data.OpdsStore
import com.paperback.app.data.catalog.CatalogApi
import com.paperback.app.data.opds.OpdsHttp
import com.paperback.app.data.Book
import com.paperback.app.data.PaperbackDb
import com.paperback.app.data.Readium
import com.paperback.app.data.ReadingTimer
import com.paperback.app.data.SearchHistory
import com.paperback.app.data.Wishlist
import com.paperback.app.data.ReaderSettings
import com.paperback.app.data.Repository
import com.paperback.app.reader.PdfSession
import com.paperback.app.reader.ReaderSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.readium.r2.navigator.epub.EpubNavigatorFactory
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication
import org.readium.r2.shared.publication.services.positions
import java.io.File

class PaperbackApp : Application() {
    lateinit var graph: Graph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = Graph(this)
    }
}

/** The app's long-lived objects, created once. */
class Graph(app: Application) {
    /** For work that must finish even if the screen that started it is gone (saving a reading session). */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val db = PaperbackDb(app)
    val readium = Readium(app)
    val repo = Repository(app, db, readium)
    val settings = ReaderSettings(app)
    val prefs = AppPrefs(app)
    val searchHistory = SearchHistory(app)
    val opdsHttp = OpdsHttp()
    val opdsStore = OpdsStore(app)
    val catalogApi = CatalogApi(opdsHttp, app.cacheDir)
    val wishlist = Wishlist(app)
    val timer = ReadingTimer(app)

    /** The book being read right now. Set by [openReader], used by ReaderActivity. */
    @Volatile
    var readerSession: ReaderSession? = null

    /** The PDF being read right now (PDFs have their own viewer). Null while an EPUB is open. */
    @Volatile
    var pdfSession: PdfSession? = null

    /** [startAtJson]: open at this saved place (a note or bookmark) instead of where you stopped. */
    suspend fun openReader(book: Book, startAtJson: String? = null): Boolean = withContext(Dispatchers.IO) {
        val file = File(book.filePath)
        if (!file.exists()) return@withContext false

        if (book.isPdf) {
            // Readium isn't involved: just remember which page to start on. The viewer opens the file itself.
            val saved = (startAtJson ?: book.locatorJson)?.let { json ->
                runCatching { JSONObject(json).getJSONObject("locations").getInt("position") }.getOrNull()
            }
            val page = (saved ?: book.position).coerceAtLeast(1)
            readerSession?.publication?.close()
            readerSession = null
            pdfSession = PdfSession(book, page)
            repo.markOpened(book.id)
            return@withContext true
        }
        pdfSession = null

        val publication = readium.open(file) ?: return@withContext false
        if (!publication.conformsTo(Publication.Profile.EPUB)) {
            publication.close()
            return@withContext false
        }

        val total = if (book.totalPositions > 0) book.totalPositions else publication.positions().size
        val initial: Locator? = (startAtJson ?: book.locatorJson)?.let { json ->
            runCatching { Locator.fromJSON(JSONObject(json)) }.getOrNull()
        }

        readerSession?.publication?.close()
        readerSession = ReaderSession(
            book = book,
            publication = publication,
            navigatorFactory = EpubNavigatorFactory(publication = publication),
            initialLocator = initial,
            totalPositions = total,
        )
        repo.markOpened(book.id)
        true
    }

    fun closePdf() {
        pdfSession = null
    }

    fun closeReader() {
        readerSession?.publication?.close()
        readerSession = null
    }
}
