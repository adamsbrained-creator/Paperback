package com.paperback.app.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Plain SQLite on purpose: no annotation processor, so nothing to break the build. All calls block; use Dispatchers.IO. */
class PaperbackDb(context: Context) : SQLiteOpenHelper(context, "paperback.db", null, 5) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE books (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                language TEXT NOT NULL,
                file_path TEXT NOT NULL,
                cover_path TEXT,
                added_at INTEGER NOT NULL,
                last_opened_at INTEGER NOT NULL DEFAULT 0,
                progress REAL NOT NULL DEFAULT 0,
                position INTEGER NOT NULL DEFAULT 0,
                total_positions INTEGER NOT NULL DEFAULT 0,
                locator TEXT,
                finished INTEGER NOT NULL DEFAULT 0,
                favorite INTEGER NOT NULL DEFAULT 0,
                rating INTEGER NOT NULL DEFAULT 0,
                journal TEXT NOT NULL DEFAULT '',
                finished_at INTEGER NOT NULL DEFAULT 0,
                tags TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                publisher TEXT NOT NULL DEFAULT '',
                published TEXT NOT NULL DEFAULT '',
                meta_read INTEGER NOT NULL DEFAULT 0
            )""",
        )
        db.execSQL(
            """CREATE TABLE sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id TEXT NOT NULL,
                start_ms INTEGER NOT NULL,
                seconds INTEGER NOT NULL,
                pages INTEGER NOT NULL DEFAULT 0,
                from_pos INTEGER NOT NULL DEFAULT 0,
                to_pos INTEGER NOT NULL DEFAULT 0
            )""",
        )
        db.execSQL("CREATE INDEX idx_sessions_start ON sessions(start_ms)")
        createAnnotationTables(db)
        createCollectionTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createAnnotationTables(db) // bookmarks and highlights
        if (oldVersion < 3) {
            // step 4: journal, finish date, collections
            db.execSQL("ALTER TABLE books ADD COLUMN journal TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN finished_at INTEGER NOT NULL DEFAULT 0")
            createCollectionTables(db)
        }
        if (oldVersion < 4) {
            // tags / genres, description, publisher, date (meta_read = 0: read from the file once, after the update)
            db.execSQL("ALTER TABLE books ADD COLUMN tags TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN description TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN publisher TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN published TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN meta_read INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 5) {
            // reading entries: the first and last page of a session
            db.execSQL("ALTER TABLE sessions ADD COLUMN from_pos INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE sessions ADD COLUMN to_pos INTEGER NOT NULL DEFAULT 0")
        }
    }

    private fun createCollectionTables(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS collections (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )""",
        )
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS collection_books (
                collection_id TEXT NOT NULL,
                book_id TEXT NOT NULL,
                PRIMARY KEY (collection_id, book_id)
            )""",
        )
    }

    private fun createAnnotationTables(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS bookmarks (
                id TEXT PRIMARY KEY,
                book_id TEXT NOT NULL,
                locator TEXT NOT NULL,
                position INTEGER NOT NULL,
                progress REAL NOT NULL,
                created_at INTEGER NOT NULL
            )""",
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_bookmarks_book ON bookmarks(book_id)")
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS highlights (
                id TEXT PRIMARY KEY,
                book_id TEXT NOT NULL,
                locator TEXT NOT NULL,
                text TEXT NOT NULL,
                note TEXT NOT NULL,
                color INTEGER NOT NULL,
                progress REAL NOT NULL,
                created_at INTEGER NOT NULL
            )""",
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_highlights_book ON highlights(book_id)")
    }

    fun allBooks(): List<Book> =
        readableDatabase.query("books", null, null, null, null, null, "added_at DESC").use { c ->
            buildList { while (c.moveToNext()) add(c.toBook()) }
        }

    fun hasBook(id: String): Boolean =
        readableDatabase.query("books", arrayOf("id"), "id = ?", arrayOf(id), null, null, null).use { it.moveToFirst() }

    /** Returns false when a book with this id already exists. */
    fun insertBook(b: Book): Boolean {
        val cv = ContentValues().apply {
            put("id", b.id)
            put("title", b.title)
            put("author", b.author)
            put("language", b.language)
            put("file_path", b.filePath)
            put("cover_path", b.coverPath)
            put("added_at", b.addedAt)
            put("total_positions", b.totalPositions)
            put("tags", b.tags.joinToString("\n"))
            put("description", b.description)
            put("publisher", b.publisher)
            put("published", b.published)
            put("meta_read", if (b.metaRead) 1 else 0)
        }
        return writableDatabase.insertWithOnConflict("books", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun updateProgress(id: String, locatorJson: String, progress: Float, position: Int, openedAt: Long) {
        val cv = ContentValues().apply {
            put("locator", locatorJson)
            put("progress", progress)
            put("position", position)
            put("last_opened_at", openedAt)
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun touchOpened(id: String, openedAt: Long) {
        val cv = ContentValues().apply { put("last_opened_at", openedAt) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setFlag(id: String, column: String, value: Boolean) {
        require(column == "finished" || column == "favorite")
        if (column == "finished") {
            setFinished(id, value)
            return
        }
        val cv = ContentValues().apply { put(column, if (value) 1 else 0) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    /** Marks a book finished (keeping the first finish date) or not finished. */
    fun setFinished(id: String, value: Boolean) {
        if (value) {
            writableDatabase.execSQL(
                "UPDATE books SET finished = 1, finished_at = CASE WHEN finished_at = 0 THEN ? ELSE finished_at END WHERE id = ?",
                arrayOf<Any?>(System.currentTimeMillis(), id),
            )
        } else {
            writableDatabase.execSQL("UPDATE books SET finished = 0, finished_at = 0 WHERE id = ?", arrayOf<Any?>(id))
        }
    }

    /** Stores what was read from the book's file and its catalog, and marks the book as done. */
    fun setMeta(id: String, x: BookExtras) {
        val cv = ContentValues().apply {
            put("tags", x.tags.joinToString("\n"))
            put("description", x.description)
            put("publisher", x.publisher)
            put("published", x.published)
            put("meta_read", 1)
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setJournal(id: String, text: String) {
        val cv = ContentValues().apply { put("journal", text) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setRating(id: String, stars: Int) {
        val cv = ContentValues().apply { put("rating", stars.coerceIn(0, 5)) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun deleteBook(id: String) {
        // Reading sessions stay: your history should survive removing a book.
        writableDatabase.delete("books", "id = ?", arrayOf(id))
        writableDatabase.delete("collection_books", "book_id = ?", arrayOf(id))
    }

    fun insertSession(bookId: String, startMs: Long, seconds: Int, pages: Int, fromPos: Int = 0, toPos: Int = 0) {
        val cv = ContentValues().apply {
            put("book_id", bookId)
            put("start_ms", startMs)
            put("seconds", seconds)
            put("pages", pages)
            put("from_pos", fromPos)
            put("to_pos", toPos)
        }
        writableDatabase.insert("sessions", null, cv)
    }

    fun updateSession(id: Long, startMs: Long, seconds: Int, pages: Int, fromPos: Int, toPos: Int) {
        val cv = ContentValues().apply {
            put("start_ms", startMs)
            put("seconds", seconds)
            put("pages", pages)
            put("from_pos", fromPos)
            put("to_pos", toPos)
        }
        writableDatabase.update("sessions", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deleteSession(id: Long) {
        writableDatabase.delete("sessions", "id = ?", arrayOf(id.toString()))
    }

    fun allSessions(): List<ReadingSession> =
        readableDatabase.query("sessions", null, null, null, null, null, "start_ms ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        ReadingSession(
                            id = c.lng("id"),
                            bookId = c.str("book_id"),
                            startMs = c.lng("start_ms"),
                            seconds = c.int("seconds"),
                            pages = c.int("pages"),
                            fromPos = c.int("from_pos"),
                            toPos = c.int("to_pos"),
                        ),
                    )
                }
            }
        }

    // ---- bookmarks ------------------------------------------------------------------------

    fun bookmarksFor(bookId: String): List<Bookmark> =
        readableDatabase.query("bookmarks", null, "book_id = ?", arrayOf(bookId), null, null, "progress ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Bookmark(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            position = c.int("position"), progress = c.getFloat(c.col("progress")),
                            createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    fun insertBookmark(b: Bookmark) {
        val cv = ContentValues().apply {
            put("id", b.id)
            put("book_id", b.bookId)
            put("locator", b.locatorJson)
            put("position", b.position)
            put("progress", b.progress)
            put("created_at", b.createdAt)
        }
        writableDatabase.insertWithOnConflict("bookmarks", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteBookmark(id: String) {
        writableDatabase.delete("bookmarks", "id = ?", arrayOf(id))
    }

    // ---- highlights and notes -------------------------------------------------------------

    fun highlightsFor(bookId: String): List<Highlight> =
        readableDatabase.query("highlights", null, "book_id = ?", arrayOf(bookId), null, null, "progress ASC, created_at ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Highlight(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            text = c.str("text"), note = c.str("note"), color = c.int("color"),
                            progress = c.getFloat(c.col("progress")), createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    fun insertHighlight(h: Highlight) {
        val cv = ContentValues().apply {
            put("id", h.id)
            put("book_id", h.bookId)
            put("locator", h.locatorJson)
            put("text", h.text)
            put("note", h.note)
            put("color", h.color)
            put("progress", h.progress)
            put("created_at", h.createdAt)
        }
        writableDatabase.insertWithOnConflict("highlights", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun updateHighlight(id: String, note: String, color: Int) {
        val cv = ContentValues().apply {
            put("note", note)
            put("color", color)
        }
        writableDatabase.update("highlights", cv, "id = ?", arrayOf(id))
    }

    fun deleteHighlight(id: String) {
        writableDatabase.delete("highlights", "id = ?", arrayOf(id))
    }

    // ---- notes across all books -----------------------------------------------------------

    fun allHighlights(): List<Highlight> =
        readableDatabase.query("highlights", null, null, null, null, null, "created_at DESC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Highlight(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            text = c.str("text"), note = c.str("note"), color = c.int("color"),
                            progress = c.getFloat(c.col("progress")), createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    fun allBookmarks(): List<Bookmark> =
        readableDatabase.query("bookmarks", null, null, null, null, null, "created_at DESC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Bookmark(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            position = c.int("position"), progress = c.getFloat(c.col("progress")),
                            createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    // ---- collections ----------------------------------------------------------------------

    fun allCollections(): List<BookCollection> =
        readableDatabase.query("collections", null, null, null, null, null, "name COLLATE NOCASE ASC").use { c ->
            buildList { while (c.moveToNext()) add(BookCollection(c.str("id"), c.str("name"), c.lng("created_at"))) }
        }

    /** collection id -> ids of the books in it */
    fun collectionMembers(): Map<String, Set<String>> =
        readableDatabase.query("collection_books", null, null, null, null, null, null).use { c ->
            val out = HashMap<String, MutableSet<String>>()
            while (c.moveToNext()) out.getOrPut(c.str("collection_id")) { mutableSetOf() }.add(c.str("book_id"))
            out
        }

    fun upsertCollection(c: BookCollection) {
        val cv = ContentValues().apply {
            put("id", c.id)
            put("name", c.name)
            put("created_at", c.createdAt)
        }
        writableDatabase.insertWithOnConflict("collections", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteCollection(id: String) {
        writableDatabase.delete("collection_books", "collection_id = ?", arrayOf(id))
        writableDatabase.delete("collections", "id = ?", arrayOf(id))
    }

    fun setMember(collectionId: String, bookId: String, member: Boolean) {
        if (member) {
            val cv = ContentValues().apply {
                put("collection_id", collectionId)
                put("book_id", bookId)
            }
            writableDatabase.insertWithOnConflict("collection_books", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        } else {
            writableDatabase.delete("collection_books", "collection_id = ? AND book_id = ?", arrayOf(collectionId, bookId))
        }
    }

    private fun Cursor.col(name: String) = getColumnIndexOrThrow(name)
    private fun Cursor.str(name: String): String = getString(col(name))
    private fun Cursor.strOrNull(name: String): String? = if (isNull(col(name))) null else getString(col(name))
    private fun Cursor.int(name: String): Int = getInt(col(name))
    private fun Cursor.lng(name: String): Long = getLong(col(name))

    private fun Cursor.toBook() = Book(
        id = str("id"),
        title = str("title"),
        author = str("author"),
        language = str("language"),
        filePath = str("file_path"),
        coverPath = strOrNull("cover_path"),
        addedAt = lng("added_at"),
        lastOpenedAt = lng("last_opened_at"),
        progress = getFloat(col("progress")),
        position = int("position"),
        totalPositions = int("total_positions"),
        locatorJson = strOrNull("locator"),
        finished = int("finished") == 1,
        favorite = int("favorite") == 1,
        rating = int("rating"),
        journal = str("journal"),
        finishedAt = lng("finished_at"),
        tags = str("tags").split('\n').filter { it.isNotBlank() },
        description = str("description"),
        publisher = str("publisher"),
        published = str("published"),
        metaRead = int("meta_read") == 1,
    )
}
