package com.paperback.app.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingSession
import com.paperback.app.ui.theme.pbTokens
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Add or change one reading entry: when you read, which pages and for how long. Used after the timer, for
 * "Add entry" on the book page, and to fix an entry the reader counted. [entry] is null for a new one.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EntryScreen(
    book: Book,
    entry: ReadingSession?,
    initialSeconds: Int,
    initialStartMs: Long,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onSave: (startMs: Long, seconds: Int, pages: Int, fromPos: Int, toPos: Int) -> Unit,
    onDelete: (() -> Unit)?,
) {
    val t = pbTokens()
    val context = LocalContext.current
    val zone = remember { ZoneId.systemDefault() }

    val seconds0 = entry?.seconds ?: initialSeconds
    val minutes0 = (seconds0 + 30) / 60
    var startMs by remember(entry?.id, initialStartMs) { mutableLongStateOf(entry?.startMs ?: initialStartMs) }
    var minutes by remember(entry?.id) { mutableStateOf(if (minutes0 > 0) minutes0.toString() else "") }
    var from by remember(entry?.id) {
        mutableStateOf(
            when {
                entry != null && entry.fromPos > 0 -> entry.fromPos.toString()
                entry == null && book.position > 0 -> book.position.toString()
                else -> "",
            },
        )
    }
    var to by remember(entry?.id) { mutableStateOf(if (entry != null && entry.toPos > 0) entry.toPos.toString() else "") }
    var confirmDelete by remember { mutableStateOf(false) }

    val fromN = from.toIntOrNull()
    val toN = to.toIntOrNull()
    val pagesError = when {
        from.isBlank() && to.isBlank() -> null
        fromN == null || toN == null -> "Fill in both pages, or leave both empty."
        toN < fromN -> "The last page can’t be before the first."
        else -> null
    }
    val pageCount = if (fromN != null && toN != null && toN >= fromN) toN - fromN else null
    val minutesN = minutes.toIntOrNull()
    val canSave = pagesError == null && ((minutesN ?: 0) > 0 || (pageCount ?: entry?.pages ?: 0) > 0)

    val local = remember(startMs) { LocalDateTime.ofInstant(Instant.ofEpochMilli(startMs), zone) }
    val dateText = "%d %s %d".format(local.dayOfMonth, local.month.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.getDefault()), local.year)
    val timeText = "%02d:%02d".format(local.hour, local.minute)

    PbPage(if (entry == null) "New entry" else "Edit entry", headerSize, onMenu, onSearch, headerGap = 8.dp) {
        Text(
            book.title.uppercase() + if (book.totalPositions > 0) " · ${book.totalPositions} PAGES" else "",
            color = MaterialTheme.colorScheme.primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        SectionLabel("When")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PickRow("Date", dateText, Modifier.weight(1f)) {
                DatePickerDialog(
                    context,
                    { _, y, m, d -> startMs = local.withYear(y).withMonth(m + 1).withDayOfMonth(d).atZone(zone).toInstant().toEpochMilli() },
                    local.year, local.monthValue - 1, local.dayOfMonth,
                ).show()
            }
            PickRow("Time", timeText, Modifier.weight(1f)) {
                TimePickerDialog(
                    context,
                    { _, h, min -> startMs = local.withHour(h).withMinute(min).atZone(zone).toInstant().toEpochMilli() },
                    local.hour, local.minute, true,
                ).show()
            }
        }

        SectionLabel("Pages read")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) {
                PbField(from, { from = it.filter { c -> c.isDigit() }.take(6) }, "From", keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Box(Modifier.weight(1f)) {
                PbField(to, { to = it.filter { c -> c.isDigit() }.take(6) }, "To", keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        }
        Text(
            pagesError ?: when {
                pageCount != null -> "$pageCount ${if (pageCount == 1) "page" else "pages"}"
                entry != null && entry.pages > 0 -> "Counted pages stay as they are (${entry.pages}) unless you fill this in."
                else -> "Optional. Pages are the numbers shown in the reader, like 25 / 136."
            },
            color = if (pagesError != null) DangerRed else t.setSub,
            fontSize = 13.sp,
            modifier = Modifier.padding(start = 4.dp, top = 8.dp),
        )

        SectionLabel("Time read")
        PbField(
            minutes,
            { minutes = it.filter { c -> c.isDigit() }.take(4) },
            "Minutes",
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15 to "15 m", 30 to "30 m", 45 to "45 m", 60 to "1 h").forEach { (m, label) ->
                TogglePill(label, minutesN == m) { minutes = m.toString() }
            }
        }

        Spacer(Modifier.height(28.dp))
        PbButton(
            "Save",
            enabled = canSave,
            onClick = {
                val sec = if (minutesN == minutes0 && seconds0 % 60 != 0) seconds0 else (minutesN ?: 0) * 60
                val pages = pageCount ?: entry?.pages ?: 0
                onSave(startMs, sec, pages, if (pageCount != null) fromN ?: 0 else entry?.fromPos ?: 0, if (pageCount != null) toN ?: 0 else entry?.toPos ?: 0)
            },
        )
        if (onDelete != null) {
            Spacer(Modifier.height(10.dp))
            PbButton("Delete entry", onClick = { confirmDelete = true }, ghost = true, destructive = true)
        }
    }

    if (confirmDelete && onDelete != null) {
        PbConfirmDialog(
            title = "Delete this entry?",
            message = "The time and pages of this entry are taken out of your stats.",
            confirm = "Delete",
            onConfirm = {
                confirmDelete = false
                onDelete()
            },
            onDismiss = { confirmDelete = false },
        )
    }
}

/** A tappable card with a small label and a value (a date or a time). */
@Composable
private fun PickRow(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = pbTokens()
    Column(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(t.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
    ) {
        Text(label, color = t.setSub, fontSize = 12.sp)
        Text(value, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }
}
