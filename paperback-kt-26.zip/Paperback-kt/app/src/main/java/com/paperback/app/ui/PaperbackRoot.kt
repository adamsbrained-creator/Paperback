package com.paperback.app.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import com.paperback.app.ui.theme.pbTokens
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.AppViewModel
import com.paperback.app.data.Authors
import com.paperback.app.data.Book
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.NavStyle
import com.paperback.app.data.Similar
import com.paperback.app.data.Tags
import com.paperback.app.data.Stats
import java.time.LocalDate
import kotlin.math.roundToInt

@Composable
fun PaperbackRoot(
    vm: AppViewModel,
    onPickBooks: () -> Unit,
    onOpenReader: () -> Unit,
    onSaveBackup: () -> Unit,
    onPickBackup: () -> Unit,
    onShareText: (String) -> Unit,
) {
    val books by vm.books.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val reflow by vm.reflow.collectAsStateWithLifecycle()
    // a scan takes minutes to read; the screen stays on meanwhile, because the phone may stop the work when it sleeps
    val view = LocalView.current
    val reflowing = reflow != null
    DisposableEffect(reflowing) {
        view.keepScreenOn = reflowing
        onDispose { view.keepScreenOn = false }
    }
    val message by vm.message.collectAsStateWithLifecycle()
    val headerSize by vm.headerSize.collectAsStateWithLifecycle()
    val themeMode by vm.themeMode.collectAsStateWithLifecycle()
    val navStyle by vm.navStyle.collectAsStateWithLifecycle()
    val libraryShelf by vm.libraryShelf.collectAsStateWithLifecycle()
    val accent by vm.accent.collectAsStateWithLifecycle()
    val goals by vm.goals.collectAsStateWithLifecycle()
    val backupCounts by vm.backupCounts.collectAsStateWithLifecycle()
    val pendingBackup by vm.pendingBackup.collectAsStateWithLifecycle()
    val collections by vm.collections.collectAsStateWithLifecycle()
    val membership by vm.membership.collectAsStateWithLifecycle()
    val highlights by vm.allHighlights.collectAsStateWithLifecycle()
    val bookmarks by vm.allBookmarks.collectAsStateWithLifecycle()
    val recentSearches by vm.recentSearches.collectAsStateWithLifecycle()
    val catalogOpen by vm.discover.browser.collectAsStateWithLifecycle()
    val wishlist by vm.wishlist.collectAsStateWithLifecycle()
    val openBookPage by vm.openBookPage.collectAsStateWithLifecycle()
    val timerState by vm.timer.state.collectAsStateWithLifecycle()

    // Where we are: a stack of screens, kept as text so it survives rotation. The first is a tab.
    // An entry is a Dest name ("Settings") or a screen about one thing: "Book:<id>", "Collection:<id>", "NotesOf:<bookId>".
    var stackRaw by rememberSaveable { mutableStateOf(Dest.Home.name) }
    val stack = remember(stackRaw) { stackRaw.split(',').filter { it.isNotEmpty() }.ifEmpty { listOf(Dest.Home.name) } }
    val route = stack.last()
    val kind = route.substringBefore(':')
    val arg = route.substringAfter(':', "")
    val simple: Dest? = Dest.values().firstOrNull { it.name == route }
    // Which menu entry to light up. A book page counts as Library, a collection page as Collections, a book's notes as Notes.
    val current: Dest = simple ?: when (kind) {
        "Collection" -> Dest.Collections
        "NotesOf" -> Dest.Notes
        "Tag" -> Dest.Genres
        "Author" -> Dest.Authors
        "Catalog", "Browse" -> Dest.Search
        else -> Dest.Library
    }
    val onTabScreen = simple?.isTab == true
    var searchQuery by rememberSaveable { mutableStateOf("") } // kept here so Back from a result returns to the same search
    var menuOpen by rememberSaveable { mutableStateOf(false) }
    var allOpen by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.consumeMessage()
        }
    }
    LaunchedEffect(current) {
        if (current == Dest.Backup) vm.refreshBackupCounts()
    }

    val open: (Book) -> Unit = { book -> vm.open(book, onOpenReader) }
    val pop: () -> Unit = { stackRaw = stack.dropLast(1).joinToString(",").ifEmpty { Dest.Home.name } }

    // Tabs replace each other; every other screen is pushed on top so Back returns to where you were.
    val navigate: (Dest) -> Unit = { dest ->
        menuOpen = false
        allOpen = false
        when {
            dest.isTab -> stackRaw = dest.name
            dest.name == route -> Unit
            stack.contains(dest.name) -> stackRaw = stack.take(stack.indexOf(dest.name) + 1).joinToString(",")
            else -> stackRaw = "$stackRaw,${dest.name}"
        }
    }
    val push: (String) -> Unit = { next ->
        menuOpen = false
        allOpen = false
        if (next != route) stackRaw = "$stackRaw,$next"
    }
    val details: (Book) -> Unit = { book -> push("Book:${book.id}") }
    // A tap on a book goes to its page (or straight into the reader, if you chose that in App style).
    val tapBook: (Book) -> Unit = { book -> if (openBookPage) details(book) else open(book) }
    // A genre or an author is part of the route, so it is encoded (the back-stack is comma-separated text).
    val openTag: (String) -> Unit = { tag -> push("Tag:${Uri.encode(tag)}") }
    val openAuthor: (String) -> Unit = { name -> push("Author:${Uri.encode(name)}") }
    // The online catalog: a book page is "Catalog:<id>", a "see all" grid is "Browse:<kind>~<encoded value>".
    val openCatalogBook: (CatalogBook) -> Unit = { b ->
        vm.catalog.remember(listOf(b))
        push("Catalog:${b.id}")
    }
    val browse: (String, String) -> Unit = { k, v ->
        if (k == "want") navigate(Dest.WantToRead) else push("Browse:$k~${Uri.encode(v)}")
    }
    val soon: () -> Unit = {
        menuOpen = false
        allOpen = false
        vm.say("Coming soon")
    }
    val openMenu: () -> Unit = { menuOpen = true }
    val search: () -> Unit = { navigate(Dest.Search) }
    val discover: () -> Unit = { navigate(Dest.Discover) }

    BackHandler(enabled = menuOpen || allOpen || stack.size > 1) {
        when {
            allOpen -> allOpen = false
            menuOpen -> menuOpen = false
            // inside a catalog, Back goes back one page of the catalog first
            current == Dest.Discover && catalogOpen != null -> vm.discover.back()
            else -> pop()
        }
    }

    val recommended = remember(books) { Similar.recommend(books) }
    val today = LocalDate.now()
    val secondsToday = remember(sessions) { Stats.secondsByDay(sessions)[today] ?: 0L }
    val reader = vm.readerSettings

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = {
                SnackbarHost(snackbar) { data ->
                    val t = pbTokens()
                    Snackbar(
                        data,
                        shape = RoundedCornerShape(22.dp),
                        containerColor = t.ink,
                        contentColor = t.bg,
                        actionColor = MaterialTheme.colorScheme.primary,
                    )
                }
            },
            bottomBar = {
                if (onTabScreen && navStyle == NavStyle.Bar) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.background) {
                        val colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        NavigationBarItem(
                            selected = current == Dest.Home, onClick = { navigate(Dest.Home) }, colors = colors,
                            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                            label = { Text("Home") },
                        )
                        NavigationBarItem(
                            selected = current == Dest.Library, onClick = { navigate(Dest.Library) }, colors = colors,
                            icon = {
                                LibraryGlyph(
                                    if (current == Dest.Library) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            },
                            label = { Text("Library") },
                        )
                        NavigationBarItem(
                            selected = current == Dest.Stats, onClick = { navigate(Dest.Stats) }, colors = colors,
                            icon = {
                                StatsGlyph(
                                    if (current == Dest.Stats) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            },
                            label = { Text("Stats") },
                        )
                        NavigationBarItem(
                            selected = current == Dest.Settings, onClick = { navigate(Dest.Settings) }, colors = colors,
                            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                            label = { Text("Settings") },
                        )
                    }
                }
            },
        ) { inner ->
            Box(Modifier.fillMaxSize().padding(inner)) {
                when (simple) {
                    Dest.Home, Dest.Library, Dest.Stats -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                      Column(Modifier.widthIn(max = 560.dp).fillMaxSize()) {
                        PageHeader(
                            label = when (current) {
                                Dest.Home -> "Home"
                                Dest.Library -> "Library"
                                else -> "Stats"
                            },
                            size = headerSize,
                            chip = if (current == Dest.Library) "${books.size} ${if (books.size == 1) "book" else "books"}" else null,
                            onMenu = openMenu,
                            onSearch = search,
                            modifier = Modifier.padding(horizontal = 20.dp).padding(top = 4.dp),
                        )
                        Box(Modifier.weight(1f)) {
                            when (current) {
                                Dest.Home -> HomeScreen(books, sessions, recommended, goalMinutes = goals.minutesPerDay, onOpen = tapBook, onRead = open, onDetails = details, onImport = onPickBooks, onDiscover = discover, catalog = vm.catalog, wishlist = wishlist, onOpenCatalogBook = openCatalogBook, onBrowse = browse)
                                Dest.Library -> LibraryScreen(
                                    books = books,
                                    onOpen = tapBook,
                                    onDetails = details,
                                    onImport = onPickBooks,
                                    onDiscover = discover,
                                    onToggleFavorite = vm::toggleFavorite,
                                    onToggleFinished = vm::toggleFinished,
                                    onRemove = vm::remove,
                                    shelfView = libraryShelf,
                                    onShelfView = vm::setLibraryShelf,
                                )
                                else -> ActivityScreen(books, sessions, goals, onOpenBook = details, onOpenGoals = { navigate(Dest.Goals) })
                            }
                        }
                      }
                    }

                    Dest.Settings -> SettingsScreen(
                        headerSize = headerSize,
                        secondsToday = secondsToday,
                        goalMinutes = goals.minutesPerDay,
                        readerValue = "${listOf("Light", "Sepia", "Dark")[reader.theme.coerceIn(0, 2)]} · ${(reader.fontSize * 100).roundToInt()}%",
                        appearanceValue = themeMode.label,
                        navLabel = navStyle.label,
                        version = rememberAppVersion(),
                        onMenu = openMenu,
                        onSearch = search,
                        onOpen = navigate,
                    )

                    Dest.AppStyle -> AppStyleScreen(headerSize, vm::setHeaderSize, navStyle, vm::setNavStyle, openBookPage, vm::setOpenBookPage, openMenu, search)

                    Dest.About -> AboutScreen(headerSize, rememberAppVersion(), openMenu, search)

                    Dest.Appearance -> AppearanceScreen(headerSize, themeMode, vm::setThemeMode, accent, vm::setAccent, openMenu, search)

                    Dest.Goals -> GoalsScreen(headerSize, goals, books, sessions, vm::setGoals, openMenu, search)

                    Dest.ReaderDefaults -> ReaderDefaultsScreen(
                        headerSize = headerSize,
                        fontSize = reader.fontSize,
                        theme = reader.theme,
                        look = reader.look,
                        onFontSize = { reader.fontSize = it },
                        onTheme = { reader.theme = it },
                        onLook = { reader.look = it },
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Import -> ImportScreen(
                        headerSize = headerSize,
                        busy = busy,
                        onPick = onPickBooks,
                        onDiscover = discover,
                        onLibrary = { navigate(Dest.Library) },
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Backup -> BackupScreen(
                        headerSize = headerSize,
                        counts = backupCounts,
                        pending = pendingBackup,
                        onSave = onSaveBackup,
                        onPick = onPickBackup,
                        onApply = vm::applyBackup,
                        onCancel = vm::cancelBackup,
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Discover -> DiscoverScreen(
                        controller = vm.discover,
                        books = books,
                        headerSize = headerSize,
                        onOpenBook = open,
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Search -> SearchScreen(
                        query = searchQuery,
                        onQuery = { searchQuery = it },
                        recent = recentSearches,
                        onCommit = vm::addRecentSearch,
                        onClearRecent = vm::clearRecentSearches,
                        books = books,
                        collections = collections,
                        membership = membership,
                        highlights = highlights,
                        headerSize = headerSize,
                        onMenu = openMenu,
                        onOpenBook = details,
                        onOpenCollection = { push("Collection:${it.id}") },
                        onOpenNote = { book, place -> vm.open(book, onOpenReader, place) },
                        onOpenPage = navigate,
                        onOpenTag = openTag,
                        onOpenAuthor = openAuthor,
                        catalog = vm.catalog,
                        wishlist = wishlist,
                        onOpenCatalogBook = openCatalogBook,
                        onBrowse = browse,
                    )

                    Dest.WantToRead -> WantToReadScreen(
                        items = wishlist,
                        headerSize = headerSize,
                        onMenu = openMenu,
                        onSearch = search,
                        onOpenBook = openCatalogBook,
                        onRemove = { vm.removeFromWishlist(it.id) },
                    )

                    Dest.Collections -> CollectionsScreen(
                        collections = collections,
                        membership = membership,
                        books = books,
                        headerSize = headerSize,
                        onMenu = openMenu,
                        onSearch = search,
                        onOpen = { push("Collection:${it.id}") },
                        onCreate = vm::createCollection,
                    )

                    Dest.Notes, Dest.Bookmarks -> NotesScreen(
                        books = books,
                        highlights = highlights,
                        bookmarks = bookmarks,
                        onlyBookId = null,
                        initialTab = if (simple == Dest.Bookmarks) 1 else 0,
                        headerSize = headerSize,
                        onMenu = openMenu,
                        onSearch = search,
                        onOpenAt = { book, place -> vm.open(book, onOpenReader, place) },
                        onDeleteHighlight = vm::deleteHighlight,
                        onDeleteBookmark = vm::deleteBookmark,
                        onShare = onShareText,
                    )

                    Dest.Genres -> {
                        val counts = remember(books) { Tags.counts(books) }
                        NameCountScreen(
                            label = "Genres",
                            items = counts,
                            emptyText = "No genres yet. Paperback reads them from your books, and from Discover downloads, and fills this page in.",
                            filterHint = "Filter genres",
                            headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpen = openTag,
                        )
                    }

                    Dest.Authors -> {
                        val counts = remember(books) { Authors.counts(books) }
                        NameCountScreen(
                            label = "Authors",
                            items = counts,
                            emptyText = "No authors yet. Add books and they show up here.",
                            filterHint = "Filter authors",
                            headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpen = openAuthor,
                        )
                    }

                    Dest.Reading -> ShelfScreen(
                        label = "Currently reading",
                        books = books.filter { it.isReading }.sortedByDescending { it.lastOpenedAt },
                        emptyText = "Nothing in progress. Open a book to start.",
                        headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                    )

                    Dest.Recent -> ShelfScreen(
                        label = "Recently read",
                        books = books.filter { it.lastOpenedAt > 0 }.sortedByDescending { it.lastOpenedAt },
                        emptyText = "Books you open show up here.",
                        headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                    )

                    Dest.Finished -> ShelfScreen(
                        label = "Finished",
                        books = books.filter { it.finished }.sortedByDescending { if (it.finishedAt > 0) it.finishedAt else it.lastOpenedAt },
                        emptyText = "No finished books yet.",
                        headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                    )

                    Dest.Favorites -> ShelfScreen(
                        label = "Favorites",
                        books = books.filter { it.favorite },
                        emptyText = "No favorites yet. Open a book's page and tap Favorite.",
                        headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                    )

                    // Screens about one thing: a book, a collection, one book's notes.
                    null -> when (kind) {
                        "Book" -> {
                            val book = books.firstOrNull { it.id == arg }
                            if (book == null) {
                                // not loaded yet, or just removed: leave once the library is known
                                if (books.isNotEmpty()) LaunchedEffect(Unit) { pop() }
                            } else {
                                val similar = remember(books, book) { Similar.like(book, books) }
                                BookDetailScreen(
                                    book = book,
                                    sessions = sessions,
                                    collections = collections,
                                    membership = membership,
                                    noteCount = highlights.count { it.bookId == book.id },
                                    bookmarkCount = bookmarks.count { it.bookId == book.id },
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onRead = { open(book) },
                                    onToggleFavorite = { vm.toggleFavorite(book) },
                                    onToggleFinished = { vm.toggleFinished(book) },
                                    onRate = { vm.rate(book, it) },
                                    onSaveJournal = { vm.saveJournal(book, it) },
                                    onToggleCollection = { c ->
                                        vm.setMember(c, book, membership[c.id]?.contains(book.id) != true)
                                    },
                                    onOpenNotes = { push("NotesOf:${book.id}") },
                                    similar = similar,
                                    onOpenBook = details,
                                    onOpenTag = openTag,
                                    onOpenAuthor = openAuthor,
                                    reflow = reflow,
                                    onReflow = { vm.reflowPdf(book) },
                                    onCancelReflow = vm::cancelReflow,
                                    timerRunning = timerState.running && timerState.bookId == book.id,
                                    onStartTimer = { push("Timer:${book.id}") },
                                    onAddEntry = { push("Entry:${book.id}~0~0~${System.currentTimeMillis()}") },
                                    onEditEntry = { e -> push("Entry:${book.id}~${e.id}~${e.seconds}~${e.startMs}") },
                                    onRemove = {
                                        vm.remove(book)
                                        pop()
                                    },
                                )
                            }
                        }

                        "Collection" -> {
                            val c = collections.firstOrNull { it.id == arg }
                            if (c == null) {
                                LaunchedEffect(Unit) { pop() }
                            } else {
                                CollectionDetailScreen(
                                    collection = c,
                                    allBooks = books,
                                    memberIds = membership[c.id].orEmpty(),
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onOpenBook = details,
                                    onRename = { vm.renameCollection(c, it) },
                                    onDelete = {
                                        vm.deleteCollection(c)
                                        pop()
                                    },
                                    onSetMember = { book, member -> vm.setMember(c, book, member) },
                                )
                            }
                        }

                        "NotesOf" -> NotesScreen(
                            books = books,
                            highlights = highlights,
                            bookmarks = bookmarks,
                            onlyBookId = arg,
                            initialTab = 0,
                            headerSize = headerSize,
                            onMenu = openMenu,
                            onSearch = search,
                            onOpenAt = { book, place -> vm.open(book, onOpenReader, place) },
                            onDeleteHighlight = vm::deleteHighlight,
                            onDeleteBookmark = vm::deleteBookmark,
                            onShare = onShareText,
                        )

                        "Tag" -> {
                            val tag = remember(arg) { Uri.decode(arg) }
                            ShelfScreen(
                                label = tag,
                                books = remember(books, tag) { books.filter { Tags.has(it, tag) }.sortedBy { it.title.lowercase() } },
                                emptyText = "No books with this genre.",
                                headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                            )
                        }

                        "Author" -> {
                            val name = remember(arg) { Uri.decode(arg) }
                            ShelfScreen(
                                label = name,
                                books = remember(books, name) { books.filter { Authors.has(it, name) }.sortedBy { it.title.lowercase() } },
                                emptyText = "No books by this author.",
                                headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                            )
                        }

                        "Catalog" -> {
                            val cb = remember(arg) { vm.catalog.find(arg) }
                            if (cb == null) {
                                // the app was restarted on this page and the book is not in memory any more
                                LaunchedEffect(Unit) { pop() }
                            } else {
                                CatalogBookScreen(
                                    book = cb,
                                    owned = books.firstOrNull { TitleKey.same(it.title, cb.title) },
                                    wished = wishlist.any { it.id == cb.id },
                                    onToggleWish = { vm.toggleWishlist(cb) },
                                    ownedKeys = remember(books) { ownedKeys(books) },
                                    catalog = vm.catalog,
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onOpenOwned = details,
                                    onOpenCatalogBook = openCatalogBook,
                                    onBrowse = browse,
                                )
                            }
                        }

                        "Timer" -> {
                            val tb = books.firstOrNull { it.id == arg }
                            if (tb == null) {
                                if (books.isNotEmpty()) LaunchedEffect(Unit) { pop() }
                            } else {
                                val busyWith = timerState.takeIf { it.active && it.bookId != tb.id }?.bookId
                                ReadingTimerScreen(
                                    book = tb,
                                    timer = vm.timer,
                                    otherTitle = busyWith?.let { id -> books.firstOrNull { it.id == id }?.title },
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onFinish = { seconds, startMs -> push("Entry:${tb.id}~0~$seconds~$startMs") },
                                    onOpenOther = { busyWith?.let { push("Timer:$it") } },
                                )
                            }
                        }

                        "Entry" -> {
                            val parts = arg.split('~')
                            val eBookId = parts.getOrElse(0) { "" }
                            val eId = parts.getOrElse(1) { "0" }.toLongOrNull() ?: 0L
                            val eSeconds = parts.getOrElse(2) { "0" }.toIntOrNull() ?: 0
                            val eStart = parts.getOrElse(3) { "0" }.toLongOrNull() ?: System.currentTimeMillis()
                            val eb = books.firstOrNull { it.id == eBookId }
                            val existing = if (eId != 0L) sessions.firstOrNull { it.id == eId } else null
                            if (eb == null || (eId != 0L && existing == null && sessions.isNotEmpty())) {
                                if (books.isNotEmpty()) LaunchedEffect(Unit) { pop() }
                            } else {
                                // after saving, go back to the book page, past the timer if it was used
                                val backToBook: () -> Unit = {
                                    stackRaw = stack.dropLastWhile { it.startsWith("Timer:") || it.startsWith("Entry:") }
                                        .joinToString(",").ifEmpty { Dest.Home.name }
                                }
                                EntryScreen(
                                    book = eb,
                                    entry = existing,
                                    initialSeconds = eSeconds,
                                    initialStartMs = eStart,
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onSave = { startMs, seconds, pages, from, to ->
                                        vm.saveEntry(eId, eb.id, startMs, seconds, pages, from, to)
                                        if (eId == 0L && eSeconds > 0 && timerState.bookId == eb.id) vm.timer.clear()
                                        backToBook()
                                    },
                                    onDelete = if (existing != null) {
                                        {
                                            vm.deleteEntry(existing.id)
                                            pop()
                                        }
                                    } else null,
                                )
                            }
                        }

                        "Browse" -> {
                            val browseKind = arg.substringBefore('~')
                            val browseValue = remember(arg) { Uri.decode(arg.substringAfter('~', "")) }
                            CatalogBrowseScreen(
                                kind = browseKind,
                                arg = browseValue,
                                ownedKeys = remember(books) { ownedKeys(books) },
                                catalog = vm.catalog,
                                headerSize = headerSize,
                                onMenu = openMenu,
                                onSearch = search,
                                onOpenBook = openCatalogBook,
                            )
                        }

                        else -> LaunchedEffect(route) { pop() }
                    }
                }
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }

        // Screens that are not tabs get the round menu button at the bottom right, like the old app's Settings.
        if (!onTabScreen && !menuOpen) {
            MenuFab(
                onClick = openMenu,
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 24.dp),
            )
        }

        MenuOverlay(
            open = menuOpen,
            current = current,
            onClose = { menuOpen = false },
            onGo = navigate,
            onSoon = soon,
            onMore = {
                menuOpen = false
                allOpen = true
            },
        )
        AllPagesSheet(open = allOpen, onClose = { allOpen = false }, onGo = navigate, onSoon = soon)
    }
}
