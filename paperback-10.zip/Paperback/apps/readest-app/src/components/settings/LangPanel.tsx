import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { useSettingsStore } from '@/store/settingsStore';
import { useKeyDownActions } from '@/hooks/useKeyDownActions';
import { SettingsPanelPanelProp } from './SettingsDialog';
import { BoxedList, NavigationRow } from './primitives';
import CustomDictionaries from './CustomDictionaries';
import WordLensPanel from './WordLensPanel';
import { PiTranslate } from 'react-icons/pi';

const LangPanel: React.FC<SettingsPanelPanelProp> = ({ bookKey, onRegisterReset }) => {
  const _ = useTranslation();
  const { activeSettingsItemId, setActiveSettingsItemId } = useSettingsStore();

  const [showCustomDictionaries, setShowCustomDictionaries] = useState(false);
  const [showWordLens, setShowWordLens] = useState(false);

  // Android Back / Esc: when a sub-page is open, intercept and step back to the
  // language list instead of letting <Dialog>'s listener close the whole
  // Settings dialog. See the matching comment in FontPanel.tsx for the
  // LIFO-dispatch reasoning.
  useKeyDownActions({
    enabled: showCustomDictionaries,
    onCancel: () => setShowCustomDictionaries(false),
  });
  useKeyDownActions({
    enabled: showWordLens,
    onCancel: () => setShowWordLens(false),
  });

  // Deep-link: callers (e.g. the dictionary popup's manage icon) can set
  // activeSettingsItemId to `'settings.language.dictionaries.manage'` to
  // jump straight into the Manage Dictionaries sub-page on open. Clear the
  // id once consumed so SettingsDialog's scroll-to-element fallback
  // (which runs on a 100ms timeout) doesn't re-fire.
  useEffect(() => {
    if (activeSettingsItemId === 'settings.language.dictionaries.manage') {
      setShowCustomDictionaries(true);
      setActiveSettingsItemId(null);
    }
  }, [activeSettingsItemId, setActiveSettingsItemId]);

  // Nothing on this page has a stored per-book value to reset.
  useEffect(() => {
    onRegisterReset(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (showCustomDictionaries) {
    return (
      <div className='my-4 w-full'>
        <CustomDictionaries onBack={() => setShowCustomDictionaries(false)} />
      </div>
    );
  }

  if (showWordLens) {
    return <WordLensPanel bookKey={bookKey} onBack={() => setShowWordLens(false)} />;
  }

  return (
    <div className={clsx('my-4 w-full space-y-6')}>
      <BoxedList
        title={_('Dictionaries')}
        data-setting-id='settings.language.dictionaries'
        cardClassName='overflow-hidden'
      >
        <NavigationRow
          title={_('Manage Dictionaries')}
          onClick={() => setShowCustomDictionaries(true)}
          className='h-14'
        />
      </BoxedList>

      <BoxedList
        title={_('Word Lens')}
        data-setting-id='settings.language.wordlens'
        cardClassName='overflow-hidden'
      >
        <NavigationRow
          icon={PiTranslate}
          title={_('Word Lens')}
          status={_('Show a short native-language hint above difficult words.')}
          onClick={() => setShowWordLens(true)}
        />
      </BoxedList>
    </div>
  );
};

export default LangPanel;
