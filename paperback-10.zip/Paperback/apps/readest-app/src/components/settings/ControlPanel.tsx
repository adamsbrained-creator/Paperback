import React, { useEffect, useRef, useState } from 'react';
import { useEnv } from '@/context/EnvContext';
import { useReaderStore } from '@/store/readerStore';
import { useTranslation } from '@/hooks/useTranslation';
import { useBookDataStore } from '@/store/bookDataStore';
import { useSettingsStore } from '@/store/settingsStore';
import { useResetViewSettings } from '@/hooks/useResetSettings';
import { useEinkMode } from '@/hooks/useEinkMode';
import { getStyles } from '@/utils/style';
import { getMaxInlineSize } from '@/utils/config';
import { saveSysSettings, saveViewSettings } from '@/helpers/settings';
import { PageTurnStyle } from '@/types/book';
import { SettingsPanelPanelProp } from './SettingsDialog';
import { annotationToolQuickActions } from '@/app/reader/components/annotator/AnnotationTools';
import { applyPageTurnAttributes } from '@/app/reader/hooks/useCapturedTurn';
import { isTauriAppPlatform } from '@/services/environment';
import {
  BoxedList,
  NavigationRow,
  SettingsRow,
  SettingsSelect,
  SettingsSwitchRow,
} from './primitives';
import NumberInput from './NumberInput';
import PageTurnerSettings from './PageTurnerSettings';
import AnnotationToolbarCustomizer from './AnnotationToolbarCustomizer';
import { DEFAULT_ANNOTATION_TOOLBAR_ITEMS } from '@/utils/annotationToolbar';
import { canShareText } from '@/utils/share';
import { useEinkRefreshSupported } from '@/hooks/useEinkRefreshSupported';

const ControlPanel: React.FC<SettingsPanelPanelProp> = ({ bookKey, onRegisterReset }) => {
  const _ = useTranslation();
  const { envConfig, appService } = useEnv();
  const { getView, getViews, getViewSettings, recreateViewer } = useReaderStore();
  const { getBookData } = useBookDataStore();
  const { settings } = useSettingsStore();
  const { applyEinkMode } = useEinkMode();
  const bookData = getBookData(bookKey);
  const viewSettings = getViewSettings(bookKey) || settings.globalViewSettings;

  const [isScrolledMode, setScrolledMode] = useState(viewSettings.scrolled);
  const [noContinuousScroll, setNoContinuousScroll] = useState(viewSettings.noContinuousScroll);
  const [scrollingOverlap, setScrollingOverlap] = useState(viewSettings.scrollingOverlap);
  const [hideScrollbar, setHideScrollbar] = useState(viewSettings.hideScrollbar || false);
  const [showPaginationButtons, setShowPaginationButtons] = useState(
    viewSettings.showPaginationButtons,
  );
  const [isDisableClick, setIsDisableClick] = useState(viewSettings.disableClick);
  const [isDisableSwipe, setIsDisableSwipe] = useState(viewSettings.disableSwipe);
  const [disablePullDownToBookmark, setDisablePullDownToBookmark] = useState(
    viewSettings.disablePullDownToBookmark ?? false,
  );
  const [fullscreenClickArea, setFullscreenClickArea] = useState(viewSettings.fullscreenClickArea);
  const [swapClickArea, setSwapClickArea] = useState(viewSettings.swapClickArea);
  const [isDisableDoubleClick, setIsDisableDoubleClick] = useState(viewSettings.disableDoubleClick);
  const [enableAnnotationQuickActions, setEnableAnnotationQuickActions] = useState(
    viewSettings.enableAnnotationQuickActions,
  );
  const [annotationQuickAction, setAnnotationQuickAction] = useState(
    viewSettings.annotationQuickAction,
  );
  const [keepSelectionAfterLookup, setKeepSelectionAfterLookup] = useState(
    viewSettings.keepSelectionAfterLookup,
  );
  const [copyToNotebook, setCopyToNotebook] = useState(viewSettings.copyToNotebook);
  const [showToolbarCustomizer, setShowToolbarCustomizer] = useState(false);
  const [animated, setAnimated] = useState(viewSettings.animated);
  const [pageTurnStyle, setPageTurnStyle] = useState(viewSettings.pageTurnStyle || 'push');
  const [isEink, setIsEink] = useState(viewSettings.isEink);
  const [isColorEink, setIsColorEink] = useState(viewSettings.isColorEink);
  const [einkAutoRefreshInterval, setEinkAutoRefreshInterval] = useState(
    viewSettings.einkAutoRefreshInterval,
  );
  // Whether this device exposes a full-refresh mechanism we can drive. The
  // "Auto Full Refresh" row is only offered when true, so it never appears on
  // panels (or phones) where the deep refresh silently does nothing.
  const einkRefreshSupported = useEinkRefreshSupported();
  const [autoScreenBrightness, setAutoScreenBrightness] = useState(settings.autoScreenBrightness);
  const [swipeBrightnessGesture, setSwipeBrightnessGesture] = useState(
    settings.swipeBrightnessGesture,
  );
  const [screenWakeLock, setScreenWakeLock] = useState(settings.screenWakeLock);
  const [autohideCursor, setAutohideCursor] = useState(settings.autohideCursor);
  const [gamepadEnabled, setGamepadEnabled] = useState(settings.gamepadEnabled);
  const [reverseWheelPaging, setReverseWheelPaging] = useState(settings.reverseWheelPaging);
  const [hideBookshelfPageButtons, setHideBookshelfPageButtons] = useState(
    settings.hideBookshelfPageButtons,
  );
  const [allowScript, setAllowScript] = useState(viewSettings.allowScript);

  const resetToDefaults = useResetViewSettings();
  const pageTurnerResetRef = useRef<() => void>(() => {});
  const canShare = canShareText(appService);

  // The layered styles need an engine with full View Transitions support or
  // the Tauri captured-turn fallback; engines like iOS 18 WebKit crash on
  // the VT turns, so on the web they only get Push (readest#555).
  const turnStyleOptions = [
    { value: 'push', label: _('Push') },
    ...(appService?.supportsViewTransitionGroup || isTauriAppPlatform()
      ? [
          { value: 'slide', label: _('Slide') },
          { value: 'curl', label: _('Page Curl') },
        ]
      : []),
  ];

  const einkAutoRefreshIntervalOptions = [
    { value: '0', label: _('Off') },
    { value: '5', label: _('Every 5 pages') },
    { value: '10', label: _('Every 10 pages') },
    { value: '15', label: _('Every 15 pages') },
    { value: '20', label: _('Every 20 pages') },
  ];
  // A synced value outside the offered set (written by another/newer client) has
  // no matching <option>, so the controlled select would resolve selectedIndex -1
  // and render blank, hiding the active interval. Surface it as an extra option —
  // shown, never rewritten — so the display still matches what noteEinkPageTurn
  // actually reads, without coercing or destroying the stored value.
  const currentInterval = String(einkAutoRefreshInterval);
  const einkAutoRefreshIntervalChoices = einkAutoRefreshIntervalOptions.some(
    (opt) => opt.value === currentInterval,
  )
    ? einkAutoRefreshIntervalOptions
    : [...einkAutoRefreshIntervalOptions, { value: currentInterval, label: currentInterval }];
  const handleReset = () => {
    resetToDefaults({
      scrolled: setScrolledMode,
      noContinuousScroll: setNoContinuousScroll,
      scrollingOverlap: setScrollingOverlap,
      hideScrollbar: setHideScrollbar,
      showPaginationButtons: setShowPaginationButtons,
      disableClick: setIsDisableClick,
      disableSwipe: setIsDisableSwipe,
      disablePullDownToBookmark: setDisablePullDownToBookmark,
      swapClickArea: setSwapClickArea,
      animated: setAnimated,
      pageTurnStyle: setPageTurnStyle,
      isEink: setIsEink,
      einkAutoRefreshInterval: setEinkAutoRefreshInterval,
      allowScript: setAllowScript,
      fullscreenClickArea: setFullscreenClickArea,
      disableDoubleClick: setIsDisableDoubleClick,
      enableAnnotationQuickActions: setEnableAnnotationQuickActions,
      keepSelectionAfterLookup: setKeepSelectionAfterLookup,
      copyToNotebook: setCopyToNotebook,
    });
    saveViewSettings(
      envConfig,
      bookKey,
      'annotationToolbarItems',
      DEFAULT_ANNOTATION_TOOLBAR_ITEMS,
      false,
      true,
    );
    pageTurnerResetRef.current();
    // Keyboard/mouse bindings are NOT reset here — they are device-local and
    // have their own "Reset all" inside the Keyboard Shortcuts sub-page.
  };

  useEffect(() => {
    onRegisterReset(handleReset);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (isScrolledMode === viewSettings.scrolled) return;
    saveViewSettings(envConfig, bookKey, 'scrolled', isScrolledMode);
    getView(bookKey)?.renderer.setAttribute('flow', isScrolledMode ? 'scrolled' : 'paginated');
    getView(bookKey)?.renderer.setAttribute(
      'max-inline-size',
      `${getMaxInlineSize(viewSettings)}px`,
    );
    getView(bookKey)?.renderer.setStyles?.(getStyles(viewSettings!));
    // `scrolled` decides which engine owns a swipe, so it has to push the turn
    // attributes through like every other input to that decision. Left stale,
    // the paginator keeps `turn-style`/no `no-swipe` from scroll flow and
    // animates the swipe itself while the interceptor — which recomputes
    // eligibility live — runs a captured turn over the top: three pages slide.
    applyTurnAttributes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isScrolledMode]);

  useEffect(() => {
    if (noContinuousScroll === viewSettings.noContinuousScroll) return;
    saveViewSettings(envConfig, bookKey, 'noContinuousScroll', noContinuousScroll);
    if (noContinuousScroll) {
      getView(bookKey)?.renderer.setAttribute('no-continuous-scroll', '');
    } else {
      getView(bookKey)?.renderer.removeAttribute('no-continuous-scroll');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [noContinuousScroll]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'hideScrollbar', hideScrollbar, false, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hideScrollbar]);

  useEffect(() => {
    if (scrollingOverlap === viewSettings.scrollingOverlap) return;
    saveViewSettings(envConfig, bookKey, 'scrollingOverlap', scrollingOverlap, false, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scrollingOverlap]);

  useEffect(() => {
    saveViewSettings(
      envConfig,
      bookKey,
      'showPaginationButtons',
      showPaginationButtons,
      false,
      false,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showPaginationButtons]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'disableClick', isDisableClick, false, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDisableClick]);

  // The renderer reads `turn-style`/`no-swipe` at touchmove/touchend time, so
  // settings changes have to push the attributes through immediately rather
  // than waiting for the next recreateViewer pass.
  const applyTurnAttributes = () => {
    const view = getView(bookKey);
    const freshSettings = getViewSettings(bookKey);
    if (view && freshSettings) {
      applyPageTurnAttributes(view, freshSettings, !!bookData?.isFixedLayout);
    }
  };

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'disableSwipe', isDisableSwipe, false, false);
    applyTurnAttributes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDisableSwipe]);

  useEffect(() => {
    saveViewSettings(
      envConfig,
      bookKey,
      'disablePullDownToBookmark',
      disablePullDownToBookmark,
      false,
      false,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [disablePullDownToBookmark]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'disableDoubleClick', isDisableDoubleClick, false, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDisableDoubleClick]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'fullscreenClickArea', fullscreenClickArea, false, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fullscreenClickArea]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'swapClickArea', swapClickArea, false, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [swapClickArea]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'animated', animated, false, false);
    if (animated) {
      getView(bookKey)?.renderer.setAttribute('animated', '');
    } else {
      getView(bookKey)?.renderer.removeAttribute('animated');
    }
    // Mesh-curl eligibility depends on `animated`.
    applyTurnAttributes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [animated]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'pageTurnStyle', pageTurnStyle, false, false);
    applyTurnAttributes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageTurnStyle]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'isEink', isEink);
    if (isEink) {
      getView(bookKey)?.renderer.setAttribute('eink', '');
    } else {
      getView(bookKey)?.renderer.removeAttribute('eink');
    }
    applyEinkMode(isEink);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEink]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'isColorEink', isColorEink);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isColorEink]);

  useEffect(() => {
    if (einkAutoRefreshInterval === viewSettings.einkAutoRefreshInterval) return;
    saveViewSettings(
      envConfig,
      bookKey,
      'einkAutoRefreshInterval',
      einkAutoRefreshInterval,
      false,
      false,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [einkAutoRefreshInterval]);

  useEffect(() => {
    if (autoScreenBrightness === settings.autoScreenBrightness) return;
    saveSysSettings(envConfig, 'autoScreenBrightness', autoScreenBrightness);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoScreenBrightness]);

  useEffect(() => {
    if (swipeBrightnessGesture === settings.swipeBrightnessGesture) return;
    saveSysSettings(envConfig, 'swipeBrightnessGesture', swipeBrightnessGesture);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [swipeBrightnessGesture]);

  useEffect(() => {
    if (screenWakeLock === settings.screenWakeLock) return;
    saveSysSettings(envConfig, 'screenWakeLock', screenWakeLock);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screenWakeLock]);

  useEffect(() => {
    if (autohideCursor === settings.autohideCursor) return;
    saveSysSettings(envConfig, 'autohideCursor', autohideCursor);
    getViews().forEach((view) => view?.toggleAttribute('autohide-cursor', autohideCursor));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autohideCursor]);

  useEffect(() => {
    if (gamepadEnabled === settings.gamepadEnabled) return;
    saveSysSettings(envConfig, 'gamepadEnabled', gamepadEnabled);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gamepadEnabled]);

  useEffect(() => {
    if (reverseWheelPaging === settings.reverseWheelPaging) return;
    saveSysSettings(envConfig, 'reverseWheelPaging', reverseWheelPaging);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reverseWheelPaging]);

  useEffect(() => {
    if (hideBookshelfPageButtons === settings.hideBookshelfPageButtons) return;
    saveSysSettings(envConfig, 'hideBookshelfPageButtons', hideBookshelfPageButtons);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hideBookshelfPageButtons]);

  useEffect(() => {
    if (viewSettings.allowScript === allowScript) return;
    saveViewSettings(envConfig, bookKey, 'allowScript', allowScript, true, false).then(() => {
      recreateViewer(envConfig, bookKey);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowScript]);

  useEffect(() => {
    saveViewSettings(
      envConfig,
      bookKey,
      'enableAnnotationQuickActions',
      enableAnnotationQuickActions,
      false,
      false,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enableAnnotationQuickActions]);

  useEffect(() => {
    saveViewSettings(
      envConfig,
      bookKey,
      'keepSelectionAfterLookup',
      keepSelectionAfterLookup,
      false,
      false,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [keepSelectionAfterLookup]);

  useEffect(() => {
    saveViewSettings(envConfig, bookKey, 'copyToNotebook', copyToNotebook, false, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [copyToNotebook]);

  const getQuickActionOptions = () => {
    return [
      {
        value: '',
        label: _('None'),
      },
      ...annotationToolQuickActions
        .filter((button) => button.type !== 'share' || canShare)
        .map((button) => ({
          value: button.type,
          label: _(button.label),
        })),
    ];
  };

  const handleSelectAnnotationQuickAction = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const action = event.target.value as typeof annotationQuickAction;
    setAnnotationQuickAction(action);
    saveViewSettings(envConfig, bookKey, 'annotationQuickAction', action, false, true);
  };

  if (showToolbarCustomizer) {
    return (
      <AnnotationToolbarCustomizer
        bookKey={bookKey}
        onBack={() => setShowToolbarCustomizer(false)}
      />
    );
  }

  return (
    <div className='my-4 w-full space-y-6'>
      <BoxedList title={_('Scroll')} data-setting-id='settings.control.scrolledMode'>
        <SettingsSwitchRow
          label={_('Scrolled Mode')}
          checked={isScrolledMode}
          onChange={() => setScrolledMode(!isScrolledMode)}
        />
        <SettingsSwitchRow
          label={_('Single Section Scroll')}
          checked={noContinuousScroll}
          disabled={!viewSettings.scrolled}
          onChange={() => setNoContinuousScroll(!noContinuousScroll)}
          data-setting-id='settings.control.scroll.noContinuousScroll'
        />
        {bookData?.isFixedLayout && (
          <NumberInput
            label={_('Overlap Pixels')}
            value={scrollingOverlap}
            onChange={setScrollingOverlap}
            disabled={!viewSettings.scrolled}
            min={0}
            max={200}
            step={10}
            data-setting-id='settings.control.overlapPixels'
          />
        )}
        <SettingsSwitchRow
          label={_('Hide Scrollbar')}
          checked={hideScrollbar}
          disabled={!viewSettings.scrolled}
          onChange={() => setHideScrollbar(!hideScrollbar)}
          data-setting-id='settings.control.scroll.hideScrollbar'
        />
      </BoxedList>

      <BoxedList title={_('Pagination')} data-setting-id='settings.control.clickToPaginate'>
        <SettingsSwitchRow
          label={appService?.isMobileApp ? _('Tap to Paginate') : _('Click to Paginate')}
          checked={!isDisableClick}
          onChange={() => setIsDisableClick(!isDisableClick)}
        />
        <SettingsSwitchRow
          label={_('Swipe to Paginate')}
          checked={!isDisableSwipe}
          onChange={() => setIsDisableSwipe(!isDisableSwipe)}
          data-setting-id='settings.control.swipeToPaginate'
        />
        <SettingsSwitchRow
          label={appService?.isMobileApp ? _('Tap Both Sides') : _('Click Both Sides')}
          checked={fullscreenClickArea}
          disabled={isDisableClick}
          onChange={() => setFullscreenClickArea(!fullscreenClickArea)}
          data-setting-id='settings.control.clickBothSides'
        />
        <SettingsSwitchRow
          label={appService?.isMobileApp ? _('Swap Tap Sides') : _('Swap Click Sides')}
          checked={swapClickArea}
          disabled={isDisableClick || fullscreenClickArea}
          onChange={() => setSwapClickArea(!swapClickArea)}
          data-setting-id='settings.control.swapClickSides'
        />
        <SettingsSwitchRow
          label={appService?.isMobileApp ? _('Disable Double Tap') : _('Disable Double Click')}
          checked={isDisableDoubleClick}
          onChange={() => setIsDisableDoubleClick(!isDisableDoubleClick)}
          data-setting-id='settings.control.disableDoubleClick'
        />
        <SettingsSwitchRow
          label={_('Show Page Navigation Buttons')}
          checked={showPaginationButtons}
          onChange={() => setShowPaginationButtons(!showPaginationButtons)}
          data-setting-id='settings.control.showPaginationButtons'
        />
      </BoxedList>

      <PageTurnerSettings
        bookKey={bookKey}
        onRegisterReset={(fn) => {
          pageTurnerResetRef.current = fn;
        }}
      />

      <BoxedList
        title={_('Annotation Tools')}
        data-setting-id='settings.control.enableQuickActions'
      >
        <SettingsSwitchRow
          label={_('Pull-Down to Bookmark')}
          checked={!disablePullDownToBookmark}
          onChange={() => setDisablePullDownToBookmark(!disablePullDownToBookmark)}
          data-setting-id='settings.control.disablePullDownToBookmark'
        />
        <SettingsSwitchRow
          label={_('Enable Quick Actions')}
          checked={enableAnnotationQuickActions}
          onChange={() => setEnableAnnotationQuickActions(!enableAnnotationQuickActions)}
        />
        <SettingsRow label={_('Quick Action')} data-setting-id='settings.control.quickAction'>
          <SettingsSelect
            value={annotationQuickAction || ''}
            onChange={handleSelectAnnotationQuickAction}
            ariaLabel={_('Quick Action')}
            options={getQuickActionOptions()}
            disabled={!enableAnnotationQuickActions}
          />
        </SettingsRow>
        {annotationQuickAction === 'dictionary' && (
          <SettingsSwitchRow
            label={_('Keep Text Selected After Lookup')}
            checked={keepSelectionAfterLookup}
            disabled={!enableAnnotationQuickActions}
            onChange={() => setKeepSelectionAfterLookup(!keepSelectionAfterLookup)}
            data-setting-id='settings.control.keepSelectionAfterLookup'
          />
        )}
        <SettingsSwitchRow
          label={_('Copy to Notebook')}
          checked={copyToNotebook}
          onChange={() => setCopyToNotebook(!copyToNotebook)}
          data-setting-id='settings.control.copyToNotebook'
        />
        <NavigationRow
          title={_('Customize Toolbar')}
          onClick={() => setShowToolbarCustomizer(true)}
          data-setting-id='settings.control.customizeToolbar'
        />
      </BoxedList>

      <BoxedList title={_('Animation')} data-setting-id='settings.control.pagingAnimation'>
        <SettingsSwitchRow
          label={_('Paging Animation')}
          checked={animated}
          onChange={() => setAnimated(!animated)}
        />
        <SettingsRow label={_('Animation Style')} data-setting-id='settings.control.pageTurnStyle'>
          <SettingsSelect
            // A synced slide/curl setting from another device still reads as
            // push here when this engine cannot animate it.
            value={
              turnStyleOptions.some((opt) => opt.value === pageTurnStyle) ? pageTurnStyle : 'push'
            }
            onChange={(e) => setPageTurnStyle(e.target.value as PageTurnStyle)}
            ariaLabel={_('Animation Style')}
            options={turnStyleOptions}
            disabled={!animated}
          />
        </SettingsRow>
      </BoxedList>

      <BoxedList title={_('Device')} data-setting-id='settings.control.device'>
        <SettingsSwitchRow
          label={_('E-Ink Mode')}
          checked={isEink}
          onChange={() => setIsEink(!isEink)}
          data-setting-id='settings.control.einkMode'
        />
        {appService?.isAndroidApp && einkRefreshSupported && (
          <SettingsRow
            label={_('Auto Full Refresh')}
            disabled={!isEink}
            data-setting-id='settings.control.autoFullRefresh'
          >
            <SettingsSelect
              value={String(einkAutoRefreshInterval)}
              onChange={(e) => setEinkAutoRefreshInterval(Number(e.target.value))}
              ariaLabel={_('Auto Full Refresh')}
              disabled={!isEink}
              options={einkAutoRefreshIntervalChoices}
            />
          </SettingsRow>
        )}
        <SettingsSwitchRow
          label={_('Color E-Ink Mode')}
          checked={isColorEink}
          disabled={!isEink}
          onChange={() => setIsColorEink(!isColorEink)}
          data-setting-id='settings.control.colorEinkMode'
        />
        <SettingsSwitchRow
          label={_('Hide Bookshelf Buttons')}
          description={_('Previous and Next in the library')}
          checked={hideBookshelfPageButtons}
          // The library follows the global E-Ink setting, not this book's.
          disabled={!settings.globalViewSettings?.isEink}
          onChange={() => setHideBookshelfPageButtons(!hideBookshelfPageButtons)}
          data-setting-id='settings.control.hideBookshelfPageButtons'
        />
        {appService?.isMobileApp && (
          <SettingsSwitchRow
            label={_('System Screen Brightness')}
            checked={autoScreenBrightness}
            onChange={() => setAutoScreenBrightness(!autoScreenBrightness)}
          />
        )}
        {appService?.hasScreenBrightness && (
          <SettingsSwitchRow
            label={_('Swipe for Brightness')}
            description={_('Slide along the left edge')}
            checked={swipeBrightnessGesture}
            onChange={() => setSwipeBrightnessGesture(!swipeBrightnessGesture)}
            data-setting-id='settings.control.swipeBrightnessGesture'
          />
        )}
        <SettingsSwitchRow
          label={_('Keep Screen Awake')}
          description={_('Only while reading')}
          checked={screenWakeLock}
          onChange={() => setScreenWakeLock(!screenWakeLock)}
          data-setting-id='settings.control.screenWakeLock'
        />
        {!appService?.isMobile && (
          <SettingsSwitchRow
            label={_('Auto-hide Cursor')}
            description={_('After a moment of inactivity')}
            checked={autohideCursor}
            onChange={() => setAutohideCursor(!autohideCursor)}
            data-setting-id='settings.control.autohideCursor'
          />
        )}
        <SettingsSwitchRow
          label={_('Reverse Mouse Wheel')}
          description={_('Scroll up for the next page')}
          checked={reverseWheelPaging}
          onChange={() => setReverseWheelPaging(!reverseWheelPaging)}
          data-setting-id='settings.control.reverseWheelPaging'
        />
        <SettingsSwitchRow
          label={_('Gamepad Support')}
          description={_('Navigate with a connected controller')}
          checked={gamepadEnabled}
          onChange={() => setGamepadEnabled(!gamepadEnabled)}
          data-setting-id='settings.control.gamepadEnabled'
        />
      </BoxedList>

      <BoxedList title={_('Security')} data-setting-id='settings.control.allowJavascript'>
        <SettingsSwitchRow
          label={_('Allow JavaScript')}
          description={_('Enable only if you trust the file.')}
          checked={allowScript}
          disabled={bookData?.book?.format !== 'EPUB'}
          onChange={() => setAllowScript(!allowScript)}
        />
      </BoxedList>
    </div>
  );
};

export default ControlPanel;
