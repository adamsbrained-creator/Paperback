import React, { useEffect, useState } from 'react';

import clsx from 'clsx';
import { useEnv } from '@/context/EnvContext';
import { useTranslation } from '@/hooks/useTranslation';
import { useCustomDictionaryStore } from '@/store/customDictionaryStore';
import { eventDispatcher } from '@/utils/event';
import { BUILTIN_PROVIDER_IDS } from '@/services/dictionaries/types';
import {
  clearRememberedLookupApp,
  getRememberedLookupApp,
  isSystemDictionaryAvailable,
  isSystemDictionarySupported,
  type RememberedLookupApp,
} from '@/services/dictionaries/systemDictionary';
import SubPageHeader from './SubPageHeader';
import { BoxedList, SettingsRow, SettingsSelect, SettingsSwitchRow } from './primitives';

/** Dictionary popup font-size multipliers, surfaced as percentages (#4443). */
const FONT_SCALE_OPTIONS = [
  { value: '0.85', label: '85%' },
  { value: '1', label: '100%' },
  { value: '1.15', label: '115%' },
  { value: '1.3', label: '130%' },
  { value: '1.5', label: '150%' },
  { value: '1.75', label: '175%' },
];

interface CustomDictionariesProps {
  onBack: () => void;
}

/**
 * Dictionaries settings: Paperback looks words up in Wiktionary, Wikipedia or
 * the phone's own dictionary app. (Importing StarDict / MDict / Slob / ... files
 * and web-search entries were removed.)
 */
const CustomDictionaries: React.FC<CustomDictionariesProps> = ({ onBack }) => {
  const _ = useTranslation();
  const { appService, envConfig } = useEnv();
  const { settings, setEnabled, setFontScale, saveCustomDictionaries, loadCustomDictionaries } =
    useCustomDictionaryStore();

  useEffect(() => {
    void loadCustomDictionaries(envConfig).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Android only: the dictionary app remembered for the system-lookup chooser.
  const [rememberedLookupApp, setRememberedLookupApp] = useState<RememberedLookupApp | null>(null);
  useEffect(() => {
    if (!appService?.isAndroidApp) return;
    let cancelled = false;
    void getRememberedLookupApp().then((app) => {
      if (!cancelled) setRememberedLookupApp(app);
    });
    return () => {
      cancelled = true;
    };
  }, [appService]);

  const handleToggle = async (id: string, next: boolean) => {
    setEnabled(id, next);
    await saveCustomDictionaries(envConfig);
  };

  const handleFontScaleChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFontScale(Number(e.target.value));
    await saveCustomDictionaries(envConfig);
  };

  const handleResetLookupApp = async () => {
    await clearRememberedLookupApp();
    setRememberedLookupApp(null);
    eventDispatcher.dispatch('toast', {
      type: 'info',
      message: _('Lookup app reset. The next lookup will ask again.'),
      timeout: 4000,
    });
  };

  const systemSupported = isSystemDictionarySupported();
  const systemAvailable = isSystemDictionaryAvailable();
  const systemOn = settings.providerEnabled[BUILTIN_PROVIDER_IDS.systemDictionary] === true;
  const isOn = (id: string) => settings.providerEnabled[id] !== false;

  return (
    <div className='w-full'>
      <SubPageHeader
        parentLabel={_('Language')}
        currentLabel={_('Dictionaries')}
        onBack={onBack}
      />

      <BoxedList>
        {systemSupported && (
          <SettingsSwitchRow
            label={_('System Dictionary')}
            checked={systemOn}
            disabled={!systemAvailable}
            onChange={() => void handleToggle(BUILTIN_PROVIDER_IDS.systemDictionary, !systemOn)}
          />
        )}
        <SettingsSwitchRow
          label={_('Wiktionary')}
          checked={isOn(BUILTIN_PROVIDER_IDS.wiktionary)}
          disabled={systemOn}
          onChange={() =>
            void handleToggle(
              BUILTIN_PROVIDER_IDS.wiktionary,
              !isOn(BUILTIN_PROVIDER_IDS.wiktionary),
            )
          }
        />
        <SettingsSwitchRow
          label={_('Wikipedia')}
          checked={isOn(BUILTIN_PROVIDER_IDS.wikipedia)}
          disabled={systemOn}
          onChange={() =>
            void handleToggle(
              BUILTIN_PROVIDER_IDS.wikipedia,
              !isOn(BUILTIN_PROVIDER_IDS.wikipedia),
            )
          }
        />
      </BoxedList>

      <BoxedList
        className='mt-4'
        title={_('Appearance')}
        description={_(
          'Sets the text size of dictionary results, independent of the reading view.',
        )}
      >
        <SettingsRow label={_('Font Size')}>
          <SettingsSelect
            value={String(settings.fontScale ?? 1)}
            onChange={handleFontScaleChange}
            options={FONT_SCALE_OPTIONS}
            ariaLabel={_('Font Size')}
          />
        </SettingsRow>
      </BoxedList>

      {rememberedLookupApp && (
        <div
          className={clsx(
            'eink-bordered mt-4 flex items-center justify-between gap-3',
            'border-base-200 bg-base-100 rounded-lg border px-4 py-3',
          )}
        >
          <div className='min-w-0'>
            <div className='text-base-content text-sm font-medium'>{_('System Lookup App')}</div>
            <div className='text-base-content/60 line-clamp-1 text-xs'>
              {rememberedLookupApp.label}
            </div>
          </div>
          <button
            type='button'
            onClick={handleResetLookupApp}
            className='btn btn-ghost btn-sm eink-bordered shrink-0'
          >
            {_('Reset')}
          </button>
        </div>
      )}
    </div>
  );
};

export default CustomDictionaries;
