import clsx from 'clsx';
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useSearchParams } from 'next/navigation';
import {
  convertBlobUrlToDataUrl,
  BookDoc,
  getDirection,
  getPageProgressionRTL,
} from '@/libs/document';
import { BOOK_IDS_SEPARATOR } from '@/services/constants';
import { BookConfig, PageInfo, ViewSettings } from '@/types/book';
import { FoliateView, wrappedFoliateView } from '@/types/view';
import { Insets } from '@/types/misc';
import { useEnv } from '@/context/EnvContext';
import { useThemeStore } from '@/store/themeStore';
import { useReaderStore } from '@/store/readerStore';
import { useBookDataStore } from '@/store/bookDataStore';
import { useSettingsStore } from '@/store/settingsStore';
import { useCustomFontStore } from '@/store/customFontStore';
import { useParallelViewStore } from '@/store/parallelViewStore';
import { useMouseEvent, useTouchEvent, useOpenMediaEvent } from '../hooks/useIframeEvents';
import { useCapturedTurn, applyPageTurnAttributes } from '../hooks/useCapturedTurn';
import { useBrightnessGesture } from '../hooks/useBrightnessGesture';
import { registerBookmarkPullDoc } from '../utils/bookmarkPullGesture';
import BrightnessOverlay from './BrightnessOverlay';
import { usePagination, viewPagination } from '../hooks/usePagination';
import { useFoliateEvents } from '../hooks/useFoliateEvents';
import { useProgressAutoSave } from '../hooks/useProgressAutoSave';
import { useBackgroundTexture } from '@/hooks/useBackgroundTexture';
import { useAutoFocus } from '@/hooks/useAutoFocus';
import { useTranslation } from '@/hooks/useTranslation';
import { useEinkMode } from '@/hooks/useEinkMode';
import {
  applyEinkModeAttribute,
  applyFixedlayoutStyles,
  applyImageStyle,
  applyNamespacedAttributes,
  applyLinkHitArea,
  applyScrollbarStyle,
  applyScrollModeClass,
  applyThemeModeClass,
  getOverlayerBlendMode,
  getPDFPageColors,
  getStyles,
  getThemeCode,
  keepTextAlignment,
  transformStylesheet,
} from '@/utils/style';
import { applyScrollableStyle, applyTableTouchScroll } from '@/utils/scrollable';
import { mountAdditionalFonts, mountCustomFont } from '@/styles/fonts';
import { refreshSectionGlosses } from '@/app/reader/utils/wordlensSection';
import { getBookDirFromLanguage, getBookDirFromWritingMode } from '@/utils/book';
import { getIndexFromCfi } from '@/utils/cfi';
import { useUICSS } from '@/hooks/useUICSS';
import {
  handleKeydown,
  handleKeyup,
  handleMousedown,
  handleMouseup,
  handleMousemove,
  handleAuxclick,
  handleClick,
  handleClickCapture,
  handleWheel,
  handleTouchStart,
  handleTouchMove,
  handleTouchEnd,
  handleTouchCancel,
} from '../utils/iframeEventHandlers';
import { getMaxInlineSize } from '@/utils/config';
import { getLockedPanX } from '../utils/lockedPan';
import { getDirFromUILanguage } from '@/utils/rtl';
import { isTauriAppPlatform } from '@/services/environment';
import { TransformContext } from '@/services/transformers/types';
import { transformContent } from '@/services/transformService';
import { sanitizeSvg } from '@/services/transformers/sanitizer';
import { lockScreenOrientation, setSelectionSuppressed } from '@/utils/bridge';
import { useBookCoverAutoSave } from '../hooks/useAutoSaveBookCover';
import { manageSyntaxHighlighting } from '@/utils/highlightjs';
import { isDialogueHighlightActive, manageDialogueHighlight } from '@/utils/dialogueHighlight';
import { getViewInsets } from '@/utils/insets';
import { collectDocumentImages, DocumentImage } from '../utils/documentImages';
import { footerReservesBand } from '../utils/footerBand';
import { showTransientHighlight } from '../utils/transientHighlight';
import { handleA11yNavigation } from '@/utils/a11y';
import { isCJKLang } from '@/utils/lang';
import { getLocale } from '@/utils/misc';
import { isMetered } from '@/utils/network';
import { eventDispatcher } from '@/utils/event';
import { isFontType } from '@/utils/font';
import { getScrollGapAttr } from '@/utils/webtoon';
import { observeDynamicResources } from '@/utils/dynamicResources';
import { setCoverSpread } from '@/utils/spread';
import { useMiddleClickAutoscroll } from '../hooks/useMiddleClickAutoscroll';
import { useAutoScroll } from '../hooks/useAutoScroll';
import { useAutoScrollSpeedGesture } from '../hooks/useAutoScrollSpeedGesture';
import { ParagraphControl } from './paragraph';
import AutoscrollIndicator from './AutoscrollIndicator';
import AutoScrollControl from './AutoScrollControl';
import AutoScrollSpeedOverlay from './AutoScrollSpeedOverlay';
import Spinner from '@/components/Spinner';
import ImageViewer from './ImageViewer';
import ImageContextMenu from './ImageContextMenu';
import TableViewer from './TableViewer';
import ExternalLinkConfirm from './ExternalLinkConfirm';
import { getTTSMiniPlayerClearance } from '../utils/ttsMiniPlayerPosition';

declare global {
  interface Window {
    eval(script: string): void;
  }
}

const FoliateViewer: React.FC<{
  bookKey: string;
  bookDoc: BookDoc;
  config: BookConfig;
  gridInsets: Insets;
  contentInsets: Insets;
}> = ({ bookKey, bookDoc, config, gridInsets, contentInsets: insets }) => {
  const _ = useTranslation();
  const searchParams = useSearchParams();
  const { appService, envConfig } = useEnv();
  const { themeCode, isDarkMode, isIPhoneDuo } = useThemeStore();
  const { settings } = useSettingsStore();
  const { loadFont, loadCustomFonts, getLoadedFonts, getAvailableFonts } = useCustomFontStore();
  // Per-field selectors — see store/readerProgressStore.ts header for the
  // "destructure-subscribes-the-whole-store" rationale.
  const getView = useReaderStore((s) => s.getView);
  const setFoliateView = useReaderStore((s) => s.setView);
  const setViewInited = useReaderStore((s) => s.setViewInited);
  const setProgress = useReaderStore((s) => s.setProgress);
  const setPreviewMode = useReaderStore((s) => s.setPreviewMode);
  const getViewState = useReaderStore((s) => s.getViewState);
  const getProgress = useReaderStore((s) => s.getProgress);
  const getViewSettings = useReaderStore((s) => s.getViewSettings);
  const setViewSettings = useReaderStore((s) => s.setViewSettings);
  const getParallels = useParallelViewStore((s) => s.getParallels);
  const getBookData = useBookDataStore((s) => s.getBookData);
  const getConfig = useBookDataStore((s) => s.getConfig);
  const setConfig = useBookDataStore((s) => s.setConfig);
  const { applyBackgroundTexture } = useBackgroundTexture();
  const { applyEinkMode } = useEinkMode();
  const { registerBrightnessListeners, overlayVisible, overlayLevel } =
    useBrightnessGesture(bookKey);
  const bookData = getBookData(bookKey);
  const viewState = getViewState(bookKey);
  const viewSettings = getViewSettings(bookKey);
  // PDF theme colors reach the canvas through CanvasRenderingContext2D.filter,
  // which WebKit lacks, so a setting synced from another device can't apply here.
  const getPageViewSettings = (vs: ViewSettings): ViewSettings =>
    appService?.supportsCanvasContext2DFilter ? vs : { ...vs, applyThemeToPDF: false };

  const viewRef = useRef<FoliateView | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const isViewCreated = useRef(false);
  const doubleClickDisabled = useRef(!!viewSettings?.disableDoubleClick);
  const [toastMessage, setToastMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [navigating, setNavigating] = useState(false);
  const navSpinnerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const librarySearchHighlightTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [scrollMargins, setScrollMargins] = useState({ top: 0, bottom: 0 });
  const docLoaded = useRef(false);

  const autoScroll = useAutoScroll(bookKey, viewRef);
  const { registerSpeedListeners, overlayVisible: speedOverlayVisible } =
    useAutoScrollSpeedGesture(autoScroll);

  // The book document outlives this view: bookDataStore keeps it for the next
  // open, so listeners left on its transformTarget would keep the closed view,
  // its iframes and their listeners alive, one more set per open (#6710).
  const removeTransformListenersRef = useRef<(() => void) | null>(null);
  const unmountedRef = useRef(false);

  // A pending anti-flash timer must not fire setNavigating on an unmounted component.
  useEffect(() => {
    unmountedRef.current = false;
    return () => {
      unmountedRef.current = true;
      removeTransformListenersRef.current?.();
      if (navSpinnerTimerRef.current) clearTimeout(navSpinnerTimerRef.current);
      if (librarySearchHighlightTimerRef.current) {
        clearTimeout(librarySearchHighlightTimerRef.current);
      }
    };
  }, []);

  useAutoFocus<HTMLDivElement>({ ref: containerRef });

  useEffect(() => {
    const timer = setTimeout(() => setToastMessage(''), 2000);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  useUICSS(bookKey);
  useProgressAutoSave(bookKey);
  useBookCoverAutoSave(bookKey);

  // Coalesce setProgress writes within a single animation frame.
  //
  // Why: foliate fires `relocate` multiple times during a swipe burst
  // (one per snap step / intermediate stabilize). Each call ends up in
  // `setProgress`, which writes to readerProgressStore + bookDataStore.
  // Even after we split progress into its own store, running the writes
  // back-to-back on the same frame is still wasted work — only the
  // last detail in the burst is what the user sees on screen.
  //
  // Earlier this used requestIdleCallback to defer the commit further,
  // but profiling on Android showed Fire Idle Callback ballooning to
  // 2.0+ seconds of total time per ~28 s session: rIC backed up under
  // sustained pressure and dumped the whole queue into the post-swipe
  // pause, producing exactly the "feels sluggish right after I let go"
  // jank we were trying to fix. rAF runs once per frame, gets scheduled
  // by the browser's normal vsync loop, and doesn't accumulate when
  // the page is busy — which is the behaviour we want here.
  const pendingRelocateRef = useRef<CustomEvent | null>(null);
  const relocateRafRef = useRef<number | null>(null);
  const relocateTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cancelRelocateScheduled = useCallback(() => {
    if (relocateTimeoutRef.current != null) {
      clearTimeout(relocateTimeoutRef.current);
      relocateTimeoutRef.current = null;
    }
    const id = relocateRafRef.current;
    if (id == null) return;
    relocateRafRef.current = null;
    cancelAnimationFrame(id);
  }, []);
  const commitRelocate = useCallback(() => {
    cancelRelocateScheduled();
    const event = pendingRelocateRef.current;
    pendingRelocateRef.current = null;
    if (!event) return;
    const detail = event.detail;
    const atEnd = viewRef.current?.renderer.atEnd || false;
    const { current, next, total } = detail.location as PageInfo;
    const currentPage = atEnd && total > 0 ? total - 1 : current;
    const pageInfo = { current: currentPage, next, total };
    setProgress(
      bookKey,
      detail.cfi,
      detail.tocItem,
      detail.pageItem,
      detail.section,
      pageInfo,
      detail.time,
      detail.range,
      detail.fraction,
    );
    // Only the primary view keeps its pan, as only it keeps its location.
    const panX = getViewState(bookKey)?.isPrimary
      ? getLockedPanX(viewRef.current, getViewSettings(bookKey))
      : undefined;
    if (panX !== undefined && panX !== getConfig(bookKey)?.panX) setConfig(bookKey, { panX });
  }, [bookKey, setProgress, cancelRelocateScheduled]);

  const progressRelocateHandler = (event: Event) => {
    // Foliate can emit a late relocation after close() clears its progress
    // resolver. Keep any valid pending position instead of replacing it.
    if (!(event as CustomEvent).detail.location) return;

    // Always stash the latest detail; if another rAF is already pending
    // it'll pick this up and the intermediate states are skipped.
    pendingRelocateRef.current = event as CustomEvent;
    // requestAnimationFrame is paused while the WebView is backgrounded, so the
    // rAF-coalesced commit below would never run during background TTS - which
    // freezes book.progress (and readerProgressStore, and the home-screen
    // widget that reads them). Commit synchronously when hidden so progress
    // stays current. The page-follow relocate still fires; only the commit was
    // being deferred.
    if (typeof document !== 'undefined' && document.visibilityState === 'hidden') {
      commitRelocate();
      return;
    }
    if (relocateRafRef.current != null) return;
    relocateRafRef.current = requestAnimationFrame(commitRelocate);
    // A CarPlay-only WebView can report "visible" without a phone scene
    // driving animation frames. TTS still needs its reading position.
    relocateTimeoutRef.current = setTimeout(commitRelocate, 100);
  };

  useEffect(() => {
    // On unmount: flush any pending commit synchronously before tearing
    // down — otherwise the last page-turn before the user closes the
    // book could be lost. Then cancel the scheduled handle to be safe
    // against double-fire.
    return () => {
      if (pendingRelocateRef.current) {
        try {
          commitRelocate();
        } catch {
          // Tearing down — last-effort save shouldn't crash the unmount
        }
      }
      cancelRelocateScheduled();
      pendingRelocateRef.current = null;
    };
  }, [cancelRelocateScheduled, commitRelocate]);

  const getDocTransformHandler = ({ width, height }: { width: number; height: number }) => {
    return (event: Event) => {
      const { detail } = event as CustomEvent;
      detail.data = Promise.resolve(detail.data)
        .then((data) => {
          const viewSettings = getViewSettings(bookKey);
          const bookData = getBookData(bookKey);
          if (viewSettings && detail.type === 'text/css')
            return transformStylesheet(
              data,
              width,
              height,
              viewSettings.vertical,
              bookData?.isFixedLayout,
            );
          if (detail.type === 'image/svg+xml' && !viewSettings?.allowScript) {
            return sanitizeSvg(data);
          }
          const isHtml = detail.type === 'application/xhtml+xml' || detail.type === 'text/html';
          if (viewSettings && bookData && isHtml) {
            const ctx: TransformContext = {
              bookKey,
              viewSettings,
              width,
              height,
              isFixedLayout: bookData.isFixedLayout,
              primaryLanguage: bookData.book?.primaryLanguage,
              userLocale: getLocale(),
              content: data,
              sectionHref: detail.name,
              sectionCfi: bookData.bookDoc?.sections?.find((s) => s.id === detail.name)?.cfi,
              transformers: [
                'epubSwitch',
                'style',
                'footnote',
                'whitespace',
                'language',
                'sanitizer',
                'nbsp',
                'proofread',
              ],
            };
            return Promise.resolve(transformContent(ctx));
          }
          return data;
        })
        .catch((e) => {
          console.error(new Error(`Failed to load ${detail.name}`, { cause: e }));
          return '';
        });
    };
  };

  const skipToReadingPosition = useCallback(() => {
    const view = getView(bookKey);
    const progress = getProgress(bookKey);
    if (view && progress) {
      view.renderer.scrollToAnchor?.(progress.range);
    }
  }, [getView, getProgress, bookKey]);

  const skipToNextSection = useCallback(() => {
    const view = getView(bookKey);
    const viewSettings = getViewSettings(bookKey);
    viewPagination(view, viewSettings, 'down', 'section');
  }, [bookKey]);

  const docLoadHandler = (event: Event) => {
    docLoaded.current = true;
    if (bookDoc.rendition?.layout === 'pre-paginated') {
      setLoading(false); // Fixed layout doesn't emit 'stabilized' event
    }
    const detail = (event as CustomEvent).detail;
    console.log('doc index loaded:', detail.index);
    if (detail.doc) {
      // Repair the parsed DOM before anything reads it: the renderer and the
      // fix-ups below both resolve styles off this document.
      applyNamespacedAttributes(detail.doc);
      applyLinkHitArea(detail.doc);
      const renderer = viewRef.current?.renderer;
      const writingDir = renderer?.setStyles && getDirection(detail.doc);
      const viewSettings = getViewSettings(bookKey)!;
      const bookData = getBookData(bookKey)!;

      const newVertical =
        writingDir?.vertical || viewSettings.writingMode.includes('vertical') || false;
      // Fixed-layout books carry no writing mode; their direction may come
      // from the document itself (PDF ViewerPreferences /Direction /R2L). The
      // UI language is the last resort, for a book that says nothing at all.
      const documentRtl = writingDir?.rtl || getDirFromUILanguage() === 'rtl' || false;
      const newRtl = getPageProgressionRTL(viewSettings.writingMode, bookDoc.dir, documentRtl);
      if (viewSettings.vertical !== newVertical || viewSettings.rtl !== newRtl) {
        viewSettings.vertical = newVertical;
        viewSettings.rtl = newRtl;
        setViewSettings(bookKey, { ...viewSettings });
      }

      if (!bookData?.isFixedLayout) {
        mountAdditionalFonts(detail.doc, isCJKLang(bookData.book?.primaryLanguage));
      }

      getLoadedFonts().forEach((font) => {
        mountCustomFont(detail.doc, font);
      });

      if (bookDoc.rendition?.layout === 'pre-paginated') {
        const pageSettings = getPageViewSettings(viewSettings);
        applyFixedlayoutStyles(detail.doc, pageSettings, undefined, bookData.book?.format);
        if (bookData.book?.format === 'PDF' && renderer) {
          renderer.pageColors = getPDFPageColors(pageSettings, getThemeCode());
        }
      }

      applyImageStyle(detail.doc);
      applyScrollableStyle(detail.doc);
      applyTableTouchScroll(detail.doc);
      applyThemeModeClass(detail.doc, isDarkMode);
      applyScrollModeClass(detail.doc, viewSettings.scrolled || false);
      applyEinkModeAttribute(detail.doc, viewSettings.isEink || false);
      applyScrollbarStyle(document, viewSettings.hideScrollbar || false);
      keepTextAlignment(detail.doc);
      handleA11yNavigation(viewRef.current, detail.doc, {
        skipToLastPosCallback: skipToReadingPosition,
        skipToLastPosLabel: _('Skip to last reading position'),
        skipToNextSectionCallback: skipToNextSection,
        skipToNextSectionLabel: _('End of this section. Continue to the next.'),
      });

      if (viewSettings.allowScript) {
        // Book scripts may add media, or a background image, with a path
        // relative to the section long after foliate's load-time URL rewrite.
        const section = bookDoc.sections?.[detail.index];
        if (section?.loadHref) observeDynamicResources(detail.doc, section.loadHref);
      }

      // Inline scripts in tauri platforms are not executed by default
      if (viewSettings.allowScript && isTauriAppPlatform()) {
        evalInlineScripts(detail.doc);
      }

      // only call on load if we have highlighting turned on.
      if (viewSettings.codeHighlighting) {
        manageSyntaxHighlighting(detail.doc, viewSettings);
      }

      if (isDialogueHighlightActive(viewSettings)) {
        manageDialogueHighlight(detail.doc, viewSettings);
      }

      setTimeout(() => {
        const sectionIndex = detail.index;
        const booknotes = config.booknotes || [];
        booknotes
          .filter(
            (item) =>
              !item.deletedAt &&
              item.type === 'annotation' &&
              item.style &&
              getIndexFromCfi(item.cfi) === sectionIndex,
          )
          .map((annotation) => {
            try {
              viewRef.current?.addAnnotation(annotation);
            } catch (err) {
              console.warn('Failed to add annotation', { annotation, error: err });
            }
          });
      }, 100);

      if (!detail.doc.isEventListenersAdded) {
        // listened events in iframes are posted to the main window
        // and then used by useMouseEvent and useTouchEvent
        // and more gesture events can be detected in the iframeEventHandlers
        detail.doc.isEventListenersAdded = true;
        detail.doc.addEventListener('keydown', handleKeydown.bind(null, bookKey));
        detail.doc.addEventListener('keyup', handleKeyup.bind(null, bookKey));
        detail.doc.addEventListener('mousedown', handleMousedown.bind(null, bookKey));
        detail.doc.addEventListener('mouseup', handleMouseup.bind(null, bookKey));
        detail.doc.addEventListener('mousemove', handleMousemove.bind(null, bookKey));
        detail.doc.addEventListener('auxclick', handleAuxclick.bind(null, bookKey));
        detail.doc.addEventListener('click', handleClickCapture.bind(null, bookKey), {
          capture: true,
        });
        detail.doc.addEventListener(
          'click',
          handleClick.bind(
            null,
            bookKey,
            doubleClickDisabled,
            !!bookData?.isFixedLayout,
            bookData?.book?.format === 'CBZ',
          ),
        );
        detail.doc.addEventListener('wheel', handleWheel.bind(null, bookKey));
        detail.doc.addEventListener('touchstart', handleTouchStart.bind(null, bookKey));
        detail.doc.addEventListener('touchmove', handleTouchMove.bind(null, bookKey), {
          passive: false,
        });
        detail.doc.addEventListener('touchend', handleTouchEnd.bind(null, bookKey), {
          passive: false,
        });
        detail.doc.addEventListener('touchcancel', handleTouchCancel.bind(null, bookKey));
        registerBrightnessListeners(detail.doc);
        registerSpeedListeners(detail.doc);
        registerBookmarkPullDoc(bookKey, detail.doc);
      }
    }
  };

  const evalInlineScripts = (doc: Document) => {
    if (doc.defaultView && doc.defaultView.frameElement) {
      const iframe = doc.defaultView.frameElement as HTMLIFrameElement;
      const scripts = doc.querySelectorAll('script:not([src])');
      scripts.forEach((script, index) => {
        const scriptContent = script.textContent || script.innerHTML;
        try {
          console.warn('Evaluating inline scripts in iframe');
          iframe.contentWindow?.eval(scriptContent);
        } catch (error) {
          console.error(`Error executing iframe script ${index + 1}:`, error);
        }
      });
    }
  };

  // Build the Word Lens refresh context: gate silent auto-download on the global
  // toggle AND a best-effort metered-connection check, and show a single
  // "Downloading…" toast on the first progress tick (the per-percent progress
  // lives in the Word Lens settings panel). `wordLensToastShownRef` de-dupes the
  // toast across the multiple section docs a refresh pass touches.
  const wordLensToastShownRef = useRef(false);
  const buildWordLensCtx = (bookLang?: string | null) => {
    // Read the live setting (not the first-render `settings` snapshot closed over
    // by the empty-deps `stabilizedHandler`) so toggling Auto-download mid-session
    // takes effect on the next section refresh.
    const liveSettings = useSettingsStore.getState().settings;
    const allowDownload =
      (liveSettings.globalReadSettings.wordLensAutoDownload ?? true) && !isMetered();
    return {
      appService: appService!,
      bookLang,
      appLang: getLocale(),
      allowDownload,
      onProgress: () => {
        if (wordLensToastShownRef.current) return;
        wordLensToastShownRef.current = true;
        eventDispatcher.dispatch('toast', {
          type: 'info',
          message: _('Downloading Word Lens data…'),
        });
      },
    };
  };

  const navigateStartHandler = useCallback(() => {
    if (navSpinnerTimerRef.current) clearTimeout(navSpinnerTimerRef.current);
    // Delay so instant same-section jumps don't flash the spinner.
    navSpinnerTimerRef.current = setTimeout(() => setNavigating(true), 200);
  }, []);

  const navigateEndHandler = useCallback(() => {
    if (navSpinnerTimerRef.current) {
      clearTimeout(navSpinnerTimerRef.current);
      navSpinnerTimerRef.current = null;
    }
    setNavigating(false);
  }, []);

  const stabilizedHandler = useCallback(() => {
    setLoading(false);
    const contents = viewRef.current?.renderer?.getContents?.() || [];
    const vs = getViewSettings(bookKey);
    const bookLang = getBookData(bookKey)?.book?.primaryLanguage;
    // Fixed-layout (pre-paginated) books have no reflow room; injecting ruby
    // would overflow their fixed boxes, so skip Word Lens glosses there.
    const isFixedLayout = bookDoc.rendition?.layout === 'pre-paginated';
    for (const { doc } of contents) {
      if (doc) {
        if (vs && appService && !isFixedLayout) {
          void refreshSectionGlosses(doc, vs, buildWordLensCtx(bookLang));
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const docRelocateHandler = (event: Event) => {
    const detail = (event as CustomEvent).detail;
    if (detail.reason !== 'scroll' && detail.reason !== 'page') return;

    // First user-initiated navigation after a deep-link landing — promote
    // the preview into the real reading position. Subsequent progress writes
    // can flow normally.
    setPreviewMode(bookKey, false);

    const parallelViews = getParallels(bookKey);
    if (parallelViews && parallelViews.size > 0) {
      parallelViews.forEach((key) => {
        if (key !== bookKey) {
          const target = getView(key)?.renderer;
          if (target) {
            target.goTo?.({ index: detail.index, anchor: detail.fraction });
          }
        }
      });
    }
  };

  const { handlePageFlip } = usePagination(bookKey, viewRef, containerRef);
  const mouseHandlers = useMouseEvent(bookKey, handlePageFlip);
  const touchHandlers = useTouchEvent(bookKey);
  const autoscrollAnchor = useMiddleClickAutoscroll(bookKey, viewRef, containerRef);

  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  // The description of the image on screen, kept next to `selectedImage` so the
  // two can never drift apart (the pressed image may be missing from the list).
  const [selectedImageAlt, setSelectedImageAlt] = useState<string>('');
  const [selectedTableHtml, setSelectedTableHtml] = useState<string | null>(null);
  const [imageList, setImageList] = useState<DocumentImage[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState<number>(0);

  const handleImagePress = useCallback(async (src: string) => {
    try {
      // Get all images from the current document
      const allImages = collectDocumentImages(
        viewRef.current?.renderer.getContents() ?? [],
        (index, range) => viewRef.current?.getCFI(index, range) || null,
      );

      // Find the index of the pressed image
      const index = allImages.findIndex((img) => img.src === src);

      setImageList(allImages);
      setCurrentImageIndex(index >= 0 ? index : 0);
      setSelectedImageAlt(index >= 0 ? allImages[index]!.alt : '');

      const dataUrl = await convertBlobUrlToDataUrl(src);
      setSelectedImage(dataUrl);
    } catch (error) {
      console.error('Failed to load image:', error);
    }
  }, []);

  const handleTablePress = useCallback((html: string) => {
    setSelectedTableHtml(html);
  }, []);

  const handlePreviousImage = useCallback(async () => {
    if (currentImageIndex > 0 && imageList.length > 0) {
      const newIndex = currentImageIndex - 1;
      setCurrentImageIndex(newIndex);
      try {
        const { src, cfi, alt } = imageList[newIndex]!;
        const dataUrl = await convertBlobUrlToDataUrl(src);
        setSelectedImage(dataUrl);
        setSelectedImageAlt(alt);
        if (cfi && viewRef.current) {
          viewRef.current?.goTo(cfi);
        }
      } catch (error) {
        console.error('Failed to load previous image:', error);
      }
    }
  }, [currentImageIndex, imageList]);

  const handleNextImage = useCallback(async () => {
    if (currentImageIndex < imageList.length - 1 && imageList.length > 0) {
      const newIndex = currentImageIndex + 1;
      setCurrentImageIndex(newIndex);
      try {
        const { src, cfi, alt } = imageList[newIndex]!;
        const dataUrl = await convertBlobUrlToDataUrl(src);
        setSelectedImage(dataUrl);
        setSelectedImageAlt(alt);
        if (cfi && viewRef.current) {
          viewRef.current?.goTo(cfi);
        }
      } catch (error) {
        console.error('Failed to load next image:', error);
      }
    }
  }, [currentImageIndex, imageList]);

  const handleCloseImage = useCallback(() => {
    setSelectedImage(null);
    setSelectedImageAlt('');
    setImageList([]);
    setCurrentImageIndex(0);
  }, []);

  useOpenMediaEvent(bookKey, handleImagePress, handleTablePress);

  useCapturedTurn(bookKey, viewRef);

  useFoliateEvents(viewRef.current, {
    onLoad: docLoadHandler,
    onStabilized: stabilizedHandler,
    onRelocate: progressRelocateHandler,
    onRendererRelocate: docRelocateHandler,
    onNavigateStart: navigateStartHandler,
    onNavigateEnd: navigateEndHandler,
  });

  useEffect(() => {
    if (isViewCreated.current) return;
    isViewCreated.current = true;

    setTimeout(() => setLoading(true), 200);

    const openBook = async () => {
      console.log('Opening book', bookKey);
      await import('foliate-js/view.js');
      const view = wrappedFoliateView(document.createElement('foliate-view') as FoliateView);
      view.id = `foliate-view-${bookKey}`;
      containerRef.current?.appendChild(view);

      const viewSettings = getViewSettings(bookKey)!;
      const writingMode = viewSettings.writingMode;
      if (writingMode) {
        const settingsDir = getBookDirFromWritingMode(writingMode);
        const languageDir = getBookDirFromLanguage(bookDoc.metadata.language);
        if (settingsDir !== 'auto') {
          bookDoc.dir = settingsDir;
        } else if (languageDir !== 'auto') {
          bookDoc.dir = languageDir;
        }
      }

      if (bookDoc.rendition?.layout === 'pre-paginated' && bookDoc.sections) {
        bookDoc.rendition.spread = viewSettings.spreadMode;
        setCoverSpread(bookDoc, viewSettings.keepCoverSpread);
      }

      await view.open(bookDoc);
      // make sure we can listen renderer events after opening book
      viewRef.current = view;
      setFoliateView(bookKey, view);

      const { book } = view;

      const handleTransformLoad = async (event: Event) => {
        const { detail } = event as CustomEvent<{
          isScript: boolean;
          type: string;
          href: string;
          url?: string;
          allow?: boolean;
        }>;
        if (detail.isScript) {
          detail.allow = viewSettings.allowScript ?? false;
        }
        if (isFontType(detail.type) && detail.href?.startsWith('fonts/')) {
          const fontFileName = detail.href.split('/').pop()?.toLowerCase();
          getAvailableFonts().forEach(async (font) => {
            const customFontFileName = font.path.split('/').pop()?.toLowerCase();
            if (fontFileName && fontFileName === customFontFileName) {
              if (!font.loaded) {
                const loadedFont = await loadFont(envConfig, font.id);
                font.blobUrl = loadedFont?.blobUrl;
              }
              if (font.blobUrl) {
                detail.url = font.blobUrl;
              }
            }
          });
        }
      };
      const viewWidth = appService?.isMobile ? screen.width : window.innerWidth;
      const viewHeight = appService?.isMobile ? screen.height : window.innerHeight;
      const width = viewWidth - insets.left - insets.right;
      const height = viewHeight - insets.top - insets.bottom;
      const handleTransformData = getDocTransformHandler({ width, height });
      book.transformTarget?.addEventListener('load', handleTransformLoad);
      book.transformTarget?.addEventListener('data', handleTransformData);
      removeTransformListenersRef.current = () => {
        book.transformTarget?.removeEventListener('load', handleTransformLoad);
        book.transformTarget?.removeEventListener('data', handleTransformData);
      };
      // The reader can close while view.open() is pending; its cleanup has run.
      if (unmountedRef.current) removeTransformListenersRef.current();
      view.renderer.setStyles?.(getStyles(viewSettings, undefined, getLoadedFonts()));

      doubleClickDisabled.current = viewSettings.disableDoubleClick!;
      const animated = viewSettings.animated!;
      const eink = viewSettings.isEink!;
      const maxColumnCount = viewSettings.maxColumnCount!;
      const maxInlineSize = getMaxInlineSize(viewSettings);
      const maxBlockSize = viewSettings.maxBlockSize!;
      const screenOrientation = viewSettings.screenOrientation!;
      if (appService?.isMobileApp) {
        await lockScreenOrientation({ orientation: screenOrientation });
      }
      if (animated) {
        view.renderer.setAttribute('animated', '');
      } else {
        view.renderer.removeAttribute('animated');
      }
      // Arms the foliate CursorAutohider — goes on the view element itself,
      // not the renderer, and is re-checked on every mousemove so the
      // ControlPanel toggle takes effect without recreating the view.
      view.toggleAttribute(
        'autohide-cursor',
        !appService?.isMobile && !!useSettingsStore.getState().settings.autohideCursor,
      );
      applyPageTurnAttributes(view, viewSettings, bookDoc.rendition?.layout === 'pre-paginated');
      // iOS WebKit composites large/persistent page layers without the Android
      // high-DPR Blink freeze, so opt this renderer into the GPU-accelerated
      // page-turn path (persistent compositor layers + no main-thread
      // rafAnimateScroll fallback) to keep 120Hz ProMotion turns smooth
      // (readest#4768).
      if (appService?.isIOSApp) {
        view.renderer.setAttribute('gpu-composite', '');
      }
      if (eink) {
        view.renderer.setAttribute('eink', '');
      } else {
        view.renderer.removeAttribute('eink');
      }
      applyEinkMode(eink);
      if (bookDoc?.rendition?.layout === 'pre-paginated') {
        view.renderer.setAttribute('zoom', viewSettings.zoomMode);
        view.renderer.setAttribute('spread', viewSettings.spreadMode);
        view.renderer.setAttribute('scale-factor', viewSettings.zoomLevel);
        view.renderer.setAttribute('scroll-gap', getScrollGapAttr(viewSettings.webtoonMode));
        view.renderer.toggleAttribute('lock-pan-x', !!viewSettings.lockHorizontalPan);
        if (viewSettings.lockHorizontalPan && config.panX !== undefined) {
          view.renderer.panX = config.panX;
        }
      } else {
        view.renderer.setAttribute('max-column-count', maxColumnCount);
        view.renderer.setAttribute('max-inline-size', `${maxInlineSize}px`);
        view.renderer.setAttribute('max-block-size', `${maxBlockSize}px`);
      }
      applyMarginAndGap();

      // If the URL carries ?cfi=... (e.g. opened from a deep link / annotation
      // export link), use it as the initial location instead of the saved one.
      // Only applies to the primary book — first id in the route's `ids` —
      // so parallel views don't all jump to the same CFI.
      const cfiParam = searchParams?.get('cfi');
      const idsParam =
        searchParams?.get('ids') ?? window.location.pathname.split('/reader/')[1] ?? '';
      const primaryId = idsParam.split(BOOK_IDS_SEPARATOR).filter(Boolean)[0];
      const thisId = bookKey.split('-')[0];
      const overrideLocation = cfiParam && primaryId === thisId ? cfiParam : null;

      const lastLocation = overrideLocation ?? config.location;
      if (lastLocation) {
        await view.init({ lastLocation });
      } else {
        await view.goToFraction(0);
      }
      // The reader is showing a deep-link target, not the user's actual reading
      // position. Mark the view as a preview so progress writers (auto-save,
      // cloud sync, kosync) skip until the user takes a reading action. The
      // flag clears on the first user-initiated relocate (page / scroll) in
      // docRelocateHandler below. Set before `inited` so everything that starts
      // reading on init (e.g. Auto Scroll resume) already sees the preview.
      if (overrideLocation) {
        setPreviewMode(bookKey, true);
      }
      setViewInited(bookKey, true);
      if (overrideLocation && searchParams?.get('highlight') === 'search') {
        librarySearchHighlightTimerRef.current = await showTransientHighlight(
          view,
          overrideLocation,
        );
      }
    };

    openBook();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const applyMarginAndGap = () => {
    // Invoked from effects/observers that can fire after the book is torn down,
    // when getViewSettings(bookKey) returns null. The `!` assertion hid that, so
    // the reads below (getViewInsets, viewSettings.showHeader) crashed on null
    // (READEST-2V). Bail: there is no view left to lay out.
    const viewSettings = getViewSettings(bookKey);
    if (!viewSettings) return;
    const viewState = getViewState(bookKey);
    const bookData = getBookData(bookKey);
    const viewInsets = getViewInsets(viewSettings);
    const showDoubleBorder = viewSettings.vertical && viewSettings.doubleBorder;
    const showDoubleBorderHeader = showDoubleBorder && viewSettings.showHeader;
    const showDoubleBorderFooter = showDoubleBorder && viewSettings.showFooter;
    const showTopHeader = viewSettings.showHeader && !viewSettings.vertical;
    // The bottom band is reserved only while the footer displays something
    // there (and never in scrolled mode, where the info floats in pills) —
    // see footerReservesBand. Otherwise the empty reservation shows as a
    // full-width blank bar that steals space from the book text.
    const showBottomFooter = footerReservesBand(viewSettings) && !viewSettings.vertical;
    const moreTopInset = showTopHeader ? Math.max(0, 16 - insets.top) : 0;
    // Only the persistent 'minimal' card reserves a band; the 'full' one
    // auto-hides with the toolbar and overlaps instead (#5310).
    const miniPlayerClearance = viewState?.ttsEnabled
      ? getTTSMiniPlayerClearance(viewSettings, gridInsets.bottom * 0.33)
      : 0;
    const moreBottomInset = showBottomFooter
      ? Math.max(0, Math.max(miniPlayerClearance, 16) - insets.bottom)
      : Math.max(0, miniPlayerClearance);
    const moreRightInset = showDoubleBorderHeader ? 32 : 0;
    const moreLeftInset = showDoubleBorderFooter ? 32 : 0;
    const topMargin = (showTopHeader ? insets.top : viewInsets.top) + moreTopInset;
    // On iPhone Duo the horizontal safe-area insets are applied to the viewer
    // container itself (see the render below), not folded into these margins:
    // the paginator treats a horizontal margin as a gutter and puts only half
    // of it (a quarter in two-column mode) on the outer edge, which left text
    // under the side status strip (#6307). Elsewhere they stay in the margins.
    const rightMargin = (isIPhoneDuo ? viewInsets.right : insets.right) + moreRightInset;
    const bottomMargin = (showBottomFooter ? insets.bottom : viewInsets.bottom) + moreBottomInset;
    const leftMargin = (isIPhoneDuo ? viewInsets.left : insets.left) + moreLeftInset;
    viewRef.current?.renderer.setAttribute('margin-top', `${topMargin}px`);
    viewRef.current?.renderer.setAttribute('margin-right', `${rightMargin}px`);
    viewRef.current?.renderer.setAttribute('margin-bottom', `${bottomMargin}px`);
    viewRef.current?.renderer.setAttribute('margin-left', `${leftMargin}px`);

    if (viewSettings.scrolled) {
      const headerVisible = showTopHeader;
      const footerVisible = showBottomFooter;
      const safeBottomPadding = appService?.hasSafeAreaInset ? gridInsets.bottom * 0.33 : 0;
      const footerBarHeight = safeBottomPadding + viewSettings.marginBottomPx;
      // topMargin, not the raw margin sum: it carries the 16px moreTopInset
      // floor, so a negative top margin keeps the scroll viewport glued to the
      // lifted header band instead of running under it (#5303).
      const scrollTop = headerVisible ? topMargin : 0;
      const scrollBottom = footerVisible
        ? Math.max(footerBarHeight, miniPlayerClearance)
        : miniPlayerClearance;
      setScrollMargins({ top: bookData?.isFixedLayout ? 0 : scrollTop, bottom: scrollBottom });
    } else {
      setScrollMargins({ top: 0, bottom: 0 });
    }
    viewRef.current?.renderer.setAttribute('gap', `${viewSettings.gapPercent}%`);
    if (viewSettings.columnGapPx > 0) {
      viewRef.current?.renderer.setAttribute('column-gap', `${viewSettings.columnGapPx}px`);
    } else {
      viewRef.current?.renderer.removeAttribute('column-gap');
    }
    viewRef.current?.renderer.setAttribute(
      'scroll-direction',
      viewSettings.scrolledDirection === 'horizontal' ? 'horizontal' : 'vertical',
    );
    if (viewSettings.scrolled) {
      viewRef.current?.renderer.setAttribute('flow', 'scrolled');
      if (viewSettings.noContinuousScroll) {
        viewRef.current?.renderer.setAttribute('no-continuous-scroll', '');
      } else {
        viewRef.current?.renderer.removeAttribute('no-continuous-scroll');
      }
    }
  };

  // iOS: the system long-press selection would race the instant-highlight
  // hold — WebKit consults selectability before any touch handler runs, so
  // JS-level suppression cannot win. Suppress it natively while the highlight
  // quick action owns the gesture; restore when the mode turns off or the
  // reader closes.
  useEffect(() => {
    if (!appService?.isIOSApp) return;
    const suppressed =
      !!viewSettings?.enableAnnotationQuickActions &&
      viewSettings?.annotationQuickAction === 'highlight';
    setSelectionSuppressed({ target: 'gesture', suppressed }).catch(() => {});
    return () => {
      if (suppressed) {
        setSelectionSuppressed({ target: 'gesture', suppressed: false }).catch(() => {});
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    appService?.isIOSApp,
    viewSettings?.enableAnnotationQuickActions,
    viewSettings?.annotationQuickAction,
  ]);

  // Android (#5427): useTextSelector keeps the system selection toolbar
  // natively suppressed while reader text is selected. If the reader closes
  // with a live selection, no selectionchange fires to lift the flag — reset
  // it here so selection menus elsewhere in the app are not muted.
  useEffect(() => {
    if (!appService?.isAndroidApp) return;
    return () => {
      setSelectionSuppressed({ target: 'menu', suppressed: false }).catch(() => {});
    };
  }, [appService?.isAndroidApp]);

  useEffect(() => {
    if (viewRef.current && viewRef.current.renderer) {
      const renderer = viewRef.current.renderer;
      const viewSettings = getViewSettings(bookKey)!;
      const pageSettings = getPageViewSettings(viewSettings);
      viewRef.current.renderer.setStyles?.(getStyles(viewSettings, undefined, getLoadedFonts()));
      const docs = viewRef.current.renderer.getContents();
      docs.forEach(({ doc }) => {
        if (bookDoc.rendition?.layout === 'pre-paginated') {
          applyFixedlayoutStyles(doc, pageSettings, undefined, bookData?.book?.format);
        }
        applyThemeModeClass(doc, isDarkMode);
        applyScrollModeClass(doc, viewSettings.scrolled || false);
        applyEinkModeAttribute(doc, viewSettings.isEink || false);
        applyScrollbarStyle(document, viewSettings.hideScrollbar || false);
      });

      if (bookData?.book?.format === 'PDF' && themeCode && renderer) {
        renderer.pageColors = getPDFPageColors(pageSettings, themeCode);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    themeCode,
    isDarkMode,
    viewSettings?.scrolled,
    viewSettings?.overrideColor,
    viewSettings?.invertImgColorInDark,
    viewSettings?.applyThemeToPDF,
    viewSettings?.contrast,
    viewSettings?.hideScrollbar,
    viewSettings?.isEink,
  ]);

  // The annotation overlay lives outside the content iframe, so its blend mode
  // has to follow the page the highlight sits on rather than the app theme: a
  // PDF keeps its own white bitmap in a dark theme unless the reader asked us
  // to darken it (#5790, #5930, #5943). Scoped to this view so the library and
  // reflowable books keep the global default from useTheme.
  useEffect(() => {
    if (!containerRef.current || !viewSettings) return;
    containerRef.current.style.setProperty(
      '--overlayer-highlight-blend-mode',
      getOverlayerBlendMode({
        isDarkMode,
        isBwEink: !!viewSettings.isEink && !viewSettings.isColorEink,
        isFixedLayout: bookDoc.rendition?.layout === 'pre-paginated',
        invertImgColorInDark: !!viewSettings.invertImgColorInDark,
        applyThemeToPDF: !!getPageViewSettings(viewSettings).applyThemeToPDF,
        format: bookData?.book?.format,
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    isDarkMode,
    viewSettings?.isEink,
    viewSettings?.isColorEink,
    viewSettings?.invertImgColorInDark,
    viewSettings?.applyThemeToPDF,
  ]);

  useEffect(() => {
    const contents = viewRef.current?.renderer?.getContents?.() || [];
    const vs = getViewSettings(bookKey);
    if (!vs || !appService) return;
    const bookLang = getBookData(bookKey)?.book?.primaryLanguage;
    const isFixedLayout = bookDoc.rendition?.layout === 'pre-paginated';
    if (isFixedLayout) return;
    // A settings change is the moment a fresh download may start; let the
    // one-time "Downloading…" toast fire again for it.
    wordLensToastShownRef.current = false;
    for (const { doc } of contents) {
      if (doc) void refreshSectionGlosses(doc, vs, buildWordLensCtx(bookLang));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewSettings?.wordLensEnabled, viewSettings?.wordLensLevel, viewSettings?.wordLensHintLang]);

  useEffect(() => {
    const mountCustomFonts = async () => {
      await loadCustomFonts(envConfig);
      getLoadedFonts().forEach((font) => {
        mountCustomFont(document, font);
        const docs = viewRef.current?.renderer.getContents();
        docs?.forEach(({ doc }) => mountCustomFont(doc, font));
      });
    };
    if (settings.customFonts) {
      mountCustomFonts();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.customFonts, envConfig]);

  useEffect(() => {
    if (!viewSettings) return;
    applyBackgroundTexture(envConfig, viewSettings);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    viewSettings?.backgroundTextureId,
    viewSettings?.backgroundOpacity,
    viewSettings?.backgroundSize,
    applyBackgroundTexture,
  ]);

  useEffect(() => {
    if (viewRef.current && viewRef.current.renderer) {
      doubleClickDisabled.current = !!viewSettings?.disableDoubleClick;
    }
  }, [viewSettings?.disableDoubleClick]);

  // A section can flip the writing axis mid-book — a vertical chapter inside an
  // otherwise horizontal one. `getMaxInlineSize` measures the other screen axis
  // for vertical writing, so the ceiling the renderer was opened with is the
  // wrong one from that section on.
  useEffect(() => {
    const renderer = viewRef.current?.renderer;
    if (!renderer || !viewSettings || bookDoc.rendition?.layout === 'pre-paginated') return;
    renderer.setAttribute('max-inline-size', `${getMaxInlineSize(viewSettings)}px`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewSettings?.vertical]);

  useEffect(() => {
    if (viewRef.current && viewRef.current.renderer && viewSettings) {
      applyMarginAndGap();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    insets.top,
    insets.right,
    insets.bottom,
    insets.left,
    isIPhoneDuo,
    // getViewInsets swaps the full top/bottom bands for the compact ones once
    // the page turns sideways, so the margins follow the axis too.
    viewSettings?.vertical,
    viewSettings?.doubleBorder,
    viewSettings?.showHeader,
    viewSettings?.showFooter,
    viewSettings?.scrolled,
    viewSettings?.noContinuousScroll,
    viewState?.ttsEnabled,
    viewState?.drawingEnabled,
    // Switching Player Style changes whether a band is reserved at all.
    viewSettings?.ttsPlayerStyle,
    // footerReservesBand inputs: the band must collapse/return live when the
    // user flips these settings.
    viewSettings?.showStickyProgressBar,
    viewSettings?.showRemainingTime,
    viewSettings?.showRemainingPages,
    viewSettings?.showProgressInfo,
    viewSettings?.showCurrentTime,
    viewSettings?.showCurrentBatteryStatus,
  ]);

  return (
    <>
      <ImageContextMenu bookKey={bookKey} />
      {selectedImage && (
        <ImageViewer
          gridInsets={gridInsets}
          src={selectedImage}
          caption={selectedImageAlt}
          onClose={handleCloseImage}
          onPrevious={currentImageIndex > 0 ? handlePreviousImage : undefined}
          onNext={currentImageIndex < imageList.length - 1 ? handleNextImage : undefined}
        />
      )}
      {selectedTableHtml && (
        <TableViewer
          gridInsets={gridInsets}
          html={selectedTableHtml}
          isDarkMode={isDarkMode}
          onClose={() => setSelectedTableHtml(null)}
        />
      )}
      <ExternalLinkConfirm view={viewRef.current} />
      <div
        ref={containerRef}
        role='main'
        aria-label={_('Book Content')}
        className={clsx(
          'foliate-viewer absolute h-[100%] w-[100%] focus:outline-hidden',
          viewState?.loading && 'bg-base-100',
        )}
        style={{
          paddingTop: scrollMargins.top,
          paddingBottom: scrollMargins.bottom,
          // Keep the whole page area inside the horizontal safe area (#6307).
          ...(isIPhoneDuo
            ? {
                left: `${gridInsets.left}px`,
                width: `calc(100% - ${gridInsets.left + gridInsets.right}px)`,
              }
            : {}),
        }}
        {...mouseHandlers}
        {...touchHandlers}
      />
      {autoscrollAnchor && <AutoscrollIndicator anchor={autoscrollAnchor} />}
      {autoScroll.active && (
        <AutoScrollControl
          bookKey={bookKey}
          paused={autoScroll.paused}
          speed={autoScroll.speed}
          onTogglePause={autoScroll.togglePause}
          onAdjustSpeed={autoScroll.adjustSpeed}
          onStop={autoScroll.stop}
          gridInsets={gridInsets}
        />
      )}
      <BrightnessOverlay visible={overlayVisible} level={overlayLevel} />
      {autoScroll.active && (
        <AutoScrollSpeedOverlay visible={speedOverlayVisible} speed={autoScroll.speed} />
      )}
      <ParagraphControl bookKey={bookKey} viewRef={viewRef} gridInsets={gridInsets} />
      {((!docLoaded.current && loading) || navigating || viewState?.loading) && (
        <div className='absolute left-0 top-0 z-10 flex h-full w-full items-center justify-center'>
          <Spinner loading={true} />
        </div>
      )}
    </>
  );
};

export default FoliateViewer;
