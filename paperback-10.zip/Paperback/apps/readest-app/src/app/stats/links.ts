import type { ShelfSpec } from '@/services/statistics/shelfStats';
import type { StatsPage } from './components/StatsNav';

/** Where a tap on a cover, card or number in Stats goes. Built once in the Stats page and handed to every view. */
export interface StatsLinks {
  /** A book's details page. */
  book: (hash: string) => void;
  /** Library → All books, with a filter chip and/or a search ("finished", "Neil Gaiman"). */
  library: (filter?: 'all' | 'reading' | 'finished', query?: string) => void;
  /** Any other Paperback page ("/notes", "/dictionary", "/authors"). */
  route: (path: string) => void;
  /** A shelf of the books behind a number (Most read · October, Languages, …). */
  shelf: (spec: ShelfSpec) => void;
  /** History, opened on the month of `day` with that day's sessions in view. */
  history: (day?: Date) => void;
  page: (p: StatsPage) => void;
  goals: () => void;
}

export function libraryHref(filter: 'all' | 'reading' | 'finished' = 'all', query = ''): string {
  const p = new URLSearchParams({ view: 'all' });
  if (filter !== 'all') p.set('filter', filter);
  if (query) p.set('q', query);
  return `/books?${p.toString()}`;
}

export const bookHref = (hash: string): string => `/book?hash=${encodeURIComponent(hash)}`;
