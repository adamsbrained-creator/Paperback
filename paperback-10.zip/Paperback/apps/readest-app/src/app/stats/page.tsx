'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useAppRouter } from '@/components/paperback/platform';
import Shell from '@/components/paperback/Shell';
import { useBooknotes } from '@/components/paperback/useBooknotes';
import { useShelves } from '@/components/paperback/useShelves';
import { buildShelf, parseShelfSpec, shelfQuery, type ShelfSpec } from '@/services/statistics/shelfStats';
import { useStatsData } from './useStatsData';
import ActivityView from './components/ActivityView';
import GoalsView from './components/GoalsView';
import MilestonesView from './components/MilestonesView';
import BooksView from './components/BooksView';
import HistoryView from './components/HistoryView';
import InsightsView from './components/InsightsView';
import ShelfScreen from './components/ShelfScreen';
import StatsNav, { STATS_PAGES, type StatsPage } from './components/StatsNav';
import { SIcon } from './components/StatsIcons';
import { bookHref, libraryHref, type StatsLinks } from './links';

// A page of Stats, or a screen opened on top of it: the reading goals, or a shelf of the books behind a number.
type Screen = 'main' | 'goals' | 'shelf';

interface UrlState {
  screen: Screen;
  page: StatsPage;
  shelf: ShelfSpec | null;
}

const pageOf = (v: string | null): StatsPage => STATS_PAGES.find((p) => p.id === v)?.id ?? 'activity';

/**
 * ?tab=goals opens the goals screen; ?tab=shelf&s=read&from=…&to=… opens a shelf (&back= names the page under it);
 * ?tab=milestones | books | history | insights opens that page. Older links use ?tab=sessions for the
 * session list, which is now the History page.
 */
function readUrl(): UrlState {
  const q = new URLSearchParams(window.location.search);
  const t = q.get('tab');
  const back = pageOf(q.get('back'));
  if (t === 'sessions') return { screen: 'main', page: 'history', shelf: null };
  if (t === 'goals') return { screen: 'goals', page: back, shelf: null };
  if (t === 'shelf') {
    const shelf = parseShelfSpec(q);
    if (shelf) return { screen: 'shelf', page: back, shelf };
  }
  return { screen: 'main', page: pageOf(t), shelf: null };
}

const pageUrl = (p: StatsPage) => (p === 'activity' ? window.location.pathname : `${window.location.pathname}?tab=${p}`);

const scroller = () => document.querySelector<HTMLElement>('.pb-root');

// Opening a book leaves Stats; where you were is kept so Back lands on the same page and spot.
const RESTORE_KEY = 'paperback.stats.restore';

export default function StatsPage() {
  const router = useAppRouter();
  const [screen, setScreen] = useState<Screen>('main');
  const [page, setPage] = useState<StatsPage>('activity');
  const [shelfSpec, setShelfSpec] = useState<ShelfSpec | null>(null);
  const [historyFocus, setHistoryFocus] = useState<Date | null>(null);
  const { events, error, now, library, booksByHash } = useStatsData();
  const scrollBefore = useRef(0);
  const pageRef = useRef<StatsPage>('activity');
  pageRef.current = page;

  // Milestones count notes, saved words and ratings. Notes are read from every book's own file, so that
  // starts the first time Milestones is opened and then stays loaded.
  const [shelves] = useShelves();
  const [wantNotes, setWantNotes] = useState(false);
  useEffect(() => {
    if (page === 'milestones') setWantNotes(true);
  }, [page]);
  const liveBooks = useMemo(() => library.filter((b) => !b.deletedAt), [library]);
  const notes = useBooknotes(liveBooks, wantNotes);

  useEffect(() => {
    const sync = () => {
      const s = readUrl();
      setScreen(s.screen);
      setPage(s.page);
      setShelfSpec(s.shelf);
      if (s.screen === 'main') {
        requestAnimationFrame(() => {
          const el = scroller();
          if (el) el.scrollTop = scrollBefore.current;
        });
      }
    };
    const first = readUrl();
    setScreen(first.screen);
    setPage(first.page);
    setShelfSpec(first.shelf);
    window.addEventListener('popstate', sync);
    return () => window.removeEventListener('popstate', sync);
  }, []);

  // Switching pages starts at the top. The page is kept in the address, so Back from a book returns to it.
  const go = useCallback((p: StatsPage) => {
    setPage(p);
    window.history.replaceState({}, '', pageUrl(p));
    const el = scroller();
    if (el) el.scrollTop = 0;
  }, []);

  const push = useCallback((next: 'goals' | 'shelf', query: string) => {
    scrollBefore.current = scroller()?.scrollTop ?? 0;
    window.history.pushState({ pbs: next }, '', `${window.location.pathname}?${query}`);
    setScreen(next);
    const el = scroller();
    if (el) el.scrollTop = 0;
  }, []);

  // Back: undo the push when this screen was opened from a page, else just show the page again.
  const close = useCallback(() => {
    if ((window.history.state as { pbs?: string } | null)?.pbs) {
      window.history.back();
    } else {
      window.history.replaceState({}, '', pageUrl(pageRef.current));
      setScreen('main');
    }
  }, []);

  const leave = useCallback(
    (href: string) => {
      try {
        sessionStorage.setItem(RESTORE_KEY, JSON.stringify({ search: window.location.search, y: scroller()?.scrollTop ?? 0 }));
      } catch {
        /* Back will start at the top */
      }
      router.push(href);
    },
    [router],
  );

  const links: StatsLinks = useMemo(
    () => ({
      book: (hash) => leave(bookHref(hash)),
      library: (filter, query) => leave(libraryHref(filter, query)),
      route: leave,
      shelf: (spec) => {
        setShelfSpec(spec);
        push('shelf', `tab=shelf&${shelfQuery(spec)}&back=${pageRef.current}`);
      },
      history: (day) => {
        setHistoryFocus(day ?? null);
        go('history');
      },
      page: go,
      goals: () => push('goals', `tab=goals&back=${pageRef.current}`),
    }),
    [leave, push, go],
  );

  const ready = events !== null;

  // Back from a book: put the page where it was.
  useEffect(() => {
    if (!ready) return;
    try {
      const raw = sessionStorage.getItem(RESTORE_KEY);
      if (!raw) return;
      sessionStorage.removeItem(RESTORE_KEY);
      const r = JSON.parse(raw) as { search?: string; y?: number };
      if (r.search !== window.location.search || !r.y) return;
      const apply = () => {
        const el = scroller();
        if (el) el.scrollTop = r.y ?? 0;
      };
      requestAnimationFrame(() => {
        apply();
        setTimeout(apply, 80);
      });
    } catch {
      /* start at the top */
    }
  }, [ready]);

  const shelfView = useMemo(
    () => (shelfSpec ? buildShelf(shelfSpec, { library, events: events ?? [], ratings: shelves.ratings, now }) : null),
    [shelfSpec, library, events, shelves.ratings, now],
  );

  const header = (
    <div className='pbs pbs-top' style={{ height: 76, paddingTop: 4 }}>
      <h1>Stats</h1>
      <span className='pbs-chip'>
        <i className='pbs-dot' /> On this device
      </span>
    </div>
  );

  const hasEvents = ready && events.length > 0;

  return (
    <Shell title='Stats' tab='stats' header={screen === 'main' ? header : <></>}>
      {error && (
        <div className='pb-card pb-pk'>
          Couldn&apos;t open the reading statistics database.
          <div className='pb-note'>{error}</div>
        </div>
      )}
      {!error && events === null && <div className='pb-empty'>Loading…</div>}

      {ready && (
        <>
          {/* Activity stays mounted while a screen is open on top of it, so its period and scroll are kept. */}
          <div className='pbs pbs-col' hidden={screen !== 'main'}>
            <StatsNav
              value={page}
              onChange={(p) => {
                setHistoryFocus(null);
                go(p);
              }}
            />
            {page === 'activity' ? (
              hasEvents ? (
                <ActivityView
                  events={events}
                  library={library}
                  booksByHash={booksByHash}
                  now={now}
                  links={links}
                />
              ) : (
                <div className='pbs-card pbs-empty'>
                  Nothing tracked yet. Read a few pages and your stats will appear here.
                </div>
              )
            ) : page === 'milestones' ? (
              <MilestonesView
                events={events}
                books={library}
                notes={notes}
                savedWords={shelves.savedWords}
                ratings={shelves.ratings}
                now={now}
                links={links}
              />
            ) : page === 'books' ? (
              <BooksView events={events} library={library} ratings={shelves.ratings} links={links} />
            ) : page === 'history' ? (
              <HistoryView events={events} booksByHash={booksByHash} now={now} focus={historyFocus} links={links} />
            ) : (
              <InsightsView events={events} library={library} booksByHash={booksByHash} now={now} links={links} />
            )}
          </div>

          {screen === 'shelf' && shelfView && (
            <ShelfScreen view={shelfView} booksByHash={booksByHash} links={links} onBack={close} />
          )}
          {screen === 'goals' && (
            <div className='pbs pbs-col'>
              <div className='pbs-stop'>
                <button type='button' className='pbs-round' aria-label='Back to Activity' onClick={close}>
                  <SIcon name='back' />
                </button>
                <h2>Goals</h2>
              </div>
              <GoalsView events={events} library={library} now={now} links={links} />
            </div>
          )}
        </>
      )}
    </Shell>
  );
}
