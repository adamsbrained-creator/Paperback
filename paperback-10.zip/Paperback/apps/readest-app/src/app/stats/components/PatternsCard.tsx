'use client';

import clsx from 'clsx';
import { useEffect, useMemo, useState } from 'react';
import {
  readingPatterns,
  timeOfDayName,
  PATTERN_DAYS,
  type PatternMetric,
} from '@/services/statistics/activityStats';
import { formatCount, type StatEventRow } from '@/services/statistics/statsAggregate';
import { SIcon } from './StatsIcons';
import { ac, type Accent } from './parts';

const R0 = 30; // inner radius of the clock
const RMAX = 66; // the longest stalk reaches this much further out

const TIME_COLOR: Record<string, Accent> = { Morning: 'blue', Afternoon: 'yellow', Evening: 'mint', Night: 'pink' };

const pol = (r: number, deg: number): [number, number] => {
  const a = (deg * Math.PI) / 180;
  return [r * Math.sin(a), -r * Math.cos(a)];
};
const f = (n: number) => n.toFixed(1);
const hh = (h: number) => String(h).padStart(2, '0');

/** "You read mostly in the morning, on weekends." with a 24-hour clock and breakdowns (last 90 days). */
export default function PatternsCard({ events, now }: { events: StatEventRow[]; now: Date }) {
  const [metric, setMetric] = useState<PatternMetric>('sessions');
  const [tip, setTip] = useState<number | null>(null);
  const [info, setInfo] = useState(false);
  const p = useMemo(() => readingPatterns(events, metric, now), [events, metric, now]);

  // A tapped hour's label goes away when tapping anywhere else.
  useEffect(() => {
    if (tip === null) return;
    const close = (e: Event) => {
      if (!(e.target as Element).closest?.('.pbs-hit')) setTip(null);
    };
    document.addEventListener('click', close);
    return () => document.removeEventListener('click', close);
  }, [tip]);

  const unit = metric === 'sessions' ? 'sessions' : 'pages';
  const unitOf = (n: number) => (n === 1 ? unit.slice(0, -1) : unit);
  const max = Math.max(1, ...p.byHour);
  const wmax = Math.max(1, ...p.byWeekday.map((d) => d.value));
  const empty = p.total === 0;
  const topColor = TIME_COLOR[p.topTime.name] ?? 'blue';

  return (
    <section className='pbs-card' aria-label='Reading patterns'>
      <div className='pbs-card-head'>
        <h3>
          Reading patterns
          <button
            type='button'
            className='pbs-info'
            aria-label='About reading patterns'
            aria-expanded={info}
            onClick={() => setInfo((v) => !v)}
          >
            <SIcon name='info' />
          </button>
        </h3>
        <div className='pbs-seg pbs-mini' role='group' aria-label='Count by'>
          <button type='button' aria-pressed={metric === 'sessions'} onClick={() => setMetric('sessions')}>
            Sessions
          </button>
          <button type='button' aria-pressed={metric === 'pages'} onClick={() => setMetric('pages')}>
            Pages
          </button>
        </div>
      </div>
      {info && (
        <p className='pbs-info-note'>
          Based on your last {PATTERN_DAYS} days. A session counts toward the hour it started in. Morning 5–12 ·
          Afternoon 12–17 · Evening 17–22 · Night 22–5. Pages follow the reader&apos;s own pagination.
        </p>
      )}

      {empty ? (
        <p className='pbs-sentence' style={{ marginTop: 16 }}>
          Read a little more and your habits will show up here.
        </p>
      ) : (
        <>
          <p className='pbs-sentence' style={{ marginTop: 16 }}>
            You read mostly in the <em>{p.topTime.name.toLowerCase()}</em>,{' '}
            {p.weekPart === 'all week' ? (
              <>
                <u>all week</u> long.
              </>
            ) : (
              <>
                on <u>{p.weekPart}</u>.
              </>
            )}
          </p>

          <div className='pbs-radial-row' style={{ marginTop: 14 }}>
            <div className='pbs-radial'>
              <svg viewBox='-110 -110 220 220' role='img' aria-label='Reading by hour of day, clock layout'>
                <g className='pbs-ring'>
                  <circle r='30' />
                  <circle r='60' />
                  <circle r='90' />
                </g>
                <g className='pbs-axis'>
                  <line x1='-96' x2='96' />
                  <line y1='-96' y2='96' />
                </g>
                {p.byHour.map((v, h) => {
                  if (!v) return null;
                  const color = `var(--${TIME_COLOR[timeOfDayName(h)]})`;
                  const [x, y] = pol(R0 + (v / max) * RMAX, h * 15 + 7.5);
                  const [x0, y0] = pol(R0, h * 15 + 7.5);
                  return (
                    <g key={h}>
                      <line x1={f(x0)} y1={f(y0)} x2={f(x)} y2={f(y)} stroke={color} strokeWidth='2' opacity='0.7' />
                      <circle cx={f(x)} cy={f(y)} r={h === p.peakHour ? 9 : 5 + (v / max) * 3} fill={color} />
                    </g>
                  );
                })}
                <circle r='5' fill='var(--text)' />
                <g className='pbs-hr' textAnchor='middle'>
                  <text y='-98'>00</text>
                  <text x='101' y='3'>06</text>
                  <text y='108'>12</text>
                  <text x='-101' y='3'>18</text>
                </g>
                {p.byHour.map((_, h) => {
                  const [x0, y0] = pol(R0, h * 15);
                  const [x1, y1] = pol(100, h * 15);
                  const [x2, y2] = pol(100, h * 15 + 15);
                  const [x3, y3] = pol(R0, h * 15 + 15);
                  return (
                    <path
                      key={`h${h}`}
                      className='pbs-hit'
                      tabIndex={0}
                      role='button'
                      aria-label={`${hh(h)} hours`}
                      d={`M${f(x0)} ${f(y0)} L${f(x1)} ${f(y1)} A100 100 0 0 1 ${f(x2)} ${f(y2)} L${f(x3)} ${f(y3)} A${R0} ${R0} 0 0 0 ${f(x0)} ${f(y0)} Z`}
                      onClick={(e) => {
                        e.stopPropagation();
                        setTip(h);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          setTip(h);
                        }
                      }}
                    />
                  );
                })}
              </svg>
              {tip !== null &&
                (() => {
                  const [x, y] = pol(R0 + 30, tip * 15 + 7.5);
                  return (
                    <div className='pbs-tip' style={{ left: `${((110 + x) / 220) * 100}%`, top: `${((110 + y) / 220) * 100}%` }}>
                      {hh(tip)}h · {p.byHour[tip]}
                    </div>
                  );
                })()}
            </div>
            <div className='pbs-pstats'>
              <div className={ac(topColor)}>
                <div className='pbs-label'>Most active</div>
                <div className='pbs-v pbs-ac'>{p.topTime.name}</div>
                <div className='pbs-sub'>
                  {formatCount(p.topTime.value)} {unitOf(p.topTime.value)}
                </div>
              </div>
              <div>
                <div className='pbs-label'>Best day</div>
                <div className='pbs-v'>{p.topWeekday.name}</div>
                <div className='pbs-sub'>
                  {formatCount(p.topWeekday.value)} {unitOf(p.topWeekday.value)}
                </div>
              </div>
              <div>
                <div className='pbs-label'>Peak</div>
                <div className='pbs-v'>
                  {p.peakHour}–{(p.peakHour + 1) % 24}h
                </div>
              </div>
            </div>
          </div>

          <div className='pbs-times'>
            {p.byTime.map((t) => (
              <div key={t.name} className={ac(TIME_COLOR[t.name] ?? 'blue')}>
                <div className='pbs-t'>{t.name}</div>
                <div className='pbs-v'>{formatCount(t.value)}</div>
              </div>
            ))}
          </div>

          <div className='pbs-wk' role='img' aria-label={`${unit} by day of week`}>
            {p.byWeekday.map((d) => (
              <div key={d.name}>
                <i className={clsx(d.value === 0 && 'pbs-zero')} style={{ height: d.value ? `${Math.max(8, Math.round((d.value / wmax) * 60))}px` : undefined }} />
                <span>{d.name.slice(0, 3)}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}
