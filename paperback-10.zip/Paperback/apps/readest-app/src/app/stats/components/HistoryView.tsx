'use client';

import clsx from 'clsx';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { PBook } from '@/services/paperback/library';
import { firstMonthIndex, monthView } from '@/services/statistics/historyStats';
import { sessionPagesText } from '@/services/statistics/activityStats';
import { dayKeyOf, formatClock, formatCount, type StatEventRow } from '@/services/statistics/statsAggregate';
import { SIcon } from './StatsIcons';
import type { StatsLinks } from '../links';
import { Thumb } from './ui';
import { Tap, accentOf, ac } from './parts';

const FIRST = 8; // sessions shown when a month opens
const MORE = 25; // sessions added by each "more"

interface Props {
  events: StatEventRow[];
  booksByHash: Map<string, PBook>;
  now: Date;
  /** Open on the month of this day, with that day's sessions in view. */
  focus?: Date | null;
  links: StatsLinks;
}

/** Stats → History: a calendar of reading days and the sessions of the month, day by day. */
export default function HistoryView({ events, booksByHash, now, focus = null, links }: Props) {
  const nowIdx = now.getFullYear() * 12 + now.getMonth();
  const firstIdx = useMemo(() => firstMonthIndex(events, now), [events, now]);
  const [idx, setIdx] = useState(() =>
    focus ? Math.max(firstIdx, Math.min(nowIdx, focus.getFullYear() * 12 + focus.getMonth())) : nowIdx,
  );
  const wanted = useRef<string | null>(focus ? dayKeyOf(focus) : null);
  const [selected, setSelected] = useState<string | null>(null);
  const [visible, setVisible] = useState(FIRST);

  const y = Math.floor(idx / 12);
  const m = idx % 12;
  const month = useMemo(() => monthView(events, y, m, now), [events, y, m, now]);

  // Bring a day's sessions into the list and into view.
  const showDay = (key: string, smooth: boolean) => {
    const upTo = month.groups.findIndex((g) => g.key === key);
    const need = month.groups.slice(0, upTo + 1).reduce((n, g) => n + g.sessions.length, 0);
    setVisible((v) => Math.max(v, need));
    requestAnimationFrame(() =>
      requestAnimationFrame(() =>
        document.getElementById(`pbs-day-${key}`)?.scrollIntoView?.({ behavior: smooth ? 'smooth' : 'auto', block: 'start' }),
      ),
    );
  };

  // A new month starts with its newest day picked and the short list; a day asked for from another page wins once.
  useEffect(() => {
    const want = wanted.current;
    wanted.current = null;
    const hit = want && month.groups.some((g) => g.key === want) ? want : null;
    setSelected(hit ?? month.groups[0]?.key ?? null);
    setVisible(FIRST);
    if (hit) showDay(hit, false);
  }, [month]);

  const pickDay = (key: string, has: boolean) => {
    if (!has) return;
    setSelected(key);
    showDay(key, true);
  };

  // The sessions to show, newest day first, cut after `visible` of them.
  let left = visible;
  const groups = month.groups
    .map((g) => {
      const take = g.sessions.slice(0, Math.max(0, left));
      left -= take.length;
      return { ...g, sessions: take };
    })
    .filter((g) => g.sessions.length > 0);
  const hidden = month.sessionCount - groups.reduce((n, g) => n + g.sessions.length, 0);

  return (
    <div className='pbs-screen pbs-col'>
      <section className='pbs-card' aria-label='Calendar'>
        <div className='pbs-calhead'>
          <div>
            <h3>{month.title}</h3>
            <div className='pbs-sub'>
              {month.sessionCount} {month.sessionCount === 1 ? 'session' : 'sessions'} · {formatCount(month.pageCount)}{' '}
              {month.pageCount === 1 ? 'page' : 'pages'}
            </div>
          </div>
          <div className='pbs-calnav'>
            <button type='button' className='pbs-round pbs-sm' aria-label='Previous month' disabled={idx <= firstIdx} onClick={() => setIdx(idx - 1)}>
              <SIcon name='cl' />
            </button>
            <button type='button' className='pbs-round pbs-sm' aria-label='Next month' disabled={idx >= nowIdx} onClick={() => setIdx(idx + 1)}>
              <SIcon name='cr' />
            </button>
          </div>
        </div>
        <div className='pbs-days'>
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((c, i) => (
            <span key={i} className='pbs-label'>
              {c}
            </span>
          ))}
          {Array.from({ length: month.blanks }, (_, i) => (
            <i key={`b${i}`} />
          ))}
          {month.days.map((d) => {
            const has = d.sessions > 0;
            return (
              <button
                key={d.key}
                type='button'
                className={clsx('pbs-cd', has && 'pbs-has', d.key === selected && 'pbs-sel', d.isToday && !has && 'pbs-today', d.inFuture && 'pbs-fut')}
                disabled={!has}
                aria-label={`${d.day} ${month.title}${has ? `, ${d.sessions} ${d.sessions === 1 ? 'session' : 'sessions'}` : ''}`}
                aria-pressed={has ? d.key === selected : undefined}
                onClick={() => pickDay(d.key, has)}
              >
                {d.day}
              </button>
            );
          })}
        </div>
      </section>

      {month.sessionCount === 0 && <div className='pbs-card pbs-empty'>No reading in {month.title}.</div>}

      {groups.map((g) => (
        <div key={g.key} className='pbs-col' style={{ gap: 10 }}>
          <div id={`pbs-day-${g.key}`} className='pbs-label pbs-daylabel'>
            {g.label}
          </div>
          {g.sessions.map((s) => (
            <Tap
              key={`${s.md5}-${s.start}`}
              className={clsx('pbs-card pbs-sess', ac(accentOf(s.md5)))}
              onTap={booksByHash.has(s.md5) ? () => links.book(s.md5) : undefined}
              label={booksByHash.has(s.md5) ? `${s.title}. Open book details.` : undefined}
            >
              <div className='pbs-sc'>
                <Thumb md5={s.md5} book={booksByHash.get(s.md5)} />
              </div>
              <div>
                <h4>{s.title}</h4>
                <p>
                  {sessionPagesText(s).split(' · ')[0]} · {formatClock(s.start)}
                </p>
              </div>
              <b>
                {s.pages} {s.pages === 1 ? 'page' : 'pages'}
              </b>
            </Tap>
          ))}
        </div>
      ))}

      {hidden > 0 && (
        <button type='button' className='pbs-more' onClick={() => setVisible((v) => v + MORE)}>
          {hidden} more session{hidden > 1 ? 's' : ''}
        </button>
      )}
    </div>
  );
}
