'use client';

import clsx from 'clsx';
import { useEffect, useMemo, useState } from 'react';
import type { PBook } from '@/services/paperback/library';
import {
  buildHeatmap,
  computeStreaks,
  dayKeyOf,
  formatCount,
  secondsByDay,
  topBooks,
  type StatEventRow,
} from '@/services/statistics/statsAggregate';
import {
  barName,
  computeDetails,
  currentAnchor,
  dateLabel,
  firstReadingYear,
  goalWeek,
  nextBestAction,
  paceSeries,
  pctDelta,
  periodData,
  periodInfo,
  sessionWhen,
  shiftAnchor,
  type Anchor,
  type Details,
  type Period,
  type PeriodData,
} from '@/services/statistics/activityStats';
import { windowSeconds } from '@/services/statistics/shelfStats';
import { countFinishedBetween } from '../useStatsData';
import { DEFAULT_GOALS, loadGoals } from '../goals';
import type { StatsLinks } from '../links';
import PatternsCard from './PatternsCard';
import PeriodDialog from './PeriodDialog';
import { SIcon } from './StatsIcons';
import { Thumb } from './ui';
import { AreaChart, Sparkline, Tap, ac, fmtMin, type Accent } from './parts';

type Metric = 'time' | 'pages';

const PERIODS: { id: Period; label: string }[] = [
  { id: 'week', label: 'Week' },
  { id: 'month', label: 'Month' },
  { id: 'year', label: 'Year' },
  { id: 'all', label: 'All' },
];

const signed = (n: number) => `${n > 0 ? '+' : n < 0 ? '−' : ''}${Math.abs(n)}`;
const ARC = Math.PI * 120; // length of the half circle of the daily goal

function BigTime({ seconds }: { seconds: number }) {
  const min = Math.round(seconds / 60);
  if (min >= 60) {
    return (
      <>
        <span>{Math.floor(min / 60)}</span>
        <span className='pbs-u'>h</span>
        <span>{min % 60}</span>
        <span className='pbs-u'>m</span>
      </>
    );
  }
  return (
    <>
      <span>{min}</span>
      <span className='pbs-u'>m</span>
    </>
  );
}

interface Props {
  events: StatEventRow[];
  library: PBook[];
  booksByHash: Map<string, PBook>;
  now: Date;
  links: StatsLinks;
}

/** Stats → Activity: daily goal, next best action, hero chart, pace, details, rhythm, patterns, most read. */
export default function ActivityView({ events, library, booksByHash, now, links }: Props) {
  const [period, setPeriod] = useState<Period>('week');
  const [metric, setMetric] = useState<Metric>('time');
  const [anchor, setAnchor] = useState<Anchor>(() => currentAnchor(now));
  const [picking, setPicking] = useState(false);
  const [picked, setPicked] = useState<number | null>(null);
  const [goals, setGoals] = useState(DEFAULT_GOALS);
  useEffect(() => setGoals(loadGoals()), []);
  const goalMin = goals.minutesPerDay;
  const goalSeconds = goalMin * 60;

  const firstYear = useMemo(() => firstReadingYear(events, now), [events, now]);
  const firstTime = useMemo(() => events.reduce((m, e) => Math.min(m, e.startTime), Infinity), [events]);
  const byDay = useMemo(() => secondsByDay(events), [events]);
  const streaks = useMemo(() => computeStreaks(byDay, now), [byDay, now]);

  const info = useMemo(() => periodInfo(period, anchor, now, firstYear), [period, anchor, now, firstYear]);
  const data = useMemo(() => periodData(events, info, now), [events, info, now]);
  const prev: PeriodData | null = useMemo(() => {
    if (period === 'all') return null;
    const pInfo = periodInfo(period, shiftAnchor(period, anchor, -1, now), now, firstYear);
    return periodData(events, pInfo, now);
  }, [events, period, anchor, now, firstYear]);
  const details = useMemo(() => computeDetails(data, now), [data, now]);
  const prevDetails = useMemo(() => (prev ? computeDetails(prev, now) : null), [prev, now]);
  const finished = useMemo(
    () => countFinishedBetween(library, info.start, info.end),
    [library, info.start, info.end],
  );
  const pace = useMemo(() => paceSeries(data), [data]);

  const time = metric === 'time';
  const vals = time ? data.seconds : data.pages;
  const goalOn = (period === 'week' || period === 'month') && time;

  // ---- hero numbers
  const total = time ? data.totalSeconds : data.totalPages;
  const prevTotal = prev ? (time ? prev.totalSeconds : prev.totalPages) : 0;
  const delta = period === 'all' ? null : pctDelta(total, prevTotal);

  // The picked bar: what the person tapped, else today / this month once it has reading, else the biggest one.
  useEffect(() => setPicked(null), [period, anchor, metric]);
  const best = useMemo(() => {
    let b = -1;
    let m = -1;
    vals.forEach((v, i) => {
      if (v !== null && v > m) {
        m = v;
        b = i;
      }
    });
    return b < 0 ? 0 : b;
  }, [vals]);
  const selected = picked ?? (info.curIdx >= 0 && (vals[info.curIdx] ?? 0) > 0 ? info.curIdx : best);

  const hasEarlier = firstTime < Math.floor(info.start.getTime() / 1000);
  const canPrev = period !== 'all' && hasEarlier;
  const move = (dir: -1 | 1) => setAnchor((a) => shiftAnchor(period, a, dir, now));

  // ---- today's goal
  const todayKey = dayKeyOf(now);
  const todaySeconds = byDay.get(todayKey) ?? 0;
  const goalPct = Math.min(1, todaySeconds / goalSeconds);
  const readMin = Math.floor(todaySeconds / 60);
  const toGo = Math.max(0, goalMin - readMin);
  const week = useMemo(() => goalWeek(byDay, goalMin, now), [byDay, goalMin, now]);
  const metDays = week.filter((d) => d.met).length;
  const weekSeconds = week.reduce((s, d) => s + (byDay.get(d.key) ?? 0), 0);
  const action = nextBestAction({
    todaySeconds,
    goalMinutes: goalMin,
    streak: streaks.current,
    longestStreak: streaks.longest,
  });

  // ---- rhythm + most read
  const heat = useMemo(() => buildHeatmap(byDay, now, 18), [byDay, now]);
  const top = useMemo(() => topBooks(data.events, 6), [data.events]);
  const topColors: Accent[] = ['pink', 'yellow', 'blue', 'mint'];

  // Where the links go: History on the last day of the window (not after today), and shelves of this window's books.
  const lastDay = info.end.getTime() > now.getTime() ? now : info.end;
  const win = windowSeconds(info.start, info.end);
  const openMostRead = () => links.shelf({ kind: 'read', ...win, label: info.label });
  const openFinished = () => links.shelf({ kind: 'done', ...win, label: info.label });

  return (
    <div className='pbs-screen pbs-col'>
      {/* ---------- daily goal ---------- */}
      <Tap className='pbs-card pbs-goal' onTap={links.goals} label={`Daily goal: ${readMin} of ${goalMin} minutes today. Open reading goals.`}>
        <div className='pbs-row'>
          <span className='pbs-label'>Daily goal</span>
          <span className='pbs-label pbs-togo'>{toGo > 0 ? `${toGo} min to go` : 'Goal reached'}</span>
        </div>
        <svg className='pbs-gauge' viewBox='0 0 322 184' role='img' aria-label={`${readMin} of ${goalMin} minutes today`}>
          <path d='M41,165 A120,120 0 0 1 281,165' fill='none' stroke='var(--track)' strokeWidth='20' strokeLinecap='round' />
          {goalPct > 0 ? (
            <path
              d='M41,165 A120,120 0 0 1 281,165'
              fill='none'
              stroke='var(--blue)'
              strokeWidth='20'
              strokeLinecap='round'
              strokeDasharray={`${(ARC * goalPct).toFixed(1)} ${ARC.toFixed(1)}`}
            />
          ) : (
            <circle cx='41' cy='165' r='10' fill='var(--blue)' />
          )}
          <text className='pbs-gnum' x='161' y='132' textAnchor='middle'>
            {readMin}
          </text>
          <text className='pbs-cap' x='161' y='156' textAnchor='middle'>
            of {goalMin} min today
          </text>
          <text className='pbs-end' x='28' y='181'>
            0
          </text>
          <text className='pbs-end' x='294' y='181' textAnchor='end'>
            {goalMin}m
          </text>
        </svg>
        <div className='pbs-trio'>
          <div>
            <div className='pbs-n' style={{ color: 'var(--yellow)' }}>
              {streaks.current}d
            </div>
            <div className='pbs-sub'>Streak</div>
          </div>
          <div>
            <div className='pbs-n'>{metDays}/7</div>
            <div className='pbs-sub'>Goal met</div>
          </div>
          <div>
            <div className='pbs-n' style={{ color: 'var(--mint)' }}>
              {fmtMin(weekSeconds)}
            </div>
            <div className='pbs-sub'>This week</div>
          </div>
        </div>
      </Tap>

      {/* ---------- next best action ---------- */}
      <button type='button' className='pbs-nba' onClick={links.goals}>
        <div>
          <div className='pbs-label'>Next best action</div>
          <b>{action.title}</b>
          <span className='pbs-sub'>{action.text}</span>
        </div>
        <span className='pbs-go' aria-hidden='true'>
          <SIcon name='cr' />
        </span>
      </button>

      {/* ---------- hero chart ---------- */}
      <section className='pbs-card pbs-hero' aria-label='Reading summary'>
        <div className='pbs-seg' role='group' aria-label='Period'>
          {PERIODS.map((p) => (
            <button key={p.id} type='button' aria-pressed={p.id === period} onClick={() => setPeriod(p.id)}>
              {p.label}
            </button>
          ))}
        </div>

        <div className='pbs-label pbs-lead'>
          <span>
            {time ? 'Time' : 'Pages'} · {info.label}
          </span>
          <span className='pbs-seg pbs-mini' role='group' aria-label='Metric'>
            <button type='button' aria-pressed={time} onClick={() => setMetric('time')}>
              Time
            </button>
            <button type='button' aria-pressed={!time} onClick={() => setMetric('pages')}>
              Pages
            </button>
          </span>
        </div>

        <div className='pbs-big'>
          {time ? (
            <BigTime seconds={total} />
          ) : (
            <>
              <span>{formatCount(total)}</span>
              <span className='pbs-u'>pages</span>
            </>
          )}
        </div>

        {period === 'all' ? (
          <div className='pbs-delta pbs-neu'>Since {firstYear}</div>
        ) : (
          delta !== null && (
            <div className={clsx('pbs-delta', delta < 0 && 'pbs-neg', delta === 0 && 'pbs-neu')}>
              <SIcon name='up' />
              <span>
                {signed(delta)}% vs {info.vsName}
              </span>
            </div>
          )
        )}

        <AreaChart
          values={vals}
          labels={info.labels}
          names={vals.map((_, i) => barName(info, i))}
          format={(v) => (time ? fmtMin(v) : `${v} ${v === 1 ? 'page' : 'pages'}`)}
          selected={selected}
          onSelect={setPicked}
          curIdx={info.curIdx}
          goal={goalOn ? goalSeconds : null}
          goalLabel={`${goalMin} min goal`}
          ariaLabel={`${time ? 'Minutes' : 'Pages'} read per ${info.unit} for ${info.label}.`}
        />

        {period !== 'all' && (
          <div className='pbs-hero-foot'>
            <div className='pbs-pager'>
              <button type='button' className='pbs-round pbs-sm' aria-label='Previous period' disabled={!canPrev} onClick={() => move(-1)}>
                <SIcon name='cl' />
              </button>
              <button type='button' className='pbs-pl' aria-haspopup='dialog' onClick={() => setPicking(true)}>
                {info.pagerLabel}
              </button>
              <button type='button' className='pbs-round pbs-sm' aria-label='Next period' disabled={info.isCurrent} onClick={() => move(1)}>
                <SIcon name='cr' />
              </button>
            </div>
          </div>
        )}
        <div className='pbs-linkrow'>
          <button type='button' onClick={() => links.history(lastDay)}>
            <SIcon name='list' />
            View sessions
            <SIcon name='cr' />
          </button>
        </div>
      </section>

      {/* ---------- pace, sessions, finished ---------- */}
      <div className='pbs-label pbs-section-label'>Details · {info.label}</div>
      <DetailTiles
        period={period}
        d={details}
        prev={prevDetails}
        prevHasData={!!prev && prev.summary.sessions > 0}
        vsName={info.vsName}
        firstYear={firstYear}
        finished={finished}
        spark={pace}
        onInsights={() => links.page('insights')}
        onSessions={() => links.history(lastDay)}
        onFinished={finished > 0 ? openFinished : undefined}
      />

      {/* ---------- session length vs the goal ---------- */}
      <section className='pbs-card' aria-label='Session length'>
        <div className='pbs-card-head'>
          <h3>Session length</h3>
          <span>vs {goalMin} min goal</span>
        </div>
        <div className='pbs-gr'>
          {(
            [
              ['Avg session', 'blue', details.avgSessionSeconds],
              ['Longest session', 'mint', details.longest?.seconds ?? 0],
              ['Best day', 'pink', details.bestDay?.seconds ?? 0],
              ['Average a day', 'yellow', details.avgPerDaySeconds],
            ] as [string, Accent, number][]
          ).map(([name, color, secs]) => (
            <div key={name} className={ac(color)}>
              <span className='pbs-gl'>{name}</span>
              <div className='pbs-gb'>
                <i style={{ width: `${secs > 0 ? Math.max(3, Math.min(100, (secs / goalSeconds) * 100)) : 0}%` }} />
                <s />
              </div>
              <b>{fmtMin(secs)}</b>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- reading rhythm ---------- */}
      <section className='pbs-card' aria-label='Reading rhythm'>
        <div className='pbs-card-head'>
          <h3>Reading rhythm</h3>
          <span>18 weeks</span>
        </div>
        <div className='pbs-dots' role='group' aria-label='Reading days over the last 18 weeks, brighter means more reading. Tap a day to open it.'>
          {heat.map((col) =>
            col.map((c) => {
              const cls = clsx('pbs-dc', c.level > 0 && `pbs-l${c.level}`, c.inFuture && 'pbs-fut', c.key === todayKey && 'pbs-today');
              if (c.inFuture || c.seconds <= 0) return <div key={c.key} className={cls} />;
              const [yy, mm, dd] = c.key.split('-').map(Number);
              return (
                <button
                  key={c.key}
                  type='button'
                  className={cls}
                  aria-label={`${dd}/${mm}/${yy}: ${fmtMin(c.seconds)} read. Open that day.`}
                  onClick={() => links.history(new Date(yy!, mm! - 1, dd!))}
                />
              );
            }),
          )}
        </div>
        <div className='pbs-heat-legend' aria-hidden='true'>
          <span>Less</span>
          <div className='pbs-dc' />
          <div className='pbs-dc pbs-l1' />
          <div className='pbs-dc pbs-l2' />
          <div className='pbs-dc pbs-l3' />
          <div className='pbs-dc pbs-l4' />
          <span>More</span>
        </div>
      </section>

      {/* ---------- reading patterns ---------- */}
      <PatternsCard events={events} now={now} />

      {/* ---------- most read ---------- */}
      {top.length > 0 && (
        <>
          <div className='pbs-label pbs-section-label pbs-sec'>
            <span>Most read · {info.label}</span>
            <button type='button' className='pbs-seeall' onClick={openMostRead}>
              See all
              <SIcon name='cr' />
            </button>
          </div>
          <div className='pbs-hs'>
            {top.map((b, i) => {
              const pct = Math.round(b.share * 100);
              const inLibrary = booksByHash.has(b.md5);
              return (
                <Tap
                  key={b.md5}
                  className={clsx('pbs-bk', ac(topColors[i % 4]!))}
                  onTap={inLibrary ? () => links.book(b.md5) : undefined}
                  label={inLibrary ? `${b.title}. Open book details.` : undefined}
                >
                  <div className='pbs-cov'>
                    <Thumb md5={b.md5} book={booksByHash.get(b.md5)} />
                    <span className='pbs-badge'>{pct}%</span>
                  </div>
                  <h4>{b.title}</h4>
                  <p>
                    {b.authors ? `${b.authors} · ` : ''}
                    {fmtMin(b.seconds)}
                  </p>
                </Tap>
              );
            })}
          </div>
        </>
      )}

      <p className='pbs-note'>
        Pages follow the reader&apos;s own pagination, so they shift a little when you change font size or margins. A
        page visit counts for at most 2 minutes, so a forgotten screen doesn&apos;t inflate your time.
      </p>

      {picking && period !== 'all' && (
        <PeriodDialog
          period={period}
          anchor={anchor}
          now={now}
          onCancel={() => setPicking(false)}
          onOk={(a) => {
            setAnchor(a);
            setPicking(false);
          }}
        />
      )}
    </div>
  );
}

function DetailTiles({
  period,
  d,
  prev,
  prevHasData,
  vsName,
  firstYear,
  finished,
  spark,
  onInsights,
  onSessions,
  onFinished,
}: {
  period: Period;
  d: Details;
  prev: Details | null;
  prevHasData: boolean;
  vsName: string;
  firstYear: number;
  finished: number;
  spark: number[];
  onInsights: () => void;
  onSessions: () => void;
  onFinished?: (() => void) | undefined;
}) {
  const vs = `vs ${vsName}`;
  const diff = (cur: number, before: number | undefined) =>
    prevHasData && prev && before !== undefined && cur > 0 ? (
      <>
        <b>{signed(cur - before)}</b> {vs}
      </>
    ) : null;
  const n = d.sessions;

  return (
    <section className='pbs-tiles' aria-label='Details'>
      <Tap className='pbs-card pbs-pace pbs-wide' onTap={onInsights} label='Reading pace. Open Insights.'>
        <div>
          <div className='pbs-label'>Reading pace</div>
          <div className='pbs-n'>
            {d.pace ? d.pace : '–'}
            {d.pace ? <span className='pbs-u'>p/h</span> : null}
          </div>
          <div className='pbs-sub'>{diff(d.pace, prev?.pace) ?? 'pages per hour'}</div>
        </div>
        <Sparkline values={spark} />
      </Tap>
      <Tap className={clsx('pbs-tile pbs-hint', ac('mint'))} onTap={onSessions} label={`${n} sessions. Open History.`}>
        <div className='pbs-label'>Sessions</div>
        <div className='pbs-n'>{n}</div>
        <div className='pbs-sub'>
          {diff(n, prev?.sessions) ?? (period === 'all' ? `since ${firstYear}` : 'in this period')}
        </div>
      </Tap>
      <Tap className={clsx('pbs-tile', onFinished && 'pbs-hint', ac('pink'))} onTap={onFinished} label={onFinished ? `${finished} finished. Show the books.` : undefined}>
        <div className='pbs-label'>Finished</div>
        <div className='pbs-n'>
          {finished}
          <span className='pbs-u'>{finished === 1 ? 'book' : 'books'}</span>
        </div>
        <div className='pbs-sub'>
          {d.longest ? `longest ${fmtMin(d.longest.seconds)} · ${sessionWhen(period, d.longest)}` : d.bestDay ? `best day ${dateLabel(period, d.bestDay.date)}` : ''}
        </div>
      </Tap>
    </section>
  );
}
