'use client';

import clsx from 'clsx';
import type { PBook } from '@/services/paperback/library';
import type { ShelfView } from '@/services/statistics/shelfStats';
import type { StatsLinks } from '../links';
import { SIcon } from './StatsIcons';
import { Thumb } from './ui';
import { Tap, ac, accentOf } from './parts';

interface Props {
  view: ShelfView;
  booksByHash: Map<string, PBook>;
  links: StatsLinks;
  onBack: () => void;
}

/** A shelf of the books behind a number in Stats; tap a cover for the book's details. */
export default function ShelfScreen({ view, booksByHash, links, onBack }: Props) {
  return (
    <div className='pbs pbs-col'>
      <div className='pbs-stop'>
        <button type='button' className='pbs-round' aria-label='Back to Stats' onClick={onBack}>
          <SIcon name='back' />
        </button>
        <h2>{view.title}</h2>
      </div>
      <p className='pbs-shelf-sub'>{view.sub}</p>

      {view.total === 0 && <div className='pbs-card pbs-empty'>{view.empty}</div>}

      {view.sections.map((s, i) => (
        <section key={s.title ?? i} className='pbs-col' aria-label={s.title ?? view.title}>
          {s.title && <div className='pbs-label pbs-section-label'>{s.title}</div>}
          <div className='pbs-shelf'>
            {s.books.map((b) => (
              <Tap
                key={b.hash}
                className={clsx('pbs-sbk', ac(accentOf(b.hash)), !b.inLibrary && 'pbs-gone')}
                onTap={b.inLibrary ? () => links.book(b.hash) : undefined}
                label={b.inLibrary ? `${b.title}. Open book details.` : undefined}
              >
                <div className='pbs-cov'>
                  <Thumb md5={b.hash} book={booksByHash.get(b.hash)} />
                  {b.badge && <span className='pbs-badge'>{b.badge}</span>}
                </div>
                <h4>{b.title}</h4>
                <p>{[b.author, b.meta].filter(Boolean).join(' · ')}</p>
              </Tap>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
