'use client';

import { useEffect, useRef } from 'react';
import type { StatsIconName } from './StatsIcons';

export type StatsPage = 'activity' | 'milestones' | 'books' | 'history' | 'insights';

export const STATS_PAGES: { id: StatsPage; label: string; icon: StatsIconName }[] = [
  { id: 'activity', label: 'Activity', icon: 'activity' },
  { id: 'milestones', label: 'Milestones', icon: 'trophy' },
  { id: 'books', label: 'Books', icon: 'book' },
  { id: 'history', label: 'History', icon: 'history' },
  { id: 'insights', label: 'Insights', icon: 'spark' },
];

/** The five pages of Stats as a row of pills that scrolls sideways; the open one is filled. */
export default function StatsNav({ value, onChange }: { value: StatsPage; onChange: (p: StatsPage) => void }) {
  const ref = useRef<HTMLElement>(null);

  // Keep the open page in view when the row is wider than the screen.
  useEffect(() => {
    const on = ref.current?.querySelector<HTMLElement>('[aria-current="page"]');
    on?.scrollIntoView?.({ inline: 'center', block: 'nearest' });
  }, [value]);

  return (
    <nav ref={ref} className='pbs-tabs' aria-label='Stats pages'>
      {STATS_PAGES.map((p) => (
        <button
          key={p.id}
          type='button'
          className='pbs-tab'
          aria-current={p.id === value ? 'page' : undefined}
          onClick={() => p.id !== value && onChange(p.id)}
        >
          {p.label}
        </button>
      ))}
    </nav>
  );
}
