'use client';

import clsx from 'clsx';
import { useMemo } from 'react';
import type { PBook } from '@/services/paperback/library';
import { booksOverview } from '@/services/statistics/booksStats';
import { formatCount, type StatEventRow } from '@/services/statistics/statsAggregate';
import type { StatsLinks } from '../links';
import { SIcon } from './StatsIcons';
import { Thumb } from './ui';
import { ACCENTS, Stars, Tap, ac } from './parts';

const MAX_PROGRESS = 6;
const MAX_AUTHORS = 14;

interface Props {
  events: StatEventRow[];
  library: PBook[];
  ratings: Record<string, number>;
  links: StatsLinks;
}

/** Stats → Books: what is in the library, what you are reading, authors and ratings. */
export default function BooksView({ events, library, ratings, links }: Props) {
  const o = useMemo(() => booksOverview(library, events, ratings), [library, events, ratings]);

  if (o.total === 0) {
    return (
      <div className='pbs-card pbs-empty'>
        <b>No books yet</b>
        Add a book to the library and its stats will show up here.
      </div>
    );
  }

  const shownProgress = o.progress.slice(0, MAX_PROGRESS);
  const hiddenProgress = o.progress.length - shownProgress.length;
  const shownAuthors = o.authors.slice(0, MAX_AUTHORS);
  const hiddenAuthors = o.authors.length - shownAuthors.length;

  return (
    <div className='pbs-screen pbs-col'>
      <Tap className='pbs-card pbs-lib' onTap={() => links.library('all')} label={`Library: ${o.total} ${o.total === 1 ? 'book' : 'books'}. Open all books.`}>
        <div>
          <div className='pbs-label'>Library</div>
          <div className='pbs-n'>{formatCount(o.total)}</div>
          <div className='pbs-sub' style={{ marginTop: 6 }}>
            {o.total === 1 ? 'book' : 'books'}
          </div>
        </div>
        <div className={clsx('pbs-fan', o.recent.length === 1 && 'pbs-one')} aria-hidden='true'>
          {o.recent.map((b) => (
            <div key={b.hash}>
              <Thumb md5={b.hash} book={library.find((x) => x.hash === b.hash)} />
            </div>
          ))}
        </div>
      </Tap>

      <div className='pbs-tiles'>
        <Tap className={clsx('pbs-tile', o.finished > 0 && 'pbs-hint', ac('mint'))} onTap={o.finished > 0 ? () => links.library('finished') : undefined} label={`${o.finished} finished. Show the finished books.`}>
          <div className='pbs-label'>Finished</div>
          <div className='pbs-n'>{o.finished}</div>
        </Tap>
        <Tap className={clsx('pbs-tile', o.reading > 0 && 'pbs-hint', ac('pink'))} onTap={o.reading > 0 ? () => links.library('reading') : undefined} label={`${o.reading} reading. Show the books you are reading.`}>
          <div className='pbs-label'>Reading</div>
          <div className='pbs-n'>{o.reading}</div>
        </Tap>
        <Tap className={clsx('pbs-tile', o.longest && 'pbs-hint', ac('blue'))} onTap={o.longest ? () => links.book(o.longest!.hash) : undefined} label={o.longest ? `Longest read: ${o.longest.title}. Open book details.` : undefined}>
          <div className='pbs-label'>Longest read</div>
          <div className='pbs-n'>
            {o.longest ? formatCount(o.longest.pages) : '–'}
            {o.longest && <span className='pbs-u'>pages</span>}
          </div>
          {o.longest && <div className='pbs-sub' style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{o.longest.title}</div>}
        </Tap>
        <Tap className={clsx('pbs-tile pbs-hint', ac('yellow'))} onTap={() => links.shelf({ kind: 'langs' })} label={`${o.languages.length} languages. Show the books by language.`}>
          <div className='pbs-label'>Languages</div>
          <div className='pbs-n'>{o.languages.length || '–'}</div>
          {o.languages.length > 0 && <div className='pbs-sub'>{o.languages.join(' · ')}</div>}
        </Tap>
      </div>

      {shownProgress.length > 0 && (
        <section className='pbs-card' aria-label='Reading progress'>
          <div className='pbs-label pbs-sec'>
            <span>Reading progress</span>
            <button type='button' className='pbs-seeall' onClick={() => links.library('reading')}>
              Open shelf
              <SIcon name='cr' />
            </button>
          </div>
          <div className='pbs-prog'>
            {shownProgress.map((r, i) => (
              <Tap key={r.hash} className={ac(ACCENTS[(i + 3) % 4]!)} onTap={() => links.book(r.hash)} label={`${r.title}, ${r.pct}%. Open book details.`}>
                <div className='pbs-pr'>
                  <span>{r.title}</span>
                  <b>{r.pct}%</b>
                </div>
                <div className='pbs-meter'>
                  <i style={{ width: `${Math.max(r.pct, 1)}%` }} />
                </div>
              </Tap>
            ))}
          </div>
          {hiddenProgress > 0 && (
            <p className='pbs-note' style={{ margin: '14px 0 0' }}>
              and {hiddenProgress} more
            </p>
          )}
        </section>
      )}

      {shownAuthors.length > 0 && (
        <section className='pbs-card' aria-label='Authors'>
          <div className='pbs-label'>Authors</div>
          <div className='pbs-tags'>
            {shownAuthors.map((a) => (
              <button key={a.name} type='button' onClick={() => links.library('all', a.name)} aria-label={`${a.name}, ${a.count} ${a.count === 1 ? 'book' : 'books'}. Show their books.`}>
                {a.name}
                {a.count > 1 && <small>{a.count}</small>}
              </button>
            ))}
            {hiddenAuthors > 0 && (
              <button type='button' className='pbs-more-tag' onClick={() => links.route('/authors')} aria-label={`${hiddenAuthors} more authors. Open all authors.`}>
                +{hiddenAuthors}
              </button>
            )}
          </div>
        </section>
      )}

      <Tap className='pbs-card pbs-rate pbs-hint' onTap={() => links.shelf({ kind: 'rated' })} label={`Ratings: ${o.rated} of ${o.total} rated. Show the books by rating.`}>
        <div>
          <div className='pbs-label'>Ratings</div>
          <div className='pbs-sub' style={{ marginTop: 8 }}>
            {o.rated} of {o.total} rated{o.avgRating !== null ? ` · average ${o.avgRating.toFixed(1)}` : ''}
          </div>
        </div>
        <Stars filled={o.avgRating === null ? 0 : Math.round(o.avgRating)} />
      </Tap>
    </div>
  );
}
