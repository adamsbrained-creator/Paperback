'use client';

import clsx from 'clsx';
import { useId, type KeyboardEvent, type ReactNode } from 'react';
import { fmtMin } from '@/services/statistics/format';
import type { MilestoneId } from '@/services/statistics/milestonesStats';

// Small pieces shared by the Stats pages: accent colours, time text, the area chart, the sparkline and stars.

export type Accent = 'blue' | 'yellow' | 'mint' | 'pink';
export const ACCENTS: Accent[] = ['blue', 'yellow', 'mint', 'pink'];
/** The class that sets --ac / --ac-s / --ac-m on an element (see paperback-stats.css). */
export const ac = (a: Accent): string => `pbs-c-${a}`;

/** A steady accent for a book (or anything with a key), so a book keeps its colour on every page. */
export function accentOf(key: string): Accent {
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
  return (['pink', 'yellow', 'blue', 'mint'] as const)[h % 4]!;
}

export { fmtMin };

/** The colour each milestone keeps on the grid, the hero and the tier sheet. */
export const MILESTONE_COLOR: Record<MilestoneId, Accent> = {
  books: 'mint',
  pages: 'blue',
  ses: 'yellow',
  hours: 'pink',
  words: 'yellow',
  rated: 'blue',
  quotes: 'pink',
  streak: 'mint',
  epic: 'pink',
  notes: 'yellow',
};

const f = (n: number) => Math.round(n * 10) / 10;

/** A smooth line through the points that never overshoots (flat tangents at every point). */
export function smoothPath(pts: [number, number][]): string {
  if (pts.length === 0) return '';
  let d = `M${f(pts[0]![0])},${f(pts[0]![1])}`;
  for (let i = 1; i < pts.length; i++) {
    const [x0, y0] = pts[i - 1]!;
    const [x1, y1] = pts[i]!;
    const mx = (x0 + x1) / 2;
    d += ` C${f(mx)},${f(y0)} ${f(mx)},${f(y1)} ${f(x1)},${f(y1)}`;
  }
  return d;
}

interface AreaChartProps {
  values: (number | null)[];
  /** Axis label under each point; most can be empty. */
  labels: string[];
  /** Name of each point, shown in the pill ("Mon", "12 Oct"). */
  names: string[];
  format: (v: number) => string;
  selected: number;
  onSelect: (i: number) => void;
  /** The running point (today / this month), drawn bold on the axis; -1 for none. */
  curIdx: number;
  goal?: number | null;
  goalLabel?: string;
  ariaLabel: string;
}

const W = 322;
const H = 172;
const BASE = 152; // bottom of the filled area
const FLOOR = 136; // where zero sits, a little above the bottom
const TOP = 44; // where the highest value sits (the pill lives above)

/** The hero chart: a filled line with a pill showing the picked point. Tap or hover a point to pick it. */
export function AreaChart({ values, labels, names, format, selected, onSelect, curIdx, goal, goalLabel, ariaLabel }: AreaChartProps) {
  const gid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const n = values.length;
  const padX = n > 14 ? 12 : 23;
  const step = n > 1 ? (W - padX * 2) / (n - 1) : 0;
  const x = (i: number) => (n > 1 ? padX + i * step : W / 2);
  const max = Math.max(1, ...values.map((v) => v ?? 0));
  const axisMax = Math.max(max * 1.08, goal ? goal * 1.15 : 0);
  const y = (v: number) => FLOOR - (Math.min(v, axisMax) / axisMax) * (FLOOR - TOP);

  const pts: [number, number][] = [];
  values.forEach((v, i) => {
    if (v !== null) pts.push([x(i), y(v)]);
  });
  const line = smoothPath(pts);
  const area = pts.length > 1 ? `${line} L${f(pts[pts.length - 1]![0])},${BASE} L${f(pts[0]![0])},${BASE} Z` : '';

  const sv = values[selected] ?? null;
  const sx = x(selected);
  const sy = sv === null ? FLOOR : y(sv);
  const tip = sv === null ? '' : `${names[selected] ?? ''} · ${format(sv)}`;
  const tipW = Math.min(W - 8, 28 + tip.length * 6.4);
  const tipX = Math.max(4, Math.min(W - 4 - tipW, sx - tipW / 2));

  return (
    <svg className='pbs-chart' viewBox={`0 0 ${W} ${H}`} role='img' aria-label={ariaLabel}>
      <defs>
        <linearGradient id={`pbsa${gid}`} x1='0' y1='0' x2='0' y2='1'>
          <stop offset='0' stopColor='var(--blue)' stopOpacity='0.5' />
          <stop offset='1' stopColor='var(--blue)' stopOpacity='0' />
        </linearGradient>
      </defs>
      <g className='pbs-grid'>
        <line x1='0' x2={W} y1={TOP - 6} y2={TOP - 6} />
        <line x1='0' x2={W} y1={(FLOOR + TOP - 6) / 2} y2={(FLOOR + TOP - 6) / 2} />
        <line x1='0' x2={W} y1={FLOOR} y2={FLOOR} />
      </g>
      {goal ? (
        <>
          <line className='pbs-goalline' x1='0' x2={W} y1={y(goal)} y2={y(goal)} />
          {goalLabel && (
            <text className='pbs-goalcap' x={W} y={y(goal) - 5} textAnchor='end'>
              {goalLabel}
            </text>
          )}
        </>
      ) : null}
      {area && <path d={area} fill={`url(#pbsa${gid})`} />}
      {pts.length > 1 && <path d={line} fill='none' stroke='var(--blue)' strokeWidth='3' strokeLinecap='round' strokeLinejoin='round' />}
      {sv !== null && (
        <>
          <line x1={sx} x2={sx} y1={sy} y2={BASE} stroke='var(--muted)' strokeOpacity='0.6' strokeDasharray='3 4' />
          <circle className='pbs-pt' cx={sx} cy={sy} r='6' />
          <rect className='pbs-pill' x={tipX} y='4' width={tipW} height='24' rx='12' />
          <text className='pbs-pilltxt' x={tipX + tipW / 2} y='20' textAnchor='middle'>
            {tip}
          </text>
        </>
      )}
      <g>
        {labels.map((l, i) =>
          l ? (
            <text key={i} className={clsx('pbs-ax', i === curIdx && 'pbs-on')} x={x(i)} y={H - 4} textAnchor='middle'>
              {l}
            </text>
          ) : null,
        )}
      </g>
      {values.map((v, i) =>
        v === null ? null : (
          <rect
            key={i}
            className='pbs-hit'
            x={x(i) - Math.max(step, 14) / 2}
            y='0'
            width={Math.max(step, 14)}
            height={H}
            role='button'
            tabIndex={n <= 12 ? 0 : -1}
            aria-label={`${names[i] ?? ''}: ${format(v)}`}
            onClick={() => onSelect(i)}
            onPointerEnter={(e) => e.pointerType === 'mouse' && onSelect(i)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelect(i);
              }
            }}
          />
        ),
      )}
    </svg>
  );
}

/** The little trend line next to a number. Draws nothing for fewer than two values. */
export function Sparkline({ values, color = 'var(--yellow)' }: { values: number[]; color?: string }) {
  if (values.length < 2) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = Math.max(1, max - min);
  const pts = values.map((v, i) => [(i / (values.length - 1)) * 120 + 4, 60 - ((v - min) / span) * 48] as const);
  const last = pts[pts.length - 1]!;
  return (
    <svg className='pbs-spark' viewBox='0 0 130 70' aria-hidden='true'>
      <polyline points={pts.map(([px, py]) => `${f(px)},${f(py)}`).join(' ')} fill='none' stroke={color} strokeWidth='3' strokeLinecap='round' strokeLinejoin='round' />
      <circle cx={last[0]} cy={last[1]} r='5' fill={color} />
    </svg>
  );
}

const STAR = 'M12 3 14.9 9 21.5 9.8 16.6 14.3 17.9 21 12 17.7 6.1 21 7.4 14.3 2.5 9.8 9.1 9z';

/** Five stars, the first `filled` of them lit. */
export function Stars({ filled }: { filled: number }) {
  return (
    <span className='pbs-stars' role='img' aria-label={`${filled} of 5 stars`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <svg key={i} viewBox='0 0 24 24' className={clsx(i <= filled && 'pbs-on')} aria-hidden='true'>
          <path d={STAR} />
        </svg>
      ))}
    </span>
  );
}

/** A ring with an arc drawn over it: `value` is 0–1. */
export function RingArc({ value, color = 'var(--mint)', size = 104, stroke = 12, children }: { value: number; color?: string; size?: number; stroke?: number; children?: React.ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(1, value));
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} aria-hidden='true'>
      <circle cx={size / 2} cy={size / 2} r={r} fill='none' stroke='var(--track)' strokeWidth={stroke} />
      {v > 0 && (
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill='none'
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap='round'
          strokeDasharray={`${(c * v).toFixed(1)} ${c.toFixed(1)}`}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      )}
      {children}
    </svg>
  );
}

/**
 * Something you can tap: a card, a row, a cover. With no `onTap` it is a plain box, so the same markup
 * serves books that are no longer in the library. Enter and Space work like a click.
 */
export function Tap({
  onTap,
  className,
  label,
  children,
}: {
  onTap?: (() => void) | undefined;
  className?: string | undefined;
  /** Read out instead of the content; leave out when the content already says what it is. */
  label?: string | undefined;
  children: ReactNode;
}) {
  if (!onTap) return <div className={className}>{children}</div>;
  const onKey = (e: KeyboardEvent) => {
    if (e.target !== e.currentTarget) return;
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onTap();
    }
  };
  return (
    <div role='button' tabIndex={0} className={clsx(className, 'pbs-tap')} aria-label={label} onClick={onTap} onKeyDown={onKey}>
      {children}
    </div>
  );
}
