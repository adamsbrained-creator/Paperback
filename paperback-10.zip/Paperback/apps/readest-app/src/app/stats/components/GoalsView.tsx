'use client';

import { useEffect, useMemo, useState } from 'react';
import type { PBook } from '@/services/paperback/library';
import {
  booksPace,
  computeStreaks,
  dayKeyOf,
  formatDuration,
  secondsByDay,
  type StatEventRow,
} from '@/services/statistics/statsAggregate';
import { countFinishedThisYear } from '../useStatsData';
import { DEFAULT_GOALS, loadGoals, normalizeGoals, saveGoals, type Goals } from '../goals';
import { windowSeconds } from '@/services/statistics/shelfStats';
import type { StatsLinks } from '../links';
import { RingArc, Tap, ac, type Accent } from './parts';

interface Props {
  events: StatEventRow[];
  library: PBook[];
  now: Date;
  links: StatsLinks;
}

const FIELDS: { key: keyof Goals; label: string; unit: string }[] = [
  { key: 'booksPerYear', label: 'Books this year', unit: 'books' },
  { key: 'pagesPerDay', label: 'Pages per day', unit: 'pages' },
  { key: 'minutesPerDay', label: 'Minutes per day', unit: 'min' },
  { key: 'streakDays', label: 'Reading streak', unit: 'days' },
];

function Row({ title, value, pct, color }: { title: string; value: string; pct: number; color: Accent }) {
  return (
    <div className={`pbs-card pbs-gcard ${ac(color)}`}>
      <div className='pbs-grow'>
        <b>{title}</b>
        <span>{value}</span>
      </div>
      <div className='pbs-meter'>
        <i style={{ width: `${Math.max(0, Math.min(1, pct)) * 100}%`, minWidth: pct > 0 ? undefined : 0 }} />
      </div>
    </div>
  );
}

/** Reading goals (opened from Activity): the year's books, today's pages and minutes, the streak, and editing them. */
export default function GoalsView({ events, library, now, links }: Props) {
  const [goals, setGoals] = useState<Goals>(DEFAULT_GOALS);
  const [draft, setDraft] = useState<Record<keyof Goals, string> | null>(null);

  useEffect(() => setGoals(loadGoals()), []);

  const today = useMemo(() => {
    const key = dayKeyOf(now);
    const from = Math.floor(new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime() / 1000);
    const todays = events.filter((e) => e.startTime >= from);
    const pages = new Set(todays.map((e) => `${e.md5}:${e.page}`)).size;
    const seconds = secondsByDay(todays).get(key) ?? 0;
    return { pages, seconds };
  }, [events, now]);

  const streaks = useMemo(() => computeStreaks(secondsByDay(events), now), [events, now]);
  const finished = useMemo(() => countFinishedThisYear(library, now), [library, now]);
  const pace = booksPace(finished, goals.booksPerYear, now);
  const booksPct = Math.min(1, finished / goals.booksPerYear);

  const startEdit = () =>
    setDraft({
      booksPerYear: String(goals.booksPerYear),
      pagesPerDay: String(goals.pagesPerDay),
      minutesPerDay: String(goals.minutesPerDay),
      streakDays: String(goals.streakDays),
    });
  const commit = () => {
    if (!draft) return;
    const next = normalizeGoals(draft);
    setGoals(next);
    saveGoals(next);
    setDraft(null);
  };

  return (
    <div className='pbs-col'>
      <Tap
        className='pbs-card pbs-gring pbs-c-mint'
        onTap={
          finished > 0
            ? () =>
                links.shelf({
                  kind: 'done',
                  ...windowSeconds(new Date(now.getFullYear(), 0, 1), new Date(now.getFullYear(), 11, 31)),
                  label: String(now.getFullYear()),
                })
            : undefined
        }
        label={`${finished} of ${goals.booksPerYear} books this year. Show the books.`}
      >
        <RingArc value={booksPct} color='var(--mint)'>
          <text x='52' y='50' textAnchor='middle' fill='var(--text)' fontSize='22' fontWeight='700'>
            {finished}/{goals.booksPerYear}
          </text>
          <text x='52' y='68' textAnchor='middle' fill='var(--muted)' fontSize='11'>
            books
          </text>
        </RingArc>
        <div>
          <h3>{now.getFullYear()} goal</h3>
          <p>{finished >= goals.booksPerYear ? 'Goal reached' : pace.label}</p>
        </div>
      </Tap>

      <Row title='Pages per day' value={`${today.pages} / ${goals.pagesPerDay}`} pct={today.pages / goals.pagesPerDay} color='blue' />
      <Row title='Minutes today' value={`${formatDuration(today.seconds)} / ${goals.minutesPerDay}m`} pct={today.seconds / 60 / goals.minutesPerDay} color='yellow' />
      <Row title='Reading streak' value={`${streaks.current} / ${goals.streakDays} days`} pct={streaks.current / goals.streakDays} color='pink' />
      <Row title='Finish by Dec 31' value={`${Math.round(booksPct * 100)}%`} pct={booksPct} color='mint' />

      {draft ? (
        <div className='pbs-card'>
          {FIELDS.map((f) => (
            <label key={f.key} className='pbs-field'>
              <span>
                <b>{f.label}</b>
                <span>{f.unit}</span>
              </span>
              <input
                className='pbs-input'
                type='number'
                inputMode='numeric'
                min={1}
                value={draft[f.key]}
                onChange={(e) => setDraft({ ...draft, [f.key]: e.target.value })}
              />
            </label>
          ))}
          <div className='pbs-btns'>
            <button type='button' className='pbs-btn' onClick={commit}>
              Save goals
            </button>
            <button type='button' className='pbs-btn pbs-ghost' onClick={() => setDraft(null)}>
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <button type='button' className='pbs-btn' onClick={startEdit}>
          Edit goals
        </button>
      )}
    </div>
  );
}
