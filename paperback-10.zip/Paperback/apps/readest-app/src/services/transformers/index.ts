import type { Transformer } from './types';
import { footnoteTransformer } from './footnote';
import { languageTransformer } from './language';
import { whitespaceTransformer } from './whitespace';
import { sanitizerTransformer } from './sanitizer';
import { styleTransformer } from './style';
import { proofreadTransformer } from './proofread';
import { nbspTransformer } from './nbsp';
import { epubSwitchTransformer } from './epubSwitch';

export const availableTransformers: Transformer[] = [
  epubSwitchTransformer,
  footnoteTransformer,
  languageTransformer,
  styleTransformer,
  whitespaceTransformer,
  sanitizerTransformer,
  nbspTransformer,
  proofreadTransformer,
  // Add more transformers here
];
