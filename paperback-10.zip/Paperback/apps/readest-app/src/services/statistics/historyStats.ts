// Paperback: everything the Stats → History page shows, as pure functions.
// A month calendar of reading days and the sessions of that month, grouped by day.
// No React, no I/O, no Date.now(): `now` is passed in.

import { MONTH_NAMES, WEEKDAY_NAMES } from './activityStats';
import { buildSessions, clampDuration, dayKeyOf, type Session, type StatEventRow } from './statsAggregate';

export interface CalendarDay {
  day: number;
  key: string;
  /** Sessions that started on this day. */
  sessions: number;
  isToday: boolean;
  inFuture: boolean;
}

export interface DayGroup {
  key: string;
  date: Date;
  /** "19 Oct · Monday" */
  label: string;
  sessions: Session[]; // newest first
}

export interface MonthView {
  y: number;
  m: number; // 0–11
  title: string; // "October 2026"
  /** Empty slots before the 1st (Monday first). */
  blanks: number;
  days: CalendarDay[];
  sessionCount: number;
  pageCount: number;
  groups: DayGroup[]; // days with reading, newest first
}

const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

/** The first month with any reading as year*12+month, or the current month when there is none. */
export function firstMonthIndex(events: StatEventRow[], now: Date): number {
  let min = Infinity;
  for (const e of events) if (e.startTime < min) min = e.startTime;
  if (!Number.isFinite(min)) return now.getFullYear() * 12 + now.getMonth();
  const d = new Date(min * 1000);
  return Math.min(d.getFullYear() * 12 + d.getMonth(), now.getFullYear() * 12 + now.getMonth());
}

export function monthView(events: StatEventRow[], y: number, m: number, now: Date): MonthView {
  const today = startOfDay(now);
  const from = Math.floor(new Date(y, m, 1).getTime() / 1000);
  const to = Math.floor(new Date(y, m + 1, 1).getTime() / 1000);
  const inMonth = events.filter((e) => e.startTime >= from && e.startTime < to);
  const sessions = buildSessions(inMonth);

  const pages = new Set<string>();
  for (const e of inMonth) if (clampDuration(e) > 0) pages.add(`${e.md5}:${e.page}`);

  const byKey = new Map<string, Session[]>();
  for (const s of sessions) {
    const key = dayKeyOf(new Date(s.start * 1000));
    const list = byKey.get(key);
    if (list) list.push(s);
    else byKey.set(key, [s]);
  }

  const count = new Date(y, m + 1, 0).getDate();
  const days: CalendarDay[] = [];
  for (let d = 1; d <= count; d++) {
    const date = new Date(y, m, d);
    const key = dayKeyOf(date);
    days.push({
      day: d,
      key,
      sessions: byKey.get(key)?.length ?? 0,
      isToday: date.getTime() === today.getTime(),
      inFuture: date.getTime() > today.getTime(),
    });
  }

  const groups: DayGroup[] = [...byKey.entries()]
    .map(([key, list]) => {
      const [yy, mm, dd] = key.split('-').map(Number);
      const date = new Date(yy!, mm! - 1, dd!);
      return {
        key,
        date,
        label: `${dd} ${MONTH_NAMES[mm! - 1]!.slice(0, 3)} · ${WEEKDAY_NAMES[date.getDay()]}`,
        sessions: [...list].sort((a, b) => b.start - a.start),
      };
    })
    .sort((a, b) => b.date.getTime() - a.date.getTime());

  return {
    y,
    m,
    title: `${MONTH_NAMES[m]} ${y}`,
    blanks: (new Date(y, m, 1).getDay() + 6) % 7,
    days,
    sessionCount: sessions.length,
    pageCount: pages.size,
    groups,
  };
}
