// Paperback: small text helpers shared by the Stats pages and the pure functions behind them.

/** 1h 07m · 42m · 1m (anything above zero shows as at least 1m) · 0m */
export function fmtMin(seconds: number): string {
  const min = seconds > 0 ? Math.max(1, Math.round(seconds / 60)) : 0;
  if (min >= 60) {
    const m = min % 60;
    return m ? `${Math.floor(min / 60)}h ${String(m).padStart(2, '0')}m` : `${Math.floor(min / 60)}h`;
  }
  return `${min}m`;
}
