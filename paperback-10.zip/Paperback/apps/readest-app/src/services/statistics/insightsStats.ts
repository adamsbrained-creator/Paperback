// Paperback: everything the Stats → Insights page shows, as pure functions.
// Patterns and records worked out from the page-read events and the library.
// No React, no I/O, no Date.now(): `now` is passed in.

import { MONTH_SHORT } from './activityStats';
import { isReadingNow, progressFraction, type BookLike } from '@/services/paperback/libraryViews';
import {
  buildSessions,
  clampDuration,
  computeStreaks,
  computeSummary,
  dayKeyOf,
  secondsByDay,
  STREAK_MIN_SECONDS,
  type Session,
  type StatEventRow,
} from './statsAggregate';

const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const addDays = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const sec = (d: Date) => Math.floor(d.getTime() / 1000);

export interface MonthCompare {
  /** Seconds read this calendar month so far, and in the whole previous month. */
  cur: number;
  prev: number;
  curPages: number;
  prevPages: number;
  /** Percent change of this month so far vs the same number of days last month; null without a base. */
  pct: number | null;
  monthName: string;
  prevName: string;
}

/** This month so far, against the same stretch (the first N days) of last month. */
export function monthCompare(events: StatEventRow[], now: Date): MonthCompare {
  const y = now.getFullYear();
  const m = now.getMonth();
  const dayOfMonth = now.getDate();
  const curFrom = sec(new Date(y, m, 1));
  const prevFrom = sec(new Date(y, m - 1, 1));
  const prevDays = new Date(y, m, 0).getDate();
  const prevTo = sec(new Date(y, m - 1, Math.min(dayOfMonth, prevDays) + 1));
  const cur = events.filter((e) => e.startTime >= curFrom);
  const prev = events.filter((e) => e.startTime >= prevFrom && e.startTime < prevTo);
  const a = computeSummary(cur);
  const b = computeSummary(prev);
  return {
    cur: a.seconds,
    prev: b.seconds,
    curPages: a.pages,
    prevPages: b.pages,
    pct: b.seconds > 0 ? Math.round(((a.seconds - b.seconds) / b.seconds) * 100) : null,
    monthName: new Date(y, m, 1).toLocaleString('en-US', { month: 'long' }),
    prevName: new Date(y, m - 1, 1).toLocaleString('en-US', { month: 'long' }),
  };
}

export interface Consistency {
  activeDays: number;
  of: number;
  pct: number; // 0–1
  streak: number;
  longestStreak: number;
}

/** On how many of the last 30 days did you read (at least a minute)? */
export function consistency(events: StatEventRow[], now: Date, days = 30): Consistency {
  const byDay = secondsByDay(events);
  const today = startOfDay(now);
  let active = 0;
  for (let i = 0; i < days; i++) if ((byDay.get(dayKeyOf(addDays(today, -i))) ?? 0) >= STREAK_MIN_SECONDS) active++;
  const st = computeStreaks(byDay, now);
  return { activeDays: active, of: days, pct: active / days, streak: st.current, longestStreak: st.longest };
}

export interface SpeedMonth {
  label: string; // "May"
  pace: number; // pages per hour, 0 when nothing was read
}

export interface Speed {
  /** Pages per hour over the last 60 days (0 when there is too little reading). */
  current: number;
  months: SpeedMonth[]; // the last six months, oldest first
  best: SpeedMonth | null;
}

export function readingSpeed(events: StatEventRow[], now: Date): Speed {
  const months: SpeedMonth[] = [];
  for (let i = 5; i >= 0; i--) {
    const from = sec(new Date(now.getFullYear(), now.getMonth() - i, 1));
    const to = sec(new Date(now.getFullYear(), now.getMonth() - i + 1, 1));
    const s = computeSummary(events.filter((e) => e.startTime >= from && e.startTime < to));
    // A month with under ten minutes of reading says nothing about speed.
    months.push({
      label: MONTH_SHORT[new Date(now.getFullYear(), now.getMonth() - i, 1).getMonth()]!,
      pace: s.seconds >= 600 ? s.pagesPerHour : 0,
    });
  }
  const recent = computeSummary(events.filter((e) => e.startTime >= sec(addDays(startOfDay(now), -59))));
  let best: SpeedMonth | null = null;
  for (const m of months) if (m.pace > 0 && (!best || m.pace > best.pace)) best = m;
  return { current: recent.seconds >= 600 ? recent.pagesPerHour : 0, months, best };
}

export interface Records {
  bestDay: { date: Date; seconds: number } | null;
  longestSession: Session | null;
  /** The best Monday-to-Sunday week by time read. */
  bestWeek: { start: Date; seconds: number } | null;
  mostPages: { date: Date; pages: number } | null;
}

export function readingRecords(events: StatEventRow[]): Records {
  const byDay = new Map<string, { seconds: number; pages: Set<string> }>();
  for (const e of events) {
    const dur = clampDuration(e);
    if (dur <= 0) continue;
    const key = dayKeyOf(new Date(e.startTime * 1000));
    let d = byDay.get(key);
    if (!d) {
      d = { seconds: 0, pages: new Set() };
      byDay.set(key, d);
    }
    d.seconds += dur;
    d.pages.add(`${e.md5}:${e.page}`);
  }
  const dateOf = (key: string) => {
    const [y, m, d] = key.split('-').map(Number);
    return new Date(y!, m! - 1, d!);
  };

  let bestDay: Records['bestDay'] = null;
  let mostPages: Records['mostPages'] = null;
  const weeks = new Map<number, number>();
  for (const [key, d] of byDay) {
    const date = dateOf(key);
    if (!bestDay || d.seconds > bestDay.seconds) bestDay = { date, seconds: d.seconds };
    if (!mostPages || d.pages.size > mostPages.pages) mostPages = { date, pages: d.pages.size };
    const monday = addDays(date, -((date.getDay() + 6) % 7)).getTime();
    weeks.set(monday, (weeks.get(monday) ?? 0) + d.seconds);
  }
  let bestWeek: Records['bestWeek'] = null;
  for (const [t, seconds] of weeks) if (!bestWeek || seconds > bestWeek.seconds) bestWeek = { start: new Date(t), seconds };

  let longestSession: Session | null = null;
  for (const s of buildSessions(events)) if (!longestSession || s.seconds > longestSession.seconds) longestSession = s;

  return { bestDay, longestSession, bestWeek, mostPages };
}

export interface ForecastRow {
  hash: string;
  title: string;
  pagesLeft: number;
  /** Reading time left at your pace, in seconds. */
  secondsLeft: number;
  /** Days until you finish at your recent pace of reading days; null when that cannot be told. */
  days: number | null;
}

/** For the books in progress: how long is left, and about when you would finish. */
export function finishForecast(
  library: (BookLike & { source?: unknown })[],
  events: StatEventRow[],
  now: Date,
  limit = 4,
): ForecastRow[] {
  const from = sec(addDays(startOfDay(now), -59));
  const recent = events.filter((e) => e.startTime >= from);
  const overall = computeSummary(recent);
  const pace = overall.seconds >= 600 ? overall.pagesPerHour : 0;

  // Seconds read on an average day you read, in the last 30 days.
  const byDay = secondsByDay(events);
  const today = startOfDay(now);
  let total = 0;
  let active = 0;
  for (let i = 0; i < 30; i++) {
    const s = byDay.get(dayKeyOf(addDays(today, -i))) ?? 0;
    if (s >= STREAK_MIN_SECONDS) {
      total += s;
      active++;
    }
  }
  const perDay = active ? total / active : 0;
  const daysActive = active / 30; // share of days you read at all

  const rows: ForecastRow[] = [];
  for (const b of library) {
    if (b.deletedAt || !isReadingNow(b)) continue;
    const p = b.progress;
    if (!p || !(p[1] > 0) || progressFraction(b) <= 0) continue;
    const pagesLeft = p[1] - p[0];
    if (pagesLeft <= 0) continue;
    // Prefer the pace on this very book once it has enough reading, else the overall one.
    const own = computeSummary(events.filter((e) => e.md5 === b.hash));
    const bookPace = own.seconds >= 600 ? own.pagesPerHour : pace;
    if (bookPace <= 0) continue;
    const secondsLeft = Math.round((pagesLeft / bookPace) * 3600);
    const readingDays = perDay > 0 ? Math.ceil(secondsLeft / perDay) : null;
    rows.push({
      hash: b.hash,
      title: b.title,
      pagesLeft,
      secondsLeft,
      days: readingDays !== null && daysActive > 0 ? Math.max(1, Math.ceil(readingDays / daysActive)) : null,
    });
  }
  return rows.sort((a, b) => a.secondsLeft - b.secondsLeft).slice(0, limit);
}

/** "about 5 days" · "about 3 weeks" · "about 2 months" */
export function inDaysText(days: number): string {
  if (days <= 1) return 'about a day';
  if (days < 21) return `about ${days} days`;
  if (days < 70) return `about ${Math.round(days / 7)} weeks`;
  return `about ${Math.round(days / 30)} months`;
}

export interface YearPace {
  finished: number;
  goal: number;
  /** Books a straight line through the year would have by today. */
  expected: number;
  /** Where the year ends up at this rate. */
  projected: number;
  /** 0–1 of the year that has passed. */
  elapsed: number;
}

export function yearPace(finished: number, goal: number, now: Date): YearPace {
  const start = new Date(now.getFullYear(), 0, 1).getTime();
  const end = new Date(now.getFullYear() + 1, 0, 1).getTime();
  const elapsed = Math.max(0.0001, Math.min(1, (now.getTime() - start) / (end - start)));
  return {
    finished,
    goal,
    expected: Math.floor(goal * elapsed),
    projected: elapsed < 0.04 ? finished : Math.round(finished / elapsed),
    elapsed,
  };
}
