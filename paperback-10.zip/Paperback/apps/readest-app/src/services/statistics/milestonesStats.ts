// Paperback: everything the Stats → Milestones page shows, as pure functions.
// Lifetime achievements: ten counters with five tiers each, a "next up" pick, and a timeline of when things happened.
// No React, no I/O, no Date.now(): `now` is passed in.

import {
  STREAK_MIN_SECONDS,
  buildSessions,
  clampDuration,
  computeStreaks,
  dayKeyOf,
  secondsByDay,
  type StatEventRow,
} from './statsAggregate';

export type MilestoneId =
  | 'books'
  | 'pages'
  | 'ses'
  | 'hours'
  | 'words'
  | 'rated'
  | 'quotes'
  | 'streak'
  | 'epic'
  | 'notes';

export type MilestoneIcon =
  | 'book'
  | 'page'
  | 'clock'
  | 'timer'
  | 'mark'
  | 'star'
  | 'quote'
  | 'flame'
  | 'stack'
  | 'note';

export type TimelineKind = 'book' | 'read' | 'note';

/** The slice of a Paperback book this page reads. */
export interface MBook {
  hash: string;
  title: string;
  deletedAt?: number | null | undefined;
  readingStatus?: string | undefined;
  readingStatusUpdatedAt?: number | undefined;
  createdAt?: number | undefined; // ms
  updatedAt?: number | undefined; // ms
}

/** The slice of a note / highlight row this page reads (see notesViews.NoteRow). */
export interface MNote {
  bookTitle: string;
  kind: 'highlight' | 'note' | 'bookmark';
  at: number; // ms
}

export interface MilestoneInput {
  events: StatEventRow[];
  books: MBook[];
  notes: MNote[];
  savedWords: { word: string; addedAt: number }[];
  ratings: Record<string, number>;
  now: Date;
}

export interface Milestone {
  id: MilestoneId;
  name: string;
  /** Shorter name for the small cards. */
  short?: string;
  icon: MilestoneIcon;
  kind: TimelineKind;
  value: number;
  tiers: number[];
  unit: string;
  /** For each tier: when it was unlocked (ms), or null when not unlocked or the date is unknown. */
  dates: (number | null)[];
  /** How many tiers are unlocked. */
  unlocked: number;
  /** The next tier's target, or null when every tier is unlocked. */
  next: number | null;
  /** 0–100: progress from the last unlocked tier to the next one. */
  pct: number;
  /** Units gained in the last 90 days (for the "about N days" estimate), or null when it cannot be known. */
  recent: number | null;
}

export type Part = { t: string; b?: true };

export interface TimelineEvent {
  key: string;
  kind: TimelineKind;
  icon: MilestoneIcon | 'trophy' | 'done' | 'plus';
  title: string;
  at: number; // ms
  sub: Part[];
  /** The book the event is about, when it has one (for opening it). */
  bookHash?: string;
}

const DAY = 864e5;
export const RECENT_DAYS = 90;
/** An epic book has at least this many pages. */
export const EPIC_PAGES = 500;
export const ADDED_TIERS = [10, 25, 50, 100, 250];

const TIERS: Record<MilestoneId, number[]> = {
  books: [10, 25, 50, 100, 250],
  pages: [1000, 5000, 10000, 25000, 50000],
  ses: [25, 100, 500, 1000, 2500],
  hours: [50, 100, 250, 500, 1000],
  words: [10, 50, 100, 250, 500],
  rated: [5, 10, 25, 50, 100],
  quotes: [10, 50, 100, 250, 500],
  streak: [7, 14, 30, 60, 100],
  epic: [3, 5, 10, 25, 50],
  notes: [1, 5, 10, 25, 50],
};

export const commas = (n: number): string => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

/** 1,234 → "1.2K", 6277 → "6.3K", 25000 → "25K", 950 → "950". */
export function shortNum(n: number): string {
  if (n >= 1000) {
    const x = n / 1000;
    return `${x >= 10 || x % 1 === 0 ? Math.round(x) : x.toFixed(1)}K`;
  }
  return String(n);
}

const ordinal = (n: number): string => {
  const v = n % 100;
  const s = ['th', 'st', 'nd', 'rd'];
  return `${commas(n)}${s[(v - 20) % 10] ?? s[v] ?? s[0]}`;
};

const isLive = (b: MBook) => !b.deletedAt;
const finishedAt = (b: MBook) => b.readingStatusUpdatedAt ?? b.updatedAt ?? 0;

/** ms of `startTime` seconds; 0 and below mean "unknown". */
const ms = (sec: number) => sec * 1000;
const known = (t: number | undefined): number | null => (t && t > 0 ? t : null);

/** Dates of the tiers a sorted list of times has reached: tier t is the time of the t-th item. */
function datesFromTimes(times: number[], tiers: number[]): (number | null)[] {
  return tiers.map((t) => (times.length >= t ? known(times[t - 1]) : null));
}

interface Reached {
  value: number;
  dates: (number | null)[];
  recent: number | null;
}

function build(
  id: MilestoneId,
  meta: Pick<Milestone, 'name' | 'icon' | 'kind' | 'unit'> & { short?: string },
  r: Reached,
): Milestone {
  const tiers = TIERS[id];
  const unlocked = tiers.filter((t) => r.value >= t).length;
  const next = unlocked < tiers.length ? tiers[unlocked]! : null;
  const prev = unlocked > 0 ? tiers[unlocked - 1]! : 0;
  const pct = next ? Math.max(0, Math.min(100, ((r.value - prev) / (next - prev)) * 100)) : 100;
  const dates = tiers.map((_, i) => (i < unlocked ? (r.dates[i] ?? null) : null));
  return { id, ...meta, value: r.value, tiers, dates, unlocked, next, pct, recent: r.recent };
}

/** Pages of a book as the reader counted them while reading (the biggest total seen in its page events). */
export function bookPageCounts(events: StatEventRow[]): Map<string, number> {
  const out = new Map<string, number>();
  for (const e of events) {
    if (e.totalPages > (out.get(e.md5) ?? 0)) out.set(e.md5, e.totalPages);
  }
  return out;
}

/** For each day with reading (oldest first): the day's start (ms) and its number of distinct pages. */
function pagesPerDay(events: StatEventRow[]): { at: number; pages: number }[] {
  const days = new Map<string, { at: number; set: Set<string> }>();
  for (const e of events) {
    if (clampDuration(e) <= 0) continue;
    const d = new Date(e.startTime * 1000);
    const key = dayKeyOf(d);
    let day = days.get(key);
    if (!day) {
      day = { at: new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(), set: new Set() };
      days.set(key, day);
    }
    day.set.add(`${e.md5}:${e.page}`);
  }
  return [...days.values()].sort((a, b) => a.at - b.at).map((d) => ({ at: d.at, pages: d.set.size }));
}

/** The day each streak length was first reached (index = length, so [7] is the day a 7-day streak first happened). */
function streakReach(byDay: Map<string, number>, lengths: number[]): Map<number, number> {
  const days = [...byDay.entries()]
    .filter(([, s]) => s >= STREAK_MIN_SECONDS)
    .map(([k]) => {
      const [y, m, d] = k.split('-').map(Number);
      return new Date(y!, m! - 1, d!);
    })
    .sort((a, b) => a.getTime() - b.getTime());
  const reach = new Map<number, number>();
  let run = 0;
  let prev: Date | null = null;
  for (const d of days) {
    const next = prev ? new Date(prev.getFullYear(), prev.getMonth(), prev.getDate() + 1) : null;
    run = next && dayKeyOf(next) === dayKeyOf(d) ? run + 1 : 1;
    for (const t of lengths) if (run >= t && !reach.has(t)) reach.set(t, d.getTime());
    prev = d;
  }
  return reach;
}

export function buildMilestones(input: MilestoneInput): Milestone[] {
  const { events, books, notes, savedWords, ratings, now } = input;
  const cutoff = now.getTime() - RECENT_DAYS * DAY;
  const since = (times: number[]) => times.filter((t) => t >= cutoff).length;

  const live = books.filter(isLive);
  const finished = live
    .filter((b) => b.readingStatus === 'finished')
    .map((b) => ({ b, at: finishedAt(b) }))
    .sort((a, b) => a.at - b.at);
  const finishTimes = finished.map((f) => f.at);

  // pages, hours, sessions, streak: from the page-read events
  const perDay = pagesPerDay(events);
  const totalPages = perDay.reduce((n, d) => n + d.pages, 0);
  const pageDates = TIERS.pages.map((t) => {
    let sum = 0;
    for (const d of perDay) {
      sum += d.pages;
      if (sum >= t) return known(d.at);
    }
    return null;
  });
  const recentPages = perDay.filter((d) => d.at >= cutoff).reduce((n, d) => n + d.pages, 0);

  const sorted = [...events].sort((a, b) => a.startTime - b.startTime);
  let totalSec = 0;
  const hourDates: (number | null)[] = TIERS.hours.map(() => null);
  for (const e of sorted) {
    totalSec += clampDuration(e);
    TIERS.hours.forEach((t, i) => {
      if (hourDates[i] === null && totalSec >= t * 3600) hourDates[i] = known(ms(e.startTime));
    });
  }
  const recentSec = sorted.filter((e) => ms(e.startTime) >= cutoff).reduce((n, e) => n + clampDuration(e), 0);

  const sessionTimes = buildSessions(events).map((s) => ms(s.start));

  const byDay = secondsByDay(events);
  const longest = computeStreaks(byDay, now).longest;
  const reach = streakReach(byDay, TIERS.streak);

  // epic books: finished books whose page count (as the reader counted it) is at least EPIC_PAGES
  const pageCounts = bookPageCounts(events);
  const epic = finished.filter((f) => (pageCounts.get(f.b.hash) ?? 0) >= EPIC_PAGES);
  const epicTimes = epic.map((f) => f.at);

  // words, ratings, quotes, notes
  const wordTimes = savedWords.map((w) => w.addedAt).sort((a, b) => a - b);
  const liveHashes = new Set(live.map((b) => b.hash));
  const rated = Object.keys(ratings).filter((h) => liveHashes.has(h)).length;
  const quoteTimes = notes.filter((n) => n.kind !== 'bookmark').map((n) => n.at).sort((a, b) => a - b);
  const noteTimes = notes.filter((n) => n.kind === 'note').map((n) => n.at).sort((a, b) => a - b);

  return [
    build('books', { name: 'Books Read', icon: 'book', kind: 'book', unit: 'books' }, {
      value: finished.length,
      dates: datesFromTimes(finishTimes, TIERS.books),
      recent: since(finishTimes),
    }),
    build('pages', { name: 'Pages Read', icon: 'page', kind: 'read', unit: 'pages' }, {
      value: totalPages,
      dates: pageDates,
      recent: recentPages,
    }),
    build('ses', { name: 'Reading Sessions', icon: 'clock', kind: 'read', unit: 'sessions' }, {
      value: sessionTimes.length,
      dates: datesFromTimes(sessionTimes, TIERS.ses),
      recent: since(sessionTimes),
    }),
    build('hours', { name: 'Reading Hours', icon: 'timer', kind: 'read', unit: 'hours' }, {
      value: Math.floor(totalSec / 3600),
      dates: hourDates,
      recent: recentSec / 3600,
    }),
    build('words', { name: 'Words Saved', icon: 'mark', kind: 'note', unit: 'words' }, {
      value: wordTimes.length,
      dates: datesFromTimes(wordTimes, TIERS.words),
      recent: since(wordTimes),
    }),
    build('rated', { name: 'Books Rated', icon: 'star', kind: 'note', unit: 'books' }, {
      value: rated,
      dates: TIERS.rated.map(() => null), // ratings are saved without a date
      recent: null,
    }),
    build('quotes', { name: 'Quotes Saved', icon: 'quote', kind: 'note', unit: 'quotes' }, {
      value: quoteTimes.length,
      dates: datesFromTimes(quoteTimes, TIERS.quotes),
      recent: since(quoteTimes),
    }),
    build('streak', { name: 'Longest Streak', icon: 'flame', kind: 'read', unit: 'days' }, {
      value: longest,
      dates: TIERS.streak.map((t) => reach.get(t) ?? null),
      recent: null,
    }),
    build('epic', { name: 'Epic Books (500+ pages)', short: 'Epic Books', icon: 'stack', kind: 'book', unit: 'books' }, {
      value: epic.length,
      dates: datesFromTimes(epicTimes, TIERS.epic),
      recent: since(epicTimes),
    }),
    build('notes', { name: 'Notes Written', icon: 'note', kind: 'note', unit: 'notes' }, {
      value: noteTimes.length,
      dates: datesFromTimes(noteTimes, TIERS.notes),
      recent: since(noteTimes),
    }),
  ];
}

export const tiersUnlocked = (ms_: Milestone[]) => ({
  done: ms_.reduce((n, m) => n + m.unlocked, 0),
  total: ms_.reduce((n, m) => n + m.tiers.length, 0),
});

// ---- next up ------------------------------------------------------------------------------

export interface NextUp {
  milestone: Milestone;
  tier: number; // 1-based number of the tier being worked on
  need: number;
  target: number;
  /** Rough days until it is reached at the last 90 days' pace; null when there is no recent pace. */
  days: number | null;
}

/** The milestone closest to its next tier (the biggest share of the way there). */
export function pickNextUp(list: Milestone[]): NextUp | null {
  let best: Milestone | null = null;
  for (const m of list) {
    if (m.next === null) continue;
    if (!best || m.pct > best.pct) best = m;
  }
  if (!best || best.next === null) return null;
  const need = best.next - best.value;
  const perDay = best.recent && best.recent > 0 ? best.recent / RECENT_DAYS : 0;
  return {
    milestone: best,
    tier: best.unlocked + 1,
    need,
    target: best.next,
    days: perDay > 0 ? Math.max(1, Math.ceil(need / perDay)) : null,
  };
}

/** "about 24 days" · "about 6 weeks" · "about 5 months". */
export function etaText(days: number): string {
  if (days < 21) return `about ${days} ${days === 1 ? 'day' : 'days'}`;
  if (days < 70) return `about ${Math.round(days / 7)} weeks`;
  const months = Math.round(days / 30);
  return months >= 24 ? 'over 2 years' : `about ${months} months`;
}

/** What the next-up card says after "until": "25 Books Read", "a 30-day streak". */
export function goalText(m: Milestone, n: number): string {
  switch (m.id) {
    case 'books':
      return `${commas(n)} Books Read`;
    case 'streak':
      return `a ${n}-day streak`;
    case 'notes':
      return n === 1 ? 'your first note' : `${commas(n)} Notes Written`;
    default:
      return tierTitle(m, n);
  }
}

// ---- timeline -----------------------------------------------------------------------------

export function tierTitle(m: Milestone, n: number): string {
  switch (m.id) {
    case 'books':
      return `${commas(n)} Books Finished`;
    case 'pages':
      return `${commas(n)} Pages Read`;
    case 'ses':
      return `${commas(n)} Reading Sessions`;
    case 'hours':
      return `${commas(n)} Reading Hours`;
    case 'words':
      return `${commas(n)} Words Saved`;
    case 'rated':
      return `${commas(n)} Books Rated`;
    case 'quotes':
      return `${commas(n)} Quotes Saved`;
    case 'streak':
      return `${n}-Day Reading Streak`;
    case 'epic':
      return `${commas(n)} Epic Books`;
    case 'notes':
      return n === 1 ? 'First Reading Note' : `${commas(n)} Notes Written`;
  }
}

/** "2 days and 2 hours of reading" (from 24 hours), else "12 hours of reading". */
export function hoursText(hours: number): string {
  if (hours < 24) return `${hours} ${hours === 1 ? 'hour' : 'hours'} of reading`;
  const d = Math.floor(hours / 24);
  const h = hours % 24;
  const days = `${d} ${d === 1 ? 'day' : 'days'}`;
  return h ? `${days} and ${h} ${h === 1 ? 'hour' : 'hours'} of reading` : `${days} of reading`;
}

const q = (title: string) => `“${title}”`;

export function buildTimeline(input: MilestoneInput, list: Milestone[]): TimelineEvent[] {
  const { books, notes, savedWords } = input;
  const live = books.filter(isLive);
  const finished = live
    .filter((b) => b.readingStatus === 'finished')
    .map((b) => ({ b, at: finishedAt(b) }))
    .sort((a, b) => a.at - b.at);
  const pageCounts = bookPageCounts(input.events);
  const quotes = notes.filter((n) => n.kind !== 'bookmark').sort((a, b) => a.at - b.at);
  const written = notes.filter((n) => n.kind === 'note').sort((a, b) => a.at - b.at);
  const words = [...savedWords].sort((a, b) => a.addedAt - b.addedAt);
  const added = live
    .map((b) => ({ b, at: b.createdAt ?? 0 }))
    .sort((a, b) => a.at - b.at);

  const hashOfTitle = (title?: string): string | undefined => (title ? live.find((b) => b.title === title)?.hash : undefined);
  const withBook = (hash?: string): { bookHash?: string } => (hash ? { bookHash: hash } : {});

  const out: TimelineEvent[] = [];
  const push = (e: Omit<TimelineEvent, 'key'> & { key?: string }) => {
    if (e.at > 0) out.push({ ...e, key: e.key ?? `${e.title}@${e.at}` });
  };

  // tier unlocks
  for (const m of list) {
    m.dates.forEach((at, i) => {
      if (at === null) return;
      const n = m.tiers[i]!;
      let sub: Part[] = [];
      let icon: TimelineEvent['icon'] = m.icon;
      let bookHash: string | undefined;
      switch (m.id) {
        case 'books':
          icon = 'done';
          sub = [{ t: 'Finished ' }, { t: q(finished[n - 1]?.b.title ?? ''), b: true }];
          bookHash = finished[n - 1]?.b.hash;
          break;
        case 'pages':
          sub = [{ t: 'Across all your books' }];
          break;
        case 'ses':
          sub = [{ t: 'Your ' }, { t: ordinal(n), b: true }, { t: ' time sitting down with a book' }];
          break;
        case 'hours':
          sub = [{ t: hoursText(n) }];
          break;
        case 'words':
          sub = [{ t: 'Latest: ' }, { t: words[n - 1]?.word ?? '', b: true }];
          break;
        case 'quotes':
          sub = [{ t: 'Latest from ' }, { t: quotes[n - 1]?.bookTitle ?? '', b: true }];
          bookHash = hashOfTitle(quotes[n - 1]?.bookTitle);
          break;
        case 'streak':
          sub = [{ t: `${n} days without a missed day` }];
          break;
        case 'epic':
          sub = [{ t: `${n} books of ${EPIC_PAGES}+ pages` }];
          break;
        case 'notes':
          sub = n === 1 ? [{ t: written[0]?.bookTitle ?? '', b: true }] : [{ t: 'Latest on ' }, { t: written[n - 1]?.bookTitle ?? '', b: true }];
          bookHash = hashOfTitle(written[n - 1]?.bookTitle ?? written[0]?.bookTitle);
          break;
        default:
          break;
      }
      push({ key: `${m.id}:${n}`, kind: m.kind, icon, title: tierTitle(m, n), at, sub, ...withBook(bookHash) });
    });
  }

  // books added
  ADDED_TIERS.forEach((n) => {
    const a = added[n - 1];
    if (a) push({ key: `added:${n}`, kind: 'book', icon: 'trophy', title: `${commas(n)} Books Added`, at: a.at, sub: [{ t: 'Milestone reached with ' }, { t: q(a.b.title), b: true }], ...withBook(a.b.hash) });
  });

  // firsts
  if (added[0]) push({ key: 'first-added', kind: 'book', icon: 'plus', title: 'First Book Added', at: added[0].at, sub: [{ t: added[0].b.title, b: true }], ...withBook(added[0].b.hash) });
  if (finished[0]) push({ key: 'first-finished', kind: 'book', icon: 'done', title: 'First Book Finished', at: finished[0].at, sub: [{ t: finished[0].b.title, b: true }], ...withBook(finished[0].b.hash) });
  if (quotes[0]) push({ key: 'first-quote', kind: 'note', icon: 'quote', title: 'First Saved Quote', at: quotes[0].at, sub: [{ t: quotes[0].bookTitle, b: true }], ...withBook(hashOfTitle(quotes[0].bookTitle)) });

  // the longest finished book (pages as counted by the reader)
  let longest: { b: MBook; at: number; pages: number } | null = null;
  for (const f of finished) {
    const pages = pageCounts.get(f.b.hash) ?? 0;
    if (pages > 0 && (!longest || pages > longest.pages)) longest = { ...f, pages };
  }
  if (longest) {
    push({
      key: 'longest-book',
      kind: 'book',
      icon: 'stack',
      title: 'Longest Book Read',
      at: longest.at,
      sub: [{ t: longest.b.title, b: true }, { t: ` (${commas(longest.pages)} pages)` }],
      ...withBook(longest.b.hash),
    });
  }

  return out.sort((a, b) => b.at - a.at || a.key.localeCompare(b.key));
}

/** "October" for this year, "May 2025" for earlier years. */
export function monthHeading(at: number, now: Date): string {
  const d = new Date(at);
  const name = d.toLocaleString('en-US', { month: 'long' });
  return d.getFullYear() === now.getFullYear() ? name : `${name} ${d.getFullYear()}`;
}

/** "8 Oct", or "8 Oct 2025" for earlier years. */
export function shortDate(at: number, now: Date): string {
  const d = new Date(at);
  const base = `${d.getDate()} ${d.toLocaleString('en-US', { month: 'short' })}`;
  return d.getFullYear() === now.getFullYear() ? base : `${base} ${d.getFullYear()}`;
}
