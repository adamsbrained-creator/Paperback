// Paperback: everything the Stats → Books page shows, as pure functions over the library list.
// No React, no I/O.

import {
  isReadingNow,
  progressFraction,
  type BookLike,
} from '@/services/paperback/libraryViews';
import { bookPageCounts } from './milestonesStats';
import type { StatEventRow } from './statsAggregate';

export interface StatsBook extends BookLike {
  language?: string;
  createdAt?: number;
}

export interface ProgressRow {
  hash: string;
  title: string;
  pct: number; // 0–100
}

export interface AuthorChip {
  name: string;
  count: number;
}

export interface BooksOverview {
  total: number;
  finished: number;
  reading: number;
  /** Pages of the longest finished book, as counted while reading (or the book's own total). */
  longest: { hash: string; title: string; pages: number } | null;
  languages: string[]; // display names
  progress: ProgressRow[]; // books being read, furthest along first
  authors: AuthorChip[];
  rated: number;
  /** Average of the ratings of live books, or null when none is rated. */
  avgRating: number | null;
  /** The newest few books, for the covers on the Library card. */
  recent: StatsBook[];
}

export const languageName = (code: string): string => {
  const base = code.trim().toLowerCase().split(/[-_]/)[0] ?? '';
  if (!base) return '';
  try {
    return new Intl.DisplayNames(['en'], { type: 'language' }).of(base) ?? base;
  } catch {
    return base;
  }
};

/** "Neil Gaiman; Terry Pratchett" and "A & B" count as two authors. */
export const splitAuthors = (raw: string): string[] =>
  raw
    .split(/;|\s&\s|\sand\s/i)
    .map((a) => a.trim())
    .filter(Boolean);

export function booksOverview(
  library: StatsBook[],
  events: StatEventRow[],
  ratings: Record<string, number>,
): BooksOverview {
  const live = library.filter((b) => !b.deletedAt);
  const finishedBooks = live.filter((b) => b.readingStatus === 'finished');
  const readingBooks = live.filter(isReadingNow);

  const counts = bookPageCounts(events);
  let longest: BooksOverview['longest'] = null;
  for (const b of finishedBooks) {
    const pages = Math.max(counts.get(b.hash) ?? 0, b.progress?.[1] ?? 0);
    if (pages > 0 && (!longest || pages > longest.pages)) longest = { hash: b.hash, title: b.title, pages };
  }

  const langs = new Set<string>();
  for (const b of live) {
    const name = languageName(b.language ?? '');
    if (name) langs.add(name);
  }

  const progress = readingBooks
    .map((b) => ({ hash: b.hash, title: b.title, pct: Math.round(progressFraction(b) * 100) }))
    .sort((a, b) => b.pct - a.pct);

  const byAuthor = new Map<string, number>();
  for (const b of live) {
    for (const a of splitAuthors(b.author || '')) byAuthor.set(a, (byAuthor.get(a) ?? 0) + 1);
  }
  const authors = [...byAuthor.entries()]
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));

  const liveHashes = new Set(live.map((b) => b.hash));
  const rated = Object.entries(ratings).filter(([h, v]) => liveHashes.has(h) && v >= 1 && v <= 5);
  const avgRating = rated.length ? rated.reduce((s, [, v]) => s + v, 0) / rated.length : null;

  const recent = [...live].sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0)).slice(0, 3);

  return {
    total: live.length,
    finished: finishedBooks.length,
    reading: readingBooks.length,
    longest,
    languages: [...langs].sort(),
    progress,
    authors,
    rated: rated.length,
    avgRating,
    recent,
  };
}
