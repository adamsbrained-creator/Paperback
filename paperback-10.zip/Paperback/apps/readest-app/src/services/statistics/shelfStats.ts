// Paperback: the "shelf" screens opened from Stats — a list of the books behind a number.
// "Most read · October", "Finished in 2026", "Languages", "Ratings", "Epic books".
// Pure functions: no React, no I/O, no Date.now() (`now` is passed in).
//
// A shelf is described by a small ShelfSpec that fits in the address bar (?tab=shelf&s=read&from=…&to=…),
// so Back from a book returns to the same shelf.

import { isReadingNow, progressPercent, type BookLike } from '@/services/paperback/libraryViews';
import { languageName } from './booksStats';
import { fmtMin } from './format';
import { EPIC_PAGES, bookPageCounts, shortDate } from './milestonesStats';
import { buildSessions, clampDuration, type StatEventRow } from './statsAggregate';

export type ShelfKind = 'read' | 'done' | 'langs' | 'rated' | 'epic';

export interface ShelfSpec {
  kind: ShelfKind;
  /** The window for 'read' and 'done': from (included) to (excluded), in Unix seconds. */
  from?: number;
  to?: number;
  /** What the window is called: "October", "2026", "last 7 days". */
  label?: string;
}

export interface ShelfBook {
  hash: string;
  title: string;
  author: string;
  /** The small line under the cover. */
  meta: string;
  /** The pill on the cover: "42%", "4★". */
  badge?: string;
  /** False when the book is no longer in the library (only reading history remains). */
  inLibrary: boolean;
}

export interface ShelfSection {
  title?: string;
  books: ShelfBook[];
}

export interface ShelfView {
  title: string;
  sub: string;
  sections: ShelfSection[];
  /** Number of books in all sections. */
  total: number;
  /** Shown when there is nothing on the shelf. */
  empty: string;
}

export interface ShelfInput {
  library: (BookLike & { language?: string })[];
  events: StatEventRow[];
  ratings: Record<string, number>;
  now: Date;
}

const books = (n: number) => `${n} ${n === 1 ? 'book' : 'books'}`;
const stamp = (b: BookLike): number => b.readingStatusUpdatedAt ?? b.updatedAt ?? 0;

/** A window of whole days as Unix seconds: the first day's start up to the end of the last day. */
export function windowSeconds(firstDay: Date, lastDay: Date): { from: number; to: number } {
  const from = new Date(firstDay.getFullYear(), firstDay.getMonth(), firstDay.getDate()).getTime();
  const to = new Date(lastDay.getFullYear(), lastDay.getMonth(), lastDay.getDate() + 1).getTime();
  return { from: Math.floor(from / 1000), to: Math.floor(to / 1000) };
}

const PAGES = (n: number) => `${n} ${n === 1 ? 'page' : 'pages'}`;

function statusMeta(b: BookLike): string {
  if (b.readingStatus === 'finished') return 'Finished';
  return isReadingNow(b) ? `${progressPercent(b)}% read` : 'Not started';
}

export function buildShelf(spec: ShelfSpec, input: ShelfInput): ShelfView {
  const live = input.library.filter((b) => !b.deletedAt);
  const byHash = new Map(live.map((b) => [b.hash, b]));
  const label = spec.label ?? '';
  const from = spec.from ?? 0;
  const to = spec.to ?? Number.MAX_SAFE_INTEGER;

  const make = (b: (typeof live)[number], meta: string, badge?: string): ShelfBook => ({
    hash: b.hash,
    title: b.title,
    author: b.author || '',
    meta,
    ...(badge ? { badge } : {}),
    inLibrary: true,
  });

  switch (spec.kind) {
    // ---- the books read in a window, most time first
    case 'read': {
      const inWin = input.events.filter((e) => e.startTime >= from && e.startTime < to);
      const seconds = new Map<string, number>();
      const names = new Map<string, { title: string; authors: string }>();
      let total = 0;
      for (const e of inWin) {
        const d = clampDuration(e);
        if (d <= 0) continue;
        total += d;
        seconds.set(e.md5, (seconds.get(e.md5) ?? 0) + d);
        if (!names.has(e.md5)) names.set(e.md5, { title: e.title, authors: e.authors });
      }
      const sessionCount = new Map<string, number>();
      for (const s of buildSessions(inWin)) sessionCount.set(s.md5, (sessionCount.get(s.md5) ?? 0) + 1);

      const rows: ShelfBook[] = [...seconds.entries()]
        .sort((a, b) => b[1] - a[1])
        .map(([hash, sec]) => {
          const b = byHash.get(hash);
          const n = sessionCount.get(hash) ?? 0;
          const share = total ? Math.round((sec / total) * 100) : 0;
          return {
            hash,
            title: b?.title ?? names.get(hash)?.title ?? '',
            author: b?.author || names.get(hash)?.authors || '',
            meta: `${fmtMin(sec)} · ${n} ${n === 1 ? 'session' : 'sessions'}`,
            badge: `${share}%`,
            inLibrary: !!b,
          };
        });
      return {
        title: 'Most read',
        sub: `${label ? `${label} · ` : ''}${books(rows.length)}`,
        sections: [{ books: rows }],
        total: rows.length,
        empty: label ? `No reading in ${label}.` : 'No reading yet.',
      };
    }

    // ---- the books finished in a window, newest first
    case 'done': {
      const fromMs = from * 1000;
      const toMs = to * 1000;
      const rows = live
        .filter((b) => b.readingStatus === 'finished' && stamp(b) >= fromMs && stamp(b) < toMs)
        .sort((a, b) => stamp(b) - stamp(a))
        .map((b) => make(b, `Finished ${shortDate(stamp(b), input.now)}`));
      return {
        title: 'Finished',
        sub: `${label ? `${label} · ` : ''}${books(rows.length)}`,
        sections: [{ books: rows }],
        total: rows.length,
        empty: label ? `No books finished in ${label}.` : 'No finished books yet.',
      };
    }

    // ---- every book by language
    case 'langs': {
      const groups = new Map<string, ShelfBook[]>();
      for (const b of [...live].sort((a, c) => a.title.localeCompare(c.title))) {
        const name = languageName(b.language ?? '') || 'Language not set';
        const list = groups.get(name);
        const row = make(b, statusMeta(b));
        if (list) list.push(row);
        else groups.set(name, [row]);
      }
      const sections = [...groups.entries()]
        .sort((a, b) => (a[0] === 'Language not set' ? 1 : b[0] === 'Language not set' ? -1 : b[1].length - a[1].length || a[0].localeCompare(b[0])))
        .map(([name, list]) => ({ title: `${name} · ${list.length}`, books: list }));
      const n = sections.filter((s) => !s.title?.startsWith('Language not set')).length;
      return {
        title: 'Languages',
        sub: `${n} ${n === 1 ? 'language' : 'languages'} · ${books(live.length)}`,
        sections,
        total: live.length,
        empty: 'No books yet.',
      };
    }

    // ---- rated books by stars, then the ones still waiting for a rating
    case 'rated': {
      const rating = (h: string) => {
        const v = input.ratings[h] ?? 0;
        return v >= 1 && v <= 5 ? v : 0;
      };
      const sections: ShelfSection[] = [];
      for (let stars = 5; stars >= 1; stars--) {
        const list = live
          .filter((b) => rating(b.hash) === stars)
          .sort((a, b) => a.title.localeCompare(b.title))
          .map((b) => make(b, statusMeta(b), `${stars}★`));
        if (list.length) sections.push({ title: `${stars} ${stars === 1 ? 'star' : 'stars'} · ${list.length}`, books: list });
      }
      const ratedCount = sections.reduce((n, s) => n + s.books.length, 0);
      const waiting = live
        .filter((b) => rating(b.hash) === 0)
        // finished books first: those are the ones worth rating
        .sort((a, b) => Number(b.readingStatus === 'finished') - Number(a.readingStatus === 'finished') || a.title.localeCompare(b.title))
        .map((b) => make(b, statusMeta(b)));
      if (waiting.length) sections.push({ title: `Not rated yet · ${waiting.length}`, books: waiting });
      return {
        title: 'Ratings',
        sub: `${ratedCount} of ${live.length} rated`,
        sections,
        total: live.length,
        empty: 'No books yet.',
      };
    }

    // ---- finished books of EPIC_PAGES or more, longest first
    case 'epic': {
      const counts = bookPageCounts(input.events);
      const pagesOf = (b: BookLike) => counts.get(b.hash) ?? 0;
      const rows = live
        .filter((b) => b.readingStatus === 'finished' && pagesOf(b) >= EPIC_PAGES)
        .sort((a, b) => pagesOf(b) - pagesOf(a))
        .map((b) => make(b, PAGES(pagesOf(b))));
      return {
        title: 'Epic books',
        sub: `${EPIC_PAGES}+ pages · ${books(rows.length)}`,
        sections: [{ books: rows }],
        total: rows.length,
        empty: `No finished books of ${EPIC_PAGES}+ pages yet.`,
      };
    }
  }
}

// ---- the address -------------------------------------------------------------------------

const KINDS: ShelfKind[] = ['read', 'done', 'langs', 'rated', 'epic'];

/** ?s=read&from=…&to=…&label=October (without the leading "?"). */
export function shelfQuery(spec: ShelfSpec): string {
  const p = new URLSearchParams({ s: spec.kind });
  if (spec.from !== undefined) p.set('from', String(spec.from));
  if (spec.to !== undefined) p.set('to', String(spec.to));
  if (spec.label) p.set('label', spec.label);
  return p.toString();
}

export function parseShelfSpec(p: URLSearchParams): ShelfSpec | null {
  const kind = p.get('s');
  if (!KINDS.includes(kind as ShelfKind)) return null;
  const num = (k: string) => {
    const v = Number(p.get(k));
    return p.get(k) !== null && Number.isFinite(v) ? v : undefined;
  };
  const from = num('from');
  const to = num('to');
  const label = p.get('label') ?? undefined;
  return {
    kind: kind as ShelfKind,
    ...(from !== undefined ? { from } : {}),
    ...(to !== undefined ? { to } : {}),
    ...(label ? { label } : {}),
  };
}
