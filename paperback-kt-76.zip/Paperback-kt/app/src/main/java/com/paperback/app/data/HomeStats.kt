package com.paperback.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.ceil
import kotlin.math.max

/*
 * Home, round 9: the stats you pin under "Today", and the next best action 2.0. Plain functions (no Android, no clock:
 * `today`, the hour and `nowMs` are passed in).
 *
 * Next best action 2.0 looks at more than today's goal: the streak and its rest days, the hour you usually read, how
 * the same weekday went before, how close this week is to your best, the book you are in and the year's books goal.
 * It ranks what it finds, shows the best one, and "Another idea" shows the next.
 */

// ---- pinned stats ------------------------------------------------------------------------------

/** The stats you can pin under "Today" on Home. [key] is what is saved. */
enum class PinnedStat(val key: String, val label: String, val about: String) {
    GoalRing("goal", "Today's goal", "A ring for today's minutes, with the tiny goal"),
    Streak("streak", "Reading streak", "Days in a row, and a warning when it ends tonight"),
    Shielded("protected", "Protected streak", "The streak that forgives rest days"),
    Today("today", "Time today", "Minutes read so far today"),
    Pages("pages", "Pages today", "Pages turned today against your daily pages goal"),
    Week("week", "This week", "Minutes this week against the weekly goal"),
    Month("month", "This month", "Minutes this month against the monthly goal"),
    Pace("pace", "Reading pace", "Pages per hour over the last 60 days"),
    Wpm("wpm", "Words per minute", "Your speed over the last 60 days"),
    Books("books", "Books this year", "Finished books against the yearly goal"),
    BookLeft("left", "Time left in book", "Reading time left in the book you are in"),
    Rest("rest", "Rest days left", "Days off left this week that keep the protected streak"),
}

/** What Home shows until you pick your own: the goal ring and the streak, as before. */
val DEFAULT_PINNED: List<PinnedStat> = listOf(PinnedStat.GoalRing, PinnedStat.Streak)

const val MAX_PINNED = 4

/** "goal,streak" -> the list (unknown or repeated names dropped, at most [MAX_PINNED]); nothing usable gives the default. */
fun parsePinned(text: String?): List<PinnedStat> {
    if (text.isNullOrBlank()) return DEFAULT_PINNED
    val out = ArrayList<PinnedStat>()
    for (part in text.split(',')) {
        val s = PinnedStat.values().firstOrNull { it.key == part.trim() } ?: continue
        if (s !in out) out.add(s)
        if (out.size >= MAX_PINNED) break
    }
    return if (out.isEmpty()) DEFAULT_PINNED else out
}

fun pinnedText(list: List<PinnedStat>): String = list.joinToString(",") { it.key }

/** The numbers behind the pinned stats and the actions, worked out once. */
class HomeFigures(
    val todaySeconds: Long,
    val todayPages: Int,
    val streak: Int,
    val longestStreak: Int,
    val shielded: Int,
    val restLeft: Int,
    val restDays: Int,
    val weekSeconds: Long,
    val monthSeconds: Long,
    /** Pages per hour and words per minute over the last 60 days (0 = not enough reading). */
    val pace: Int,
    val wpm: Int,
    val wpmEstimated: Boolean,
    val booksYear: Int,
    val booksExpected: Int,
    /** The hour (0 to 23) you most often start reading in, null while there is too little to tell. */
    val peakHour: Int?,
    /** Seconds you read on an average one of the last eight same weekdays, null until you read on three of them. */
    val weekdayAvgSeconds: Long?,
    /** The most you read in any earlier Monday-to-Sunday week. */
    val bestWeekSeconds: Long,
    val bookTitle: String?,
    val bookSecondsLeft: Long?,
)

private const val DAY_MIN_SECONDS = 60L

private fun mondayOf(d: LocalDate): LocalDate = d.minusDays((d.dayOfWeek.value - 1).toLong())

fun homeFigures(
    rows: List<ReadingSession>,
    books: List<Book>,
    goals: Goals,
    today: LocalDate,
    nowMs: Long,
    zone: ZoneId,
    bookTitle: String?,
    bookSecondsLeft: Long?,
): HomeFigures {
    val byDay = Stats.secondsByDay(rows, zone)
    val todaySeconds = byDay[today] ?: 0L
    val todayPages = rows.filter { dateOf(it.startMs, zone) == today }.sumOf { it.pages }
    val history = GoalHistory(emptyMap(), goals.minutesPerDay, today)
    val st = streaks(byDay, history, goals, today)

    val monday = mondayOf(today)
    val weekSeconds = byDay.entries.filter { !it.key.isBefore(monday) && !it.key.isAfter(today) }.sumOf { it.value }
    val monthStart = today.withDayOfMonth(1)
    val monthSeconds = byDay.entries.filter { !it.key.isBefore(monthStart) && !it.key.isAfter(today) }.sumOf { it.value }

    // the best earlier week
    val weeks = HashMap<LocalDate, Long>()
    for ((d, s) in byDay) weeks[mondayOf(d)] = (weeks[mondayOf(d)] ?: 0L) + s
    val bestWeek = weeks.filterKeys { it != monday }.values.maxOrNull() ?: 0L

    // speed, last 60 days
    val from60 = today.minusDays(59).atStartOfDay(zone).toInstant().toEpochMilli()
    val recent = rows.filter { it.startMs >= from60 }
    val pace = forecastPattern(rows, today, zone)?.pace ?: 0
    val wpm = wpmOf(recent, books.associateBy { it.id })

    // the hour you usually start reading (reading only, last 60 days)
    val perHour = LongArray(24)
    val activeDays = HashSet<LocalDate>()
    for (r in recent) {
        if (r.kind == SessionKind.LISTEN || r.seconds <= 0) continue
        val at = Instant.ofEpochMilli(r.startMs).atZone(zone)
        perHour[at.hour] += r.seconds.toLong()
        activeDays.add(at.toLocalDate())
    }
    val totalHour = perHour.sum()
    var peak: Int? = null
    if (activeDays.size >= 4 && totalHour >= 1800L) {
        val top = perHour.indices.maxByOrNull { perHour[it] } ?: 0
        // a lone hour that holds at least an eighth of all reading
        if (perHour[top] * 8 >= totalHour) peak = top
    }

    // the same weekday, the last eight times
    val sameDays = (1..8).map { byDay[today.minusDays(7L * it)] ?: 0L }
    val weekdayAvg = if (sameDays.count { it >= DAY_MIN_SECONDS } >= 3) sameDays.sum() / sameDays.size else null

    val finished = Stats.booksFinishedInYear(books, today.year, zone)
    val year = yearPace(finished, goals.booksPerYear, nowMs, zone)

    return HomeFigures(
        todaySeconds = todaySeconds,
        todayPages = todayPages,
        streak = Stats.currentStreak(byDay, today),
        longestStreak = Stats.longestStreak(byDay),
        shielded = st.shielded.length,
        restLeft = st.restLeft,
        restDays = st.restDays,
        weekSeconds = weekSeconds,
        monthSeconds = monthSeconds,
        pace = pace,
        wpm = wpm.first,
        wpmEstimated = wpm.second,
        booksYear = finished,
        booksExpected = year.expected,
        peakHour = peak,
        weekdayAvgSeconds = weekdayAvg,
        bestWeekSeconds = bestWeek,
        bookTitle = bookTitle,
        bookSecondsLeft = bookSecondsLeft,
    )
}

/** One pinned tile: the small label, the big value and an optional line under it. */
class PinnedValue(val label: String, val value: String, val sub: String?)

private fun daysText(n: Int): String = if (n == 1) "1 day" else "$n days"

/** The tile for [stat]. [GoalRing] is drawn by the ring tile itself, so it only returns a plain fallback here. */
fun pinnedValue(stat: PinnedStat, f: HomeFigures, goals: Goals, hour: Int): PinnedValue = when (stat) {
    PinnedStat.GoalRing -> PinnedValue("Today's goal", Stats.duration(f.todaySeconds), "of ${goals.minutesPerDay} min")
    PinnedStat.Streak -> {
        // after 17:00 a streak of two days or more with no reading yet says it ends tonight
        val atRisk = f.streak >= 2 && f.todaySeconds < DAY_MIN_SECONDS && hour >= 17
        PinnedValue(if (atRisk) "Streak at risk" else "Streak", daysText(f.streak), if (f.longestStreak > f.streak) "best ${f.longestStreak}" else null)
    }
    PinnedStat.Shielded -> PinnedValue(
        "Protected streak", daysText(f.shielded),
        if (goals.restDays > 0) "${f.restLeft} rest ${if (f.restLeft == 1) "day" else "days"} left" else "rest days are off",
    )
    PinnedStat.Today -> PinnedValue("Time today", Stats.duration(f.todaySeconds), "goal ${goals.minutesPerDay} min")
    PinnedStat.Pages -> PinnedValue("Pages today", "${f.todayPages}", "goal ${goals.pagesPerDay}")
    PinnedStat.Week -> PinnedValue("This week", Stats.duration(f.weekSeconds), "of ${goals.weeklyMinutes} min")
    PinnedStat.Month -> PinnedValue("This month", Stats.duration(f.monthSeconds), "of ${goals.monthlyMinutes} min")
    PinnedStat.Pace -> PinnedValue("Pace", if (f.pace > 0) "${f.pace} p/h" else "–", "last 60 days")
    PinnedStat.Wpm -> PinnedValue(
        "Words per minute", if (f.wpm > 0) "${if (f.wpmEstimated) "~" else ""}${f.wpm}" else "–",
        if (f.wpmEstimated && f.wpm > 0) "estimated" else "last 60 days",
    )
    PinnedStat.Books -> PinnedValue(
        "Books this year", "${f.booksYear} of ${goals.booksPerYear}",
        if (f.booksYear >= goals.booksPerYear) "goal reached" else if (f.booksYear >= f.booksExpected) "on pace" else "${f.booksExpected - f.booksYear} behind",
    )
    PinnedStat.BookLeft -> PinnedValue(
        "Time left in book", f.bookSecondsLeft?.let { Stats.duration(it) } ?: "–", f.bookTitle,
    )
    PinnedStat.Rest -> PinnedValue(
        "Rest days left", "${f.restLeft}", if (goals.restDays > 0) "of ${goals.restDays} a week" else "rest days are off",
    )
}

// ---- next best action 2.0 -----------------------------------------------------------------------

/** What the button of an action does. */
enum class ActionGo { None, Read, Goals }

class HomeAction(
    val id: String,
    val title: String,
    val text: String,
    val go: ActionGo,
    /** Higher shows first. */
    val priority: Int,
)

private fun hourText(h: Int): String = "%02d:00".format(h)

private fun minutesWord(n: Int): String = if (n == 1) "1 minute" else "$n minutes"

/** The ideas for right now, best first (never empty). */
fun nextActions(f: HomeFigures, goals: Goals, today: LocalDate, hour: Int): List<HomeAction> {
    val out = ArrayList<HomeAction>()
    val goalS = goals.minutesPerDay * 60L
    val readToday = f.todaySeconds >= DAY_MIN_SECONDS
    val dailyLeft = max(0L, ceil((goalS - f.todaySeconds) / 60.0).toLong()).toInt()
    val tiny = goals.tinyMinutes
    val tinyLeft = max(1L, ceil((tiny * 60L - f.todaySeconds) / 60.0).toLong()).toInt()
    val weekdayName = StatNames.WEEKDAYS[StatNames.weekdayIndex(today)]
    val bookLeftMin = f.bookSecondsLeft?.let { ceil(it / 60.0).toInt() }

    // 1. the day is done
    if (f.todaySeconds >= goalS) {
        out.add(
            HomeAction(
                "done", "Daily goal reached",
                if (f.streak > 1) "${f.streak} days in a row. See you tomorrow." else "Nice work today. See you tomorrow.",
                ActionGo.None, 80,
            ),
        )
    }

    // 2. a streak that ends tonight, or a streak to keep
    if (f.streak >= 2 && !readToday) {
        if (hour >= 17) {
            val rest = if (f.restDays > 0 && f.restLeft > 0) {
                " Or take today as a rest day: you have ${f.restLeft} left this week."
            } else ""
            out.add(
                HomeAction(
                    "streak-risk", "Save your ${f.streak}-day streak",
                    "Read ${minutesWord(tiny)} (your tiny goal) and it holds.$rest",
                    ActionGo.Read, 100,
                ),
            )
        } else {
            out.add(
                HomeAction(
                    "streak-keep", "Keep your ${f.streak}-day streak",
                    "Even ${minutesWord(tiny)} counts as a reading day. The goal is ${goals.minutesPerDay}.",
                    ActionGo.Read, 60,
                ),
            )
        }
    }

    if (f.todaySeconds < goalS) {
        // 3. the goal is close
        if (readToday) {
            out.add(
                HomeAction(
                    "goal-close", "$dailyLeft min to today's goal",
                    "Read ${minutesWord(dailyLeft)} more to reach ${goals.minutesPerDay}.",
                    ActionGo.Read, if (dailyLeft <= 10) 90 else 70,
                ),
            )
        }
        // 4. the book is nearly done
        if (bookLeftMin != null && f.bookTitle != null && bookLeftMin in 1..40) {
            val also = if (dailyLeft in 1..bookLeftMin) " That reaches today's goal too." else ""
            out.add(
                HomeAction(
                    "book-finish", "Finish ${f.bookTitle}",
                    "About ${minutesWord(bookLeftMin)} left at your pace.$also",
                    ActionGo.Read, 85,
                ),
            )
        }
        // 5. your usual hour
        val peak = f.peakHour
        if (peak != null && !readToday) {
            if (hour in (peak - 1)..(peak + 1)) {
                out.add(
                    HomeAction(
                        "peak-now", "It's your reading hour",
                        "You usually start around ${hourText(peak)}. Begin with ${minutesWord(tiny)}.",
                        ActionGo.Read, 75,
                    ),
                )
            } else if (hour < peak - 1) {
                out.add(
                    HomeAction(
                        "peak-later", "Plan your reading",
                        "You usually read around ${hourText(peak)}. Keep a few minutes free then.",
                        ActionGo.None, 45,
                    ),
                )
            }
        }
        // 6. beat the same weekday
        val avg = f.weekdayAvgSeconds
        if (avg != null && f.todaySeconds < avg && avg - f.todaySeconds <= 20 * 60L) {
            val need = (ceil((avg - f.todaySeconds) / 60.0).toInt() + 1).coerceAtLeast(1)
            out.add(
                HomeAction(
                    "beat-day", "${minutesWord(need)} beats your usual $weekdayName",
                    "You read about ${Stats.duration(avg)} on a $weekdayName.",
                    ActionGo.Read, 65,
                ),
            )
        }
    }

    // 7. a record week is in reach
    val toBest = f.bestWeekSeconds - f.weekSeconds
    if (f.bestWeekSeconds >= 3600L && toBest in 1..(90 * 60L)) {
        out.add(
            HomeAction(
                "best-week", "Beat your best week",
                "${minutesWord(ceil(toBest / 60.0).toInt() + 1)} more this week sets a new best (${Stats.duration(f.bestWeekSeconds)}).",
                ActionGo.Read, 66,
            ),
        )
    }

    // 8. the weekly goal
    val weekGoalS = goals.weeklyMinutes * 60L
    if (f.weekSeconds < weekGoalS) {
        val leftMin = ceil((weekGoalS - f.weekSeconds) / 60.0).toInt()
        val daysLeft = 8 - today.dayOfWeek.value // Monday = 7 days left, Sunday = 1
        val perDay = ceil(leftMin / daysLeft.toDouble()).toInt()
        out.add(
            HomeAction(
                "week-goal", "Weekly goal: $perDay min a day",
                "$leftMin min left this week, $daysLeft ${if (daysLeft == 1) "day" else "days"} to go.",
                ActionGo.Goals, 50,
            ),
        )
    }

    // 9. the year's books goal
    if (f.booksYear < f.booksExpected) {
        val behind = f.booksExpected - f.booksYear
        out.add(
            HomeAction(
                "year-books", "$behind ${if (behind == 1) "book" else "books"} behind this year's pace",
                if (f.bookTitle != null) "Finishing ${f.bookTitle} gets you closer." else "Start a book to get back on pace.",
                ActionGo.Goals, 48,
            ),
        )
    }

    // 10. a low bar for a day that is nearly over, and the starting lines of the first version
    if (!readToday && f.streak == 0 && hour >= 19) {
        out.add(HomeAction("tiny", "Just ${minutesWord(tiny)}", "A tiny read still counts as a reading day.", ActionGo.Read, 55))
    }
    if (f.todaySeconds < goalS && !readToday) {
        out.add(
            when {
                f.streak > 0 -> HomeAction("goal-today", "Read ${goals.minutesPerDay} minutes today", "${tinyLeft} min is enough to keep the streak.", ActionGo.Read, 40)
                f.longestStreak > 0 -> HomeAction(
                    "new-streak", "Start a new streak",
                    "Your best is ${daysText(f.longestStreak)}. Read ${minutesWord(goals.minutesPerDay)} today.", ActionGo.Read, 40,
                )
                else -> HomeAction("first-streak", "Light your first streak day", "Read ${minutesWord(goals.minutesPerDay)} today to start a streak.", ActionGo.Read, 40)
            },
        )
    }

    if (out.isEmpty()) {
        out.add(HomeAction("fallback", "You're on track", "Nothing needs you right now.", ActionGo.None, 1))
    }
    return out.sortedByDescending { it.priority }
}
