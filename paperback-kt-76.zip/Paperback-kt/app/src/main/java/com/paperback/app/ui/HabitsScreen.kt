package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.PacePoint
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.StatNames
import com.paperback.app.data.paceStats
import com.paperback.app.data.weekHour
import com.paperback.app.ui.theme.pbTokens
import java.time.ZoneId
import kotlin.math.min

/**
 * Stats -> Habits: when and how you read best. Words per minute by time of day, weekday, length of the sitting and
 * genre; a card with your best conditions; and a week-by-hour map of when you read. Words per minute come from the
 * pages you turned and the words on a page of each book (see Edit book -> Reading facts), listening is left out.
 */
@Composable
fun HabitsScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    statsLayout: String = "",
    onStatsLayout: (String) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val zone = remember { ZoneId.systemDefault() }
    val pace = remember(sessions, books) { paceStats(sessions, books, zone) }
    val grid = remember(sessions) { weekHour(sessions, zone) }
    val look = remember(sessions, books) { com.paperback.app.data.lookPace(sessions, books) }
    val focus = remember(sessions, books) { com.paperback.app.data.focusFigures(sessions, books) }
    val context = remember(sessions) { com.paperback.app.data.contextFigures(sessions) }
    val accent = MaterialTheme.colorScheme.primary

    if (pace == null && grid == null) {
        Box(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Not enough reading yet", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("Once you have read for a while, your best times show up here.", color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        }
        return
    }

    val cards = ArrayList<StatCard>()
    fun card(key: String, title: String, content: @Composable () -> Unit) {
        cards.add(StatCard(key, title, content))
    }
    run {
        pace?.let { p ->
            if (p.best.isNotEmpty()) card("best", "Your best conditions") {
                HbCard("Your best conditions") {
                    p.best.forEachIndexed { i, b ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Text(b.measure.uppercase(), color = t.setSub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(b.label, color = inkOf(if (i % 2 == 0) DashAccent.Violet else DashAccent.Pink), fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                Text(
                                    "${b.wpm} wpm" + if (b.abovePercent != 0) " \u00B7 ${if (b.abovePercent > 0) "+" else ""}${b.abovePercent}%" else "",
                                    color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp),
                                )
                            }
                        }
                    }
                    HbHint(
                        "Your average is ${p.overall} words a minute" + (if (p.estimated) " (estimated: most of your books have no word count)" else "") +
                            ". Percent is against that average.",
                    )
                }
            }
            if (p.byHour.size >= 2) card("hour", "Pace by time of day") { HbCard("Pace by time of day") { PaceBars(p.byHour, accent) } }
            if (p.byWeekday.size >= 2) card("weekday", "Pace by weekday") {
                HbCard("Pace by weekday") {
                    PaceStems(p.byWeekday)
                    p.byWeekday.maxByOrNull { it.wpm }?.let { HbHint("Fastest on ${it.label}. Words a minute for each weekday.") }
                }
            }
            if (p.byLength.size >= 2) card("length", "Pace by sitting length") {
                HbCard("Pace by sitting length") {
                    PaceBars(p.byLength, accent)
                    HbHint("Whether longer sittings speed you up or slow you down.")
                }
            }
            if (p.byGenre.size >= 2) card("genre", "Pace by genre") {
                HbCard("Pace by genre") {
                    PaceBars(p.byGenre, accent)
                    HbHint("Your tags sorted into broad genres. Needs 20 minutes of reading in a genre.")
                }
            }
        }

        look?.let { l ->
            if (l.byTheme.size >= 2) card("theme", "Pace by page colour") {
                HbCard("Pace by page colour") {
                    PaceBars(l.byTheme, accent)
                    l.bestTheme?.let { HbHint("You read fastest on ${it.label}. Needs 10 minutes on each colour.") }
                }
            }
            if (l.byFontSize.size >= 2) card("fontsize", "Pace by text size") {
                HbCard("Pace by text size") {
                    PaceBars(l.byFontSize, accent)
                    l.bestFont?.let { HbHint("You read fastest at ${it.label}. Sizes are rounded to the nearest 10%.") }
                }
            }
        }

        focus?.let { f ->
            card("focus", "Focus") {
                HbCard("Focus") {
                    Row {
                        Text("%.1f".format(f.breaksPerHour), modifier = Modifier.alignByBaseline(), color = t.ink, fontSize = 36.sp, fontWeight = FontWeight.SemiBold)
                        Text("breaks an hour", modifier = Modifier.alignByBaseline().padding(start = 8.dp), color = t.setSub, fontSize = 15.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(t.ink.copy(alpha = 0.1f))) {
                        Box(
                            Modifier
                                .fillMaxWidth((f.focusPercent / 100f).coerceIn(0.03f, 1f))
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(3.dp))
                                .background(Brush.horizontalGradient(listOf(DashAccent.Violet, DashAccent.Pink))),
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("${f.focusPercent}% of ${f.sessions} sessions had no break", color = t.setSub, fontSize = 13.sp)
                    val most = f.mostFocused
                    val least = f.leastFocused
                    if (most != null || least != null) {
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (most != null) FocusBookTile("Most focused", most.title, most.focusPercent, DashAccent.Cyan, Modifier.weight(1f))
                            if (least != null) FocusBookTile("Least focused", least.title, least.focusPercent, DashAccent.Pink, Modifier.weight(1f))
                        }
                    }
                    HbHint("A break is a gap of more than 3 minutes without a page turn (the app went to the background, or you paused). Counted from this update on; books need 3 sessions.")
                }
            }
        }

        context?.let { c ->
            card("context", "Place and mood") {
                HbCard("Place and mood") {
                    if (c.byPlace.isNotEmpty()) {
                        Text("PLACE", color = t.setSub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        c.byPlace.forEach { HbFact(it.label, "${it.minutes} min \u00B7 ${it.sessions} sessions \u00B7 avg ${it.averageMinutes} min") }
                    }
                    if (c.byMood.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text("MOOD", color = t.setSub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        c.byMood.forEach { HbFact(it.label, "${it.minutes} min \u00B7 ${it.sessions} sessions \u00B7 avg ${it.averageMinutes} min") }
                    }
                    HbHint("Only sessions where you tapped a place or mood after reading (${c.tapped} so far).")
                }
            }
        }

        grid?.let { g ->
            card("weekhour", "When you read") {
                HbCard("When you read") {
                    WeekHourMap(g.minutes, g.max, DashAccent.Violet)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Most reading: ${StatNames.WEEKDAYS_MON_FIRST[g.peakDay]} around ${"%02d".format(g.peakHour)}:00 \u00B7 ${g.max.toInt()} min in total",
                        color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    )
                    HbHint("Every sitting split across the hours it covered, reading and listening together. Brighter is more time.")
                }
            }
        }
    }
    CardList("habits", cards, statsLayout, onStatsLayout, modifier)
}

@Composable
private fun HbCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val t = pbTokens()
    DashCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
            Text(title, color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun HbFact(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.setSub, fontSize = 14.sp, modifier = Modifier.weight(0.8f))
        Text(value, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(1.2f))
    }
}

@Composable
private fun HbHint(text: String) {
    Text(text, color = pbTokens().setSub, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
}

/**
 * Thin bars of words per minute. They start a little under the slowest group so the differences show; the numbers
 * beside them are the real values. The fastest group is lit violet to pink.
 */
@Composable
private fun PaceBars(points: List<PacePoint>, color: Color) {
    val t = pbTokens()
    val low = (points.minOf { it.wpm } * 0.8)
    val high = points.maxOf { it.wpm }.toDouble()
    val span = (high - low).coerceAtLeast(1.0)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        points.forEach { p ->
            val best = p.wpm.toDouble() == high
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.label, color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Text("${p.wpm} wpm \u00B7 ${p.minutes} min", color = t.setSub, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 10.dp))
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(t.ink.copy(alpha = 0.1f))) {
                    val fraction = (((p.wpm - low) / span).toFloat()).coerceIn(0.04f, 1f)
                    Box(
                        Modifier
                            .fillMaxWidth(fraction)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(3.dp))
                            .background(
                                Brush.horizontalGradient(
                                    if (best) listOf(DashAccent.Violet, DashAccent.Pink) else listOf(DashAccent.Blue, DashAccent.Cyan),
                                ),
                            ),
                    )
                }
            }
        }
    }
}

/** One thin stem with a dot on top for each group (the weekdays): the higher the dot, the faster you read. */
@Composable
private fun PaceStems(points: List<PacePoint>) {
    val t = pbTokens()
    val low = (points.minOf { it.wpm } * 0.8)
    val high = points.maxOf { it.wpm }.toDouble()
    val span = (high - low).coerceAtLeast(1.0)
    val stem = t.ink.copy(alpha = 0.16f)
    Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        points.forEach { p ->
            val fraction = (((p.wpm - low) / span).toFloat()).coerceIn(0.1f, 1f)
            val best = p.wpm.toDouble() == high
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${p.wpm}", color = if (best) t.ink else t.setSub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Canvas(Modifier.weight(1f).fillMaxWidth()) {
                    val cx = size.width / 2f
                    val topY = size.height * (1f - fraction) + 12.dp.toPx()
                    drawLine(stem, Offset(cx, size.height), Offset(cx, topY), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                    if (best) {
                        drawCircle(DashAccent.Pink.copy(alpha = 0.35f), 11.dp.toPx(), Offset(cx, topY))
                        drawCircle(Color.White, 8.dp.toPx(), Offset(cx, topY))
                    } else {
                        drawCircle(DashAccent.Violet, 6.dp.toPx(), Offset(cx, topY))
                    }
                }
                Text(p.label.take(3), color = t.setSub, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

/** The most or least focused book: a small soft tile inside the Focus card. */
@Composable
private fun FocusBookTile(label: String, title: String, percent: Int, color: Color, modifier: Modifier) {
    val t = pbTokens()
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(t.ink.copy(alpha = 0.06f))
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Text(label, color = t.setSub, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Text(title, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        Text("$percent% without a break", color = inkOf(color), fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

/** Seven rows (Monday first) of 24 hours; the darker the cell the more minutes. */
@Composable
private fun WeekHourMap(minutes: Array<DoubleArray>, max: Double, color: Color) {
    val t = pbTokens()
    val track = t.ink.copy(alpha = 0.06f)
    val cellHeight = 14.dp
    val gap = 2.dp
    Row(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            StatNames.WEEKDAYS_MON_FIRST.forEach { d ->
                Box(Modifier.height(cellHeight).padding(end = 6.dp), contentAlignment = Alignment.CenterStart) {
                    Text(d.take(3), color = t.setSub, fontSize = 10.sp)
                }
            }
        }
        Canvas(Modifier.weight(1f).height(cellHeight * 7 + gap * 6)) {
            val g = gap.toPx()
            val ch = cellHeight.toPx()
            val cw = (size.width - g * 23f) / 24f
            for (d in 0 until 7) {
                for (h in 0 until 24) {
                    val v = minutes[d][h]
                    val c = if (v <= 0.0) track else color.copy(alpha = (0.15 + 0.85 * (v / max)).toFloat().coerceIn(0.15f, 1f))
                    drawCircle(
                        color = c,
                        radius = min(cw, ch) / 2f,
                        center = Offset(h * (cw + g) + cw / 2f, d * (ch + g) + ch / 2f),
                    )
                }
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(start = 30.dp, top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        listOf("00", "06", "12", "18", "23").forEach { Text(it, color = t.setSub, fontSize = 10.sp) }
    }
}
