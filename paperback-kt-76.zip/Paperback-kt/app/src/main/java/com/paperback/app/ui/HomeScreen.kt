package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.draw.clip
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.Ranker
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.catalog.Load
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.HomeSection
import com.paperback.app.data.HomeView
import com.paperback.app.data.Recommendation
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.data.RecapRow
import java.time.LocalDate

@Composable
fun HomeScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    recommended: List<Recommendation>,
    goalMinutes: Int,
    tinyMinutes: Int = 0,
    /** All the goals (for the pinned stats and the suggestions), the stats pinned under Today, and how to change them. */
    goals: com.paperback.app.data.Goals = com.paperback.app.data.Goals(),
    pinned: List<com.paperback.app.data.PinnedStat> = com.paperback.app.data.DEFAULT_PINNED,
    onPinned: (List<com.paperback.app.data.PinnedStat>) -> Unit = {},
    onOpenGoals: () -> Unit = {},
    onOpen: (Book) -> Unit,
    onRead: (Book) -> Unit,
    onDetails: (Book) -> Unit,
    onImport: () -> Unit,
    onDiscover: () -> Unit,
    catalog: CatalogController,
    wishlist: List<CatalogBook>,
    onOpenCatalogBook: (CatalogBook) -> Unit,
    onBrowse: (kind: String, value: String) -> Unit,
    /** How each section is drawn; a section missing from the map uses its default look. */
    homeViews: Map<HomeSection, HomeView> = emptyMap(),
    onHomeView: (HomeSection, HomeView) -> Unit = { _, _ -> },
    /** false hides "Recommended for you" and "Books you might like". */
    showRecommendations: Boolean = true,
    /** "Not interested" on a book of "Recommended for you". */
    onDismissRecommended: (Book) -> Unit = {},
    /** The books of your library to suggest as the next read, best first (empty = no "Pick my next read"). */
    nextPicks: List<com.paperback.app.data.Similar.NextPick> = emptyList(),
    /** Last month's recap, while it waits to be opened. */
    recap: RecapRow? = null,
    onOpenRecap: () -> Unit = {},
    /** The session the optional place-and-mood question is about (null = don't ask), and what its buttons do. */
    contextSession: com.paperback.app.data.ReadingSession? = null,
    contextTitle: String = "",
    onContextSave: (sessionId: Long, place: Int, mood: Int) -> Unit = { _, _, _ -> },
    onContextDismiss: (sessionId: Long) -> Unit = {},
    onContextNever: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val today = LocalDate.now()
    val pace = remember(sessions) { Stats.paceSecondsPerPosition(sessions) }

    val next = remember(books) {
        books.filter { it.isReading && it.hasFile }.maxByOrNull { it.lastOpenedAt } ?: books.firstOrNull { !it.finished && it.hasFile }
    }

    // the figures behind the pinned stats and the next best action (the hour only moves when the screen is redrawn)
    val hour = java.time.LocalTime.now().hour
    val figures = remember(sessions, books, goals, today, next, pace) {
        com.paperback.app.data.homeFigures(
            rows = sessions,
            books = books,
            goals = goals,
            today = today,
            nowMs = System.currentTimeMillis(),
            zone = java.time.ZoneId.systemDefault(),
            bookTitle = next?.title,
            bookSecondsLeft = next?.let { Stats.timeLeftSeconds(it, pace) },
        )
    }
    val actions = remember(figures, goals, today, hour) { com.paperback.app.data.nextActions(figures, goals, today, hour) }
    var editPinned by remember { mutableStateOf(false) }
    val recent = remember(books, next) {
        books.filter { it.lastOpenedAt > 0 && it.id != next?.id }.sortedByDescending { it.lastOpenedAt }.take(10)
    }

    val onlineOn by catalog.enabled.collectAsStateWithLifecycle()
    val forYou by catalog.forYou.collectAsStateWithLifecycle()
    val owned = remember(books) { ownedKeys(books) }
    LaunchedEffect(onlineOn, books, showRecommendations) { if (showRecommendations) catalog.refresh() }
    val fy = forYou
    val picks: List<Ranker.Pick> = if (fy is Load.Ready) fy.value else emptyList()
    // the picks that share a reason become rows of their own ("Because you liked ..."); the rest stay in one row
    val pickRows = remember(picks) { Ranker.group(picks, 3, 2) }
    val mixedPicks = remember(picks, pickRows) {
        val inRows = pickRows.flatMap { g -> g.picks.take(12).map { it.book.id } }.toSet()
        picks.filter { it.book.id !in inRows }
    }

    fun viewOf(section: HomeSection): HomeView = homeViews[section] ?: section.default
    val favorites = remember(books) { books.filter { it.favorite }.sortedByDescending { it.lastOpenedAt } }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        if (recap != null) {
            RecapBanner(recap, onOpenRecap)
            Spacer(Modifier.height(22.dp))
        }
        if (contextSession != null) {
            SessionContextCard(
                bookTitle = contextTitle,
                minutes = (contextSession.seconds / 60).coerceAtLeast(1),
                onSave = { place, mood -> onContextSave(contextSession.id, place, mood) },
                onDismiss = { onContextDismiss(contextSession.id) },
                onNever = { onContextNever(); onContextDismiss(contextSession.id) },
            )
            Spacer(Modifier.height(22.dp))
        }
        Eyebrow("Continue reading")
        Spacer(Modifier.height(12.dp))

        if (next == null) {
            LibraryEmpty(onImport = onImport, onDiscover = onDiscover)
        } else {
            Row(Modifier.fillMaxWidth()) {
                BookCover(next, Modifier.width(132.dp).clickable { onOpen(next) })
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        next.title,
                        modifier = Modifier.clickable { onDetails(next) },
                        fontFamily = PbSerif,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (next.author.isNotBlank()) {
                        Text(next.author, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(14.dp))
                    if (next.currentPage > 0 && next.pageCount > 0) {
                        Text("Page ${next.currentPage} of ${next.pageCount}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    ProgressTrack(next.progress)
                    Spacer(Modifier.height(8.dp))
                    val left = Stats.timeLeftSeconds(next, pace)?.let { " · ${Stats.duration(it)} left" } ?: ""
                    Text("${next.percent}%$left", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            PbButton(if (next.isReading) "Resume reading" else "Start reading", onClick = { onRead(next) })
            // when nothing is half-read, help choose what to start
            if (!next.isReading && nextPicks.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                NextReadPicker(nextPicks, onRead = onRead, onDetails = onDetails)
            }
        }

        if (actions.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            NextActionCard(actions, canRead = next != null, onRead = { next?.let(onRead) }, onGoals = onOpenGoals)
        }

        Spacer(Modifier.height(28.dp))
        TodayHeader(onEdit = { editPinned = true })
        Spacer(Modifier.height(12.dp))
        PinnedTiles(pinned.ifEmpty { com.paperback.app.data.DEFAULT_PINNED }, figures, goals, hour)
        if (editPinned) {
            PinnedStatsDialog(
                selected = pinned,
                onSave = { onPinned(it); editPinned = false },
                onCancel = { editPinned = false },
            )
        }

        if (favorites.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            val v = viewOf(HomeSection.Favorites)
            HomeSectionHeader("Favorites", HomeSection.Favorites, v, { onHomeView(HomeSection.Favorites, it) })
            HomeBooks(favorites, v, onClick = onOpen, shelfRows = 1)
        }

        if (recent.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            val v = viewOf(HomeSection.Recent)
            HomeSectionHeader("Recently read", HomeSection.Recent, v, { onHomeView(HomeSection.Recent, it) })
            // The book you had open last leans on the others, the way you leave one on a real shelf.
            HomeBooks(recent, v, onClick = onOpen, shelfRows = 2, leanId = recent.first().id)
        }

        if (showRecommendations && recommended.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            val v = viewOf(HomeSection.Recommended)
            HomeSectionHeader("Recommended for you", HomeSection.Recommended, v, { onHomeView(HomeSection.Recommended, it) })
            HomeBooks(
                recommended.map { it.book },
                v,
                onClick = onDetails,
                shelfRows = 1,
                notes = recommended.associate { it.book.id to (it.note ?: "Because you liked ${it.because.title}") },
                onDismiss = onDismissRecommended,
            )
        }
        if (wishlist.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            val v = viewOf(HomeSection.WantToRead)
            HomeSectionHeader("Want to read", HomeSection.WantToRead, v, { onHomeView(HomeSection.WantToRead, it) }, onAll = { onBrowse("want", "") })
            HomeCatalogBooks(wishlist.take(12), v, owned, onOpen = onOpenCatalogBook)
        }

        if (showRecommendations && onlineOn) {
            val rowView = viewOf(HomeSection.Because)
            pickRows.forEach { g ->
                Spacer(Modifier.height(28.dp))
                HomeSectionHeader(g.title, HomeSection.Because, rowView, { onHomeView(HomeSection.Because, it) })
                HomeCatalogBooks(
                    g.picks.take(12).map { it.book },
                    rowView,
                    owned,
                    onOpen = onOpenCatalogBook,
                    onDismiss = { catalog.dismiss(it) },
                )
            }
            if (mixedPicks.isNotEmpty()) {
                Spacer(Modifier.height(28.dp))
                val v = viewOf(HomeSection.MightLike)
                HomeSectionHeader("Books you might like", HomeSection.MightLike, v, { onHomeView(HomeSection.MightLike, it) }, onAll = { onBrowse("foryou", "") })
                HomeCatalogBooks(
                    mixedPicks.take(10).map { it.book },
                    v,
                    owned,
                    onOpen = onOpenCatalogBook,
                    notes = mixedPicks.associate { it.book.id to it.reason },
                    onDismiss = { catalog.dismiss(it) },
                )
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
