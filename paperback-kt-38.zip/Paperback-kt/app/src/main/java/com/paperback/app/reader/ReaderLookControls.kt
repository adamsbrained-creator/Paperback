package com.paperback.app.reader

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.FOOTER_LEFT_PAGES
import com.paperback.app.data.FOOTER_PERCENT
import com.paperback.app.data.FOOTER_TOTAL
import com.paperback.app.data.HEADER_MAX
import com.paperback.app.data.HEADER_MIN
import com.paperback.app.data.ReaderLook
import com.paperback.app.data.SPACE_MAX
import com.paperback.app.data.SPACE_MIN
import com.paperback.app.ui.PbSlider
import com.paperback.app.ui.theme.PbSerif
import kotlin.math.roundToInt

private fun tenth(v: Float): Float = (v * 10f).roundToInt() / 10f

@Composable
private fun Section(c: ReaderColors, label: String, value: String? = null, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f), color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (value != null) Text(value, color = c.ink.copy(alpha = 0.6f), fontSize = 13.sp)
        }
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
private fun Slide(c: ReaderColors, label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit) {
    Section(c, label, valueText) {
        PbSlider(value = value, onValueChange = onValue, valueRange = range, trackColor = c.ink.copy(alpha = 0.15f))
    }
}

@Composable
private fun Toggle(c: ReaderColors, label: String, hint: String? = null, on: Boolean, onToggle: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (hint != null) Text(hint, color = c.ink.copy(alpha = 0.55f), fontSize = 12.sp)
        }
        Pill(c, if (on) "On" else "Off", selected = on) { onToggle(!on) }
    }
}

/** A folder of settings: tap the title to open it. Only one is open at a time, so the sheet stays short. */
@Composable
private fun Folder(c: ReaderColors, title: String, open: Boolean, onToggle: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.chip.copy(alpha = 0.5f))) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, modifier = Modifier.weight(1f), color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(if (open) "\u25BE" else "\u25B8", color = c.ink.copy(alpha = 0.6f), fontSize = 16.sp)
        }
        if (open) {
            Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                content()
            }
        }
    }
}

/**
 * All the look settings, in folders: Page (margins and space), Text (layout, font, spacing, alignment), Header and footer, Display
 * (brightness, columns, screen). Used by the reader's text sheet and by Settings → Reader defaults (without brightness, which only
 * makes sense while reading). Colours come from [c], so it matches the page theme in both places.
 */
@Composable
fun ReaderLookControls(
    look: ReaderLook,
    onChange: (ReaderLook) -> Unit,
    c: ReaderColors,
    showBrightness: Boolean,
    modifier: Modifier = Modifier,
) {
    var open by rememberSaveable { mutableStateOf("Text") }
    fun folder(name: String): () -> Unit = { open = if (open == name) "" else name }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Folder(c, "Page", open == "Page", folder("Page")) {
            Slide(c, "Side margins", "${(look.margins * 100).roundToInt()}%", look.margins, 0.5f..2.5f) { onChange(look.copy(margins = tenth(it))) }
            Slide(c, "Top space", "${look.topSpace.roundToInt()} dp", look.topSpace, SPACE_MIN..SPACE_MAX) { onChange(look.copy(topSpace = it.roundToInt().toFloat())) }
            Slide(c, "Bottom space", "${look.bottomSpace.roundToInt()} dp", look.bottomSpace, SPACE_MIN..SPACE_MAX) { onChange(look.copy(bottomSpace = it.roundToInt().toFloat())) }
            Section(c, "Columns") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(c, "Auto", selected = look.columns == 0) { onChange(look.copy(columns = 0)) }
                    Pill(c, "One", selected = look.columns == 1) { onChange(look.copy(columns = 1)) }
                }
            }
        }
        Folder(c, "Text", open == "Text", folder("Text")) {
            Section(c, "Layout") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(c, "Book's own", selected = !look.custom) { onChange(look.copy(custom = false)) }
                    Pill(c, "Custom", selected = look.custom) { onChange(look.copy(custom = true)) }
                    Pill(c, "Readest", selected = false) { onChange(ReaderLook.readest(look.brightness)) }
                }
            }
            if (look.custom) {
                Section(c, "Font") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Serif", "Sans", "Mono").forEachIndexed { i, name ->
                            Pill(c, name, selected = look.fontFamily == i) { onChange(look.copy(fontFamily = i)) }
                        }
                    }
                }
                Slide(c, "Font weight", "${(look.fontWeight * 100).roundToInt()}%", look.fontWeight, 0.5f..2.0f) { onChange(look.copy(fontWeight = (it * 20f).roundToInt() / 20f)) }
                Slide(c, "Line spacing", "%.2f".format(look.lineSpacing), look.lineSpacing, 1.0f..2.2f) { onChange(look.copy(lineSpacing = (it * 20f).roundToInt() / 20f)) }
                Slide(c, "Paragraph spacing", "%.1f".format(look.paragraphSpacing), look.paragraphSpacing, 0f..2f) { onChange(look.copy(paragraphSpacing = tenth(it))) }
                Slide(c, "First-line indent", "%.1f".format(look.indent), look.indent, 0f..3f) { onChange(look.copy(indent = tenth(it))) }
                Slide(c, "Letter spacing", "%.2f".format(look.letterSpacing), look.letterSpacing, 0f..0.5f) { onChange(look.copy(letterSpacing = (it * 50f).roundToInt() / 50f)) }
                Slide(c, "Word spacing", "%.2f".format(look.wordSpacing), look.wordSpacing, 0f..1f) { onChange(look.copy(wordSpacing = (it * 20f).roundToInt() / 20f)) }
                Section(c, "Alignment") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(c, "Left", selected = !look.justify) { onChange(look.copy(justify = false)) }
                        Pill(c, "Justified", selected = look.justify) { onChange(look.copy(justify = true)) }
                    }
                }
                Toggle(c, "Hyphenation", "Break long words at the end of a line", look.hyphens) { onChange(look.copy(hyphens = it)) }
            } else {
                Text("Choose Custom to change the font, weight and spacing.", color = c.ink.copy(alpha = 0.55f), fontSize = 12.sp)
            }
        }
        Folder(c, "Header and footer", open == "Header and footer", folder("Header and footer")) {
            Toggle(c, "Chapter name at the top", null, look.showHeader) { onChange(look.copy(showHeader = it)) }
            Slide(c, "Header position", "${look.headerSpace.roundToInt()} dp", look.headerSpace, HEADER_MIN..HEADER_MAX) { onChange(look.copy(headerSpace = it.roundToInt().toFloat())) }
            Slide(c, "Header text size", "${look.headerSize.roundToInt()} sp", look.headerSize, 8f..20f) { onChange(look.copy(headerSize = it.roundToInt().toFloat())) }
            Section(c, "Bottom of the page") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(FOOTER_LEFT_PAGES to "Pages left", FOOTER_PERCENT to "Percent", FOOTER_TOTAL to "Page / total").forEach { (bit, name) ->
                        Pill(c, name, selected = look.footerItems and bit != 0) { onChange(look.copy(footerItems = look.footerItems xor bit)) }
                    }
                }
            }
            Slide(c, "Bottom text size", "${look.footerSize.roundToInt()} sp", look.footerSize, 8f..20f) { onChange(look.copy(footerSize = it.roundToInt().toFloat())) }
        }
        Folder(c, "Display", open == "Display", folder("Display")) {
            if (showBrightness) {
                val auto = look.brightness < 0f
                Section(c, "Brightness", if (auto) "Same as phone" else "${(look.brightness * 100).roundToInt()}%") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PbSlider(
                            value = if (auto) 0.5f else look.brightness,
                            onValueChange = { onChange(look.copy(brightness = it.coerceIn(0.05f, 1f))) },
                            valueRange = 0.05f..1f,
                            trackColor = c.ink.copy(alpha = 0.15f),
                            modifier = Modifier.weight(1f),
                        )
                        Spacer(Modifier.width(8.dp))
                        Pill(c, "Auto", selected = auto) { onChange(look.copy(brightness = -1f)) }
                    }
                }
            }
            Toggle(c, "Keep screen on", "Stops the screen from turning off while you read", look.keepScreenOn) { onChange(look.copy(keepScreenOn = it)) }
        }
    }
}

/**
 * The "Text" sheet at the bottom of the reader. It sits over the page without dimming it, so every change is
 * visible straight away.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderLookSheet(
    themeIndex: Int,
    themeChoice: Int,
    fontSize: Double,
    look: ReaderLook,
    onFontSize: (Double) -> Unit,
    onTheme: (Int) -> Unit,
    onLook: (ReaderLook) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = readerColors(themeIndex)
    BackHandler(onBack = onClose)
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(c.card)
            // swallow touches so nothing reaches the book underneath
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
            .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
            .heightIn(max = 520.dp)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Reader settings",
                modifier = Modifier.weight(1f),
                color = c.ink,
                fontFamily = PbSerif,
                fontSize = 22.sp,
                fontWeight = FontWeight.Medium,
            )
            Pill(c, "Done", onClick = onClose)
        }
        Section(c, "Font size", "${(fontSize * 100).roundToInt()}%") {
            PbSlider(
                value = fontSize.toFloat(),
                onValueChange = { onFontSize(tenth(it).toDouble()) },
                valueRange = 0.6f..2.5f,
                trackColor = c.ink.copy(alpha = 0.15f),
            )
        }
        Section(c, "Page colors") {
            ThemePickerRow(c, themeChoice, onPick = onTheme)
        }
        ReaderLookControls(look = look, onChange = onLook, c = c, showBrightness = true)
        Box(Modifier.height(4.dp))
    }
}
