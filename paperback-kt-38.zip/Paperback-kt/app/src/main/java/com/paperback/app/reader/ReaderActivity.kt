package com.paperback.app.reader

import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.core.view.ViewCompat
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Alignment
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.ComposeView
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commitNow
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.paperback.app.PaperbackApp
import com.paperback.app.R
import com.paperback.app.data.Bookmark
import com.paperback.app.data.Highlight
import com.paperback.app.data.HighlightColors
import com.paperback.app.data.ReaderLook
import com.paperback.app.data.EpubSizes
import com.paperback.app.data.LocationCounter
import com.paperback.app.data.ReaderPlace
import com.paperback.app.data.TocRef
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PaperbackTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Collections
import java.util.zip.ZipFile
import kotlin.math.ceil
import org.json.JSONObject
import org.json.JSONTokener
import org.readium.r2.navigator.DecorableNavigator
import org.readium.r2.navigator.Decoration
import org.readium.r2.navigator.epub.EpubNavigatorFragment
import org.readium.r2.navigator.input.InputListener
import org.readium.r2.navigator.input.TapEvent
import org.readium.r2.navigator.util.DirectionalNavigationAdapter
import org.readium.r2.shared.publication.Link
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.services.search.search
import org.readium.r2.shared.publication.services.locateProgression
import org.readium.r2.shared.publication.services.positions

class ReaderActivity : FragmentActivity() {

    private val graph get() = (application as PaperbackApp).graph

    private var session: ReaderSession? = null
    private var navigator: EpubNavigatorFragment? = null
    private val tracker = ReadingTracker()

    private val chromeVisible = mutableStateOf(false)
    private val locatorState = mutableStateOf<Locator?>(null)
    private val fontSizeState = mutableDoubleStateOf(1.0)
    /** What the reader picked: a page colour, or -1 (Auto) to follow the phone. */
    private val themeState = mutableIntStateOf(ReaderThemes.AUTO)

    /** True while the phone is in its dark theme; it decides the page colour while the choice is Auto. */
    private val darkState = mutableStateOf(false)

    private val bookmarks = mutableStateOf<List<Bookmark>>(emptyList())
    private val highlights = mutableStateOf<List<Highlight>>(emptyList())
    private val panelOpen = mutableStateOf(false)
    private val editor = mutableStateOf<NoteEditorState?>(null)

    private val panelTab = mutableIntStateOf(0)
    private val toc = mutableStateOf<List<TocEntry>>(emptyList())
    private val lookOpen = mutableStateOf(false)
    private val lookState = mutableStateOf(ReaderLook())
    private val searchOpen = mutableStateOf(false)
    private val searchUi = mutableStateOf(SearchUi())
    private var searchJob: Job? = null

    // Chapter name and "pages left" in the margins (see ReaderMarginInfo).
    private var tocRefs: List<TocRef> = emptyList()
    private var resourceByHref: Map<String, Int> = emptyMap()
    private val positionsPerResource = mutableStateOf<List<Int>>(emptyList())
    private val screenCount = mutableIntStateOf(0)
    private val screenHref = mutableStateOf("")
    private var measureJob: Job? = null
    private var resourceCount = 0
    private var hrefByIndex: List<String> = emptyList()
    private val locationCounter = mutableStateOf<LocationCounter?>(null)
    private var settleUntil = 0L

    /** The little menu that appears when you select text: adds "Highlight" and "Note". */
    private val selectionCallback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            menu.add(Menu.NONE, MENU_HIGHLIGHT, 0, "Highlight")
            menu.add(Menu.NONE, MENU_NOTE, 1, "Note")
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            val wantsNote = when (item.itemId) {
                MENU_HIGHLIGHT -> false
                MENU_NOTE -> true
                else -> return false
            }
            val nav = navigator
            val s = session
            if (nav == null || s == null) {
                mode.finish()
                return true
            }
            lifecycleScope.launch {
                // Read the selection first, then close the menu (closing it clears the selection).
                val selection = nav.currentSelection()
                if (selection != null) {
                    val quote = selection.locator.text.highlight.orEmpty()
                    if (wantsNote) {
                        editor.value = NoteEditorState(null, selection.locator, quote, "", HighlightColors.DEFAULT)
                    } else {
                        graph.repo.addHighlight(s.book.id, selection.locator, quote, "", HighlightColors.DEFAULT)
                        highlights.value = graph.repo.highlights(s.book.id)
                    }
                }
                mode.finish()
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val s = graph.readerSession
        if (s == null) {
            // The app was killed and Android is restoring this screen with nothing to show. The Readium
            // fragment still needs *a* factory to be restored, so give it a dummy one and leave.
            supportFragmentManager.fragmentFactory = EpubNavigatorFragment.createDummyFactory()
            super.onCreate(null)
            finish()
            return
        }
        session = s
        fontSizeState.doubleValue = graph.settings.fontSize
        darkState.value = systemDark()
        themeState.intValue = graph.settings.theme
        lookState.value = graph.settings.look
        toc.value = buildToc(s)
        buildPlaceData(s)

        // IMPORTANT: the factory has to be set before super.onCreate().
        supportFragmentManager.fragmentFactory = s.navigatorFactory.createFragmentFactory(
            initialLocator = s.initialLocator,
            initialPreferences = graph.settings.toEpubPreferences(darkState.value),
            configuration = EpubNavigatorFragment.Configuration(selectionActionModeCallback = selectionCallback),
        )
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_reader)
        applyBand(lookState.value)
        applyKeepScreenOn(lookState.value.keepScreenOn)
        applyPageBackground()
        loadPositions(s)

        if (savedInstanceState == null) {
            supportFragmentManager.commitNow {
                add(R.id.navigator_container, EpubNavigatorFragment::class.java, Bundle(), NAV_TAG)
            }
        }
        val nav = supportFragmentManager.findFragmentByTag(NAV_TAG) as EpubNavigatorFragment
        navigator = nav

        // Tap near the left/right edge turns the page; tap in the middle shows or hides the controls.
        nav.addInputListener(DirectionalNavigationAdapter(nav))
        nav.addInputListener(
            object : InputListener {
                override fun onTap(event: TapEvent): Boolean {
                    chromeVisible.value = !chromeVisible.value
                    return true
                }
            },
        )

        // Tap on a highlight: open it to edit the note, change the colour or delete it.
        nav.addDecorationListener(
            HIGHLIGHT_GROUP,
            object : DecorableNavigator.Listener {
                override fun onDecorationActivated(event: DecorableNavigator.OnActivatedEvent): Boolean {
                    val h = highlights.value.firstOrNull { it.id == event.decoration.id } ?: return false
                    editor.value = NoteEditorState(h.id, null, h.text, h.note, h.color)
                    return true
                }
            },
        )

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                nav.currentLocator.collect { onLocator(s, it) }
            }
        }

        // Keep the highlights drawn on the page in sync with the list.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                snapshotFlow { highlights.value }.collect { list ->
                    nav.applyDecorations(toDecorations(list), HIGHLIGHT_GROUP)
                }
            }
        }

        lifecycleScope.launch {
            bookmarks.value = graph.repo.bookmarks(s.book.id)
            highlights.value = graph.repo.highlights(s.book.id)
        }

        val pace = Stats.paceSecondsPerPosition(graph.repo.sessions.value)

        findViewById<ComposeView>(R.id.chrome).setContent {
            PaperbackTheme {
                val position = locatorState.value?.locations?.position ?: s.book.position
                Box(Modifier.fillMaxSize()) {
                    val place = placeInfo(locatorState.value)
                    ReaderMarginInfo(
                        themeIndex = effectiveTheme(),
                        hidden = chromeVisible.value,
                        chapter = place.chapter,
                        pagesLeft = place.pagesLeft,
                        position = if (place.location > 0) place.location else locatorState.value?.locations?.position ?: 0,
                        totalPositions = if (place.location > 0) place.locationTotal else s.totalPositions,
                        headerSpace = lookState.value.headerSpace,
                        bottomSpace = lookState.value.bottomSpace,
                        percent = (locatorState.value?.locations?.totalProgression ?: s.book.progress.toDouble()).toFloat(),
                        footerItems = lookState.value.footerItems,
                        showHeader = lookState.value.showHeader,
                        headerSize = lookState.value.headerSize,
                        footerSize = lookState.value.footerSize,
                    )
                    ReaderChrome(
                        title = s.book.title,
                        visible = chromeVisible.value,
                        position = position,
                        totalPositions = s.totalPositions,
                        shownPosition = if (place.location > 0) place.location else position,
                        shownTotal = if (place.location > 0) place.locationTotal else s.totalPositions,
                        progress = (locatorState.value?.locations?.totalProgression ?: s.book.progress.toDouble()).toFloat(),
                        secondsPerPage = pace,
                        fontSize = fontSizeState.doubleValue,
                        themeIndex = effectiveTheme(),
                        themeChoice = themeState.intValue,
                        brightness = lookState.value.brightness,
                        style = chromeStyle,
                        bookmarked = bookmarks.value.any { it.position == position },
                        onBack = { finish() },
                        onToggleBookmark = { toggleBookmark() },
                        onOpenPanel = { openPanel(1) },
                        onOpenContents = { openPanel(0) },
                        onOpenSearch = {
                            chromeVisible.value = false
                            searchOpen.value = true
                        },
                        onOpenLook = {
                            chromeVisible.value = false
                            lookOpen.value = true
                        },
                        onSeek = { fraction ->
                            // locateProgression is a suspend function, so it needs a coroutine.
                            lifecycleScope.launch {
                                s.publication.locateProgression(fraction.toDouble())?.let { nav.go(it) }
                            }
                        },
                        onFontSize = { delta -> changeFontSize(delta) },
                        onTheme = { index -> changeTheme(index) },
                        onBrightness = { value -> changeLook(lookState.value.copy(brightness = value)) },
                    )

                    if (panelOpen.value) {
                        ReaderPanel(
                            themeIndex = effectiveTheme(),
                            initialTab = panelTab.intValue,
                            toc = toc.value,
                            currentHref = locatorState.value?.href?.toString(),
                            bookmarks = bookmarks.value,
                            highlights = highlights.value,
                            onGo = { json -> goTo(json) },
                            onDeleteBookmark = { b -> deleteBookmark(b) },
                            onDeleteHighlight = { h -> deleteHighlight(h) },
                            onClose = { panelOpen.value = false },
                        )
                    }

                    if (lookOpen.value) {
                        ReaderLookSheet(
                            themeIndex = effectiveTheme(),
                            themeChoice = themeState.intValue,
                            fontSize = fontSizeState.doubleValue,
                            look = lookState.value,
                            onFontSize = { value -> setFontSize(value) },
                            onTheme = { index -> changeTheme(index) },
                            onLook = { look -> changeLook(look) },
                            onClose = { lookOpen.value = false },
                            modifier = Modifier.align(Alignment.BottomStart),
                        )
                    }

                    if (searchOpen.value) {
                        ReaderSearchPanel(
                            themeIndex = effectiveTheme(),
                            ui = searchUi.value,
                            onQuery = { q -> searchUi.value = searchUi.value.copy(query = q) },
                            onSubmit = { runSearch() },
                            onGo = { hit -> goToHit(hit) },
                            onClose = { closeSearch() },
                        )
                    }

                    editor.value?.let { state ->
                        NoteEditorDialog(
                            state = state,
                            themeIndex = effectiveTheme(),
                            onSave = { note, color -> saveEditor(state, note, color) },
                            onDelete = state.highlightId?.let { id -> { deleteHighlightById(id) } },
                            onDismiss = { editor.value = null },
                        )
                    }
                }
            }
        }

        hideSystemBars()
        applyBrightness(lookState.value.brightness)
    }

    // ---- reading position and time --------------------------------------------------------

    private fun onLocator(s: ReaderSession, locator: Locator) {
        locatorState.value = locator
        scheduleMeasure(false, 150L, 450L, 1000L, 2000L)
        tracker.onPosition(System.currentTimeMillis(), locator.locations.position ?: 0)
        graph.appScope.launch { graph.repo.saveProgress(s.book.id, locator) }
    }

    private fun changeFontSize(delta: Double) {
        val next = (fontSizeState.doubleValue + delta).coerceIn(0.6, 2.5)
        fontSizeState.doubleValue = next
        graph.settings.fontSize = next
        navigator?.submitPreferences(graph.settings.toEpubPreferences(darkState.value))
        relayout()
    }

    private fun setFontSize(value: Double) {
        val next = value.coerceIn(0.6, 2.5)
        fontSizeState.doubleValue = next
        graph.settings.fontSize = next
        navigator?.submitPreferences(graph.settings.toEpubPreferences(darkState.value))
        relayout()
    }

    private fun changeLook(look: ReaderLook) {
        lookState.value = look
        graph.settings.look = look
        applyBand(look)
        applyKeepScreenOn(look.keepScreenOn)
        navigator?.submitPreferences(graph.settings.toEpubPreferences(darkState.value))
        relayout()
        applyBrightness(look.brightness)
    }

    /** A value from 0.05 to 1 dims or brightens this screen only; below zero follows the phone again. */
    private fun applyBrightness(value: Float) {
        val attrs = window.attributes
        attrs.screenBrightness = if (value < 0f) android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else value.coerceIn(0.05f, 1f)
        window.attributes = attrs
    }

    private fun changeTheme(index: Int) {
        themeState.intValue = index
        graph.settings.theme = index
        navigator?.submitPreferences(graph.settings.toEpubPreferences(darkState.value))
        applyPageBackground()
    }

    // ---- bookmarks, highlights, notes -----------------------------------------------------

    private fun toggleBookmark() {
        val s = session ?: return
        val loc = locatorState.value ?: return
        val position = loc.locations.position ?: return
        lifecycleScope.launch {
            val existing = bookmarks.value.firstOrNull { it.position == position }
            if (existing != null) graph.repo.removeBookmark(existing.id) else graph.repo.addBookmark(s.book.id, loc)
            bookmarks.value = graph.repo.bookmarks(s.book.id)
        }
    }

    private fun deleteBookmark(b: Bookmark) {
        val s = session ?: return
        lifecycleScope.launch {
            graph.repo.removeBookmark(b.id)
            bookmarks.value = graph.repo.bookmarks(s.book.id)
        }
    }

    private fun saveEditor(state: NoteEditorState, note: String, color: Int) {
        val s = session ?: return
        editor.value = null
        lifecycleScope.launch {
            val id = state.highlightId
            val locator = state.locator
            if (id != null) graph.repo.updateHighlight(id, note, color)
            else if (locator != null) graph.repo.addHighlight(s.book.id, locator, state.quote, note, color)
            highlights.value = graph.repo.highlights(s.book.id)
        }
    }

    private fun deleteHighlight(h: Highlight) = deleteHighlightById(h.id)

    private fun deleteHighlightById(id: String) {
        val s = session ?: return
        editor.value = null
        lifecycleScope.launch {
            graph.repo.removeHighlight(id)
            highlights.value = graph.repo.highlights(s.book.id)
        }
    }

    private fun openPanel(tab: Int) {
        panelTab.intValue = tab
        chromeVisible.value = false
        panelOpen.value = true
    }

    /** The book's table of contents as a flat list, each line remembering how deep it is nested. */
    private fun buildToc(s: ReaderSession): List<TocEntry> {
        val out = ArrayList<TocEntry>()
        fun walk(links: List<Link>, depth: Int) {
            for (link in links) {
                val locator = s.publication.locatorFromLink(link)
                if (locator != null) {
                    out += TocEntry(
                        title = link.title?.trim().orEmpty().ifBlank { "Untitled" },
                        depth = depth,
                        locatorJson = locator.toJSON().toString(),
                        href = locator.href.toString(),
                    )
                }
                walk(link.children, depth + 1)
            }
        }
        walk(s.publication.tableOfContents, 0)
        return out
    }

    // ---- chapter name and "pages left in chapter" in the margins -----------------------------

    private class PlaceInfo(val chapter: String, val pagesLeft: Int, val location: Int = 0, val locationTotal: Int = 0)

    /** Which file of the book each contents entry starts in, and which file every href is (in reading order). */
    private fun buildPlaceData(s: ReaderSession) {
        val byHref = HashMap<String, Int>()
        s.publication.readingOrder.forEachIndexed { i, link ->
            s.publication.locatorFromLink(link)?.let { byHref[it.href.toString().substringBefore('#')] = i }
        }
        resourceByHref = byHref
        hrefByIndex = List(s.publication.readingOrder.size) { i -> byHref.entries.firstOrNull { it.value == i }?.key.orEmpty() }
        resourceCount = s.publication.readingOrder.size
        val refs = ArrayList<TocRef>()
        fun walk(links: List<Link>) {
            for (link in links) {
                val locator = s.publication.locatorFromLink(link)
                val resource = locator?.let { byHref[it.href.toString().substringBefore('#')] } ?: -1
                refs += TocRef(link.title?.trim().orEmpty(), resource)
                walk(link.children)
            }
        }
        walk(s.publication.tableOfContents)
        tocRefs = refs
    }

    /** How many reading "positions" each file has (Readium's own count, the same one the "2 / 196" counter uses). */
    private fun loadPositions(s: ReaderSession) {
        lifecycleScope.launch {
            val all = s.publication.positions()
            val counts = withContext(Dispatchers.Default) {
                val c = IntArray(resourceCount)
                for (p in all) {
                    val r = resourceByHref[p.href.toString().substringBefore('#')] ?: continue
                    c[r]++
                }
                c.toList()
            }
            positionsPerResource.value = counts
            // The unpacked size of every file of the book, read from the EPUB (a zip) itself; the "25 / 136" counter is cut from it.
            val sizes = withContext(Dispatchers.IO) {
                val entries = runCatching {
                    ZipFile(File(s.book.filePath)).use { z -> Collections.list(z.entries()).associate { it.name to it.size } }
                }.getOrDefault(emptyMap())
                if (entries.isEmpty()) null
                else List(resourceCount) { i -> EpubSizes.sizeOf(entries, hrefByIndex[i]) ?: (counts.getOrElse(i) { 0 } * 3072L) }
            }
            if (sizes != null) locationCounter.value = LocationCounter(sizes)
        }
    }

    private fun placeInfo(locator: Locator?): PlaceInfo {
        locator ?: return PlaceInfo("", 0)
        val href = locator.href.toString().substringBefore('#')
        val resource = resourceByHref[href] ?: return PlaceInfo("", 0)
        val chapter = ReaderPlace.chapterIndex(tocRefs, resource)
        val title = if (chapter >= 0) tocRefs[chapter].title else ""
        val counter = locationCounter.value
        val location = counter?.current(resource, locator.locations.progression ?: 0.0) ?: 0
        val locationTotal = counter?.total ?: 0
        val screens = screenCount.intValue
        if (screens <= 0 || screenHref.value != href) return PlaceInfo(title, 0, location, locationTotal)
        val perResource = positionsPerResource.value
        val end = if (chapter >= 0) ReaderPlace.chapterEnd(tocRefs, chapter, resourceCount) else resource + 1
        val left = ReaderPlace.pagesLeft(
            screens = screens,
            screenIndex = ReaderPlace.screenIndex(locator.locations.progression ?: 0.0, screens),
            positionsHere = perResource.getOrElse(resource) { 0 },
            positionsAfter = ReaderPlace.positionsAfter(perResource, resource, end),
        )
        return PlaceInfo(title, left, location, locationTotal)
    }

    /** The page changed shape (text size, margins, font): forget the old screen count and measure again. */
    private fun relayout() {
        screenHref.value = ""
        settleUntil = System.currentTimeMillis() + 4000L
        scheduleMeasure(true, 500L, 1000L, 2000L, 3500L)
    }

    /** The text is measured a few times, because the page can still be laying itself out (images, fonts) for a moment. */
    private fun scheduleMeasure(settle: Boolean, vararg delaysMs: Long) {
        // While a size change is settling its own measuring job runs; a page turn must not cancel it.
        if (!settle && System.currentTimeMillis() < settleUntil) return
        measureJob?.cancel()
        measureJob = lifecycleScope.launch {
            for (d in delaysMs) {
                delay(d)
                measureScreens()
            }
        }
    }

    /** Asks the page on screen how wide it is: its width divided by the screen width is the number of pages in this file. */
    private fun measureScreens() {
        val root = navigator?.view ?: return
        val web = visibleWebView(root) ?: return
        val href = locatorState.value?.href?.toString()?.substringBefore('#') ?: return
        web.evaluateJavascript(MEASURE_JS) { raw ->
            val text = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull() ?: return@evaluateJavascript
            val parts = text.split(',', limit = 3)
            val width = parts.getOrNull(0)?.toDoubleOrNull() ?: return@evaluateJavascript
            val inner = parts.getOrNull(1)?.toDoubleOrNull() ?: return@evaluateJavascript
            val path = Uri.decode(parts.getOrNull(2).orEmpty())
            // Only trust it when the page on screen really is the file we are in (same file name) (during a page change it may not be yet).
            if (inner <= 0.0 || path.substringAfterLast('/') != Uri.decode(href).substringAfterLast('/')) return@evaluateJavascript
            val n = ceil(width / inner - 0.25).toInt() // a spread can end on a half screen
            if (n >= 1) {
                screenCount.intValue = n
                screenHref.value = href
            }
        }
    }

    private fun visibleWebView(root: View): WebView? {
        var best: WebView? = null
        var bestWidth = 0
        fun walk(v: View) {
            if (v is WebView) {
                val r = Rect()
                if (v.isShown && v.getGlobalVisibleRect(r) && r.width() > bestWidth) {
                    best = v
                    bestWidth = r.width()
                }
            } else if (v is ViewGroup) {
                for (i in 0 until v.childCount) walk(v.getChildAt(i))
            }
        }
        walk(root)
        return best
    }

    private fun applyKeepScreenOn(on: Boolean) {
        if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    /** Sets how far the text stays from the top and bottom edges of the screen (the Top and Bottom sliders). */
    private fun applyBand(look: ReaderLook) {
        val root = findViewById<View>(R.id.reader_root)
        val container = findViewById<View>(R.id.navigator_container)
        // The same frame as Readest: fixed distances from the screen edges, the same as the strips drawn in ReaderMarginInfo.
        val d = resources.displayMetrics.density
        container.setPadding(0, (look.topSpace * d).toInt(), 0, (look.bottomSpace * d).toInt())
    }

    /** Behind the strips the page colour shows, so they look like part of the page. */
    private fun applyPageBackground() {
        findViewById<View>(R.id.reader_root)?.setBackgroundColor(readerColors(effectiveTheme()).page.toArgb())
    }

    // ---- search inside the book ----------------------------------------------------------

    private fun runSearch() {
        val s = session ?: return
        val query = searchUi.value.query.trim()
        searchJob?.cancel()
        clearSearchMark()
        if (query.length < 2) {
            searchUi.value = searchUi.value.copy(hits = emptyList(), running = false, done = false, capped = false, error = null)
            return
        }
        searchUi.value = searchUi.value.copy(hits = emptyList(), running = true, done = false, capped = false, error = null)
        searchJob = lifecycleScope.launch {
            val hits = ArrayList<SearchHit>()
            var error: String? = null
            var capped = false
            val iterator = s.publication.search(query)
            if (iterator == null) {
                error = "This book can't be searched."
            } else {
                try {
                    while (true) {
                        val page = iterator.next().getOrNull() ?: break
                        for (locator in page.locators) {
                            hits += SearchHit(
                                locatorJson = locator.toJSON().toString(),
                                before = locator.text.before.orEmpty(),
                                hit = locator.text.highlight.orEmpty(),
                                after = locator.text.after.orEmpty(),
                                chapter = locator.title,
                                progress = (locator.locations.totalProgression ?: 0.0).toFloat(),
                            )
                        }
                        searchUi.value = searchUi.value.copy(hits = hits.toList())
                        if (hits.size >= MAX_SEARCH_HITS) {
                            capped = true
                            break
                        }
                    }
                } finally {
                    iterator.close()
                }
            }
            searchUi.value = searchUi.value.copy(hits = hits.toList(), running = false, done = true, capped = capped, error = error)
        }
    }

    private fun goToHit(hit: SearchHit) {
        val nav = navigator ?: return
        val locator = runCatching { Locator.fromJSON(JSONObject(hit.locatorJson)) }.getOrNull() ?: return
        searchOpen.value = false
        chromeVisible.value = false
        lifecycleScope.launch {
            nav.go(locator)
            // Mark the match on the page until the next search (or until the book is closed).
            nav.applyDecorations(
                listOf(Decoration(id = "match", locator = locator, style = Decoration.Style.Highlight(tint = SEARCH_TINT))),
                SEARCH_GROUP,
            )
        }
    }

    private fun closeSearch() {
        searchOpen.value = false
    }

    private fun clearSearchMark() {
        val nav = navigator ?: return
        lifecycleScope.launch { nav.applyDecorations(emptyList(), SEARCH_GROUP) }
    }

    private fun goTo(locatorJson: String) {
        val nav = navigator ?: return
        val locator = runCatching { Locator.fromJSON(JSONObject(locatorJson)) }.getOrNull() ?: return
        panelOpen.value = false
        chromeVisible.value = false
        lifecycleScope.launch { nav.go(locator) }
    }

    private fun toDecorations(list: List<Highlight>): List<Decoration> = list.mapNotNull { h ->
        val locator = runCatching { Locator.fromJSON(JSONObject(h.locatorJson)) }.getOrNull() ?: return@mapNotNull null
        Decoration(id = h.id, locator = locator, style = Decoration.Style.Highlight(tint = h.color))
    }

    // ---- system bars: hidden for the whole reading session, so nothing resizes when controls toggle ----

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        val dark = systemDark()
        if (session != null && dark != darkState.value) {
            darkState.value = dark
            // On Auto the page changes colour with the phone's theme, as soon as it happens.
            if (themeState.intValue < 0) {
                navigator?.submitPreferences(graph.settings.toEpubPreferences(dark))
                applyPageBackground()
            }
        }
        if (session != null) relayout() // turning the phone changes how many screens a chapter has
    }

    private fun systemDark(): Boolean =
        (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    /** The page colour on screen: the reader's choice, or for Auto White / Black following the phone. */
    private fun effectiveTheme(): Int = ReaderThemes.resolve(themeState.intValue, darkState.value)

    /** Which layout of the bottom controls Settings → Reader defaults chose. */
    private val chromeStyle: Int get() = graph.settings.chromeStyle

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && session != null) hideSystemBars() // e.g. after a dialog closes
    }

    // ---- lifecycle ------------------------------------------------------------------------

    override fun onResume() {
        super.onResume()
        tracker.resume(System.currentTimeMillis())
    }

    override fun onPause() {
        super.onPause()
        val s = session ?: return
        tracker.pause(System.currentTimeMillis())?.let { flush ->
            // appScope, not lifecycleScope: this has to finish even if the activity is going away.
            graph.appScope.launch { graph.repo.addSession(s.book.id, flush.startMs, flush.seconds, flush.pages, flush.fromPos, flush.toPos) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing && session != null) graph.closeReader()
    }

    private companion object {
        const val NAV_TAG = "navigator"
        const val MEASURE_JS =
            "(function(){var e=document.scrollingElement||document.documentElement;" +
                "return [e.scrollWidth,window.innerWidth,location.pathname].join(',');})()"
        const val HIGHLIGHT_GROUP = "highlights"
        const val SEARCH_GROUP = "search"
        const val SEARCH_TINT = 0xFFFFC857.toInt()
        const val MAX_SEARCH_HITS = 200
        const val MENU_HIGHLIGHT = 1
        const val MENU_NOTE = 2
    }
}
