package com.paperback.app.data

import android.content.Context
import org.readium.r2.navigator.epub.EpubPreferences
import org.readium.r2.navigator.preferences.ColumnCount
import org.readium.r2.navigator.preferences.FontFamily
import org.readium.r2.navigator.preferences.TextAlign
import org.readium.r2.navigator.preferences.Color as ReadiumColor
import org.readium.r2.navigator.preferences.Theme
import com.paperback.app.reader.ReaderThemes

/**
 * How the page is laid out. While [custom] is off the book keeps its own fonts, spacing and alignment
 * (that is what Readium calls publisher styles); turning it on applies [fontFamily], [lineSpacing], [justify], [paragraphSpacing] and [indent].
 * The Readest look is [ReaderLook.readest]: Readest's own defaults (sans, line height 1.4, left aligned, 0.6 between paragraphs, no indent).
 * [margins] and [brightness] work either way. [brightness] below zero means "follow the phone".
 */
data class ReaderLook(
    val custom: Boolean = false,
    /** 0 = serif, 1 = sans, 2 = mono */
    val fontFamily: Int = 0,
    val lineSpacing: Float = 1.5f,
    val margins: Float = 1.0f,
    val justify: Boolean = true,
    val brightness: Float = -1f,
    /** Space between paragraphs, in lines of text (Readium's rem). Readest uses 0.6. */
    val paragraphSpacing: Float = 0.6f,
    /** First-line indent in em. Readest uses 0. */
    val indent: Float = 0f,
    /** Distance in dp from the top edge of the screen to the first line of text. 64 = Readest's, 0 = the text starts at the very edge. */
    val topSpace: Float = DEFAULT_TOP_SPACE,
    /** Distance in dp from the bottom edge of the screen to the last line of text. 44 = Readest's, 0 = the very edge. */
    val bottomSpace: Float = DEFAULT_BOTTOM_SPACE,
    /** Distance in dp from the top edge of the screen to the chapter name ("header helper"). It is independent of [topSpace]. */
    val headerSpace: Float = DEFAULT_HEADER_SPACE,
    /** Which small texts show at the bottom of the page: a mix of [FOOTER_LEFT_PAGES], [FOOTER_PERCENT] and [FOOTER_TOTAL]. */
    val footerItems: Int = FOOTER_LEFT_PAGES or FOOTER_TOTAL,
    /** Font weight, 1 = normal (custom layout only). */
    val fontWeight: Float = 1f,
    /** Extra space between letters and between words, in em (custom layout only). */
    val letterSpacing: Float = 0f,
    val wordSpacing: Float = 0f,
    /** Break long words with a hyphen at the end of a line (custom layout only). */
    val hyphens: Boolean = true,
    /** 0 = automatic (two columns on a wide screen), 1 = always one column. */
    val columns: Int = 0,
    /** The chapter name at the top of the page, and the size of the small texts around the page, in sp. */
    val showHeader: Boolean = true,
    val headerSize: Float = 12f,
    val footerSize: Float = 12f,
    /** Keep the screen on while reading. */
    val keepScreenOn: Boolean = false,
) {
    companion object {
        /** Readest's defaults on a phone, keeping the phone's brightness choice. */
        fun readest(brightness: Float) = ReaderLook(
            custom = true, fontFamily = 1, lineSpacing = 1.4f, margins = 1.0f, justify = false,
            brightness = brightness, paragraphSpacing = 0.6f, indent = 0f,
            topSpace = DEFAULT_TOP_SPACE, bottomSpace = DEFAULT_BOTTOM_SPACE, headerSpace = DEFAULT_HEADER_SPACE,
        )
    }
}

/** Bottom-of-page texts (bit flags): "4 pages left", "98.8%" and "492 / 496". */
const val FOOTER_LEFT_PAGES = 1
const val FOOTER_PERCENT = 2
const val FOOTER_TOTAL = 4
const val FOOTER_ALL = 7
const val DEFAULT_TOP_SPACE = 64f
const val DEFAULT_BOTTOM_SPACE = 44f
const val DEFAULT_HEADER_SPACE = 40f
const val SPACE_MIN = 0f
const val SPACE_MAX = 160f
const val HEADER_MIN = 0f
const val HEADER_MAX = 160f

/** The reader choices Paperback remembers. */
class ReaderSettings(context: Context) {
    private val sp = context.getSharedPreferences("reader", Context.MODE_PRIVATE)

    var fontSize: Double
        get() = sp.getFloat("fontSize", 1.0f).toDouble()
        set(v) = sp.edit().putFloat("fontSize", v.toFloat()).apply()

    /** The page colour (see [ReaderThemes]); -1, the default, follows the phone: white in the light theme, black in the dark one. */
    var theme: Int
        get() = sp.getInt("theme", ReaderThemes.AUTO).let { if (it in 0..5) it else ReaderThemes.AUTO }
        set(v) = sp.edit().putInt("theme", v).apply()

    /** The reader's bottom controls: 0 = compact card, 1 = quick settings, 2 = icon tiles. */
    var chromeStyle: Int
        get() = sp.getInt("chromeStyle", 0).coerceIn(0, 2)
        set(v) = sp.edit().putInt("chromeStyle", v).apply()

    /** PDF viewer: true turns pages right to left (manga). */
    var pdfRtl: Boolean
        get() = sp.getBoolean("pdfRtl", false)
        set(v) = sp.edit().putBoolean("pdfRtl", v).apply()

    var look: ReaderLook
        get() {
            val d = ReaderLook()
            return ReaderLook(
                custom = sp.getBoolean("custom", d.custom),
                fontFamily = sp.getInt("fontFamily", d.fontFamily).coerceIn(0, 2),
                lineSpacing = sp.getFloat("lineSpacing", d.lineSpacing).coerceIn(1.0f, 2.2f),
                margins = sp.getFloat("margins", d.margins).coerceIn(0.5f, 2.5f),
                justify = sp.getBoolean("justify", d.justify),
                brightness = sp.getFloat("brightness", d.brightness),
                paragraphSpacing = sp.getFloat("paragraphSpacing", d.paragraphSpacing).coerceIn(0f, 2f),
                indent = sp.getFloat("indent", d.indent).coerceIn(0f, 3f),
                // Older versions had one 0..1.5 "Top and bottom space" slider; turn it into the new dp values once.
                topSpace = (if (sp.contains("topSpace")) sp.getFloat("topSpace", d.topSpace)
                    else if (sp.contains("verticalSpace")) 20f + (DEFAULT_TOP_SPACE - 20f) * sp.getFloat("verticalSpace", 1f)
                    else d.topSpace).coerceIn(SPACE_MIN, SPACE_MAX),
                bottomSpace = (if (sp.contains("bottomSpace")) sp.getFloat("bottomSpace", d.bottomSpace)
                    else if (sp.contains("verticalSpace")) 20f + (DEFAULT_BOTTOM_SPACE - 20f) * sp.getFloat("verticalSpace", 1f)
                    else d.bottomSpace).coerceIn(SPACE_MIN, SPACE_MAX),
                headerSpace = sp.getFloat("headerSpace", d.headerSpace).coerceIn(HEADER_MIN, HEADER_MAX),
                footerItems = sp.getInt("footerItems", d.footerItems).and(FOOTER_ALL),
                fontWeight = sp.getFloat("fontWeight", d.fontWeight).coerceIn(0.5f, 2.0f),
                letterSpacing = sp.getFloat("letterSpacing", d.letterSpacing).coerceIn(0f, 0.5f),
                wordSpacing = sp.getFloat("wordSpacing", d.wordSpacing).coerceIn(0f, 1f),
                hyphens = sp.getBoolean("hyphens", d.hyphens),
                columns = sp.getInt("columns", d.columns).coerceIn(0, 1),
                showHeader = sp.getBoolean("showHeader", d.showHeader),
                headerSize = sp.getFloat("headerSize", d.headerSize).coerceIn(8f, 20f),
                footerSize = sp.getFloat("footerSize", d.footerSize).coerceIn(8f, 20f),
                keepScreenOn = sp.getBoolean("keepScreenOn", d.keepScreenOn),
            )
        }
        set(v) {
            sp.edit()
                .putBoolean("custom", v.custom)
                .putInt("fontFamily", v.fontFamily)
                .putFloat("lineSpacing", v.lineSpacing)
                .putFloat("margins", v.margins)
                .putBoolean("justify", v.justify)
                .putFloat("brightness", v.brightness)
                .putFloat("paragraphSpacing", v.paragraphSpacing)
                .putFloat("indent", v.indent)
                .putFloat("topSpace", v.topSpace)
                .putFloat("bottomSpace", v.bottomSpace)
                .putFloat("headerSpace", v.headerSpace)
                .putInt("footerItems", v.footerItems)
                .putFloat("fontWeight", v.fontWeight)
                .putFloat("letterSpacing", v.letterSpacing)
                .putFloat("wordSpacing", v.wordSpacing)
                .putBoolean("hyphens", v.hyphens)
                .putInt("columns", v.columns)
                .putBoolean("showHeader", v.showHeader)
                .putFloat("headerSize", v.headerSize)
                .putFloat("footerSize", v.footerSize)
                .putBoolean("keepScreenOn", v.keepScreenOn)
                .apply()
        }

    /** [systemDark] is the phone's theme, which decides the page colour while [theme] is Auto. */
    fun toEpubPreferences(systemDark: Boolean = false): EpubPreferences {
        val l = look
        val page = ReaderThemes.resolve(theme, systemDark)
        return EpubPreferences(
            fontSize = fontSize,
            theme = when (page) {
                1 -> Theme.SEPIA
                2, 4, 5 -> Theme.DARK
                else -> Theme.LIGHT
            },
            // Sage, Slate and Dark are Readium's light or dark theme with their own paper and ink colours.
            backgroundColor = when (page) {
                3 -> ReadiumColor(0xFFD6E3D3.toInt())
                4 -> ReadiumColor(0xFF4A4F57.toInt())
                5 -> ReadiumColor(0xFF1C1C1C.toInt())
                else -> null
            },
            textColor = when (page) {
                3 -> ReadiumColor(0xFF22332A.toInt())
                4 -> ReadiumColor(0xFFECEFF3.toInt())
                5 -> ReadiumColor(0xFFE8E8E8.toInt())
                else -> null
            },
            // 100% is Readest's side margin: 2.5% of the width plus 8 dp (about 18 dp on a phone) against Readium's own 20 dp.
            pageMargins = l.margins * READEST_SIDE,
            publisherStyles = if (l.custom) false else null,
            fontFamily = if (l.custom) {
                when (l.fontFamily) {
                    1 -> FontFamily.SANS_SERIF
                    2 -> FontFamily.MONOSPACE
                    else -> FontFamily.SERIF
                }
            } else null,
            lineHeight = if (l.custom) l.lineSpacing.toDouble() else null,
            textAlign = if (l.custom) (if (l.justify) TextAlign.JUSTIFY else TextAlign.START) else null,
            paragraphSpacing = if (l.custom) l.paragraphSpacing.toDouble() else null,
            paragraphIndent = if (l.custom) l.indent.toDouble() else null,
            hyphens = if (l.custom) l.hyphens else null,
            // Only sent when changed from normal, so the default look is exactly what it was.
            fontWeight = if (l.custom && l.fontWeight != 1f) l.fontWeight.toDouble() else null,
            letterSpacing = if (l.custom && l.letterSpacing > 0f) l.letterSpacing.toDouble() else null,
            wordSpacing = if (l.custom && l.wordSpacing > 0f) l.wordSpacing.toDouble() else null,
            columnCount = if (l.columns == 1) ColumnCount.ONE else null,
        )
    }
}

/** Readest's side margin (about 18.3 dp on a 411 dp wide phone) divided by Readium's default page margin of 20 dp. */
private const val READEST_SIDE = 0.915
