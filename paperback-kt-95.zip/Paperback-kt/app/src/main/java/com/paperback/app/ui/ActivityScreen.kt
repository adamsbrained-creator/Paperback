package com.paperback.app.ui

import androidx.compose.ui.graphics.SolidColor
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Anchor
import com.paperback.app.data.Book
import com.paperback.app.data.Goals
import com.paperback.app.data.PatternMetric
import com.paperback.app.data.Period
import com.paperback.app.data.PeriodData
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.data.StatNames
import com.paperback.app.data.barDate
import com.paperback.app.data.barName
import com.paperback.app.data.buildHeatmap
import com.paperback.app.data.computeDetails
import com.paperback.app.data.currentAnchor
import com.paperback.app.data.dateLabel
import com.paperback.app.data.finishedBetween
import com.paperback.app.data.firstReadingYear
import com.paperback.app.data.formatCount
import com.paperback.app.data.goalWeek
import com.paperback.app.data.lifetime
import com.paperback.app.data.nextBestAction
import com.paperback.app.data.paceSeries
import com.paperback.app.data.pctDelta
import com.paperback.app.data.periodData
import com.paperback.app.data.periodInfo
import com.paperback.app.data.readingPatterns
import com.paperback.app.data.sessionWhen
import com.paperback.app.data.shiftAnchor
import com.paperback.app.data.signed
import com.paperback.app.data.topBooks
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

private val UpGreen = Color(0xFF2E9E5B)

/**
 * Stats -> Activity: the daily goal, a suggestion for today, the reading chart for a week / month / year / all time,
 * details, session lengths, a rhythm calendar, when you read, what you read most, and lifetime totals.
 * (A port of the TypeScript app's Activity page.)
 */
@Composable
fun ActivityScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    goals: Goals,
    onOpenBook: (Book) -> Unit,
    onOpenGoals: () -> Unit,
    onViewDay: (LocalDate) -> Unit = {},
    calendarLook: Boolean = false,
    goalStyle: com.paperback.app.data.GoalStyle = com.paperback.app.data.GoalStyle.Ring,
    activityStyle: com.paperback.app.data.ActivityStyle = com.paperback.app.data.ActivityStyle.Chart,
    onCalendarLook: (Boolean) -> Unit = {},
    onOpenCalendar: () -> Unit = {},
    onShareText: (String) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val coral = DashAccent.Violet
    val zone = remember { ZoneId.systemDefault() }
    val today = LocalDate.now(zone)

    // How far back each period is from now (0 = the current one). Kept as counts so it stays right after midnight.
    var periodName by rememberSaveable { mutableStateOf(Period.Week.name) }
    val period = Period.valueOf(periodName)
    var timeMetric by rememberSaveable { mutableStateOf(true) }
    var weekBack by rememberSaveable { mutableIntStateOf(0) }
    var monthBack by rememberSaveable { mutableIntStateOf(0) }
    var yearBack by rememberSaveable { mutableIntStateOf(0) }
    var picking by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<Int?>(null) }
    var pickedDay by remember { mutableStateOf<LocalDate?>(null) }
    var patternSessions by rememberSaveable { mutableStateOf(true) }
    var pickedHour by remember { mutableStateOf<Int?>(null) }

    val anchor = Anchor(
        weekEnd = today.minusDays(weekBack.toLong()),
        month = YearMonth.from(today).minusMonths(monthBack.toLong()),
        year = today.year - yearBack,
    )
    fun applyAnchor(a: Anchor) {
        weekBack = ChronoUnit.DAYS.between(a.weekEnd, today).toInt().coerceAtLeast(0)
        monthBack = ((today.year * 12 + today.monthValue) - (a.month.year * 12 + a.month.monthValue)).coerceAtLeast(0)
        yearBack = (today.year - a.year).coerceAtLeast(0)
    }
    LaunchedEffect(period, weekBack, monthBack, yearBack, timeMetric) { picked = null }

    // ---- numbers --------------------------------------------------------------------------
    val firstYear = remember(sessions) { firstReadingYear(sessions, today, zone) }
    val firstMs = remember(sessions) { sessions.minOfOrNull { it.startMs } }
    val byDay = remember(sessions) { Stats.secondsByDay(sessions, zone) }
    val streak = Stats.currentStreak(byDay, today)
    val longestStreak = max(Stats.longestStreak(byDay), streak)

    val goalMin = goals.minutesPerDay.coerceAtLeast(1)
    val goalSeconds = goalMin * 60L
    val todaySeconds = byDay[today] ?: 0L
    val readMin = (todaySeconds / 60).toInt()
    val action = nextBestAction(todaySeconds, goalMin, streak, longestStreak)

    val info = remember(period, weekBack, monthBack, yearBack, firstYear, today) { periodInfo(period, anchor, today, firstYear) }
    val data = remember(sessions, info, today) { periodData(sessions, info, today, zone) }
    val prev: PeriodData? = remember(sessions, info, today) {
        if (period == Period.All) null else periodData(sessions, periodInfo(period, shiftAnchor(period, anchor, -1, today), today, firstYear), today, zone)
    }
    val details = remember(data) { computeDetails(data, today, zone) }
    val prevDetails = remember(prev) { prev?.let { computeDetails(it, today, zone) } }
    val finished = remember(books, info) { finishedBetween(books, info.start, info.end, zone) }
    val pace = remember(data) { paceSeries(data) }
    val most = remember(data) { topBooks(data.rows, 6) }
    val heat = remember(byDay, today) { buildHeatmap(byDay, today, 18) }
    val dayBooks = remember(sessions, books) { readingByDay(sessions, books, zone) }
    val life = remember(sessions, books, today) { lifetime(sessions, books, today, zone) }
    val patterns = remember(sessions, patternSessions, today) {
        readingPatterns(sessions, if (patternSessions) PatternMetric.Sessions else PatternMetric.Pages, today, zone)
    }
    val byId = remember(books) { books.associateBy { it.id } }
    // The dashboard's peak hour and bell curve always count sessions, whatever the "When you read" toggle says below.
    val dashPatterns = remember(sessions, today) { readingPatterns(sessions, PatternMetric.Sessions, today, zone) }

    // ---- the hero chart -------------------------------------------------------------------
    val vals: List<Float?> = if (timeMetric) data.seconds.map { it?.toFloat() } else data.pages.map { it?.toFloat() }
    val total: Long = if (timeMetric) data.totalSeconds else data.totalPages.toLong()
    val prevTotal: Long = if (prev == null) 0L else if (timeMetric) prev.totalSeconds else prev.totalPages.toLong()
    val delta = if (prev == null) null else pctDelta(total, prevTotal)
    val best = vals.indices.maxByOrNull { vals[it] ?: -1f } ?: 0
    val selected = picked
        ?: if (info.curIdx >= 0 && (vals.getOrNull(info.curIdx) ?: 0f) > 0f) info.curIdx else best
    val goalOn = timeMetric && (period == Period.Week || period == Period.Month)
    val hasEarlier = firstMs != null && firstMs < info.start.atStartOfDay(zone).toInstant().toEpochMilli()
    val canPrev = period != Period.All && hasEarlier

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // ---- 1. the dashboard: consistency, daily goal, peak hour, most active, this week, report ----
        ActivityDashboard(
            sessions = sessions,
            byDay = byDay,
            patterns = dashPatterns,
            today = today,
            zone = zone,
            goalMinutes = goalMin,
            todaySeconds = todaySeconds,
            streak = streak,
            onOpenGoals = onOpenGoals,
            onShare = onShareText,
        )

        // ---- 2. next best action ----------------------------------------------------------
        ActCard(onClick = onOpenGoals) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    CardLabel("Next best action")
                    Spacer(Modifier.height(6.dp))
                    Text(action.title, color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    Text(action.text, color = t.setSub, fontSize = 14.sp, lineHeight = 20.sp)
                }
                PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub, strokeWidth = 2f)
            }
        }

        // ---- 3. the hero chart ------------------------------------------------------------
        ActCard {
            PbSegmented(
                options = listOf(Period.Week to "Week", Period.Month to "Month", Period.Year to "Year", Period.All to "All"),
                selected = period,
                onSelect = { periodName = it.name },
            )
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (if (timeMetric) "Reading time" else "Pages read") + " \u00B7 " + info.label,
                    modifier = Modifier.weight(1f),
                    color = t.setSub,
                    fontSize = 13.sp,
                )
                PbSegmented(
                    options = listOf(true to "Time", false to "Pages"),
                    selected = timeMetric,
                    onSelect = { timeMetric = it },
                    modifier = Modifier.width(150.dp),
                )
            }
            Spacer(Modifier.height(10.dp))
            val bigSize = if (activityStyle == com.paperback.app.data.ActivityStyle.Big) 72 else 46
            if (timeMetric) BigTime(total, bigSize) else BigNumber(total.toInt(), "pages", bigSize)
            if (delta != null && info.vsName.isNotEmpty()) {
                val color = when {
                    delta > 0 -> UpGreen
                    delta < 0 -> DangerRed
                    else -> t.setSub
                }
                Text(
                    "${if (delta > 0) "+" else if (delta < 0) "\u2212" else ""}${abs(delta)}% vs ${info.vsName}",
                    color = color,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
            Spacer(Modifier.height(14.dp))
            val selValue = vals.getOrNull(selected)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    barName(info, selected) + " \u00B7 " + when {
                        selValue == null -> "not yet"
                        selValue <= 0f -> "no reading"
                        timeMetric -> Stats.duration(selValue.toLong())
                        else -> "${formatCount(selValue.toInt())} pages"
                    },
                    modifier = Modifier.weight(1f),
                    color = coral,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                )
                if (selValue != null && selValue > 0f) {
                    Text(
                        "View sessions",
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onViewDay(barDate(info, selected)) }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        color = t.ink,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            val fmtBar: (Float) -> String = { v -> if (timeMetric) Stats.duration(v.toLong()) else "${formatCount(v.toInt())} p" }
            val barNames = remember(info) { (0 until info.count).map { barName(info, it) } }
            when (activityStyle) {
                com.paperback.app.data.ActivityStyle.Chart -> ActivityBarChart(
                    values = vals,
                    labels = info.labels,
                    selected = selected,
                    curIdx = info.curIdx,
                    goal = if (goalOn) goalSeconds.toFloat() else null,
                    goalLabel = "$goalMin min goal",
                    onSelect = { picked = it },
                )
                com.paperback.app.data.ActivityStyle.List -> ActivityBarList(
                    names = barNames, values = vals, selected = selected, format = fmtBar, onSelect = { picked = it },
                )
                com.paperback.app.data.ActivityStyle.Big -> ActivityBigFacts(
                    names = barNames, values = vals, format = fmtBar,
                    unitName = when (period) { Period.Week, Period.Month -> "day"; Period.Year -> "month"; Period.All -> "year" },
                )
            }
            if (period != Period.All) {
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ArrowButton(left = true, enabled = canPrev) { applyAnchor(shiftAnchor(period, anchor, -1, today)) }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text(
                            info.pagerLabel,
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { picking = true }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            color = t.ink,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                    ArrowButton(left = false, enabled = !info.isCurrent) { applyAnchor(shiftAnchor(period, anchor, 1, today)) }
                }
            }
        }

        // ---- 4. details -------------------------------------------------------------------
        DashHeading("Details \u00B7 ${info.label}")
        ActCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    CardLabel("Reading pace")
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            if (details.pace > 0) "${details.pace}" else "\u2013",
                            color = t.ink, fontSize = 34.sp, fontWeight = FontWeight.Medium,
                        )
                        Text(" pages/h", color = t.setSub, fontSize = 14.sp, modifier = Modifier.padding(bottom = 6.dp))
                    }
                    val paceDiff = if (prevDetails != null && prevDetails.pace > 0 && details.pace > 0) details.pace - prevDetails.pace else null
                    Text(
                        if (paceDiff != null && info.vsName.isNotEmpty()) "${signed(paceDiff)} pages/h vs ${info.vsName}" else "pages per hour",
                        color = t.setSub, fontSize = 13.sp,
                    )
                }
                Sparkline(pace, coral)
            }
        }
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            val sessionsDiff = if (prevDetails != null && prevDetails.sessions > 0) details.sessions - prevDetails.sessions else null
            MiniStat(
                "Sessions", formatCount(details.sessions),
                if (sessionsDiff != null && info.vsName.isNotEmpty()) "${signed(sessionsDiff)} vs ${info.vsName}" else "reading sittings",
                Modifier.weight(1f).fillMaxHeight(),
            )
            MiniStat(
                "Finished", formatCount(finished),
                if (finished == 0) "none yet" else if (finished == 1) "book in ${info.label}" else "books in ${info.label}",
                Modifier.weight(1f).fillMaxHeight(),
            )
        }

        // ---- 5. session length vs goal ----------------------------------------------------
        ActCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { CardLabel("Session length") }
                Text("vs $goalMin min goal", color = t.setSub, fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            val longest = details.longest
            val bestDay = details.bestDay
            LengthRow("Average session", null, details.avgSessionSeconds, goalSeconds, StatsAccent.Blue)
            LengthRow("Longest session", longest?.let { sessionWhen(period, it, zone) }, longest?.seconds ?: 0L, goalSeconds, StatsAccent.Yellow)
            LengthRow("Best day", bestDay?.let { dateLabel(period, it.date) }, bestDay?.seconds ?: 0L, goalSeconds, StatsAccent.Mint)
            LengthRow("Average a day", null, details.avgPerDaySeconds, goalSeconds, StatsAccent.Pink)
        }

        // ---- 6. reading rhythm ------------------------------------------------------------
        ActCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { CardLabel("Reading rhythm") }
                Text(
                    if (calendarLook) today.month.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.getDefault()) else "last 18 weeks",
                    color = t.setSub, fontSize = 12.sp,
                )
            }
            Spacer(Modifier.height(14.dp))
            PbSegmented(
                options = listOf(false to "Squares", true to "Calendar"),
                selected = calendarLook,
                onSelect = onCalendarLook,
                modifier = Modifier.width(220.dp),
            )
            Spacer(Modifier.height(14.dp))
            if (calendarLook) {
                CalendarMonth(YearMonth.from(today), dayBooks, covers = false, selected = pickedDay, onPick = { pickedDay = it })
                Spacer(Modifier.height(12.dp))
                val titles = pickedDay?.let { d -> dayBooks[d]?.joinToString(", ") { it.book.title } }
                Text(
                    if (pickedDay == null) "Tap a day to see what you read." else "${pickedDay!!.dayOfMonth} ${StatNames.MONTHS_SHORT[pickedDay!!.monthValue - 1]} \u00B7 ${titles.orEmpty()}",
                    color = if (pickedDay == null) t.setSub else coral,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(10.dp))
                ActionPill("Open the full calendar", onClick = onOpenCalendar)
            } else {
            Heatmap(heat, today, pickedDay, onPick = { pickedDay = it.date })
            Spacer(Modifier.height(12.dp))
            val cell = pickedDay?.let { d -> heat.flatten().firstOrNull { it.date == d } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (cell == null) "Tap a day to see how much you read."
                    else "${StatNames.WEEKDAYS_SHORT[StatNames.weekdayIndex(cell.date)]} ${cell.date.dayOfMonth} ${StatNames.MONTHS_SHORT[cell.date.monthValue - 1]} \u00B7 " +
                        (if (cell.seconds >= 60) Stats.duration(cell.seconds) + " read" else "no reading"),
                    modifier = Modifier.weight(1f),
                    color = if (cell == null) t.setSub else coral,
                    fontSize = 13.sp,
                    fontWeight = if (cell == null) FontWeight.Normal else FontWeight.Medium,
                )
                Text("Less", color = t.setSub, fontSize = 11.sp)
                Spacer(Modifier.width(5.dp))
                listOf(0.07f, 0.30f, 0.50f, 0.75f, 1f).forEachIndexed { i, a ->
                    Box(
                        Modifier
                            .padding(horizontal = 1.5.dp)
                            .size(12.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (i == 0) t.ink.copy(alpha = a) else coral.copy(alpha = a)),
                    )
                }
                Spacer(Modifier.width(5.dp))
                Text("More", color = t.setSub, fontSize = 11.sp)
            }
            if (cell != null && cell.seconds >= 60) {
                Spacer(Modifier.height(10.dp))
                ActionPill("View sessions", onClick = { onViewDay(cell.date) })
            }
            }
        }

        // ---- 7. patterns ------------------------------------------------------------------
        ActCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    CardLabel("When you read")
                    Text("last 90 days", color = t.setSub, fontSize = 12.sp)
                }
                PbSegmented(
                    options = listOf(true to "Sessions", false to "Pages"),
                    selected = patternSessions,
                    onSelect = { patternSessions = it },
                    modifier = Modifier.width(190.dp),
                )
            }
            Spacer(Modifier.height(14.dp))
            if (patterns.total == 0) {
                Text("Read a little more and your habits will show up here.", color = t.setSub, fontSize = 14.sp)
            } else {
                Text(
                    buildAnnotatedString {
                        append("You read mostly in the ")
                        withStyle(SpanStyle(color = coral, fontWeight = FontWeight.SemiBold)) { append(patterns.topTime.name.lowercase()) }
                        if (patterns.weekPart == "all week") {
                            append(", all week.")
                        } else {
                            append(", on ")
                            withStyle(SpanStyle(color = coral, fontWeight = FontWeight.SemiBold)) { append(patterns.weekPart) }
                            append(".")
                        }
                    },
                    color = t.ink,
                    fontSize = 18.sp,
                    lineHeight = 25.sp,
                )
                Spacer(Modifier.height(14.dp))
                val unit = if (patternSessions) "sessions" else "pages"
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    HourClock(patterns.byHour, patterns.peakHour, pickedHour, { pickedHour = it }, Modifier.size(172.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        val h = pickedHour
                        if (h != null) {
                            SideStat("Hour ${pad2(h)}\u2013${pad2((h + 1) % 24)}", "${formatCount(patterns.byHour[h])} $unit")
                        }
                        SideStat("Most active", patterns.topTime.name, "${formatCount(patterns.topTime.value)} $unit")
                        SideStat("Best day", patterns.topWeekday.name, "${formatCount(patterns.topWeekday.value)} $unit")
                        SideStat("Peak hour", "${pad2(patterns.peakHour)}\u2013${pad2((patterns.peakHour + 1) % 24)}h", null)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    patterns.byTime.forEachIndexed { i, n ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(9.dp).clip(CircleShape).background(StatsAccent.TimeOfDay[i]))
                            Text(n.name, color = t.setSub, fontSize = 11.sp, maxLines = 1)
                            Text(formatCount(n.value), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                val topDay = max(1, patterns.byWeekday.maxOf { it.value })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
                    patterns.byWeekday.forEach { d ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier
                                    .width(10.dp)
                                    .height((6 + 54f * d.value / topDay).dp)
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(
                                        if (d.name == patterns.topWeekday.name) barBrush(DashAccent.Pink) else SolidColor(t.ink.copy(alpha = 0.16f)),
                                    ),
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(d.name.take(3), color = t.setSub, fontSize = 11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "A session counts for the hour it started in. Morning 5\u201312 \u00B7 Afternoon 12\u201317 \u00B7 Evening 17\u201322 \u00B7 Night 22\u20135.",
                    color = t.setSub, fontSize = 11.sp, lineHeight = 15.sp,
                )
            }
        }

        // ---- 8. most read -----------------------------------------------------------------
        val shownMost = most.filter { byId[it.bookId] != null }
        if (shownMost.isNotEmpty()) {
            DashHeading("Most read \u00B7 ${info.label}")
            LazyRow(
                modifier = Modifier.fullBleed(20.dp),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                items(shownMost, key = { it.bookId }) { tb ->
                    val book = byId.getValue(tb.bookId)
                    Column(Modifier.width(112.dp).clickable { onOpenBook(book) }) {
                        Box {
                            BookCover(book, Modifier.fillMaxWidth())
                            Text(
                                "${(tb.share * 100).toInt()}%",
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(6.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Black.copy(alpha = 0.62f))
                                    .padding(horizontal = 7.dp, vertical = 3.dp),
                                color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(book.title, color = t.ink, fontSize = 13.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            Stats.duration(tb.seconds) + if (book.author.isNotBlank()) " \u00B7 ${book.author}" else "",
                            color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }

        // ---- 9. lifetime totals -----------------------------------------------------------
        DashHeading("All time")
        PbCard {
            val rows = listOf(
                "Reading time" to Stats.duration(life.seconds),
                "Pages read" to formatCount(life.pages),
                "Sessions" to formatCount(life.sessions),
                "Books read" to formatCount(life.booksRead),
                "Books finished" to formatCount(life.finished),
                "Days read" to formatCount(life.activeDays),
                "Current streak" to "${life.currentStreak} ${if (life.currentStreak == 1) "day" else "days"}",
                "Longest streak" to "${life.longestStreak} ${if (life.longestStreak == 1) "day" else "days"}",
                "Longest session" to (life.longestSession?.let { Stats.duration(it.seconds) } ?: "\u2013"),
                "Best day" to (life.bestDay?.let { Stats.duration(it.seconds) + " \u00B7 " + dateLabel(Period.All, it.date) } ?: "\u2013"),
                "Average on days read" to (if (life.avgPerActiveDaySeconds > 0) Stats.duration(life.avgPerActiveDaySeconds) else "\u2013"),
                "Reading since" to (life.firstDay?.let { dateLabel(Period.All, it) } ?: "\u2013"),
            )
            rows.forEachIndexed { i, (label, value) ->
                if (i > 0) CardDivider(18.dp)
                InfoRow(label, value)
            }
        }

        Text(
            "Time counts the minutes you spend turning pages (long pauses are left out). Pages are the pages you turned, so going back over a page counts again.",
            color = t.setSub, fontSize = 12.sp, lineHeight = 17.sp,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
        )
        Spacer(Modifier.height(96.dp))
    }

    if (picking && period != Period.All) {
        PeriodPickerDialog(
            period = period,
            anchor = anchor,
            today = today,
            firstYear = firstYear,
            onCancel = { picking = false },
            onOk = { a ->
                picking = false
                applyAnchor(a)
            },
        )
    }
}

private fun pad2(n: Int): String = n.toString().padStart(2, '0')

@Composable
private fun ActCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .dashSurface()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(20.dp),
        content = content,
    )
}

@Composable
private fun TrioStat(value: String, label: String) {
    val t = pbTokens()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = t.ink, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        Text(label, color = t.setSub, fontSize = 12.sp)
    }
}

@Composable
private fun BigTime(seconds: Long, size: Int = 46) {
    val t = pbTokens()
    val minutes = ((seconds + 30) / 60).toInt()
    @Composable
    fun num(n: Int) = Text("$n", color = t.ink, fontSize = size.sp, fontWeight = FontWeight.Medium)
    @Composable
    fun unit(u: String) = Text(u, color = t.setSub, fontSize = 18.sp, modifier = Modifier.padding(start = 2.dp, end = 10.dp, bottom = 8.dp))
    Row(verticalAlignment = Alignment.Bottom) {
        if (minutes >= 60) {
            num(minutes / 60)
            unit("h")
            num(minutes % 60)
            unit("m")
        } else {
            num(minutes)
            unit("m")
        }
    }
}

@Composable
private fun BigNumber(n: Int, unit: String, size: Int = 46) {
    val t = pbTokens()
    Row(verticalAlignment = Alignment.Bottom) {
        Text(formatCount(n), color = t.ink, fontSize = size.sp, fontWeight = FontWeight.Medium)
        Text(" $unit", color = t.setSub, fontSize = 18.sp, modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
private fun MiniStat(label: String, value: String, sub: String, modifier: Modifier = Modifier) {
    val t = pbTokens()
    Column(
        modifier
            .dashSurface()
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Text(label, color = t.setSub, fontSize = 13.sp)
        Text(value, color = t.ink, fontSize = 30.sp, fontWeight = FontWeight.Medium)
        Text(sub, color = t.setSub, fontSize = 12.sp, lineHeight = 16.sp)
    }
}

/** One of the session-length bars: a label (and when), the length, and a bar filled against the daily goal. */
@Composable
private fun LengthRow(label: String, whenText: String?, seconds: Long, goalSeconds: Long, color: Color) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text(label, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                if (whenText != null) Text(whenText, color = t.setSub, fontSize = 12.sp)
            }
            Text(if (seconds > 0) Stats.duration(seconds) else "\u2013", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(6.dp))
        GradientTrack(if (seconds > 0) seconds.toFloat() / goalSeconds else 0f, color, minFraction = 0.03f)
    }
}

@Composable
private fun SideStat(label: String, value: String, sub: String? = null) {
    val t = pbTokens()
    Column {
        Text(label, color = t.setSub, fontSize = 11.sp)
        Text(value, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (sub != null) Text(sub, color = t.setSub, fontSize = 11.sp)
    }
}
