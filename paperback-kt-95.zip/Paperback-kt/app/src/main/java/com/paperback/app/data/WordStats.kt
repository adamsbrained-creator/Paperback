package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt

/*
 * Words read and words per minute, as plain functions (no Android, no clock: `today` is passed in).
 *
 * A book with a word count (Edit book -> Reading facts, or imported) gives exact words per page: its words divided by
 * its pages. A book without one is counted at an average page ([WORDS_PER_PAGE] words) and the result says so
 * ("estimated"). Words are the pages turned in your sessions times the words on a page, like the pages on the Activity
 * page: a page you read again counts again. Listening (read-aloud) is counted apart, never in words per minute.
 */

/** Words on an average printed page, for books without a word count. */
const val WORDS_PER_PAGE = 275

/** Words in an average novel, for "that is about N novels". */
const val NOVEL_WORDS = 90_000

private const val MIN_WPM_SECONDS = 600L
private const val MIN_BOOK_WPM_SECONDS = 1200L

/** True when the book has a word count and a page count, so its words per page are its own. */
fun hasWordCount(b: Book): Boolean = b.words > 0 && b.pageCount > 0

/** Words on one page of this book: its own when it has a count, else an average page. */
fun wordsPerPage(b: Book?): Double = if (b != null && hasWordCount(b)) b.words.toDouble() / b.pageCount else WORDS_PER_PAGE.toDouble()

/** Listening is not reading: read-aloud rows are left out of words read and words per minute. */
private fun isReading(s: ReadingSession): Boolean = s.kind != SessionKind.LISTEN

/** Words in these rows (the pages turned times the words on a page of each book). */
fun wordsIn(rows: List<ReadingSession>, byId: Map<String, Book>): Long =
    rows.sumOf { (wordsPerPage(byId[it.bookId]) * it.pages).toLong() }

/** Words per minute of these rows: from books with a word count when there is enough of them, else estimated. */
fun wpmOf(rows: List<ReadingSession>, byId: Map<String, Book>): Pair<Int, Boolean> {
    val reading = rows.filter { isReading(it) && it.seconds > 0 }
    val known = reading.filter { r -> byId[r.bookId]?.let { hasWordCount(it) } == true }
    val knownSeconds = known.sumOf { it.seconds.toLong() }
    if (knownSeconds >= MIN_WPM_SECONDS) {
        return (wordsIn(known, byId) / (knownSeconds / 60.0)).roundToInt() to false
    }
    val seconds = reading.sumOf { it.seconds.toLong() }
    if (seconds >= MIN_WPM_SECONDS) {
        return (wordsIn(reading, byId) / (seconds / 60.0)).roundToInt() to true
    }
    return 0 to false
}

class WpmMonth(val label: String, val firstDay: LocalDate, val wpm: Int)

class BookWords(val book: Book, val words: Long, val seconds: Long, val wpm: Int)

class WordStats(
    /** Words read, all time / this month / this year. */
    val total: Long,
    val thisMonth: Long,
    val thisYear: Long,
    /** Words you listened to (read-aloud), all time. */
    val listened: Long,
    /** Words per minute over the last 60 days (0 when there is too little reading), and whether it is estimated. */
    val wpm: Int,
    val wpmEstimated: Boolean,
    /** Words on an average day you read, in the last 30 days (0 when none). */
    val perReadingDay: Int,
    /** Books you read with an exact word count, and books you read without one (counted at an average page). */
    val countedBooks: Int,
    val uncountedBooks: Int,
    /** The last six months, oldest first. */
    val months: List<WpmMonth>,
    val bestMonth: WpmMonth?,
    /** The books you read the most words of (at most three). */
    val topBooks: List<BookWords>,
    /** Fastest and slowest book by words per minute: only books with a word count and 20 minutes of reading. */
    val fastest: BookWords?,
    val slowest: BookWords?,
) {
    /** The words read as a number of average novels. */
    val novels: Double get() = total.toDouble() / NOVEL_WORDS
}

fun wordStats(rows: List<ReadingSession>, books: List<Book>, today: LocalDate, zone: ZoneId): WordStats {
    val byId = books.associateBy { it.id }
    val reading = rows.filter { isReading(it) }
    val listening = rows.filter { !isReading(it) }

    fun startMs(d: LocalDate) = d.atStartOfDay(zone).toInstant().toEpochMilli()

    val total = wordsIn(reading, byId)
    val monthMs = startMs(today.withDayOfMonth(1))
    val yearMs = startMs(LocalDate.of(today.year, 1, 1))
    val thisMonth = wordsIn(reading.filter { it.startMs >= monthMs }, byId)
    val thisYear = wordsIn(reading.filter { it.startMs >= yearMs }, byId)
    val listened = wordsIn(listening, byId)

    val recent = wpmOf(reading.filter { it.startMs >= startMs(today.minusDays(59)) }, byId)

    // words on an average reading day, last 30 days
    val from30 = startMs(today.minusDays(29))
    val last30 = reading.filter { it.startMs >= from30 }
    val activeDays = last30.map { dateOf(it.startMs, zone) }.toSet().size
    val perDay = if (activeDays > 0) (wordsIn(last30, byId) / activeDays).toInt() else 0

    // the last six months
    val thisMonthStart = today.withDayOfMonth(1)
    val months = (5 downTo 0).map { i ->
        val from = thisMonthStart.minusMonths(i.toLong())
        val to = from.plusMonths(1)
        val inMonth = reading.filter { it.startMs >= startMs(from) && it.startMs < startMs(to) }
        WpmMonth(StatNames.MONTHS_SHORT[from.monthValue - 1], from, wpmOf(inMonth, byId).first)
    }
    var best: WpmMonth? = null
    for (m in months) {
        val b = best
        if (m.wpm > 0 && (b == null || m.wpm > b.wpm)) best = m
    }

    // books
    val perBook = reading.groupBy { it.bookId }.mapNotNull { (id, list) ->
        val b = byId[id] ?: return@mapNotNull null
        val seconds = list.sumOf { it.seconds.toLong() }
        val words = wordsIn(list, byId)
        val wpm = if (hasWordCount(b) && seconds >= MIN_BOOK_WPM_SECONDS) (words / (seconds / 60.0)).roundToInt() else 0
        BookWords(b, words, seconds, wpm)
    }.filter { it.words > 0 }
    val withWpm = perBook.filter { it.wpm > 0 }

    return WordStats(
        total = total,
        thisMonth = thisMonth,
        thisYear = thisYear,
        listened = listened,
        wpm = recent.first,
        wpmEstimated = recent.second,
        perReadingDay = perDay,
        countedBooks = perBook.count { hasWordCount(it.book) },
        uncountedBooks = perBook.count { !hasWordCount(it.book) },
        months = months,
        bestMonth = best,
        topBooks = perBook.sortedByDescending { it.words }.take(3),
        fastest = withWpm.maxByOrNull { it.wpm },
        slowest = if (withWpm.size > 1) withWpm.minByOrNull { it.wpm } else null,
    )
}

/** 1,234,567 -> "1.2M words", 85,000 -> "85K words", 950 -> "950 words". */
fun wordsText(n: Long): String = when {
    n >= 1_000_000L -> {
        val x = n / 1_000_000.0
        if (x >= 10) "${Math.round(x)}M" else "%.1fM".format(x)
    }
    n >= 10_000L -> "${Math.round(n / 1000.0)}K"
    n >= 1_000L -> "%.1fK".format(n / 1000.0)
    else -> "$n"
}
