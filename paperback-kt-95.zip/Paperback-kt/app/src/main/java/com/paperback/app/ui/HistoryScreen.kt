package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.CalendarDay
import com.paperback.app.data.DayGroup
import com.paperback.app.data.MonthView
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Session
import com.paperback.app.data.Stats
import com.paperback.app.data.accentIndex
import com.paperback.app.data.firstMonth
import com.paperback.app.data.formatClock
import com.paperback.app.data.formatCount
import com.paperback.app.data.monthView
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.max

private const val FIRST = 8 // sessions shown when a month opens
private const val MORE = 25 // sessions added by each "more" button

private sealed interface HEntry {
    val key: String
}

private class ECalendar(val month: MonthView) : HEntry {
    override val key: String = "calendar"
}

private class EEmpty(val title: String) : HEntry {
    override val key: String = "empty"
}

private class EDay(val group: DayGroup) : HEntry {
    override val key: String = "day-${group.date}"
}

private class ESession(val session: Session) : HEntry {
    override val key: String = "session-${session.bookId}-${session.startMs}"
}

private class EMore(val hidden: Int) : HEntry {
    override val key: String = "more"
}

/**
 * Stats -> History: a calendar of the days you read in a month, and that month's sessions day by day, newest first.
 * Tap a day with reading to jump to its sessions; tap a session to open the book. [focus] opens on that day.
 */
@Composable
fun HistoryScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    focus: LocalDate?,
    onOpenBook: (Book) -> Unit,
    modifier: Modifier = Modifier,
) {
    val zone = remember { ZoneId.systemDefault() }
    val today = LocalDate.now(zone)
    val nowMonth = YearMonth.from(today)
    val first = remember(sessions) { firstMonth(sessions, today, zone) }
    val initial = remember {
        val f = focus?.let { YearMonth.from(it) }
        when {
            f == null -> nowMonth
            f.isBefore(first) -> first
            f.isAfter(nowMonth) -> nowMonth
            else -> f
        }
    }

    var monthKey by rememberSaveable { mutableIntStateOf(initial.year * 12 + initial.monthValue - 1) }
    val ym = YearMonth.of(monthKey / 12, monthKey % 12 + 1)
    var visible by remember { mutableIntStateOf(FIRST) }
    var selected by remember { mutableStateOf<LocalDate?>(null) }
    var wanted by remember { mutableStateOf(focus) }
    var scrollTo by remember { mutableStateOf<LocalDate?>(null) }
    val listState = rememberLazyListState()

    val month = remember(sessions, ym, today) { monthView(sessions, ym, today, zone) }
    val byId = remember(books) { books.associateBy { it.id } }

    /** How many sessions have to be shown for [date]'s group to be in the list. */
    fun need(date: LocalDate): Int {
        var n = 0
        for (g in month.groups) {
            n += g.sessions.size
            if (g.date == date) break
        }
        return n
    }

    // A new month starts with its newest day picked and the short list; a day asked for from another page wins once.
    LaunchedEffect(month) {
        val want = wanted
        wanted = null
        val hit = if (want != null && month.groups.any { it.date == want }) want else null
        selected = hit ?: month.groups.firstOrNull()?.date
        visible = if (hit != null) max(FIRST, need(hit)) else FIRST
        scrollTo = hit
    }

    val entries = remember(month, visible) {
        val out = ArrayList<HEntry>()
        out.add(ECalendar(month))
        if (month.sessionCount == 0) out.add(EEmpty(month.title))
        var left = visible
        var shown = 0
        for (g in month.groups) {
            if (left <= 0) break
            val take = g.sessions.take(left)
            left -= take.size
            shown += take.size
            out.add(EDay(g))
            for (s in take) out.add(ESession(s))
        }
        val hidden = month.sessionCount - shown
        if (hidden > 0) out.add(EMore(hidden))
        out
    }

    // Bring a picked day's heading to the top once its sessions are in the list.
    LaunchedEffect(scrollTo, entries) {
        val d = scrollTo ?: return@LaunchedEffect
        val idx = entries.indexOfFirst { it is EDay && it.group.date == d }
        if (idx >= 0) {
            listState.animateScrollToItem(idx)
            scrollTo = null
        }
    }

    fun pickDay(d: CalendarDay) {
        if (d.sessions <= 0) return
        selected = d.date
        visible = max(visible, need(d.date))
        scrollTo = d.date
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(entries, key = { it.key }) { e ->
            when (e) {
                is ECalendar -> CalendarCard(
                    month = e.month,
                    selected = selected,
                    canPrev = ym.isAfter(first),
                    canNext = ym.isBefore(nowMonth),
                    onPrev = { monthKey -= 1 },
                    onNext = { monthKey += 1 },
                    onPick = { pickDay(it) },
                )
                is EEmpty -> PbNote("No reading in ${e.title}.")
                is EDay -> Text(
                    e.group.label,
                    modifier = Modifier.padding(start = 6.dp, top = 12.dp),
                    color = pbTokens().ink,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                is ESession -> {
                    val book = byId[e.session.bookId]
                    SessionCard(e.session, book, zone, if (book != null) ({ onOpenBook(book) }) else null)
                }
                is EMore -> PbButton(
                    "${e.hidden} more session${if (e.hidden > 1) "s" else ""}",
                    onClick = { visible += MORE },
                    ghost = true,
                )
            }
        }
    }
}

@Composable
private fun CalendarCard(
    month: MonthView,
    selected: LocalDate?,
    canPrev: Boolean,
    canNext: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onPick: (CalendarDay) -> Unit,
) {
    val t = pbTokens()
    val coral = DashAccent.Violet
    Column(
        Modifier
            .fillMaxWidth()
            .dashSurface()
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(month.title, color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "${month.sessionCount} ${if (month.sessionCount == 1) "session" else "sessions"} \u00B7 " +
                        "${formatCount(month.pageCount)} ${if (month.pageCount == 1) "page" else "pages"} \u00B7 " +
                        Stats.duration(month.seconds),
                    color = t.setSub,
                    fontSize = 13.sp,
                )
            }
            ArrowButton(left = true, enabled = canPrev, onClick = onPrev)
            Spacer(Modifier.width(8.dp))
            ArrowButton(left = false, enabled = canNext, onClick = onNext)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth()) {
            for (c in listOf("M", "T", "W", "T", "F", "S", "S")) {
                Text(c, Modifier.weight(1f), color = t.setSub, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        }
        val cells: List<CalendarDay?> = List(month.blanks) { null } + month.days
        cells.chunked(7).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                for (i in 0 until 7) {
                    val d = row.getOrNull(i)
                    Box(Modifier.weight(1f).height(44.dp), contentAlignment = Alignment.Center) {
                        if (d != null) {
                            val has = d.sessions > 0
                            val isSel = has && d.date == selected
                            Box(
                                Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isSel -> coral
                                            has -> coral.copy(alpha = 0.18f)
                                            else -> Color.Transparent
                                        },
                                    )
                                    .then(if (d.isToday && !has) Modifier.border(1.5.dp, t.ink, CircleShape) else Modifier)
                                    .clickable(enabled = has) { onPick(d) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    "${d.day}",
                                    color = when {
                                        isSel -> Color.White
                                        d.inFuture -> t.setSub.copy(alpha = 0.4f)
                                        has -> t.ink
                                        else -> t.setSub
                                    },
                                    fontSize = 14.sp,
                                    fontWeight = if (has) FontWeight.SemiBold else FontWeight.Normal,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private val ACCENTS = listOf(StatsAccent.Pink, StatsAccent.Yellow, StatsAccent.Blue, StatsAccent.Mint)

/** "Pages 107\u2013137", or "31 pages" when the range is not known. */
private fun pagesText(s: Session): String = when {
    s.fromPos > 0 && s.toPos > s.fromPos -> "Pages ${s.fromPos}\u2013${s.toPos}"
    s.pages > 0 -> "${s.pages} ${if (s.pages == 1) "page" else "pages"}"
    else -> "No pages noted"
}

@Composable
private fun SessionCard(s: Session, book: Book?, zone: ZoneId, onClick: (() -> Unit)?) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .dashSurface()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(4.dp).height(52.dp).clip(RoundedCornerShape(2.dp)).background(ACCENTS[accentIndex(s.bookId)]))
        Spacer(Modifier.width(12.dp))
        if (book != null) {
            BookCover(book, Modifier.width(40.dp))
        } else {
            Box(
                Modifier.size(width = 40.dp, height = 60.dp).clip(RoundedCornerShape(8.dp)).background(t.bg),
                contentAlignment = Alignment.Center,
            ) { PbIcon(PbIconName.Reader, size = 20.dp, tint = t.setSub) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                book?.title ?: "Removed book",
                color = t.ink,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text("${pagesText(s)} \u00B7 ${formatClock(s.startMs, zone)}", color = t.setSub, fontSize = 13.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(Stats.duration(s.seconds), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            if (s.pages > 0) Text("${s.pages} ${if (s.pages == 1) "page" else "pages"}", color = t.setSub, fontSize = 12.sp)
        }
    }
}
