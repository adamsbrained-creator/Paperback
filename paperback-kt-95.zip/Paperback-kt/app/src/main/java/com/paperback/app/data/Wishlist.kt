package com.paperback.app.data

import android.content.Context
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * The "Want to read" list: books from the online catalog you saved to come back to. Kept on the phone (a short
 * list, so a small file is enough), newest first, and included in backups. A book leaves the list by itself
 * once you add a copy to your library.
 */
class Wishlist(context: Context) {
    private val sp = context.getSharedPreferences("wishlist", Context.MODE_PRIVATE)
    private val _items = MutableStateFlow(read(sp.getString("items", null)))
    val items: StateFlow<List<CatalogBook>> = _items.asStateFlow()

    /** When each book was put on the list (ms), by book id. A book saved before dates were kept has none. */
    private var dates: Map<String, Long> = readDates(sp.getString("dates", null))

    /** The day a book was saved, 0 = not known. */
    fun addedAt(id: String): Long = dates[id] ?: 0L

    fun has(id: String): Boolean = _items.value.any { it.id == id }

    fun toggle(book: CatalogBook) {
        if (has(book.id)) remove(book.id) else save(listOf(book) + _items.value)
    }

    fun remove(id: String) = save(_items.value.filterNot { it.id == id })

    /** Drops books you now own. */
    fun prune(ownedKeys: Set<String>) {
        val kept = _items.value.filterNot { TitleKey.of(it.title) in ownedKeys }
        if (kept.size != _items.value.size) save(kept)
    }

    /** For a backup. */
    fun toJson(): JSONArray = write(_items.value)

    /** From a backup: adds what is not on the list yet, keeping the list as it is. */
    fun merge(arr: JSONArray?) {
        if (arr == null) return
        val have = _items.value.map { it.id }.toSet()
        val extra = read(arr.toString()).filter { it.id !in have }
        val restored = HashMap<String, Long>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val at = o.optLong("addedAt", 0L)
            if (at > 0L) restored[o.optString("id")] = at
        }
        if (extra.isNotEmpty()) save(_items.value + extra, restored)
    }

    private fun save(list: List<CatalogBook>, restored: Map<String, Long> = emptyMap()) {
        val before = _items.value.map { it.id }.toSet()
        val now = System.currentTimeMillis()
        val next = HashMap<String, Long>()
        for (b in list) {
            val known = dates[b.id] ?: restored[b.id] ?: 0L
            // a book that was not on the list a moment ago is new today; one that was keeps what we knew
            next[b.id] = if (known > 0L) known else if (b.id !in before) now else 0L
        }
        dates = next
        _items.value = list
        sp.edit()
            .putString("items", write(list).toString())
            .putString("dates", JSONObject().also { o -> next.forEach { (k, v) -> if (v > 0L) o.put(k, v) } }.toString())
            .apply()
    }

    private fun readDates(text: String?): Map<String, Long> {
        if (text.isNullOrBlank()) return emptyMap()
        return try {
            val o = JSONObject(text)
            val out = HashMap<String, Long>()
            for (k in o.keys()) out[k] = o.optLong(k, 0L)
            out
        } catch (e: org.json.JSONException) {
            emptyMap()
        }
    }

    private fun write(list: List<CatalogBook>): JSONArray {
        val arr = JSONArray()
        for (b in list) {
            arr.put(
                JSONObject()
                    .put("id", b.id)
                    .put("title", b.title)
                    .put("author", b.author)
                    .put("year", b.year)
                    .put("cover", b.coverId)
                    .put("rating", b.rating)
                    .put("ratings", b.ratingCount)
                    .put("editions", b.editions)
                    .put("readers", b.readers)
                    .put("addedAt", dates[b.id] ?: 0L)
                    .put("subjects", JSONArray(b.subjects)),
            )
        }
        return arr
    }

    private fun read(text: String?): List<CatalogBook> {
        if (text.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(text)
            val out = ArrayList<CatalogBook>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                val title = o.optString("title")
                if (id.isEmpty() || title.isEmpty()) continue
                val subjects = ArrayList<String>()
                o.optJSONArray("subjects")?.let { s -> for (j in 0 until s.length()) subjects.add(s.optString(j)) }
                out.add(
                    CatalogBook(
                        id, title, o.optString("author"), o.optInt("year"), o.optInt("cover"),
                        o.optDouble("rating", 0.0), o.optInt("ratings"), o.optInt("editions"), o.optInt("readers"), subjects,
                    ),
                )
            }
            out
        } catch (e: org.json.JSONException) {
            emptyList()
        }
    }
}
