package com.paperback.app.data

import com.paperback.app.catalog.CatalogBook
import com.paperback.app.reader.ReaderThemes
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

/*
 * Round 7, as plain functions: every streak you have had, collection stats, the Want to read list, focus (interruptions),
 * place and mood, and pace by the reader look. No Android in here; `today` and the zone are passed in.
 */

private const val DAY_MIN_SECONDS = 60L

// ---- streak history ---------------------------------------------------------------------------

/** One run of reading days in a row. [current] is true for the run that reaches today (or yesterday, while today is still open). */
class StreakRun(val start: LocalDate, val end: LocalDate, val length: Int, val current: Boolean)

class StreakHistory(
    /** Runs of two days or more, newest first. */
    val runs: List<StreakRun>,
    val average: Double,
    val longest: StreakRun?,
    /** The streak you are on today, 0 = none. */
    val currentLength: Int,
    /** True when you have a streak but have not read today yet: it ends tonight if you don't. */
    val atRiskTonight: Boolean,
)

fun streakHistory(rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): StreakHistory? {
    val byDay = Stats.secondsByDay(rows, zone)
    val days = byDay.filterValues { it >= DAY_MIN_SECONDS }.keys.sorted()
    if (days.isEmpty()) return null
    val all = ArrayList<StreakRun>()
    var start = days.first()
    var prev = days.first()
    fun close(end: LocalDate) {
        val len = ChronoUnit.DAYS.between(start, end).toInt() + 1
        val live = end == today || end == today.minusDays(1)
        all.add(StreakRun(start, end, len, live))
    }
    for (i in 1 until days.size) {
        val d = days[i]
        if (d != prev.plusDays(1)) {
            close(prev)
            start = d
        }
        prev = d
    }
    close(prev)
    val runs = all.filter { it.length >= 2 }.sortedByDescending { it.start }
    val current = all.lastOrNull()?.takeIf { it.current }
    val readToday = (byDay[today] ?: 0L) >= DAY_MIN_SECONDS
    val average = if (runs.isEmpty()) 0.0 else runs.sumOf { it.length }.toDouble() / runs.size
    return StreakHistory(
        runs = runs,
        average = average,
        longest = runs.maxByOrNull { it.length },
        currentLength = current?.length ?: 0,
        atRiskTonight = current != null && current.length >= 2 && !readToday,
    )
}

// ---- collections ------------------------------------------------------------------------------

class CollectionRow(val id: String, val name: String, val books: Int, val seconds: Long, val finished: Int) {
    val percentFinished: Int get() = if (books <= 0) 0 else ((finished * 100.0) / books).roundToInt()
}

/** Per collection: books, reading time and how many of its books you finished. Biggest reading time first. */
fun collectionRows(
    collections: List<BookCollection>,
    membership: Map<String, Set<String>>,
    books: List<Book>,
    rows: List<ReadingSession>,
): List<CollectionRow> {
    val byId = books.associateBy { it.id }
    val secs = Stats.secondsByBook(rows)
    return collections.mapNotNull { c ->
        val members = membership[c.id].orEmpty().mapNotNull { byId[it] }
        if (members.isEmpty()) return@mapNotNull null
        CollectionRow(c.id, c.name, members.size, members.sumOf { secs[it.id] ?: 0L }, members.count { it.finished })
    }.sortedWith(compareByDescending<CollectionRow> { it.seconds }.thenByDescending { it.books })
}

// ---- Want to read -----------------------------------------------------------------------------

class WishlistMix(
    val size: Int,
    val genres: List<Pair<String, Int>>,
    val authors: List<Pair<String, Int>>,
    /** The book that has been on the list longest, and for how many days; null when no date is known. */
    val oldest: Pair<String, Int>?,
    /** Average days on the list, over the books with a known date; -1 = none known. */
    val averageDays: Int,
)

fun wishlistMix(items: List<CatalogBook>, addedAt: (String) -> Long, today: LocalDate, zone: ZoneId): WishlistMix? {
    if (items.isEmpty()) return null
    val genreCount = HashMap<String, Int>()
    val authorCount = HashMap<String, Int>()
    for (b in items) {
        for (g in Tags.clean(b.subjects).map(::broadGenre).distinct()) genreCount[g] = (genreCount[g] ?: 0) + 1
        for (a in splitAuthors(b.author)) authorCount[a] = (authorCount[a] ?: 0) + 1
    }
    val ages = items.mapNotNull { b ->
        val at = addedAt(b.id)
        if (at <= 0L) null else b.title to ChronoUnit.DAYS.between(Instant.ofEpochMilli(at).atZone(zone).toLocalDate(), today).toInt().coerceAtLeast(0)
    }
    return WishlistMix(
        size = items.size,
        genres = genreCount.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key }).take(5).map { it.key to it.value },
        authors = authorCount.entries.filter { it.value > 1 }.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key }).take(5).map { it.key to it.value },
        oldest = ages.maxByOrNull { it.second },
        averageDays = if (ages.isEmpty()) -1 else ages.sumOf { it.second } / ages.size,
    )
}

// ---- focus (interruptions) --------------------------------------------------------------------

/** A session the reader counted since interruptions were saved: it carries the look it was read with. */
private fun tracked(s: ReadingSession): Boolean = s.kind == SessionKind.READ && s.seconds > 0 && (s.look.isNotEmpty() || s.breaks > 0)

class FocusBook(val bookId: String, val title: String, val sessions: Int, val focusPercent: Int)

class FocusFigures(
    val sessions: Int,
    /** Share of sessions with no interruption, 0..100. */
    val focusPercent: Int,
    /** Interruptions per hour of reading. */
    val breaksPerHour: Double,
    val mostFocused: FocusBook?,
    val leastFocused: FocusBook?,
)

fun focusFigures(rows: List<ReadingSession>, books: List<Book>): FocusFigures? {
    val list = rows.filter(::tracked)
    if (list.size < 3) return null
    val clean = list.count { it.breaks == 0 }
    val hours = list.sumOf { it.seconds.toLong() } / 3600.0
    val byBook = list.groupBy { it.bookId }.mapNotNull { (id, ss) ->
        if (ss.size < 3) return@mapNotNull null
        val title = books.firstOrNull { it.id == id }?.title ?: return@mapNotNull null
        FocusBook(id, title, ss.size, ((ss.count { it.breaks == 0 } * 100.0) / ss.size).roundToInt())
    }
    val most = byBook.maxByOrNull { it.focusPercent }
    val least = byBook.minByOrNull { it.focusPercent }
    return FocusFigures(
        sessions = list.size,
        focusPercent = ((clean * 100.0) / list.size).roundToInt(),
        breaksPerHour = if (hours <= 0.0) 0.0 else list.sumOf { it.breaks } / hours,
        mostFocused = most,
        leastFocused = if (least != null && most != null && least.bookId != most.bookId) least else null,
    )
}

// ---- place and mood ---------------------------------------------------------------------------

class ContextRow(val label: String, val sessions: Int, val minutes: Int, val averageMinutes: Int)

class ContextFigures(val byPlace: List<ContextRow>, val byMood: List<ContextRow>, val tapped: Int)

/** Time by the place and mood you tapped after a session. Only sessions where you tapped something are in it. */
fun contextFigures(rows: List<ReadingSession>): ContextFigures? {
    val tapped = rows.filter { (it.place > 0 || it.mood > 0) && it.seconds > 0 }
    if (tapped.isEmpty()) return null
    fun rowsOf(key: (ReadingSession) -> String): List<ContextRow> =
        tapped.groupBy(key).filterKeys { it.isNotEmpty() }.map { (label, ss) ->
            val secs = ss.sumOf { it.seconds.toLong() }
            ContextRow(label, ss.size, (secs / 60).toInt(), (secs / 60.0 / ss.size).roundToInt())
        }.sortedByDescending { it.minutes }
    return ContextFigures(rowsOf { SessionPlace.name(it.place) }, rowsOf { SessionMood.name(it.mood) }, tapped.size)
}

// ---- pace by reader look ----------------------------------------------------------------------

private class LookAcc {
    var words = 0.0
    var seconds = 0L
    val wpm: Int get() = if (seconds <= 0L) 0 else (words / (seconds / 60.0)).roundToInt()
}

class LookPace(val byTheme: List<PacePoint>, val byFontSize: List<PacePoint>, val bestTheme: PacePoint?, val bestFont: PacePoint?)

/** "theme|font %|brightness %" as saved with a session; null when it can't be read. */
private fun parseLook(look: String): Pair<Int, Int>? {
    val parts = look.split('|')
    if (parts.size < 2) return null
    val theme = parts[0].toIntOrNull() ?: return null
    val font = parts[1].toIntOrNull() ?: return null
    return theme to font
}

/**
 * Words per minute by the page colour and the text size you read with. Needs sittings of two minutes or more with a
 * saved look, speeds under 1,500 words a minute, and 10 minutes of reading in a group before it is shown.
 */
fun lookPace(rows: List<ReadingSession>, books: List<Book>): LookPace? {
    val byId = books.associateBy { it.id }
    val theme = HashMap<Int, LookAcc>()
    val font = HashMap<Int, LookAcc>()
    for (s in rows) {
        if (s.kind != SessionKind.READ || s.pages <= 0 || s.seconds < 120) continue
        val (th, pct) = parseLook(s.look) ?: continue
        val words = wordsPerPage(byId[s.bookId]) * s.pages
        if (words / (s.seconds / 60.0) > 1500.0) continue
        theme.getOrPut(th) { LookAcc() }.also { it.words += words; it.seconds += s.seconds }
        val bucket = ((pct / 10.0).roundToInt() * 10).coerceIn(50, 300)
        font.getOrPut(bucket) { LookAcc() }.also { it.words += words; it.seconds += s.seconds }
    }
    fun points(map: Map<Int, LookAcc>, label: (Int) -> String): List<PacePoint> =
        map.entries.filter { it.value.seconds >= 600L }.sortedBy { it.key }
            .map { PacePoint(label(it.key), it.value.wpm, (it.value.seconds / 60).toInt()) }
    val byTheme = points(theme) { ReaderThemes.name(it) }
    val byFont = points(font) { "$it%" }
    if (byTheme.size < 2 && byFont.size < 2) return null
    return LookPace(
        byTheme = byTheme.takeIf { it.size >= 2 }.orEmpty(),
        byFontSize = byFont.takeIf { it.size >= 2 }.orEmpty(),
        bestTheme = if (byTheme.size >= 2) byTheme.maxByOrNull { it.wpm } else null,
        bestFont = if (byFont.size >= 2) byFont.maxByOrNull { it.wpm } else null,
    )
}
