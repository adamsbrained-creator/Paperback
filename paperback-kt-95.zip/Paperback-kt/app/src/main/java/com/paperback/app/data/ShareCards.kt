package com.paperback.app.data

/*
 * What goes on a picture you share (Year, a finished book, your week). Plain data and functions: the drawing is in
 * share/ShareImage.kt. [caption] travels with the picture as text, so apps that take a caption show it.
 */

class ShareStat(val value: String, val label: String)

class ShareCard(
    /** A small line above the title, drawn in capitals. */
    val kicker: String,
    val title: String,
    val subtitle: String = "",
    /** Up to six big numbers with a label under each, two to a row. */
    val stats: List<ShareStat> = emptyList(),
    /** A passage, drawn in quotation marks. */
    val quote: String = "",
    /** One more line at the bottom of the card. */
    val note: String = "",
    val caption: String = "",
)

fun yearShareCard(r: YearReview): ShareCard {
    val stats = ArrayList<ShareStat>()
    stats.add(ShareStat(Stats.duration(r.seconds), "time read"))
    stats.add(ShareStat(r.booksFinished.toString(), if (r.booksFinished == 1) "book finished" else "books finished"))
    stats.add(ShareStat(commas(r.pages), "pages"))
    stats.add(ShareStat(r.readingDays.toString(), "reading days"))
    if (r.longestStreak > 1) stats.add(ShareStat(r.longestStreak.toString(), "day streak"))
    if (r.words > 0L) stats.add(ShareStat(wordsText(r.words), "words"))
    val most = listOfNotNull(r.topGenres.firstOrNull()?.label, r.topAuthors.firstOrNull()?.label)
    return ShareCard(
        kicker = "My reading",
        title = "${r.year} in books",
        subtitle = if (most.isEmpty()) "" else "Most read: " + most.joinToString(" · "),
        stats = stats.take(6),
        note = r.longestBook?.let { "Longest book: ${it.title}" }.orEmpty(),
        caption = yearShareText(r),
    )
}

fun finishedShareCard(book: Book, f: FinishedFigures): ShareCard {
    val stats = ArrayList<ShareStat>()
    f.daysTaken?.let { stats.add(ShareStat(it.toString(), if (it == 1) "day" else "days")) }
    if (f.seconds > 0L) stats.add(ShareStat(Stats.duration(f.seconds), "time read"))
    if (f.pages > 0) stats.add(ShareStat(commas(f.pages), "pages"))
    f.stars?.let { stats.add(ShareStat("%.1f".format(it), "stars")) }
    if (f.wpm > 0) stats.add(ShareStat(f.wpm.toString(), "words a minute"))
    val q = f.quote
    return ShareCard(
        kicker = "Finished",
        title = book.title,
        subtitle = book.author,
        stats = stats.take(6),
        quote = if (q == null) "" else (if (q.note.isNotBlank()) q.note else q.text).trim().take(300),
        caption = finishedShareText(book, f),
    )
}

fun weekShareCard(seconds: Long, pages: Int, sessions: Int, daysRead: Int, streak: Int, caption: String): ShareCard {
    val stats = arrayListOf(
        ShareStat(Stats.duration(seconds), "time read"),
        ShareStat(commas(pages), "pages"),
        ShareStat(sessions.toString(), if (sessions == 1) "session" else "sessions"),
        ShareStat("$daysRead of 30", "days read"),
    )
    if (streak > 1) stats.add(ShareStat(streak.toString(), "days in a row"))
    return ShareCard(kicker = "My reading", title = "This week", stats = stats, caption = caption)
}
