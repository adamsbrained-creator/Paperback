package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/*
 * Everything the Stats -> Explore page shows, as plain functions over the library, the reading sessions and the
 * notes. Nothing here touches Android. Sections follow the stats list: time by genre, author and language,
 * listened vs read, pages, days to finish, books per month, this year vs last year, session lengths, breaks,
 * ratings, book lengths, publication years, completion, backlog, paused books and notes.
 */

/** One row of a bar list. [value] sizes the bar; [text] and [sub] are what is written. */
class Bar(
    val label: String,
    val value: Double,
    val text: String,
    val sub: String = "",
    val bookId: String? = null,
)

private const val DAY_MS = 24L * 60L * 60L * 1000L
private const val MIN_READING_DAY_SECONDS = 60L

private fun daysBetween(a: LocalDate, b: LocalDate): Int = ChronoUnit.DAYS.between(a, b).toInt()

private fun pct(part: Long, whole: Long): Int = if (whole <= 0L) 0 else ((part * 100.0) / whole).toInt()

// ---- listened vs read -------------------------------------------------------------------------

class TimeSplit(
    val readSeconds: Long,
    val listenSeconds: Long,
    val loggedSeconds: Long,
    /** The book you listened to most, with its listening seconds; null when you have not listened. */
    val topListened: Pair<String, Long>?,
) {
    val total: Long get() = readSeconds + listenSeconds + loggedSeconds
    val listenPercent: Int get() = pct(listenSeconds, total)
}

fun timeSplit(rows: List<ReadingSession>): TimeSplit {
    var read = 0L
    var listen = 0L
    var logged = 0L
    val listenByBook = HashMap<String, Long>()
    for (r in rows) {
        val s = r.seconds.toLong()
        when (r.kind) {
            SessionKind.LISTEN -> {
                listen += s
                listenByBook[r.bookId] = (listenByBook[r.bookId] ?: 0L) + s
            }
            SessionKind.LOGGED -> logged += s
            else -> read += s
        }
    }
    val top = listenByBook.entries.maxByOrNull { it.value }?.let { it.key to it.value }
    return TimeSplit(read, listen, logged, top)
}

// ---- time by genre, author, language ---------------------------------------------------------

/**
 * Reading time grouped by whatever [keys] says about each book (its genres, authors or language). A book with
 * several genres shares its time evenly between them, so the shares add up to 100%. Time in books you removed is
 * kept under "Removed books".
 */
fun timeBars(rows: List<ReadingSession>, books: List<Book>, limit: Int, keys: (Book) -> List<String>): List<Bar> {
    val byId = books.associateBy { it.id }
    val secs = HashMap<String, Long>()
    for (r in rows) {
        if (r.seconds <= 0) continue
        val b = byId[r.bookId]
        val ks = if (b == null) listOf("Removed books") else keys(b).ifEmpty { listOf("Not set") }
        val share = r.seconds.toLong() / ks.size
        for (k in ks) secs[k] = (secs[k] ?: 0L) + share
    }
    val total = secs.values.sum()
    return secs.entries
        .sortedByDescending { it.value }
        .take(limit)
        .map { Bar(it.key, it.value.toDouble(), Stats.duration(it.value), "${pct(it.value, total)}%") }
}

fun genresOf(b: Book): List<String> = b.tags.map { it.trim() }.filter { it.isNotEmpty() }.take(3)
fun authorsOf(b: Book): List<String> = splitAuthors(b.author)
fun languageOf(b: Book): List<String> = listOf(languageName(b.language)).filter { it.isNotEmpty() }

// ---- pages ------------------------------------------------------------------------------------

class PageFigures(
    /** Pages you turned in all sessions (page turns, not distinct pages). */
    val turned: Int,
    val avgPerSession: Int,
    val longestSessionPages: Int,
    val avgPerMonth: Int,
    /** Pages of every book in the library together. */
    val libraryPages: Int,
    /** Books not finished and not dropped. */
    val booksLeft: Int,
    /** Pages still to read in those books. */
    val pagesLeft: Int,
)

fun pageFigures(rows: List<ReadingSession>, books: List<Book>, today: LocalDate, zone: ZoneId): PageFigures {
    val sessions = buildSessions(rows)
    val turned = sessions.sumOf { it.pages }
    val first = rows.minOfOrNull { it.startMs }
    val months = if (first == null) 1 else {
        val a = dateOf(first, zone)
        (ChronoUnit.MONTHS.between(a.withDayOfMonth(1), today.withDayOfMonth(1)).toInt() + 1).coerceAtLeast(1)
    }
    val left = books.filter { !it.finished && it.status != BookStatus.DROPPED }
    return PageFigures(
        turned = turned,
        avgPerSession = if (sessions.isEmpty()) 0 else turned / sessions.size,
        longestSessionPages = sessions.maxOfOrNull { it.pages } ?: 0,
        avgPerMonth = turned / months,
        libraryPages = books.sumOf { it.pageCount.coerceAtLeast(0) },
        booksLeft = left.size,
        pagesLeft = left.sumOf { (it.pageCount - it.currentPage).coerceAtLeast(0) },
    )
}

// ---- days to finish ---------------------------------------------------------------------------

class FinishRow(val book: Book, val days: Int)

class FinishFigures(
    val count: Int,
    val avgDays: Int,
    val medianDays: Int,
    val fastest: List<FinishRow>,
    val slowest: List<FinishRow>,
)

/**
 * Days from the day you started a book to the day you finished it (same day = 1). The start is the date saved on
 * the book, else the first reading entry. Books with no start we can know are left out.
 */
fun finishFigures(books: List<Book>, rows: List<ReadingSession>, zone: ZoneId): FinishFigures? {
    val firstEntry = HashMap<String, Long>()
    for (r in rows) {
        val cur = firstEntry[r.bookId]
        if (cur == null || r.startMs < cur) firstEntry[r.bookId] = r.startMs
    }
    val list = ArrayList<FinishRow>()
    for (b in books) {
        if (!b.finished) continue
        val start = if (b.startedAt > 0L) b.startedAt else (firstEntry[b.id] ?: 0L)
        if (start <= 0L) continue
        val end = finishedAtMs(b)
        if (end < start - DAY_MS) continue
        val days = (daysBetween(dateOf(start, zone), dateOf(end, zone)) + 1).coerceAtLeast(1)
        list.add(FinishRow(b, days))
    }
    if (list.isEmpty()) return null
    val sorted = list.sortedBy { it.days }
    return FinishFigures(
        count = list.size,
        avgDays = list.sumOf { it.days } / list.size,
        medianDays = sorted[sorted.size / 2].days,
        fastest = sorted.take(3),
        slowest = sorted.takeLast(3).reversed(),
    )
}

// ---- books per month and per year -------------------------------------------------------------

/** Books finished in each month (January first) of [year]. */
fun booksPerMonth(books: List<Book>, year: Int, zone: ZoneId): IntArray {
    val out = IntArray(12)
    for (b in books) {
        if (!b.finished) continue
        val d = finishedDate(b, zone)
        if (d.year == year) out[d.monthValue - 1]++
    }
    return out
}

/** Books finished per year, newest year first. */
fun booksPerYear(books: List<Book>, zone: ZoneId): List<Pair<Int, Int>> =
    books.filter { it.finished }
        .groupingBy { finishedDate(it, zone).year }
        .eachCount()
        .entries.sortedByDescending { it.key }
        .map { it.key to it.value }

// ---- this year vs last year -------------------------------------------------------------------

class YearTotals(val year: Int, val seconds: Long, val pages: Int, val books: Int, val days: Int)

/** This year and last year, both only up to today's date, so the comparison is fair. */
fun yearCompare(rows: List<ReadingSession>, books: List<Book>, today: LocalDate, zone: ZoneId): Pair<YearTotals, YearTotals> {
    fun totals(year: Int): YearTotals {
        val end = runCatching { LocalDate.of(year, today.monthValue, today.dayOfMonth) }.getOrElse { LocalDate.of(year, 2, 28) }
        var seconds = 0L
        var pages = 0
        val days = HashMap<LocalDate, Long>()
        for (r in rows) {
            val d = dateOf(r.startMs, zone)
            if (d.year != year || d.isAfter(end)) continue
            seconds += r.seconds
            pages += r.pages
            days[d] = (days[d] ?: 0L) + r.seconds
        }
        val finished = books.count { it.finished && finishedDate(it, zone).let { d -> d.year == year && !d.isAfter(end) } }
        return YearTotals(year, seconds, pages, finished, days.count { it.value >= MIN_READING_DAY_SECONDS })
    }
    return totals(today.year) to totals(today.year - 1)
}

// ---- session lengths --------------------------------------------------------------------------

class LengthSpread(
    val buckets: List<Bar>,
    val medianSeconds: Long,
    val count: Int,
    val commonBucket: String,
)

fun lengthSpread(rows: List<ReadingSession>): LengthSpread? {
    val sessions = buildSessions(rows).filter { it.seconds > 0 }
    if (sessions.isEmpty()) return null
    val labels = listOf("Under 10 min", "10 to 30 min", "30 to 60 min", "Over an hour")
    val counts = IntArray(4)
    for (s in sessions) {
        val m = s.seconds / 60.0
        counts[if (m < 10) 0 else if (m < 30) 1 else if (m < 60) 2 else 3]++
    }
    val sorted = sessions.map { it.seconds }.sorted()
    val common = counts.indices.maxByOrNull { counts[it] } ?: 0
    return LengthSpread(
        buckets = labels.indices.map { Bar(labels[it], counts[it].toDouble(), counts[it].toString(), "${pct(counts[it].toLong(), sessions.size.toLong())}%") },
        medianSeconds = sorted[sorted.size / 2],
        count = sessions.size,
        commonBucket = labels[common],
    )
}

// ---- breaks -----------------------------------------------------------------------------------

class BreakFigures(
    /** 0 = you read today. */
    val daysSince: Int,
    val longestBreak: Int,
    val avgGap: Double,
    val readingDays: Int,
)

fun breakFigures(rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): BreakFigures? {
    val byDay = Stats.secondsByDay(rows, zone).filterValues { it >= MIN_READING_DAY_SECONDS }.keys.sorted()
    if (byDay.isEmpty()) return null
    var longest = 0
    var gapSum = 0
    for (i in 1 until byDay.size) {
        val gap = daysBetween(byDay[i - 1], byDay[i])
        gapSum += gap
        if (gap - 1 > longest) longest = gap - 1
    }
    return BreakFigures(
        daysSince = daysBetween(byDay.last(), today).coerceAtLeast(0),
        longestBreak = longest,
        avgGap = if (byDay.size > 1) gapSum.toDouble() / (byDay.size - 1) else 0.0,
        readingDays = byDay.size,
    )
}

// ---- ratings ----------------------------------------------------------------------------------

class RatingFigures(
    /** Index 0 = one star ... 4 = five stars. */
    val histogram: IntArray,
    val rated: Int,
    val average: Double,
    val byGenre: List<Bar>,
    val byAuthor: List<Bar>,
)

fun ratingFigures(books: List<Book>): RatingFigures? {
    val rated = books.filter { ratingStars(it) > 0 }
    if (rated.isEmpty()) return null
    val hist = IntArray(5)
    for (b in rated) hist[ratingStars(b) - 1]++

    fun averages(keys: (Book) -> List<String>): List<Bar> {
        val sum = HashMap<String, Double>()
        val n = HashMap<String, Int>()
        for (b in rated) {
            val score = if (b.rating10 > 0f) b.rating10 / 2.0 else ratingStars(b).toDouble()
            for (k in keys(b)) {
                sum[k] = (sum[k] ?: 0.0) + score
                n[k] = (n[k] ?: 0) + 1
            }
        }
        return sum.keys
            .filter { (n[it] ?: 0) >= 2 }
            .map { k -> k to (sum.getValue(k) / n.getValue(k)) }
            .sortedWith(compareByDescending<Pair<String, Double>> { it.second }.thenBy { it.first })
            .take(5)
            .map { (k, avg) -> Bar(k, avg, "%.1f".format(avg) + "\u2605", "${n[k]} books") }
    }

    val avg = rated.map { if (it.rating10 > 0f) it.rating10 / 2.0 else ratingStars(it).toDouble() }.average()
    return RatingFigures(hist, rated.size, avg, averages(::genresOf), averages(::authorsOf))
}

// ---- book lengths -----------------------------------------------------------------------------

class LengthFigures(
    val buckets: List<Bar>,
    val avgPages: Int,
    val finishedPages: Int,
    val counted: Int,
)

fun lengthFigures(books: List<Book>): LengthFigures? {
    val done = books.filter { it.finished && it.pageCount > 0 }
    if (done.isEmpty()) return null
    val labels = listOf("Short \u00B7 under 200", "Medium \u00B7 200 to 349", "Long \u00B7 350 to 499", "Epic \u00B7 $EPIC_PAGES and more")
    val counts = IntArray(4)
    for (b in done) {
        val p = b.pageCount
        counts[if (p < 200) 0 else if (p < 350) 1 else if (p < EPIC_PAGES) 2 else 3]++
    }
    return LengthFigures(
        buckets = labels.indices.map { Bar(labels[it], counts[it].toDouble(), counts[it].toString(), "${pct(counts[it].toLong(), done.size.toLong())}%") },
        avgPages = done.sumOf { it.pageCount } / done.size,
        finishedPages = done.sumOf { it.pageCount },
        counted = done.size,
    )
}

// ---- publication years ------------------------------------------------------------------------

class PublicationFigures(
    val decades: List<Bar>,
    val oldest: Pair<Book, Int>,
    val newest: Pair<Book, Int>,
    val publishers: List<Bar>,
)

fun publicationYear(b: Book): Int? =
    Regex("^\\s*(\\d{4})").find(b.published)?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it in 1000..2200 }

fun publicationFigures(books: List<Book>): PublicationFigures? {
    val dated = books.mapNotNull { b -> publicationYear(b)?.let { b to it } }
    if (dated.isEmpty()) return null
    val byDecade = dated.groupingBy { (it.second / 10) * 10 }.eachCount().entries.sortedByDescending { it.key }
    val maxCount = (byDecade.maxOfOrNull { it.value } ?: 1).toDouble()
    val decades = byDecade.map { Bar("${it.key}s", it.value.toDouble() / maxCount, it.value.toString(), if (it.value == 1) "1 book" else "${it.value} books") }
    val publishers = books.map { it.publisher.trim() }.filter { it.isNotEmpty() }
        .groupingBy { it }.eachCount().entries
        .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
        .take(5)
        .map { Bar(it.key, it.value.toDouble(), it.value.toString()) }
    return PublicationFigures(decades, dated.minByOrNull { it.second }!!, dated.maxByOrNull { it.second }!!, publishers)
}

// ---- completion, backlog, paused --------------------------------------------------------------

class CompletionFigures(
    val started: Int,
    val finished: Int,
    val dropped: Int,
    val paused: Int,
    /** Average percent you had read when you dropped a book; null when none is dropped. */
    val avgDroppedAt: Int?,
    /** Share of started books that you finished. */
    val rate: Int,
)

fun completionFigures(books: List<Book>): CompletionFigures {
    val started = books.filter { it.finished || it.isReading || it.status != BookStatus.NORMAL }
    val finished = started.count { it.finished }
    val dropped = books.filter { it.status == BookStatus.DROPPED && !it.finished }
    return CompletionFigures(
        started = started.size,
        finished = finished,
        dropped = dropped.size,
        paused = books.count { it.status == BookStatus.PAUSED && !it.finished },
        avgDroppedAt = if (dropped.isEmpty()) null else dropped.sumOf { it.droppedPct } / dropped.size,
        rate = pct(finished.toLong(), started.size.toLong()),
    )
}

class BacklogFigures(
    val books: Int,
    val pages: Int,
    val oldest: Book?,
    /** Days the pile lasts at the pace of the last 90 days, null when there is no recent pace. */
    val daysToClear: Int?,
)

fun backlogFigures(books: List<Book>, rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): BacklogFigures {
    val pile = books.filter { !it.finished && !it.isReading && it.status == BookStatus.NORMAL }
    val pages = pile.sumOf { it.pageCount.coerceAtLeast(0) }
    val since = today.minusDays(90)
    val recent = rows.filter { !dateOf(it.startMs, zone).isBefore(since) }.sumOf { it.pages }
    val perDay = recent / 90.0
    return BacklogFigures(
        books = pile.size,
        pages = pages,
        oldest = pile.minByOrNull { it.addedAt },
        daysToClear = if (perDay >= 1.0 && pages > 0) (pages / perDay).toInt() else null,
    )
}

class PausedRow(val book: Book, val idleDays: Int)

/** Books you started and have not opened for [minDays] days or more, the longest idle first. Dropped books are not listed. */
fun idleBooks(books: List<Book>, rows: List<ReadingSession>, today: LocalDate, zone: ZoneId, minDays: Int = 30): List<PausedRow> {
    val lastEntry = HashMap<String, Long>()
    for (r in rows) {
        val cur = lastEntry[r.bookId]
        if (cur == null || r.startMs > cur) lastEntry[r.bookId] = r.startMs
    }
    return books
        .filter { !it.finished && it.isReading && it.status != BookStatus.DROPPED }
        .mapNotNull { b ->
            val last = maxOf(b.lastOpenedAt, lastEntry[b.id] ?: 0L)
            if (last <= 0L) return@mapNotNull null
            val idle = daysBetween(dateOf(last, zone), today)
            if (idle >= minDays) PausedRow(b, idle) else null
        }
        .sortedByDescending { it.idleDays }
}

// ---- notes ------------------------------------------------------------------------------------

class NoteFigures(
    val total: Int,
    val withNote: Int,
    val plain: Int,
    val perHundredPages: Double,
    val byColor: List<Pair<Int, Int>>,
    val topBooks: List<Bar>,
    /** The last six months, oldest first: label and count. */
    val byMonth: List<Bar>,
)

fun noteFigures(highlights: List<Highlight>, books: List<Book>, today: LocalDate, zone: ZoneId): NoteFigures? {
    if (highlights.isEmpty()) return null
    val byId = books.associateBy { it.id }
    val withNote = highlights.count { it.note.isNotBlank() }
    val bookIds = highlights.map { it.bookId }.toSet()
    val pagesOfThose = bookIds.sumOf { id -> byId[id]?.let { maxOf(it.currentPage, 0) } ?: 0 }
    val perHundred = if (pagesOfThose > 0) highlights.size * 100.0 / pagesOfThose else 0.0
    val colors = highlights.groupingBy { it.color }.eachCount().entries.sortedByDescending { it.value }.map { it.key to it.value }
    val top = highlights.groupingBy { it.bookId }.eachCount().entries.sortedByDescending { it.value }.take(3).map { e ->
        Bar(byId[e.key]?.title ?: "Removed book", e.value.toDouble(), e.value.toString(), "", byId[e.key]?.id)
    }
    val months = (5 downTo 0).map { i -> today.withDayOfMonth(1).minusMonths(i.toLong()) }
    val monthBars = months.map { m ->
        val n = highlights.count { val d = dateOf(it.createdAt, zone); d.year == m.year && d.monthValue == m.monthValue }
        Bar(StatNames.MONTHS_SHORT[m.monthValue - 1], n.toDouble(), n.toString())
    }
    return NoteFigures(highlights.size, withNote, highlights.size - withNote, perHundred, colors, top, monthBars)
}

// ================================================================================================
// Round 2
// ================================================================================================

// ---- genres grouped into broad ones -----------------------------------------------------------

/** Keywords of each broad genre, checked in this order: the first that appears in a tag decides. */
private val BROAD_GENRES: List<Pair<String, List<String>>> = listOf(
    "Science fiction" to listOf("science fiction", "sci-fi", "scifi", "cyberpunk", "dystopia", "space opera"),
    "Fantasy" to listOf("fantasy", "fairy", "magic", "wizard", "dragon", "mythology"),
    "Mystery & thriller" to listOf("mystery", "thriller", "crime", "detective", "suspense", "noir", "spy"),
    "Horror" to listOf("horror", "gothic", "ghost", "supernatural"),
    "Romance" to listOf("romance", "love stor"),
    "Historical" to listOf("historical", "history", "war", "ancient", "medieval"),
    "Biography & memoir" to listOf("biograph", "memoir", "autobiograph", "diaries"),
    "Self-help & business" to listOf("self-help", "self help", "business", "productivity", "personal development", "finance", "economics", "management", "leadership", "success"),
    "Psychology & philosophy" to listOf("psycholog", "philosoph", "ethics", "mind"),
    "Science & technology" to listOf("science", "nature", "physics", "biology", "mathemat", "technology", "computer", "programming", "engineering", "medicine", "space", "artificial", "software", "chemistry", "astronom"),
    "Religion & spirituality" to listOf("religio", "spiritual", "theolog", "bible", "christian", "islam", "buddh"),
    "Poetry & drama" to listOf("poetry", "poem", "drama", "plays", "theatre", "theater"),
    "Children & young adult" to listOf("juvenile", "children", "young adult", "teen", "picture book", "ya "),
    "Classics" to listOf("classic"),
    "Literary fiction" to listOf("fiction", "literary", "literature", "novel", "stories", "humor", "humour", "satire"),
    "Non-fiction" to listOf("non-fiction", "nonfiction", "essay", "reference", "education", "travel", "cooking", "art", "music", "sport", "politic", "social", "true"),
)

/** "Epic Fantasy" -> "Fantasy", "Business & Economics" -> "Self-help & business"; anything unknown -> "Other". */
fun broadGenre(tag: String): String {
    val t = tag.lowercase().trim()
    if (t.isEmpty()) return "Other"
    for ((name, matchers) in BROAD_MATCHERS) if (matchers.any { it.containsMatchIn(t) }) return name
    return "Other"
}

/**
 * Short keywords (4 letters or fewer) must be a whole word, so "war" does not match "software"; longer ones match the
 * start of a word, so "biograph" matches "biography" and "autobiographies".
 */
private val BROAD_MATCHERS: List<Pair<String, List<Regex>>> = BROAD_GENRES.map { (name, words) ->
    name to words.map { w ->
        val k = w.trim()
        Regex(if (k.length <= 4) "\\b" + Regex.escape(k) + "\\b" else "\\b" + Regex.escape(k))
    }
}

fun broadGenresOf(b: Book): List<String> = genresOf(b).map(::broadGenre).distinct()

// ---- format and source ------------------------------------------------------------------------

fun formatLabel(b: Book): String = when (b.format) {
    "ebook" -> "E-book"
    "paperback" -> "Paperback"
    "hardcover" -> "Hardcover"
    "audiobook" -> "Audiobook"
    "mixed" -> "Mixed"
    "other" -> "Other"
    else -> when {
        b.isPdf -> "PDF"
        b.hasFile -> "E-book"
        else -> "Format not set"
    }
}

fun sourceLabel(b: Book): String = when (b.source.lowercase()) {
    "" -> if (b.hasFile) "Imported file" else "Added without a file"
    "file" -> "Imported file"
    "gutenberg" -> "Project Gutenberg"
    "standardebooks", "standard ebooks" -> "Standard Ebooks"
    "calibre" -> "Calibre"
    "catalog" -> "Online catalog"
    "bookshelf" -> "Bookshelf history"
    "pdf", "reflow" -> "Reflowed PDF"
    else -> b.source.trim().replaceFirstChar { it.uppercase() }
}

/** Books and hours per format, most books first. */
fun formatBars(books: List<Book>, rows: List<ReadingSession>): List<Bar> {
    val secsByBook = Stats.secondsByBook(rows)
    val groups = books.groupBy(::formatLabel)
    val max = (groups.values.maxOfOrNull { it.size } ?: 1).toDouble()
    return groups.entries.sortedByDescending { it.value.size }.map { (label, list) ->
        val secs = list.sumOf { secsByBook[it.id] ?: 0L }
        Bar(label, list.size / max, "${list.size} ${if (list.size == 1) "book" else "books"}", if (secs > 0) Stats.duration(secs) else "")
    }
}

/** Books per source, with the share of them you finished. */
fun sourceBars(books: List<Book>): List<Bar> {
    val groups = books.groupBy(::sourceLabel)
    val max = (groups.values.maxOfOrNull { it.size } ?: 1).toDouble()
    return groups.entries.sortedByDescending { it.value.size }.map { (label, list) ->
        Bar(label, list.size / max, "${list.size} ${if (list.size == 1) "book" else "books"}", "${pct(list.count { it.finished }.toLong(), list.size.toLong())}% finished")
    }
}

// ---- series -----------------------------------------------------------------------------------

class SeriesRow(val name: String, val total: Int, val finished: Int, val next: Book?)

/** Series you have books of: how many you own and finished, and the next one to read (the lowest number not finished). */
fun seriesRows(books: List<Book>): List<SeriesRow> =
    books.filter { it.series.isNotBlank() }
        .groupBy { it.series.trim().lowercase() }
        .values
        .map { list ->
            val ordered = list.sortedWith(compareBy<Book> { if (it.seriesNo > 0f) it.seriesNo else Float.MAX_VALUE }.thenBy { it.title.lowercase() })
            SeriesRow(
                name = list.first().series.trim(),
                total = list.size,
                finished = list.count { it.finished },
                next = ordered.firstOrNull { !it.finished && it.status != BookStatus.DROPPED },
            )
        }
        .sortedWith(compareByDescending<SeriesRow> { it.total - it.finished > 0 }.thenByDescending { it.finished }.thenBy { it.name.lowercase() })

// ---- chapters ---------------------------------------------------------------------------------

class ChapterFigures(
    val chapters: Int,
    val booksWithChapters: Int,
    val pagesPerChapter: Double?,
    val minutesPerChapter: Double?,
    val topBooks: List<Bar>,
)

/** From entries that say how many chapters they covered (imported history for now). */
fun chapterFigures(rows: List<ReadingSession>, books: List<Book>): ChapterFigures? {
    val withCh = rows.filter { it.chapters > 0 }
    if (withCh.isEmpty()) return null
    val total = withCh.sumOf { it.chapters }
    val pages = withCh.sumOf { it.pages }
    val seconds = withCh.sumOf { it.seconds.toLong() }
    val byId = books.associateBy { it.id }
    val perBook = withCh.groupBy { it.bookId }.mapValues { e -> e.value.sumOf { it.chapters } }
    val top = perBook.entries.sortedByDescending { it.value }.take(5)
    val max = (top.firstOrNull()?.value ?: 1).toDouble()
    return ChapterFigures(
        chapters = total,
        booksWithChapters = perBook.size,
        pagesPerChapter = if (pages > 0) pages.toDouble() / total else null,
        minutesPerChapter = if (seconds > 0) seconds / 60.0 / total else null,
        topBooks = top.map { Bar(byId[it.key]?.title ?: "Removed book", it.value / max, "${it.value} chapters", "", byId[it.key]?.id) },
    )
}

// ---- this month so far against last month -----------------------------------------------------

class MonthTotals(val label: String, val seconds: Long, val pages: Int, val sessions: Int, val books: Int, val days: Int)

/** This month up to today, and last month up to the same day of the month. */
fun monthCompare(rows: List<ReadingSession>, books: List<Book>, today: LocalDate, zone: ZoneId): Pair<MonthTotals, MonthTotals> {
    fun totals(first: LocalDate): MonthTotals {
        val lastDay = minOf(today.dayOfMonth, first.lengthOfMonth())
        val end = first.withDayOfMonth(lastDay)
        val inMonth = rows.filter { val d = dateOf(it.startMs, zone); !d.isBefore(first) && !d.isAfter(end) }
        val byDay = Stats.secondsByDay(inMonth, zone)
        val finished = books.count { it.finished && finishedDate(it, zone).let { d -> !d.isBefore(first) && !d.isAfter(end) } }
        return MonthTotals(
            label = StatNames.MONTHS[first.monthValue - 1],
            seconds = inMonth.sumOf { it.seconds.toLong() },
            pages = inMonth.sumOf { it.pages },
            sessions = buildSessions(inMonth).size,
            books = finished,
            days = byDay.count { it.value >= MIN_READING_DAY_SECONDS },
        )
    }
    val thisFirst = today.withDayOfMonth(1)
    return totals(thisFirst) to totals(thisFirst.minusMonths(1))
}

// ---- all time totals --------------------------------------------------------------------------

class AllTime(val books: Int, val finished: Int, val daysRead: Int, val seconds: Long, val pagesTurned: Int, val libraryPages: Int, val bestStreak: Int)

fun allTime(rows: List<ReadingSession>, books: List<Book>, zone: ZoneId): AllTime {
    val byDay = Stats.secondsByDay(rows, zone)
    return AllTime(
        books = books.size,
        finished = books.count { it.finished },
        daysRead = byDay.count { it.value >= MIN_READING_DAY_SECONDS },
        seconds = rows.sumOf { it.seconds.toLong() },
        pagesTurned = rows.sumOf { it.pages },
        libraryPages = books.sumOf { it.pageCount.coerceAtLeast(0) },
        bestStreak = Stats.longestStreak(byDay),
    )
}

// ---- recently added and finished --------------------------------------------------------------

class DatedBook(val book: Book, val ms: Long)

fun recentlyAdded(books: List<Book>, n: Int = 5): List<DatedBook> =
    books.sortedByDescending { it.addedAt }.take(n).map { DatedBook(it, it.addedAt) }

fun recentlyFinished(books: List<Book>, n: Int = 5): List<DatedBook> =
    books.filter { it.finished }.sortedByDescending { finishedAtMs(it) }.take(n).map { DatedBook(it, finishedAtMs(it)) }

// ---- added against finished -------------------------------------------------------------------

/** Books added to the library in each month (January first) of [year]. */
fun booksAddedPerMonth(books: List<Book>, year: Int, zone: ZoneId): IntArray {
    val out = IntArray(12)
    for (b in books) {
        if (b.addedAt <= 0L) continue
        val d = dateOf(b.addedAt, zone)
        if (d.year == year) out[d.monthValue - 1]++
    }
    return out
}

// ---- favorites --------------------------------------------------------------------------------

class FavoriteFigures(val count: Int, val sharePercent: Int, val byGenre: List<Bar>)

fun favoriteFigures(books: List<Book>): FavoriteFigures? {
    val fav = books.filter { it.favorite }
    if (fav.isEmpty()) return null
    val groups = fav.flatMap { b -> broadGenresOf(b).ifEmpty { listOf("Other") } }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5)
    val max = (groups.firstOrNull()?.value ?: 1).toDouble()
    return FavoriteFigures(fav.size, pct(fav.size.toLong(), books.size.toLong()), groups.map { Bar(it.key, it.value / max, it.value.toString()) })
}

// ---- quote of the day and journals ------------------------------------------------------------

/** One of your highlights, the same all day and a different one tomorrow. */
fun quoteOfTheDay(highlights: List<Highlight>, today: LocalDate): Highlight? {
    val usable = highlights.filter { it.text.trim().length >= 20 }.sortedBy { it.id }
    if (usable.isEmpty()) return null
    return usable[Math.floorMod(today.toEpochDay(), usable.size.toLong()).toInt()]
}

/**
 * The chapter a highlight was made in, from the place saved with it (the reader saves the chapter title there), or ""
 * when it is not known: a PDF page, or a highlight made before chapter titles were saved.
 */
fun chapterOf(h: Highlight): String =
    runCatching { org.json.JSONObject(h.locatorJson).optString("title", "") }.getOrDefault("").trim().take(80)

class JournalFigures(val books: Int, val words: Int, val longest: Book?)

fun journalFigures(books: List<Book>): JournalFigures? {
    val withJournal = books.filter { it.journal.isNotBlank() }
    if (withJournal.isEmpty()) return null
    fun words(s: String) = s.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
    return JournalFigures(withJournal.size, withJournal.sumOf { words(it.journal) }, withJournal.maxByOrNull { words(it.journal) })
}
