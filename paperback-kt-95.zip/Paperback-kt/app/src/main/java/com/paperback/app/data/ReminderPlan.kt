package com.paperback.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/*
 * The reading reminder, as plain functions (no Android, no clock: the time, the day and the zone are passed in).
 * One notification a day, at your usual reading hour or at a time you pick, and only when you have not read yet today.
 */

/** When the reminder goes off. [key] is what is saved. */
enum class ReminderMode(val key: String, val label: String) {
    Off("off", "Off"),
    Peak("peak", "Usual hour"),
    Fixed("fixed", "My time"),
}

fun reminderModeOf(key: String?): ReminderMode = ReminderMode.values().firstOrNull { it.key == key } ?: ReminderMode.Off

/** 21:00, until you pick another time. */
const val DEFAULT_REMINDER_MINUTE = 21 * 60

/** "21:00" for a minute of the day (0 to 1439). */
fun clockText(minuteOfDay: Int): String {
    val m = minuteOfDay.coerceIn(0, 24 * 60 - 1)
    return "%02d:%02d".format(m / 60, m % 60)
}

/**
 * The minute of the day to remind you, or null when the reminder is off. "Usual hour" uses the hour you read most
 * ([peakHour]); until there is enough reading to tell, it uses your own time ([fixedMinute]) so it still reminds.
 */
fun reminderMinute(mode: ReminderMode, fixedMinute: Int, peakHour: Int?): Int? = when (mode) {
    ReminderMode.Off -> null
    ReminderMode.Fixed -> fixedMinute.coerceIn(0, 24 * 60 - 1)
    ReminderMode.Peak -> if (peakHour != null) peakHour.coerceIn(0, 23) * 60 else fixedMinute.coerceIn(0, 24 * 60 - 1)
}

/** The next moment (ms) after [nowMs] that the clock reads [minuteOfDay] in [zone]: later today, or tomorrow. */
fun nextReminderAtMs(nowMs: Long, minuteOfDay: Int, zone: ZoneId): Long {
    val m = minuteOfDay.coerceIn(0, 24 * 60 - 1)
    val now = Instant.ofEpochMilli(nowMs).atZone(zone)
    fun at(day: LocalDate) = day.atTime(m / 60, m % 60).atZone(zone).toInstant().toEpochMilli()
    val today = at(now.toLocalDate())
    return if (today > nowMs) today else at(now.toLocalDate().plusDays(1))
}

class ReminderMessage(val title: String, val text: String)

/**
 * What the notification says, or null when it should stay quiet: you already read today (a minute or more), or the day's
 * goal is done. [bookTitle] is the book you are in, if any.
 */
fun reminderMessage(todaySeconds: Long, goals: Goals, streak: Int, bookTitle: String?): ReminderMessage? {
    if (todaySeconds >= 60L) return null
    val tiny = goals.tinyMinutes.coerceAtLeast(1)
    val book = if (bookTitle.isNullOrBlank()) "" else " Continue $bookTitle."
    return if (streak >= 2) {
        ReminderMessage("Keep your $streak-day streak", "Even $tiny ${if (tiny == 1) "minute" else "minutes"} counts as a reading day.$book")
    } else {
        ReminderMessage("Time to read", "$tiny ${if (tiny == 1) "minute is" else "minutes is"} enough to count today. Your goal is ${goals.minutesPerDay}.$book")
    }
}
