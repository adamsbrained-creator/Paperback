package com.paperback.app.ui

import androidx.compose.runtime.staticCompositionLocalOf
import com.paperback.app.data.ShareCard

/**
 * How a card becomes a picture and opens the share sheet. MainActivity provides the real one; any screen can call it
 * (`val shareImage = LocalShareImage.current`, then `shareImage(card)`), so nothing has to be passed down page by page.
 */
val LocalShareImage = staticCompositionLocalOf<(ShareCard) -> Unit> { {} }
