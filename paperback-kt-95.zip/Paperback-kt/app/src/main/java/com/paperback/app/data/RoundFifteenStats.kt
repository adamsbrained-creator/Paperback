package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/*
 * Round 15, as plain functions: reading points with levels, and the numbers for any range of days you pick.
 */

// ---- reading points ---------------------------------------------------------------------------

class PointsFigures(
    val total: Int,
    val level: Int,
    val title: String,
    /** Points earned since the start of this level, and what the level takes in all. */
    val intoLevel: Int,
    val levelSize: Int,
    /** Where the points came from: reading time, goal days, finished books, highlights, streak weeks. */
    val parts: List<Pair<String, Int>>,
    val thisWeek: Int,
    val bestWeek: Int,
)

/** Points needed to reach [level] (level 1 = 0, level 2 = 200, level 3 = 600, level 4 = 1,200 ...). */
fun pointsToReach(level: Int): Int = 100 * level * (level - 1)

private fun levelTitle(level: Int): String = when {
    level <= 2 -> "Page turner"
    level <= 4 -> "Bookworm"
    level <= 6 -> "Bibliophile"
    level <= 9 -> "Scholar"
    else -> "Library keeper"
}

/**
 * One point for each minute you read or listened, 10 for every day you met your daily goal, 100 for each book you
 * finished, 2 for each highlight (3 more when it has a note) and 50 for every full week of a reading streak. Worked out
 * from your history each time, nothing is stored, so it follows edits and imports. The daily goal is today's.
 */
fun readingPoints(
    books: List<Book>,
    sessions: List<ReadingSession>,
    highlights: List<Highlight>,
    goals: Goals,
    today: LocalDate,
    zone: ZoneId,
): PointsFigures? {
    val byDay = Stats.secondsByDay(sessions, zone)
    if (byDay.isEmpty() && books.none { it.finished } && highlights.isEmpty()) return null

    val perDay = HashMap<LocalDate, Int>()
    fun add(day: LocalDate, points: Int) { perDay[day] = (perDay[day] ?: 0) + points }
    var timePts = 0
    var goalPts = 0
    var bookPts = 0
    var notePts = 0
    var streakPts = 0

    for ((day, secs) in byDay) {
        val minutes = (secs / 60).toInt()
        timePts += minutes
        add(day, minutes)
        if (secs >= goals.minutesPerDay * 60L) { goalPts += 10; add(day, 10) }
    }
    for (b in books) if (b.finished) { bookPts += 100; add(finishedDate(b, zone), 100) }
    for (h in highlights) {
        val p = if (h.note.isNotBlank()) 5 else 2
        notePts += p
        add(dateOf(h.createdAt, zone), p)
    }
    // a full week of reading days in a row, paid on the day it is complete
    var run = 0
    var prev: LocalDate? = null
    for (day in byDay.filterValues { it >= 60L }.keys.sorted()) {
        run = if (prev != null && ChronoUnit.DAYS.between(prev, day) == 1L) run + 1 else 1
        if (run % 7 == 0) { streakPts += 50; add(day, 50) }
        prev = day
    }

    val total = timePts + goalPts + bookPts + notePts + streakPts
    var level = 1
    while (pointsToReach(level + 1) <= total) level++
    val start = pointsToReach(level)
    val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val byWeek = perDay.entries.groupBy { it.key.minusDays((it.key.dayOfWeek.value - 1).toLong()) }
        .mapValues { g -> g.value.sumOf { it.value } }
    return PointsFigures(
        total = total,
        level = level,
        title = levelTitle(level),
        intoLevel = total - start,
        levelSize = pointsToReach(level + 1) - start,
        parts = listOf(
            "Reading time" to timePts, "Goal days" to goalPts, "Books finished" to bookPts,
            "Highlights and notes" to notePts, "Streak weeks" to streakPts,
        ).filter { it.second > 0 },
        thisWeek = byWeek[monday] ?: 0,
        bestWeek = byWeek.values.maxOrNull() ?: 0,
    )
}

// ---- any range of days ------------------------------------------------------------------------

class RangeFigures(
    val start: LocalDate,
    val end: LocalDate,
    val days: Int,
    val seconds: Long,
    val pages: Int,
    val sessions: Int,
    val readingDays: Int,
    val booksFinished: Int,
    val topGenre: String?,
    val topAuthor: String?,
    /** The same number of days just before [start]. */
    val prevSeconds: Long,
    val prevPages: Int,
    val prevBooks: Int,
)

/** Everything between [start] and [end] (both included), against the same number of days before it. */
fun rangeFigures(start: LocalDate, end: LocalDate, books: List<Book>, sessions: List<ReadingSession>, zone: ZoneId): RangeFigures {
    val from = if (end.isBefore(start)) end else start
    val to = if (end.isBefore(start)) start else end
    val days = (ChronoUnit.DAYS.between(from, to).toInt() + 1).coerceAtLeast(1)
    val prevFrom = from.minusDays(days.toLong())
    val prevTo = from.minusDays(1)

    fun inRange(r: ReadingSession, a: LocalDate, b: LocalDate): Boolean {
        val d = dateOf(r.startMs, zone)
        return !d.isBefore(a) && !d.isAfter(b)
    }
    fun finishedIn(a: LocalDate, b: LocalDate) = books.count { it.finished && finishedDate(it, zone).let { d -> !d.isBefore(a) && !d.isAfter(b) } }

    val rows = sessions.filter { inRange(it, from, to) }
    val prev = sessions.filter { inRange(it, prevFrom, prevTo) }
    val byDay = Stats.secondsByDay(rows, zone)
    return RangeFigures(
        start = from, end = to, days = days,
        seconds = rows.sumOf { it.seconds.toLong() },
        pages = rows.sumOf { it.pages },
        sessions = buildSessions(rows).size,
        readingDays = byDay.count { it.value >= 60L },
        booksFinished = finishedIn(from, to),
        topGenre = timeBars(rows, books, 1, ::broadGenresOf).firstOrNull()?.label?.takeIf { it != "Not set" && it != "Other" },
        topAuthor = timeBars(rows, books, 1, ::authorsOf).firstOrNull()?.label?.takeIf { it != "Not set" },
        prevSeconds = prev.sumOf { it.seconds.toLong() },
        prevPages = prev.sumOf { it.pages },
        prevBooks = finishedIn(prevFrom, prevTo),
    )
}
