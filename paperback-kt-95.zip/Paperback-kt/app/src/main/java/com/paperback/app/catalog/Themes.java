package com.paperback.app.catalog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * What the descriptions of the books you like are about, compared with the description of a book you may like.
 * Words that few descriptions use count more (tf-idf), and the score is how close the two are (cosine). Worked
 * out on the phone from text that is already there; nothing about your books is sent anywhere.
 */
public final class Themes {
    private Themes() {}

    /** Words that say nothing about a book: small words, and the words every back cover has. */
    private static final Set<String> STOP = new HashSet<String>(Arrays.asList(
        "about", "after", "again", "against", "also", "another", "because", "been", "before", "being", "between",
        "both", "book", "books", "but", "came", "come", "comes", "could", "does", "each", "even", "ever", "every",
        "first", "from", "gets", "give", "gives", "goes", "have", "having", "here", "himself", "herself", "into",
        "just", "know", "knows", "last", "like", "made", "make", "makes", "many", "more", "most", "much", "must",
        "never", "nothing", "novel", "only", "other", "others", "over", "part", "people", "same", "says", "series",
        "should", "since", "some", "something", "still", "story", "stories", "such", "take", "takes", "tells",
        "than", "that", "their", "them", "then", "there", "these", "they", "this", "those", "through", "time",
        "told", "under", "until", "very", "want", "wants", "were", "what", "when", "where", "which", "while",
        "will", "with", "without", "would", "years", "your", "author", "bestselling", "bestseller", "times",
        "best", "edition", "classic", "find", "finds", "away", "back", "becomes", "become", "became", "way",
        "once", "life", "lives", "world", "new", "three", "four", "five", "long", "tale", "reader", "readers",
        "award", "winning", "winner", "acclaimed", "masterpiece", "brilliant", "powerful", "beautiful"));

    private static final java.util.regex.Pattern NOT_LETTERS = java.util.regex.Pattern.compile("[^\\p{L}]+");

    /** Scores descriptions against the taste in a set of descriptions of books you liked. */
    public static final class Scorer {
        private final Map<String, String> surface = new HashMap<String, String>(); // stem -> a word that has it
        private final Map<String, Double> idf = new HashMap<String, Double>();
        private final Map<String, Double> centroid = new HashMap<String, Double>();
        private double centroidNorm = 0.0;

        /**
         * [likedDocs] are descriptions of books you liked, each with its weight in [likedWeights]; [otherDocs] are
         * the descriptions that will be scored. All of them are used to tell common words from telling ones.
         */
        public Scorer(List<String> likedDocs, List<Double> likedWeights, List<String> otherDocs) {
            List<Map<String, Double>> liked = new ArrayList<Map<String, Double>>();
            for (String d : likedDocs) liked.add(termFrequency(d));
            List<Map<String, Double>> others = new ArrayList<Map<String, Double>>();
            for (String d : otherDocs) others.add(termFrequency(d));

            Map<String, Integer> df = new HashMap<String, Integer>();
            for (Map<String, Double> m : liked) count(df, m);
            for (Map<String, Double> m : others) count(df, m);
            int n = liked.size() + others.size();
            for (Map.Entry<String, Integer> e : df.entrySet()) {
                idf.put(e.getKey(), Math.log((n + 1.0) / (e.getValue() + 1.0)) + 1.0);
            }

            for (int i = 0; i < liked.size(); i++) {
                double w = i < likedWeights.size() ? likedWeights.get(i) : 1.0;
                for (Map.Entry<String, Double> e : liked.get(i).entrySet()) {
                    double add = w * e.getValue() * idf.get(e.getKey());
                    Double cur = centroid.get(e.getKey());
                    centroid.put(e.getKey(), cur == null ? add : cur + add);
                }
            }
            double sum = 0.0;
            for (Double v : centroid.values()) sum += v * v;
            centroidNorm = Math.sqrt(sum);
        }

        /** False when the liked descriptions had no usable words, so every score would be zero. */
        public boolean usable() {
            return centroidNorm > 0.0;
        }

        /** How close [doc] is to what you like, 0 to 1 (typically 0.02 to 0.3). */
        public double similarity(String doc) {
            if (centroidNorm <= 0.0) return 0.0;
            Map<String, Double> v = vector(doc);
            double dot = 0.0;
            double norm = 0.0;
            for (Map.Entry<String, Double> e : v.entrySet()) {
                norm += e.getValue() * e.getValue();
                Double c = centroid.get(e.getKey());
                if (c != null) dot += c * e.getValue();
            }
            if (norm <= 0.0) return 0.0;
            return dot / (centroidNorm * Math.sqrt(norm));
        }

        /** Up to [max] telling words that [doc] and the books you like have in common, strongest first. */
        public List<String> shared(String doc, int max) {
            Map<String, Double> v = vector(doc);
            final Map<String, Double> contribution = new HashMap<String, Double>();
            for (Map.Entry<String, Double> e : v.entrySet()) {
                Double c = centroid.get(e.getKey());
                Double i = idf.get(e.getKey());
                if (c == null || i == null || i < 1.3) continue; // skip words nearly every description has
                contribution.put(e.getKey(), c * e.getValue());
            }
            List<String> stems = new ArrayList<String>(contribution.keySet());
            Collections.sort(stems, new Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return Double.compare(contribution.get(b), contribution.get(a));
                }
            });
            List<String> out = new ArrayList<String>();
            for (int i = 0; i < stems.size() && out.size() < max; i++) {
                String word = surface.get(stems.get(i));
                if (word != null) out.add(word);
            }
            return out;
        }

        private Map<String, Double> vector(String doc) {
            Map<String, Double> tf = termFrequency(doc);
            Map<String, Double> v = new HashMap<String, Double>();
            for (Map.Entry<String, Double> e : tf.entrySet()) {
                Double i = idf.get(e.getKey());
                if (i != null) v.put(e.getKey(), e.getValue() * i);
            }
            return v;
        }

        private Map<String, Double> termFrequency(String doc) {
            Map<String, Integer> counts = new HashMap<String, Integer>();
            if (doc != null) {
                for (String raw : NOT_LETTERS.split(doc.toLowerCase(Locale.ROOT))) {
                    if (raw.length() < 4 || STOP.contains(raw)) continue;
                    String stem = stem(raw);
                    if (stem.length() < 3) continue;
                    if (!surface.containsKey(stem)) surface.put(stem, raw);
                    Integer c = counts.get(stem);
                    counts.put(stem, c == null ? 1 : c + 1);
                }
            }
            Map<String, Double> tf = new HashMap<String, Double>();
            for (Map.Entry<String, Integer> e : counts.entrySet()) tf.put(e.getKey(), 1.0 + Math.log(e.getValue()));
            return tf;
        }

        private static void count(Map<String, Integer> df, Map<String, Double> doc) {
            for (String t : doc.keySet()) {
                Integer c = df.get(t);
                df.put(t, c == null ? 1 : c + 1);
            }
        }
    }

    /** A light stem, so "farms" and "farm" count as one word. */
    static String stem(String w) {
        if (w.length() > 5 && w.endsWith("ies")) return w.substring(0, w.length() - 3) + "y";
        if (w.length() > 6 && w.endsWith("ing")) return w.substring(0, w.length() - 3);
        if (w.length() > 5 && w.endsWith("ed")) return w.substring(0, w.length() - 2);
        if (w.length() > 4 && w.endsWith("s") && !w.endsWith("ss")) return w.substring(0, w.length() - 1);
        return w;
    }
}
