package com.paperback.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/*
 * The monthly recap ("wrapped"): everything about one month of reading, as plain functions over the data the app
 * already has (books, reading sessions, highlights, bookmarks, goals). No Android, no clock: `nowMs` is passed in.
 *
 * A recap is computed from the data each time it is opened, so it always matches the History and Stats pages. What
 * "generated" means is only that you opened it once (see AppPrefs.recapGenerated), which is what stops the reminder.
 *
 * As on the other Stats pages, "pages" are the pages turned in the reading sessions, and a day counts as a reading
 * day from one minute of reading.
 */

private const val READING_DAY_SECONDS = 60L

/** "2026-09", the way a month is saved and put in a route. */
fun recapKey(m: YearMonth): String = m.toString()

fun recapMonthOf(key: String): YearMonth? = runCatching { YearMonth.parse(key) }.getOrNull()

/** "September 2026" */
fun recapTitle(m: YearMonth): String = "${StatNames.MONTHS[m.monthValue - 1]} ${m.year}"

fun recapMonthName(m: YearMonth): String = StatNames.MONTHS[m.monthValue - 1]

private fun msOf(d: LocalDate, zone: ZoneId): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()

/** When you started a book: the date saved on it, else your first reading session. 0 when not known. */
private fun startedMs(b: Book, firstEver: Map<String, Long>): Long = if (b.startedAt > 0L) b.startedAt else (firstEver[b.id] ?: 0L)

// ---- the pieces of a recap ------------------------------------------------------------------

class RecapBook(
    val book: Book,
    /** Time, pages and sessions on this book in the month; all 0 for a book that was only marked finished. */
    val seconds: Long,
    val pages: Int,
    val sessions: Int,
    val days: Int,
    val firstDay: LocalDate?,
    /** The first time you read it was this month. */
    val started: Boolean,
    /** It was finished this month. */
    val finished: Boolean,
    /** Share of the month's reading time, 0..100. */
    val sharePct: Int,
)

class RecapDay(
    val date: LocalDate,
    val seconds: Long,
    val pages: Int,
    /** The book read longest that day (or the one finished that day). */
    val main: Book?,
    val bookCount: Int,
    /** How many books were started and finished that day. */
    val started: Int,
    val finished: Int,
) {
    val read: Boolean get() = seconds >= READING_DAY_SECONDS
}

class RecapQuote(val highlight: Highlight, val book: Book?, /** Roughly which page, 0 when not known. */ val page: Int)

/** A personal record broken this month. */
class RecapRecord(val label: String, val value: String, val sub: String, val target: MilestoneTarget?)

/** One of the "book highlights" rows. [tone] picks the accent: 0 blue, 1 yellow, 2 mint, 3 pink. */
class RecapFact(
    val icon: MilestoneIcon,
    val label: String,
    val title: String,
    val sub: String,
    val tone: Int,
    val target: MilestoneTarget?,
)

/** A number this month against the same stretch of last month. */
class RecapStat(val label: String, val cur: Long, val prev: Long, val isTime: Boolean) {
    val pct: Int? get() = pctDelta(cur, prev)
}

class RecapHabits(
    /** Seconds read in each hour of the day, 24 values. */
    val hours: List<Long>,
    /** Seconds in Night (10 pm to 5 am), Morning (5 to 12), Afternoon (12 to 5 pm), Evening (5 to 10 pm). */
    val parts: List<Long>,
    val favoritePart: Int?,
    /** Seconds per weekday, Monday first. */
    val weekdays: List<Long>,
    val favoriteWeekday: Int?,
    /** Share of the time read on Saturday and Sunday, 0..100. */
    val weekendPct: Int,
    /** Number of sessions: under 10 minutes, 10 to 30, 30 to 60, over an hour. */
    val lengths: List<Int>,
)

class RecapPersona(val title: String, val blurb: String)

class RecapName(val name: String, val seconds: Long)

val RECAP_PARTS = listOf("Night", "Morning", "Afternoon", "Evening")
val RECAP_PART_HOURS = listOf("10 pm to 5 am", "5 am to 12 pm", "12 to 5 pm", "5 to 10 pm")
val RECAP_LENGTHS = listOf("Under 10 min", "10 to 30 min", "30 to 60 min", "Over an hour")

fun recapPartOf(hour: Int): Int = when (hour) {
    in 5..11 -> 1
    in 12..16 -> 2
    in 17..21 -> 3
    else -> 0
}

class Recap(
    val month: YearMonth,
    /** The month is not over yet. */
    val inProgress: Boolean,
    val daysInMonth: Int,
    /** Days of the month that have passed (all of them for a finished month). */
    val daysElapsed: Int,

    val seconds: Long,
    val pages: Int,
    val sessions: Int,
    val readingDays: Int,
    val avgSessionSeconds: Long,
    /** Seconds on a day you read. */
    val avgDaySeconds: Long,
    val pagesPerHour: Int,
    val longestSession: Session?,
    /** Time split by how it was spent: reading, listening (read aloud) and hand-made entries. */
    val readSeconds: Long,
    val listenSeconds: Long,
    val loggedSeconds: Long,
    /** The book you listened to most, and for how long. */
    val topListenedId: String?,
    val topListenedSeconds: Long,
    /** Words read, estimated from each book's word count and the share of it you turned. 0 when unknown. */
    val wordsRead: Long,

    /** Every book read, started or finished in the month, most time first. */
    val books: List<RecapBook>,
    val startedCount: Int,
    val finishedCount: Int,
    val addedBooks: List<Book>,
    /** Books you paused or dropped this month. */
    val putDown: List<Book>,
    val days: List<RecapDay>,

    val quoteCount: Int,
    val noteCount: Int,
    val bookmarkCount: Int,
    val quotes: List<RecapQuote>,

    val bestDay: DayTotal?,
    val mostPagesDay: DayPages?,
    val bestStreak: Int,
    val bestStreakStart: LocalDate?,
    /** The streak you were on at the end of the month (or today). */
    val streakAtEnd: Int,

    val habits: RecapHabits,
    val goalMinutes: Int,
    val goalPages: Int,
    /** Days the daily time goal / page goal was met. */
    val goalDays: Int,
    val goalPageDays: Int,
    val yearFinished: Int,
    val yearGoal: Int,
    val yearExpected: Int,

    val prevName: String,
    val compare: List<RecapStat>,
    val records: List<RecapRecord>,
    val events: List<TimelineEvent>,
    val facts: List<RecapFact>,

    val authors: List<RecapName>,
    val genres: List<RecapName>,
    val languages: List<RecapName>,

    /** Books per star (1 to 5) among the books read this month. */
    val ratingCounts: List<Int>,
    val ratingAvg: Double?,

    val persona: RecapPersona,
    /** The pages you read as a number of average books, null when it is under half a book. */
    val equivBooks: Double?,
) {
    val isEmpty: Boolean get() = seconds <= 0L && books.isEmpty() && quoteCount == 0
    val ratedCount: Int get() = ratingCounts.sum()
}

// ---- building a recap -----------------------------------------------------------------------

/** Seconds of a session spread over the hours it covers (a session from 9:40 to 10:20 counts in two hours). */
private fun spreadHours(startMs: Long, seconds: Long, zone: ZoneId, out: LongArray) {
    var t = startMs
    var left = seconds * 1000L
    var guard = 0
    while (left > 0 && guard < 72) {
        val z = Instant.ofEpochMilli(t).atZone(zone)
        val nextHour = z.truncatedTo(ChronoUnit.HOURS).plusHours(1).toInstant().toEpochMilli()
        val chunk = min(left, max(1L, nextHour - t))
        out[z.hour] += chunk
        t += chunk
        left -= chunk
        guard++
    }
}

private fun quoteScore(h: Highlight): Int {
    val len = h.text.length
    val fit = if (len in 30..260) 100 - abs(len - 130) / 2 else 0
    return fit + if (h.note.isNotBlank()) 40 else 0
}

private fun personaOf(
    seconds: Long, readingDays: Int, elapsed: Int, avgSession: Long, finished: Int, weekendPct: Int, favoritePart: Int?, listenPct: Int,
): RecapPersona = when {
    seconds <= 0L -> RecapPersona("Quiet month", "Not much reading this month. A fresh start is one page away.")
    elapsed >= 7 && readingDays >= elapsed * 0.85 ->
        RecapPersona("Daily Reader", "You read on $readingDays of $elapsed days. That is a real habit.")
    avgSession >= 2400L ->
        RecapPersona("Marathoner", "Your average session ran ${Stats.duration(avgSession)}. You like to sink in.")
    finished >= 4 ->
        RecapPersona("Page Turner", "$finished books finished in one month. Hard to put them down.")
    weekendPct >= 55 && readingDays >= 4 ->
        RecapPersona("Weekend Reader", "$weekendPct% of your reading happened on a Saturday or Sunday.")
    listenPct >= 40 -> RecapPersona("Listener", "$listenPct% of your time was spent listening. The book came to you.")
    favoritePart == 0 -> RecapPersona("Night Owl", "Most of your reading happened late, between 10 pm and 5 am.")
    favoritePart == 1 -> RecapPersona("Early Bird", "Most of your reading happened in the morning.")
    favoritePart == 2 -> RecapPersona("Afternoon Reader", "Most of your reading happened in the afternoon.")
    favoritePart == 3 -> RecapPersona("Evening Reader", "Most of your reading happened in the evening.")
    else -> RecapPersona("Steady Reader", "A calm, steady month of reading.")
}

fun buildRecap(
    month: YearMonth,
    books: List<Book>,
    sessions: List<ReadingSession>,
    highlights: List<Highlight>,
    bookmarks: List<Bookmark>,
    goals: Goals,
    zone: ZoneId,
    nowMs: Long,
): Recap {
    val first = month.atDay(1)
    val after = month.plusMonths(1).atDay(1)
    val msFrom = msOf(first, zone)
    val msTo = msOf(after, zone)
    val today = dateOf(nowMs, zone)
    val inProgress = !today.isBefore(first) && today.isBefore(after)
    val daysInMonth = month.lengthOfMonth()
    val elapsed = when {
        inProgress -> today.dayOfMonth
        today.isBefore(first) -> 0
        else -> daysInMonth
    }
    val lastDay = first.plusDays(max(0, elapsed - 1).toLong())

    val byId = books.associateBy { it.id }
    val rows = sessions.filter { it.startMs >= msFrom && it.startMs < msTo }.sortedBy { it.startMs }
    val merged = buildSessions(rows)
    val summary = computeSummary(rows, merged)

    // When each book was first read, over all time.
    val firstEver = HashMap<String, Long>()
    for (s in sessions) {
        val cur = firstEver[s.bookId]
        if (cur == null || s.startMs < cur) firstEver[s.bookId] = s.startMs
    }
    fun startedHere(b: Book): Boolean {
        val ms = startedMs(b, firstEver)
        return ms >= msFrom && ms < msTo
    }
    fun finishedHere(b: Book): Boolean = b.finished && YearMonth.from(finishedDate(b, zone)) == month

    // ---- books ----
    val monthTotal = max(1L, summary.seconds)
    val recapBooks = ArrayList<RecapBook>()
    for ((id, list) in rows.groupBy { it.bookId }) {
        val b = byId[id] ?: continue
        val sec = list.sumOf { it.seconds.toLong() }
        val dayset = list.map { dateOf(it.startMs, zone) }.toSet()
        recapBooks.add(
            RecapBook(
                book = b,
                seconds = sec,
                pages = list.sumOf { it.pages },
                sessions = buildSessions(list).size,
                days = dayset.size,
                firstDay = dayset.minOrNull(),
                started = startedHere(b),
                finished = finishedHere(b),
                sharePct = ((sec * 100.0) / monthTotal).roundToInt(),
            ),
        )
    }
    val seen = recapBooks.map { it.book.id }.toSet()
    for (b in books) {
        if (b.id !in seen && finishedHere(b)) {
            recapBooks.add(RecapBook(b, 0L, 0, 0, 0, finishedDate(b, zone), false, true, 0))
        }
    }
    // A book started this month that has no session in it (a start date you set, or an import).
    val listed = recapBooks.map { it.book.id }.toSet()
    for (b in books) {
        if (b.id !in listed && startedHere(b)) {
            recapBooks.add(RecapBook(b, 0L, 0, 0, 0, dateOf(startedMs(b, firstEver), zone), true, finishedHere(b), 0))
        }
    }
    recapBooks.sortWith(compareByDescending<RecapBook> { it.seconds }.thenBy { it.book.title.lowercase() })
    val startedCount = recapBooks.count { it.started }
    val finishedBooks = recapBooks.filter { it.finished }
    val addedBooks = books
        .filter { it.addedAt >= msFrom && it.addedAt < msTo }
        .sortedBy { it.addedAt }

    // ---- days ----
    val startedOn = HashMap<LocalDate, Int>()
    val finishedOn = HashMap<LocalDate, Int>()
    val finishedOnBook = HashMap<LocalDate, Book>()
    for (rb in recapBooks) {
        if (rb.started) {
            val ms = startedMs(rb.book, firstEver)
            if (ms > 0L) {
                val d = dateOf(ms, zone)
                startedOn[d] = (startedOn[d] ?: 0) + 1
            }
        }
        if (rb.finished) {
            val d = finishedDate(rb.book, zone)
            finishedOn[d] = (finishedOn[d] ?: 0) + 1
            if (!finishedOnBook.containsKey(d)) finishedOnBook[d] = rb.book
        }
    }
    val rowsByDay = rows.groupBy { dateOf(it.startMs, zone) }
    val days = (1..daysInMonth).map { n ->
        val date = month.atDay(n)
        val list = rowsByDay[date].orEmpty()
        val perBook = list.groupBy { it.bookId }.mapValues { (_, l) -> l.sumOf { it.seconds.toLong() } }
        val mainId = perBook.maxByOrNull { it.value }?.key
        RecapDay(
            date = date,
            seconds = list.sumOf { it.seconds.toLong() },
            pages = list.sumOf { it.pages },
            main = (if (mainId != null) byId[mainId] else null) ?: finishedOnBook[date],
            bookCount = perBook.size,
            started = startedOn[date] ?: 0,
            finished = finishedOn[date] ?: 0,
        )
    }
    val readingDays = days.count { it.read }

    var bestStreak = 0
    var bestStreakStart: LocalDate? = null
    var run = 0
    var runStart: LocalDate? = null
    for (d in days) {
        if (d.read) {
            if (run == 0) runStart = d.date
            run++
            if (run > bestStreak) {
                bestStreak = run
                bestStreakStart = runStart
            }
        } else {
            run = 0
        }
    }
    val byDayAll = Stats.secondsByDay(sessions, zone)
    val streakAtEnd = if (elapsed > 0) Stats.currentStreak(byDayAll, lastDay) else 0

    val bestDay: DayTotal? = days.filter { it.seconds > 0 }.maxByOrNull { it.seconds }?.let { DayTotal(it.date, it.seconds) }
    val mostPagesDay: DayPages? = days.filter { it.pages > 0 }.maxByOrNull { it.pages }?.let { DayPages(it.date, it.pages) }
    val longestSession = merged.maxByOrNull { it.seconds }

    // ---- read, listened, logged; put down; words ----
    val split = timeSplit(rows)
    val putDown = books.filter { it.status != BookStatus.NORMAL && it.statusAt >= msFrom && it.statusAt < msTo }
        .sortedBy { it.statusAt }
    var wordsRead = 0L
    for (rb in recapBooks) {
        val b = rb.book
        if (b.words > 0 && b.pageCount > 0 && rb.pages > 0) {
            wordsRead += (b.words.toDouble() * min(1.0, rb.pages.toDouble() / b.pageCount)).toLong()
        }
    }

    // ---- habits ----
    val hourMs = LongArray(24)
    for (r in rows) spreadHours(r.startMs, r.seconds.toLong(), zone, hourMs)
    val hours = hourMs.map { it / 1000L }
    val parts = LongArray(4)
    for (h in 0 until 24) parts[recapPartOf(h)] += hours[h]
    val partTotal = parts.sum()
    val favoritePart = if (partTotal > 0) parts.indices.maxByOrNull { parts[it] } else null
    val weekdays = LongArray(7)
    for (d in days) weekdays[d.date.dayOfWeek.value - 1] += d.seconds
    val weekTotal = weekdays.sum()
    val favoriteWeekday = if (weekTotal > 0) weekdays.indices.maxByOrNull { weekdays[it] } else null
    val weekendPct = if (weekTotal > 0) (((weekdays[5] + weekdays[6]) * 100.0) / weekTotal).roundToInt() else 0
    val lengths = IntArray(4)
    for (s in merged) {
        val i = when {
            s.seconds < 600L -> 0
            s.seconds < 1800L -> 1
            s.seconds < 3600L -> 2
            else -> 3
        }
        lengths[i]++
    }
    val habits = RecapHabits(hours, parts.toList(), favoritePart, weekdays.toList(), favoriteWeekday, weekendPct, lengths.toList())

    // ---- goals and the year ----
    val goalDays = days.count { it.seconds >= goals.minutesPerDay * 60L }
    val goalPageDays = days.count { it.pages >= goals.pagesPerDay }
    val yearFinished = books.count {
        it.finished && finishedDate(it, zone).let { d -> d.year == month.year && d.isBefore(after) }
    }
    val endDay = if (elapsed > 0) lastDay else first
    val yearExpected = floor(goals.booksPerYear * (endDay.dayOfYear.toDouble() / endDay.lengthOfYear())).toInt()

    // ---- against last month ----
    val prevFrom = first.minusMonths(1)
    val prevSpan = if (inProgress) min(elapsed, prevFrom.lengthOfMonth()) else prevFrom.lengthOfMonth()
    val prevTo = prevFrom.plusDays(prevSpan.toLong())
    val pFrom = msOf(prevFrom, zone)
    val pTo = msOf(prevTo, zone)
    val prevRows = sessions.filter { it.startMs >= pFrom && it.startMs < pTo }
    val prevSummary = computeSummary(prevRows, buildSessions(prevRows))
    val prevDays = Stats.secondsByDay(prevRows, zone).count { it.value >= READING_DAY_SECONDS }
    val prevFinished = books.count {
        it.finished && finishedDate(it, zone).let { d -> !d.isBefore(prevFrom) && d.isBefore(prevTo) }
    }
    val monthHighlights = highlights.filter { it.createdAt >= msFrom && it.createdAt < msTo }
    val prevQuotes = highlights.count { it.createdAt >= pFrom && it.createdAt < pTo }
    val compare = listOf(
        RecapStat("Time read", summary.seconds, prevSummary.seconds, true),
        RecapStat("Pages", summary.pages.toLong(), prevSummary.pages.toLong(), false),
        RecapStat("Sessions", merged.size.toLong(), prevSummary.sessions.toLong(), false),
        RecapStat("Reading days", readingDays.toLong(), prevDays.toLong(), false),
        RecapStat("Books finished", finishedBooks.size.toLong(), prevFinished.toLong(), false),
        RecapStat("Quotes saved", monthHighlights.size.toLong(), prevQuotes.toLong(), false),
    )

    // ---- quotes ----
    val quotes = monthHighlights
        .sortedByDescending { quoteScore(it) }
        .take(3)
        .map { h ->
            val b = byId[h.bookId]
            val page = if (b != null && b.pageCount > 0) (h.progress * b.pageCount).roundToInt().coerceIn(1, b.pageCount) else 0
            RecapQuote(h, b, page)
        }

    // ---- records broken this month ----
    val records = ArrayList<RecapRecord>()
    val before = sessions.filter { it.startMs < msFrom }
    if (before.isNotEmpty()) {
        val beforeByDay = Stats.secondsByDay(before, zone)
        val beforeDay = beforeByDay.values.maxOrNull() ?: 0L
        val beforeSession = buildSessions(before).maxOfOrNull { it.seconds } ?: 0L
        val beforePages = before.groupBy { dateOf(it.startMs, zone) }.values.maxOfOrNull { l -> l.sumOf { it.pages } } ?: 0
        val beforeStreak = Stats.longestStreak(beforeByDay)
        if (bestDay != null && bestDay.seconds > beforeDay) {
            records.add(
                RecapRecord(
                    "Best day", Stats.duration(bestDay.seconds), "${dayLabel(bestDay.date)} \u00B7 before ${Stats.duration(beforeDay)}",
                    MilestoneTarget.OpenHistory(bestDay.date),
                ),
            )
        }
        if (longestSession != null && longestSession.seconds > beforeSession) {
            val d = dateOf(longestSession.startMs, zone)
            records.add(
                RecapRecord(
                    "Longest session", Stats.duration(longestSession.seconds), "${dayLabel(d)} \u00B7 before ${Stats.duration(beforeSession)}",
                    MilestoneTarget.OpenHistory(d),
                ),
            )
        }
        if (mostPagesDay != null && mostPagesDay.pages > beforePages) {
            records.add(
                RecapRecord(
                    "Most pages in a day", commas(mostPagesDay.pages), "${dayLabel(mostPagesDay.date)} \u00B7 before ${commas(beforePages)}",
                    MilestoneTarget.OpenHistory(mostPagesDay.date),
                ),
            )
        }
        val streakUpToEnd = Stats.longestStreak(Stats.secondsByDay(sessions.filter { it.startMs < msTo }, zone))
        if (streakUpToEnd > beforeStreak && bestStreak > 0) {
            records.add(
                RecapRecord(
                    "Longest streak", "$streakUpToEnd days", "Before $beforeStreak days",
                    bestStreakStart?.let { MilestoneTarget.OpenHistory(it) },
                ),
            )
        }
    }

    // ---- milestones and firsts that happened this month ----
    val msInput = MilestoneInput(sessions, books, highlights, emptyList(), zone, nowMs)
    val events = buildTimeline(msInput, buildMilestones(msInput)).filter { it.at >= msFrom && it.at < msTo }

    // ---- who and what ----
    val authorSeconds = LinkedHashMap<String, Pair<String, Long>>()
    val genreSeconds = LinkedHashMap<String, Pair<String, Long>>()
    val languageSeconds = LinkedHashMap<String, Pair<String, Long>>()
    fun addTo(map: MutableMap<String, Pair<String, Long>>, name: String, sec: Long) {
        val key = name.lowercase()
        val cur = map[key]
        map[key] = if (cur == null) name to sec else cur.first to (cur.second + sec)
    }
    for (rb in recapBooks) {
        if (rb.seconds <= 0L) continue
        for (a in splitAuthors(rb.book.author)) addTo(authorSeconds, a, rb.seconds)
        for (g in rb.book.tags) addTo(genreSeconds, g, rb.seconds)
        val lang = languageName(rb.book.language)
        if (lang.isNotEmpty()) addTo(languageSeconds, lang, rb.seconds)
    }
    fun top(map: Map<String, Pair<String, Long>>, n: Int): List<RecapName> =
        map.values.map { RecapName(it.first, it.second) }.sortedByDescending { it.seconds }.take(n)
    val authors = top(authorSeconds, 6)
    val genres = top(genreSeconds, 8)
    val languages = top(languageSeconds, 4)

    // ---- ratings of the books read ----
    val ratingCounts = IntArray(5)
    for (rb in recapBooks) {
        val stars = ratingStars(rb.book)
        if (stars in 1..5) ratingCounts[stars - 1]++
    }
    val ratedTotal = ratingCounts.sum()
    val ratingAvg = if (ratedTotal > 0) ratingCounts.indices.sumOf { (it + 1) * ratingCounts[it] }.toDouble() / ratedTotal else null

    // ---- book highlights ----
    val facts = ArrayList<RecapFact>()
    val longestBook = recapBooks.filter { it.book.pageCount > 0 }.maxByOrNull { it.book.pageCount }
    if (longestBook != null) {
        facts.add(
            RecapFact(
                MilestoneIcon.Page, "Longest book", longestBook.book.title, "${commas(longestBook.book.pageCount)} pages", 0,
                MilestoneTarget.OpenBook(longestBook.book.id),
            ),
        )
    }
    val topBook = recapBooks.firstOrNull { it.seconds > 0 }
    if (topBook != null) {
        facts.add(
            RecapFact(
                MilestoneIcon.Book, "Book of the month", topBook.book.title,
                "${Stats.duration(topBook.seconds)} \u00B7 ${topBook.sharePct}% of your reading", 3,
                MilestoneTarget.OpenBook(topBook.book.id),
            ),
        )
    }
    if (readingDays > 0 && summary.pages > 0) {
        facts.add(
            RecapFact(
                MilestoneIcon.Page, "Average pages per day", "%.1f pages".format(summary.pages.toDouble() / readingDays), "Based on reading days", 1,
                MilestoneTarget.OpenHistory(first),
            ),
        )
    }
    if (bestStreak > 0) {
        facts.add(
            RecapFact(
                MilestoneIcon.Flame, "Best reading streak", if (bestStreak == 1) "1 day" else "$bestStreak days", "Consecutive reading days", 2,
                bestStreakStart?.let { MilestoneTarget.OpenHistory(it) },
            ),
        )
    }
    if (authors.isNotEmpty()) {
        val a = authors[0]
        facts.add(RecapFact(MilestoneIcon.Mark, "Most read author", a.name, Stats.duration(a.seconds), 0, null))
    }
    // the quickest finish: from the first page to the last, in days
    var quickest: Pair<RecapBook, Long>? = null
    for (rb in finishedBooks) {
        val ms = startedMs(rb.book, firstEver)
        if (ms <= 0L) continue
        val span = ChronoUnit.DAYS.between(dateOf(ms, zone), finishedDate(rb.book, zone)) + 1
        val q = quickest
        if (span >= 1 && (q == null || span < q.second)) quickest = rb to span
    }
    val qk = quickest
    if (qk != null) {
        facts.add(
            RecapFact(
                MilestoneIcon.Done, "Quickest finish", qk.first.book.title,
                if (qk.second == 1L) "Finished in a day" else "Finished in ${qk.second} days", 2,
                MilestoneTarget.OpenBook(qk.first.book.id),
            ),
        )
    }
    if (bestDay != null) {
        facts.add(
            RecapFact(
                MilestoneIcon.Timer, "Biggest reading day", Stats.duration(bestDay.seconds), dayLabel(bestDay.date), 1,
                MilestoneTarget.OpenHistory(bestDay.date),
            ),
        )
    }

    val avgPages = books.filter { it.pageCount > 0 }.map { it.pageCount }.average()
    val equiv = if (summary.pages > 0 && !avgPages.isNaN() && avgPages > 0) summary.pages / avgPages else null

    return Recap(
        month = month,
        inProgress = inProgress,
        daysInMonth = daysInMonth,
        daysElapsed = elapsed,
        seconds = summary.seconds,
        pages = summary.pages,
        sessions = merged.size,
        readingDays = readingDays,
        avgSessionSeconds = summary.avgSessionSeconds,
        avgDaySeconds = if (readingDays > 0) summary.seconds / readingDays else 0L,
        pagesPerHour = summary.pagesPerHour,
        longestSession = longestSession,
        readSeconds = split.readSeconds,
        listenSeconds = split.listenSeconds,
        loggedSeconds = split.loggedSeconds,
        topListenedId = split.topListened?.first,
        topListenedSeconds = split.topListened?.second ?: 0L,
        wordsRead = wordsRead,
        books = recapBooks,
        startedCount = startedCount,
        finishedCount = finishedBooks.size,
        addedBooks = addedBooks,
        putDown = putDown,
        days = days,
        quoteCount = monthHighlights.size,
        noteCount = monthHighlights.count { it.note.isNotBlank() },
        bookmarkCount = bookmarks.count { it.createdAt >= msFrom && it.createdAt < msTo },
        quotes = quotes,
        bestDay = bestDay,
        mostPagesDay = mostPagesDay,
        bestStreak = bestStreak,
        bestStreakStart = bestStreakStart,
        streakAtEnd = streakAtEnd,
        habits = habits,
        goalMinutes = goals.minutesPerDay,
        goalPages = goals.pagesPerDay,
        goalDays = goalDays,
        goalPageDays = goalPageDays,
        yearFinished = yearFinished,
        yearGoal = goals.booksPerYear,
        yearExpected = yearExpected,
        prevName = recapMonthName(YearMonth.from(prevFrom)),
        compare = compare,
        records = records,
        events = events,
        facts = facts,
        authors = authors,
        genres = genres,
        languages = languages,
        ratingCounts = ratingCounts.toList(),
        ratingAvg = ratingAvg,
        persona = personaOf(
            summary.seconds, readingDays, elapsed, summary.avgSessionSeconds, finishedBooks.size, weekendPct, favoritePart,
            if (split.total > 0) ((split.listenSeconds * 100.0) / split.total).roundToInt() else 0,
        ),
        equivBooks = if (equiv != null && equiv >= 0.5) equiv else null,
    )
}

/** "28 Oct" */
fun dayLabel(d: LocalDate): String = "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"

// ---- the list of months ---------------------------------------------------------------------

class RecapRow(
    val month: YearMonth,
    val started: Int,
    val finished: Int,
    val pages: Int,
    val days: Int,
    val seconds: Long,
    /** This month, still going. */
    val current: Boolean,
)

/** Every month with reading (or a finished book) up to this one, newest first. */
fun recapRows(books: List<Book>, sessions: List<ReadingSession>, zone: ZoneId, nowMs: Long): List<RecapRow> {
    val nowMonth = YearMonth.from(dateOf(nowMs, zone))
    val byMonth = sessions.groupBy { YearMonth.from(dateOf(it.startMs, zone)) }

    val firstEver = HashMap<String, Long>()
    for (s in sessions) {
        val cur = firstEver[s.bookId]
        if (cur == null || s.startMs < cur) firstEver[s.bookId] = s.startMs
    }
    val startedBy = HashMap<YearMonth, Int>()
    for (b in books) {
        val ms = startedMs(b, firstEver)
        if (ms <= 0L) continue
        val m = YearMonth.from(dateOf(ms, zone))
        startedBy[m] = (startedBy[m] ?: 0) + 1
    }
    val finishedBy = HashMap<YearMonth, Int>()
    for (b in books) {
        if (!b.finished) continue
        val m = YearMonth.from(finishedDate(b, zone))
        finishedBy[m] = (finishedBy[m] ?: 0) + 1
    }

    val out = ArrayList<RecapRow>()
    for (m in (byMonth.keys + finishedBy.keys).toSet()) {
        if (m.isAfter(nowMonth)) continue
        val list = byMonth[m].orEmpty()
        val seconds = list.sumOf { it.seconds.toLong() }
        val finished = finishedBy[m] ?: 0
        if (seconds <= 0L && finished == 0) continue
        val perDay = list.groupBy { dateOf(it.startMs, zone) }.mapValues { (_, l) -> l.sumOf { it.seconds.toLong() } }
        out.add(
            RecapRow(
                month = m,
                started = startedBy[m] ?: 0,
                finished = finished,
                pages = list.sumOf { it.pages },
                days = perDay.count { it.value >= READING_DAY_SECONDS },
                seconds = seconds,
                current = m == nowMonth,
            ),
        )
    }
    return out.sortedByDescending { it.month }
}

/** The month a recap is waiting for: last month, when it has reading and its recap was not opened yet. */
fun pendingRecap(rows: List<RecapRow>, generated: Set<String>, nowMs: Long, zone: ZoneId): RecapRow? {
    val prev = YearMonth.from(dateOf(nowMs, zone)).minusMonths(1)
    return rows.firstOrNull { it.month == prev && it.days > 0 && recapKey(it.month) !in generated }
}

// ---- sharing --------------------------------------------------------------------------------

/** The recap as text for a share sheet. */
fun recapShareText(r: Recap): String {
    val sb = StringBuilder()
    sb.append("My ").append(recapTitle(r.month)).append(" in books").append("\n\n")
    sb.append(Stats.duration(r.seconds)).append(" of reading over ")
        .append(r.readingDays).append(if (r.readingDays == 1) " day" else " days")
        .append(", ").append(commas(r.pages)).append(" pages, ")
        .append(r.sessions).append(if (r.sessions == 1) " session" else " sessions").append("\n")
    sb.append(r.finishedCount).append(if (r.finishedCount == 1) " book finished" else " books finished")
        .append(", ").append(r.startedCount).append(" started").append("\n")
    if (r.bestStreak > 1) sb.append("Best streak: ").append(r.bestStreak).append(" days\n")
    if (r.quoteCount > 0) sb.append(r.quoteCount).append(if (r.quoteCount == 1) " quote saved\n" else " quotes saved\n")
    sb.append("Reader type: ").append(r.persona.title).append("\n")
    val top = r.books.filter { it.seconds > 0 }.take(3)
    if (top.isNotEmpty()) {
        sb.append("\nMost read\n")
        top.forEachIndexed { i, b ->
            sb.append(i + 1).append(". ").append(b.book.title).append(" - ").append(Stats.duration(b.seconds)).append("\n")
        }
    }
    sb.append("\nPaperback")
    return sb.toString()
}
