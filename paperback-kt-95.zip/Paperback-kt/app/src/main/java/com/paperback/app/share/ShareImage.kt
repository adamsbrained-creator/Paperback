package com.paperback.app.share

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import com.paperback.app.data.ShareCard

/**
 * Draws a [ShareCard] as a picture: black page, white text, coral kicker, the numbers in outlined tiles. Drawn with the
 * plain Android canvas (no screen needed), 1080 pixels wide and at least 1350 tall.
 */
object ShareImage {
    private const val WIDTH = 1080
    private const val MARGIN = 72
    private const val MIN_HEIGHT = 1350
    private const val TILE_H = 232
    private const val GAP = 24

    private val INK = Color.WHITE
    private val SUB = 0xFF9A9A9A.toInt()
    private val CORAL = 0xFFF46B4E.toInt()
    private val LINE = 0x38FFFFFF

    private fun text(size: Float, color: Int, face: Typeface): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color; typeface = face }

    private fun layout(text: String, p: TextPaint, maxLines: Int, width: Int, spacing: Float = 1.12f): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setLineSpacing(0f, spacing)
            .build()

    fun render(card: ShareCard, dateText: String): Bitmap {
        val inner = WIDTH - 2 * MARGIN
        val sans = Typeface.SANS_SERIF
        val bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        val serif = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        val serifItalic = Typeface.create(Typeface.SERIF, Typeface.ITALIC)

        val kickerPaint = text(34f, CORAL, bold).apply { letterSpacing = 0.14f }
        val titleLayout = layout(card.title.ifBlank { "Paperback" }, text(80f, INK, serif), 3, inner, 1.06f)
        val subLayout = if (card.subtitle.isBlank()) null else layout(card.subtitle, text(40f, SUB, sans), 2, inner)
        val quoteLayout = if (card.quote.isBlank()) null else layout("“${card.quote.trim()}”", text(44f, INK, serifItalic), 7, inner, 1.18f)
        val noteLayout = if (card.note.isBlank()) null else layout(card.note, text(34f, SUB, sans), 2, inner)
        val tileW = (inner - GAP) / 2
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = LINE }
        val footerPaint = text(34f, CORAL, bold)
        val datePaint = text(32f, SUB, sans)

        // one pass that only measures (canvas = null) and one that draws, so the picture is exactly as tall as it needs to be
        fun paint(canvas: Canvas?): Int {
            var y = MARGIN
            y += 34
            canvas?.drawText(card.kicker.uppercase(), MARGIN.toFloat(), y.toFloat(), kickerPaint)
            y += 38
            canvas?.save(); canvas?.translate(MARGIN.toFloat(), y.toFloat()); canvas?.let { titleLayout.draw(it) }; canvas?.restore()
            y += titleLayout.height
            if (subLayout != null) {
                y += 14
                canvas?.save(); canvas?.translate(MARGIN.toFloat(), y.toFloat()); canvas?.let { subLayout.draw(it) }; canvas?.restore()
                y += subLayout.height
            }
            y += 56
            card.stats.take(6).chunked(2).forEach { pair ->
                pair.forEachIndexed { i, s ->
                    val x = MARGIN + i * (tileW + GAP)
                    if (canvas != null) {
                        canvas.drawRoundRect(RectF(x.toFloat(), y.toFloat(), (x + tileW).toFloat(), (y + TILE_H).toFloat()), 40f, 40f, line)
                        val value = text(84f, INK, bold)
                        while (value.measureText(s.value) > tileW - 56 && value.textSize > 40f) value.textSize -= 4f
                        canvas.drawText(s.value, (x + 28).toFloat(), (y + 112).toFloat(), value)
                        canvas.drawText(s.label, (x + 28).toFloat(), (y + 172).toFloat(), text(34f, SUB, sans))
                    }
                }
                y += TILE_H + GAP
            }
            if (card.stats.isNotEmpty()) y += 24
            if (quoteLayout != null) {
                canvas?.save(); canvas?.translate(MARGIN.toFloat(), y.toFloat()); canvas?.let { quoteLayout.draw(it) }; canvas?.restore()
                y += quoteLayout.height + 32
            }
            if (noteLayout != null) {
                canvas?.save(); canvas?.translate(MARGIN.toFloat(), y.toFloat()); canvas?.let { noteLayout.draw(it) }; canvas?.restore()
                y += noteLayout.height + 32
            }
            return y
        }

        val content = paint(null)
        val height = maxOf(MIN_HEIGHT, content + 56 + 40 + MARGIN)
        val bitmap = Bitmap.createBitmap(WIDTH, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.BLACK)
        paint(canvas)
        val base = (height - MARGIN).toFloat()
        canvas.drawText("Paperback", MARGIN.toFloat(), base, footerPaint)
        canvas.drawText(dateText, WIDTH - MARGIN - datePaint.measureText(dateText), base, datePaint)
        return bitmap
    }
}
