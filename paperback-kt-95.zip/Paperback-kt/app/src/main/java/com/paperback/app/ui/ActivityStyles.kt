package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.ui.theme.pbTokens

/**
 * The two other looks for the Activity chart (App style -> Activity): a compact list with one thin bar per row,
 * and a big-number look without a chart (just the best bar and the average under the total).
 */
@Composable
fun ActivityBarList(
    names: List<String>,
    values: List<Float?>,
    selected: Int,
    format: (Float) -> String,
    onSelect: (Int) -> Unit,
) {
    val t = pbTokens()
    val max = (values.maxOfOrNull { it ?: 0f } ?: 0f).coerceAtLeast(1f)
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        // Newest first, bars that are still in the future left out.
        for (i in values.indices.reversed()) {
            val v = values[i] ?: continue
            val on = i == selected
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (on) t.ink.copy(alpha = 0.07f) else androidx.compose.ui.graphics.Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    names.getOrElse(i) { "" },
                    modifier = Modifier.width(72.dp),
                    color = if (on) t.ink else t.setSub,
                    fontSize = 13.sp,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                )
                GradientTrack(v / max, com.paperback.app.ui.DashAccent.Violet, Modifier.weight(1f), height = 6.dp)
                Text(
                    if (v > 0f) format(v) else "–",
                    modifier = Modifier.width(76.dp).padding(start = 8.dp),
                    color = t.ink,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = androidx.compose.ui.text.style.TextAlign.End,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
fun ActivityBigFacts(
    names: List<String>,
    values: List<Float?>,
    unitName: String,
    format: (Float) -> String,
) {
    val real = values.mapIndexedNotNull { i, v -> if (v != null && v > 0f) i to v else null }
    val best = real.maxByOrNull { it.second }
    val avg = if (real.isEmpty()) 0f else real.sumOf { it.second.toDouble() }.toFloat() / real.size
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        BigFactRow("Best $unitName", best?.let { names.getOrElse(it.first) { "" } + " · " + format(it.second) } ?: "–")
        BigFactRow("Average per $unitName you read", if (real.isEmpty()) "–" else format(avg))
        BigFactRow("${unitName.replaceFirstChar { it.uppercase() }}s with reading", "${real.size} of ${values.count { it != null }}")
    }
}

@Composable
private fun BigFactRow(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), color = t.setSub, fontSize = 14.sp)
        Text(value, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}
