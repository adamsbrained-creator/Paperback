package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/*
 * Finish forecasts with a range, as plain functions (no Android, no clock: `today` is passed in).
 *
 * "When you'll finish" used to give one number. Now it gives three: a quick day, a likely day and a slow day, from
 * how long you read on the days you do read (the best quarter, the middle and the slowest quarter of the last 60
 * days) and how often you read. It also answers the other two questions the page asks:
 *  - "I read N minutes a day: when do I finish?"  -> [daysAtMinutes]
 *  - "I want to finish by this day: how many minutes a day?"  -> [minutesPerDayToFinish]
 */

private const val MIN_PACE_SECONDS = 600L
private const val ACTIVE_DAY_SECONDS = 60L

/** How you read: minutes on a day you read (three levels), the share of days you read, and pages per hour. */
class ForecastPattern(
    /** Seconds on a day you read: the slowest quarter, the middle and the best quarter of the last 60 days. */
    val slowSeconds: Double,
    val likelySeconds: Double,
    val fastSeconds: Double,
    /** 0..1: the share of the last 30 days you read (never below one day in thirty). */
    val share: Double,
    /** Pages per hour over the last 60 days, 0 when there is too little reading. */
    val pace: Int,
    val readingDays: Int,
)

class ForecastBook(
    val book: Book,
    val pagesLeft: Int,
    /** Reading time left at your pace, in seconds. */
    val secondsLeft: Long,
    /** Days from today to finish on a quick, a likely and a slow stretch; null when it cannot be told. */
    val fastDays: Int?,
    val likelyDays: Int?,
    val slowDays: Int?,
)

class Forecast(val pattern: ForecastPattern?, val books: List<ForecastBook>)

private fun quantile(sorted: List<Long>, q: Double): Double {
    if (sorted.isEmpty()) return 0.0
    val pos = q * (sorted.size - 1)
    val lo = floor(pos).toInt()
    val hi = ceil(pos).toInt()
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo)
}

private fun startMs(d: LocalDate, zone: ZoneId): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()

private fun paceOf(rows: List<ReadingSession>): Int {
    if (rows.isEmpty()) return 0
    val s = computeSummary(rows, buildSessions(rows))
    return if (s.seconds >= MIN_PACE_SECONDS) s.pagesPerHour else 0
}

/** How you read, from the last 60 days; null when you read on fewer than three of them. */
fun forecastPattern(rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): ForecastPattern? {
    val byDay = Stats.secondsByDay(rows, zone)
    val seconds = ArrayList<Long>()
    var active30 = 0
    for (i in 0 until 60) {
        val s = byDay[today.minusDays(i.toLong())] ?: 0L
        if (s >= ACTIVE_DAY_SECONDS) {
            seconds.add(s)
            if (i < 30) active30++
        }
    }
    if (seconds.size < 3) return null
    seconds.sort()
    val pace = paceOf(rows.filter { it.startMs >= startMs(today.minusDays(59), zone) })
    return ForecastPattern(
        slowSeconds = quantile(seconds, 0.25).coerceAtLeast(ACTIVE_DAY_SECONDS.toDouble()),
        likelySeconds = quantile(seconds, 0.50).coerceAtLeast(ACTIVE_DAY_SECONDS.toDouble()),
        fastSeconds = quantile(seconds, 0.75).coerceAtLeast(ACTIVE_DAY_SECONDS.toDouble()),
        share = max(active30, 1) / 30.0,
        pace = pace,
        readingDays = seconds.size,
    )
}

private fun calendarDays(secondsLeft: Long, perDay: Double, share: Double): Int =
    max(1, ceil(secondsLeft / perDay / share).toInt())

/** For the books in progress: how long is left, and a quick, likely and slow finish (shortest first). */
fun buildForecast(books: List<Book>, rows: List<ReadingSession>, today: LocalDate, zone: ZoneId, limit: Int = 6): Forecast {
    val pattern = forecastPattern(rows, today, zone)
    val byBook = rows.groupBy { it.bookId }
    val out = ArrayList<ForecastBook>()
    for (b in books) {
        if (!b.isReading || b.pageCount <= 0) continue
        val pagesLeft = b.pageCount - b.currentPage
        if (pagesLeft <= 0) continue
        // Prefer the pace on this very book once it has enough reading, else the overall one.
        val own = byBook[b.id].orEmpty()
        val ownPace = paceOf(own)
        val pace = if (ownPace > 0) ownPace else pattern?.pace ?: 0
        if (pace <= 0) continue
        val secondsLeft = Math.round(pagesLeft.toDouble() / pace * 3600)
        out.add(
            ForecastBook(
                book = b,
                pagesLeft = pagesLeft,
                secondsLeft = secondsLeft,
                fastDays = pattern?.let { calendarDays(secondsLeft, it.fastSeconds, it.share) },
                likelyDays = pattern?.let { calendarDays(secondsLeft, it.likelySeconds, it.share) },
                slowDays = pattern?.let { calendarDays(secondsLeft, it.slowSeconds, it.share) },
            ),
        )
    }
    return Forecast(pattern, out.sortedBy { it.secondsLeft }.take(limit))
}

/** Days to finish when you read [minutesPerDay] minutes every day. */
fun daysAtMinutes(secondsLeft: Long, minutesPerDay: Int): Int =
    max(1, ceil(secondsLeft / 60.0 / max(1, minutesPerDay)).toInt())

/** Minutes a day, every day, to finish in [days] days (today counts as the first). */
fun minutesPerDayToFinish(secondsLeft: Long, days: Int): Int =
    max(1, ceil(secondsLeft / 60.0 / max(1, days)).toInt())

/** The "finish by" choices: a week, two weeks, a month, the end of this month, the end of this year. */
enum class FinishBy(val label: String) {
    Week("1 week"),
    TwoWeeks("2 weeks"),
    Month("1 month"),
    MonthEnd("Month end"),
    YearEnd("Year end"),
    ;

    /** Days from today to that day, counting today (so at least 1). */
    fun days(today: LocalDate): Int = when (this) {
        Week -> 7
        TwoWeeks -> 14
        Month -> 30
        MonthEnd -> (ChronoUnit.DAYS.between(today, today.withDayOfMonth(today.lengthOfMonth())) + 1).toInt()
        YearEnd -> (ChronoUnit.DAYS.between(today, LocalDate.of(today.year, 12, 31)) + 1).toInt()
    }
}

/** "26 Nov", or "26 Nov 2027" when it is in another year. [days] counts today as 1, so 1 day is today. */
fun finishDateText(today: LocalDate, days: Int): String {
    val d = today.plusDays((days - 1).toLong())
    val base = "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"
    return if (d.year == today.year) base else "$base ${d.year}"
}

/** "5 min" / "1h 20m" for a minutes-a-day figure. */
fun minutesText(minutes: Int): String = if (minutes < 60) "$minutes min" else {
    val h = minutes / 60
    val m = minutes % 60
    if (m == 0) "${h}h" else "${h}h ${m}m"
}

// ---- the books goal ---------------------------------------------------------------------------

/** What the year's books goal asks of the rest of the year. */
class GoalNeed(
    val booksLeft: Int,
    val daysLeft: Int,
    /** A book every this many days (null when the goal is reached). */
    val everyDays: Int?,
    /** Books a month to get there (null when the goal is reached). */
    val perMonth: Double?,
)

fun goalNeed(finished: Int, goal: Int, today: LocalDate): GoalNeed {
    val left = (goal - finished).coerceAtLeast(0)
    val days = (ChronoUnit.DAYS.between(today, LocalDate.of(today.year, 12, 31)) + 1).toInt().coerceAtLeast(1)
    if (left == 0) return GoalNeed(0, days, null, null)
    return GoalNeed(left, days, max(1, days / left), left * 30.4 / days)
}
