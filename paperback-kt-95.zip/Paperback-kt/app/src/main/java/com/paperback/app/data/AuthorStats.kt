package com.paperback.app.data

import java.time.Instant
import java.time.ZoneId
import kotlin.math.roundToInt

/** One author in numbers: what you own and finished of theirs, the time you gave them, and how you rated them. */
class AuthorFigures(
    val books: Int,
    val finished: Int,
    val seconds: Long,
    val pages: Int,
    val avgStars: Double?,
    val rated: Int,
    /** Your first and last reading entry in any of their books, 0 = never read. */
    val firstMs: Long,
    val lastMs: Long,
    /** Share of all your reading time. */
    val sharePercent: Int,
    val readingDays: Int,
    val favorite: Book?,
    /** Words per minute across their books, 0 = not enough reading to say. */
    val wpm: Int,
)

/** Null when [name] has no books. */
fun authorFigures(name: String, books: List<Book>, sessions: List<ReadingSession>, zone: ZoneId): AuthorFigures? {
    val mine = books.filter { Authors.has(it, name) }
    if (mine.isEmpty()) return null
    val ids = mine.map { it.id }.toHashSet()
    val rows = sessions.filter { it.bookId in ids }
    val seconds = rows.sumOf { it.seconds.toLong() }
    val total = sessions.sumOf { it.seconds.toLong() }
    val rated = mine.filter { ratingStars(it) > 0 }
    val avg = if (rated.isEmpty()) null else rated.map { if (it.rating10 > 0f) it.rating10 / 2.0 else ratingStars(it).toDouble() }.average()
    val secsByBook = Stats.secondsByBook(rows)
    val favorite = mine.filter { ratingStars(it) > 0 }
        .maxWithOrNull(compareBy<Book>({ it.rating10 }, { secsByBook[it.id] ?: 0L }))
        ?: mine.maxByOrNull { secsByBook[it.id] ?: 0L }?.takeIf { (secsByBook[it.id] ?: 0L) > 0L }
    val days = rows.filter { it.seconds > 0 }.map { Instant.ofEpochMilli(it.startMs).atZone(zone).toLocalDate() }.toSet().size
    return AuthorFigures(
        books = mine.size,
        finished = mine.count { it.finished },
        seconds = seconds,
        pages = rows.sumOf { it.pages },
        avgStars = avg,
        rated = rated.size,
        firstMs = rows.minOfOrNull { it.startMs } ?: 0L,
        lastMs = rows.maxOfOrNull { it.startMs + it.seconds * 1000L } ?: 0L,
        sharePercent = if (total <= 0L) 0 else ((seconds * 100.0) / total).roundToInt(),
        readingDays = days,
        favorite = favorite,
        wpm = wpmOf(rows.filter { it.kind != SessionKind.LISTEN }, mine.associateBy { it.id }).first,
    )
}
