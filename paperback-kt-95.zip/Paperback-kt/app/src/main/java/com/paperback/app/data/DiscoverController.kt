package com.paperback.app.data

import com.paperback.app.data.opds.OpdsDoc
import com.paperback.app.data.opds.OpdsFeed
import com.paperback.app.data.opds.OpdsFormats
import com.paperback.app.data.opds.OpdsHttp
import com.paperback.app.data.opds.OpdsHttpException
import com.paperback.app.data.opds.OpdsLink
import com.paperback.app.data.opds.OpdsParser
import com.paperback.app.data.opds.OpdsPublication
import com.paperback.app.data.opds.OpdsUrl
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/** One screen of the catalog browser. Every page the person has visited is kept, so Back is instant. */
sealed interface BrowserPage {
    val uid: Int
    val url: String

    data class FeedPage(override val uid: Int, override val url: String, val feed: OpdsFeed) : BrowserPage

    data class DetailPage(
        override val uid: Int,
        override val url: String,
        val publication: OpdsPublication,
        /** The full record is being fetched (the feed only listed a summary). */
        val loadingMore: Boolean = false,
        val detailFailed: Boolean = false,
    ) : BrowserPage
}

data class BrowserState(
    val catalog: Catalog,
    val pages: List<BrowserPage> = emptyList(),
    val loading: Boolean = true,
    val error: String? = null,
    /** The address to try again when [error] is showing. */
    val failedUrl: String? = null,
    val searchTerm: String = "",
    /** The search link of the catalog's first page, used when the page being shown has none of its own. */
    val rootSearch: OpdsLink? = null,
) {
    val current: BrowserPage? get() = pages.lastOrNull()
    val searchLink: OpdsLink? get() = (current as? BrowserPage.FeedPage)?.feed?.searchLink ?: rootSearch
}

/** A download in progress. [progress] is null while the size is unknown; [adding] once it is being put in the library. */
data class DownloadState(val key: String, val progress: Float?, val adding: Boolean)

/**
 * Everything behind the Discover screens: the catalog list, the browsing history inside one catalog, search,
 * and downloading a book into the library. Lives in the view model, so a half-browsed catalog is still there
 * when you come back to Discover. The screens only draw [browser] and call these functions.
 */
class DiscoverController(
    private val scope: CoroutineScope,
    private val appScope: CoroutineScope,
    private val http: OpdsHttp,
    private val store: OpdsStore,
    private val repo: Repository,
    private val cacheDir: File,
    private val say: (String) -> Unit,
) {
    val catalogs: StateFlow<List<Catalog>> = store.catalogs

    private val _browser = MutableStateFlow<BrowserState?>(null)
    val browser: StateFlow<BrowserState?> = _browser.asStateFlow()

    private val _download = MutableStateFlow<DownloadState?>(null)
    val download: StateFlow<DownloadState?> = _download.asStateFlow()

    private var nextUid = 1
    private var loadJob: Job? = null

    /** Pages already fetched (address -> where it ended up, and what it was), so going back to one or opening it again is instant. */
    private class Cached(val at: Long, val finalUrl: String, val doc: OpdsDoc)

    private val cache = object : LinkedHashMap<String, Cached>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Cached>?): Boolean = size > 40
    }

    private fun cacheKey(catalog: Catalog, url: String) = "${catalog.id}|$url"

    /** Fetches and reads one catalog document. A normal web page may only point at its feed; that pointer is followed (at most twice). */
    private suspend fun fetchDoc(catalog: Catalog, url: String): Pair<String, OpdsDoc?> {
        val key = cacheKey(catalog, url)
        val hit = synchronized(cache) { cache[key] }
        if (hit != null && System.currentTimeMillis() - hit.at < CACHE_MS) return hit.finalUrl to hit.doc
        var doc: OpdsDoc? = null
        var finalUrl = url
        var target = url
        for (attempt in 0..2) {
            val res = withContext(Dispatchers.IO) { http.getText(target, catalog.auth) }
            finalUrl = res.url
            doc = OpdsParser.parse(res.text, res.url)
            val d = doc
            if (d is OpdsDoc.Redirect) target = d.href else break
        }
        val read = doc
        if (read != null && (read is OpdsDoc.Feed || read is OpdsDoc.Entry)) {
            synchronized(cache) { cache[key] = Cached(System.currentTimeMillis(), finalUrl, read) }
        }
        return finalUrl to doc
    }
    private val scrollPositions = HashMap<Int, Pair<Int, Int>>()

    // ---- catalog list -----------------------------------------------------------------------

    fun saveCatalog(id: String?, name: String, address: String, username: String, password: String): String? =
        store.upsert(id, name, address, username, password)

    fun removeCatalog(id: String) = store.remove(id)

    // ---- browsing ---------------------------------------------------------------------------

    fun openCatalog(catalog: Catalog) {
        loadJob?.cancel()
        _browser.value = BrowserState(catalog, loading = true)
        startLoad(catalog, catalog.url, isSearch = false)
    }

    fun closeBrowser() {
        loadJob?.cancel()
        _browser.value = null
    }

    fun navigate(url: String) {
        val b = _browser.value ?: return
        startLoad(b.catalog, url, isSearch = false)
    }

    fun retry() {
        val b = _browser.value ?: return
        val url = b.failedUrl ?: return
        synchronized(cache) { cache.remove(cacheKey(b.catalog, url)) }
        startLoad(b.catalog, url, isSearch = false)
    }

    /** Back one step. Returns false when no catalog is open (the caller then goes back itself). */
    fun back(): Boolean {
        val b = _browser.value ?: return false
        if (b.loading || b.error != null) {
            loadJob?.cancel()
            _browser.value = if (b.pages.isEmpty()) null else b.copy(loading = false, error = null, failedUrl = null)
            return true
        }
        _browser.value = if (b.pages.size <= 1) null else b.copy(pages = b.pages.dropLast(1))
        return true
    }

    /** The catalog's first page (the Home button). */
    fun goStart() {
        loadJob?.cancel()
        _browser.update { it?.copy(pages = it.pages.take(1), loading = false, error = null, failedUrl = null, searchTerm = "") }
    }

    fun saveScroll(uid: Int, index: Int, offset: Int) {
        scrollPositions[uid] = index to offset
    }

    fun scrollOf(uid: Int): Pair<Int, Int> = scrollPositions[uid] ?: (0 to 0)

    private fun startLoad(catalog: Catalog, url: String, isSearch: Boolean) {
        loadJob?.cancel()
        _browser.update { it?.copy(loading = true, error = null, failedUrl = null) }
        loadJob = scope.launch { loadPage(catalog, url, isSearch) }
    }

    private suspend fun loadPage(catalog: Catalog, url: String, isSearch: Boolean) {
        try {
            val (finalUrl, doc) = fetchDoc(catalog, url)
            val page: BrowserPage? = when (val d = doc) {
                // A book's own page can arrive as a "list" holding that one book (twice, on Project Gutenberg): show the book.
                is OpdsDoc.Feed -> if (isSingleBook(d.feed, finalUrl)) {
                    BrowserPage.DetailPage(nextUid++, finalUrl, d.feed.publications.first())
                } else {
                    BrowserPage.FeedPage(nextUid++, finalUrl, d.feed)
                }
                is OpdsDoc.Entry -> BrowserPage.DetailPage(nextUid++, finalUrl, d.publication)
                else -> null
            }
            if (page == null) {
                fail(catalog, url, "That address is not an OPDS catalog.")
                return
            }
            push(catalog, page)
        } catch (e: CancellationException) {
            throw e
        } catch (e: OpdsHttpException) {
            if (isSearch && e.status == 404) {
                push(catalog, BrowserPage.FeedPage(nextUid++, url, OpdsFeed("No results", null, emptyList(), emptyList(), emptyList(), emptyList(), emptyList())))
            } else {
                fail(catalog, url, explain(e))
            }
        } catch (e: Exception) {
            fail(catalog, url, explain(e))
        }
    }

    private fun isSingleBook(feed: OpdsFeed, url: String): Boolean {
        if (feed.navigation.isNotEmpty() || feed.groups.isNotEmpty() || feed.publications.isEmpty()) return false
        if (feed.publications.size > 3) return false
        val first = feed.publications.first()
        if (first.acquisitionLinks.isEmpty()) return false
        if (feed.publications.size == 1 && !OpdsParser.isGutenbergBookPage(url)) return false
        return feed.publications.all { it.title == first.title && it.authors == first.authors }
    }

    private fun push(catalog: Catalog, page: BrowserPage) {
        _browser.update { cur ->
            if (cur == null || cur.catalog.id != catalog.id) {
                cur
            } else {
                cur.copy(
                    pages = cur.pages + page,
                    loading = false,
                    error = null,
                    failedUrl = null,
                    rootSearch = cur.rootSearch ?: (page as? BrowserPage.FeedPage)?.feed?.searchLink,
                )
            }
        }
    }

    private fun fail(catalog: Catalog, url: String, message: String) {
        _browser.update { cur ->
            if (cur == null || cur.catalog.id != catalog.id) cur else cur.copy(loading = false, error = message, failedUrl = url)
        }
    }

    private fun explain(e: Exception): String = when {
        e is OpdsHttpException && e.status == 401 && e.message?.contains("not accepted") == true ->
            "The username or password was not accepted. Change it from the catalog's menu in Discover."
        e is OpdsHttpException && e.status == 401 ->
            "This catalog needs a username and password. Add them from the catalog's menu in Discover."
        e is OpdsHttpException -> e.message ?: "The catalog could not be loaded."
        e is IOException && !e.message.isNullOrBlank() && e.message!!.startsWith("Too many") -> "The catalog keeps redirecting. Check its address."
        e is IOException -> "Couldn't reach the catalog. Check your connection and the address."
        else -> "Something went wrong while loading the catalog."
    }

    // ---- search -----------------------------------------------------------------------------

    fun search(term: String) {
        val t = term.trim()
        if (t.isEmpty()) return
        val b = _browser.value ?: return
        val link = b.searchLink
        if (link == null) {
            say("This catalog has no search.")
            return
        }
        val catalog = b.catalog
        loadJob?.cancel()
        _browser.value = b.copy(loading = true, error = null, failedUrl = null, searchTerm = t)
        loadJob = scope.launch {
            try {
                val template: String? = if (link.type?.contains("opensearchdescription") == true) {
                    // The link points at a description of the search; its Url entry holds the real address.
                    val res = withContext(Dispatchers.IO) { http.getText(link.href, catalog.auth) }
                    val d = OpdsParser.parse(res.text, res.url) as? OpdsDoc.OpenSearch
                    val pick = d?.templates?.firstOrNull { x -> x.type?.let { it.contains("atom") || it.contains("opds") } == true }
                        ?: d?.templates?.firstOrNull()
                    pick?.let { OpdsUrl.resolve(it.template, res.url) }
                } else {
                    link.href
                }
                if (template == null) {
                    fail(catalog, link.href, "This catalog's search could not be read.")
                    return@launch
                }
                loadPage(catalog, OpdsUrl.expandSearch(template, t), isSearch = true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(catalog, link.href, explain(e))
            }
        }
    }

    // ---- a book's page ----------------------------------------------------------------------

    fun openPublication(pub: OpdsPublication) {
        val b = _browser.value ?: return
        val detail = pub.detailLink
        val page = BrowserPage.DetailPage(nextUid++, b.current?.url ?: b.catalog.url, pub, loadingMore = detail != null)
        _browser.value = b.copy(pages = b.pages + page)
        if (detail == null) return
        val catalog = b.catalog
        scope.launch {
            val full: OpdsPublication? = try {
                run {
                    when (val d = fetchDoc(catalog, detail.href).second) {
                        is OpdsDoc.Entry -> d.publication
                        is OpdsDoc.Feed -> d.feed.publications.firstOrNull() ?: d.feed.groups.firstNotNullOfOrNull { it.publications.firstOrNull() }
                        else -> null
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            _browser.update { cur ->
                cur?.copy(
                    pages = cur.pages.map { p ->
                        if (p is BrowserPage.DetailPage && p.uid == page.uid) {
                            p.copy(publication = if (full != null) merge(pub, full) else pub, loadingMore = false, detailFailed = full == null)
                        } else {
                            p
                        }
                    },
                )
            }
        }
    }

    /** The full record wins, but the feed's own links and cover are kept when it leaves them out. */
    private fun merge(base: OpdsPublication, full: OpdsPublication): OpdsPublication = full.copy(
        title = full.title.takeIf { it.isNotBlank() && it != "Untitled" } ?: base.title,
        authors = full.authors.ifEmpty { base.authors },
        links = if (full.links.any { it.isAcquisition }) full.links else base.links + full.links.filter { it !in base.links },
        images = full.images.ifEmpty { base.images },
    )

    // ---- the library side -------------------------------------------------------------------

    fun downloadKey(pub: OpdsPublication): String = pub.id ?: pub.title

    /** The source a book downloaded from [catalog] is saved with: the two built-in ones by name, any other by the catalog's own name. */
    private fun sourceOf(catalog: Catalog): String {
        val u = catalog.url.lowercase()
        return when {
            "gutenberg" in u -> "gutenberg"
            "standardebooks" in u -> "standardebooks"
            "calibre" in catalog.name.lowercase() -> "calibre"
            else -> catalog.name.trim().ifEmpty { "catalog" }
        }
    }

    private fun sourceKeys(pub: OpdsPublication): List<String> =
        listOfNotNull(pub.id, pub.identifier) + OpdsFormats.epubLinks(pub).map { it.href }

    private fun norm(s: String): String = s.replace(Regex("\\s+"), " ").trim().lowercase()

    /** The book in the library that this entry already is (downloaded before, or added by hand with the same title). */
    fun existingBook(pub: OpdsPublication, books: List<Book>): Book? {
        val catalogId = _browser.value?.catalog?.id
        if (catalogId != null) {
            val id = store.findSource(catalogId, sourceKeys(pub))
            if (id != null) books.firstOrNull { it.id == id }?.let { return it }
        }
        val t = norm(pub.title)
        if (t.isEmpty()) return null
        return books.firstOrNull { norm(it.title) == t }
    }

    fun download(pub: OpdsPublication, link: OpdsLink) {
        val b = _browser.value ?: return
        if (_download.value != null) {
            say("A download is already running.")
            return
        }
        val catalog = b.catalog
        val key = downloadKey(pub)
        _download.value = DownloadState(key, null, false)
        appScope.launch {
            val tmp = File(cacheDir, "opds-${System.nanoTime()}.epub")
            try {
                http.download(link.href, catalog.auth, tmp) { done, total ->
                    _download.value = DownloadState(key, if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else null, false)
                }
                _download.value = DownloadState(key, null, true)
                val name = pub.title.replace(Regex("[\\\\/:*?\"<>|]"), " ").trim().take(80).ifEmpty { "book" } + ".epub"
                val hints = ImportHints(
                    subjects = pub.subjects,
                    description = pub.summary,
                    publisher = pub.publisher,
                    published = pub.published,
                    source = sourceOf(catalog),
                )
                when (val r = repo.importFile(tmp, name, hints)) {
                    is ImportOutcome.Added -> {
                        store.rememberSource(catalog.id, sourceKeys(pub) + link.href, r.id)
                        say("Added “${r.title}” to your library")
                    }
                    is ImportOutcome.Duplicate -> {
                        if (r.id.isNotEmpty()) store.rememberSource(catalog.id, sourceKeys(pub) + link.href, r.id)
                        say("“${pub.title}” is already in your library")
                    }
                    is ImportOutcome.Unsupported -> say("That file is not an EPUB, so Paperback can't open it yet.")
                    is ImportOutcome.Failed -> say("The download could not be added to your library.")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say(
                    when {
                        e is OpdsHttpException -> explain(e)
                        e is java.net.UnknownHostException || e is java.net.SocketException || e is java.net.SocketTimeoutException ->
                            "Couldn't reach the server. Check your connection."
                        else -> e.message ?: "The download failed."
                    },
                )
            } finally {
                tmp.delete()
                _download.value = null
            }
        }
    }

    private companion object {
        const val CACHE_MS = 10 * 60 * 1000L
    }
}
