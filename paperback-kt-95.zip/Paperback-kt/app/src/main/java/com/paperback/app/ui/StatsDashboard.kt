package com.paperback.app.ui

import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Patterns
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.StatNames
import com.paperback.app.data.Stats
import com.paperback.app.data.buildSessions
import com.paperback.app.data.dateOf
import com.paperback.app.data.formatCount
import com.paperback.app.data.pctDelta
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.LocalPbDark
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/*
 * The Stats -> Activity dashboard: a grid of rounded cards (consistency, daily goal arc, peak hour, most active time,
 * this week against last week, and a report to share). The look is the "Reference colors" mockup: cards a little
 * lighter than the page, a blue-violet-pink arc, a purple bell curve and soft green deltas.
 */

private val GaugeBlue = Color(0xFF5464C3)
private val GaugeViolet = Color(0xFFC66DC1)
private val GaugePink = Color(0xFFEC67E6)
private val BellPurple = Color(0xFF8A6CF2)
private val ReportPurple = Color(0xFF5A41A6)
private val ReportRing = Color(0xFF3E3A52)

@Composable
private fun upColor(): Color = if (LocalPbDark.current) Color(0xFF5CCF86) else Color(0xFF2E9E5B)

@Composable
private fun downColor(): Color = if (LocalPbDark.current) Color(0xFFF2766B) else Color(0xFFD84A3C)

// ---- the page header (Settings -> App style -> Stats header) ------------------------------------

/** "Stats", today's date, and the buttons: menu on the left, calendar and search on the right. */
@Composable
fun StatsOwnHeader(
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onCalendar: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val today = remember { LocalDate.now() }
    val dateText = remember(today) {
        "${StatNames.WEEKDAYS[StatNames.weekdayIndex(today)]}, ${today.dayOfMonth} ${StatNames.MONTHS[today.monthValue - 1]}"
    }
    Row(modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
        HeaderCircle(PbIconName.Menu, "Open library menu", onMenu)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Stats", color = t.ink, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em, maxLines = 1)
            Text(dateText, color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        HeaderCircle(PbIconName.Calendar, "Open the full calendar", onCalendar)
        Spacer(Modifier.width(8.dp))
        HeaderCircle(PbIconName.Search, "Search", onSearch)
    }
}

@Composable
private fun HeaderCircle(icon: PbIconName, description: String, onClick: () -> Unit) {
    val t = pbTokens()
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(t.card)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        PbIcon(icon, size = 22.dp, tint = t.ink, contentDescription = description)
    }
}

/** One page tab of the Stats row: a soft pill when chosen, plain text otherwise. */
@Composable
fun StatsTabPill(text: String, selected: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    Box(
        Modifier
            .height(42.dp)
            .clip(RoundedCornerShape(21.dp))
            .background(if (selected) t.card else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (selected) t.ink else t.setSub,
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            maxLines = 1,
        )
    }
}

// ---- the dashboard ------------------------------------------------------------------------------

/**
 * @param byDay seconds read on each day
 * @param patterns reading by hour, from the last 90 days
 */
@Composable
fun ActivityDashboard(
    sessions: List<ReadingSession>,
    byDay: Map<LocalDate, Long>,
    patterns: Patterns,
    today: LocalDate,
    zone: ZoneId,
    goalMinutes: Int,
    todaySeconds: Long,
    streak: Int,
    onOpenGoals: () -> Unit,
    onShare: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val shareImage = LocalShareImage.current

    // Consistency: how many of the last 30 days had at least a minute of reading.
    val last30 = remember(byDay, today) { (29 downTo 0).map { today.minusDays(it.toLong()) } }
    val daysRead = last30.count { (byDay[it] ?: 0L) >= 60L }
    val consistency = (daysRead * 100f / 30f).toInt()

    // This week (the last seven days) against the seven days before it.
    val week = remember(sessions, byDay, today, zone) { weekTotals(sessions, byDay, today.minusDays(6), today, zone) }
    val before = remember(sessions, byDay, today, zone) { weekTotals(sessions, byDay, today.minusDays(13), today.minusDays(7), zone) }

    val readMin = (todaySeconds / 60).toInt()
    val progress = if (goalMinutes <= 0) 0f else (todaySeconds / 60f / goalMinutes).coerceIn(0f, 1f)

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // ---- row 1: consistency + daily goal ----
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DashCard(Modifier.weight(1f).height(188.dp)) {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { DashLabel(PbIconName.Check, "Consistency") }
                            if (streak > 0) {
                                Row(
                                    Modifier.clip(RoundedCornerShape(14.dp)).background(t.ink.copy(alpha = 0.1f)).padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    PbIcon(PbIconName.Flame, size = 14.dp, tint = Accent.color, filled = true)
                                    Spacer(Modifier.width(3.dp))
                                    Text("$streak", color = t.ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("$consistency%", color = t.ink, fontSize = 36.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em)
                        Spacer(Modifier.height(8.dp))
                        DayDots(last30.takeLast(21).map { (byDay[it] ?: 0L) >= 60L })
                    }
                    Text(
                        buildAnnotatedString {
                            append("Read on ")
                            withStyle(SpanStyle(color = t.ink, fontWeight = FontWeight.SemiBold)) { append("$daysRead of the last 30 days") }
                        },
                        color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp,
                    )
                }
            }

            DashCard(Modifier.weight(1f).height(188.dp), onClick = onOpenGoals) {
                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    DashLabel(PbIconName.Goals, "Daily goal")
                    Box(Modifier.fillMaxWidth().weight(1f).padding(top = 6.dp)) {
                        GoalGauge(progress, Modifier.fillMaxSize())
                        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$readMin", color = t.ink, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em)
                            Text(if (progress >= 1f) "goal reached" else "min today", color = t.setSub, fontSize = 12.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("0", color = t.setSub, fontSize = 12.sp)
                        Text("$goalMinutes min", color = t.setSub, fontSize = 12.sp)
                    }
                }
            }
        }

        // ---- row 2: peak hour + most active ----
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DashCard(Modifier.weight(1f).height(168.dp)) {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        DashLabel(PbIconName.Clock, "Peak hour")
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (patterns.total == 0) "–" else hourLabel(patterns.peakHour),
                            color = t.ink, fontSize = 36.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em,
                        )
                        Spacer(Modifier.height(10.dp))
                        HourSlider(if (patterns.total == 0) 0.5f else (patterns.peakHour + 0.5f) / 24f)
                    }
                    Text(
                        if (patterns.total == 0) AnnotatedString("Read a little more and your best time will show here.")
                        else buildAnnotatedString {
                            append("You read most ")
                            withStyle(SpanStyle(color = t.ink, fontWeight = FontWeight.SemiBold)) {
                                append("between ${hourLabel(patterns.peakHour)} & ${hourLabel((patterns.peakHour + 1) % 24)}")
                            }
                        },
                        color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp,
                    )
                }
            }

            DashCard(Modifier.weight(1f).height(168.dp)) {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        DashLabel(PbIconName.Timer, "Most active")
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (patterns.total == 0) "–" else patterns.topTime.name,
                            color = t.ink, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em, maxLines = 1,
                        )
                    }
                    HourBell(patterns.byHour, patterns.peakHour, patterns.total > 0, Modifier.fillMaxWidth().height(60.dp))
                }
            }
        }

        // ---- this week ----
        Text(
            "This week",
            modifier = Modifier.padding(start = 4.dp, top = 10.dp),
            color = t.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold,
        )
        LazyRow(
            modifier = Modifier.fullBleed(20.dp),
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                val d = pctDelta(week.pages.toLong(), before.pages.toLong())
                WeekCard(
                    PbIconName.Book, "Pages", formatCount(week.pages),
                    when {
                        d == null -> if (week.pages > 0 && before.pages == 0) "new" else "–"
                        d > 0 -> "▲ $d%"
                        d < 0 -> "▼ ${abs(d)}%"
                        else -> "same"
                    },
                    when {
                        d == null -> 0
                        d > 0 -> 1
                        d < 0 -> -1
                        else -> 0
                    },
                )
            }
            item {
                val diffMin = ((week.seconds - before.seconds) / 60L).toInt()
                WeekCard(
                    PbIconName.Clock, "Time", Stats.duration(week.seconds),
                    when {
                        before.seconds == 0L && week.seconds == 0L -> "–"
                        diffMin > 0 -> "▲ $diffMin min"
                        diffMin < 0 -> "▼ ${abs(diffMin)} min"
                        else -> "same"
                    },
                    if (diffMin > 0) 1 else if (diffMin < 0) -1 else 0,
                )
            }
            item {
                val diff = week.sessions - before.sessions
                WeekCard(
                    PbIconName.Stack, "Sessions", formatCount(week.sessions),
                    when {
                        week.sessions == 0 && before.sessions == 0 -> "–"
                        diff > 0 -> "▲ $diff"
                        diff < 0 -> "▼ ${abs(diff)}"
                        else -> "same"
                    },
                    if (diff > 0) 1 else if (diff < 0) -1 else 0,
                )
            }
        }

        // ---- report ----
        DashCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    DashLabel(PbIconName.Note, "Reading report")
                    Spacer(Modifier.height(6.dp))
                    Text(
                        buildAnnotatedString {
                            append("Share your reading stats with ")
                            withStyle(SpanStyle(color = t.ink, fontWeight = FontWeight.SemiBold)) { append("friends or on social media") }
                        },
                        color = t.setSub, fontSize = 14.sp, lineHeight = 20.sp,
                    )
                }
                Spacer(Modifier.width(12.dp))
                Box(Modifier.size(56.dp).clip(CircleShape).background(ReportRing), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(ReportPurple)
                            .clickable {
                                // a picture of the week, with the old text as its caption
                                shareImage(
                                    com.paperback.app.data.weekShareCard(
                                        week.seconds, week.pages, week.sessions, daysRead, streak,
                                        "My week in Paperback: ${Stats.duration(week.seconds)} of reading, ${formatCount(week.pages)} pages, " +
                                            "${formatCount(week.sessions)} sessions. Read on $daysRead of the last 30 days" +
                                            if (streak > 1) ", $streak days in a row." else ".",
                                    ),
                                )
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        PbIcon(PbIconName.ImportFile, size = 20.dp, tint = Color.White, strokeWidth = 2.3f, contentDescription = "Share your stats")
                    }
                }
            }
        }
    }
}

// ---- numbers ------------------------------------------------------------------------------------

private class WeekTotals(val seconds: Long, val pages: Int, val sessions: Int)

private fun weekTotals(
    sessions: List<ReadingSession>,
    byDay: Map<LocalDate, Long>,
    from: LocalDate,
    to: LocalDate,
    zone: ZoneId,
): WeekTotals {
    var seconds = 0L
    var d = from
    while (!d.isAfter(to)) {
        seconds += byDay[d] ?: 0L
        d = d.plusDays(1)
    }
    val rows = sessions.filter {
        val day = dateOf(it.startMs, zone)
        !day.isBefore(from) && !day.isAfter(to)
    }
    return WeekTotals(seconds, rows.sumOf { it.pages }, buildSessions(rows).size)
}

/** 0 -> "12am", 9 -> "9am", 12 -> "12pm", 21 -> "9pm". */
private fun hourLabel(h: Int): String = when {
    h == 0 -> "12am"
    h < 12 -> "${h}am"
    h == 12 -> "12pm"
    else -> "${h - 12}pm"
}

// ---- pieces -------------------------------------------------------------------------------------

/**
 * A card a little lighter than the page, with a soft top-left glow like the mockup. With [onClick] it is clickable
 * (and announced as a button); [description] is what a screen reader says for the whole card.
 */
@Composable
internal fun DashCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    description: String? = null,
    content: @Composable () -> Unit,
) {
    val t = pbTokens()
    val shape = RoundedCornerShape(26.dp)
    val described = if (description != null) Modifier.semantics(mergeDescendants = true) { contentDescription = description } else Modifier
    Box(
        modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(lerp(t.card, Color.White, 0.045f), t.card)))
            .then(described)
            .then(if (onClick != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button, onClick = onClick) else Modifier),
    ) { content() }
}

/** The colours the dashboard-style Stats pages draw with (the Reference palette): blue, violet, cyan, pink. */
object DashAccent {
    val Blue = Color(0xFF6C8CFF)
    val Violet = Color(0xFFA58BFF)
    val Cyan = Color(0xFF5DE0E6)
    val Pink = Color(0xFFF08AD8)
}

@Composable
internal fun DashLabel(icon: PbIconName, text: String) {
    val t = pbTokens()
    Row(verticalAlignment = Alignment.CenterVertically) {
        PbIcon(icon, size = 16.dp, tint = t.setSub, strokeWidth = 2f)
        Spacer(Modifier.width(8.dp))
        Text(text, color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** The last three weeks as small dots: lit when you read that day. */
@Composable
private fun DayDots(read: List<Boolean>) {
    val t = pbTokens()
    val lit = Accent.color.copy(alpha = 0.75f)
    val off = t.ink.copy(alpha = 0.1f)
    Canvas(Modifier.width(88.dp).height(34.dp)) {
        val step = 12.dp.toPx()
        val r = 4.dp.toPx()
        read.forEachIndexed { i, on ->
            val col = i % 7
            val row = i / 7
            drawCircle(if (on) lit else off, r, Offset(r + col * step, r + row * step))
        }
    }
}

/** A half ring from 0 to the goal, in the mockup's blue - violet - pink, with a white tick where you are. */
@Composable
internal fun GoalGauge(progress: Float, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val track = t.ink.copy(alpha = 0.12f)
    Canvas(modifier) {
        val stroke = 14.dp.toPx()
        val w = size.width
        val h = size.height
        val r = min((w - stroke) / 2f, h - stroke)
        val cx = w / 2f
        val cy = h - stroke / 2f
        val topLeft = Offset(cx - r, cy - r)
        val arc = Size(2f * r, 2f * r)
        drawArc(
            color = track, startAngle = 180f, sweepAngle = 180f, useCenter = false,
            topLeft = topLeft, size = arc, style = Stroke(width = stroke, cap = StrokeCap.Round),
        )
        if (progress > 0f) {
            drawArc(
                brush = Brush.linearGradient(listOf(GaugeBlue, GaugeViolet, GaugePink), start = Offset(cx - r, 0f), end = Offset(cx + r, 0f)),
                startAngle = 180f, sweepAngle = 180f * progress, useCenter = false,
                topLeft = topLeft, size = arc, style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            val a = PI * (1.0 - progress)
            val inner = r - stroke * 0.7f
            val outer = r + stroke * 0.7f
            drawLine(
                color = Color.White,
                start = Offset(cx + (inner * cos(a)).toFloat(), cy - (inner * sin(a)).toFloat()),
                end = Offset(cx + (outer * cos(a)).toFloat(), cy - (outer * sin(a)).toFloat()),
                strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round,
            )
        }
    }
}

/** A thin purple line with a white dot at [fraction] of the day. */
@Composable
private fun HourSlider(fraction: Float) {
    Canvas(Modifier.fillMaxWidth().height(14.dp)) {
        val y = size.height / 2f
        drawLine(
            brush = Brush.horizontalGradient(listOf(Color(0xFF5A556B), Color(0xFF7666A4))),
            start = Offset(0f, y), end = Offset(size.width, y),
            strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round,
        )
        drawCircle(Color.White, 6.dp.toPx(), Offset(6.dp.toPx() + fraction * (size.width - 12.dp.toPx()), y))
    }
}

/** Your 24 hours as one soft curve, with the peak lit in purple and two white dots at its feet. */
@Composable
private fun HourBell(byHour: List<Int>, peak: Int, hasData: Boolean, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val ghost = t.ink.copy(alpha = 0.18f)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val base = h - 4.dp.toPx()
        val top = 6.dp.toPx()
        drawLine(ghost, Offset(0f, base), Offset(w, base), strokeWidth = 1.dp.toPx())
        if (!hasData || byHour.size < 24) return@Canvas
        val maxV = max(1, byHour.maxOrNull() ?: 1)
        fun px(i: Int): Float = i * w / 23f
        fun py(i: Int): Float = base - (byHour[i].toFloat() / maxV) * (base - top)
        fun curve(from: Int, to: Int): Path {
            val p = Path()
            p.moveTo(px(from), py(from))
            for (i in from + 1..to) {
                val mid = (px(i - 1) + px(i)) / 2f
                p.cubicTo(mid, py(i - 1), mid, py(i), px(i), py(i))
            }
            return p
        }
        drawPath(curve(0, 23), ghost, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
        val a = max(0, peak - 1)
        val b = min(23, peak + 1)
        drawPath(curve(a, b), BellPurple, style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round))
        drawCircle(Color.White, 4.dp.toPx(), Offset(px(a), py(a)))
        drawCircle(Color.White, 4.dp.toPx(), Offset(px(b), py(b)))
    }
}

/** [sign]: 1 = up (green), -1 = down (red), 0 = no change. */
@Composable
private fun WeekCard(icon: PbIconName, label: String, value: String, delta: String, sign: Int) {
    val t = pbTokens()
    DashCard(Modifier.width(150.dp).height(116.dp)) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            DashLabel(icon, label)
            Text(value, color = t.ink, fontSize = 32.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em, maxLines = 1)
            Text(
                delta,
                color = when {
                    sign > 0 -> upColor()
                    sign < 0 -> downColor()
                    else -> t.setSub
                },
                fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Start,
            )
        }
    }
}


// ---- shared by every Stats page -----------------------------------------------------------------

/** The dashboard card surface (a soft glow from the top left) for a Column or Row that already lays out its own content. */
@Composable
internal fun Modifier.dashSurface(radius: Dp = 26.dp): Modifier {
    val t = pbTokens()
    return this
        .clip(RoundedCornerShape(radius))
        .background(Brush.linearGradient(listOf(lerp(t.card, Color.White, 0.045f), t.card)))
}

/** A thin track with [color] filling [fraction] (0..1) of it, fading to a lighter tone at the end. */
@Composable
internal fun GradientTrack(
    fraction: Float,
    color: Color,
    modifier: Modifier = Modifier,
    height: Dp = 6.dp,
    minFraction: Float = 0f,
) {
    val f = fraction.coerceIn(0f, 1f)
    val shape = RoundedCornerShape(height / 2)
    Box(modifier.fillMaxWidth().height(height).clip(shape).background(pbTokens().ink.copy(alpha = 0.10f))) {
        if (f > 0f) {
            Box(
                Modifier
                    .fillMaxWidth(f.coerceAtLeast(minFraction))
                    .fillMaxHeight()
                    .clip(shape)
                    .background(Brush.horizontalGradient(listOf(color, lerp(color, Color.White, 0.3f)))),
            )
        }
    }
}

/** The fill of a thin upright bar: lighter at the top. [strong] false is the faded look of the past periods. */
internal fun barBrush(color: Color, strong: Boolean = true): Brush {
    val a = if (strong) 1f else 0.45f
    return Brush.verticalGradient(listOf(lerp(color, Color.White, 0.3f).copy(alpha = a), color.copy(alpha = a)))
}

/** A section heading between cards, like "This week" on the dashboard. */
@Composable
internal fun DashHeading(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(start = 6.dp, end = 4.dp, top = 24.dp, bottom = 10.dp),
        color = pbTokens().ink,
        fontSize = 20.sp,
        fontWeight = FontWeight.SemiBold,
    )
}
