package com.paperback.app.data

import java.io.File
import java.util.zip.ZipFile

/**
 * Counts the words of an EPUB straight from its file: every XHTML / HTML part is read, tags, scripts and styles are
 * dropped, and the rest is split on white space. Plain Kotlin with no Android, so it can be tested on its own.
 * Navigation pages (the contents list) are left out so they don't add to the count.
 */
object WordCount {
    private val tagOrEntityBreak = Regex("<[^>]*>")
    private val blocks = Regex("(?is)<(script|style|head)\\b.*?</\\1>")
    private val entities = Regex("&(#\\d+|#x[0-9a-fA-F]+|[a-zA-Z]+);")

    /** The words in [file], or 0 when it can't be read (a damaged file, or not a zip). Never throws. */
    fun ofEpub(file: File): Int = try {
        if (!file.exists()) 0 else ZipFile(file).use { zip ->
            var total = 0L
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                if (e.isDirectory) continue
                val name = e.name.lowercase()
                if (!(name.endsWith(".xhtml") || name.endsWith(".html") || name.endsWith(".htm"))) continue
                if (name.endsWith("nav.xhtml") || name.endsWith("toc.xhtml") || name.endsWith("toc.html")) continue
                val text = zip.getInputStream(e).use { it.readBytes().toString(Charsets.UTF_8) }
                total += ofHtml(text)
            }
            total.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }
    } catch (e: Exception) {
        0
    }

    /** The words in one HTML or XHTML text. */
    fun ofHtml(html: String): Int {
        val noBlocks = blocks.replace(html, " ")
        // a tag ends a word ("one<br/>two" is two words), an entity stands for one character
        val noTags = tagOrEntityBreak.replace(noBlocks, " ")
        val plain = entities.replace(noTags) { if (it.value == "&nbsp;") " " else "x" }
        var count = 0
        var inWord = false
        for (ch in plain) {
            if (ch.isLetterOrDigit()) {
                if (!inWord) {
                    count++
                    inWord = true
                }
            } else if (ch.isWhitespace()) {
                inWord = false
            }
            // other marks (punctuation, dashes) stay inside the word they touch, so "don't" is one word
        }
        return count
    }
}
