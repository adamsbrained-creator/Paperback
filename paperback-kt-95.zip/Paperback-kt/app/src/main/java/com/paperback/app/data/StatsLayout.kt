package com.paperback.app.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Which cards each Stats page shows and in what order, as you set it with Customize. Saved as one small piece of
 * JSON ({"explore": {"order": [...], "hidden": [...]}}) in the app's preferences and in backups.
 * A card the layout has never heard of (a new one in an update) is shown after the ones you ordered.
 */
class StatsLayout private constructor(
    private val order: Map<String, List<String>>,
    private val hidden: Map<String, Set<String>>,
) {
    /** The card keys of [page] in the order to show them: your order first, then any others in their normal order. */
    fun arrange(page: String, keys: List<String>): List<String> {
        val saved = order[page].orEmpty().filter { it in keys }
        return saved + keys.filter { it !in saved }
    }

    fun isHidden(page: String, key: String): Boolean = key in hidden[page].orEmpty()

    fun hiddenCount(page: String): Int = hidden[page].orEmpty().size

    fun withOrder(page: String, keys: List<String>): StatsLayout = StatsLayout(order + (page to keys), hidden)

    fun withHidden(page: String, key: String, hide: Boolean): StatsLayout {
        val now = hidden[page].orEmpty()
        val next = if (hide) now + key else now - key
        return StatsLayout(order, hidden + (page to next))
    }

    /** Back to the normal cards in the normal order for one page. */
    fun reset(page: String): StatsLayout = StatsLayout(order - page, hidden - page)

    fun toJson(): String {
        val root = JSONObject()
        for (page in (order.keys + hidden.keys)) {
            root.put(
                page,
                JSONObject()
                    .put("order", JSONArray(order[page].orEmpty()))
                    .put("hidden", JSONArray(hidden[page].orEmpty().toList())),
            )
        }
        return root.toString()
    }

    companion object {
        val EMPTY = StatsLayout(emptyMap(), emptyMap())

        fun parse(json: String): StatsLayout {
            if (json.isBlank()) return EMPTY
            return try {
                val root = JSONObject(json)
                val order = LinkedHashMap<String, List<String>>()
                val hidden = LinkedHashMap<String, Set<String>>()
                for (page in root.keys()) {
                    val o = root.optJSONObject(page) ?: continue
                    order[page] = o.optJSONArray("order").toStrings()
                    hidden[page] = o.optJSONArray("hidden").toStrings().toSet()
                }
                StatsLayout(order, hidden)
            } catch (e: Exception) {
                EMPTY
            }
        }

        private fun JSONArray?.toStrings(): List<String> =
            if (this == null) emptyList() else (0 until length()).map { optString(it) }.filter { it.isNotEmpty() }
    }
}
