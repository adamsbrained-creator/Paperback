package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.paperback.app.data.Book
import com.paperback.app.data.BooksOverview
import com.paperback.app.data.ProgressRow
import com.paperback.app.data.SHELF_LANGS
import com.paperback.app.data.SHELF_RATED
import com.paperback.app.data.booksOverview
import com.paperback.app.data.commas
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** Where a tap on the Books page goes. The Stats screen builds this from the app's navigation. */
class BooksLinks(
    /** All the books (the Library). */
    val library: () -> Unit,
    val finished: () -> Unit,
    /** The shelf of the books you are reading. */
    val reading: () -> Unit,
    val book: (bookId: String) -> Unit,
    /** A shelf of the books behind a number: "langs" or "rated". */
    val shelf: (kind: String) -> Unit,
    /** The books of one author. */
    val author: (name: String) -> Unit,
    /** The list of all authors. */
    val authors: () -> Unit,
)

private const val MAX_PROGRESS = 6
private const val MAX_AUTHORS = 14

/** The progress bars take the accents in this order, starting with pink (the same as the TypeScript app). */
private val PROGRESS_ACCENTS = listOf(StatsAccent.Blue, StatsAccent.Yellow, StatsAccent.Mint, StatsAccent.Pink)

/**
 * Stats -> Books: what is in the library, what you are reading, the authors and the ratings.
 * Every card opens something: the Library, a shelf, a book, an author or the ratings.
 */
@Composable
fun BooksScreen(books: List<Book>, links: BooksLinks, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val o = remember(books) { booksOverview(books) }

    if (o.total == 0) {
        Box(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().dashSurface().padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("No books yet", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Add a book to the library and its stats will show up here.",
                    color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center,
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "library") { LibraryCard(o, links.library) }
        item(key = "tiles1") {
            TileRow(
                { m ->
                    StatTile(
                        "Finished", StatsAccent.Mint, m,
                        onTap = if (o.finished > 0) links.finished else null,
                        description = "${o.finished} finished. Show the finished books.",
                    ) { BigNumber(o.finished.toString()) }
                },
                { m ->
                    StatTile(
                        "Reading", StatsAccent.Pink, m,
                        onTap = if (o.reading > 0) links.reading else null,
                        description = "${o.reading} reading. Show the books you are reading.",
                    ) { BigNumber(o.reading.toString()) }
                },
            )
        }
        item(key = "tiles2") {
            val longest = o.longest
            TileRow(
                { m ->
                    StatTile(
                        "Longest read", StatsAccent.Blue, m,
                        onTap = if (longest != null) ({ links.book(longest.book.id) }) else null,
                        description = if (longest != null) "Longest read: ${longest.book.title}. Open book details." else "Longest read: none yet.",
                    ) {
                        BigNumber(if (longest != null) commas(longest.pages) else "\u2013", unit = if (longest != null) "pages" else null)
                        if (longest != null) TileSub(longest.book.title)
                    }
                },
                { m ->
                    StatTile(
                        "Languages", StatsAccent.Yellow, m,
                        onTap = { links.shelf(SHELF_LANGS) },
                        description = "${o.languages.size} languages. Show the books by language.",
                    ) {
                        BigNumber(if (o.languages.isEmpty()) "\u2013" else o.languages.size.toString())
                        if (o.languages.isNotEmpty()) TileSub(o.languages.joinToString(" \u00B7 "))
                    }
                },
            )
        }

        if (o.progress.isNotEmpty()) {
            item(key = "progress") { ProgressCard(o.progress, links) }
        }
        if (o.authors.isNotEmpty()) {
            item(key = "authors") { AuthorsCard(o, links) }
        }
        item(key = "ratings") { RatingsCard(o, links) { links.shelf(SHELF_RATED) } }
    }
}

// ---- library card ---------------------------------------------------------------------------

@Composable
internal fun CardLabel(text: String, modifier: Modifier = Modifier, color: Color = pbTokens().setSub) {
    Text(
        text,
        modifier = modifier,
        color = color,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
    )
}

@Composable
private fun LibraryCard(o: BooksOverview, onOpen: () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .dashSurface()
            .semantics(mergeDescendants = true) {
                contentDescription = "Library: ${o.total} ${if (o.total == 1) "book" else "books"}. Open all books."
            }
            .clickable(onClickLabel = "Open all books", role = Role.Button, onClick = onOpen)
            .padding(start = 22.dp, top = 18.dp, bottom = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            CardLabel("Library")
            Spacer(Modifier.height(10.dp))
            Text(
                commas(o.total),
                color = t.ink,
                fontSize = 64.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.03).em,
                maxLines = 1,
            )
            Text(if (o.total == 1) "book" else "books", color = t.setSub, fontSize = 15.sp)
        }
        CoverFan(o.recent)
    }
}

/** Up to three covers fanned out, newest on top; one cover stands alone. The positions are the TypeScript app's. */
@Composable
private fun CoverFan(recent: List<Book>) {
    // left, top (dp), rotation (degrees), stacking
    val slots = if (recent.size == 1) {
        listOf(Slot(44f, 16f, -3f, 0f))
    } else {
        listOf(Slot(4f, 24f, -12f, 0f), Slot(44f, 10f, -2f, 1f), Slot(84f, 20f, 9f, 2f))
    }
    Box(Modifier.width(170.dp).height(150.dp)) {
        recent.take(3).forEachIndexed { i, b ->
            val s = slots[i]
            BookCover(
                b,
                Modifier
                    .offset(x = s.left.dp, y = s.top.dp)
                    .zIndex(s.z)
                    .rotate(s.rotate)
                    .width(78.dp),
            )
        }
    }
}

private class Slot(val left: Float, val top: Float, val rotate: Float, val z: Float)

// ---- tiles ----------------------------------------------------------------------------------

/** Two tiles side by side, the same height. */
@Composable
internal fun TileRow(first: @Composable (Modifier) -> Unit, second: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        first(Modifier.weight(1f).fillMaxHeight())
        second(Modifier.weight(1f).fillMaxHeight())
    }
}

/**
 * A dashboard card with a small dot in its accent beside the label. With [onTap] it is clickable and shows a small
 * arrow. [nested] is for a tile inside another card: it is a soft tint instead of a card of its own.
 */
@Composable
internal fun StatTile(
    label: String,
    accent: Color,
    modifier: Modifier,
    onTap: (() -> Unit)?,
    description: String,
    nested: Boolean = false,
    content: @Composable () -> Unit,
) {
    val t = pbTokens()
    val body: @Composable () -> Unit = {
        Box(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                    Spacer(Modifier.width(8.dp))
                    CardLabel(label)
                }
                Spacer(Modifier.height(8.dp))
                content()
            }
            if (onTap != null) {
                PbIcon(PbIconName.CaretRight, size = 14.dp, tint = t.setSub, modifier = Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 14.dp))
            }
        }
    }
    if (nested) {
        val tap = if (onTap != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button, onClick = onTap) else Modifier
        Box(
            modifier
                .clip(RoundedCornerShape(20.dp))
                .background(t.ink.copy(alpha = 0.06f))
                .semantics(mergeDescendants = true) { contentDescription = description }
                .then(tap),
        ) { body() }
    } else {
        DashCard(modifier, onClick = onTap, description = description) { body() }
    }
}

@Composable
internal fun BigNumber(text: String, unit: String? = null) {
    val t = pbTokens()
    Row {
        Text(
            text,
            modifier = Modifier.alignByBaseline(),
            color = t.ink,
            fontSize = 30.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
        if (unit != null) {
            Text(unit, modifier = Modifier.alignByBaseline().padding(start = 4.dp), color = t.setSub, fontSize = 14.sp, maxLines = 1)
        }
    }
}

@Composable
internal fun TileSub(text: String) {
    Text(text, modifier = Modifier.padding(top = 6.dp), color = pbTokens().setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

// ---- reading progress -----------------------------------------------------------------------

@Composable
private fun ProgressCard(rows: List<ProgressRow>, links: BooksLinks) {
    val t = pbTokens()
    val shown = rows.take(MAX_PROGRESS)
    val hidden = rows.size - shown.size
    val blue = inkOf(StatsAccent.Blue)
    Column(Modifier.fillMaxWidth().dashSurface().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            CardLabel("Reading progress")
            Row(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClickLabel = "Open the shelf of books you are reading", role = Role.Button, onClick = links.reading)
                    .padding(start = 10.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Open shelf", color = blue, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                PbIcon(PbIconName.CaretRight, size = 16.dp, tint = blue)
            }
        }
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            shown.forEachIndexed { i, r ->
                val ac = PROGRESS_ACCENTS[(i + 3) % PROGRESS_ACCENTS.size]
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .semantics(mergeDescendants = true) { contentDescription = "${r.book.title}, ${r.pct}%. Open book details." }
                        .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(r.book.id) }
                        .padding(vertical = 6.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(r.book.title, modifier = Modifier.weight(1f), color = t.ink, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${r.pct}%", color = inkOf(ac), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    PctBar(max(r.pct, 1) / 100f, ac, 8.dp)
                }
            }
        }
        if (hidden > 0) {
            Text(
                "and $hidden more",
                modifier = Modifier
                    .padding(top = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClickLabel = "Open the shelf", role = Role.Button, onClick = links.reading)
                    .padding(vertical = 4.dp),
                color = t.setSub,
                fontSize = 13.sp,
            )
        }
    }
}

// ---- authors --------------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AuthorsCard(o: BooksOverview, links: BooksLinks) {
    val t = pbTokens()
    val shown = o.authors.take(MAX_AUTHORS)
    val hidden = o.authors.size - shown.size
    Column(Modifier.fillMaxWidth().dashSurface().padding(horizontal = 20.dp, vertical = 18.dp)) {
        CardLabel("Authors")
        Spacer(Modifier.height(14.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            shown.forEach { a ->
                AuthorPill(
                    onClick = { links.author(a.name) },
                    description = "${a.name}, ${a.count} ${if (a.count == 1) "book" else "books"}. Show their books.",
                ) {
                    Text(a.name, color = t.ink, fontSize = 14.sp)
                    if (a.count > 1) Text(a.count.toString(), modifier = Modifier.padding(start = 6.dp), color = t.setSub, fontSize = 12.sp)
                }
            }
            if (hidden > 0) {
                AuthorPill(onClick = links.authors, description = "$hidden more authors. Open all authors.") {
                    Text("+$hidden", color = t.setSub, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun AuthorPill(onClick: () -> Unit, description: String, content: @Composable () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .heightIn(min = 40.dp)
            .clip(RoundedCornerShape(99.dp))
            .background(t.asOn)
            .semantics(mergeDescendants = true) { contentDescription = description }
            .clickable(onClickLabel = "Open", role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

// ---- ratings --------------------------------------------------------------------------------

@Composable
private fun RatingsCard(o: BooksOverview, links: BooksLinks, onOpen: () -> Unit) {
    val t = pbTokens()
    val avg = o.avgRating
    Row(
        Modifier
            .fillMaxWidth()
            .dashSurface()
            .semantics(mergeDescendants = true) {
                contentDescription = "Ratings: ${o.rated} of ${o.total} rated. Show the books by rating."
            }
            .clickable(onClickLabel = "Show the books by rating", role = Role.Button, onClick = onOpen)
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            CardLabel("Ratings")
            Spacer(Modifier.height(8.dp))
            Text(
                buildAnnotatedString {
                    append("${o.rated} of ${o.total} rated")
                    if (avg != null) {
                        append(" \u00B7 average ")
                        withStyle(SpanStyle(color = t.ink, fontWeight = FontWeight.SemiBold)) { append("%.1f".format(avg)) }
                    }
                },
                color = t.setSub,
                fontSize = 14.sp,
            )
        }
        Spacer(Modifier.width(12.dp))
        StarsRow(if (avg == null) 0 else avg.roundToInt())
        Spacer(Modifier.width(6.dp))
        PbIcon(PbIconName.CaretRight, size = 14.dp, tint = t.setSub)
    }
}

/** Five small stars, the first [filled] in yellow. */
@Composable
private fun StarsRow(filled: Int) {
    val track = trackColor()
    val on = StatsAccent.Yellow
    val star = 18.dp
    val gap = 4.dp
    Canvas(Modifier.size(width = star * 5 + gap * 4, height = star)) {
        val s = star.toPx()
        val path = starShape(s)
        for (i in 0 until 5) {
            val left = i * (s + gap.toPx())
            translate(left, 0f) {
                drawPath(path, if (i < filled) on else track, style = Fill)
            }
        }
    }
}

/** A five-point star that fits a square of [size] px. */
private fun starShape(size: Float): Path {
    val r = size / 2f
    val inner = r * 0.46f
    val path = Path()
    for (i in 0 until 10) {
        val radius = if (i % 2 == 0) r else inner
        val angle = Math.toRadians(-90.0 + i * 36.0)
        val x = r + (radius * cos(angle)).toFloat()
        val y = r + 0.06f * size + (radius * sin(angle)).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}
