package com.paperback.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.ln
import kotlin.math.roundToInt

/*
 * Round 5, as plain functions: how fast you read by hour, weekday, sitting length and genre, the conditions where you
 * read best, a week-by-hour map of when you read, re-reads, how varied your genres are, fiction against non-fiction,
 * the books you dropped, and your streak of days with a note. No Android in here; `today` and the zone are passed in.
 */

private class Acc {
    var words = 0.0
    var seconds = 0L
    val wpm: Int get() = if (seconds <= 0L) 0 else (words / (seconds / 60.0)).roundToInt()
}

// ---- pace -------------------------------------------------------------------------------------

class PacePoint(val label: String, val wpm: Int, val minutes: Int)

/** The spot where you read fastest on one measure, and how far above your own average it is. */
class BestCondition(val measure: String, val label: String, val wpm: Int, val abovePercent: Int)

class PaceStats(
    val overall: Int,
    /** True when most of the words are guessed at an average page (the books have no word count). */
    val estimated: Boolean,
    val byHour: List<PacePoint>,
    val byWeekday: List<PacePoint>,
    val byLength: List<PacePoint>,
    val byGenre: List<PacePoint>,
    val best: List<BestCondition>,
)

private val LENGTH_LABELS = listOf("Under 10 min", "10 to 30 min", "30 to 60 min", "Over an hour")

private fun lengthBucket(seconds: Long): Int {
    val m = seconds / 60.0
    return if (m < 10) 0 else if (m < 30) 1 else if (m < 60) 2 else 3
}

/**
 * Words per minute by when and how you read. Sittings under two minutes and speeds over 1,500 words a minute (page
 * skipping, not reading) are left out, and so is listening. A group needs some reading behind it to be shown.
 */
fun paceStats(rows: List<ReadingSession>, books: List<Book>, zone: ZoneId): PaceStats? {
    val byId = books.associateBy { it.id }
    val usable = rows.filter { it.kind != SessionKind.LISTEN && it.pages > 0 && it.seconds > 0 }
    val sessions = buildSessions(usable).filter { it.seconds >= 120L && it.pages > 0 }
    if (sessions.isEmpty()) return null

    val hour = Array(24) { Acc() }
    val day = Array(7) { Acc() }
    val len = Array(4) { Acc() }
    val genre = HashMap<String, Acc>()
    var allWords = 0.0
    var allSeconds = 0L
    var guessed = 0.0

    for (s in sessions) {
        val b = byId[s.bookId]
        val words = wordsPerPage(b) * s.pages
        val mins = s.seconds / 60.0
        if (words / mins > 1500.0) continue
        val at = Instant.ofEpochMilli(s.startMs).atZone(zone)
        allWords += words
        allSeconds += s.seconds
        if (b == null || !hasWordCount(b)) guessed += words
        hour[at.hour].also { it.words += words; it.seconds += s.seconds }
        day[at.dayOfWeek.value - 1].also { it.words += words; it.seconds += s.seconds }
        len[lengthBucket(s.seconds)].also { it.words += words; it.seconds += s.seconds }
        if (b != null) for (g in broadGenresOf(b)) {
            genre.getOrPut(g) { Acc() }.also { it.words += words; it.seconds += s.seconds }
        }
    }
    if (allSeconds < 600L) return null
    val overall = (allWords / (allSeconds / 60.0)).roundToInt()

    fun point(label: String, a: Acc, minSeconds: Long): PacePoint? =
        if (a.seconds >= minSeconds) PacePoint(label, a.wpm, (a.seconds / 60).toInt()) else null

    val byHour = (0 until 24).mapNotNull { point("%02d:00".format(it), hour[it], 600L) }
    val byWeekday = (0 until 7).mapNotNull { point(StatNames.WEEKDAYS_MON_FIRST[it], day[it], 1200L) }
    val byLength = (0 until 4).mapNotNull { point(LENGTH_LABELS[it], len[it], 600L) }
    val byGenre = genre.entries.mapNotNull { point(it.key, it.value, 1200L) }.sortedByDescending { it.wpm }.take(6)

    val best = ArrayList<BestCondition>()
    fun addBest(measure: String, points: List<PacePoint>) {
        if (points.size < 2) return
        val top = points.maxByOrNull { it.wpm } ?: return
        val above = if (overall > 0) ((top.wpm * 100.0 / overall) - 100.0).roundToInt() else 0
        best.add(BestCondition(measure, top.label, top.wpm, above))
    }
    addBest("Time of day", byHour)
    addBest("Weekday", byWeekday)
    addBest("Sitting length", byLength)
    addBest("Genre", byGenre)

    return PaceStats(overall, guessed > allWords / 2.0, byHour, byWeekday, byLength, byGenre, best)
}

// ---- week by hour -----------------------------------------------------------------------------

class WeekHour(
    /** Minutes read, [weekday 0 = Monday][hour 0..23]. */
    val minutes: Array<DoubleArray>,
    val max: Double,
    val peakDay: Int,
    val peakHour: Int,
)

/** All reading and listening time, each sitting split across the hours it covered. Null when nothing is logged. */
fun weekHour(rows: List<ReadingSession>, zone: ZoneId): WeekHour? {
    val grid = Array(7) { DoubleArray(24) }
    var any = false
    for (r in rows) {
        if (r.seconds <= 0) continue
        any = true
        val end = r.startMs + r.seconds * 1000L
        var t = r.startMs
        var guard = 0
        while (t < end && guard < 200) {
            val at = Instant.ofEpochMilli(t).atZone(zone)
            val nextHour = at.truncatedTo(ChronoUnit.HOURS).plusHours(1).toInstant().toEpochMilli()
            val segEnd = minOf(end, nextHour)
            grid[at.dayOfWeek.value - 1][at.hour] += (segEnd - t) / 60000.0
            t = segEnd
            guard++
        }
    }
    if (!any) return null
    var max = 0.0
    var pd = 0
    var ph = 0
    for (d in 0 until 7) for (h in 0 until 24) if (grid[d][h] > max) { max = grid[d][h]; pd = d; ph = h }
    if (max <= 0.0) return null
    return WeekHour(grid, max, pd, ph)
}

// ---- fiction against non-fiction --------------------------------------------------------------

private val FICTION_GENRES = setOf(
    "Science fiction", "Fantasy", "Mystery & thriller", "Horror", "Romance", "Literary fiction", "Classics",
    "Poetry & drama", "Children & young adult",
)
private val NONFICTION_GENRES = setOf(
    "Biography & memoir", "Self-help & business", "Psychology & philosophy", "Science & technology",
    "Religion & spirituality", "Non-fiction",
)

/** 1 = fiction, 2 = non-fiction, 0 = cannot tell from the tags. A "fiction" tag wins over a broad genre; "Historical" follows it. */
fun fictionKind(b: Book): Int {
    if (b.fiction in 1..2) return b.fiction // your own choice (Edit book) wins over the tags
    val tags = b.tags.map { it.lowercase() }
    val nonTag = tags.any { it.contains("non-fiction") || it.contains("nonfiction") }
    if (nonTag) return 2
    if (tags.any { it.contains("fiction") || it.contains("novel") }) return 1
    val genres = broadGenresOf(b)
    if (genres.any { it in FICTION_GENRES }) return 1
    if (genres.any { it in NONFICTION_GENRES }) return 2
    if ("Historical" in genres) return 2
    return 0
}

class FictionSplit(
    val fictionBooks: Int,
    val nonFictionBooks: Int,
    val unknownBooks: Int,
    val fictionSeconds: Long,
    val nonFictionSeconds: Long,
) {
    val fictionPercent: Int
        get() {
            val total = fictionSeconds + nonFictionSeconds
            return if (total <= 0L) 0 else ((fictionSeconds * 100.0) / total).roundToInt()
        }
}

fun fictionSplit(books: List<Book>, rows: List<ReadingSession>): FictionSplit? {
    if (books.isEmpty()) return null
    val secs = Stats.secondsByBook(rows)
    var fb = 0
    var nb = 0
    var ub = 0
    var fs = 0L
    var ns = 0L
    for (b in books) {
        when (fictionKind(b)) {
            1 -> { fb++; fs += secs[b.id] ?: 0L }
            2 -> { nb++; ns += secs[b.id] ?: 0L }
            else -> ub++
        }
    }
    if (fb + nb == 0) return null
    return FictionSplit(fb, nb, ub, fs, ns)
}

// ---- genre explorer ---------------------------------------------------------------------------

class GenreExplorer(
    /** Broad genres you have read or are reading. */
    val genresRead: Int,
    /** 0 to 100: how evenly your reading time is spread over those genres (100 = perfectly even). */
    val variety: Int,
    val topGenre: String?,
    /** Genres of books you own that you have not touched in any book, with how many books wait. */
    val untouched: List<Bar>,
)

fun genreExplorer(books: List<Book>, rows: List<ReadingSession>): GenreExplorer? {
    val byId = books.associateBy { it.id }
    val secs = HashMap<String, Long>()
    for (r in rows) {
        if (r.seconds <= 0) continue
        val b = byId[r.bookId] ?: continue
        val gs = broadGenresOf(b).filter { it != "Other" }
        if (gs.isEmpty()) continue
        val share = r.seconds.toLong() / gs.size
        for (g in gs) secs[g] = (secs[g] ?: 0L) + share
    }
    val touchedByBooks = books.filter { it.finished || it.isReading }.flatMap { broadGenresOf(it) }.filter { it != "Other" }.toSet()
    val touched = touchedByBooks + secs.keys

    val waiting = books.filter { !it.finished && !it.isReading && it.status == BookStatus.NORMAL }
        .flatMap { broadGenresOf(it) }
        .filter { it != "Other" && it !in touched }
        .groupingBy { it }.eachCount()
    val untouched = waiting.entries.sortedByDescending { it.value }.take(6).map {
        Bar(it.key, it.value.toDouble(), "${it.value} ${if (it.value == 1) "book" else "books"}")
    }

    if (touched.isEmpty() && untouched.isEmpty()) return null
    val total = secs.values.sum().toDouble()
    val variety = if (secs.size <= 1 || total <= 0.0) 0 else {
        var h = 0.0
        for (v in secs.values) { val p = v / total; if (p > 0) h -= p * ln(p) }
        ((h / ln(secs.size.toDouble())) * 100).roundToInt().coerceIn(0, 100)
    }
    return GenreExplorer(touched.size, variety, secs.entries.maxByOrNull { it.value }?.key, untouched)
}

// ---- re-reads ---------------------------------------------------------------------------------

class ReReadRow(val book: Book?, val title: String, val times: Int, val firstStars: Double, val lastStars: Double)

class ReReadFigures(val booksReread: Int, val totalReadings: Int, val rows: List<ReReadRow>)

/** Books you have finished more than once (a re-read is a second finished reading), with how the rating moved. */
fun reReadFigures(readings: List<Reading>, books: List<Book>): ReReadFigures? {
    if (readings.isEmpty()) return null
    val byId = books.associateBy { it.id }
    val groups = readings.groupBy { it.bookId }.filter { it.value.size >= 2 }
    if (groups.isEmpty()) return null
    val rows = groups.entries.map { (id, list) ->
        val ordered = list.sortedBy { it.finishedAt }
        val b = byId[id]
        ReReadRow(b, b?.title ?: "Removed book", ordered.size, ordered.first().rating10 / 2.0, ordered.last().rating10 / 2.0)
    }.sortedByDescending { it.times }
    return ReReadFigures(rows.size, readings.size, rows)
}

// ---- dropped and paused -----------------------------------------------------------------------

class DroppedFigures(
    val dropped: Int,
    val paused: Int,
    /** Dropped out of finished plus dropped. */
    val dropRatePercent: Int,
    val avgDroppedAt: Int?,
    val byGenre: List<Bar>,
    val droppedBooks: List<Book>,
    val pausedBooks: List<Book>,
)

fun droppedFigures(books: List<Book>): DroppedFigures? {
    val dropped = books.filter { it.status == BookStatus.DROPPED && !it.finished }
    val paused = books.filter { it.status == BookStatus.PAUSED && !it.finished }
    if (dropped.isEmpty() && paused.isEmpty()) return null
    val finished = books.count { it.finished }
    val rate = if (finished + dropped.size == 0) 0 else ((dropped.size * 100.0) / (finished + dropped.size)).roundToInt()
    val genres = dropped.flatMap { b -> broadGenresOf(b).ifEmpty { listOf("Other") } }
        .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5)
    val max = (genres.firstOrNull()?.value ?: 1).toDouble()
    return DroppedFigures(
        dropped = dropped.size,
        paused = paused.size,
        dropRatePercent = rate,
        avgDroppedAt = if (dropped.isEmpty()) null else dropped.sumOf { it.droppedPct } / dropped.size,
        byGenre = genres.map { Bar(it.key, it.value / max, it.value.toString()) },
        droppedBooks = dropped.sortedByDescending { it.statusAt },
        pausedBooks = paused.sortedByDescending { it.statusAt },
    )
}

// ---- notes streak -----------------------------------------------------------------------------

class NoteStreak(val current: Int, val best: Int, val daysWithNotes: Int)

/** Days in a row with at least one highlight or note. The current streak may end yesterday (today can still be done). */
fun noteStreak(highlights: List<Highlight>, today: LocalDate, zone: ZoneId): NoteStreak? {
    if (highlights.isEmpty()) return null
    val days = highlights.map { dateOf(it.createdAt, zone) }.toSortedSet()
    var best = 0
    var run = 0
    var prev: LocalDate? = null
    for (d in days) {
        run = if (prev != null && ChronoUnit.DAYS.between(prev, d) == 1L) run + 1 else 1
        if (run > best) best = run
        prev = d
    }
    var cur = 0
    var d = if (today in days) today else today.minusDays(1)
    while (d in days) { cur++; d = d.minusDays(1) }
    return NoteStreak(cur, best, days.size)
}
