package com.paperback.app.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.SavedWord
import com.paperback.app.ui.DictState
import com.paperback.app.ui.DictionaryResult
import com.paperback.app.ui.PbDialog
import com.paperback.app.ui.rememberDefinition

/** What the reader is looking up: the word, the sentence it is in, and whether it is already saved. */
class DictRequest(val word: String, val context: String, val saved: Boolean)

/** The dictionary over the page: meanings (online), Save word, and the old "other app" route as a fallback. */
@Composable
fun ReaderDictionaryDialog(
    request: DictRequest,
    bookLang: String,
    themeIndex: Int,
    onSave: (SavedWord) -> Unit,
    onOtherApp: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = readerColors(themeIndex)
    val state = rememberDefinition(request.word, bookLang)
    var saved by remember(request) { mutableStateOf(request.saved) }
    PbDialog(title = "Dictionary", onDismiss = onDismiss, container = c.card, ink = c.ink) {
        Box(Modifier.fillMaxWidth().height(260.dp).verticalScroll(rememberScrollState())) {
            DictionaryResult(request.word, state, c.ink, c.ink.copy(alpha = 0.6f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).background(c.ink.copy(alpha = 0.08f)).clickable(onClick = onOtherApp),
                contentAlignment = androidx.compose.ui.Alignment.Center,
            ) { Text("Other app", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            val found = state as? DictState.Found
            Box(
                Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).background(c.ink)
                    .clickable(enabled = found != null && !saved) {
                        if (found != null) {
                            onSave(SavedWord(found.entry.word, System.currentTimeMillis(), "", found.entry.short, found.entry.lang, request.context))
                            saved = true
                        }
                    },
                contentAlignment = androidx.compose.ui.Alignment.Center,
            ) {
                Text(if (saved) "Saved" else "Save word", color = c.card, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
