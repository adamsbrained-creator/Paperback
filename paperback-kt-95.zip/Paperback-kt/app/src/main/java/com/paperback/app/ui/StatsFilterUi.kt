package com.paperback.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.FilterOptions
import com.paperback.app.data.StatsFilter
import com.paperback.app.ui.theme.pbTokens

/**
 * The Filter on the Stats tab: narrow every page to some of your books by genre, format, language or collection.
 * Within a group any choice counts; across groups a book must match each group you picked.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StatsFilterDialog(
    options: FilterOptions,
    filter: StatsFilter,
    shown: Int,
    total: Int,
    onChange: (StatsFilter) -> Unit,
    onDismiss: () -> Unit,
) {
    val t = pbTokens()

    @Composable
    fun Group(title: String, kind: String, choices: List<Pair<String, String>>) {
        if (choices.isEmpty()) return
        Text(title, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            choices.forEach { (value, label) ->
                TogglePill(label, filter.has(kind, value)) { onChange(filter.toggled(kind, value)) }
            }
        }
    }

    PbDialog(title = "Filter Stats", onDismiss = onDismiss) {
        Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
            Text(
                if (filter.isEmpty) "Every page shows all $total books." else "Every page shows $shown of $total books.",
                color = t.setSub, fontSize = 13.sp,
            )
            Group("Genre", "g", options.genres.map { it to it })
            Group("Format", "f", options.formats.map { it to it })
            Group("Language", "l", options.languages.map { it to it })
            Group("Collection", "c", options.collections)
            Spacer(Modifier.height(8.dp))
            Text(
                "Goals and streaks compare the time in these books with your normal goal.",
                color = t.setSub, fontSize = 12.sp,
            )
        }
        PbDialogButtons(
            confirm = "Done",
            onConfirm = onDismiss,
            onCancel = { if (filter.isEmpty) onDismiss() else onChange(StatsFilter()) },
            cancel = if (filter.isEmpty) "Close" else "Clear",
        )
    }
}
