package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.AuthorFigures
import com.paperback.app.data.Book
import com.paperback.app.data.Stats
import com.paperback.app.data.commas
import com.paperback.app.ui.theme.pbTokens
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val AUTHOR_DATE: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())

private fun authorDay(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(AUTHOR_DATE)

/** The top of an author's page: books and finished, time, pages and rating, then how you read them. */
@Composable
fun AuthorStatsCard(f: AuthorFigures, onOpenBook: (Book) -> Unit) {
    val t = pbTokens()
    Column(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(24.dp)).background(t.card).padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(Modifier.fillMaxWidth()) {
            AuthorFigure("${f.finished} of ${f.books}", "finished", Modifier.weight(1f))
            AuthorFigure(if (f.seconds > 0) Stats.duration(f.seconds) else "\u2013", "read", Modifier.weight(1f))
            AuthorFigure(if (f.pages > 0) commas(f.pages) else "\u2013", "pages", Modifier.weight(1f))
            AuthorFigure(f.avgStars?.let { "%.1f".format(it) + "\u2605" } ?: "\u2013", "rating", Modifier.weight(1f))
        }
        if (f.seconds > 0) {
            Spacer(Modifier.height(8.dp))
            AuthorLine("Reading days", f.readingDays.toString())
            AuthorLine("Share of all your reading", "${f.sharePercent}%")
            if (f.wpm > 0) AuthorLine("Speed", "${f.wpm} words a minute")
            if (f.firstMs > 0L) AuthorLine("First read", authorDay(f.firstMs))
            if (f.lastMs > 0L) AuthorLine("Last read", authorDay(f.lastMs))
        }
        f.favorite?.let { b ->
            Row(Modifier.fillMaxWidth().clickable { onOpenBook(b) }.padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Favorite book", color = t.setSub, fontSize = 13.sp)
                Text(b.title, color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 12.dp), textAlign = TextAlign.End)
            }
        }
    }
}

@Composable
private fun AuthorFigure(value: String, label: String, modifier: Modifier) {
    val t = pbTokens()
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(label, color = t.setSub, fontSize = 11.sp)
    }
}

@Composable
private fun AuthorLine(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = t.setSub, fontSize = 13.sp)
        Text(value, color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}
