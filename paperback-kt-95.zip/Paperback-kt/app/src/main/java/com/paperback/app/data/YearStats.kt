package com.paperback.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/*
 * The year in review, as plain functions. One year of reading: totals, how it compares with the year before, what you
 * read (genres, authors, languages), when you read, your streak and busiest day, fastest and slowest finish, longest and
 * shortest book, the book you marked up most, and the books of the year. Listening counts in time but not in words.
 */

private const val READING_DAY_SECONDS = 60L

/** The years that have reading or a finished book, newest first. */
fun yearsWithReading(books: List<Book>, sessions: List<ReadingSession>, zone: ZoneId): List<Int> {
    val years = HashSet<Int>()
    for (s in sessions) years.add(dateOf(s.startMs, zone).year)
    for (b in books) if (b.finished) years.add(finishedDate(b, zone).year)
    return years.sortedDescending()
}

class YearReview(
    val year: Int,
    val seconds: Long,
    val pages: Int,
    val booksFinished: Int,
    val readingDays: Int,
    val sessions: Int,
    val words: Long,
    val listenedSeconds: Long,
    /** The year before, whole (time, pages, books, days), or null when there was no reading in it. */
    val previous: YearTotals?,
    val topGenres: List<Bar>,
    val topAuthors: List<Bar>,
    val topLanguages: List<Bar>,
    val longestStreak: Int,
    val streakStart: LocalDate?,
    val busiestDay: Pair<LocalDate, Long>?,
    /** The hour you most often start reading, 0 to 23. */
    val favoriteHour: Int?,
    val booksPerMonth: IntArray,
    val secondsPerMonth: LongArray,
    val fastest: FinishRow?,
    val slowest: FinishRow?,
    val longestBook: Book?,
    val shortestBook: Book?,
    val mostMarkedUp: Pair<Book?, Int>?,
    val avgStars: Double?,
    val fiveStars: Int,
    /** Books finished this year, in the order you finished them. */
    val finished: List<Book>,
)

private fun totalsFor(year: Int, books: List<Book>, rows: List<ReadingSession>, zone: ZoneId): YearTotals {
    val inYear = rows.filter { dateOf(it.startMs, zone).year == year }
    val byDay = Stats.secondsByDay(inYear, zone)
    return YearTotals(
        year = year,
        seconds = inYear.sumOf { it.seconds.toLong() },
        pages = inYear.sumOf { it.pages },
        books = books.count { it.finished && finishedDate(it, zone).year == year },
        days = byDay.count { it.value >= READING_DAY_SECONDS },
    )
}

fun yearReview(year: Int, books: List<Book>, sessions: List<ReadingSession>, highlights: List<Highlight>, zone: ZoneId): YearReview? {
    val rows = sessions.filter { dateOf(it.startMs, zone).year == year }
    val finished = books.filter { it.finished && finishedDate(it, zone).year == year }.sortedBy { finishedAtMs(it) }
    if (rows.isEmpty() && finished.isEmpty()) return null

    val byId = books.associateBy { it.id }
    val byDay = Stats.secondsByDay(rows, zone)
    val readDays = byDay.filterValues { it >= READING_DAY_SECONDS }.keys.sorted()

    // longest run of reading days inside the year
    var best = 0
    var bestStart: LocalDate? = null
    var run = 0
    var runStart: LocalDate? = null
    var prev: LocalDate? = null
    for (d in readDays) {
        if (prev != null && ChronoUnit.DAYS.between(prev, d) == 1L) {
            run++
        } else {
            run = 1
            runStart = d
        }
        if (run > best) { best = run; bestStart = runStart }
        prev = d
    }

    // the hour you most often begin a sitting
    val hours = IntArray(24)
    for (r in rows) if (r.seconds >= 60) hours[Instant.ofEpochMilli(r.startMs).atZone(zone).hour]++
    val favHour = if (hours.all { it == 0 }) null else hours.indices.maxByOrNull { hours[it] }

    val perMonthSeconds = LongArray(12)
    for (r in rows) perMonthSeconds[dateOf(r.startMs, zone).monthValue - 1] += r.seconds.toLong()

    val finish = finishFigures(finished, sessions, zone)
    val withPages = finished.filter { it.pageCount > 0 }

    val marks = highlights.filter { dateOf(it.createdAt, zone).year == year }
        .groupingBy { it.bookId }.eachCount().entries.maxByOrNull { it.value }
        ?.let { byId[it.key] to it.value }

    val stars = finished.map { ratingStars(it) }.filter { it > 0 }
    val prevTotals = totalsFor(year - 1, books, sessions, zone).takeIf { it.seconds > 0 || it.books > 0 }

    return YearReview(
        year = year,
        seconds = rows.sumOf { it.seconds.toLong() },
        pages = rows.sumOf { it.pages },
        booksFinished = finished.size,
        readingDays = readDays.size,
        sessions = buildSessions(rows).size,
        words = wordsIn(rows.filter { it.kind != SessionKind.LISTEN }, byId),
        listenedSeconds = rows.filter { it.kind == SessionKind.LISTEN }.sumOf { it.seconds.toLong() },
        previous = prevTotals,
        topGenres = timeBars(rows, books, 5, ::broadGenresOf),
        topAuthors = timeBars(rows, books, 5, ::authorsOf),
        topLanguages = timeBars(rows, books, 3, ::languageOf),
        longestStreak = best,
        streakStart = bestStart,
        busiestDay = byDay.entries.maxByOrNull { it.value }?.takeIf { it.value > 0 }?.let { it.key to it.value },
        favoriteHour = favHour,
        booksPerMonth = booksPerMonth(books, year, zone),
        secondsPerMonth = perMonthSeconds,
        fastest = finish?.fastest?.firstOrNull(),
        slowest = finish?.slowest?.firstOrNull(),
        longestBook = withPages.maxByOrNull { it.pageCount },
        shortestBook = withPages.minByOrNull { it.pageCount },
        mostMarkedUp = marks,
        avgStars = if (stars.isEmpty()) null else stars.average(),
        fiveStars = stars.count { it == 5 },
        finished = finished,
    )
}

/** "Change against the year before" as text, or null when there is nothing to compare. */
fun yearChange(now: Long, before: Long?): String? {
    if (before == null || before <= 0L) return null
    val p = Math.round((now - before) * 100.0 / before).toInt()
    return if (p >= 0) "+$p% on last year" else "$p% on last year"
}

/** A short plain-text summary of the year, for the share sheet. */
fun yearShareText(r: YearReview): String {
    val sb = StringBuilder()
    sb.append("My ${r.year} in reading\n")
    sb.append("${Stats.duration(r.seconds)} read on ${r.readingDays} days\n")
    sb.append("${r.booksFinished} ${if (r.booksFinished == 1) "book" else "books"} finished, ${commas(r.pages)} pages\n")
    if (r.longestStreak > 1) sb.append("Longest streak: ${r.longestStreak} days\n")
    r.topGenres.firstOrNull()?.let { sb.append("Most read genre: ${it.label}\n") }
    r.topAuthors.firstOrNull()?.let { sb.append("Most read author: ${it.label}\n") }
    r.longestBook?.let { sb.append("Longest book: ${it.title} (${it.pageCount} pages)\n") }
    return sb.toString().trimEnd()
}
