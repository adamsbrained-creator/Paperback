package com.paperback.app.widget

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.paperback.app.MainActivity
import com.paperback.app.data.Stats
import com.paperback.app.data.widgetFigures
import com.paperback.app.reminder.Reminders
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

/**
 * The quick-settings tile: today's reading against the daily goal. It lights up once the goal is met. Pull down the
 * quick settings, edit the tiles and drag Paperback in; a tap opens Paperback.
 */
class GoalTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        val app = applicationContext
        Reminders.graphOf(app).appScope.launch {
            val figures = try {
                val graph = Reminders.graphOf(app)
                widgetFigures(graph.db.allSessions(), graph.prefs.goals.value.minutesPerDay, LocalDate.now(), ZoneId.systemDefault())
            } catch (e: Exception) {
                null
            }
            Handler(Looper.getMainLooper()).post {
                val tile = qsTile ?: return@post
                tile.label = "Paperback"
                if (figures != null) {
                    val streak = if (figures.streak == 1) "1-day streak" else "${figures.streak}-day streak"
                    val text = "${Stats.duration(figures.todaySeconds)} of ${figures.goalMinutes}m \u00B7 $streak"
                    if (Build.VERSION.SDK_INT >= 29) tile.subtitle = text
                    tile.state = if (figures.percent >= 100) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
                } else {
                    tile.state = Tile.STATE_INACTIVE
                }
                tile.updateTile()
            }
        }
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
