package com.paperback.app.data

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import kotlin.math.roundToInt

/*
 * Round 10, as plain functions: records your last session broke, and the warm-up curve (pace in the first five minutes
 * of a sitting against the rest). No Android in here.
 */

// ---- records broken by the last session (D7) --------------------------------------------------

class SessionRecords(val sessionId: Long, val lines: List<String>)

private const val RECORD_WINDOW_MS = 3L * 60 * 60 * 1000

private fun mondayOfDay(d: LocalDate): LocalDate = d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

/**
 * What the last reading session beat: your longest session, best day, most pages in a day, best week or longest streak.
 * Null when there is none, when the session ended more than three hours ago, or while there is too little history to
 * call anything a record (ten earlier entries).
 */
fun sessionRecords(rows: List<ReadingSession>, zone: ZoneId, nowMs: Long): SessionRecords? {
    val read = rows.filter { it.kind != SessionKind.LISTEN && it.seconds > 0 }
    val last = read.maxByOrNull { it.startMs } ?: return null
    if (nowMs - (last.startMs + last.seconds * 1000L) > RECORD_WINDOW_MS) return null
    val merged = buildSessions(read).maxByOrNull { it.startMs } ?: return null
    val before = rows.filter { it.startMs < merged.startMs }
    if (before.size < 10) return null

    val lines = ArrayList<String>()
    val day = Instant.ofEpochMilli(last.startMs).atZone(zone).toLocalDate()
    val byNow = Stats.secondsByDay(rows, zone)
    val byBefore = Stats.secondsByDay(before, zone)

    val longestBefore = buildSessions(before.filter { it.kind != SessionKind.LISTEN }).maxOfOrNull { it.seconds } ?: 0L
    if (merged.seconds >= 600L && merged.seconds > longestBefore) lines.add("Longest session yet: ${Stats.duration(merged.seconds)}")

    val dayNow = byNow[day] ?: 0L
    val bestDayBefore = byBefore.values.maxOrNull() ?: 0L
    if (dayNow >= 600L && dayNow > bestDayBefore) lines.add("Best reading day yet: ${Stats.duration(dayNow)}")

    fun pagesPerDay(list: List<ReadingSession>): Map<LocalDate, Int> =
        list.groupBy { Instant.ofEpochMilli(it.startMs).atZone(zone).toLocalDate() }.mapValues { (_, v) -> v.sumOf { it.pages } }
    val pagesNow = pagesPerDay(rows)[day] ?: 0
    val pagesBefore = pagesPerDay(before).values.maxOrNull() ?: 0
    if (pagesNow >= 10 && pagesNow > pagesBefore) lines.add("Most pages in a day yet: ${commas(pagesNow)}")

    fun weekTotals(m: Map<LocalDate, Long>): Map<LocalDate, Long> =
        m.entries.groupBy({ mondayOfDay(it.key) }, { it.value }).mapValues { (_, v) -> v.sum() }
    val weekNow = weekTotals(byNow)[mondayOfDay(day)] ?: 0L
    val weekBefore = weekTotals(byBefore).values.maxOrNull() ?: 0L
    val readDaysThisWeek = (0L..6L).count { (byNow[mondayOfDay(day).plusDays(it)] ?: 0L) >= 60L }
    if (readDaysThisWeek >= 3 && weekNow > weekBefore) lines.add("Best week yet: ${Stats.duration(weekNow)} so far")

    val streakNow = Stats.currentStreak(byNow, day)
    if (streakNow >= 3 && streakNow > Stats.longestStreak(byBefore)) lines.add("Longest reading streak yet: $streakNow days")

    return if (lines.isEmpty()) null else SessionRecords(last.id, lines.take(3))
}

// ---- warm-up curve (C6) -----------------------------------------------------------------------

class WarmUp(val earlyWpm: Int, val laterWpm: Int, val sessions: Int, val changePercent: Int)

/**
 * Words per minute in the first five minutes of a sitting against the rest of it. Only sittings of ten minutes or more
 * that saved their early timing count (from this update on), and five of them are needed.
 */
fun warmUp(rows: List<ReadingSession>, books: List<Book>): WarmUp? {
    val byId = books.associateBy { it.id }
    var eWords = 0.0
    var eSecs = 0L
    var lWords = 0.0
    var lSecs = 0L
    var n = 0
    for (s in rows) {
        if (s.kind != SessionKind.READ || s.earlySeconds < 240 || s.seconds < 600 || s.pages <= s.earlyPages) continue
        val wpp = wordsPerPage(byId[s.bookId])
        val laterSecs = (s.seconds - s.earlySeconds).toLong()
        val laterWords = (s.pages - s.earlyPages) * wpp
        val earlyWords = s.earlyPages * wpp
        if (laterWords / (laterSecs / 60.0) > 1500.0 || earlyWords / (s.earlySeconds / 60.0) > 1500.0) continue
        eWords += earlyWords
        eSecs += s.earlySeconds
        lWords += laterWords
        lSecs += laterSecs
        n++
    }
    if (n < 5 || eSecs <= 0L || lSecs <= 0L) return null
    val early = (eWords / (eSecs / 60.0)).roundToInt()
    val later = (lWords / (lSecs / 60.0)).roundToInt()
    if (early <= 0 || later <= 0) return null
    return WarmUp(early, later, n, (((later * 100.0) / early) - 100.0).roundToInt())
}
