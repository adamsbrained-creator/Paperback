package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId

/** The numbers on the home-screen widget: today against the daily goal, the streak and the week. */
class WidgetFigures(
    val todaySeconds: Long,
    val goalMinutes: Int,
    val streak: Int,
    val weekSeconds: Long,
) {
    /** Today as a percent of the goal, 0 to 100. */
    val percent: Int get() = if (goalMinutes <= 0) 0 else ((todaySeconds * 100) / (goalMinutes * 60L)).toInt().coerceIn(0, 100)
}

/**
 * Same sessions the Stats tab uses (a stretch you logged twice is counted once), then today, the streak and this week
 * (Monday to today).
 */
fun widgetFigures(raw: List<ReadingSession>, goalMinutes: Int, today: LocalDate, zone: ZoneId): WidgetFigures {
    val spans = raw.map {
        com.paperback.app.catalog.Coverage.Span(it.id, it.bookId, it.startMs, it.startMs + it.seconds * 1000L, it.manual, it.fromPos, it.toPos)
    }
    val covered = com.paperback.app.catalog.Coverage.covered(spans)
    val rows = raw.filter { it.id !in covered }
    val byDay = Stats.secondsByDay(rows, zone)
    val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    var week = 0L
    var d = monday
    while (!d.isAfter(today)) {
        week += byDay[d] ?: 0L
        d = d.plusDays(1)
    }
    return WidgetFigures(byDay[today] ?: 0L, goalMinutes, Stats.currentStreak(byDay, today), week)
}
