package com.paperback.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.paperback.app.MainActivity
import com.paperback.app.R
import com.paperback.app.data.Stats
import com.paperback.app.data.widgetFigures
import com.paperback.app.reminder.Reminders
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

/**
 * The home-screen widget: today's reading against your daily goal, with the streak and the week. Android asks it to
 * refresh every half hour; Paperback also refreshes it each time a reading session is saved. Tapping it opens Paperback.
 */
class GoalWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        val app = context.applicationContext
        Reminders.graphOf(app).appScope.launch {
            try {
                draw(app, manager, appWidgetIds)
            } catch (e: Exception) {
                // a widget that fails to refresh keeps showing what it had
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        /** Redraws every placed widget (nothing happens when there is none). Safe to call from anywhere. */
        fun refreshAll(context: Context) {
            val app = context.applicationContext
            val manager = AppWidgetManager.getInstance(app)
            val ids = manager.getAppWidgetIds(ComponentName(app, GoalWidgetProvider::class.java))
            if (ids.isEmpty()) return
            Reminders.graphOf(app).appScope.launch {
                try {
                    draw(app, manager, ids)
                } catch (e: Exception) {
                    // keep what is shown
                }
            }
        }

        /** Reads the database, so it runs off the main thread. */
        private fun draw(app: Context, manager: AppWidgetManager, ids: IntArray) {
            val graph = Reminders.graphOf(app)
            val goal = graph.prefs.goals.value.minutesPerDay
            val f = widgetFigures(graph.db.allSessions(), goal, LocalDate.now(), ZoneId.systemDefault())

            val views = RemoteViews(app.packageName, R.layout.widget_goal)
            views.setTextViewText(R.id.widget_value, Stats.duration(f.todaySeconds))
            views.setProgressBar(R.id.widget_progress, 100, f.percent, false)
            val streak = if (f.streak == 1) "1-day streak" else "${f.streak}-day streak"
            views.setTextViewText(R.id.widget_note, "of $goal min \u00B7 $streak")
            views.setTextViewText(R.id.widget_week, "This week ${Stats.duration(f.weekSeconds)}")
            val open = PendingIntent.getActivity(
                app, 0, Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            views.setOnClickPendingIntent(R.id.widget_root, open)
            manager.updateAppWidget(ids, views)
        }
    }
}
