package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

/*
 * Shared building blocks, so every page and dialog is made of the same few pieces:
 * the pill button (PbButton), rounded cards, the filled text field, the dialog, the on/off dot.
 * Nothing here uses Material's stock look.
 */

val DangerRed = Color(0xFFE5534B)

/** Small caps label above a block of content, same style as the Settings group labels. */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(start = 4.dp, end = 4.dp, top = 24.dp, bottom = 10.dp),
        color = pbTokens().setSub,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
    )
}

/** A rounded card in the card colour (like a Settings group). */
@Composable
fun PbCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(pbTokens().card),
        content = content,
    )
}

/** The thin line between rows of a card. [startInset] lines it up with the text after an icon or cover. */
@Composable
fun CardDivider(startInset: androidx.compose.ui.unit.Dp = 16.dp) {
    Box(Modifier.padding(start = startInset, end = 16.dp).fillMaxWidth().height(1.dp).background(pbTokens().rule))
}

/** "Added  Oct 22, 2026" style line inside a card. */
@Composable
fun InfoRow(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.setSub, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(value, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

/** A small rounded button for secondary actions (Rename, Share). [danger] turns the text red. */
@Composable
fun ActionPill(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, danger: Boolean = false) {
    val t = pbTokens()
    Box(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(t.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (danger) DangerRed else t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

/** The rounded switch between a few options (the one on App style, usable anywhere). */
@Composable
fun <T> PbSegmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    val t = pbTokens()
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(t.asTrack)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        options.forEach { (value, label) ->
            val on = value == selected
            val shape = RoundedCornerShape(18.dp)
            Box(
                Modifier
                    .weight(1f)
                    .height(38.dp)
                    .then(if (on) Modifier.shadow(1.dp, shape) else Modifier)
                    .clip(shape)
                    .background(if (on) t.asOn else Color.Transparent)
                    .clickable { onSelect(value) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (on) t.asOnInk else t.setSub,
                    fontSize = 14.sp,
                    fontWeight = if (on) FontWeight.Medium else FontWeight.Normal,
                    maxLines = 1,
                )
            }
        }
    }
}

/** A round on/off mark for lists where you pick several things: empty ring, or coral with a tick. */
@Composable
fun SelectDot(selected: Boolean) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    Box(
        Modifier
            .size(26.dp)
            .clip(CircleShape)
            .background(if (selected) primary else Color.Transparent)
            .border(2.dp, if (selected) primary else t.setSub.copy(alpha = 0.55f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Canvas(Modifier.size(14.dp)) {
                val w = size.width
                val h = size.height
                val tick = Path().apply {
                    moveTo(w * 0.10f, h * 0.55f)
                    lineTo(w * 0.40f, h * 0.82f)
                    lineTo(w * 0.90f, h * 0.20f)
                }
                drawPath(tick, Color.White, style = Stroke(width = w * 0.17f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

/**
 * The app's text field: filled with the card colour, no outline, rounded. [container] and [ink] let the reader
 * show it in the page's own theme (light / sepia / dark).
 */
@Composable
fun PbField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    leading: PbIconName? = null,
    onClear: (() -> Unit)? = null,
    singleLine: Boolean = true,
    minLines: Int = 1,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    container: Color? = null,
    ink: Color? = null,
    visualTransformation: VisualTransformation = VisualTransformation.None,
) {
    val t = pbTokens()
    val bg = container ?: t.card
    val fg = ink ?: t.ink
    val hint = fg.copy(alpha = 0.55f)
    TextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        placeholder = { Text(placeholder, color = hint) },
        leadingIcon = if (leading != null) {
            { PbIcon(leading, size = 20.dp, tint = hint) }
        } else null,
        trailingIcon = if (onClear != null && value.isNotEmpty()) {
            {
                Box(
                    Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClear),
                    contentAlignment = Alignment.Center,
                ) { PbIcon(PbIconName.Close, size = 16.dp, tint = hint, strokeWidth = 2.2f) }
            }
        } else null,
        singleLine = singleLine,
        minLines = minLines,
        shape = RoundedCornerShape(if (singleLine) 28.dp else 22.dp),
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        visualTransformation = visualTransformation,
        colors = TextFieldDefaults.colors(
            focusedContainerColor = bg,
            unfocusedContainerColor = bg,
            disabledContainerColor = bg,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            cursorColor = MaterialTheme.colorScheme.primary,
            focusedTextColor = fg,
            unfocusedTextColor = fg,
            focusedPlaceholderColor = hint,
            unfocusedPlaceholderColor = hint,
        ),
    )
}

/**
 * The app's dialog: a rounded card on the dimmed page, serif title, your content, then buttons.
 * Tap outside to dismiss. [container] and [ink] recolour it for the reader.
 */
@Composable
fun PbDialog(
    title: String,
    onDismiss: () -> Unit,
    container: Color? = null,
    ink: Color? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val t = pbTokens()
    val bg = container ?: t.menuBg
    val fg = ink ?: t.ink
    val none = remember { MutableInteractionSource() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier
                .fillMaxSize()
                .clickable(indication = null, interactionSource = none, onClick = onDismiss)
                .padding(horizontal = 24.dp, vertical = 32.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .widthIn(max = 440.dp)
                    .fillMaxWidth()
                    .shadow(24.dp, RoundedCornerShape(32.dp))
                    .clip(RoundedCornerShape(32.dp))
                    .background(bg)
                    // swallow taps on the card so they don't count as "outside"
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
                    .padding(horizontal = 22.dp, vertical = 24.dp),
            ) {
                Text(title, color = fg, fontFamily = PbSerif, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(16.dp))
                content()
            }
        }
    }
}

/** Cancel + confirm side by side at the bottom of a dialog. */
@Composable
fun PbDialogButtons(
    confirm: String,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    cancel: String = "Cancel",
    danger: Boolean = false,
    enabled: Boolean = true,
    container: Color? = null,
    ink: Color? = null,
) {
    val t = pbTokens()
    val page = container ?: t.menuBg
    val fg = ink ?: t.ink
    Row(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier
                .weight(1f)
                .height(50.dp)
                .clip(RoundedCornerShape(25.dp))
                .background(fg.copy(alpha = 0.08f))
                .clickable(onClick = onCancel),
            contentAlignment = Alignment.Center,
        ) { Text(cancel, color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        Box(
            Modifier
                .weight(1f)
                .height(50.dp)
                .clip(RoundedCornerShape(25.dp))
                .background(if (danger) DangerRed else fg)
                .alpha(if (enabled) 1f else 0.4f)
                .clickable(enabled = enabled, onClick = onConfirm),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                confirm,
                color = if (danger) Color.White else page,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

/** "Are you sure?" with a message. [danger] makes the confirm button red. */
@Composable
fun PbConfirmDialog(
    title: String,
    message: String,
    confirm: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    danger: Boolean = true,
) {
    PbDialog(title, onDismiss) {
        Text(message, color = pbTokens().setSub, fontSize = 15.sp, lineHeight = 22.sp)
        PbDialogButtons(confirm = confirm, onConfirm = onConfirm, onCancel = onDismiss, danger = danger)
    }
}

/**
 * A small text action ("Remove") with a tap target of at least 44 dp: the text is small but your finger isn't.
 */
@Composable
fun QuietAction(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = pbTokens().setSub,
    fontSize: androidx.compose.ui.unit.TextUnit = 12.sp,
) {
    Box(
        modifier
            .defaultMinSize(minWidth = 44.dp, minHeight = 44.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = color, fontSize = fontSize, fontWeight = FontWeight.Medium)
    }
}
