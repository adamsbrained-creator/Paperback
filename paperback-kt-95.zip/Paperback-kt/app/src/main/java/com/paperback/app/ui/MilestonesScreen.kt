package com.paperback.app.ui

import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.Highlight
import com.paperback.app.data.Milestone
import com.paperback.app.data.MilestoneIcon
import com.paperback.app.data.MilestoneId
import com.paperback.app.data.MilestoneInput
import com.paperback.app.data.MilestoneTarget
import com.paperback.app.data.NextUp
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.SavedWord
import com.paperback.app.data.TimelineEvent
import com.paperback.app.data.TimelineKind
import com.paperback.app.data.buildMilestones
import com.paperback.app.data.buildTimeline
import com.paperback.app.data.commas
import com.paperback.app.data.etaText
import com.paperback.app.data.goalText
import com.paperback.app.data.monthHeading
import com.paperback.app.data.pickNextUp
import com.paperback.app.data.shortDateLabel
import com.paperback.app.data.shortNum
import com.paperback.app.data.tiersUnlocked
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.LocalPbDark
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.max

/**
 * Where a tap on a card, a tier or a timeline entry goes. The Stats screen builds this from the app's navigation,
 * so Milestones itself knows nothing about routes.
 */
class MilestoneLinks(
    /** A book's page. */
    val book: (bookId: String) -> Unit,
    /** The notes of one book, or every note and highlight when null. */
    val notes: (bookId: String?) -> Unit,
    /** Stats -> History, on that day, or just the page when null. */
    val history: (day: LocalDate?) -> Unit,
    /** The finished books. */
    val finished: () -> Unit,
    /** A shelf of the books behind a number: "epic" or "rated". */
    val shelf: (kind: String) -> Unit,
    val dictionary: () -> Unit,
)

private fun MilestoneTarget.open(links: MilestoneLinks) {
    when (this) {
        is MilestoneTarget.OpenBook -> links.book(bookId)
        is MilestoneTarget.OpenNotes -> links.notes(bookId)
        is MilestoneTarget.OpenHistory -> links.history(date)
        is MilestoneTarget.OpenDictionary -> links.dictionary()
    }
}

// ---- colours and icons ----------------------------------------------------------------------

/** The colour each milestone keeps on the grid, the hero and the tier sheet (same as the TypeScript app). */
private fun accentOf(id: MilestoneId): Color = when (id) {
    MilestoneId.Books -> StatsAccent.Mint
    MilestoneId.Pages -> StatsAccent.Blue
    MilestoneId.Sessions -> StatsAccent.Yellow
    MilestoneId.Hours -> StatsAccent.Pink
    MilestoneId.Words -> StatsAccent.Yellow
    MilestoneId.Rated -> StatsAccent.Blue
    MilestoneId.Quotes -> StatsAccent.Pink
    MilestoneId.Streak -> StatsAccent.Mint
    MilestoneId.Epic -> StatsAccent.Pink
    MilestoneId.Notes -> StatsAccent.Yellow
    MilestoneId.WordsRead -> StatsAccent.Blue
    MilestoneId.ListenHours -> StatsAccent.Pink
    MilestoneId.Reviews -> StatsAccent.Mint
    MilestoneId.Days -> StatsAccent.Yellow
    MilestoneId.Authors -> StatsAccent.Blue
    MilestoneId.PerfectWeeks -> StatsAccent.Mint
    MilestoneId.Comebacks -> StatsAccent.Pink
    MilestoneId.Marathons -> StatsAccent.Yellow
    MilestoneId.EarlyBird -> StatsAccent.Yellow
    MilestoneId.NightOwl -> StatsAccent.Blue
    MilestoneId.Genres -> StatsAccent.Mint
    MilestoneId.Languages -> StatsAccent.Pink
    MilestoneId.ReReads -> StatsAccent.Blue
}

private fun eventAccent(e: TimelineEvent): Color = when {
    e.icon == MilestoneIcon.Done -> StatsAccent.Mint
    e.icon == MilestoneIcon.Plus || e.icon == MilestoneIcon.Trophy -> StatsAccent.Yellow
    e.icon == MilestoneIcon.Stack -> StatsAccent.Blue
    e.kind == TimelineKind.Note -> StatsAccent.Pink
    e.kind == TimelineKind.Read -> StatsAccent.Blue
    else -> StatsAccent.Mint
}

/** The soft accents are made for dark cards; on the light look the text versions are darkened to stay readable. */
@Composable
internal fun inkOf(c: Color): Color = if (LocalPbDark.current) c else lerp(c, Color.Black, 0.38f)

@Composable
internal fun trackColor(): Color = pbTokens().ink.copy(alpha = 0.10f)

internal fun MilestoneIcon.pb(): PbIconName = when (this) {
    MilestoneIcon.Book -> PbIconName.Book
    MilestoneIcon.Page -> PbIconName.Note
    MilestoneIcon.Clock -> PbIconName.Clock
    MilestoneIcon.Timer -> PbIconName.Timer
    MilestoneIcon.Mark -> PbIconName.Bookmark
    MilestoneIcon.Star -> PbIconName.Star
    MilestoneIcon.Quote -> PbIconName.Quote
    MilestoneIcon.Flame -> PbIconName.Flame
    MilestoneIcon.Stack -> PbIconName.Stack
    MilestoneIcon.Note -> PbIconName.Edit
    MilestoneIcon.Trophy -> PbIconName.Trophy
    MilestoneIcon.Done -> PbIconName.Check
    MilestoneIcon.Plus -> PbIconName.Plus
    MilestoneIcon.Headphones -> PbIconName.Headphones
    MilestoneIcon.Calendar -> PbIconName.Calendar
    MilestoneIcon.Person -> PbIconName.Person
    MilestoneIcon.Words -> PbIconName.Dictionary
}

/** The button at the bottom of a tier sheet: where the numbers come from. */
private fun milestoneAction(m: Milestone, links: MilestoneLinks): Pair<String, () -> Unit>? = when (m.id) {
    MilestoneId.Books -> if (m.value > 0) "See finished books" to { links.finished() } else null
    MilestoneId.Epic -> if (m.value > 0) "See epic books" to { links.shelf("epic") } else null
    MilestoneId.Rated -> "See rated books" to { links.shelf("rated") }
    MilestoneId.Words -> "Open dictionary" to { links.dictionary() }
    MilestoneId.Quotes, MilestoneId.Notes -> "Open notes & highlights" to { links.notes(null) }
    MilestoneId.Pages, MilestoneId.Sessions, MilestoneId.Hours, MilestoneId.Streak,
    MilestoneId.WordsRead, MilestoneId.ListenHours, MilestoneId.Days, MilestoneId.PerfectWeeks, MilestoneId.Comebacks,
    MilestoneId.Marathons, MilestoneId.EarlyBird, MilestoneId.NightOwl ->
        if (m.value > 0) "See your sessions" to { links.history(null) } else null
    MilestoneId.Authors, MilestoneId.Genres, MilestoneId.Languages, MilestoneId.ReReads -> if (m.value > 0) "See finished books" to { links.finished() } else null
    MilestoneId.Reviews -> null
}

private const val ALL = "all"

// ---- the page -------------------------------------------------------------------------------

/**
 * Stats -> Milestones: twenty-three lifetime achievements with five tiers each, what is next, and a timeline of when things
 * happened. Everything opens something: a card opens its tiers, a tier opens the book / notes / day behind it, a
 * timeline entry opens the same, and the sheet's button goes to the page the numbers come from.
 */
@Composable
fun MilestonesScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    highlights: List<Highlight>,
    links: MilestoneLinks,
    modifier: Modifier = Modifier,
    savedWords: List<SavedWord> = emptyList(),
    /** Every finished reading of every book, for Re-reads (empty while it loads). */
    readings: List<com.paperback.app.data.Reading> = emptyList(),
) {
    val zone = remember { ZoneId.systemDefault() }
    val nowMs = remember { System.currentTimeMillis() }

    val input = remember(books, sessions, highlights, savedWords, readings) {
        MilestoneInput(sessions, books, highlights, savedWords, zone, nowMs, readings)
    }
    val list = remember(input) { buildMilestones(input) }
    val timeline = remember(input, list) { buildTimeline(input, list) }
    val next = remember(list) { pickNextUp(list) }
    val counts = remember(list) { tiersUnlocked(list) }

    var view by rememberSaveable { mutableStateOf("progress") }
    var filter by rememberSaveable { mutableStateOf(ALL) }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }

    val shown = remember(timeline, filter) {
        if (filter == ALL) timeline else timeline.filter { it.kind.name == filter }
    }
    // One card per month, newest first (the timeline is already newest first).
    val months = remember(shown) {
        val out = ArrayList<Pair<String, MutableList<TimelineEvent>>>()
        for (e in shown) {
            val name = monthHeading(e.at, nowMs, zone)
            val last = out.lastOrNull()
            if (last != null && last.first == name) last.second.add(e) else out.add(name to mutableListOf(e))
        }
        out
    }

    Box(modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "next") {
                if (next != null) {
                    NextUpCard(next, counts.first, counts.second) { openId = next.milestone.id.name }
                } else {
                    AllDoneCard(counts.first, counts.second)
                }
            }
            item(key = "switch") {
                PbSegmented(
                    options = listOf("progress" to "Progress \u00B7 ${list.size}", "timeline" to "Timeline \u00B7 ${timeline.size}"),
                    selected = view,
                    onSelect = { view = it },
                )
            }

            if (view == "progress") {
                items(list.chunked(2), key = { it.first().id.name }) { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { m ->
                            MilestoneCard(m, Modifier.weight(1f)) { openId = m.id.name }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                item(key = "foot") {
                    PbNote("${counts.first} of ${counts.second} tiers unlocked. Tap a card to see its tiers.")
                }
            } else {
                item(key = "chips") {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TogglePill("All", filter == ALL) { filter = ALL }
                        TogglePill("Books", filter == TimelineKind.Book.name) { filter = TimelineKind.Book.name }
                        TogglePill("Reading", filter == TimelineKind.Read.name) { filter = TimelineKind.Read.name }
                        TogglePill("Notes", filter == TimelineKind.Note.name) { filter = TimelineKind.Note.name }
                    }
                }
                if (months.isEmpty()) {
                    item(key = "empty") { EmptyCard("Nothing here yet.") }
                } else {
                    items(months, key = { "month-${it.first}" }) { (name, events) ->
                        TimelineCard(name, events, nowMs, zone, links)
                    }
                    item(key = "tl-note") { PbNote("Tap an entry to open the book, the notes or the day behind it.") }
                }
            }
        }

        val open = list.firstOrNull { it.id.name == openId }
        if (open != null) {
            TierSheet(open, nowMs, zone, links, onClose = { openId = null })
        }
    }
}

// ---- next up --------------------------------------------------------------------------------

private enum class HexState { Done, Cur, Lock }

@Composable
private fun NextUpCard(next: NextUp, done: Int, total: Int, onOpen: () -> Unit) {
    val t = pbTokens()
    val m = next.milestone
    val ac = accentOf(m.id)
    val ink = inkOf(ac)
    val needText = commas(next.need)
    Column(
        Modifier
            .fillMaxWidth()
            .dashSurface()
            .semantics(mergeDescendants = true) {
                contentDescription = "Next up: $needText more to ${goalText(m, next.target)}. Open tiers."
            }
            .clickable(onClickLabel = "Open tiers", role = Role.Button, onClick = onOpen)
            .padding(horizontal = 20.dp, vertical = 22.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            m.tiers.indices.forEach { k ->
                val state = when {
                    k < m.unlocked -> HexState.Done
                    k == m.unlocked -> HexState.Cur
                    else -> HexState.Lock
                }
                TierHex(state, k + 1, ac, ink)
            }
        }
        Spacer(Modifier.height(22.dp))
        Text(
            "Next up \u00B7 tier ${next.tier} of ${m.tiers.size}",
            color = t.setSub,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
        )
        Spacer(Modifier.height(8.dp))
        Row {
            Text(
                needText,
                modifier = Modifier.alignByBaseline(),
                color = ink,
                fontSize = 64.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.03).em,
            )
            Spacer(Modifier.width(10.dp))
            Text(
                "${m.unit} to go",
                modifier = Modifier.alignByBaseline(),
                color = t.ink,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Text("until ${goalText(m, next.target)}", color = t.setSub, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        PctBar(m.pct / 100f, ac, 10.dp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth()) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = t.ink, fontWeight = FontWeight.SemiBold)) { append(commas(m.value)) }
                    append(" of ${commas(next.target)}")
                },
                modifier = Modifier.weight(1f),
                color = t.setSub,
                fontSize = 13.sp,
            )
            Text(
                if (next.days != null) etaText(next.days) else "$done of $total tiers",
                color = t.setSub,
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun AllDoneCard(done: Int, total: Int) {
    val t = pbTokens()
    Column(
        Modifier.fillMaxWidth().dashSurface().padding(horizontal = 20.dp, vertical = 22.dp),
    ) {
        Text("Every tier unlocked", color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        Text("$done of $total", color = t.ink, fontSize = 40.sp, fontWeight = FontWeight.SemiBold)
        Text("You have unlocked every tier there is.", color = t.setSub, fontSize = 13.sp)
    }
}

/** One tier badge of the hero: a tick when unlocked, its number when it is the one being worked on, dashed when locked. */
@Composable
private fun TierHex(state: HexState, number: Int, accent: Color, ink: Color) {
    val t = pbTokens()
    val onAccent = Accent.onAccent(accent)
    val big = state == HexState.Cur
    val lockFill = t.asTrack
    val lockStroke = t.setSub.copy(alpha = 0.45f)
    Box(Modifier.size(if (big) 64.dp else 56.dp, if (big) 72.dp else 64.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            // The shape is drawn on a 64 x 72 grid, like the TypeScript app's badge.
            val k = size.width / 64f
            val hex = Path().apply {
                moveTo(32f * k, 3f * k)
                lineTo(59f * k, 18f * k)
                lineTo(59f * k, 54f * k)
                lineTo(32f * k, 69f * k)
                lineTo(5f * k, 54f * k)
                lineTo(5f * k, 18f * k)
                close()
            }
            val sw = 3.dp.toPx()
            when (state) {
                HexState.Done -> {
                    drawPath(hex, accent)
                    drawPath(hex, accent, style = Stroke(sw, join = StrokeJoin.Round))
                    val tick = Path().apply {
                        moveTo(22f * k, 37f * k)
                        lineTo(29f * k, 44f * k)
                        lineTo(43f * k, 28f * k)
                    }
                    drawPath(tick, onAccent, style = Stroke(4f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                HexState.Cur -> {
                    drawPath(hex, accent.copy(alpha = 0.27f))
                    drawPath(hex, accent, style = Stroke(sw, join = StrokeJoin.Round))
                }
                HexState.Lock -> {
                    drawPath(hex, lockFill)
                    drawPath(
                        hex,
                        lockStroke,
                        style = Stroke(sw, join = StrokeJoin.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f * k, 5f * k))),
                    )
                }
            }
        }
        if (state == HexState.Cur) {
            Text("$number", color = ink, fontSize = 26.sp, fontWeight = FontWeight.Medium)
        }
    }
}

/** A rounded bar, [fraction] 0..1 of the way across, never narrower than a dot so a start is visible. */
@Composable
internal fun PctBar(fraction: Float, color: Color, height: Dp) {
    val track = trackColor()
    Canvas(Modifier.fillMaxWidth().height(height)) {
        val r = CornerRadius(size.height / 2f)
        drawRoundRect(track, size = size, cornerRadius = r)
        val w = max(6.dp.toPx(), size.width * fraction.coerceIn(0f, 1f)).coerceAtMost(size.width)
        drawRoundRect(
            Brush.horizontalGradient(listOf(color, lerp(color, Color.White, 0.3f)), startX = 0f, endX = w),
            size = Size(w, size.height), cornerRadius = r,
        )
    }
}

// ---- progress grid --------------------------------------------------------------------------

@Composable
private fun MilestoneCard(m: Milestone, modifier: Modifier, onOpen: () -> Unit) {
    val t = pbTokens()
    val ac = accentOf(m.id)
    val ink = inkOf(ac)
    val track = trackColor()
    Column(
        modifier
            .dashSurface()
            .semantics(mergeDescendants = true) {
                contentDescription = "${m.label}: ${commas(m.value)}" +
                    (if (m.next != null) " of ${commas(m.next)}" else "") +
                    ", tier ${m.unlocked} of ${m.tiers.size}. Open tiers."
            }
            .clickable(onClickLabel = "Open tiers", role = Role.Button, onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Text(m.label, color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row {
                    Text(
                        shortNum(m.value),
                        modifier = Modifier.alignByBaseline(),
                        color = if (m.value == 0) t.ink else ink,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                    if (m.next != null) {
                        Text(
                            "/${shortNum(m.next)}",
                            modifier = Modifier.alignByBaseline().padding(start = 1.dp),
                            color = t.setSub,
                            fontSize = 14.sp,
                            maxLines = 1,
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    m.tiers.indices.forEach { k ->
                        Box(
                            Modifier
                                .size(width = 14.dp, height = 4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    when {
                                        k < m.unlocked -> ac
                                        k == m.unlocked -> ac.copy(alpha = 0.5f)
                                        else -> track
                                    },
                                ),
                        )
                    }
                }
            }
            Spacer(Modifier.width(6.dp))
            ProgressRing(m.pct, ac, 44.dp)
        }
    }
}

/** A ring filled [pct] percent of the way round, starting at the top. With nothing yet it is a dot at the start. */
@Composable
private fun ProgressRing(pct: Float, color: Color, size: Dp) {
    val track = trackColor()
    Canvas(Modifier.size(size)) {
        val sw = 5.dp.toPx()
        val d = this.size.minDimension - sw
        val tl = Offset(sw / 2f, sw / 2f)
        drawArc(track, 0f, 360f, false, topLeft = tl, size = Size(d, d), style = Stroke(sw))
        if (pct <= 0f) {
            drawCircle(color, radius = sw / 2f, center = Offset(this.size.width / 2f, sw / 2f))
        } else {
            drawArc(color, -90f, 360f * (pct / 100f).coerceAtMost(1f), false, topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
        }
    }
}

// ---- timeline -------------------------------------------------------------------------------

@Composable
private fun EmptyCard(text: String) {
    val t = pbTokens()
    Box(
        Modifier.fillMaxWidth().dashSurface().padding(horizontal = 16.dp, vertical = 28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = t.setSub, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun TimelineCard(name: String, events: List<TimelineEvent>, nowMs: Long, zone: ZoneId, links: MilestoneLinks) {
    val t = pbTokens()
    Column(
        Modifier
            .fillMaxWidth()
            .dashSurface()
            .padding(start = 14.dp, end = 14.dp, top = 18.dp, bottom = 4.dp),
    ) {
        Text(
            "Timeline \u00B7 $name",
            modifier = Modifier.padding(start = 4.dp, bottom = 14.dp),
            color = t.setSub,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
        )
        events.forEachIndexed { i, e ->
            TimelineRow(e, last = i == events.lastIndex, nowMs = nowMs, zone = zone, links = links)
        }
    }
}

@Composable
private fun TimelineRow(e: TimelineEvent, last: Boolean, nowMs: Long, zone: ZoneId, links: MilestoneLinks) {
    val t = pbTokens()
    val ac = eventAccent(e)
    val target = e.target
    val line = t.rule
    val sub = buildAnnotatedString {
        e.sub.forEach { p ->
            if (p.bold) withStyle(SpanStyle(color = t.ink, fontWeight = FontWeight.Medium)) { append(p.text) } else append(p.text)
        }
    }
    val tap = if (target != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button) { target.open(links) } else Modifier
    Row(
        Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(16.dp))
            .semantics(mergeDescendants = true) {
                contentDescription = "${e.title}. ${e.sub.joinToString("") { it.text }}." + if (target != null) " Open." else ""
            }
            .then(tap)
            .padding(horizontal = 4.dp),
    ) {
        Column(Modifier.width(22.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(22.dp).clip(CircleShape).background(ac.copy(alpha = 0.22f)))
                Box(Modifier.size(12.dp).clip(CircleShape).background(ac))
            }
            Box(
                Modifier
                    .padding(top = 2.dp)
                    .width(2.dp)
                    .weight(1f)
                    .background(if (last) Color.Transparent else line),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).padding(bottom = 18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    e.title,
                    modifier = Modifier.weight(1f),
                    color = t.ink,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.width(10.dp))
                Text(shortDateLabel(e.at, nowMs, zone), color = t.setSub, fontSize = 12.sp, maxLines = 1)
                if (target != null) PbIcon(PbIconName.CaretRight, size = 14.dp, tint = t.setSub)
            }
            Text(sub, modifier = Modifier.padding(top = 2.dp), color = t.setSub, fontSize = 14.sp, lineHeight = 19.sp)
        }
    }
}

// ---- tier sheet -----------------------------------------------------------------------------

/** The tiers of one milestone, as a sheet that rises from the bottom. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TierSheet(m: Milestone, nowMs: Long, zone: ZoneId, links: MilestoneLinks, onClose: () -> Unit) {
    val t = pbTokens()
    val ac = accentOf(m.id)
    val ink = inkOf(ac)
    val onAccent = Accent.onAccent(ac)
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val left = if (m.next == null) 0 else m.next - m.value
    val action = milestoneAction(m, links)

    ModalBottomSheet(
        onDismissRequest = onClose,
        sheetState = sheetState,
        containerColor = t.menuBg,
        contentColor = t.ink,
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
        dragHandle = {
            Box(Modifier.padding(top = 10.dp, bottom = 6.dp).size(width = 40.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(trackColor()))
        },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 22.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(17.dp)).background(ac.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) { PbIcon(m.icon.pb(), size = 24.dp, tint = ink) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(m.label, color = t.ink, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                    Text("Tier ${m.unlocked} of ${m.tiers.size} unlocked", color = t.setSub, fontSize = 14.sp)
                }
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(t.card).clickable(onClickLabel = "Close", role = Role.Button, onClick = onClose),
                    contentAlignment = Alignment.Center,
                ) { PbIcon(PbIconName.Close, size = 18.dp, tint = t.ink, strokeWidth = 2.2f) }
            }

            Spacer(Modifier.height(20.dp))
            Row {
                Text(
                    commas(m.value),
                    modifier = Modifier.alignByBaseline(),
                    color = ink,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = (-0.03).em,
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    if (m.next != null) "/ ${commas(m.next)} ${m.unit}" else m.unit,
                    modifier = Modifier.alignByBaseline(),
                    color = t.setSub,
                    fontSize = 18.sp,
                )
            }
            Spacer(Modifier.height(16.dp))
            PctBar(m.pct / 100f, ac, 8.dp)
            Text(
                if (m.next != null) {
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = ink, fontWeight = FontWeight.SemiBold)) { append("${commas(left)} ${m.unit}") }
                        append(" to tier ${m.unlocked + 1}")
                    }
                } else {
                    buildAnnotatedString { append("Every tier unlocked") }
                },
                modifier = Modifier.padding(top = 8.dp),
                color = t.setSub,
                fontSize = 14.sp,
            )

            Spacer(Modifier.height(18.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                m.tiers.forEachIndexed { k, tier ->
                    val state = when {
                        k < m.unlocked -> HexState.Done
                        k == m.unlocked -> HexState.Cur
                        else -> HexState.Lock
                    }
                    val whenMs = m.dates[k]
                    val target = m.targets[k]
                    val status = when (state) {
                        HexState.Done -> if (whenMs != null) shortDateLabel(whenMs, nowMs, zone) else "Unlocked"
                        HexState.Cur -> "${commas(tier - m.value)} to go"
                        HexState.Lock -> "Locked"
                    }
                    val shape = RoundedCornerShape(18.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(if (state == HexState.Cur) ac.copy(alpha = 0.10f) else t.card)
                            .then(if (state == HexState.Cur) Modifier.border(1.5.dp, ac.copy(alpha = 0.27f), shape) else Modifier)
                            .then(
                                if (target != null) {
                                    Modifier.clickable(onClickLabel = "Open", role = Role.Button) {
                                        onClose()
                                        target.open(links)
                                    }
                                } else {
                                    Modifier
                                },
                            )
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        TierNumber(state, k + 1, ac, ink, onAccent)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${commas(tier)} ${m.unit}",
                                color = if (state == HexState.Lock) t.setSub else t.ink,
                                fontSize = 16.sp,
                                fontWeight = if (state == HexState.Lock) FontWeight.Medium else FontWeight.SemiBold,
                            )
                            Text("Tier ${k + 1}", color = t.setSub, fontSize = 13.sp)
                        }
                        Text(
                            status,
                            color = if (state == HexState.Cur) ink else t.setSub,
                            fontSize = 13.sp,
                            fontWeight = if (state == HexState.Cur) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                        )
                        if (target != null) {
                            Spacer(Modifier.width(4.dp))
                            PbIcon(PbIconName.CaretRight, size = 14.dp, tint = t.setSub)
                        }
                    }
                }
            }

            if (action != null) {
                Spacer(Modifier.height(18.dp))
                PbButton(action.first, onClick = {
                    onClose()
                    action.second()
                })
            }
        }
    }
}

/** The round number at the start of a tier row: a tick when unlocked, a ring when it is next, grey when locked. */
@Composable
private fun TierNumber(state: HexState, number: Int, accent: Color, ink: Color, onAccent: Color) {
    val t = pbTokens()
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(if (state == HexState.Done) accent else if (state == HexState.Lock) trackColor() else Color.Transparent)
            .then(if (state == HexState.Cur) Modifier.border(2.dp, accent, CircleShape) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        if (state == HexState.Done) {
            PbIcon(PbIconName.Tick, size = 16.dp, tint = onAccent, strokeWidth = 2.8f)
        } else {
            Text(
                "$number",
                color = if (state == HexState.Cur) ink else t.setSub,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}
