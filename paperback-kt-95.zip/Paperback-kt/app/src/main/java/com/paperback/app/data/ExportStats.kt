package com.paperback.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/*
 * Your reading as files you can keep: every session and every book as CSV (opens in a spreadsheet) and everything
 * together as JSON. Dates are written as yyyy-MM-dd in your time zone, times as HH:mm, durations in minutes.
 */

private fun csvCell(s: String): String =
    if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s

private fun csvLine(cells: List<String>): String = cells.joinToString(",") { csvCell(it) }

private fun dayText(ms: Long, zone: ZoneId): String = if (ms <= 0L) "" else Instant.ofEpochMilli(ms).atZone(zone).toLocalDate().toString()

private fun timeText(ms: Long, zone: ZoneId): String =
    Instant.ofEpochMilli(ms).atZone(zone).toLocalTime().let { "%02d:%02d".format(it.hour, it.minute) }

private fun kindName(kind: Int): String = when (kind) {
    SessionKind.LISTEN -> "listened"
    SessionKind.LOGGED -> "logged"
    else -> "read"
}

private fun statusName(b: Book): String = when {
    b.finished -> "finished"
    b.status == BookStatus.DROPPED -> "dropped"
    b.status == BookStatus.PAUSED -> "paused"
    b.isReading -> "reading"
    else -> "unread"
}

private fun minutesOf(seconds: Long): String = "%.1f".format(seconds / 60.0)

/** One line per reading session, oldest first. */
fun sessionsCsv(sessions: List<ReadingSession>, books: List<Book>, zone: ZoneId): String {
    val byId = books.associateBy { it.id }
    val sb = StringBuilder()
    sb.append(csvLine(listOf("date", "start_time", "book", "author", "minutes", "pages", "kind", "from_page", "to_page", "chapters", "entered_by_hand"))).append('\n')
    for (s in sessions.sortedBy { it.startMs }) {
        val b = byId[s.bookId]
        sb.append(
            csvLine(
                listOf(
                    dayText(s.startMs, zone), timeText(s.startMs, zone), b?.title ?: "(removed book)", b?.author ?: "",
                    minutesOf(s.seconds.toLong()), s.pages.toString(), kindName(s.kind),
                    if (s.fromPos > 0) s.fromPos.toString() else "", if (s.toPos > 0) s.toPos.toString() else "",
                    if (s.chapters > 0) s.chapters.toString() else "", if (s.manual) "yes" else "no",
                ),
            ),
        ).append('\n')
    }
    return sb.toString()
}

/** One line per book with its own numbers (time read, sessions, dates, rating, words). */
fun booksCsv(books: List<Book>, sessions: List<ReadingSession>, zone: ZoneId): String {
    val secs = Stats.secondsByBook(sessions)
    val counts = sessions.groupingBy { it.bookId }.eachCount()
    val sb = StringBuilder()
    sb.append(
        csvLine(
            listOf(
                "title", "author", "language", "genres", "series", "series_no", "format", "source", "status", "added", "started", "finished",
                "rating", "pages", "words", "minutes_read", "sessions", "progress_percent", "favorite",
            ),
        ),
    ).append('\n')
    for (b in books.sortedBy { it.title.lowercase() }) {
        sb.append(
            csvLine(
                listOf(
                    b.title, b.author, b.language, b.tags.joinToString("; "), b.series,
                    if (b.seriesNo > 0f) b.seriesNo.toString() else "", formatLabel(b), sourceLabel(b), statusName(b),
                    dayText(b.addedAt, zone), dayText(b.startedAt, zone), if (b.finished) dayText(finishedAtMs(b), zone) else "",
                    if (b.rating10 > 0f) "%.2f".format(b.rating10 / 2.0) else "",
                    if (b.pageCount > 0) b.pageCount.toString() else "", if (b.words > 0) b.words.toString() else "",
                    minutesOf(secs[b.id] ?: 0L), (counts[b.id] ?: 0).toString(), b.percent.toString(), if (b.favorite) "yes" else "no",
                ),
            ),
        ).append('\n')
    }
    return sb.toString()
}

/** Everything in one JSON file: books with their numbers, every session, and every highlight. */
fun statsJson(books: List<Book>, sessions: List<ReadingSession>, highlights: List<Highlight>, zone: ZoneId): String {
    val byId = books.associateBy { it.id }
    val secs = Stats.secondsByBook(sessions)
    val root = JSONObject()
    root.put("exported", LocalDate.now(zone).toString())

    val booksJson = JSONArray()
    for (b in books) {
        booksJson.put(
            JSONObject()
                .put("title", b.title).put("author", b.author).put("language", b.language)
                .put("genres", JSONArray(b.tags)).put("series", b.series).put("seriesNo", b.seriesNo.toDouble())
                .put("format", formatLabel(b)).put("source", sourceLabel(b)).put("status", statusName(b))
                .put("added", dayText(b.addedAt, zone)).put("started", dayText(b.startedAt, zone))
                .put("finished", if (b.finished) dayText(finishedAtMs(b), zone) else "")
                .put("rating", b.rating10 / 2.0).put("pages", b.pageCount).put("words", b.words)
                .put("minutesRead", (secs[b.id] ?: 0L) / 60.0).put("progressPercent", b.percent).put("favorite", b.favorite),
        )
    }
    root.put("books", booksJson)

    val sessionsJson = JSONArray()
    for (s in sessions.sortedBy { it.startMs }) {
        val b = byId[s.bookId]
        sessionsJson.put(
            JSONObject()
                .put("date", dayText(s.startMs, zone)).put("time", timeText(s.startMs, zone))
                .put("book", b?.title ?: "").put("author", b?.author ?: "")
                .put("minutes", s.seconds / 60.0).put("pages", s.pages).put("kind", kindName(s.kind))
                .put("fromPage", s.fromPos).put("toPage", s.toPos).put("chapters", s.chapters).put("byHand", s.manual),
        )
    }
    root.put("sessions", sessionsJson)

    val notesJson = JSONArray()
    for (h in highlights.sortedBy { it.createdAt }) {
        notesJson.put(
            JSONObject()
                .put("date", dayText(h.createdAt, zone)).put("book", byId[h.bookId]?.title ?: "")
                .put("text", h.text).put("note", h.note),
        )
    }
    root.put("highlights", notesJson)
    return root.toString(2)
}
