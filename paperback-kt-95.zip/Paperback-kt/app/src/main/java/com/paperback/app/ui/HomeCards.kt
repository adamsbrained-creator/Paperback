package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

/** After a session that beat one of your records: what it beat, with one tap to dismiss. Shown once per session. */
@Composable
fun RecordCard(lines: List<String>, onDone: () -> Unit) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PbIcon(PbIconName.Sparkle, size = 22.dp, tint = primary)
            Spacer(Modifier.width(10.dp))
            Text("A new record", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(8.dp))
        lines.forEach { Text(it, color = t.ink, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Nice", color = primary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onDone() }.padding(vertical = 6.dp))
        }
    }
}

/** One passage you saved, picked by the day (the same one all day), at the bottom of Home. */
@Composable
fun QuoteOfTheDayCard(text: String, note: String, bookTitle: String, onOpen: (() -> Unit)?, chapter: String = "") {
    val t = pbTokens()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .then(if (onOpen != null) Modifier.clickable { onOpen() } else Modifier)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Text("QUOTE OF THE DAY", color = t.setSub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        Text("“${text.trim().take(320)}”", color = t.ink, fontSize = 16.sp, lineHeight = 24.sp, fontFamily = PbSerif)
        if (note.isNotBlank()) Text(note.trim().take(200), color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(8.dp))
        Text(bookTitle, color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        if (chapter.isNotBlank()) Text(chapter, color = t.setSub, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
    }
}
