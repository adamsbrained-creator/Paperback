package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.BookStatus
import com.paperback.app.data.Bookmark
import com.paperback.app.data.Goals
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.Highlight
import com.paperback.app.data.MilestoneTarget
import com.paperback.app.data.RECAP_PARTS
import com.paperback.app.data.RECAP_PART_HOURS
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Recap
import com.paperback.app.data.RecapBook
import com.paperback.app.data.RecapDay
import com.paperback.app.data.RecapStat
import com.paperback.app.data.StatNames
import com.paperback.app.data.Stats
import com.paperback.app.data.buildRecap
import com.paperback.app.data.commas
import com.paperback.app.data.dateOf
import com.paperback.app.data.dayLabel
import com.paperback.app.data.recapKey
import com.paperback.app.data.recapShareText
import com.paperback.app.data.shortNum
import com.paperback.app.data.recapTitle
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** Where a tap on the recap goes. The root builds this from the app's navigation. */
class RecapLinks(
    val book: (bookId: String) -> Unit,
    /** The notes of one book, or every note and highlight when null. */
    val notes: (bookId: String?) -> Unit,
    /** Stats -> History, on that day. */
    val history: (day: LocalDate) -> Unit,
    /** A shelf: "m-started-2026-09", "rated", "langs"... */
    val shelf: (kind: String) -> Unit,
    val author: (name: String) -> Unit,
    val tag: (name: String) -> Unit,
    val goals: () -> Unit,
    val share: (text: String) -> Unit,
)

private val TONES = listOf(StatsAccent.Blue, StatsAccent.Yellow, StatsAccent.Mint, StatsAccent.Pink)
private val WEEKDAY_NAMES = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

private fun MilestoneTarget.openRecap(links: RecapLinks) {
    when (this) {
        is MilestoneTarget.OpenBook -> links.book(bookId)
        is MilestoneTarget.OpenNotes -> links.notes(bookId)
        is MilestoneTarget.OpenHistory -> links.history(date)
        is MilestoneTarget.OpenDictionary -> links.notes(null)
    }
}

// ---- the page -------------------------------------------------------------------------------

/**
 * One month, looked back on: the numbers, the books on a shelf, a calendar of covers, charts, habits, records, quotes
 * and how it compares with the month before. Everything that has something behind it opens it.
 */
@Composable
fun RecapScreen(
    month: YearMonth,
    books: List<Book>,
    sessions: List<ReadingSession>,
    highlights: List<Highlight>,
    bookmarks: List<Bookmark>,
    goals: Goals,
    links: RecapLinks,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    val zone = remember { ZoneId.systemDefault() }
    val nowMs = remember { System.currentTimeMillis() }
    // A recap goes through every session of the history, so it is built off the main thread.
    val recap by produceState<Recap?>(null, month, books, sessions, highlights, bookmarks, goals) {
        value = withContext(Dispatchers.Default) {
            buildRecap(month, books, sessions, highlights, bookmarks, goals, zone, nowMs)
        }
    }
    PbListPage(recapTitle(month), headerSize, onMenu, onSearch) {
        val r = recap
        if (r == null) {
            Text("Putting your month together\u2026", modifier = Modifier.padding(start = 4.dp, top = 8.dp), color = t.setSub, fontSize = 15.sp)
        } else {
            RecapBody(r, links, zone, nowMs, Modifier.weight(1f))
        }
    }
}

@Composable
private fun RecapBody(r: Recap, links: RecapLinks, zone: ZoneId, nowMs: Long, modifier: Modifier) {
    val today = remember(nowMs) { dateOf(nowMs, zone) }
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(top = 8.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "hero") { HeroCard(r, links) }
        if (r.isEmpty) {
            item(key = "empty") { EmptyRecap(r) }
            return@LazyColumn
        }
        item(key = "books") { BooksCard(r, links) }
        item(key = "overview") { OverviewTiles(r, links) }
        item(key = "yourbooks") { BookListCard(r, links) }
        if (r.books.count { it.seconds > 0 } >= 2) item(key = "split") { TimeSplitCard(r, links) }
        item(key = "calendar") { CalendarCard(r, links, today) }
        item(key = "chart") { PagesChartCard(r, links) }
        if (r.facts.isNotEmpty()) item(key = "facts") { FactsCard(r, links) }
        item(key = "when") { WhenCard(r, links) }
        item(key = "how") { HowCard(r) }
        item(key = "goals") { GoalsCard(r, links, today) }
        if (r.records.isNotEmpty() || r.events.isNotEmpty()) item(key = "records") { RecordsCard(r, links, zone) }
        if (r.quotes.isNotEmpty()) item(key = "quotes") { QuotesCard(r, links) }
        if (r.ratedCount > 0) item(key = "ratings") { RatingsCard(r, links) }
        if (r.authors.isNotEmpty() || r.genres.isNotEmpty() || r.languages.isNotEmpty()) item(key = "people") { PeopleCard(r, links) }
        item(key = "compare") { CompareCard(r) }
        item(key = "share") { ShareCard(r, links) }
    }
}

// ---- shared bits ----------------------------------------------------------------------------

/** A grey card with a small caps label (and a note at the right). With [onTap] the whole card is a button. */
@Composable
private fun RecapCard(
    label: String,
    modifier: Modifier = Modifier,
    trailing: String? = null,
    onTap: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    val t = pbTokens()
    val tap = if (onTap != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button, onClick = onTap) else Modifier
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(t.card)
            .then(tap)
            .padding(horizontal = 20.dp, vertical = 18.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            CardLabel(label)
            if (trailing != null) Text(trailing, color = t.setSub, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun RecapPill(text: String, onClick: () -> Unit) {
    val t = pbTokens()
    Text(
        text,
        modifier = Modifier
            .heightIn(min = 36.dp)
            .clip(RoundedCornerShape(99.dp))
            .background(t.asOn)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        color = t.ink,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        maxLines = 1,
    )
}

@Composable
private fun Chip(text: String, color: Color) {
    Text(
        text,
        modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(color.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 2.dp),
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
    )
}

private fun countText(n: Int, one: String, many: String) = "$n ${if (n == 1) one else many}"

// ---- hero -----------------------------------------------------------------------------------

@Composable
private fun HeroCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    val pct = r.compare.firstOrNull()?.pct
    RecapCard(
        label = recapTitle(r.month) + if (r.inProgress) " \u00B7 so far" else " \u00B7 recap",
        onTap = { links.history(r.month.atDay(1)) },
    ) {
        Text(
            Stats.duration(r.seconds),
            color = inkOf(primary),
            fontFamily = PbSerif,
            fontSize = 56.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.03).em,
            maxLines = 1,
        )
        Text(
            "of reading over ${countText(r.readingDays, "day", "days")}" + if (r.pages > 0) " \u00B7 ${commas(r.pages)} pages" else "",
            color = t.setSub,
            fontSize = 15.sp,
        )
        if (pct != null) {
            val up = pct >= 0
            val c = if (up) inkOf(StatsAccent.Mint) else inkOf(StatsAccent.Pink)
            val sign = if (pct > 0) "+" else if (pct < 0) "\u2212" else ""
            Spacer(Modifier.height(12.dp))
            Text(
                if (pct == 0) "Same as ${r.prevName}" else "$sign${abs(pct)}% vs ${r.prevName}",
                modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(c.copy(alpha = 0.14f)).padding(horizontal = 12.dp, vertical = 5.dp),
                color = c,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(primary.copy(alpha = 0.10f)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PbIcon(PbIconName.Sparkle, size = 22.dp, tint = primary)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(r.persona.title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(r.persona.blurb, color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp)
            }
        }
        if (r.equivBooks != null) {
            Text(
                "That is about ${"%.1f".format(r.equivBooks)} books of average length.",
                modifier = Modifier.padding(top = 10.dp),
                color = t.setSub,
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun EmptyRecap(r: Recap) {
    val t = pbTokens()
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Nothing read in ${recapTitle(r.month)}", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text("Open a book and the next recap will have plenty to say.", color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

// ---- books ----------------------------------------------------------------------------------

@Composable
private fun BooksCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    val key = recapKey(r.month)
    val read = r.books.count { it.seconds > 0 }
    RecapCard("Books", trailing = countText(r.books.size, "book", "books")) {
        if (r.books.isEmpty()) {
            Text("No books this month.", color = t.setSub, fontSize = 14.sp)
        } else {
            LazyRow(
                Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(r.books, key = { it.book.id }) { rb -> CoverTile(rb, links) }
            }
            Plank(Modifier.offset(y = (-6).dp))
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (r.startedCount > 0) RecapPill("Started ${r.startedCount}") { links.shelf("m-started-$key") }
                if (r.finishedCount > 0) RecapPill("Finished ${r.finishedCount}") { links.shelf("m-finished-$key") }
                if (read > 0) RecapPill("Read $read") { links.shelf("m-read-$key") }
            }
        }
        if (r.putDown.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text("Put down this month", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            r.putDown.forEach { b ->
                val dropped = b.status == BookStatus.DROPPED
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(b.id) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Chip(if (dropped) "Dropped" else "Paused", if (dropped) inkOf(StatsAccent.Pink) else inkOf(StatsAccent.Yellow))
                    Spacer(Modifier.width(10.dp))
                    Text(b.title, modifier = Modifier.weight(1f), color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (b.droppedPct > 0) Text("${b.droppedPct}% read", color = t.setSub, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun CoverTile(rb: RecapBook, links: RecapLinks) {
    Box(
        Modifier
            .width(92.dp)
            .semantics(mergeDescendants = true) { contentDescription = rb.book.title + if (rb.finished) ", finished" else if (rb.started) ", started" else "" }
            .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(rb.book.id) },
    ) {
        BookCover(rb.book, Modifier.fillMaxWidth())
        Row(Modifier.align(Alignment.TopStart).padding(5.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            if (rb.started) CoverBadge(PbIconName.Play, StatsAccent.Blue, 22.dp)
            if (rb.finished) CoverBadge(PbIconName.Tick, StatsAccent.Mint, 22.dp)
        }
    }
}

/** A small round marker on a cover: a play triangle (started) or a tick (finished). */
@Composable
private fun CoverBadge(icon: PbIconName, color: Color, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
        PbIcon(icon, size = size * 0.55f, tint = Accent.onAccent(color), filled = icon == PbIconName.Play, strokeWidth = 3f)
    }
}

// ---- the numbers ----------------------------------------------------------------------------

@Composable
private fun NumTile(label: String, accent: Color, value: String, sub: String?, onTap: (() -> Unit)?, m: Modifier) {
    StatTile(
        label, accent, m, onTap,
        description = "$label: $value" + (if (sub != null) ". $sub" else ""),
    ) {
        BigNumber(value)
        if (sub != null) TileSub(sub)
    }
}

@Composable
private fun OverviewTiles(r: Recap, links: RecapLinks) {
    val key = recapKey(r.month)
    val first = r.month.atDay(1)
    val ls = r.longestSession
    val zone = remember { ZoneId.systemDefault() }
    val longestDay = if (ls != null) dateOf(ls.startMs, zone) else null
    val toMonth: () -> Unit = { links.history(first) }
    val toNotes: () -> Unit = { links.notes(null) }
    val listenBook = r.topListenedId
    val listenTap: () -> Unit = if (listenBook != null) ({ links.book(listenBook) }) else toMonth

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CardLabel("Monthly overview", Modifier.padding(start = 4.dp, top = 8.dp))
        TileRow(
            { m -> NumTile("Books started", StatsAccent.Blue, "${r.startedCount}", null, if (r.startedCount > 0) ({ links.shelf("m-started-$key") }) else null, m) },
            { m -> NumTile("Books finished", StatsAccent.Mint, "${r.finishedCount}", null, if (r.finishedCount > 0) ({ links.shelf("m-finished-$key") }) else null, m) },
        )
        TileRow(
            { m -> NumTile("Pages read", StatsAccent.Pink, commas(r.pages), null, toMonth, m) },
            { m -> NumTile("Reading days", StatsAccent.Yellow, "${r.readingDays}", "of ${r.daysElapsed} days", toMonth, m) },
        )
        TileRow(
            { m -> NumTile("Quotes saved", StatsAccent.Pink, "${r.quoteCount - r.noteCount}", null, toNotes, m) },
            { m -> NumTile("Notes added", StatsAccent.Yellow, "${r.noteCount}", null, toNotes, m) },
        )

        CardLabel("Reading time", Modifier.padding(start = 4.dp, top = 12.dp))
        TileRow(
            { m -> NumTile("Time read", StatsAccent.Blue, Stats.duration(r.seconds), if (r.readingDays > 0) "${Stats.duration(r.avgDaySeconds)} a reading day" else null, toMonth, m) },
            { m -> NumTile("Sessions", StatsAccent.Mint, "${r.sessions}", if (r.sessions > 0) "${Stats.duration(r.avgSessionSeconds)} on average" else null, toMonth, m) },
        )
        TileRow(
            { m ->
                NumTile(
                    "Longest session", StatsAccent.Pink, if (ls != null) Stats.duration(ls.seconds) else "\u2013",
                    if (longestDay != null) dayLabel(longestDay) else null,
                    if (longestDay != null) ({ links.history(longestDay) }) else null, m,
                )
            },
            { m -> NumTile("Reading speed", StatsAccent.Yellow, if (r.pagesPerHour > 0) "${r.pagesPerHour}" else "\u2013", if (r.pagesPerHour > 0) "pages per hour" else null, toMonth, m) },
        )
        TileRow(
            { m ->
                NumTile(
                    "Listened", StatsAccent.Pink, if (r.listenSeconds > 0) Stats.duration(r.listenSeconds) else "\u2013",
                    if (r.listenSeconds > 0 && r.seconds > 0) "${((r.listenSeconds * 100.0) / r.seconds).roundToInt()}% of your time" else null,
                    listenTap, m,
                )
            },
            { m ->
                NumTile(
                    "Words read", StatsAccent.Blue, if (r.wordsRead > 0) shortNum(r.wordsRead.toInt()) else "\u2013",
                    if (r.wordsRead > 0) "estimated from page counts" else null, toMonth, m,
                )
            },
        )
        TileRow(
            { m -> NumTile("Bookmarks", StatsAccent.Blue, "${r.bookmarkCount}", null, toNotes, m) },
            { m -> NumTile("Books added", StatsAccent.Mint, "${r.addedBooks.size}", null, if (r.addedBooks.isNotEmpty()) ({ links.shelf("m-added-$key") }) else null, m) },
        )
    }
}

// ---- your books -----------------------------------------------------------------------------

@Composable
private fun BookListCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    var all by rememberSaveable { mutableStateOf(false) }
    val shown = if (all) r.books else r.books.take(5)
    RecapCard("Your books", trailing = countText(r.books.size, "book", "books")) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            shown.forEachIndexed { i, rb ->
                val ac = TONES[i % TONES.size]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .semantics(mergeDescendants = true) { contentDescription = "${rb.book.title}. Open book details." }
                        .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(rb.book.id) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BookCover(rb.book, Modifier.width(46.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                rb.book.title,
                                modifier = Modifier.weight(1f, fill = false),
                                color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            if (rb.finished) {
                                Spacer(Modifier.width(8.dp))
                                Chip("Finished", inkOf(StatsAccent.Mint))
                            } else if (rb.started) {
                                Spacer(Modifier.width(8.dp))
                                Chip("Started", inkOf(StatsAccent.Blue))
                            }
                        }
                        Text(
                            if (rb.seconds > 0) "${Stats.duration(rb.seconds)} \u00B7 ${commas(rb.pages)} pages \u00B7 ${countText(rb.days, "day", "days")}" else "Marked finished",
                            color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Spacer(Modifier.height(6.dp))
                        val progress = if (rb.book.finished) 1f else rb.book.progress
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { PctBar(max(0.02f, progress), ac, 6.dp) }
                            Text(
                                "${(progress * 100).roundToInt()}%",
                                modifier = Modifier.padding(start = 10.dp),
                                color = inkOf(ac), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }
            }
        }
        if (r.books.size > 5) {
            Spacer(Modifier.height(10.dp))
            RecapPill(if (all) "Show fewer" else "Show all ${r.books.size}") { all = !all }
        }
    }
}

@Composable
private fun TimeSplitCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    val withTime = r.books.filter { it.seconds > 0 }
    val top = withTime.take(4)
    val total = max(1L, r.seconds)
    val rest = r.seconds - top.sumOf { it.seconds }
    val track = trackColor()
    RecapCard("Where your time went") {
        Row(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp))) {
            top.forEachIndexed { i, rb ->
                Box(Modifier.weight(max(0.001f, rb.seconds.toFloat() / total)).fillMaxHeight().background(TONES[i % TONES.size]))
            }
            if (rest > 0) Box(Modifier.weight(max(0.001f, rest.toFloat() / total)).fillMaxHeight().background(track))
        }
        Spacer(Modifier.height(12.dp))
        top.forEachIndexed { i, rb ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(rb.book.id) }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(TONES[i % TONES.size]))
                Spacer(Modifier.width(10.dp))
                Text(rb.book.title, modifier = Modifier.weight(1f), color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${rb.sharePct}%", color = t.setSub, fontSize = 13.sp)
                Text(Stats.duration(rb.seconds), modifier = Modifier.width(72.dp), color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
            }
        }
        if (rest > 0) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(track))
                Spacer(Modifier.width(10.dp))
                Text("${withTime.size - top.size} other ${if (withTime.size - top.size == 1) "book" else "books"}", modifier = Modifier.weight(1f), color = t.setSub, fontSize = 14.sp)
                Text(Stats.duration(rest), color = t.setSub, fontSize = 14.sp)
            }
        }
    }
}

// ---- calendar -------------------------------------------------------------------------------

@Composable
private fun CalendarCard(r: Recap, links: RecapLinks, today: LocalDate) {
    val t = pbTokens()
    val lead = r.month.atDay(1).dayOfWeek.value - 1
    val cells: List<RecapDay?> = List<RecapDay?>(lead) { null } + r.days
    val weeks = cells.chunked(7)
    RecapCard("Reading calendar", trailing = "${r.readingDays} of ${r.daysElapsed} days") {
        Row(Modifier.fillMaxWidth()) {
            listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach {
                Text(it, modifier = Modifier.weight(1f), color = t.setSub, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1)
            }
        }
        Spacer(Modifier.height(6.dp))
        weeks.forEach { week ->
            Row(Modifier.fillMaxWidth()) {
                for (i in 0 until 7) DayCell(week.getOrNull(i), today, links, Modifier.weight(1f))
            }
        }
        Text(
            "Tap a day to see its sessions.",
            modifier = Modifier.padding(top = 8.dp),
            color = t.setSub,
            fontSize = 12.sp,
        )
    }
}

@Composable
private fun DayCell(day: RecapDay?, today: LocalDate, links: RecapLinks, modifier: Modifier) {
    val t = pbTokens()
    if (day == null) {
        Spacer(modifier.height(78.dp))
        return
    }
    val future = day.date.isAfter(today)
    val active = day.read || day.finished > 0
    val tap = if (active) Modifier.clickable(onClickLabel = "Open day", role = Role.Button) { links.history(day.date) } else Modifier
    Column(
        modifier
            .height(78.dp)
            .clip(RoundedCornerShape(10.dp))
            .then(tap)
            .padding(top = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "${day.date.dayOfMonth}",
            color = if (future) t.setSub.copy(alpha = 0.45f) else if (active) t.ink else t.setSub,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
        )
        Spacer(Modifier.height(3.dp))
        Box(Modifier.size(width = 34.dp, height = 51.dp)) {
            val main = day.main
            if (main != null && active) {
                BookCover(main, Modifier.fillMaxSize())
                if (day.finished > 0) Box(Modifier.align(Alignment.TopStart).padding(2.dp)) { CoverBadge(PbIconName.Tick, StatsAccent.Mint, 14.dp) }
                if (day.started > 0) Box(Modifier.align(Alignment.BottomStart).padding(2.dp)) { CoverBadge(PbIconName.Play, StatsAccent.Blue, 14.dp) }
                if (day.bookCount > 1) {
                    Text(
                        "+${day.bookCount - 1}",
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(2.dp)
                            .clip(RoundedCornerShape(99.dp))
                            .background(StatsAccent.Pink)
                            .padding(horizontal = 4.dp),
                        color = Accent.onAccent(StatsAccent.Pink),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            } else {
                Box(Modifier.align(Alignment.Center).size(4.dp).clip(CircleShape).background(t.ink.copy(alpha = if (future) 0.05f else 0.14f)))
            }
        }
    }
}

// ---- chart ----------------------------------------------------------------------------------

@Composable
private fun PagesChartCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    var mode by rememberSaveable { mutableStateOf("pages") }
    var sel by remember { mutableStateOf<Int?>(null) }
    val pages = mode == "pages"
    val values = remember(r, mode) { r.days.map { if (pages) it.pages.toFloat() else it.seconds / 60f } }
    val counted = values.count { it > 0f }
    val avg = if (counted > 0) values.sum() / counted else null
    fun valueText(v: Float): String = if (pages) "${v.toInt()} pages" else Stats.duration((v * 60f).toLong())

    RecapCard(if (pages) "Pages read over time" else "Time read over time") {
        PbSegmented(
            options = listOf("pages" to "Pages", "time" to "Time"),
            selected = mode,
            onSelect = {
                mode = it
                sel = null
            },
        )
        Spacer(Modifier.height(14.dp))
        DailyBars(
            values = values,
            accent = primary,
            selected = sel,
            average = avg,
            format = { v -> if (pages) "${v.toInt()}" else axisMinutes(v) },
            xLabel = { i -> if ((i + 1) % 2 == 1) "${i + 1}" else "" },
            onSelect = { sel = it },
        )
        val s = sel
        if (s != null && s in r.days.indices) {
            val d = r.days[s]
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(primary.copy(alpha = 0.10f))
                    .clickable(onClickLabel = "Open day", role = Role.Button) { links.history(d.date) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "${StatNames.WEEKDAYS_SHORT[StatNames.weekdayIndex(d.date)]} ${dayLabel(d.date)}: ${valueText(values[s])}",
                    modifier = Modifier.weight(1f), color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                )
                PbIcon(PbIconName.CaretRight, size = 16.dp, tint = t.setSub)
            }
        } else {
            Text(
                if (avg != null) "Dashed line: ${valueText(avg)} on a reading day. Tap a bar for a day." else "Tap a bar for a day.",
                modifier = Modifier.padding(top = 8.dp),
                color = t.setSub,
                fontSize = 12.sp,
            )
        }
    }
}

// ---- book highlights ------------------------------------------------------------------------

@Composable
private fun FactsCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    RecapCard("Book highlights") {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            r.facts.forEach { f ->
                val ac = TONES[f.tone % TONES.size]
                val target = f.target
                val tap = if (target != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button) { target.openRecap(links) } else Modifier
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(ac.copy(alpha = 0.08f))
                        .semantics(mergeDescendants = true) { contentDescription = "${f.label}: ${f.title}. ${f.sub}" }
                        .then(tap)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(ac.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                        PbIcon(f.icon.pb(), size = 22.dp, tint = inkOf(ac))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.label, color = t.setSub, fontSize = 12.sp)
                        Text(f.title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(f.sub, color = t.setSub, fontSize = 13.sp)
                    }
                    if (target != null) PbIcon(PbIconName.CaretRight, size = 16.dp, tint = t.setSub)
                }
            }
        }
    }
}

// ---- habits ---------------------------------------------------------------------------------

@Composable
private fun WhenCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    val h = r.habits
    val partTotal = max(1L, h.parts.sum())
    val fp = h.favoritePart
    val fw = h.favoriteWeekday
    RecapCard("When you read") {
        if (fp != null) {
            Text(
                "Mostly in the ${RECAP_PARTS[fp].lowercase()}",
                color = t.ink, fontFamily = PbSerif, fontSize = 22.sp, fontWeight = FontWeight.Medium,
            )
            Text(
                "${RECAP_PART_HOURS[fp]} \u00B7 ${((h.parts[fp] * 100.0) / partTotal).roundToInt()}% of your reading",
                modifier = Modifier.padding(top = 2.dp), color = t.setSub, fontSize = 13.sp,
            )
            Spacer(Modifier.height(12.dp))
        }
        HourBars(h.hours, fp, primary)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RECAP_PARTS.forEachIndexed { i, name ->
                val on = i == fp
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) primary.copy(alpha = 0.14f) else t.ink.copy(alpha = 0.05f))
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(name, color = if (on) t.ink else t.setSub, fontSize = 12.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                    Text("${((h.parts[i] * 100.0) / partTotal).roundToInt()}%", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        CardLabel("Days of the week")
        Spacer(Modifier.height(10.dp))
        if (fw != null) {
            Text(
                "${WEEKDAY_NAMES[fw]} was your day",
                color = t.ink, fontFamily = PbSerif, fontSize = 20.sp, fontWeight = FontWeight.Medium,
            )
            Text(
                "${Stats.duration(h.weekdays[fw])} in total \u00B7 ${h.weekendPct}% of your reading was on a weekend",
                modifier = Modifier.padding(top = 2.dp, bottom = 10.dp), color = t.setSub, fontSize = 13.sp,
            )
        }
        WeekdayBars(h.weekdays, fw, primary) { i ->
            r.days.filter { it.date.dayOfWeek.value - 1 == i }.maxByOrNull { it.seconds }?.let { links.history(it.date) }
        }
    }
}

@Composable
private fun HowCard(r: Recap) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    val lengths = r.habits.lengths
    val topLen = lengths.indices.maxByOrNull { lengths[it] }
    RecapCard("How you read") {
        Row(Modifier.fillMaxWidth()) {
            Stat3(Stats.duration(r.avgSessionSeconds), "average session", Modifier.weight(1f))
            Stat3(if (r.longestSession != null) Stats.duration(r.longestSession.seconds) else "\u2013", "longest session", Modifier.weight(1f))
            Stat3(if (r.pagesPerHour > 0) "${r.pagesPerHour}" else "\u2013", "pages per hour", Modifier.weight(1f))
        }
        if (r.listenSeconds > 0 || r.loggedSeconds > 0) {
            Spacer(Modifier.height(16.dp))
            val whole = max(1L, r.readSeconds + r.listenSeconds + r.loggedSeconds)
            Row(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp))) {
                if (r.readSeconds > 0) Box(Modifier.weight(max(0.001f, r.readSeconds.toFloat() / whole)).fillMaxHeight().background(primary))
                if (r.listenSeconds > 0) Box(Modifier.weight(max(0.001f, r.listenSeconds.toFloat() / whole)).fillMaxHeight().background(StatsAccent.Blue))
                if (r.loggedSeconds > 0) Box(Modifier.weight(max(0.001f, r.loggedSeconds.toFloat() / whole)).fillMaxHeight().background(t.ink.copy(alpha = 0.25f)))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                SplitLegend("Read", r.readSeconds, primary)
                if (r.listenSeconds > 0) SplitLegend("Listened", r.listenSeconds, StatsAccent.Blue)
                if (r.loggedSeconds > 0) SplitLegend("Logged", r.loggedSeconds, t.ink.copy(alpha = 0.25f))
            }
        }
        Spacer(Modifier.height(16.dp))
        LengthBars(lengths, primary)
        if (topLen != null && lengths[topLen] > 0) {
            Text(
                "Most of your sessions (${lengths[topLen]} of ${r.sessions}) were ${com.paperback.app.data.RECAP_LENGTHS[topLen].lowercase()}.",
                modifier = Modifier.padding(top = 12.dp), color = t.setSub, fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun SplitLegend(label: String, seconds: Long, color: Color) {
    val t = pbTokens()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color))
        Text(" $label ${Stats.duration(seconds)}", color = t.setSub, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun Stat3(value: String, label: String, modifier: Modifier) {
    val t = pbTokens()
    Column(modifier) {
        Text(value, color = t.ink, fontFamily = PbSerif, fontSize = 24.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        Text(label, color = t.setSub, fontSize = 12.sp)
    }
}

// ---- goals ----------------------------------------------------------------------------------

@Composable
private fun GoalsCard(r: Recap, links: RecapLinks, today: LocalDate) {
    val t = pbTokens()
    val mint = StatsAccent.Mint
    val mark = if (r.yearGoal > 0) minOf(1f, r.yearExpected.toFloat() / r.yearGoal) else 0f
    RecapCard("Goals", onTap = links.goals) {
        Text(
            "Daily goal met on ${r.goalDays} of ${r.daysElapsed} days",
            color = t.ink, fontFamily = PbSerif, fontSize = 20.sp, fontWeight = FontWeight.Medium,
        )
        Text("${r.goalMinutes} minutes a day", modifier = Modifier.padding(top = 2.dp, bottom = 10.dp), color = t.setSub, fontSize = 13.sp)
        GoalDots(r.days, r.goalMinutes * 60L, today) { links.history(it) }
        Text(
            "Green: goal met. Amber: you read, but under the goal.",
            modifier = Modifier.padding(top = 6.dp), color = t.setSub, fontSize = 12.sp,
        )
        if (r.goalPages > 0 && r.goalPageDays > 0) {
            Text(
                "The page goal (${commas(r.goalPages)} pages) was met on ${countText(r.goalPageDays, "day", "days")}.",
                modifier = Modifier.padding(top = 10.dp), color = t.setSub, fontSize = 13.sp,
            )
        }
        if (r.yearGoal > 0) {
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text("${r.yearFinished}", color = inkOf(mint), fontFamily = PbSerif, fontSize = 34.sp, fontWeight = FontWeight.Medium)
                Text(
                    " of ${r.yearGoal} books in ${r.month.year}",
                    modifier = Modifier.padding(bottom = 6.dp), color = t.setSub, fontSize = 14.sp,
                )
            }
            YearBar(minOf(1f, r.yearFinished.toFloat() / r.yearGoal), mark, mint)
            Text(
                if (r.yearFinished >= r.yearExpected) "On pace or ahead at the end of ${StatNames.MONTHS[r.month.monthValue - 1]}" else "${r.yearExpected - r.yearFinished} behind the line",
                color = t.setSub, fontSize = 13.sp,
            )
        }
    }
}

// ---- records and milestones -----------------------------------------------------------------

@Composable
private fun RecordsCard(r: Recap, links: RecapLinks, zone: ZoneId) {
    val t = pbTokens()
    val yellow = StatsAccent.Yellow
    RecapCard("Records & milestones") {
        if (r.records.isNotEmpty()) {
            Text("New personal records", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                r.records.forEach { rec ->
                    val target = rec.target
                    val tap = if (target != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button) { target.openRecap(links) } else Modifier
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(yellow.copy(alpha = 0.10f)).then(tap).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PbIcon(PbIconName.Trophy, size = 24.dp, tint = inkOf(yellow))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(rec.label, color = t.setSub, fontSize = 12.sp)
                            Text(rec.value, color = t.ink, fontFamily = PbSerif, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                            Text(rec.sub, color = t.setSub, fontSize = 12.sp)
                        }
                        if (target != null) PbIcon(PbIconName.CaretRight, size = 16.dp, tint = t.setSub)
                    }
                }
            }
        }
        if (r.events.isNotEmpty()) {
            if (r.records.isNotEmpty()) Spacer(Modifier.height(18.dp))
            Text("Milestones this month", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            r.events.take(8).forEach { e ->
                val target = e.target
                val tap = if (target != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button) { target.openRecap(links) } else Modifier
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).then(tap).padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(t.ink.copy(alpha = 0.06f)), contentAlignment = Alignment.Center) {
                        PbIcon(e.icon.pb(), size = 18.dp, tint = t.ink)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val sub = e.sub.joinToString("") { it.text }
                        if (sub.isNotEmpty()) Text(sub, color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(dayLabel(dateOf(e.at, zone)), color = t.setSub, fontSize = 12.sp)
                }
            }
            if (r.events.size > 8) {
                Text("and ${r.events.size - 8} more", modifier = Modifier.padding(top = 4.dp), color = t.setSub, fontSize = 13.sp)
            }
        }
    }
}

// ---- quotes ---------------------------------------------------------------------------------

@Composable
private fun QuotesCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    RecapCard("Quotes & notes", trailing = "${r.quoteCount} saved") {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            r.quotes.forEach { q ->
                val bookId = q.book?.id
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(primary.copy(alpha = 0.08f))
                        .clickable(onClickLabel = "Open notes", role = Role.Button) { links.notes(bookId) }
                        .padding(16.dp),
                ) {
                    PbIcon(PbIconName.Quote, size = 18.dp, tint = primary, modifier = Modifier.padding(top = 3.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            q.highlight.text.trim(),
                            color = t.ink, fontFamily = PbSerif, fontStyle = FontStyle.Italic,
                            fontSize = 16.sp, lineHeight = 23.sp, maxLines = 7, overflow = TextOverflow.Ellipsis,
                        )
                        if (q.highlight.note.isNotBlank()) {
                            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.Top) {
                                PbIcon(PbIconName.Edit, size = 14.dp, tint = t.setSub, modifier = Modifier.padding(top = 2.dp))
                                Text(
                                    " ${q.highlight.note.trim()}",
                                    color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp, maxLines = 4, overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                q.book?.title ?: "A removed book",
                                modifier = Modifier.weight(1f),
                                color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            if (q.page > 0) Text("Page ${q.page}", color = t.setSub, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "${countText(r.quoteCount - r.noteCount, "quote", "quotes")} \u00B7 ${countText(r.noteCount, "note", "notes")} \u00B7 ${countText(r.bookmarkCount, "bookmark", "bookmarks")}",
            color = t.setSub, fontSize = 13.sp,
        )
        Spacer(Modifier.height(10.dp))
        RecapPill("See all quotes and notes") { links.notes(null) }
    }
}

// ---- ratings --------------------------------------------------------------------------------

@Composable
private fun RatingsCard(r: Recap, links: RecapLinks) {
    val primary = MaterialTheme.colorScheme.primary
    val avg = r.ratingAvg
    RecapCard(
        "Distribution by rating",
        trailing = if (avg != null) "average ${"%.1f".format(avg)} \u2605" else null,
        onTap = { links.shelf("rated") },
    ) {
        Lollipops(r.ratingCounts, primary)
        Text(
            "${countText(r.ratedCount, "book", "books")} you read this month ${if (r.ratedCount == 1) "has" else "have"} a rating.",
            modifier = Modifier.padding(top = 6.dp), color = pbTokens().setSub, fontSize = 12.sp,
        )
    }
}

// ---- who and what ---------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PeopleCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    @Composable
    fun Group(title: String, items: List<com.paperback.app.data.RecapName>, onTap: (String) -> Unit) {
        if (items.isEmpty()) return
        Text(title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items.forEach { n ->
                Row(
                    Modifier
                        .heightIn(min = 40.dp)
                        .clip(RoundedCornerShape(99.dp))
                        .background(t.asOn)
                        .semantics(mergeDescendants = true) { contentDescription = "${n.name}, ${Stats.duration(n.seconds)}. Open." }
                        .clickable(onClickLabel = "Open", role = Role.Button) { onTap(n.name) }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(n.name, color = t.ink, fontSize = 14.sp)
                    Text(" ${Stats.duration(n.seconds)}", color = t.setSub, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
    RecapCard("Authors, genres & languages") {
        Group("Authors you read most", r.authors) { links.author(it) }
        Group("Genres", r.genres) { links.tag(it) }
        Group("Languages", r.languages) { links.shelf("langs") }
    }
}

// ---- against last month ---------------------------------------------------------------------

@Composable
private fun CompareCard(r: Recap) {
    val t = pbTokens()
    RecapCard("Against ${r.prevName}") {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            r.compare.forEach { s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(s.label, modifier = Modifier.weight(1f), color = t.ink, fontSize = 15.sp)
                    Column(horizontalAlignment = Alignment.End) {
                        Text(statText(s, s.cur), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("was ${statText(s, s.prev)}", color = t.setSub, fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    DeltaChip(s)
                }
            }
        }
        if (r.inProgress) {
            Text(
                "${recapTitle(r.month)} is compared with the same days of ${r.prevName}.",
                modifier = Modifier.padding(top = 12.dp), color = t.setSub, fontSize = 12.sp,
            )
        }
    }
}

private fun statText(s: RecapStat, v: Long): String = if (s.isTime) Stats.duration(v) else commas(v.toInt())

@Composable
private fun DeltaChip(s: RecapStat) {
    val t = pbTokens()
    val pct = s.pct
    val (text, color) = when {
        pct != null && pct > 0 -> "+$pct%" to inkOf(StatsAccent.Mint)
        pct != null && pct < 0 -> "\u2212${abs(pct)}%" to inkOf(StatsAccent.Pink)
        pct != null -> "same" to t.setSub
        s.cur > 0 -> "new" to inkOf(StatsAccent.Blue)
        else -> "\u2013" to t.setSub
    }
    Text(
        text,
        modifier = Modifier.width(64.dp).clip(RoundedCornerShape(99.dp)).background(color.copy(alpha = 0.14f)).padding(vertical = 4.dp),
        color = color,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center,
        maxLines = 1,
    )
}

// ---- share ----------------------------------------------------------------------------------

@Composable
private fun ShareCard(r: Recap, links: RecapLinks) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        PbButton("Share this recap", onClick = { links.share(recapShareText(r)) })
        Text(
            "Shares a short summary as text: the month's numbers and the books you read most.",
            modifier = Modifier.padding(start = 4.dp, top = 8.dp),
            color = t.setSub,
            fontSize = 12.sp,
        )
    }
}
