package com.paperback.app.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.MoreStyle
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.pbTokens

private class MoreItem(val name: String, val icon: PbIconName, val dest: Dest?)
private class MoreGroup(val key: String, val title: String, val icon: PbIconName, val items: List<MoreItem>)

// Paperback's other pages, in five groups (the old "All pages" list). A page with no destination is still to be built.
private val MORE_GROUPS = listOf(
    MoreGroup(
        "reading", "Reading", PbIconName.Book,
        listOf(
            MoreItem("Currently reading", PbIconName.Book, Dest.Reading),
            MoreItem("Recently read", PbIconName.Clock, Dest.Recent),
            MoreItem("Finished", PbIconName.Check, Dest.Finished),
            MoreItem("Authors", PbIconName.Person, Dest.Authors),
        ),
    ),
    MoreGroup(
        "notes", "Your notes", PbIconName.Note,
        listOf(
            MoreItem("Notes & highlights", PbIconName.Note, Dest.Notes),
            MoreItem("Bookmarks", PbIconName.Bookmark, Dest.Bookmarks),
            MoreItem("Search", PbIconName.Search, Dest.Search),
            MoreItem("Dictionary", PbIconName.Dictionary, Dest.Dictionary),
        ),
    ),
    MoreGroup(
        "shelves", "Shelves", PbIconName.Collections,
        listOf(
            MoreItem("Favorites", PbIconName.Heart, Dest.Favorites),
            MoreItem("Want to read", PbIconName.ListPlus, Dest.WantToRead),
            MoreItem("Collections", PbIconName.Collections, Dest.Collections),
            MoreItem("Genres", PbIconName.Tag, Dest.Genres),
        ),
    ),
    MoreGroup(
        "get", "Get books", PbIconName.Discover,
        listOf(
            MoreItem("Discover", PbIconName.Discover, Dest.Discover),
            MoreItem("Import", PbIconName.ImportFile, Dest.Import),
        ),
    ),
    MoreGroup(
        "app", "App", PbIconName.Settings,
        listOf(
            MoreItem("Reading history", PbIconName.History, Dest.Stats),
            MoreItem("Settings", PbIconName.Settings, Dest.Settings),
            MoreItem("Backup & restore", PbIconName.Backup, Dest.Backup),
            MoreItem("About", PbIconName.About, Dest.About),
        ),
    ),
)

/**
 * "More": every other page of the app, in the layout chosen in App style: Accordion (five group cards, one open
 * at a time, and a field that finds a page by name) or Bento (tiles, shelf spines and a short list).
 * The title comes from the shared page header, like every other screen.
 */
@Composable
fun MoreScreen(
    headerSize: HeaderSize,
    moreStyle: MoreStyle,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onGo: (Dest) -> Unit,
    onSoon: () -> Unit,
) {
    val t = pbTokens()
    var open by rememberSaveable { mutableStateOf("reading") }
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim()
    val matches = remember(q) {
        if (q.isEmpty()) emptyList() else MORE_GROUPS.flatMap { it.items }.filter { it.name.contains(q, ignoreCase = true) }
    }
    val go: (MoreItem) -> Unit = { item ->
        val d = item.dest
        if (d == null) onSoon() else onGo(d)
    }

    if (moreStyle == MoreStyle.Bento) {
        PbPage("More", headerSize, onMenu, onSearch, headerGap = 4.dp) {
            BentoContent(go)
        }
        return
    }

    PbPage("More", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        PbField(value = query, onValueChange = { query = it }, placeholder = "Find a page", leading = PbIconName.Search, onClear = { query = "" })
        Spacer(Modifier.height(16.dp))
        when {
            q.isEmpty() -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MORE_GROUPS.forEach { group ->
                    MoreCard(
                        group = group,
                        expanded = open == group.key,
                        onToggle = { open = if (open == group.key) "" else group.key },
                        onItem = go,
                    )
                }
            }
            matches.isEmpty() -> Text("Nothing matches.", color = t.setSub, modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp))
            else -> Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card)) {
                matches.forEachIndexed { i, item ->
                    if (i > 0) CardDivider(startInset = 60.dp)
                    MoreRow(item, startPadding = 16.dp, onClick = { go(item) })
                }
            }
        }
    }
}

@Composable
private fun MoreCard(group: MoreGroup, expanded: Boolean, onToggle: () -> Unit, onItem: (MoreItem) -> Unit) {
    val t = pbTokens()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(t.card)
            .animateContentSize(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clickable(onClick = onToggle)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(t.asSelBg), contentAlignment = Alignment.Center) {
                PbIcon(group.icon, size = 21.dp, tint = t.ink)
            }
            Column(Modifier.weight(1f)) {
                Text(group.title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                Text("${group.items.size} pages", color = t.setSub, fontSize = 13.sp, maxLines = 1)
            }
            PbIcon(
                if (expanded) PbIconName.CaretUp else PbIconName.CaretDown,
                size = 18.dp,
                tint = if (expanded) t.ink else t.setSub,
                strokeWidth = 2f,
                contentDescription = if (expanded) "Collapse ${group.title}" else "Expand ${group.title}",
            )
        }
        if (expanded) {
            group.items.forEach { item ->
                CardDivider(startInset = 70.dp)
                MoreRow(item, startPadding = 26.dp, onClick = { onItem(item) })
            }
        }
    }
}

/** One page: icon, name, "Soon" if it is not built yet, and a caret. [startPadding] lines the icon up under the group's icon. */
@Composable
private fun MoreRow(item: MoreItem, startPadding: Dp, onClick: () -> Unit, height: Dp = 52.dp) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .height(height)
            .clickable(onClick = onClick)
            .padding(start = startPadding, end = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PbIcon(item.icon, size = 20.dp, tint = t.ink)
        Spacer(Modifier.width(24.dp))
        Text(
            item.name,
            modifier = Modifier.weight(1f),
            color = t.ink,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (item.dest == null) {
            Text("Soon", color = t.setSub, fontSize = 12.sp)
            Spacer(Modifier.width(10.dp))
        }
        PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub, strokeWidth = 2f)
    }
}

// ---- Bento --------------------------------------------------------------------------------------------

private fun moreItem(name: String): MoreItem = MORE_GROUPS.flatMap { it.items }.first { it.name == name }

@Composable
private fun BentoLabel(text: String) {
    Text(
        text,
        modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 20.dp, bottom = 8.dp),
        color = pbTokens().setSub,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = 0.14.em,
    )
}

/** Bento: a big Currently reading tile and three small ones, notes in a 2 x 2 grid, shelves as spines on a plank, Discover and Import, then the app pages as a list. */
@Composable
private fun BentoContent(onItem: (MoreItem) -> Unit) {
    val t = pbTokens()
    val dark = t.bg.luminance() < 0.5f
    val accent = Accent.color
    val onAccent = Accent.onAccent()

    BentoLabel("READING")
    val current = moreItem("Currently reading")
    Row(
        Modifier
            .fillMaxWidth()
            .height(80.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(t.goalCard)
            .clickable { onItem(current) }
            .padding(start = 16.dp, end = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
            PbIcon(current.icon, size = 24.dp, tint = onAccent)
        }
        Column(Modifier.weight(1f)) {
            Text("Currently reading", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text("Pick up where you left off", color = Color(0xFFC4C4C4), fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
        }
        PbIcon(PbIconName.CaretRight, size = 22.dp, tint = Color.White, strokeWidth = 2f)
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf("Recently read", "Finished", "Authors").forEach { name ->
            val item = moreItem(name)
            BentoSmallTile(item) { onItem(item) }
        }
    }

    BentoLabel("YOUR NOTES")
    listOf(listOf("Notes & highlights", "Bookmarks"), listOf("Search", "Dictionary")).forEachIndexed { r, pair ->
        if (r > 0) Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            pair.forEach { name ->
                val item = moreItem(name)
                BentoNoteTile(item) { onItem(item) }
            }
        }
    }

    BentoLabel("SHELVES")
    val spineA = if (dark) Color(0xFF2C2C2C) else Color(0xFFD9D9D9)
    val spineB = if (dark) Color(0xFF222222) else Color(0xFFECECEC)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
        BentoSpine(moreItem("Favorites"), 128.dp, accent, onAccent) { onItem(moreItem("Favorites")) }
        BentoSpine(moreItem("Want to read"), 108.dp, t.goalCard, Color.White) { onItem(moreItem("Want to read")) }
        BentoSpine(moreItem("Collections"), 120.dp, spineA, t.ink) { onItem(moreItem("Collections")) }
        BentoSpine(moreItem("Genres"), 100.dp, spineB, t.ink) { onItem(moreItem("Genres")) }
    }
    Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFFC9A56E)))

    BentoLabel("GET BOOKS")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        val discover = moreItem("Discover")
        val importItem = moreItem("Import")
        BentoGetTile(discover, "Free books online", filled = true) { onItem(discover) }
        BentoGetTile(importItem, "EPUB or PDF", filled = false) { onItem(importItem) }
    }

    BentoLabel("APP")
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(t.card)) {
        listOf("Reading history", "Settings", "Backup & restore", "About").forEachIndexed { i, name ->
            val item = moreItem(name)
            if (i > 0) CardDivider(startInset = 60.dp)
            MoreRow(item, startPadding = 16.dp, onClick = { onItem(item) }, height = 48.dp)
        }
    }
}

@Composable
private fun RowScope.BentoSmallTile(item: MoreItem, onClick: () -> Unit) {
    val t = pbTokens()
    Column(
        Modifier
            .weight(1f)
            .height(88.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        PbIcon(item.icon, size = 22.dp, tint = t.ink)
        Text(item.name, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, lineHeight = 17.sp, maxLines = 2)
    }
}

@Composable
private fun RowScope.BentoNoteTile(item: MoreItem, onClick: () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .weight(1f)
            .height(60.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(t.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(t.bg), contentAlignment = Alignment.Center) {
            PbIcon(item.icon, size = 19.dp, tint = t.ink)
        }
        Column(Modifier.weight(1f)) {
            Text(item.name, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, lineHeight = 17.sp, maxLines = 2)
            if (item.dest == null) Text("Soon", color = t.setSub, fontSize = 12.sp)
        }
    }
}

@Composable
private fun RowScope.BentoSpine(item: MoreItem, height: Dp, bg: Color, ink: Color, onClick: () -> Unit) {
    Column(
        Modifier
            .weight(1f)
            .height(height)
            .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 4.dp, bottomEnd = 4.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        PbIcon(item.icon, size = 22.dp, tint = ink)
        Text(item.name, color = ink, fontSize = 12.sp, fontWeight = FontWeight.Medium, lineHeight = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun RowScope.BentoGetTile(item: MoreItem, sub: String, filled: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    val accent = Accent.color
    val ink = if (filled) Accent.onAccent() else t.ink
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier
            .weight(1f)
            .height(64.dp)
            .clip(shape)
            .then(if (filled) Modifier.background(accent) else Modifier.background(t.bg).border(2.dp, t.ink, shape))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        PbIcon(item.icon, size = 24.dp, tint = ink)
        Column {
            Text(item.name, color = ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(sub, color = if (filled) ink.copy(alpha = 0.8f) else t.setSub, fontSize = 12.sp, maxLines = 1)
        }
    }
}
