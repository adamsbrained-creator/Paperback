package com.paperback.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats

/**
 * A page inside the book's page: how far you are, the time you read, the timer, and every reading entry.
 * Pages and progress follow the entries and the timer too, not only reading inside Paperback.
 */
@Composable
fun BookProgressScreen(
    book: Book,
    sessions: List<ReadingSession>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    timerRunning: Boolean,
    onStartTimer: () -> Unit,
    onAddEntry: () -> Unit,
    onEditEntry: (ReadingSession) -> Unit,
    /** All your books, notes and bookmarks: for the finished-book card and the highlight strip. */
    books: List<Book> = emptyList(),
    highlights: List<com.paperback.app.data.Highlight> = emptyList(),
    bookmarks: List<com.paperback.app.data.Bookmark> = emptyList(),
    onShare: (String) -> Unit = {},
    /** Opens the reader at a saved place (a bookmark): the book and the place's locator. */
    onOpenAt: (Book, String) -> Unit = { _, _ -> },
    /** The dictionary: saved words and look-ups, for this book's words card. */
    savedWords: List<com.paperback.app.data.SavedWord> = emptyList(),
    lookups: List<com.paperback.app.data.WordLookup> = emptyList(),
) {
    val mine = remember(sessions, book.id) { sessions.filter { it.bookId == book.id } }
    val seconds = mine.sumOf { it.seconds.toLong() }

    PbPage("Progress", headerSize, onMenu, onSearch, headerGap = 8.dp) {
        Text(
            book.title.uppercase(),
            color = MaterialTheme.colorScheme.primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        SectionLabel("This book")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Progress", "${book.percent}%", Modifier.weight(1f))
            StatTile("Time read", Stats.duration(seconds), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(
                "Page",
                if (book.pageCount > 0) "${book.currentPage} / ${book.pageCount}" else "—",
                Modifier.weight(1f),
            )
            StatTile("Sessions", "${mine.size}", Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        if (book.pageCount <= 0) {
            PbNote("This book has no page count yet, so entries can't move its progress. Set the page count with Edit on the book's page and your pages will count.")
            Spacer(Modifier.height(8.dp))
        }
        PbNote("Entries and the timer move your page and progress forward, just like reading in Paperback does. To change the page count or set your page by hand, use Edit on the book's page.")

        if (mine.any { it.seconds > 0 || it.pages > 0 }) {
            SectionLabel("How you read it")
            BookInsightsCard(book, mine)
        }

        val myWords = remember(savedWords, book.id) { savedWords.filter { it.bookId == book.id } }
        val myLookups = remember(lookups, book.id) { lookups.count { it.bookId == book.id } }
        if (myWords.isNotEmpty() || myLookups > 0) {
            SectionLabel("Words")
            BookWordsCard(book, mine, myWords, myLookups, books)
        }

        if (book.finished) {
            val zone = remember { java.time.ZoneId.systemDefault() }
            val fin = remember(book, sessions, books, highlights) {
                com.paperback.app.data.finishedFigures(book, sessions, books, highlights, zone)
            }
            if (fin != null) {
                SectionLabel("Finished")
                FinishedBookCard(book, fin, onShare)
            }
        }

        val myMarks = remember(highlights, book.id) { highlights.filter { it.bookId == book.id } }
        val myBookmarks = remember(bookmarks, book.id) { bookmarks.filter { it.bookId == book.id } }
        if (myMarks.isNotEmpty() || myBookmarks.isNotEmpty()) {
            SectionLabel("Highlights and bookmarks")
            BookMarksCard(book, myMarks, myBookmarks, sessions, onOpenAt = { place -> onOpenAt(book, place) })
        }

        SectionLabel("Reading time")
        ReadingActions(timerRunning, onStartTimer, onAddEntry)
        Spacer(Modifier.height(14.dp))
        ReadingHistory(mine, onEditEntry)
        Spacer(Modifier.height(24.dp))
    }
}
