package com.paperback.app.ui

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.paperback.app.data.Book
import com.paperback.app.data.HeaderSize

/** A simple page of covers: Currently reading, Recently read, Finished, Favorites. Tap a cover for the book page. */
@Composable
fun ShelfScreen(
    label: String,
    books: List<Book>,
    emptyText: String,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenBook: (Book) -> Unit,
    /** Something above the books (an author's numbers, say). */
    top: @Composable () -> Unit = {},
) {
    PbListPage(label, headerSize, onMenu, onSearch) {
        top()
        if (books.isEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(emptyText, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
        } else {
            CoverGrid(books, onOpenBook, Modifier.weight(1f))
        }
    }
}
