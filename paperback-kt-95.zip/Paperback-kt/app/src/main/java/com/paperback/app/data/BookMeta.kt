package com.paperback.app.data

import com.paperback.app.catalog.Taste
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.opds.OpdsText

/*
 * What Paperback knows about a book beyond its title: genres / tags, description, publisher, date.
 * Everything here is plain Kotlin (no Android), so it can be tested on its own.
 */

/** Extra facts about a book that a catalog already told us (Discover), used when the file itself says nothing. */
class ImportHints(
    val subjects: List<String> = emptyList(),
    val description: String? = null,
    val publisher: String? = null,
    val published: String? = null,
    /** Where the book came from ("file", "gutenberg", "standardebooks", "reflow", a catalog's name...); null = "file". */
    val source: String? = null,
)

/** The book facts read from a file (and the catalog), ready to store. */
class BookExtras(
    val tags: List<String>,
    val description: String,
    val publisher: String,
    val published: String,
)

object Tags {
    /** Words some catalogs use as a "subject" that say nothing about what the book is about. */
    private val noise = setOf(
        "text", "sound", "image", "dataset", "software", "collection", "service", "event",
        "moving image", "still image", "interactive resource", "physical object", "ebook", "e-book",
    )
    private val code = Regex("^[A-Z]{3}[0-9]{6}$|^[0-9][0-9. /-]*$")

    /**
     * Turns the raw subject lines of a book into short, clean tags.
     *  - "England -- Fiction" becomes two tags, "England" and "Fiction" (Project Gutenberg writes them that way)
     *  - lines with a colon ("LoCC: Language and Literatures"), subject codes and words like "Text" are dropped
     *  - the same tag in different capitals counts once; the first spelling is kept
     */
    fun clean(raw: List<String>, max: Int = 16): List<String> {
        val seen = LinkedHashMap<String, String>()
        for (line in raw) {
            for (piece in line.split(" -- ", "--", ";", "\n", "|")) {
                var s = piece.replace(Regex("\\s+"), " ").trim().trimEnd('.', ',', ' ')
                if (s.length < 2 || s.length > 40) continue
                if (s.contains(':')) continue
                if (code.matches(s)) continue
                val key = s.lowercase()
                if (key in noise) continue
                if (s[0].isLowerCase()) s = s.replaceFirstChar { it.uppercaseChar() }
                if (!seen.containsKey(key)) seen[key] = s
                if (seen.size >= max) return seen.values.toList()
            }
        }
        return seen.values.toList()
    }

    /** tag -> books that have it, most books first, then A to Z. */
    fun counts(books: List<Book>): List<Pair<String, Int>> {
        val map = LinkedHashMap<String, Pair<String, Int>>()
        for (b in books) for (t in b.tags) {
            val key = t.lowercase()
            val cur = map[key]
            map[key] = if (cur == null) t to 1 else cur.first to (cur.second + 1)
        }
        return map.values.sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first.lowercase() })
    }

    fun has(book: Book, tag: String): Boolean = book.tags.any { it.equals(tag, ignoreCase = true) }
}

object Authors {
    /** author -> number of books, most books first, then A to Z. Books with no author are left out. */
    fun counts(books: List<Book>): List<Pair<String, Int>> {
        val map = LinkedHashMap<String, Pair<String, Int>>()
        for (b in books) {
            val name = b.author.trim()
            if (name.isEmpty()) continue
            val key = name.lowercase()
            val cur = map[key]
            map[key] = if (cur == null) name to 1 else cur.first to (cur.second + 1)
        }
        return map.values.sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first.lowercase() })
    }

    /** True when [author] is the book's author, or one of them ("A; B" and "A & B" have two). */
    fun has(book: Book, author: String): Boolean {
        val want = author.trim()
        return book.author.trim().equals(want, ignoreCase = true) ||
            splitAuthors(book.author).any { it.equals(want, ignoreCase = true) }
    }
}

object BookText {
    private val summaryPart = Regex("Summary:\\s*(.+?)(?:\\n\\s*\\n[A-Z][A-Za-z ]{2,30}:|\\z)", RegexOption.DOT_MATCHES_ALL)
    private val autoNote = Regex("\\s*\\(This is an automatically generated summary\\.\\)", RegexOption.IGNORE_CASE)

    /**
     * A description as plain text. Project Gutenberg's "description" is the whole catalogue record (title, notes,
     * credits, reading level...); when it has a Summary part, only that part is kept.
     */
    fun description(raw: String?): String {
        val plain = OpdsText.plain(raw)
        if (plain.isEmpty()) return ""
        val found = summaryPart.find(plain)?.groupValues?.get(1)?.let { autoNote.replace(it, "").trim() }
        return if (!found.isNullOrEmpty()) found else plain
    }

    /** "1998-06-01T00:00:00Z" -> "1998-06-01"; anything else is kept as it is. */
    fun date(raw: String?): String {
        val s = raw?.trim().orEmpty()
        return if (Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}.*").matches(s)) s.take(10) else s
    }
}

/** Ways to order the Library. */
enum class BookSort(val label: String) {
    Added("Recently added"),
    Opened("Recently read"),
    Title("Title"),
    Author("Author"),
    Rating("Rating"),
    Progress("Progress"),
    Custom("My order"),
    ;

    fun apply(books: List<Book>): List<Book> = when (this) {
        Added -> books.sortedByDescending { it.addedAt }
        Opened -> books.sortedWith(compareByDescending<Book> { it.lastOpenedAt }.thenByDescending { it.addedAt })
        Title -> books.sortedBy { it.title.lowercase() }
        Author -> books.sortedWith(compareBy<Book> { it.author.isBlank() }.thenBy { it.author.lowercase() }.thenBy { it.title.lowercase() })
        Rating -> books.sortedWith(compareByDescending<Book> { it.rating10 }.thenBy { it.title.lowercase() })
        Progress -> books.sortedWith(compareByDescending<Book> { it.progress }.thenBy { it.title.lowercase() })
        // books you placed come first, in your order; the rest follow, newest first
        Custom -> books.sortedWith(compareBy<Book> { it.shelfOrder == 0 }.thenBy { it.shelfOrder }.thenByDescending { it.addedAt })
    }
}

/** A suggested [book] from your library; [because] is the book of yours behind it, [note] replaces "Because you liked ...". */
class Recommendation(val book: Book, val because: Book, val note: String? = null)

/** "Books like this one" and "Recommended for you", worked out only from your own library. */
object Similar {
    /** How alike two books are: shared tags (as a share of all their tags) and the same author. 0 = nothing in common. */
    fun score(a: Book, b: Book): Double {
        var s = 0.0
        val ta = a.tags.map { it.lowercase() }.toSet()
        val tb = b.tags.map { it.lowercase() }.toSet()
        if (ta.isNotEmpty() && tb.isNotEmpty()) {
            val shared = ta.intersect(tb).size
            if (shared > 0) s += 3.0 * shared / ta.union(tb).size
        }
        if (a.author.isNotBlank() && Authors.has(a, b.author)) s += 2.0
        return s
    }

    fun like(book: Book, books: List<Book>, limit: Int = 12): List<Book> =
        books.asSequence()
            .filter { it.id != book.id }
            .map { it to score(book, it) }
            .filter { it.second > 0.0 }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
            .toList()

    /**
     * How much a book you have already read tells us you like this kind of book. [shift] moves your ratings to
     * where most people's sit (see [Taste.ratingShift]); [pace] is how fast you read it, for a book you never rated.
     */
    private fun taste(b: Book, shift: Double, pace: Double?, mark: Double = 0.0): Double {
        if (b.status == BookStatus.DROPPED) return 0.0
        var w = mark // many highlights for its length: it spoke to you
        if (b.rating > 0) {
            val r = b.rating + shift
            if (r < 2.5) return 0.0 // you did not like it
            w += if (r >= 3.5) 3.0 else 1.0
        }
        if (b.favorite) w += 2.0
        if (b.finished && b.rating == 0) {
            w += 1.0
            if (pace != null && pace >= 1.5) w += 1.0 else if (pace != null && pace <= 0.5) w -= 0.4
        }
        return w
    }

    /** How far your own ratings sit from the usual: a generous rater's 4 stars count for less. */
    private fun ratingShiftOf(books: List<Book>): Double {
        val rated = books.filter { it.rating > 0 }
        if (rated.isEmpty()) return 0.0
        return Taste.ratingShift(rated.map { it.rating }.average(), rated.size)
    }

    /** How well a book's era and length fit the books you like, 0 to 1; -1 when there is nothing to compare. */
    private fun fitOf(c: Book, taste: Taste): Double {
        val parts = listOf(taste.eraFit(Implicit.yearOf(c.published)), taste.lengthFit(c.pageCount)).filter { it >= 0.0 }
        return if (parts.isEmpty()) -1.0 else parts.average()
    }

    /**
     * The next unread book of each series you are working through: the one after the last you finished, as long
     * as you did not rate that one low and are not reading another of the series. The series you read last first.
     */
    fun nextInSeries(books: List<Book>, hidden: Set<String> = emptySet()): List<Recommendation> {
        val out = ArrayList<Pair<Recommendation, Long>>()
        val groups = books.filter { it.series.isNotBlank() && it.seriesNo > 0f }.groupBy { it.series.trim().lowercase() }
        for (group in groups.values) {
            val last = group.filter { it.finished }.maxByOrNull { it.seriesNo } ?: continue
            if (last.rating in 1..2) continue
            if (group.any { !it.finished && it.isReading && it.status != BookStatus.DROPPED }) continue
            val next = group
                .filter { !it.finished && it.seriesNo > last.seriesNo && it.status != BookStatus.DROPPED && it.id !in hidden }
                .minByOrNull { it.seriesNo } ?: continue
            out += Recommendation(next, last, "Next in ${next.series.trim()}") to maxOf(last.finishedAt, last.lastOpenedAt)
        }
        return out.sortedByDescending { it.second }.map { it.first }
    }

    /** Books you have not started, ranked by how much they resemble what you rated high, favorited or finished. */
    fun recommend(
        books: List<Book>,
        limit: Int = 10,
        hidden: Set<String> = emptySet(),
        /** How many highlights you made in each book (see [Implicit.highlightCounts]). */
        marks: Map<String, Int> = emptyMap(),
    ): List<Recommendation> {
        val next = nextInSeries(books, hidden)
        val shift = ratingShiftOf(books)
        val paces = Implicit.paceRatios(books)
        val liked = books.map { it to taste(it, shift, paces[it.id], Implicit.markBoost(marks[it.id] ?: 0, it.pageCount)) }.filter { it.second > 0.0 }
        if (liked.isEmpty()) return next.take(limit)
        val profile = CatalogController.tasteOf(books)
        val out = ArrayList<Pair<Recommendation, Double>>()
        val taken = next.map { it.book.id }.toSet()
        for (c in books) {
            if (c.finished || c.isReading || c.lastOpenedAt > 0L || c.id in hidden || c.id in taken) continue
            var total = 0.0
            var best: Book? = null
            var bestGain = 0.0
            for ((l, w) in liked) {
                if (l.id == c.id) continue
                val gain = w * score(c, l)
                total += gain
                if (gain > bestGain) {
                    bestGain = gain
                    best = l
                }
            }
            // a little more for a book of the era and the length you like, a little less for one that is not
            val fit = fitOf(c, profile)
            if (fit >= 0.0) total *= 0.85 + 0.3 * fit
            if (total > 0.0 && best != null) out += Recommendation(c, best) to total
        }
        return (next + out.sortedByDescending { it.second }.map { it.first }).take(limit)
    }

    /** An unread book of your library that [pickNext] suggests, with a short reason. */
    class NextPick(val book: Book, val why: String)

    /** The part of the day an hour belongs to: 0 morning, 1 afternoon, 2 evening, 3 night. */
    private fun dayPart(hour: Int): Int = when (hour) {
        in 5..10 -> 0
        in 11..16 -> 1
        in 17..21 -> 2
        else -> 3
    }

    private val dayPartNames = listOf("mornings", "afternoons", "evenings", "nights")

    /**
     * How much more of the time you read in some situation went to books with a given tag than of all your reading,
     * as a way to score a book for that situation (0 to 1, by its best tag). Null until at least [minSeconds] of
     * reading were in that situation. [inContext] says which sessions are in it.
     */
    private fun contextFit(
        books: List<Book>,
        sessions: List<ReadingSession>,
        minSeconds: Long,
        inContext: (ReadingSession) -> Boolean,
    ): ((Book) -> Double)? {
        val byId = books.associateBy { it.id }
        val ctx = HashMap<String, Long>()
        val all = HashMap<String, Long>()
        var ctxTotal = 0L
        var allTotal = 0L
        for (s in sessions) {
            if (s.seconds <= 0) continue
            val b = byId[s.bookId] ?: continue
            val tags = b.tags.map { it.lowercase() }.toSet()
            if (tags.isEmpty()) continue
            allTotal += s.seconds
            for (t in tags) all[t] = (all[t] ?: 0L) + s.seconds
            if (inContext(s)) {
                ctxTotal += s.seconds
                for (t in tags) ctx[t] = (ctx[t] ?: 0L) + s.seconds
            }
        }
        if (ctxTotal < minSeconds || allTotal <= ctxTotal) return null
        return { c ->
            val tags = c.tags.map { it.lowercase() }.toSet()
            val lift = tags.maxOfOrNull { t ->
                (ctx[t] ?: 0L).toDouble() / ctxTotal - (all[t] ?: 0L).toDouble() / allTotal
            } ?: 0.0
            lift.coerceIn(0.0, 0.5) * 2.0
        }
    }

    /**
     * Which book of your library to start next. Unlike [recommend] it always has an answer: books like the ones
     * you liked rank first, then the next of a series you are in, books of the length and era you like, and books
     * that have waited longest. Only books with a file, that you have not opened, and did not hide.
     *
     * With [sessions] it also learns from when and in what mood you read: [hour] (0 to 23, -1 = ignore) favors books
     * like the ones you read at that time of day, and [mood] (a [SessionMood], 0 = any) books like the ones you
     * read in that mood. Each only once there is about half an hour of reading to learn from.
     */
    fun pickNext(
        books: List<Book>,
        hidden: Set<String> = emptySet(),
        limit: Int = 5,
        marks: Map<String, Int> = emptyMap(),
        sessions: List<ReadingSession> = emptyList(),
        mood: Int = 0,
        hour: Int = -1,
    ): List<NextPick> {
        val shift = ratingShiftOf(books)
        val paces = Implicit.paceRatios(books)
        val liked = books.map { it to taste(it, shift, paces[it.id], Implicit.markBoost(marks[it.id] ?: 0, it.pageCount)) }
            .filter { it.second > 0.0 }
        val profile = CatalogController.tasteOf(books)
        val series = nextInSeries(books, hidden).associateBy { it.book.id }
        val part = if (hour in 0..23) dayPart(hour) else -1
        val timeFit = if (part >= 0) contextFit(books, sessions, 1800L) { dayPart(java.time.Instant.ofEpochMilli(it.startMs).atZone(java.time.ZoneId.systemDefault()).hour) == part } else null
        val moodFit = if (mood > 0) contextFit(books, sessions, 1200L) { it.mood == mood } else null
        val now = System.currentTimeMillis()
        val out = ArrayList<Triple<Book, Double, String>>()
        for (c in books) {
            if (!c.hasFile || c.finished || c.isReading || c.lastOpenedAt > 0L) continue
            if (c.status == BookStatus.DROPPED || c.id in hidden) continue
            var total = 0.0
            var bestGain = 0.0
            var why = ""
            for ((l, w) in liked) {
                if (l.id == c.id) continue
                val gain = w * score(c, l)
                total += gain
                if (gain > bestGain) {
                    bestGain = gain
                    why = "Because you liked ${l.title}"
                }
            }
            // many liked books should not drown the other signs
            total = Math.log1p(total) * 1.5
            val inSeries = series[c.id]
            if (inSeries != null) {
                total += 4.0
                why = inSeries.note ?: why
            }
            val len = profile.lengthFit(c.pageCount)
            if (len >= 0.0) {
                total += len - 0.5
                if (len > 0.85 && why.isEmpty()) why = "About the length you like"
            }
            val era = profile.eraFit(Implicit.yearOf(c.published))
            if (era >= 0.0) total += 0.6 * (era - 0.5)
            // when and how you read: books like the ones you read in this part of the day / this mood
            var fits = ""
            val tf = timeFit?.invoke(c) ?: 0.0
            if (tf > 0.0) {
                total += tf
                if (tf >= 0.4) fits = "fits your ${dayPartNames[part]}"
            }
            val mf = moodFit?.invoke(c) ?: 0.0
            if (mf > 0.0) {
                total += 2.0 * mf
                if (mf >= 0.4) fits = "suits a ${SessionMood.name(mood).lowercase()} mood"
            }
            val waited = ((now - c.addedAt) / 86_400_000L).coerceAtLeast(0L)
            total += 0.5 * minOf(1.0, waited / 365.0) // what has waited longest gets a nudge
            if (why.isEmpty()) why = if (waited > 60L) "It has been waiting on your shelf" else "New on your shelf"
            if (fits.isNotEmpty()) why = "$why · $fits"
            out += Triple(c, total, why)
        }
        return out.sortedByDescending { it.second }.take(limit).map { NextPick(it.first, it.third) }
    }

    /** A book of your library worth reading again, with a line on why. */
    class Reread(val book: Book, val note: String)

    /**
     * Books you finished a long time ago (at least 18 months) and loved (4 or 5 stars, or a favorite) that you have
     * not opened for half a year: the best loved and the longest ago first. Only books with a file.
     */
    fun rereads(
        books: List<Book>,
        hidden: Set<String> = emptySet(),
        limit: Int = 8,
        nowMs: Long = System.currentTimeMillis(),
    ): List<Reread> {
        val day = 86_400_000L
        val out = ArrayList<Pair<Reread, Double>>()
        for (b in books) {
            if (!b.finished || !b.hasFile || b.status == BookStatus.DROPPED || b.id in hidden || b.isReading) continue
            if (!(b.favorite || b.rating >= 4)) continue
            if (b.finishedAt <= 0L || (nowMs - b.finishedAt) / day < 540L) continue
            if (b.lastOpenedAt > 0L && (nowMs - b.lastOpenedAt) / day < 180L) continue
            val years = (nowMs - b.finishedAt) / (day * 365.0)
            val score = (if (b.rating == 5) 3.0 else if (b.rating == 4) 2.0 else 1.5) +
                (if (b.favorite) 1.5 else 0.0) + minOf(years, 6.0) * 0.4
            val ago = if (years < 2.0) "Finished over a year ago" else "Finished ${years.toInt()} years ago"
            val loved = if (b.rating > 0) " · ${b.rating} stars" else if (b.favorite) " · a favorite" else ""
            out += Reread(b, ago + loved) to score
        }
        return out.sortedByDescending { it.second }.take(limit).map { it.first }
    }
}
