package com.paperback.app.data

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import kotlin.math.abs

/*
 * The weekly summary notification: once a week (Sunday evening) a line about your week, Monday to Sunday, compared with the
 * week before. Plain functions: the time, the day and the zone are passed in.
 */

const val WEEKLY_SUMMARY_HOUR = 18

/** The next Sunday at [WEEKLY_SUMMARY_HOUR]:00 after [nowMs] (later today when it is Sunday and still before the hour). */
fun nextWeeklyAtMs(nowMs: Long, zone: ZoneId): Long {
    val now = Instant.ofEpochMilli(nowMs).atZone(zone)
    fun at(day: LocalDate) = day.atTime(WEEKLY_SUMMARY_HOUR, 0).atZone(zone).toInstant().toEpochMilli()
    val sunday = now.toLocalDate().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))
    val first = at(sunday)
    return if (first > nowMs) first else at(sunday.plusWeeks(1))
}

class WeeklyText(val title: String, val text: String)

/** The week's lines, or null (stay quiet) when you read nothing this week and nothing the week before. */
fun weeklySummary(rows: List<ReadingSession>, books: List<Book>, today: LocalDate, zone: ZoneId): WeeklyText? {
    val monday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val prevMonday = monday.minusWeeks(1)
    fun day(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    val thisWeek = rows.filter { day(it.startMs) >= monday && day(it.startMs) <= monday.plusDays(6) }
    val lastWeek = rows.filter { day(it.startMs) >= prevMonday && day(it.startMs) < monday }
    val secs = thisWeek.sumOf { it.seconds.toLong() }
    val prevSecs = lastWeek.sumOf { it.seconds.toLong() }
    if (secs <= 0L && prevSecs <= 0L) return null

    val daysRead = thisWeek.groupBy { day(it.startMs) }.count { (_, l) -> l.sumOf { it.seconds } >= 60 }
    val pages = thisWeek.sumOf { it.pages }
    val finished = books.count { b ->
        b.finished && b.finishedAt > 0L && day(b.finishedAt).let { it >= monday && it <= monday.plusDays(6) }
    }

    val title = if (secs > 0L) "Your week: ${Stats.duration(secs)} of reading" else "No reading this week"
    val parts = ArrayList<String>()
    if (secs > 0L) {
        val diff = secs - prevSecs
        parts.add(
            when {
                prevSecs <= 0L -> "$daysRead ${if (daysRead == 1) "day" else "days"} read"
                abs(diff) < 60L -> "Same as last week"
                diff > 0 -> "${Stats.duration(diff)} more than last week"
                else -> "${Stats.duration(-diff)} less than last week"
            },
        )
        if (prevSecs > 0L) parts.add("$daysRead ${if (daysRead == 1) "day" else "days"} read")
        if (pages > 0) parts.add("$pages pages")
        if (finished > 0) parts.add("$finished ${if (finished == 1) "book" else "books"} finished")
    } else {
        parts.add("Last week you read ${Stats.duration(prevSecs)}. A few minutes tomorrow starts a new week.")
    }
    return WeeklyText(title, parts.joinToString(" · "))
}
