package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.catalog.Taste
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.theme.pbTokens

/**
 * What Paperback has worked out about your taste, from your ratings, favorites, finished and dropped books,
 * highlights and reading pace. You can ask for less of a subject in the online suggestions, and bring back
 * the books you said "not interested" to. All of it is worked out on the phone.
 */
@Composable
fun TasteScreen(
    headerSize: HeaderSize,
    taste: Taste,
    muted: List<String>,
    hiddenCount: Int,
    onMute: (String) -> Unit,
    onUnmute: (String) -> Unit,
    onForgetHidden: () -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    val subjects = remember(taste) { taste.likedSubjects(8) }
    val authors = remember(taste) { taste.likedAuthors(6) }
    val era = remember(taste) { taste.eraRange() }
    val pages = remember(taste) { taste.typicalPages() }
    val strongest = subjects.maxOfOrNull { it.weight }?.takeIf { it > 0.0 } ?: 1.0

    PbListPage("Your taste", headerSize, onMenu, onSearch) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
            Text(
                "What Paperback has worked out from your ratings, favorites, finished and dropped books, highlights and " +
                    "reading pace. It stays on your phone; only a few subject and author names are used as search words.",
                color = t.setSub,
                fontSize = 14.sp,
                lineHeight = 20.sp,
            )

            if (subjects.isEmpty() && authors.isEmpty()) {
                Spacer(Modifier.height(24.dp))
                Text(
                    "Not enough yet. Rate, favorite or finish a few books and this fills in.",
                    color = t.ink,
                    fontSize = 16.sp,
                    lineHeight = 22.sp,
                )
            }

            if (subjects.isNotEmpty()) {
                Spacer(Modifier.height(26.dp))
                Eyebrow("Subjects you like")
                Spacer(Modifier.height(10.dp))
                subjects.forEach { s ->
                    TasteRow(
                        title = s.name,
                        detail = "${s.count} ${if (s.count == 1) "book" else "books"} · like ${s.because}",
                        fraction = (s.weight / strongest).toFloat().coerceIn(0.05f, 1f),
                        action = "Less of this",
                        onAction = { onMute(s.name) },
                    )
                }
            }

            if (authors.isNotEmpty()) {
                Spacer(Modifier.height(22.dp))
                Eyebrow("Authors you like")
                Spacer(Modifier.height(10.dp))
                authors.forEach { a ->
                    TasteRow(title = a.name, detail = "Because of ${a.because}", fraction = null, action = null, onAction = {})
                }
            }

            if (era != null || pages > 0) {
                Spacer(Modifier.height(22.dp))
                Eyebrow("Era and length")
                Spacer(Modifier.height(10.dp))
                if (era != null) {
                    Text("Mostly books from ${era[0]} to ${era[1]}", color = t.ink, fontSize = 16.sp, modifier = Modifier.padding(vertical = 4.dp))
                }
                if (pages > 0) {
                    Text("Usually about $pages pages", color = t.ink, fontSize = 16.sp, modifier = Modifier.padding(vertical = 4.dp))
                }
            }

            if (muted.isNotEmpty()) {
                Spacer(Modifier.height(22.dp))
                Eyebrow("Left out of online suggestions")
                Spacer(Modifier.height(10.dp))
                muted.forEach { name ->
                    TasteRow(title = name, detail = "No online book with this subject is suggested", fraction = null, action = "Allow", onAction = { onUnmute(name) })
                }
            }

            if (hiddenCount > 0) {
                Spacer(Modifier.height(22.dp))
                Eyebrow("Hidden suggestions")
                Spacer(Modifier.height(10.dp))
                TasteRow(
                    title = "$hiddenCount ${if (hiddenCount == 1) "book" else "books"} you said not interested to",
                    detail = "They also taught the suggestions a little about what you don't want",
                    fraction = null,
                    action = "Bring back",
                    onAction = onForgetHidden,
                )
            }
        }
    }
}

/** One line of the taste page: a title, a detail line, an optional bar for how strong it is, and an optional action. */
@Composable
private fun TasteRow(title: String, detail: String, fraction: Float?, action: String?, onAction: () -> Unit) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(detail, color = t.setSub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (fraction != null) {
                Spacer(Modifier.height(6.dp))
                ProgressTrack(fraction, height = 4.dp)
            }
        }
        if (action != null) {
            Spacer(Modifier.width(10.dp))
            Text(
                action,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onAction).padding(horizontal = 8.dp, vertical = 6.dp),
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}
