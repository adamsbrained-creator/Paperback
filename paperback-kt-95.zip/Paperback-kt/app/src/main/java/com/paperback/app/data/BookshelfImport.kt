package com.paperback.app.data

import com.paperback.app.catalog.TitleKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.util.Locale
import java.util.zip.ZipInputStream
import kotlin.math.abs

/*
 * Reads a Bookshelf library export (the zip of CSV files: books, entries, quotes, notes) and turns it into a
 * Paperback backup, which the normal restore then applies after you confirm. Nothing here touches the database.
 *
 * Safe to run again, and safe on top of an earlier import:
 *  - a book you already have (same id, or the same title) keeps everything it has; only the sessions and quotes it
 *    is missing are added;
 *  - a session is skipped when the book already has one within five minutes, or one on the same day of the same length;
 *  - a quote is skipped when the book already has a highlight with the same text.
 * Books on the "to read" or "wishlist" shelf (and nothing read in them) go to Want to read, unless you own them or
 * already have them there. The yearly book goal is taken over only while yours is still the default.
 */
class BookshelfResult(
    val json: String,
    val newBooks: Int,
    val sessions: Int,
    val quotes: Int,
    /** Books from the to-read shelf that went to Want to read. */
    val skippedShelf: Int,
    /** The yearly book goal taken from Bookshelf, null = left as it is. */
    val goalBooks: Int? = null,
)

object BookshelfImport {
    /** True when [bytes] look like a zip file (they start with "PK"). */
    fun isZip(bytes: ByteArray): Boolean = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()

    fun convert(
        bytes: ByteArray,
        books: List<Book>,
        sessions: List<ReadingSession>,
        highlights: List<Highlight>,
        zone: ZoneId = ZoneId.systemDefault(),
        wishlistTitles: Set<String> = emptySet(),
        goals: Goals = Goals(),
    ): Result<BookshelfResult> = runCatching {
        val tables = readTables(bytes)
        val rows = tables["books"] ?: error("That zip has no books.csv, so it is not a Bookshelf export.")

        val byTitle = books
        val haveSessions = sessions.groupBy { it.bookId }
        val haveText = highlights.groupBy { it.bookId }.mapValues { (_, l) -> l.map { it.text.trim() }.toHashSet() }

        val entries = tables["entries"].orEmpty()
        val quotes = tables["quotes"].orEmpty()
        val notes = tables["notes"].orEmpty()
        val readRefs = (entries.map { it["book_ref"].orEmpty() } + quotes.map { it["book_ref"].orEmpty() } + notes.map { it["book_ref"].orEmpty() }).toHashSet()

        val idOf = HashMap<String, String>()      // book_ref -> Paperback id
        val isNew = HashMap<String, Boolean>()    // book_ref -> created by this import
        val booksJson = JSONArray()
        var skippedShelf = 0
        val wantJson = JSONArray()
        val wantKeys = HashSet<String>(wishlistTitles)

        for (r in rows) {
            val ref = r["book_ref"].orEmpty()
            val title = r["title"].orEmpty().trim()
            if (ref.isEmpty() || title.isEmpty()) continue
            val primary = r["author"].orEmpty().substringBefore(',').trim()
            val logId = "log-" + sha1(title.lowercase() + "|" + primary.lowercase()).take(16)
            val existing = books.firstOrNull { it.id == logId } ?: byTitle.firstOrNull { TitleKey.same(it.title, title) }
            if (existing != null) {
                idOf[ref] = existing.id
                isNew[ref] = false
                continue
            }
            val status = r["status"].orEmpty()
            if ((status == "toRead" || status == "wishlist") && ref !in readRefs) {
                val key = TitleKey.of(title)
                if (wantKeys.add(key)) {
                    val year = Regex("(\\d{4})").find(r["published_date"].orEmpty())?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    wantJson.put(
                        JSONObject()
                            .put("id", "bs-" + sha1("${title.lowercase()}|${primary.lowercase()}").take(14))
                            .put("title", title).put("author", r["authors"].orEmpty().ifBlank { r["author"].orEmpty() }.replace(";", ","))
                            .put("year", year).put("cover", 0).put("rating", 0.0).put("ratings", 0).put("editions", 0).put("readers", 0)
                            .put("addedAt", dayMs(r["date_added"], zone))
                            .put("subjects", JSONArray(list(r["genres"]))),
                    )
                    skippedShelf++
                }
                continue
            }
            idOf[ref] = logId
            isNew[ref] = true

            val finished = status == "finished"
            val start = dayMs(r["start_date"], zone)
            val end = dayMs(r["end_date"], zone)
            val rating = r["rating"].orEmpty().toDoubleOrNull() ?: 0.0
            val o = JSONObject()
                .put("id", logId)
                .put("noFile", true)
                .put("title", title)
                .put("author", r["authors"].orEmpty().ifBlank { r["author"].orEmpty() })
                .put("language", languageCode(r["language"].orEmpty()))
                .put("publisher", r["publisher"].orEmpty())
                .put("published", r["published_date"].orEmpty())
                .put("addedAt", dayMs(r["date_added"], zone).takeIf { it > 0L } ?: System.currentTimeMillis())
                .put("tags", JSONArray(list(r["genres"]) + list(r["tags"])))
                .put("favorite", r["favorite"] == "true")
                .put("finished", finished)
                .put("source", "bookshelf")
                .put("format", formatOf(r["type"].orEmpty()))
            if (finished && end > 0L) o.put("finishedAt", end)
            if (start > 0L) o.put("startedAt", start)
            if (rating > 0.0) {
                o.put("rating10", (rating * 2).coerceIn(0.0, 10.0))
                val ratedAt = if (end > 0L) end else start
                if (ratedAt > 0L) o.put("ratedAt", ratedAt)
            }
            r["pages"].orEmpty().toIntOrNull()?.takeIf { it > 0 }?.let { o.put("customPages", it) }
            if (status == "abandoned") o.put("abandoned", true)
            r["series"].orEmpty().takeIf { it.isNotBlank() }?.let { o.put("series", it) }
            r["series_position"].orEmpty().toFloatOrNull()?.let { o.put("seriesNo", it.toDouble()) }
            r["cover_url"].orEmpty().takeIf { it.startsWith("http") }?.let { o.put("coverUrl", it) }
            booksJson.put(o)
        }

        // reading sessions
        val sessionsJson = JSONArray()
        var sessionCount = 0
        val addedStarts = HashSet<Pair<String, Long>>()
        for (e in entries) {
            val id = idOf[e["book_ref"].orEmpty()] ?: continue
            val local = runCatching { LocalDateTime.parse(e["date"].orEmpty().trim()) }.getOrNull() ?: continue
            val offsetMin = e["tz_offset"].orEmpty().trim().toIntOrNull()
            val startMs = if (offsetMin != null) local.toInstant(ZoneOffset.ofTotalSeconds(offsetMin * 60)).toEpochMilli()
            else local.atZone(zone).toInstant().toEpochMilli()
            val seconds = ((e["minutes"].orEmpty().toDoubleOrNull() ?: 0.0) * 60).toInt().coerceAtLeast(0)
            val from = e["start_page"].orEmpty().toIntOrNull() ?: 0
            val to = e["end_page"].orEmpty().toIntOrNull() ?: 0
            val pages = if (to >= from && to > 0) to - from + 1 else 0
            if (seconds == 0 && pages == 0) continue

            val mine = haveSessions[id].orEmpty()
            val day = Instant.ofEpochMilli(startMs).atZone(zone).toLocalDate()
            val dup = mine.any { s ->
                abs(s.startMs - startMs) < 5 * 60_000L ||
                    (Instant.ofEpochMilli(s.startMs).atZone(zone).toLocalDate() == day && s.seconds == seconds && seconds > 0)
            }
            if (dup || !addedStarts.add(id to startMs)) continue
            sessionsJson.put(
                JSONObject().put("bookId", id).put("startMs", startMs).put("seconds", seconds).put("pages", pages)
                    .put("fromPos", from).put("toPos", to).put("manual", true).put("kind", SessionKind.LOGGED),
            )
            sessionCount++
        }

        // quotes, and notes (kept as highlights whose text is the note)
        val pagesOf = rows.associate { it["book_ref"].orEmpty() to (it["pages"].orEmpty().toIntOrNull() ?: 0) }
        val highlightsJson = JSONArray()
        var quoteCount = 0
        val seenText = HashSet<Pair<String, String>>()
        fun addText(ref: String, text: String, page: Int, date: String?) {
            val id = idOf[ref] ?: return
            val clean = text.trim()
            if (clean.isEmpty()) return
            if (clean in haveText[id].orEmpty() || !seenText.add(id to clean)) return
            val total = pagesOf[ref] ?: 0
            val progress = if (total > 0 && page > 0) (page.toDouble() / total).coerceIn(0.0, 1.0) else 0.0
            val at = dayMs(date, zone).takeIf { it > 0L }?.plus(12 * 3_600_000L) ?: System.currentTimeMillis()
            highlightsJson.put(
                JSONObject().put("id", "bs-" + sha1("$id|$clean").take(16)).put("bookId", id).put("locator", "")
                    .put("text", clean).put("note", "").put("color", HighlightColors.DEFAULT)
                    .put("progress", progress).put("createdAt", at),
            )
            quoteCount++
        }
        for (q in quotes) addText(q["book_ref"].orEmpty(), q["quote"].orEmpty(), q["page"].orEmpty().toIntOrNull() ?: 0, q["date"])
        for (n in notes) addText(n["book_ref"].orEmpty(), n["note"].orEmpty(), 0, n["date"])

        // one finished reading for each new finished book, with the dates we know
        val readingsJson = JSONArray()
        for (r in rows) {
            val ref = r["book_ref"].orEmpty()
            if (isNew[ref] != true || r["status"] != "finished") continue
            val end = dayMs(r["end_date"], zone)
            if (end <= 0L) continue
            readingsJson.put(
                JSONObject().put("bookId", idOf[ref]).put("startedAt", dayMs(r["start_date"], zone)).put("finishedAt", end)
                    .put("rating10", (r["rating"].orEmpty().toDoubleOrNull() ?: 0.0) * 2),
            )
        }

        val root = JSONObject()
            .put("app", "paperback").put("platform", "bookshelf").put("version", 1)
            .put("exportedAt", Instant.now().toString())
            .put("books", booksJson).put("sessions", sessionsJson).put("highlights", highlightsJson).put("readings", readingsJson)
        if (wantJson.length() > 0) root.put("wantToRead", wantJson)

        // the yearly book goal: only while yours is still the default
        val target = tables["goals"].orEmpty().firstOrNull { it["type"] == "books" && it["archived"] != "true" }
            ?.get("target")?.toIntOrNull()?.takeIf { it in 1..500 }
        var goalBooks: Int? = null
        if (target != null && goals.booksPerYear == Goals().booksPerYear && target != goals.booksPerYear) {
            root.put(
                "goals",
                JSONObject().put("booksPerYear", target).put("pagesPerDay", goals.pagesPerDay).put("minutesPerDay", goals.minutesPerDay)
                    .put("streakDays", goals.streakDays).put("weeklyMinutes", goals.weeklyMinutes).put("monthlyMinutes", goals.monthlyMinutes)
                    .put("monthlyBooks", goals.monthlyBooks).put("tinyMinutes", goals.tinyMinutes).put("restDays", goals.restDays),
            )
            goalBooks = target
        }
        BookshelfResult(root.toString(), booksJson.length(), sessionCount, quoteCount, skippedShelf, goalBooks)
    }

    // ---- reading the zip and the CSV ---------------------------------------------------------

    /** "books", "entries", "quotes", "notes", "goals", "settings" -> their rows (numbered parts joined). */
    private fun readTables(bytes: ByteArray): Map<String, List<Map<String, String>>> {
        val out = HashMap<String, MutableList<Map<String, String>>>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) continue
                val name = entry.name.substringAfterLast('/').lowercase()
                if (!name.endsWith(".csv")) continue
                val table = name.removeSuffix(".csv").replace(Regex("_\\d+$"), "")
                out.getOrPut(table) { ArrayList() }.addAll(parseCsv(zip.readBytes().toString(Charsets.UTF_8)))
            }
        }
        return out
    }

    internal fun parseCsv(raw: String): List<Map<String, String>> {
        val s = raw.removePrefix("﻿")
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < s.length && s[i + 1] == '"') { cell.append('"'); i++ } else quoted = false
                } else cell.append(c)
            } else if (c == '"') {
                quoted = true
            } else if (c == ',') {
                row.add(cell.toString()); cell.setLength(0)
            } else if (c == '\n') {
                row.add(cell.toString()); cell.setLength(0)
                rows.add(row); row = ArrayList()
            } else if (c != '\r') {
                cell.append(c)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString()); rows.add(row) }
        if (rows.isEmpty()) return emptyList()
        val header = rows[0].map { it.trim() }
        return rows.drop(1).filter { r -> r.any { it.isNotEmpty() } }.map { r ->
            header.indices.associate { idx -> header[idx] to r.getOrElse(idx) { "" } }
        }
    }

    // ---- small helpers -------------------------------------------------------------------------

    private fun sha1(text: String): String =
        MessageDigest.getInstance("SHA-1").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun list(v: String?): List<String> =
        v.orEmpty().split(';').map { it.trim() }.filter { it.isNotEmpty() && !it.equals("unknown", ignoreCase = true) }

    /** "2026-09-20", "2026-09" or "2026" -> the start of that day in [zone], 0 when empty or unreadable. */
    private fun dayMs(v: String?, zone: ZoneId): Long {
        val m = Regex("^(\\d{4})(?:-(\\d{2}))?(?:-(\\d{2}))?").find(v.orEmpty().trim()) ?: return 0L
        val y = m.groupValues[1].toInt()
        val mo = m.groupValues[2].toIntOrNull() ?: 1
        val d = m.groupValues[3].toIntOrNull() ?: 1
        return runCatching { LocalDate.of(y, mo, d).atStartOfDay(zone).toInstant().toEpochMilli() }.getOrDefault(0L)
    }

    private fun formatOf(type: String): String = when (type) {
        "hardCover" -> "hardcover"
        "paperback" -> "paper"
        "ebook" -> "ebook"
        "audiobook" -> "audiobook"
        "mixed" -> "mixed"
        "other" -> "other"
        else -> ""
    }

    private val languageCodes: Map<String, String> by lazy {
        Locale.getISOLanguages().associateBy({ Locale(it).getDisplayLanguage(Locale.ENGLISH).lowercase() }, { it })
    }

    private fun languageCode(name: String): String = languageCodes[name.trim().lowercase()].orEmpty()
}
