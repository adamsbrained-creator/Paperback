package com.paperback.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/*
 * Word look-ups for the dictionary page and the reader. The definitions come from Wiktionary's free online API
 * (no account, many languages: a Russian word gets its Russian entry), so a look-up needs the internet.
 */

class DictSense(val partOfSpeech: String, val meanings: List<String>)

class DictEntry(
    val word: String,
    /** Wiktionary's language code of the entry shown ("en", "ru"...) and its name ("English"). */
    val lang: String,
    val language: String,
    val senses: List<DictSense>,
) {
    /** One short line for lists: the first meaning. */
    val short: String get() = senses.firstOrNull()?.meanings?.firstOrNull().orEmpty()
}

/** A word you looked up (saved or not): for "look-ups per 1,000 words". */
class WordLookup(val word: String, val bookId: String, val at: Long)

object DictionaryApi {
    private const val BASE = "https://en.wiktionary.org/api/rest_v1/page/definition/"
    private const val MAX_SENSES = 5
    private const val MAX_MEANINGS = 3

    /** Trims quotes and punctuation round a selected word. Blank when nothing is left or it is too long to be a word. */
    fun clean(raw: String): String {
        val t = raw.trim().trim { !it.isLetterOrDigit() }.replace(Regex("\\s+"), " ")
        return if (t.length > 60 || t.split(' ').size > 4) "" else t
    }

    /** The entry for [raw], or null when there is none. [preferLang] is a language code such as "ru" or "en-GB". */
    fun define(raw: String, preferLang: String): Result<DictEntry?> = runCatching {
        val word = clean(raw)
        if (word.isEmpty()) return@runCatching null
        val prefer = preferLang.trim().lowercase().substringBefore('-').substringBefore('_')
        for (candidate in listOf(word, word.lowercase()).distinct()) {
            val body = get(BASE + URLEncoder.encode(candidate, "UTF-8").replace("+", "%20")) ?: continue
            val entry = parse(candidate, body, prefer)
            if (entry != null) return@runCatching entry
        }
        null
    }

    internal fun parse(word: String, body: String, prefer: String): DictEntry? {
        val root = JSONObject(body)
        val keys = root.keys().asSequence().toList()
        if (keys.isEmpty()) return null
        val lang = keys.firstOrNull { it == prefer } ?: keys.firstOrNull { it == "en" } ?: keys.first()
        val arr: JSONArray = root.optJSONArray(lang) ?: return null
        val senses = ArrayList<DictSense>()
        var language = lang
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            language = o.optString("language", language).ifBlank { language }
            val defs = o.optJSONArray("definitions") ?: continue
            val meanings = ArrayList<String>()
            for (j in 0 until defs.length()) {
                val d = defs.optJSONObject(j)?.optString("definition").orEmpty()
                val plain = plain(d)
                if (plain.isNotEmpty() && meanings.size < MAX_MEANINGS) meanings.add(plain)
            }
            if (meanings.isNotEmpty() && senses.size < MAX_SENSES) senses.add(DictSense(o.optString("partOfSpeech"), meanings))
        }
        return if (senses.isEmpty()) null else DictEntry(word, lang, language, senses)
    }

    private fun plain(html: String): String =
        android.text.Html.fromHtml(html, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()

    /** The page's text, or null for "no such page" (404). Anything else that is not 200 is an error. */
    private fun get(url: String): String? {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.setRequestProperty("User-Agent", "Paperback/1.0 (Android ebook reader)")
            conn.setRequestProperty("Accept", "application/json")
            return when (val code = conn.responseCode) {
                200 -> conn.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
                404 -> null
                else -> throw IOException("The dictionary answered $code.")
            }
        } finally {
            conn.disconnect()
        }
    }
}

// ---- look-ups per 1,000 words ---------------------------------------------------------------

class LookupFigures(
    val saved: Int,
    val lookups: Int,
    /** Look-ups per 1,000 words read, null until about 2,000 words are read. */
    val perThousand: Double?,
    /** The book with the most look-ups for the words read in it (at least five look-ups and 2,000 words). */
    val hardest: Pair<Book, Double>?,
)

fun lookupFigures(saved: List<SavedWord>, lookups: List<WordLookup>, rows: List<ReadingSession>, books: List<Book>): LookupFigures {
    val byId = books.associateBy { it.id }
    val total = wordsIn(rows, byId)
    var hardest: Pair<Book, Double>? = null
    for ((id, list) in lookups.groupBy { it.bookId }) {
        val book = byId[id] ?: continue
        if (list.size < 5) continue
        val words = wordsIn(rows.filter { it.bookId == id }, byId)
        if (words < 2_000L) continue
        val rate = list.size * 1000.0 / words
        val h = hardest
        if (h == null || rate > h.second) hardest = book to rate
    }
    return LookupFigures(
        saved = saved.size,
        lookups = lookups.size,
        perThousand = if (total >= 2_000L && lookups.isNotEmpty()) lookups.size * 1000.0 / total else null,
        hardest = hardest,
    )
}
