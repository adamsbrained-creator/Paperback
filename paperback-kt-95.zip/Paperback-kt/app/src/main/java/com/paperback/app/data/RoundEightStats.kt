package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

/*
 * Round 8, as plain functions: the consistency score and the month's challenges for the Goals page, notes per hour
 * read, where in a book you highlight, the card for a finished book, and the filter that narrows every Stats page
 * to some of your books. Nothing here touches Android.
 */

private const val READING_DAY_SECONDS = 60L

// ---- consistency score ------------------------------------------------------------------------

class ConsistencyScore(
    /** 0 to 100. */
    val score: Int,
    /** Share of the last 30 days you read, share that met the goal, and how far the goal streak is towards your streak goal. */
    val readPct: Int,
    val goalPct: Int,
    val streakPct: Int,
    /** The last twelve weeks, oldest first, each 0 to 100. */
    val weekly: List<Int>,
)

private fun mondayOf(d: LocalDate): LocalDate = d.minusDays((d.dayOfWeek.value - 1).toLong())

/** Half days read, a third days that met the goal, the rest the goal streak towards your streak goal (last 30 days). */
fun consistencyScore(
    byDay: Map<LocalDate, Long>,
    history: GoalHistory,
    tinyMinutes: Int,
    streakGoalDays: Int,
    goalStreak: Int,
    today: LocalDate,
): ConsistencyScore? {
    val r30 = hitRates(byDay, history, tinyMinutes, today).getOrNull(1) ?: return null
    if (r30.days <= 0) return null
    val readShare = r30.read.toDouble() / r30.days
    val hitShare = r30.met.toDouble() / r30.days
    val streakShare = minOf(1.0, goalStreak.toDouble() / streakGoalDays.coerceAtLeast(1))
    val score = ((0.5 * readShare + 0.35 * hitShare + 0.15 * streakShare) * 100).roundToInt().coerceIn(0, 100)

    val monday = mondayOf(today)
    val weekly = (11 downTo 0).map { i ->
        val start = monday.minusWeeks(i.toLong())
        var read = 0
        var met = 0
        for (k in 0 until 7) {
            val day = start.plusDays(k.toLong())
            if (day.isAfter(today)) break
            val s = byDay[day] ?: 0L
            if (s >= READING_DAY_SECONDS) read++
            if (s >= history.minutesOn(day) * 60L) met++
        }
        ((0.6 * read / 7.0 + 0.4 * met / 7.0) * 100).roundToInt().coerceIn(0, 100)
    }
    return ConsistencyScore(score, (readShare * 100).roundToInt(), (hitShare * 100).roundToInt(), (streakShare * 100).roundToInt(), weekly)
}

// ---- monthly challenges -----------------------------------------------------------------------

class MonthChallenge(val title: String, val progress: String, val fraction: Float, val done: Boolean)

/** Four challenges for the current month: five hours, two books, seven days in a row, a genre you have not finished before. */
fun monthChallenges(rows: List<ReadingSession>, books: List<Book>, today: LocalDate, zone: ZoneId): List<MonthChallenge> {
    val monthStart = today.withDayOfMonth(1)
    val inMonth = rows.filter { val d = dateOf(it.startMs, zone); !d.isBefore(monthStart) && !d.isAfter(today) }
    val seconds = inMonth.sumOf { it.seconds.toLong() }
    val fiveHours = 5 * 3600L

    fun finishedThisMonth(b: Book): Boolean =
        b.finished && finishedDate(b, zone).let { d -> !d.isBefore(monthStart) && !d.isAfter(today) }
    val finishedNow = books.count { finishedThisMonth(it) }

    val byDay = Stats.secondsByDay(inMonth, zone)
    var bestRun = 0
    var run = 0
    var d = monthStart
    while (!d.isAfter(today)) {
        if ((byDay[d] ?: 0L) >= READING_DAY_SECONDS) {
            run++
            if (run > bestRun) bestRun = run
        } else {
            run = 0
        }
        d = d.plusDays(1)
    }

    val seenBefore = books.filter { it.finished && finishedDate(it, zone).isBefore(monthStart) }
        .flatMap { broadGenresOf(it) }.toSet()
    val thisMonthBooks = books.filter {
        val began = it.startedAt > 0L && dateOf(it.startedAt, zone).let { s -> !s.isBefore(monthStart) && !s.isAfter(today) }
        finishedThisMonth(it) || began
    }
    val newGenres = thisMonthBooks.flatMap { broadGenresOf(it) }.filter { it != "Other" && it !in seenBefore }.distinct()

    return listOf(
        MonthChallenge("Read 5 hours", "${Stats.duration(seconds)} of 5h 00m", (seconds.toFloat() / fiveHours).coerceIn(0f, 1f), seconds >= fiveHours),
        MonthChallenge("Finish 2 books", "$finishedNow of 2", (finishedNow / 2f).coerceIn(0f, 1f), finishedNow >= 2),
        MonthChallenge("Read 7 days in a row", "$bestRun of 7 days", (bestRun / 7f).coerceIn(0f, 1f), bestRun >= 7),
        MonthChallenge(
            "Try a new genre",
            if (newGenres.isEmpty()) "None yet" else newGenres.take(2).joinToString(", "),
            if (newGenres.isEmpty()) 0f else 1f,
            newGenres.isNotEmpty(),
        ),
    )
}

// ---- notes per hour read ----------------------------------------------------------------------

class NoteRates(
    val total: Int,
    val hoursRead: Double,
    val perHour: Double,
    /** Books you marked up most for the time you spent in them (an hour of reading and two notes at least). */
    val books: List<Bar>,
)

fun noteRates(highlights: List<Highlight>, sessions: List<ReadingSession>, books: List<Book>): NoteRates? {
    if (highlights.isEmpty()) return null
    val secs = Stats.secondsByBook(sessions)
    val byId = books.associateBy { it.id }
    val perBook = highlights.groupingBy { it.bookId }.eachCount()
    var notes = 0
    var seconds = 0L
    val rows = ArrayList<Pair<Book, Double>>()
    for ((id, n) in perBook) {
        val s = secs[id] ?: 0L
        if (s <= 0L) continue
        notes += n
        seconds += s
        val b = byId[id] ?: continue
        if (s >= 3600L && n >= 2) rows.add(b to n / (s / 3600.0))
    }
    if (seconds < 3600L) return null
    val top = rows.sortedByDescending { it.second }.take(4)
    val max = (top.firstOrNull()?.second ?: 1.0).coerceAtLeast(0.000001)
    return NoteRates(
        total = notes,
        hoursRead = seconds / 3600.0,
        perHour = notes / (seconds / 3600.0),
        books = top.map { (b, v) -> Bar(b.title, v / max, "%.1f an hour".format(v), "", b.id) },
    )
}

/** How many of [progress] values (0 to 1, where in the book) fall in each of [buckets] equal parts of the book. */
fun spreadOf(progress: List<Float>, buckets: Int = 10): IntArray {
    val out = IntArray(buckets)
    for (p in progress) out[(p.coerceIn(0f, 0.9999f) * buckets).toInt()]++
    return out
}

// ---- the card for a finished book -------------------------------------------------------------

class FinishedFigures(
    val daysTaken: Int?,
    val seconds: Long,
    val pages: Int,
    val stars: Double?,
    /** Words per minute in this book and across your other books (0 = not enough reading to say). */
    val wpm: Int,
    val averageWpm: Int,
    /** A passage worth keeping: your longest note, else your longest highlight. */
    val quote: Highlight?,
)

fun finishedFigures(
    book: Book,
    rows: List<ReadingSession>,
    allBooks: List<Book>,
    highlights: List<Highlight>,
    zone: ZoneId,
): FinishedFigures? {
    if (!book.finished) return null
    val mine = rows.filter { it.bookId == book.id }
    val first = mine.minOfOrNull { it.startMs } ?: 0L
    val start = if (book.startedAt > 0L) book.startedAt else first
    val days = if (start > 0L) {
        (ChronoUnit.DAYS.between(dateOf(start, zone), dateOf(finishedAtMs(book), zone)).toInt() + 1).coerceAtLeast(1)
    } else null

    val byId = allBooks.associateBy { it.id }
    val own = wpmOf(mine, mapOf(book.id to book)).first
    val others = wpmOf(rows.filter { it.bookId != book.id }, byId).first

    val marks = highlights.filter { it.bookId == book.id }
    val quote = marks.filter { it.note.isNotBlank() }.maxByOrNull { it.note.length }
        ?: marks.filter { it.text.length in 20..300 }.maxByOrNull { it.text.length }

    return FinishedFigures(
        daysTaken = days,
        seconds = mine.sumOf { it.seconds.toLong() },
        pages = book.pageCount,
        stars = ratingStars(book).takeIf { it > 0 }?.let { if (book.rating10 > 0f) book.rating10 / 2.0 else it.toDouble() },
        wpm = own,
        averageWpm = others,
        quote = quote,
    )
}

fun finishedShareText(book: Book, f: FinishedFigures): String {
    val sb = StringBuilder()
    sb.append("Finished ${book.title}")
    if (book.author.isNotBlank()) sb.append(" by ${book.author}")
    sb.append('\n')
    val bits = ArrayList<String>()
    f.daysTaken?.let { bits.add(if (it == 1) "1 day" else "$it days") }
    if (f.seconds > 0) bits.add(Stats.duration(f.seconds))
    if (f.pages > 0) bits.add("${f.pages} pages")
    f.stars?.let { bits.add("%.1f".format(it) + " stars") }
    if (bits.isNotEmpty()) sb.append(bits.joinToString(" \u00B7 ")).append('\n')
    f.quote?.let { q -> sb.append("\n\u201C").append((if (q.note.isNotBlank()) q.note else q.text).trim().take(300)).append("\u201D") }
    return sb.toString().trimEnd()
}

// ---- the Stats filter -------------------------------------------------------------------------

/**
 * Narrows every Stats page to some of your books. Within one kind (genres, formats, languages, collections) any
 * choice matches; between kinds all of them must. Saved as text while the page is open.
 */
class StatsFilter(
    val genres: Set<String> = emptySet(),
    val formats: Set<String> = emptySet(),
    val languages: Set<String> = emptySet(),
    val collections: Set<String> = emptySet(),
) {
    val isEmpty: Boolean get() = genres.isEmpty() && formats.isEmpty() && languages.isEmpty() && collections.isEmpty()
    val count: Int get() = genres.size + formats.size + languages.size + collections.size

    fun matches(b: Book, membership: Map<String, Set<String>>): Boolean {
        if (genres.isNotEmpty() && broadGenresOf(b).none { it in genres }) return false
        if (formats.isNotEmpty() && formatLabel(b) !in formats) return false
        if (languages.isNotEmpty() && languageName(b.language) !in languages) return false
        if (collections.isNotEmpty() && collections.none { membership[it].orEmpty().contains(b.id) }) return false
        return true
    }

    fun toggled(kind: String, value: String): StatsFilter {
        fun flip(s: Set<String>) = if (value in s) s - value else s + value
        return when (kind) {
            "g" -> StatsFilter(flip(genres), formats, languages, collections)
            "f" -> StatsFilter(genres, flip(formats), languages, collections)
            "l" -> StatsFilter(genres, formats, flip(languages), collections)
            else -> StatsFilter(genres, formats, languages, flip(collections))
        }
    }

    fun has(kind: String, value: String): Boolean = when (kind) {
        "g" -> value in genres
        "f" -> value in formats
        "l" -> value in languages
        else -> value in collections
    }

    fun encode(): String =
        (genres.map { "g:$it" } + formats.map { "f:$it" } + languages.map { "l:$it" } + collections.map { "c:$it" }).joinToString("\u001F")

    companion object {
        fun parse(text: String): StatsFilter {
            if (text.isEmpty()) return StatsFilter()
            val g = HashSet<String>()
            val f = HashSet<String>()
            val l = HashSet<String>()
            val c = HashSet<String>()
            for (part in text.split('\u001F')) {
                if (part.length < 3 || part[1] != ':') continue
                val v = part.substring(2)
                when (part[0]) {
                    'g' -> g.add(v)
                    'f' -> f.add(v)
                    'l' -> l.add(v)
                    'c' -> c.add(v)
                }
            }
            return StatsFilter(g, f, l, c)
        }
    }
}

/** What there is to filter by in this library: the genres, formats and languages of your books, and your collections. */
class FilterOptions(
    val genres: List<String>,
    val formats: List<String>,
    val languages: List<String>,
    /** Collection id and name. */
    val collections: List<Pair<String, String>>,
)

fun filterOptions(books: List<Book>, collections: List<BookCollection>): FilterOptions = FilterOptions(
    genres = books.flatMap { broadGenresOf(it) }.filter { it != "Other" }.groupingBy { it }.eachCount().entries
        .sortedByDescending { it.value }.map { it.key },
    formats = books.map { formatLabel(it) }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.map { it.key },
    languages = books.map { languageName(it.language) }.filter { it.isNotEmpty() }.groupingBy { it }.eachCount().entries
        .sortedByDescending { it.value }.map { it.key },
    collections = collections.map { it.id to it.name },
)
