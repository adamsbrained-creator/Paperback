package com.paperback.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.paperback.app.data.Block
import com.paperback.app.data.BlockType
import com.paperback.app.data.HomeCatalog
import com.paperback.app.data.HomeLayout
import com.paperback.app.data.HomePreset
import com.paperback.app.data.HomePresets
import com.paperback.app.data.HomeSpacing
import com.paperback.app.data.HomeTitles
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlinx.coroutines.isActive

/*
 * Customize Home. A full-screen editor over the app, in two steps: pick a layout to start from, then change it.
 *
 * Editing happens in three tabs. Blocks shows the real Home, shrunk to fit, and a tap on a block opens its looks and
 * switches. Layout is the list of blocks: drag to reorder, eye to hide, add more. Style is what applies to all of
 * them: spacing, titles, corners, dividers.
 *
 * Nothing is saved until Done. Undo and Redo walk through every change made since the editor opened.
 */

/** The state of one visit to Customize Home. The app keeps it in the view model so turning the phone doesn't lose the work. */
class HomeSession(private val initial: HomeLayout?) {
    enum class Stage { Start, Edit }
    enum class Tab { Blocks, Layout, Style }

    var stage by mutableStateOf(if (initial == null) Stage.Start else Stage.Edit)
        private set
    var tab by mutableStateOf(Tab.Blocks)
    var draft by mutableStateOf(initial ?: HomePresets.original())
        private set
    var selected by mutableStateOf<Int?>(null)
    var adding by mutableStateOf(false)

    private var undoStack by mutableStateOf(emptyList<HomeLayout>())
    private var redoStack by mutableStateOf(emptyList<HomeLayout>())
    private var gesture = false

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** False on the first screen when there is no Home of one's own to go back to. */
    val canLeaveStart: Boolean get() = initial != null

    /** Whether leaving now would throw something away. */
    val changed: Boolean get() = if (initial == null) stage == Stage.Edit else draft != initial

    val selectedBlock: Block? get() = draft.blocks.firstOrNull { it.id == selected }

    private fun push() {
        undoStack = (undoStack + draft).takeLast(60)
        redoStack = emptyList()
    }

    /** One undoable change. */
    fun edit(change: (HomeLayout) -> HomeLayout) {
        endLive()
        val next = change(draft)
        if (next != draft) {
            push()
            draft = next
        }
    }

    /** A change that comes in many small steps (a slider, a drag): the first step is remembered, the rest are not, until [endLive]. */
    fun live(change: (HomeLayout) -> HomeLayout) {
        val next = change(draft)
        if (next == draft) return
        if (!gesture) {
            push()
            gesture = true
        }
        draft = next
    }

    fun endLive() {
        gesture = false
    }

    fun undo() {
        endLive()
        val last = undoStack.lastOrNull() ?: return
        redoStack = redoStack + draft
        undoStack = undoStack.dropLast(1)
        draft = last
        keepSelectionValid()
    }

    fun redo() {
        endLive()
        val next = redoStack.lastOrNull() ?: return
        undoStack = undoStack + draft
        redoStack = redoStack.dropLast(1)
        draft = next
        keepSelectionValid()
    }

    private fun keepSelectionValid() {
        if (draft.blocks.none { it.id == selected }) selected = null
    }

    fun startWith(key: String) {
        edit { HomePresets.build(key) }
        selected = null
        tab = Tab.Blocks
        stage = Stage.Edit
    }

    /** Starts with nothing, and opens the list of blocks to add. */
    fun startBlank() {
        edit { HomePresets.blank() }
        selected = null
        tab = Tab.Layout
        stage = Stage.Edit
        adding = true
    }

    fun backToStart() {
        selected = null
        stage = Stage.Start
    }

    fun leaveStart() {
        stage = Stage.Edit
    }

    fun select(id: Int?) {
        selected = id
    }

    /** Adds a block of [type] with its normal look after the block [after] (or at the end) and picks it. */
    fun add(type: BlockType, after: Int?) {
        val (next, block) = draft.adding(type, HomeCatalog.defaultStyle(type), after)
        edit { next }
        selected = block.id
        adding = false
    }

    fun update(id: Int, change: (Block) -> Block) {
        edit { layout ->
            val block = layout.blocks.firstOrNull { it.id == id } ?: return@edit layout
            layout.withBlock(change(block))
        }
    }

    fun toggleHidden(id: Int) = update(id) { it.copy(hidden = !it.hidden) }

    fun duplicateSelected() {
        val id = selected ?: return
        val (next, twin) = draft.duplicating(id)
        if (twin == null) return
        edit { next }
        selected = twin.id
    }

    fun removeSelected() {
        val id = selected ?: return
        edit { it.removing(id) }
        selected = null
    }

    /** One step of a drag in the list of blocks. */
    fun moveLive(from: Int, to: Int) = live { it.moving(from, to) }
}

private val SheetTop = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)

@Composable
fun HomeConstructor(
    session: HomeSession,
    /** The real Home, drawn with the given layout; the preview says how it is to behave. */
    home: @Composable (HomeLayout, HomePreview) -> Unit,
    onDone: (HomeLayout) -> Unit,
    onUseOriginal: () -> Unit,
    onClose: () -> Unit,
) {
    val t = pbTokens()
    var askDiscard by remember { mutableStateOf(false) }
    var askOriginal by remember { mutableStateOf(false) }
    val close: () -> Unit = { if (session.changed) askDiscard = true else onClose() }

    BackHandler {
        when {
            session.stage == HomeSession.Stage.Start && session.canLeaveStart -> session.leaveStart()
            session.stage == HomeSession.Stage.Edit && session.selected != null -> session.select(null)
            else -> close()
        }
    }

    // the editor rises a little as it opens
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val appear by animateFloatAsState(if (shown) 1f else 0f, tween(PB_MS_ENTER, easing = PbEaseOut), label = "homeEditorIn")

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = appear
                translationY = (1f - appear) * 24.dp.toPx()
            }
            .background(t.bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            // nothing under the editor may be touched
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Crossfade(targetState = session.stage, label = "homeEditorStage") { stage ->
            when (stage) {
                HomeSession.Stage.Start -> StartScreen(
                    session = session,
                    onBack = { if (session.canLeaveStart) session.leaveStart() else close() },
                )
                HomeSession.Stage.Edit -> EditScreen(
                    session = session,
                    home = home,
                    onClose = close,
                    onDone = { if (session.changed) onDone(session.draft) else onClose() },
                    onUseOriginal = { askOriginal = true },
                )
            }
        }
    }

    if (session.adding) {
        AddSheet(
            onDismiss = { session.adding = false },
            onPick = { type -> session.add(type, after = if (session.tab == HomeSession.Tab.Blocks) session.selected else null) },
            counts = session.draft.blocks.groupingBy { it.type }.eachCount(),
        )
    }
    if (askDiscard) {
        PbConfirmDialog(
            title = "Discard your changes?",
            message = "Home stays the way it was before you opened Customize Home.",
            confirm = "Discard",
            onConfirm = { askDiscard = false; onClose() },
            onDismiss = { askDiscard = false },
        )
    }
    if (askOriginal) {
        PbConfirmDialog(
            title = "Use the original Home?",
            message = "Your layout is removed and Home goes back to how it looked before Customize Home. You can build a new one any time.",
            confirm = "Use original",
            onConfirm = { askOriginal = false; onUseOriginal() },
            onDismiss = { askOriginal = false },
        )
    }
}

// ---- step 1: pick a layout ----------------------------------------------------------------------

@Composable
private fun StartScreen(session: HomeSession, onBack: () -> Unit) {
    val t = pbTokens()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BarIcon(PbIconName.Close, "Close", true, onBack)
        }
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
        ) {
            Text("Customize Home", color = t.ink, fontFamily = PbSerif, fontSize = 32.sp, fontWeight = FontWeight.Medium)
            Text(
                "Pick a layout to start from. You can change every part of it afterwards.",
                color = t.setSub,
                fontSize = 15.sp,
                lineHeight = 21.sp,
                modifier = Modifier.padding(top = 6.dp, bottom = 20.dp),
            )
            HomePresets.all.chunked(2).forEach { pair ->
                Row(
                    Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    pair.forEach { preset ->
                        PresetCard(preset, Modifier.weight(1f).fillMaxHeight()) { session.startWith(preset.key) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .pbTap({ session.startBlank() }, RoundedCornerShape(22.dp))
                    .clip(RoundedCornerShape(22.dp))
                    .background(t.card)
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PbIcon(PbIconName.Plus, size = 22.dp, tint = t.ink)
                Column(Modifier.padding(start = 14.dp)) {
                    Text("Start from nothing", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text("An empty Home. Add the blocks you want.", color = t.setSub, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun PresetCard(preset: HomePreset, modifier: Modifier, onClick: () -> Unit) {
    val t = pbTokens()
    val layout = remember(preset.key) { HomePresets.build(preset.key) }
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .pbTap(onClick, shape, haptic = true, pressedScale = 0.97f, role = Role.Button)
            .clip(shape)
            .background(t.card),
    ) {
        WireLayout(layout, height = 150.dp, fade = t.card, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp))
        Column(Modifier.padding(start = 16.dp, end = 12.dp, bottom = 14.dp)) {
            Text(preset.name, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(preset.description, color = t.setSub, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

// ---- step 2: change it ---------------------------------------------------------------------------

@Composable
private fun EditScreen(
    session: HomeSession,
    home: @Composable (HomeLayout, HomePreview) -> Unit,
    onClose: () -> Unit,
    onDone: () -> Unit,
    onUseOriginal: () -> Unit,
) {
    val t = pbTokens()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BarIcon(PbIconName.Close, "Close", true, onClose)
            Spacer(Modifier.weight(1f))
            BarIcon(PbIconName.Undo, "Undo", session.canUndo) { session.undo() }
            BarIcon(PbIconName.Redo, "Redo", session.canRedo) { session.redo() }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .height(44.dp)
                    .pbTap(onDone, RoundedCornerShape(22.dp), haptic = true, role = Role.Button)
                    .clip(RoundedCornerShape(22.dp))
                    .background(t.ink)
                    .padding(horizontal = 22.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Done", color = t.bg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
        }
        PbSegmented(
            options = listOf(
                HomeSession.Tab.Blocks to "Blocks",
                HomeSession.Tab.Layout to "Layout",
                HomeSession.Tab.Style to "Style",
            ),
            selected = session.tab,
            onSelect = { session.tab = it },
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (session.tab) {
                HomeSession.Tab.Blocks -> PreviewWithPanel(session, home, editing = true) {
                    val block = session.selectedBlock
                    if (block == null) {
                        HintPanel(
                            if (session.draft.visibleBlocks.isEmpty()) "Nothing on Home yet. Open Layout to add a block."
                            else "Tap a block to change how it looks.",
                        )
                    } else {
                        BlockPanel(session, block)
                    }
                }
                HomeSession.Tab.Layout -> LayoutTab(session, onUseOriginal)
                HomeSession.Tab.Style -> PreviewWithPanel(session, home, editing = false) { StylePanel(session) }
            }
        }
    }
}

/** The real Home, shrunk to the width of the screen, with a panel under it. */
@Composable
private fun PreviewWithPanel(
    session: HomeSession,
    home: @Composable (HomeLayout, HomePreview) -> Unit,
    editing: Boolean,
    panel: @Composable () -> Unit,
) {
    val t = pbTokens()
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(top = 6.dp, bottom = 16.dp),
            ) {
                val frame = RoundedCornerShape(28.dp)
                Box(Modifier.fillMaxWidth().clip(frame).border(1.dp, t.rule, frame)) {
                    ScaledBox(designWidth = 390.dp) {
                        Column(Modifier.fillMaxWidth()) {
                            // room for the name tag of the first block
                            Spacer(Modifier.height(28.dp))
                            val preview = if (editing) HomePreview(session.selected) { id -> session.select(id) } else HomePreview(null, null)
                            home(session.draft, preview)
                            Spacer(Modifier.height(20.dp))
                        }
                    }
                }
            }
        }
        panel()
    }
}

/** Lays [content] out at [designWidth] whatever room there is, then shrinks it to fit. Touches still land where they should. */
@Composable
private fun ScaledBox(designWidth: Dp, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Layout(content = content, modifier = modifier) { measurables, constraints ->
        val designPx = designWidth.roundToPx()
        val scale = if (constraints.hasBoundedWidth) constraints.maxWidth.toFloat() / designPx else 1f
        val placeables = measurables.map {
            it.measure(Constraints(minWidth = designPx, maxWidth = designPx, minHeight = 0, maxHeight = Constraints.Infinity))
        }
        val height = placeables.maxOfOrNull { it.height } ?: 0
        val width = if (constraints.hasBoundedWidth) constraints.maxWidth else designPx
        layout(width, (height * scale).toInt()) {
            placeables.forEach {
                it.placeWithLayer(0, 0) {
                    scaleX = scale
                    scaleY = scale
                    transformOrigin = TransformOrigin(0f, 0f)
                }
            }
        }
    }
}

@Composable
private fun HintPanel(text: String) {
    val t = pbTokens()
    Box(Modifier.fillMaxWidth().clip(SheetTop).background(t.card).padding(horizontal = 24.dp, vertical = 26.dp), contentAlignment = Alignment.Center) {
        Text(text, color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

// ---- Blocks tab: the panel of the picked block ---------------------------------------------------

@Composable
private fun BlockPanel(session: HomeSession, block: Block) {
    val t = pbTokens()
    val styles = HomeCatalog.stylesOf(block.type)
    val options = HomeCatalog.options.getValue(block.type)
    Column(Modifier.fillMaxWidth().clip(SheetTop).background(t.card)) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(block.title, color = t.ink, fontFamily = PbSerif, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(block.styleLabel, color = t.setSub, fontSize = 13.sp)
            }
            BarIcon(PbIconName.Copy, "Duplicate", true) { session.duplicateSelected() }
            BarIcon(PbIconName.EyeOff, "Hide", true) { session.toggleHidden(block.id); session.select(null) }
            BarIcon(PbIconName.Trash, "Remove", true) { session.removeSelected() }
            BarIcon(PbIconName.Close, "Close", true) { session.select(null) }
        }
        Column(
            Modifier
                .heightIn(max = 330.dp)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 14.dp),
        ) {
            if (styles.size > 1) {
                Eyebrow("Look", Modifier.padding(start = 20.dp, top = 6.dp, bottom = 8.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    styles.forEach { info ->
                        StyleChoice(block.copy(style = info.key), info.label, info.key == block.style) {
                            session.update(block.id) { it.copy(style = info.key) }
                        }
                    }
                }
            }
            if (options.isNotEmpty()) {
                Eyebrow("Show", Modifier.padding(start = 20.dp, top = 14.dp, bottom = 2.dp))
                options.forEach { option ->
                    SwitchRow(option.label, block.opt(option.key)) { on -> session.update(block.id) { it.withOpt(option.key, on) } }
                }
            }
            if (styles.size <= 1 && options.isEmpty()) {
                Text(
                    "This block has nothing to adjust. You can still move it, hide it or remove it.",
                    color = t.setSub,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                )
            }
        }
    }
}

@Composable
private fun StyleChoice(sample: Block, label: String, selected: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    val accent = MaterialTheme.colorScheme.primary
    val edge by animateColorAsState(if (selected) accent else t.rule, tween(PB_MS_ENTER), label = "styleEdge")
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.width(92.dp).pbTap(onClick, shape, haptic = true, pressedScale = 0.97f, role = Role.RadioButton),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .clip(shape)
                .background(t.bg)
                .border(if (selected) 2.dp else 1.dp, edge, shape),
        ) { WireThumb(sample, width = 92.dp, height = 68.dp) }
        Text(
            label,
            color = if (selected) t.ink else t.setSub,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 15.sp,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

// ---- Style tab -----------------------------------------------------------------------------------

@Composable
private fun StylePanel(session: HomeSession) {
    val t = pbTokens()
    val layout = session.draft
    Column(
        Modifier
            .fillMaxWidth()
            .clip(SheetTop)
            .background(t.card)
            .heightIn(max = 360.dp)
            .verticalScroll(rememberScrollState())
            .padding(top = 6.dp, bottom = 14.dp),
    ) {
        Eyebrow("Space between blocks", Modifier.padding(start = 20.dp, top = 10.dp, bottom = 8.dp))
        PbSegmented(
            options = HomeSpacing.entries.map { it to it.label },
            selected = layout.spacing,
            onSelect = { s -> session.edit { it.copy(spacing = s) } },
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Eyebrow("Section titles", Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp))
        PbSegmented(
            options = HomeTitles.entries.map { it to it.label },
            selected = layout.titles,
            onSelect = { s -> session.edit { it.copy(titles = s) } },
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Eyebrow("Corners", Modifier.weight(1f))
            Box(
                Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(topStart = layout.cardDp.dp))
                    .background(t.ink.copy(alpha = 0.12f)),
            )
        }
        PbSlider(
            value = layout.round,
            onValueChange = { v -> session.live { it.copy(round = v) } },
            trackColor = t.ink.copy(alpha = 0.08f),
            modifier = Modifier.padding(horizontal = 10.dp),
            valueRange = 0f..1f,
            onValueChangeFinished = session::endLive,
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text("Sharp", color = t.setSub, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("Round", color = t.setSub, fontSize = 12.sp)
        }
        SwitchRow("Thin line between blocks", layout.dividers, Modifier.padding(top = 6.dp)) { on -> session.edit { it.copy(dividers = on) } }
    }
}

// ---- Layout tab ----------------------------------------------------------------------------------

private val RowHeight = 68.dp
private val RowGap = 8.dp

@Composable
private fun LayoutTab(session: HomeSession, onUseOriginal: () -> Unit) {
    val t = pbTokens()
    val blocks = session.draft.blocks
    val pitch = with(LocalDensity.current) { (RowHeight + RowGap).toPx() }
    var dragId by remember { mutableStateOf<Int?>(null) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val shape = RoundedCornerShape(20.dp)
    val density = LocalDensity.current
    val scroll = rememberScrollState()
    // where the finger is on screen, and where the list is, so a drag near an edge can scroll the list
    var fingerY by remember { mutableFloatStateOf(0f) }
    var viewTop by remember { mutableFloatStateOf(0f) }
    var viewBottom by remember { mutableFloatStateOf(0f) }

    // swaps the dragged block with its neighbours for as long as it has moved more than half a row away
    val settle: (Int) -> Unit = { id ->
        var again = true
        while (again) {
            again = false
            val now = session.draft.blocks
            val at = now.indexOfFirst { it.id == id }
            if (dragY > pitch / 2f && at in 0 until now.lastIndex) {
                session.moveLive(at, at + 1)
                dragY -= pitch
                again = true
            } else if (dragY < -pitch / 2f && at > 0) {
                session.moveLive(at, at - 1)
                dragY += pitch
                again = true
            }
        }
    }

    // holding a block near the top or bottom edge scrolls the list, faster the closer to the edge
    LaunchedEffect(dragId) {
        val id = dragId ?: return@LaunchedEffect
        val edge = with(density) { 80.dp.toPx() }
        val fastest = with(density) { 16.dp.toPx() }
        while (isActive) {
            withFrameNanos { }
            val step = when {
                fingerY < viewTop + edge -> -fastest * ((viewTop + edge - fingerY) / edge).coerceIn(0f, 1f)
                fingerY > viewBottom - edge -> fastest * ((fingerY - (viewBottom - edge)) / edge).coerceIn(0f, 1f)
                else -> 0f
            }
            if (step != 0f) {
                // the list moves under the finger, so the block has to move with it
                val moved = scroll.scrollBy(step)
                if (moved != 0f) {
                    dragY += moved
                    settle(id)
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned {
                viewTop = it.positionInRoot().y
                viewBottom = viewTop + it.size.height
            }
            .verticalScroll(scroll)
            .padding(horizontal = 20.dp)
            .padding(top = 4.dp, bottom = 32.dp),
    ) {
        Text(
            "Drag a block by its handle to move it. The eye hides a block but keeps its settings.",
            color = t.setSub,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(bottom = 12.dp),
        )
        Column(verticalArrangement = Arrangement.spacedBy(RowGap)) {
            for (block in blocks) {
                androidx.compose.runtime.key(block.id) {
                    val dragging = dragId == block.id
                    var gripTop by remember { mutableFloatStateOf(0f) }
                    val lift by animateDpAsState(if (dragging) 10.dp else 0.dp, spring(stiffness = 600f), label = "rowLift")
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(RowHeight)
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer { translationY = if (dragging) dragY else 0f }
                            .shadow(lift, shape)
                            .clip(shape)
                            .background(t.card)
                            .alpha(if (block.hidden) 0.55f else 1f),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier
                                .size(width = 44.dp, height = RowHeight)
                                .onGloballyPositioned { gripTop = it.positionInRoot().y }
                                .pointerInput(block.id) {
                                    detectDragGestures(
                                        onDragStart = { start -> dragId = block.id; dragY = 0f; fingerY = gripTop + start.y },
                                        onDragEnd = { dragId = null; dragY = 0f; session.endLive() },
                                        onDragCancel = { dragId = null; dragY = 0f; session.endLive() },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            fingerY += amount.y
                                            dragY += amount.y
                                            settle(block.id)
                                        },
                                    )
                                },
                            contentAlignment = Alignment.Center,
                        ) { PbIcon(PbIconName.Grip, size = 22.dp, tint = t.setSub, strokeWidth = 3.4f, contentDescription = "Move ${block.title}") }
                        Row(
                            Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                ) {
                                    session.select(block.id)
                                    session.tab = HomeSession.Tab.Blocks
                                },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.clip(RoundedCornerShape(12.dp)).background(t.bg)) { WireThumb(block, width = 64.dp, height = 46.dp) }
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(block.title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (block.hidden) "Hidden" else block.styleLabel,
                                    color = t.setSub,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                )
                            }
                        }
                        BarIcon(
                            if (block.hidden) PbIconName.EyeOff else PbIconName.Eye,
                            if (block.hidden) "Show ${block.title}" else "Hide ${block.title}",
                            true,
                        ) { session.toggleHidden(block.id) }
                        Spacer(Modifier.width(4.dp))
                    }
                }
            }
        }
        if (blocks.isEmpty()) {
            Text("Nothing here yet.", color = t.setSub, fontSize = 15.sp, modifier = Modifier.padding(vertical = 18.dp))
        }
        Row(
            Modifier
                .padding(top = 14.dp)
                .fillMaxWidth()
                .height(56.dp)
                .pbTap({ session.adding = true }, RoundedCornerShape(22.dp), haptic = true, role = Role.Button)
                .clip(RoundedCornerShape(22.dp))
                .background(t.asSelBg),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PbIcon(PbIconName.Plus, size = 20.dp, tint = t.asSelInk)
            Text("Add a block", color = t.asSelInk, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp))
        }
        PbCard(Modifier.padding(top = 24.dp)) {
            LinkRow("Start from another layout") { session.backToStart() }
            CardDivider()
            LinkRow("Use the original Home", onClick = onUseOriginal)
        }
    }
}

@Composable
private fun LinkRow(text: String, onClick: () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .pbTap(onClick, RoundedCornerShape(20.dp), pressedScale = 0.985f, role = Role.Button)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = t.ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub)
    }
}

// ---- Add a block ---------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddSheet(onDismiss: () -> Unit, onPick: (BlockType) -> Unit, counts: Map<BlockType, Int>) {
    val t = pbTokens()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = t.menuBg,
        contentColor = t.ink,
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
        dragHandle = {
            Box(Modifier.padding(top = 10.dp, bottom = 6.dp).size(width = 40.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(t.ink.copy(alpha = 0.10f)))
        },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 28.dp),
        ) {
            Text("Add a block", color = t.ink, fontFamily = PbSerif, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            HomeCatalog.groups.forEach { group ->
                Eyebrow(group.label, Modifier.padding(top = 20.dp, bottom = 6.dp))
                group.types.forEach { type ->
                    val sample = remember(type) { Block(0, type, HomeCatalog.defaultStyle(type)) }
                    val shape = RoundedCornerShape(18.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .pbTap({ onPick(type) }, shape, pressedScale = 0.98f, role = Role.Button)
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.clip(RoundedCornerShape(14.dp)).background(t.card)) { WireThumb(sample, width = 72.dp, height = 52.dp) }
                        Column(Modifier.weight(1f).padding(start = 14.dp, end = 8.dp)) {
                            Text(type.label, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Text(type.about, color = t.setSub, fontSize = 13.sp, lineHeight = 17.sp)
                        }
                        val n = counts[type] ?: 0
                        if (n > 0) Text(if (n == 1) "On Home" else "On Home ×$n", color = t.setSub, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ---- small parts ---------------------------------------------------------------------------------

/** A round icon button, 44 dp. */
@Composable
private fun BarIcon(icon: PbIconName, description: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .alpha(if (enabled) 1f else 0.3f)
            .pbTap(onClick, CircleShape, enabled = enabled, haptic = true, role = Role.Button),
        contentAlignment = Alignment.Center,
    ) { PbIcon(icon, size = 22.dp, tint = pbTokens().ink, contentDescription = description) }
}

/** A line with a label and a switch; the whole line is the target. */
@Composable
private fun SwitchRow(label: String, on: Boolean, modifier: Modifier = Modifier, onChange: (Boolean) -> Unit) {
    Row(
        modifier
            .fillMaxWidth()
            .pbTap({ onChange(!on) }, RoundedCornerShape(16.dp), pressedScale = 0.99f, haptic = true, role = Role.Switch)
            .padding(horizontal = 20.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = pbTokens().ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
        PbSwitchMark(on)
    }
}

/** The switch itself: a pill that fills with the accent, and a round handle that slides over. */
@Composable
private fun PbSwitchMark(on: Boolean) {
    val accent = MaterialTheme.colorScheme.primary
    val track by animateColorAsState(if (on) accent else pbTokens().ink.copy(alpha = 0.16f), tween(PB_MS_ENTER), label = "switchTrack")
    val x by animateDpAsState(if (on) 20.dp else 0.dp, spring(dampingRatio = 0.7f, stiffness = 600f), label = "switchHandle")
    Box(Modifier.size(width = 50.dp, height = 30.dp).clip(CircleShape).background(track).padding(3.dp)) {
        Box(
            Modifier
                .padding(start = x)
                .size(24.dp)
                .shadow(1.dp, CircleShape)
                .clip(CircleShape)
                .background(androidx.compose.ui.graphics.Color.White),
        )
    }
}
