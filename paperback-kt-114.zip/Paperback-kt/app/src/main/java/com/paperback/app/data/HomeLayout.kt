package com.paperback.app.data

/*
 * Customize Home: the Home page is a stack of blocks. This file is the model of that stack and nothing else, so it
 * has no Android in it: the kinds of block, the looks and switches each one has, the ready-made layouts, and the
 * plain-text form the layout is saved in (preferences and backups).
 */

/** The kinds of block a Home is built from. [key] is what gets saved; [about] is the line in "Add a block"; [empty] is what the editor says when a block has nothing to show yet. */
enum class BlockType(val key: String, val label: String, val about: String, val empty: String) {
    Greeting("greeting", "Greeting", "A hello for the time of day, with the date.", ""),
    Alerts(
        "alerts", "Reminders", "Last month's recap, a new record and the mood question after a session.",
        "Shows only when there is something to say: a recap, a record or the mood question.",
    ),
    Continue("continue", "Continue reading", "The book you are in the middle of, with a button to go on.", ""),
    NextAction("next", "Next best action", "One idea for right now, with a button.", "An idea shows up here once you have some reading to go on."),
    Today("today", "Today", "The stats you pinned: the goal ring, streak, time and pages.", ""),
    Shortcuts("shortcuts", "Shortcuts", "Buttons for Library, Stats, Discover and Import.", "Turn on at least one shortcut."),
    Favorites("favorites", "Favorites", "The books you marked as favorite.", "Books you mark as favorite show up here."),
    Recent("recent", "Recently read", "The books you opened last.", "Books you open show up here."),
    Recommended("recommended", "Recommended for you", "Books in your library that look like the ones you loved.", "Needs a few books you rated, favorited or finished."),
    Reread("reread", "Worth reading again", "Books you loved a long time ago.", "Books you loved long ago show up here."),
    Want("want", "Want to read", "Books you saved from Discover.", "Save a book from Discover and it shows up here."),
    NewReleases("new", "New from authors you read", "Fresh books by authors in your library.", "Needs online suggestions and a few authors you read."),
    Stretch("stretch", "Try something different", "Books a little outside your usual taste.", "Needs online suggestions and some reading to learn your taste from."),
    Because("because", "Because you liked", "One row for each book you liked, with others like it.", "Needs online suggestions and a few books you liked."),
    MightLike("mightlike", "Books you might like", "Suggestions from the online catalog, with the reason.", "Needs online suggestions."),
    Quote("quote", "Quote of the day", "One passage you highlighted, the same one all day.", "Highlight a passage while you read and one shows up here."),
    ;

    /** True for the blocks that are a row of books. */
    val isBooks: Boolean get() = this == Favorites || this == Recent || this == Recommended || this == Reread || this == Want || this == NewReleases || this == Stretch || this == Because || this == MightLike

    companion object {
        fun of(key: String): BlockType? = entries.firstOrNull { it.key == key }
    }
}

/** The gap between blocks, in dp. Cozy is what Home always had. */
enum class HomeSpacing(val label: String, val dp: Int) { Compact("Compact", 16), Cozy("Cozy", 28), Roomy("Roomy", 40) }

/** How big the title above a block is. Small is the grey label Home always had. */
enum class HomeTitles(val label: String) { Small("Small"), Large("Large") }

/** One way a block can look. [key] is what gets saved. */
class StyleInfo(val key: String, val label: String)

/** One on/off switch of a block. */
class OptionInfo(val key: String, val label: String, val default: Boolean)

/** A group of block types in the "Add a block" sheet. */
class BlockGroup(val label: String, val types: List<BlockType>)

/** Everything the constructor knows about the blocks: their looks and their switches. The first look of a block is its normal one. */
object HomeCatalog {

    private val bookStyles = listOf(
        StyleInfo("spines", "Spines"),
        StyleInfo("shelf", "Covers on shelf"),
        StyleInfo("frosted", "Frosted shelf"),
        StyleInfo("row", "Cover row"),
        StyleInfo("grid", "Cover grid"),
        StyleInfo("list", "List"),
    )

    private val catalogStyles = listOf(
        StyleInfo("row", "Cover row"),
        StyleInfo("shelf", "Covers on shelf"),
        StyleInfo("grid", "Cover grid"),
        StyleInfo("list", "List"),
    )

    val styles: Map<BlockType, List<StyleInfo>> = mapOf(
        BlockType.Greeting to listOf(
            StyleInfo("hello", "Hello"),
            StyleInfo("stats", "Hello and stats"),
            StyleInfo("date", "Big date"),
        ),
        BlockType.Alerts to listOf(StyleInfo("cards", "Cards")),
        BlockType.Continue to listOf(
            StyleInfo("classic", "Classic"),
            StyleInfo("card", "Card"),
            StyleInfo("compact", "Compact"),
            StyleInfo("hero", "Big cover"),
        ),
        BlockType.NextAction to listOf(StyleInfo("card", "Card")),
        BlockType.Today to listOf(
            StyleInfo("tiles", "Tiles"),
            StyleInfo("strip", "Strip"),
            StyleInfo("ring", "Big ring"),
        ),
        BlockType.Shortcuts to listOf(
            StyleInfo("pills", "Row"),
            StyleInfo("grid", "Tiles"),
        ),
        BlockType.Favorites to bookStyles,
        BlockType.Recent to bookStyles,
        BlockType.Recommended to bookStyles,
        BlockType.Reread to bookStyles,
        BlockType.Want to catalogStyles,
        BlockType.NewReleases to catalogStyles,
        BlockType.Stretch to catalogStyles,
        BlockType.Because to catalogStyles,
        BlockType.MightLike to catalogStyles,
        BlockType.Quote to listOf(
            StyleInfo("card", "Card"),
            StyleInfo("plain", "Big text"),
        ),
    )

    private val title = OptionInfo("title", "Section title", true)

    val options: Map<BlockType, List<OptionInfo>> = mapOf(
        BlockType.Greeting to listOf(OptionInfo("date", "Show the date", true)),
        BlockType.Alerts to listOf(
            OptionInfo("recap", "Monthly recap", true),
            OptionInfo("records", "New records", true),
            OptionInfo("mood", "Mood question", true),
        ),
        BlockType.Continue to listOf(
            title,
            OptionInfo("button", "Resume button", true),
            OptionInfo("left", "Time left", true),
            OptionInfo("picker", "Help me choose a book", true),
        ),
        BlockType.NextAction to emptyList(),
        BlockType.Today to listOf(title, OptionInfo("edit", "Edit button", true)),
        BlockType.Shortcuts to listOf(
            OptionInfo("library", "Library", true),
            OptionInfo("stats", "Stats", true),
            OptionInfo("discover", "Discover", true),
            OptionInfo("import", "Import", false),
        ),
        BlockType.Favorites to listOf(title),
        BlockType.Recent to listOf(title),
        BlockType.Recommended to listOf(title, OptionInfo("why", "Say why", true)),
        BlockType.Reread to listOf(title),
        BlockType.Want to listOf(title, OptionInfo("all", "View all link", true)),
        BlockType.NewReleases to listOf(title),
        BlockType.Stretch to listOf(title),
        BlockType.Because to listOf(title),
        BlockType.MightLike to listOf(title, OptionInfo("all", "View all link", true), OptionInfo("why", "Say why", true)),
        BlockType.Quote to emptyList(),
    )

    val groups: List<BlockGroup> = listOf(
        BlockGroup("Top", listOf(BlockType.Greeting, BlockType.Alerts, BlockType.Continue, BlockType.NextAction, BlockType.Today, BlockType.Shortcuts)),
        BlockGroup("Shelves", listOf(BlockType.Favorites, BlockType.Recent, BlockType.Reread)),
        BlockGroup("Discover", listOf(BlockType.Recommended, BlockType.Want, BlockType.MightLike, BlockType.Because, BlockType.NewReleases, BlockType.Stretch)),
        BlockGroup("Extras", listOf(BlockType.Quote)),
    )

    fun stylesOf(type: BlockType): List<StyleInfo> = styles.getValue(type)

    fun styleLabel(type: BlockType, key: String): String = stylesOf(type).firstOrNull { it.key == key }?.label ?: key

    fun defaultStyle(type: BlockType): String = stylesOf(type).first().key

    fun defaults(type: BlockType): Map<String, Boolean> = options.getValue(type).associate { it.key to it.default }
}

/** One block of the Home. [opts] holds only the switches that were changed from their default. */
data class Block(
    val id: Int,
    val type: BlockType,
    val style: String,
    val hidden: Boolean = false,
    val opts: Map<String, Boolean> = emptyMap(),
) {
    /** The value of one switch, falling back to its default. */
    fun opt(key: String): Boolean =
        opts[key] ?: HomeCatalog.options.getValue(type).firstOrNull { it.key == key }?.default ?: false

    fun withOpt(key: String, on: Boolean): Block = copy(opts = opts + (key to on))

    val title: String get() = type.label

    val styleLabel: String get() = HomeCatalog.styleLabel(type, style)
}

/** The whole Home: its blocks in order, and the look that applies to all of them. */
data class HomeLayout(
    val name: String,
    val blocks: List<Block>,
    val spacing: HomeSpacing = HomeSpacing.Cozy,
    val titles: HomeTitles = HomeTitles.Small,
    /** A thin line between blocks. */
    val dividers: Boolean = false,
    /** 0 is nearly square corners, 1 is very round. 0.6 is the 24 dp the cards always had. */
    val round: Float = DEFAULT_ROUND,
) {
    val visibleBlocks: List<Block> get() = blocks.filter { !it.hidden }

    val hiddenCount: Int get() = blocks.count { it.hidden }

    /** The corner radius of cards, in dp: 12 (sharp) to 32 (round). */
    val cardDp: Float get() = 12f + round.coerceIn(0f, 1f) * 20f

    fun nextId(): Int = (blocks.maxOfOrNull { it.id } ?: 0) + 1

    fun withBlock(block: Block): HomeLayout = copy(blocks = blocks.map { if (it.id == block.id) block else it })

    /** Adds a new block with default switches after the block with id [after], or at the end. */
    fun adding(type: BlockType, style: String, after: Int?): Pair<HomeLayout, Block> {
        val block = Block(nextId(), type, style)
        val at = blocks.indexOfFirst { it.id == after }.let { if (it < 0) blocks.size else it + 1 }
        return copy(blocks = blocks.toMutableList().apply { add(at, block) }) to block
    }

    fun duplicating(id: Int): Pair<HomeLayout, Block?> {
        val source = blocks.firstOrNull { it.id == id } ?: return this to null
        val twin = source.copy(id = nextId())
        val at = blocks.indexOf(source) + 1
        return copy(blocks = blocks.toMutableList().apply { add(at, twin) }) to twin
    }

    fun removing(id: Int): HomeLayout = copy(blocks = blocks.filter { it.id != id })

    fun moving(from: Int, to: Int): HomeLayout {
        if (from !in blocks.indices || to !in blocks.indices || from == to) return this
        return copy(blocks = blocks.toMutableList().apply { add(to, removeAt(from)) })
    }

    companion object {
        const val DEFAULT_ROUND: Float = 0.6f
    }
}

/** A ready-made Home to start from. */
class HomePreset(
    val key: String,
    val name: String,
    val description: String,
    val blocks: List<PresetBlock>,
    val spacing: HomeSpacing = HomeSpacing.Cozy,
    val titles: HomeTitles = HomeTitles.Small,
    val dividers: Boolean = false,
)

/** One block of a preset: its type, look and the switches that differ from the defaults. */
class PresetBlock(val type: BlockType, val style: String, val opts: Map<String, Boolean> = emptyMap())

object HomePresets {

    private fun b(type: BlockType, style: String, vararg opts: Pair<String, Boolean>) = PresetBlock(type, style, opts.toMap())

    private val G = BlockType.Greeting
    private val A = BlockType.Alerts
    private val C = BlockType.Continue
    private val N = BlockType.NextAction
    private val T = BlockType.Today
    private val S = BlockType.Shortcuts
    private val F = BlockType.Favorites
    private val R = BlockType.Recent
    private val M = BlockType.Recommended
    private val W = BlockType.Reread
    private val L = BlockType.Want
    private val E = BlockType.NewReleases
    private val X = BlockType.Stretch
    private val Y = BlockType.Because
    private val K = BlockType.MightLike
    private val Q = BlockType.Quote

    val all: List<HomePreset> = listOf(
        HomePreset(
            "classic", "Classic", "Home as it always was",
            listOf(b(A, "cards"), b(C, "classic"), b(N, "card"), b(T, "tiles"), b(F, "spines"), b(R, "spines"), b(M, "spines"), b(W, "spines"), b(L, "row"), b(E, "row"), b(X, "row"), b(Y, "row"), b(K, "row"), b(Q, "card")),
        ),
        HomePreset(
            "focus", "Focus", "Only the book you are on",
            listOf(b(A, "cards"), b(C, "hero"), b(T, "ring", "title" to false), b(N, "card")),
            spacing = HomeSpacing.Roomy,
        ),
        HomePreset(
            "dashboard", "Dashboard", "Numbers first",
            listOf(b(G, "stats"), b(A, "cards"), b(T, "tiles"), b(C, "card", "title" to false), b(N, "card"), b(R, "row"), b(Q, "card")),
            titles = HomeTitles.Large,
        ),
        HomePreset(
            "shelves", "Shelves", "Books on planks",
            listOf(b(G, "hello"), b(A, "cards"), b(C, "compact", "title" to false), b(F, "frosted"), b(R, "spines"), b(L, "shelf")),
            titles = HomeTitles.Large,
        ),
        HomePreset(
            "gallery", "Gallery", "Big covers, lots of them",
            listOf(b(A, "cards"), b(C, "compact"), b(R, "grid"), b(F, "grid"), b(M, "grid"), b(L, "grid")),
            spacing = HomeSpacing.Roomy,
            titles = HomeTitles.Large,
        ),
        HomePreset(
            "discover", "Discover", "Find the next one",
            listOf(b(A, "cards"), b(C, "compact"), b(S, "pills", "import" to true), b(M, "row"), b(K, "shelf"), b(Y, "row"), b(E, "row"), b(X, "row"), b(L, "row")),
        ),
        HomePreset(
            "lists", "Lists", "Rows of text, thin lines",
            listOf(b(A, "cards"), b(C, "classic"), b(T, "strip"), b(F, "list"), b(R, "list"), b(L, "list")),
            spacing = HomeSpacing.Compact,
            dividers = true,
        ),
        HomePreset(
            "quiet", "Quiet", "Calm and simple",
            listOf(b(G, "date"), b(A, "cards"), b(C, "classic", "picker" to false), b(Q, "plain")),
            spacing = HomeSpacing.Roomy,
        ),
        HomePreset(
            "minimal", "Minimal", "Almost nothing",
            listOf(b(C, "compact", "title" to false), b(R, "row", "title" to false)),
            spacing = HomeSpacing.Compact,
        ),
        HomePreset(
            "everything", "Everything", "Every block, one after another",
            listOf(
                b(G, "stats"), b(A, "cards"), b(C, "card"), b(N, "card"), b(T, "tiles"), b(S, "grid"), b(F, "frosted"), b(R, "spines"),
                b(M, "row"), b(W, "shelf"), b(L, "row"), b(E, "row"), b(X, "row"), b(Y, "row"), b(K, "row"), b(Q, "card"),
            ),
            titles = HomeTitles.Large,
        ),
    )

    fun find(key: String): HomePreset = all.firstOrNull { it.key == key } ?: all.first()

    /** A layout from the preset [key]. */
    fun build(key: String): HomeLayout {
        val preset = find(key)
        val blocks = preset.blocks.mapIndexed { i, p -> Block(i + 1, p.type, p.style, false, p.opts) }
        return HomeLayout(preset.name, blocks, preset.spacing, preset.titles, preset.dividers)
    }

    /**
     * The Home as it was before there was a constructor. [styleOf] gives the look picked for a block with the old
     * "Spines ▾" menu on its title (null = the normal one), so a Home nobody customized looks exactly as it did.
     */
    fun original(styleOf: (BlockType) -> String? = { null }): HomeLayout {
        val classic = find("classic")
        val blocks = classic.blocks.mapIndexed { i, p ->
            val picked = styleOf(p.type)
            val style = if (picked != null && HomeCatalog.stylesOf(p.type).any { it.key == picked }) picked else p.style
            Block(i + 1, p.type, style, false, p.opts)
        }
        return HomeLayout(classic.name, blocks)
    }

    /** An empty Home to build from nothing. */
    fun blank(): HomeLayout = HomeLayout("Custom", emptyList())
}

/**
 * Saves a [HomeLayout] as plain text, one line per setting. It is written by hand, not with a JSON library, so the
 * format can be tested on a computer without a phone.
 */
object HomeLayoutCodec {

    private const val VERSION = "pb1"

    fun encode(layout: HomeLayout): String = buildString {
        appendLine(VERSION)
        appendLine("name=" + layout.name.replace('\n', ' '))
        appendLine("spacing=${layout.spacing.name}")
        appendLine("titles=${layout.titles.name}")
        appendLine("dividers=${if (layout.dividers) 1 else 0}")
        appendLine("round=${layout.round}")
        for (block in layout.blocks) {
            val opts = block.opts.entries.joinToString(",") { "${it.key}:${if (it.value) 1 else 0}" }
            appendLine("b=${block.id}|${block.type.key}|${block.style}|${if (block.hidden) 1 else 0}|$opts")
        }
    }

    /** The layout in [text], or null when the text is not one this app wrote. */
    fun decode(text: String): HomeLayout? {
        val lines = text.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
        if (lines.firstOrNull() != VERSION) return null
        var layout = HomeLayout(name = "Custom", blocks = emptyList())
        val blocks = ArrayList<Block>()
        for (line in lines.drop(1)) {
            val at = line.indexOf('=')
            if (at < 0) continue
            val key = line.substring(0, at)
            val value = line.substring(at + 1)
            when (key) {
                "name" -> layout = layout.copy(name = value)
                "spacing" -> HomeSpacing.entries.firstOrNull { it.name == value }?.let { layout = layout.copy(spacing = it) }
                "titles" -> HomeTitles.entries.firstOrNull { it.name == value }?.let { layout = layout.copy(titles = it) }
                "dividers" -> layout = layout.copy(dividers = value == "1")
                "round" -> value.toFloatOrNull()?.let { if (it.isFinite()) layout = layout.copy(round = it.coerceIn(0f, 1f)) }
                "b" -> parseBlock(value)?.let { blocks += it }
            }
        }
        // Two blocks must never share an id, or editing one would edit both.
        return layout.copy(blocks = blocks.distinctBy { it.id })
    }

    private fun parseBlock(value: String): Block? {
        val parts = value.split('|')
        if (parts.size < 4) return null
        val id = parts[0].toIntOrNull() ?: return null
        val type = BlockType.of(parts[1]) ?: return null
        val style = parts[2]
        // A look this version does not know falls back to the first one, so the block still shows.
        val known = HomeCatalog.stylesOf(type).any { it.key == style }
        val opts = HashMap<String, Boolean>()
        parts.getOrNull(4)?.split(',')?.filter { it.isNotEmpty() }?.forEach { pair ->
            val kv = pair.split(':')
            if (kv.size == 2) opts[kv[0]] = kv[1] == "1"
        }
        return Block(id, type, if (known) style else HomeCatalog.defaultStyle(type), parts[3] == "1", opts)
    }
}
