package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Session
import com.paperback.app.data.SessionKind
import com.paperback.app.data.buildSessions
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

// A book's reading history: one card for each time you read (counted by the reader, the timer, or added by hand).

private val DATE_TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy · HH:mm", Locale.getDefault())

fun entryDate(startMs: Long): String = Instant.ofEpochMilli(startMs).atZone(ZoneId.systemDefault()).format(DATE_TIME)

/** "20 min", "1 h 05 min", "40 s". */
fun entryDuration(seconds: Int): String = when {
    seconds < 60 -> "$seconds s"
    seconds < 3600 -> "${(seconds + 30) / 60} min"
    else -> "${seconds / 3600} h ${((seconds % 3600) / 60).toString().padStart(2, '0')} min"
}

private fun pagesLabel(s: ReadingSession): String = when {
    s.fromPos > 0 && s.toPos >= s.fromPos && s.toPos > s.fromPos -> "Pages ${s.fromPos}–${s.toPos}"
    s.pages > 0 -> "${s.pages} ${if (s.pages == 1) "page" else "pages"}"
    else -> "No pages noted"
}

private fun minPerPage(s: ReadingSession): String? =
    if (s.pages > 0 && s.seconds > 0) "%.1f min/page".format(s.seconds / 60.0 / s.pages) else null

@Composable
fun EntryCard(entry: ReadingSession, onClick: () -> Unit) {
    val t = pbTokens()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(entryDate(entry.startMs), color = t.setSub, fontSize = 13.sp, modifier = Modifier.weight(1f))
            minPerPage(entry)?.let { Text(it, color = t.setSub, fontSize = 13.sp) }
        }
        Text(
            if (entry.manual) "Set by you" else "Counted automatically",
            color = if (entry.manual) MaterialTheme.colorScheme.primary else t.setSub,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 2.dp),
        )
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(pagesLabel(entry), color = t.ink, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            if (entry.pages > 0) {
                Text(
                    "+ ${entry.pages}",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(entryDuration(entry.seconds), color = t.ink, fontSize = 14.sp)
    }
}

private val TIME_ONLY: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault())
private val DAY_ONLY: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault())

private fun timeOf(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(TIME_ONLY)

/** "Today", "Yesterday" or "Mon 3 Nov" (with the year when it is not this one). */
private fun dayLabel(ms: Long): String {
    val zone = ZoneId.systemDefault()
    val d = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    val today = LocalDate.now(zone)
    return when {
        d == today -> "Today"
        d == today.minusDays(1) -> "Yesterday"
        d.year != today.year -> d.format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault()))
        else -> d.format(DAY_ONLY)
    }
}

private fun sittingPages(s: Session): String = when {
    s.fromPos > 0 && s.toPos > s.fromPos -> "Pages ${s.fromPos}–${s.toPos}"
    s.pages > 0 -> "${s.pages} ${if (s.pages == 1) "page" else "pages"}"
    else -> "No pages noted"
}

/** One small entry inside a big session: its time, pages and length. Tap to edit. */
@Composable
private fun InnerEntry(e: ReadingSession, onClick: () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(timeOf(e.startMs), color = t.setSub, fontSize = 13.sp, modifier = Modifier.width(48.dp))
        Column(Modifier.weight(1f)) {
            Text(pagesLabel(e), color = t.ink, fontSize = 14.sp)
            val tag = when {
                e.kind == SessionKind.LISTEN -> "Listened"
                e.manual -> "Set by you"
                else -> null
            }
            if (tag != null) Text(tag, color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
            if (e.breaks > 0) Text("${e.breaks} ${if (e.breaks == 1) "pause" else "pauses"} not counted", color = t.setSub, fontSize = 11.sp)
        }
        Text(entryDuration(e.seconds), color = t.setSub, fontSize = 13.sp)
    }
}

/**
 * One big reading session: when you started, the pages, the time, and (tap to open) the small entries it is made of.
 * A session of a single entry has nothing to open: tapping it edits that entry.
 */
@Composable
private fun SittingCard(s: Session, onEdit: (ReadingSession) -> Unit) {
    val t = pbTokens()
    var open by rememberSaveable(s.bookId, s.rows.firstOrNull()?.id ?: s.startMs) { mutableStateOf(false) }
    val many = s.rows.size > 1
    val pace = if (s.pages > 0 && s.seconds > 0) "%.1f min/page".format(s.seconds / 60.0 / s.pages) else null
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .clickable { if (many) open = !open else s.rows.firstOrNull()?.let(onEdit) }
            .padding(horizontal = 18.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val real = s.rows.lastOrNull()?.endMs ?: 0L
            val when_ = if (real > s.startMs && real - s.startMs >= 60_000L) "${timeOf(s.startMs)}–${timeOf(real)}" else "started ${timeOf(s.startMs)}"
            Text("${dayLabel(s.startMs)} · $when_", color = t.setSub, fontSize = 13.sp, modifier = Modifier.weight(1f))
            if (pace != null) Text(pace, color = t.setSub, fontSize = 13.sp)
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(sittingPages(s), color = t.ink, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            if (s.pages > 0) {
                Text(
                    "+ ${s.pages}",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(entryDuration(s.seconds.toInt()), color = t.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
            if (many) {
                Text(
                    if (open) "Hide ${s.rows.size} entries" else "${s.rows.size} entries",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
        if (s.breaks > 0) {
            Text(
                "${s.breaks} ${if (s.breaks == 1) "pause" else "pauses"} not counted",
                color = t.setSub,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        if (many && open) {
            Spacer(Modifier.height(8.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.06f))
                    .padding(vertical = 4.dp),
            ) {
                s.rows.forEach { e -> InnerEntry(e) { onEdit(e) } }
            }
        }
    }
}

/**
 * The history block of the book page: today's time and your pace, then your reading sessions, newest first.
 * Entries made close together (10 minutes or less apart) form one session; open it to see the exact entries.
 */
@Composable
fun ReadingHistory(entries: List<ReadingSession>, onEdit: (ReadingSession) -> Unit) {
    val t = pbTokens()
    var all by remember { mutableStateOf(false) }
    val sittings = remember(entries) { buildSessions(entries).sortedByDescending { it.startMs } }
    if (sittings.isEmpty()) {
        Text(
            "No entries yet. Reading in Paperback is counted for you. Set a timer or add an entry to use your own time and pages instead, or for paper books and other apps.",
            color = t.setSub,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        return
    }
    val zone = remember { ZoneId.systemDefault() }
    val today = LocalDate.now(zone)
    val todaySeconds = entries
        .filter { Instant.ofEpochMilli(it.startMs).atZone(zone).toLocalDate() == today }
        .sumOf { it.seconds.toLong() }
    val pages = sittings.sumOf { it.pages }
    val seconds = sittings.sumOf { it.seconds }
    val pace = if (pages > 0 && seconds > 0) "  ·  ~%.1f min/page".format(seconds / 60.0 / pages) else ""
    val head = buildString {
        if (todaySeconds > 0) append("Today ${entryDuration(todaySeconds.toInt())}  ·  ")
        append("${sittings.size} ${if (sittings.size == 1) "session" else "sessions"}")
        append(pace)
    }
    Text(head, color = t.setSub, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
    Spacer(Modifier.height(10.dp))
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        (if (all) sittings else sittings.take(5)).forEach { s -> key(s.bookId, s.startMs) { SittingCard(s, onEdit) } }
    }
    if (sittings.size > 5) {
        Text(
            if (all) "Show fewer" else "Show all ${sittings.size}",
            color = MaterialTheme.colorScheme.primary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(12.dp)).clickable { all = !all }.padding(horizontal = 4.dp, vertical = 8.dp),
        )
    }
}

/** Two buttons side by side: the timer and a hand-made entry. */
@Composable
fun ReadingActions(timerRunning: Boolean, onTimer: () -> Unit, onAdd: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.weight(1f)) { PbButton(if (timerRunning) "Timer running" else "Timer", onClick = onTimer) }
        Box(Modifier.weight(1f)) { PbButton("Add entry", onClick = onAdd, ghost = true) }
    }
}
