package com.paperback.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.ReadingSession
import com.paperback.app.ui.theme.pbTokens

/**
 * Asked after you close a book: how long you read, how many pages, and whether to keep it. It is already saved,
 * so tapping outside, going back or "Keep" leaves it in your stats; only "Discard" removes it.
 */
@Composable
fun KeepSessionDialog(
    bookTitle: String,
    rows: List<ReadingSession>,
    onKeep: () -> Unit,
    onDiscard: () -> Unit,
) {
    val t = pbTokens()
    val seconds = rows.sumOf { it.seconds.toLong() }
    val pages = rows.sumOf { it.pages }
    val from = rows.map { it.fromPos }.filter { it > 0 }.minOrNull() ?: 0
    val to = rows.maxOf { it.toPos }
    val breaks = rows.sumOf { it.breaks }
    PbDialog("Keep this session?", onDismiss = onKeep) {
        Text(bookTitle, color = t.setSub, fontSize = 14.sp, maxLines = 2, modifier = Modifier.padding(bottom = 10.dp))
        KeepLine("Time read", entryDuration(seconds.toInt()))
        KeepLine("Pages", if (pages > 0) "$pages" + (if (from > 0 && to > from) "  (${from}–${to})" else "") else "none")
        if (pages > 0 && seconds > 0) KeepLine("Pace", "%.1f min/page".format(seconds / 60.0 / pages))
        if (rows.size > 1) KeepLine("Entries", "${rows.size}")
        if (breaks > 0) KeepLine("Pauses not counted", "$breaks")
        Text(
            "It is already saved. Discard removes it from your stats; your place in the book stays.",
            color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 10.dp),
        )
        PbDialogButtons(confirm = "Keep", onConfirm = onKeep, onCancel = onDiscard, cancel = "Discard")
    }
}

@Composable
private fun KeepLine(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.setSub, fontSize = 15.sp)
        Text(value, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}
