package com.paperback.app.ui

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

/*
 * The app's motion in one place, so every screen moves the same way: things you touch shrink a little under the
 * finger and spring back, things that appear ease out (fast at first, then settle), things that leave are quicker
 * than things that arrive. Compose follows the phone's "Remove animations" setting by itself, so nothing here
 * needs its own switch.
 */

/** Material's "emphasized decelerate" curve: quick start, long soft landing. Used for things that appear. */
val PbEaseOut = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)

/** Material's "emphasized accelerate" curve, for things that leave. */
val PbEaseIn = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)

/** Durations in milliseconds. Leaving is always shorter than arriving. */
const val PB_MS_QUICK = 140
const val PB_MS_ENTER = 260
const val PB_MS_LEAVE = 180

/**
 * A tap target that gives the finger something back: the element shrinks a little while pressed and springs back,
 * with the normal ripple on top. Put it where `.clickable` used to be, but **before** `.background(...)`, so the
 * background shrinks with it:
 *
 *     Modifier.height(44.dp).pbTap(onClick, RoundedCornerShape(20.dp)).background(color)
 *
 * [shape] clips the ripple (and the content) to the same rounded corners as the background. [haptic] adds a light
 * tick, for switches and choices. A null [onClick] makes it a plain, untouchable element.
 */
fun Modifier.pbTap(
    onClick: (() -> Unit)?,
    shape: Shape = RectangleShape,
    enabled: Boolean = true,
    pressedScale: Float = 0.96f,
    haptic: Boolean = false,
    onClickLabel: String? = null,
    role: Role? = null,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled && onClick != null) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "pbTap",
    )
    val feel = LocalHapticFeedback.current
    val indication = LocalIndication.current
    if (onClick == null) {
        Modifier.clip(shape)
    } else {
        Modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(shape)
            .clickable(
                interactionSource = source,
                indication = indication,
                enabled = enabled,
                onClickLabel = onClickLabel,
                role = role,
            ) {
                if (haptic) feel.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
    }
}

/**
 * Entrance for a block in a stack: it fades in and rises about 20 dp, [index] x 60 ms after the page opens, so a page
 * of cards arrives one after another instead of all at once. Plays once, when the block is first composed.
 */
fun Modifier.rise(index: Int): Modifier = composed {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(60L * index)
        shown = true
    }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(PB_MS_ENTER + 80, easing = PbEaseOut), label = "rise")
    Modifier.graphicsLayer {
        alpha = a
        translationY = (1f - a) * 20.dp.toPx()
    }
}

/**
 * [pbTap] with a long press, for book covers: it shrinks a little under the finger, and does not clip, so the cover's
 * shadow stays visible.
 */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.pbTapLong(
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
    pressedScale: Float = 0.96f,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "pbTapLong",
    )
    val indication = LocalIndication.current
    Modifier
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .combinedClickable(
            interactionSource = source,
            indication = indication,
            onClick = onClick,
            onLongClick = onLongClick,
        )
}
