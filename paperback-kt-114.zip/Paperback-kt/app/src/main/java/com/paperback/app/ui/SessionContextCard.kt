package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.SessionMood
import com.paperback.app.data.SessionPlace
import com.paperback.app.ui.theme.pbTokens

/**
 * An optional question on Home after you have read: where were you and how did it feel. Nothing is written unless you
 * tap Save; "Not now" hides it for this session and "Don't ask" turns it off. The answers show on Stats -> Habits.
 */
@Composable
fun SessionContextCard(
    bookTitle: String,
    minutes: Int,
    onSave: (place: Int, mood: Int) -> Unit,
    onDismiss: () -> Unit,
    onNever: () -> Unit,
) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    var place by remember { mutableIntStateOf(0) }
    var mood by remember { mutableIntStateOf(0) }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalHomeRound.current))
            .background(t.card)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Text("How was that session?", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "$minutes min in $bookTitle. Optional, and only saved if you tap Save.",
            color = t.setSub, fontSize = 13.sp, maxLines = 2, modifier = Modifier.padding(top = 2.dp),
        )
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 1 until SessionPlace.names.size) {
                ContextChip(SessionPlace.names[i], place == i, primary) { place = if (place == i) 0 else i }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 1 until SessionMood.names.size) {
                ContextChip(SessionMood.names[i], mood == i, primary) { mood = if (mood == i) 0 else i }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (place > 0 || mood > 0) {
                Text(
                    "Save", color = primary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onSave(place, mood) }.padding(vertical = 6.dp),
                )
            }
            Text("Not now", color = t.setSub, fontSize = 14.sp, modifier = Modifier.clickable { onDismiss() }.padding(vertical = 6.dp))
            Text("Don't ask", color = t.setSub, fontSize = 14.sp, modifier = Modifier.clickable { onNever() }.padding(vertical = 6.dp))
        }
    }
}

@Composable
private fun ContextChip(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val t = pbTokens()
    Text(
        label,
        color = if (selected) accent else t.ink,
        fontSize = 14.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) accent.copy(alpha = 0.16f) else t.ink.copy(alpha = 0.07f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}
