package com.paperback.app.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import com.paperback.app.ui.PB_MS_QUICK
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import com.paperback.app.ui.PbSlider
import kotlin.math.roundToInt

/** One page colour: its name and the colours the reader's controls use on it. */
class ReaderTheme(val name: String, val colors: ReaderColors)

/**
 * The page colours. The numbers are saved in the settings, so existing ones never change meaning:
 * 0 White, 1 Sepia, 2 Black (what used to be called Dark), then the newer ones.
 * [AUTO] (-1) is not a colour: it follows the phone, White in the light theme and Black in the dark one.
 */
object ReaderThemes {
    const val AUTO = -1

    private val themes = listOf(
        ReaderTheme("White", ReaderColors(card = Color(0xFFF3F3F3), ink = Color(0xFF111111), chip = Color.White, page = Color.White)),
        ReaderTheme("Sepia", ReaderColors(card = Color(0xFFEADFC6), ink = Color(0xFF5B4636), chip = Color(0xFFF6EEDC), page = Color(0xFFFAF4E8))),
        ReaderTheme("Black", ReaderColors(card = Color(0xFF1C1C1C), ink = Color(0xFFF2F2F2), chip = Color(0xFF2C2C2C), page = Color(0xFF000000))),
        ReaderTheme("Sage", ReaderColors(card = Color(0xFFC5D6C2), ink = Color(0xFF22332A), chip = Color(0xFFE3EDE0), page = Color(0xFFD6E3D3))),
        ReaderTheme("Slate", ReaderColors(card = Color(0xFF3A3E45), ink = Color(0xFFECEFF3), chip = Color(0xFF5A606A), page = Color(0xFF4A4F57))),
        ReaderTheme("Dark", ReaderColors(card = Color(0xFF2B2B2B), ink = Color(0xFFE8E8E8), chip = Color(0xFF383838), page = Color(0xFF1C1C1C))),
    )

    /** The order the colours are shown in. */
    val menuOrder = listOf(0, 1, 3, 4, 5, 2)

    /** The colour to draw with: a saved choice, or for [AUTO] White or Black depending on the phone's theme. */
    fun resolve(choice: Int, systemDark: Boolean): Int = if (choice in themes.indices) choice else if (systemDark) 2 else 0

    fun name(choice: Int): String = if (choice in themes.indices) themes[choice].name else "Auto"

    /** Colours of a colour that is already resolved (never [AUTO]). */
    fun colors(index: Int): ReaderColors = themes[if (index in themes.indices) index else 0].colors
}

/** A round colour swatch. With [split] it is half white, half black: the Auto choice. */
@Composable
internal fun ThemeDot(
    fill: Color,
    selected: Boolean,
    size: Dp,
    description: String,
    edge: Color,
    split: Boolean = false,
    onClick: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary
    val ring by animateColorAsState(if (selected) accent else edge, tween(PB_MS_QUICK), label = "dotRing")
    val gap by animateDpAsState(if (selected) 4.dp else 0.dp, tween(PB_MS_QUICK), label = "dotGap")
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description }
            .border(if (selected) 2.dp else 1.dp, ring, CircleShape)
            .padding(gap)
            .clip(CircleShape)
            .then(if (split) Modifier else Modifier.background(fill)),
    ) {
        if (split) {
            Row(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxHeight().background(Color.White))
                Box(Modifier.weight(1f).fillMaxHeight().background(Color.Black))
            }
        }
    }
}

/** Every page colour in one row, Auto first. [choice] is the saved choice (-1 = Auto). Used where there is room. */
@Composable
fun ThemePickerRow(c: ReaderColors, choice: Int, modifier: Modifier = Modifier, onPick: (Int) -> Unit) {
    val edge = c.ink.copy(alpha = 0.25f)
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ThemeDot(Color.Unspecified, choice < 0, 40.dp, "Auto, matches your phone", edge, split = true) { onPick(ReaderThemes.AUTO) }
        ReaderThemes.menuOrder.forEach { i ->
            ThemeDot(ReaderThemes.colors(i).page, choice == i, 40.dp, ReaderThemes.name(i), edge) { onPick(i) }
        }
    }
}

/** The pop-up behind the colour circle: Auto on top, then the six colours with their names. */
@Composable
internal fun ThemeMenu(c: ReaderColors, choice: Int, onPick: (Int) -> Unit) {
    val edge = c.ink.copy(alpha = 0.25f)
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .width(248.dp)
            .clip(shape)
            .background(c.chip)
            .border(1.dp, c.ink.copy(alpha = 0.12f), shape)
            .padding(12.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .clickable { onPick(ReaderThemes.AUTO) }
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ThemeDot(Color.Unspecified, choice < 0, 36.dp, "Auto", edge, split = true) { onPick(ReaderThemes.AUTO) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Auto", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text("Matches your phone", color = c.ink.copy(alpha = 0.6f), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        ReaderThemes.menuOrder.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { i ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        ThemeDot(ReaderThemes.colors(i).page, choice == i, 44.dp, ReaderThemes.name(i), edge) { onPick(i) }
                        Text(
                            ReaderThemes.name(i),
                            color = c.ink.copy(alpha = 0.75f),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                        )
                    }
                }
            }
        }
    }
}

/** The pop-up behind the brightness button: a slider and Auto (same as the phone). */
@Composable
internal fun BrightnessMenu(c: ReaderColors, brightness: Float, onBrightness: (Float) -> Unit) {
    val auto = brightness < 0f
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .width(264.dp)
            .clip(shape)
            .background(c.chip)
            .border(1.dp, c.ink.copy(alpha = 0.12f), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Brightness", modifier = Modifier.weight(1f), color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(
                if (auto) "Same as phone" else "${(brightness * 100).roundToInt()}%",
                color = c.ink.copy(alpha = 0.6f),
                fontSize = 13.sp,
            )
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            PbSlider(
                value = if (auto) 0.5f else brightness,
                onValueChange = { onBrightness(it.coerceIn(0.05f, 1f)) },
                valueRange = 0.05f..1f,
                trackColor = c.ink.copy(alpha = 0.15f),
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            Pill(c, "Auto", selected = auto, container = c.ink.copy(alpha = 0.08f)) { onBrightness(-1f) }
        }
    }
}

/** Puts a pop-up just above its anchor, its right edge level with the anchor's, and keeps it on screen. */
private class AboveEnd(private val gapPx: Int) : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize,
    ): IntOffset {
        val x = (anchorBounds.right - popupContentSize.width).coerceIn(0, (windowSize.width - popupContentSize.width).coerceAtLeast(0))
        val y = (anchorBounds.top - popupContentSize.height - gapPx).coerceAtLeast(0)
        return IntOffset(x, y)
    }
}

/** Call inside the Box that holds the anchor. A tap outside, or Back, calls [onDismiss]. */
@Composable
internal fun AnchoredPopup(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    val gap = with(LocalDensity.current) { 10.dp.roundToPx() }
    Popup(
        popupPositionProvider = remember(gap) { AboveEnd(gap) },
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true),
    ) { content() }
}
