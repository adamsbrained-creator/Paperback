package com.paperback.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.ui.theme.pbTokens

/*
 * "Why this?" for suggestions. A screen that shows suggestions wraps its content in [WithExplanations]; any
 * [SuggestionMenu] inside it then offers "Why this?" beside "Not interested", and the answer shows in a dialog.
 */

/** What links a suggestion to you, as short lines under the book's title. */
class Explanation(val title: String, val lines: List<String>)

/** Asks for the explanation of a suggested book; null outside a [WithExplanations]. */
val LocalExplain = compositionLocalOf<((Any) -> Unit)?> { null }

/**
 * Shows [content] with "Why this?" available in its suggestion menus. [explain] turns the long-pressed book (a
 * `Book` or a `CatalogBook`) into its [Explanation]; null shows nothing.
 */
@Composable
fun WithExplanations(explain: (Any) -> Explanation?, content: @Composable () -> Unit) {
    var target by remember { mutableStateOf<Any?>(null) }
    CompositionLocalProvider(LocalExplain provides { picked: Any -> target = picked }) { content() }
    val shown = target?.let { explain(it) }
    if (shown != null) {
        val t = pbTokens()
        PbDialog(shown.title, onDismiss = { target = null }) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                shown.lines.forEach { line ->
                    Text("\u2022 $line", color = t.ink, fontSize = 15.sp, lineHeight = 21.sp)
                }
            }
            Spacer(Modifier.height(20.dp))
            PbButton("Close", onClick = { target = null })
        }
    }
}

/** The long-press menu of a suggestion: "Why this?" (inside a [WithExplanations]) and "Not interested". */
@Composable
fun SuggestionMenu(expanded: Boolean, onClose: () -> Unit, target: Any, onDismiss: () -> Unit) {
    val explain = LocalExplain.current
    PbMenu(expanded = expanded, onDismiss = onClose) {
        if (explain != null) {
            DropdownMenuItem(text = { Text("Why this?") }, onClick = { onClose(); explain(target) })
        }
        DropdownMenuItem(text = { Text("Not interested") }, onClick = { onClose(); onDismiss() })
    }
}
