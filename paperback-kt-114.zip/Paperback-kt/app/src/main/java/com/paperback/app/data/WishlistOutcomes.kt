package com.paperback.app.data

import com.paperback.app.catalog.TitleKey
import java.time.Instant
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/** A book that left the Want to read list: when it was saved, when it left, and whether you added a copy. */
class WishOutcome(val title: String, val savedAt: Long, val leftAt: Long, val added: Boolean)

/** What became of the books you saved. */
class WishOutcomes(
    /** Books that left the list since outcomes were kept, plus the ones still on it. */
    val savedEver: Int,
    val waiting: Int,
    /** Left because you added a copy to your library. */
    val added: Int,
    /** Left because you took them off the list. */
    val removed: Int,
    /** Of the books added to the library, how many you have finished. */
    val finished: Int,
    /** Average days between saving a book and adding it, -1 when no saved day is known. */
    val averageDaysToAdd: Int,
) {
    /** Of the books that left the list, the percent that went into your library; 0 when none left. */
    val addedPercent: Int get() = if (added + removed == 0) 0 else (added * 100.0 / (added + removed)).toInt()

    /** Of the books added to the library, the percent you finished. */
    val finishedPercent: Int get() = if (added == 0) 0 else (finished * 100.0 / added).toInt()
}

/**
 * What became of the Want to read list, from the log of books that left it ([log]), how many are still on it
 * ([waiting]) and your library ([books], to see which added books you finished). Null until a book has left.
 */
fun wishlistOutcomes(log: List<WishOutcome>, waiting: Int, books: List<Book>, zone: ZoneId): WishOutcomes? {
    if (log.isEmpty()) return null
    val finishedKeys = books.filter { it.finished }.mapTo(HashSet()) { TitleKey.of(it.title) }
    val added = log.filter { it.added }
    val waits = added.filter { it.savedAt > 0L }.map {
        ChronoUnit.DAYS.between(
            Instant.ofEpochMilli(it.savedAt).atZone(zone).toLocalDate(),
            Instant.ofEpochMilli(it.leftAt).atZone(zone).toLocalDate(),
        ).toInt().coerceAtLeast(0)
    }
    return WishOutcomes(
        savedEver = log.size + waiting,
        waiting = waiting,
        added = added.size,
        removed = log.size - added.size,
        finished = added.count { TitleKey.of(it.title) in finishedKeys },
        averageDaysToAdd = if (waits.isEmpty()) -1 else waits.sum() / waits.size,
    )
}
