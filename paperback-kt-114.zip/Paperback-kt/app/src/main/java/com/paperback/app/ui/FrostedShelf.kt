package com.paperback.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.Tags
import com.paperback.app.ui.theme.pbTokens
import kotlinx.coroutines.launch

/** The colour of the frosted ledge (Settings → App style → Frosted shelf color). */
val LocalLedgeColor = compositionLocalOf { Color(0xFFF5A54A) }

private val COVER_W = 100.dp
private val COVER_H = 150.dp

/**
 * Covers in a row you swipe sideways, with a frosted glass ledge across the lower part of the covers like the
 * front of a real shelf. The ledge stays put while the covers slide behind it. Taps go through it to the covers.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FrostedRow(
    books: List<Book>,
    onClick: (Book) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyListState = rememberLazyListState(),
    menu: (@Composable ColumnScope.(Book, () -> Unit) -> Unit)? = null,
) {
    var menuId by remember { mutableStateOf<String?>(null) }
    val ledge = LocalLedgeColor.current
    val shape = RoundedCornerShape(14.dp)
    Box(modifier.fillMaxWidth().height(COVER_H + 8.dp)) {
        LazyRow(state = state, horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 8.dp)) {
            items(books, key = { it.id }) { b ->
                val tap = Modifier.pbTapLong({ onClick(b) }, if (menu != null) ({ menuId = b.id }) else null)
                Box(Modifier.width(COVER_W).then(tap)) {
                    BookCover(b, Modifier.fillMaxWidth())
                    if (menu != null && menuId == b.id) {
                        DropdownMenu(
                            expanded = true,
                            onDismissRequest = { menuId = null },
                            shape = RoundedCornerShape(22.dp),
                            containerColor = pbTokens().menuBg,
                            tonalElevation = 0.dp,
                            shadowElevation = 12.dp,
                        ) { menu.invoke(this, b) { menuId = null } }
                    }
                }
            }
        }
        // the ledge: tinted glass with a soft shine on top, a thin light edge and a shadow, with a screw at each end
        Row(
            Modifier
                .align(Alignment.TopStart)
                .offset(y = 98.dp)
                .fillMaxWidth()
                .height(44.dp)
                .shadow(10.dp, shape, ambientColor = Color.Black.copy(alpha = 0.25f), spotColor = Color.Black.copy(alpha = 0.25f))
                .clip(shape)
                .background(ledge.copy(alpha = 0.62f))
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.28f), Color.Transparent)))
                .border(1.dp, Color.White.copy(alpha = 0.4f), shape)
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.75f)))
            Box(Modifier.size(10.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.75f)))
        }
    }
}

/** A Library shelf: the name, how many books, arrows that slide the row, and the frosted row itself. */
@Composable
fun FrostedShelfGroup(
    title: String,
    books: List<Book>,
    onClick: (Book) -> Unit,
    menu: (@Composable ColumnScope.(Book, () -> Unit) -> Unit)?,
) {
    val t = pbTokens()
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val step = with(LocalDensity.current) { 230.dp.toPx() }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
            Text(if (books.size == 1) "1 book" else "${books.size} books", color = t.setSub, fontSize = 13.sp)
            Box(
                Modifier.size(44.dp).clip(CircleShape).clickable { scope.launch { state.animateScrollBy(-step) } },
                contentAlignment = Alignment.Center,
            ) { Text("\u2039", color = t.setSub, fontSize = 24.sp) }
            Box(
                Modifier.size(44.dp).clip(CircleShape).clickable { scope.launch { state.animateScrollBy(step) } },
                contentAlignment = Alignment.Center,
            ) { Text("\u203A", color = t.setSub, fontSize = 24.sp) }
        }
        FrostedRow(books, onClick, state = state, menu = menu)
    }
}

/**
 * The Library split into shelves by genre: the biggest genres first, books with no genre on "Other".
 * With [pinFavorites], favorites get a shelf of their own on top.
 */
fun frostedGroups(books: List<Book>, pinFavorites: Boolean): List<Pair<String, List<Book>>> {
    val out = mutableListOf<Pair<String, List<Book>>>()
    val pinned = if (pinFavorites) books.filter { it.favorite } else emptyList()
    if (pinned.isNotEmpty()) out += "Favorites" to pinned
    val rest = if (pinned.isEmpty()) books else books.filter { !it.favorite }
    val top = Tags.counts(rest).take(12).map { it.first }
    val byTag = LinkedHashMap<String, MutableList<Book>>()
    val other = mutableListOf<Book>()
    rest.forEach { b ->
        val tag = top.firstOrNull { name -> b.tags.any { it.equals(name, ignoreCase = true) } }
        if (tag == null) other += b else byTag.getOrPut(tag) { mutableListOf() } += b
    }
    byTag.entries.sortedByDescending { it.value.size }.forEach { out += it.key to it.value }
    if (other.isNotEmpty()) out += "Other" to other
    return out
}
