package com.paperback.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.catalog.Categories
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.catalog.CatalogList
import com.paperback.app.data.catalog.Load
import com.paperback.app.ui.theme.pbTokens

/** The page title for a "see all" list, known before it loads. */
fun browseTitle(kind: String, value: String): String = when (kind) {
    "trending" -> "Trending this week"
    "foryou" -> "For you"
    "cat" -> Categories.bySlug(value)?.name ?: value
    else -> value
}

/** A grid of catalog books: a category, the trending list, your recommendations, an author or a genre. */
@Composable
fun CatalogBrowseScreen(
    kind: String,
    arg: String,
    ownedKeys: Set<String>,
    catalog: CatalogController,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenBook: (CatalogBook) -> Unit,
) {
    val t = pbTokens()
    var attempt by remember(kind, arg) { mutableIntStateOf(0) }
    val state by produceState<Load<CatalogList>>(Load.Loading, kind, arg, attempt) {
        value = Load.Loading
        value = catalog.list(kind, arg).fold({ Load.Ready(it) }, { Load.Failed(it.message ?: "") })
    }

    // books you said "not interested" to on this page leave it at once
    var hidden by remember(kind, arg) { mutableStateOf(emptySet<String>()) }

    // long-press a suggestion for "Why this?" and "Not interested"
    WithExplanations({ target -> if (target is CatalogBook) Explanation(target.title, catalog.explain(target)) else null }) {
    PbListPage(browseTitle(kind, arg), headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(12.dp))
        when (val s = state) {
            is Load.Loading -> Text("Loading…", color = t.setSub, modifier = Modifier.padding(vertical = 16.dp))
            is Load.Failed -> NoteCard(s.message, action = "Try again", onAction = { attempt++ })
            is Load.Ready -> {
                if (s.value.books.isEmpty()) {
                    Text(
                        if (kind == "foryou") "No recommendations yet. Rate a few books, or mark some as favorites." else "Nothing found.",
                        color = t.setSub,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(104.dp),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 112.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(20.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        items(s.value.books.filter { it.id !in hidden }, key = { it.id }) { b ->
                            SuggestionCard(
                                b,
                                note = s.value.reasons[b.id],
                                owned = TitleKey.of(b.title) in ownedKeys,
                                onDismiss = if (kind == "foryou") ({ book -> catalog.dismiss(book); hidden = hidden + book.id }) else null,
                            ) { onOpenBook(b) }
                        }
                    }
                }
            }
        }
    }
    }
}
