package com.paperback.app.reader

/** The first part of a session that is timed on its own (for the warm-up curve). */
private const val EARLY_SECONDS = 300L

/** The idle limit never grows past this, however slowly you read. */
private const val MAX_CAP_MS = 8 * 60_000L

/** Page turns kept to learn how long a page takes you. */
private const val SAMPLES = 15

/**
 * Counts reading time without counting idle time. Every page turn credits the time since the previous one, but
 * never more than the idle limit. The limit is [capSeconds] at least, and grows to three times your usual page
 * time when you read slowly, so a long page is not cut short. When you leave the reader, the time since your
 * last page turn is credited only up to about twice a normal page, so a phone left lying open is not counted.
 * Pure logic, no Android.
 */
class ReadingTracker(private val capSeconds: Long = 180) {
    class Flush(
        val startMs: Long, val seconds: Int, val pages: Int, val fromPos: Int = 0, val toPos: Int = 0,
        /** Distinct chapters (files of the book) you were in during the session. */
        val chapters: Int = 0,
        /** Times time was cut short (a gap over the idle limit, or an idle tail at the end): a pause, a phone call, a nap. */
        val breaks: Int = 0,
        /** Pages turned and seconds read in the first five minutes of the session. */
        val earlyPages: Int = 0,
        val earlySeconds: Int = 0,
        /** The real time you left the reader (wall clock), not start plus counted time. */
        val endMs: Long = 0L,
    )

    private var sessionStart = 0L
    private var lastTick = 0L
    /** Reading time in milliseconds: whole seconds were cut off at every page turn before, which added up. */
    private var millis = 0L
    private val seconds: Long get() = (millis + 500) / 1000
    private var pages = 0
    private var lastPosition = -1
    private var firstPosition = -1
    private var breaks = 0
    private var earlyPages = 0
    private val chapterKeys = HashSet<String>()
    /** How long your last few page turns took, in milliseconds (kept across pauses: it is how you read, not one stretch). */
    private val samples = ArrayDeque<Long>()

    private val baseCapMs: Long get() = capSeconds * 1000

    private fun typicalPageMs(): Long? {
        if (samples.size < 3) return null
        val sorted = samples.sorted()
        return sorted[sorted.size / 2]
    }

    /** The longest gap between two page turns that still counts as reading. */
    private fun capMs(): Long {
        val typical = if (samples.size >= 5) typicalPageMs() else null
        return if (typical == null) baseCapMs else maxOf(baseCapMs, minOf(typical * 3, MAX_CAP_MS))
    }

    /** The most credited for the time between your last page turn and leaving the reader. */
    private fun tailCapMs(): Long {
        val typical = typicalPageMs()
        return if (typical == null) minOf(capMs(), 90_000L) else (typical * 2).coerceIn(30_000L, capMs())
    }

    /** Call when the page you are on changes chapter; a chapter counts once per session. */
    fun onChapter(key: String) {
        if (key.isNotEmpty()) chapterKeys.add(key)
    }

    fun resume(now: Long) {
        if (firstPosition < 0 && lastPosition >= 0) firstPosition = lastPosition // the page you start on
        if (sessionStart == 0L) sessionStart = now
        lastTick = now
    }

    fun onPosition(now: Long, position: Int) {
        val gap = if (lastTick > 0L) now - lastTick else 0L
        val cap = capMs()
        credit(now)
        // Small forward steps are pages read; jumps (slider, table of contents) are not.
        if (lastPosition in 0 until position && position - lastPosition <= 3) {
            val step = position - lastPosition
            pages += step
            if (seconds <= EARLY_SECONDS) earlyPages += step
            // learn your page time from real turns only (not a pause), per page
            if (gap in 1_000L..cap) {
                samples.addLast(gap / step)
                if (samples.size > SAMPLES) samples.removeFirst()
            }
        }
        lastPosition = position
        if (firstPosition < 0) firstPosition = position
    }

    /** Call when the reader goes to the background. Returns what to save, or null if nothing happened. */
    fun pause(now: Long): Flush? {
        if (lastTick > 0L) {
            // the tail: time since your last page turn counts only up to a normal page or two
            val gap = (now - lastTick).coerceAtLeast(0L)
            val tail = tailCapMs()
            if (gap > tail) breaks++
            millis += gap.coerceAtMost(tail)
        }
        lastTick = 0L
        if (seconds <= 0L && pages <= 0) {
            // nothing read: forget this stretch, so the next one starts at its own start time
            sessionStart = 0L
            breaks = 0
            earlyPages = 0
            chapterKeys.clear()
            millis = 0L
            firstPosition = -1
            return null
        }
        val out = Flush(
            sessionStart, seconds.toInt(), pages, firstPosition.coerceAtLeast(0), lastPosition.coerceAtLeast(0),
            chapters = chapterKeys.size, breaks = breaks,
            earlyPages = earlyPages, earlySeconds = seconds.coerceAtMost(EARLY_SECONDS).toInt(),
            endMs = now,
        )
        sessionStart = 0L
        breaks = 0
        earlyPages = 0
        chapterKeys.clear()
        millis = 0L
        pages = 0
        firstPosition = -1
        return out
    }

    private fun credit(now: Long) {
        if (lastTick > 0L) {
            val gap = now - lastTick
            val cap = capMs()
            if (gap > cap) breaks++
            millis += gap.coerceIn(0L, cap)
        }
        lastTick = now
    }
}
