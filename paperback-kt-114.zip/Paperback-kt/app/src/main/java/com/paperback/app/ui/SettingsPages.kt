package com.paperback.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.selection.selectable
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Backup
import com.paperback.app.data.BackupCounts
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.GoalStyle
import com.paperback.app.data.IconStyle
import com.paperback.app.data.MoreStyle
import com.paperback.app.data.BookPageStyle
import com.paperback.app.data.NavStyle
import com.paperback.app.data.PendingBackup
import com.paperback.app.data.ThemeMode
import com.paperback.app.data.ReaderLook
import com.paperback.app.reader.ReaderColors
import com.paperback.app.reader.ReaderLookControls
import com.paperback.app.reader.ReaderThemes
import com.paperback.app.reader.ThemePickerRow
import com.paperback.app.reader.readerColors
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.Coral
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlin.math.roundToInt

// ---- shared pieces ------------------------------------------------------------------------------

/** The big pill button (.pb-btn): ink on page colour, or [ghost] on the card colour. */
@Composable
fun PbButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, ghost: Boolean = false, enabled: Boolean = true, destructive: Boolean = false) {
    val t = pbTokens()
    Box(
        modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.4f)
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(if (ghost) t.card else t.ink)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (destructive) DangerRed else if (ghost) t.ink else t.bg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** A little note under a card (.pb-note). */
@Composable
fun PbNote(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(start = 2.dp, end = 2.dp, top = 8.dp),
        color = pbTokens().sub,
        fontSize = 13.sp,
        lineHeight = 18.2.sp,
    )
}

/** The rounded segmented switch used on App style (.pb-as-seg). */
@Composable
internal fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .padding(top = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(t.asTrack)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        options.forEach { (value, label) ->
            val on = value == selected
            val shape = RoundedCornerShape(18.dp)
            Box(
                Modifier
                    .weight(1f)
                    .height(36.dp)
                    .then(if (on) Modifier.shadow(1.dp, shape) else Modifier)
                    .clip(shape)
                    .background(if (on) t.asOn else Color.Transparent)
                    .clickable { onSelect(value) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (on) t.asOnInk else t.setSub,
                    fontSize = 15.sp,
                    fontWeight = if (on) FontWeight.Medium else FontWeight.Normal,
                )
            }
        }
    }
}

/** A card with a title, a one-line hint and whatever [content] adds (.pb-as-card). */
@Composable
internal fun AsCard(title: String, hint: String, content: @Composable () -> Unit) {
    val t = pbTokens()
    Column(
        Modifier
            .padding(top = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .padding(16.dp),
    ) {
        Text(title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Text(hint, color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        content()
    }
}

// ---- App style ----------------------------------------------------------------------------------

private class StyleSample(val size: HeaderSize, val note: String? = null, val isDefault: Boolean = false)

private val SAMPLES = listOf(
    StyleSample(HeaderSize.Compact, note = "no circles, left-aligned"),
    StyleSample(HeaderSize.Regular, isDefault = true),
    StyleSample(HeaderSize.Large),
    StyleSample(HeaderSize.Minimal, note = "buttons only, no wordmark"),
)

@Composable
private fun Badge(text: String, selected: Boolean) {
    val t = pbTokens()
    Text(
        text,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) t.asSelBg else t.asBadge)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        color = if (selected) t.asSelInk else t.setSub,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
    )
}

/** Settings → App style: how much room the top bar takes, with a live sample of each size. */
@Composable
fun AppStyleScreen(
    headerSize: HeaderSize,
    onSize: (HeaderSize) -> Unit,
    navStyle: NavStyle,
    onNavStyle: (NavStyle) -> Unit,
    openBookPage: Boolean,
    onOpenBookPage: (Boolean) -> Unit,
    swipeBack: Boolean,
    onSwipeBack: (Boolean) -> Unit,
    swipeTabs: Boolean,
    onSwipeTabs: (Boolean) -> Unit,
    ratingScale: Int,
    onRatingScale: (Int) -> Unit,
    ratingSteps: Int,
    onRatingSteps: (Int) -> Unit,
    iconStyle: IconStyle,
    onIconStyle: (IconStyle) -> Unit,
    moreStyle: MoreStyle,
    onMoreStyle: (MoreStyle) -> Unit,
    goalStyle: GoalStyle,
    onGoalStyle: (GoalStyle) -> Unit,
    statsHeader: com.paperback.app.data.StatsHeader,
    onStatsHeader: (com.paperback.app.data.StatsHeader) -> Unit,
    statsBackground: com.paperback.app.data.StatsBackground,
    onStatsBackground: (com.paperback.app.data.StatsBackground) -> Unit,
    appBackground: com.paperback.app.data.AppBackground,
    onAppBackground: (com.paperback.app.data.AppBackground) -> Unit,
    activityStyle: com.paperback.app.data.ActivityStyle,
    onActivityStyle: (com.paperback.app.data.ActivityStyle) -> Unit,
    showRecommendations: Boolean,
    onShowRecommendations: (Boolean) -> Unit,
    hiddenCount: Int,
    onForgetHidden: () -> Unit,
    onOpenTaste: () -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    ledgeColor: Int = 0xFFF5A54A.toInt(),
    onLedgeColor: (Int) -> Unit = {},
    bookPageStyle: BookPageStyle = BookPageStyle.Classic,
    onBookPageStyle: (BookPageStyle) -> Unit = {},
    /** The name of the layout built in Customize Home, or null while Home is the original one. */
    homeLayoutName: String? = null,
    onCustomizeHome: () -> Unit = {},
    onResetHome: () -> Unit = {},
) {
    val t = pbTokens()
    PbPage("App style", headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(10.dp))
        AsCard(
            "App icon",
            "The icon on your home screen. Same book, two looks. Your launcher may take a few seconds to change it.",
        ) {
            Row(Modifier.padding(top = 14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconStyle.values().forEach { style ->
                    val on = style == iconStyle
                    val shape = RoundedCornerShape(20.dp)
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(shape)
                            .border(if (on) 2.dp else 1.dp, if (on) Accent.color else t.asEdge, shape)
                            .selectable(selected = on, onClick = { onIconStyle(style) }, role = Role.RadioButton)
                            .padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Image(painterResource(style.preview), contentDescription = "${style.label} icon", modifier = Modifier.size(84.dp))
                        Text(style.label, modifier = Modifier.padding(top = 10.dp), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(style.note, color = t.setSub, fontSize = 12.sp, modifier = Modifier.padding(top = 1.dp, bottom = 8.dp))
                        Badge(if (on) "Selected" else "Tap to use", on)
                    }
                }
            }
        }
        AsCard(
            "Navigation",
            when (navStyle) {
                NavStyle.Clean -> "No bar at the bottom. Open Home, Library, Stats and the rest with the menu button at the top."
                NavStyle.Dots -> "Only the name of the page and four small dots at the bottom. Swipe sideways to change page, or tap a dot."
                else -> "Home, Library, Stats and Settings stay one tap away at the bottom."
            },
        ) {
            Segmented(NavStyle.values().map { it to it.label }, navStyle, onNavStyle)
        }
        AsCard(
            "Book page",
            if (bookPageStyle == BookPageStyle.Floating) {
                "A big cover with your progress beside it, the description under the title, and one bar floating at the bottom with favorite, notes, share and the Read button. Everything else is below as you scroll."
            } else {
                "The cover and title in the middle, with the read button and small icons under them."
            },
        ) {
            Segmented(BookPageStyle.values().map { it to it.label }, bookPageStyle, onBookPageStyle)
        }
        AsCard(
            "Frosted shelf color",
            "The glass ledge in front of the covers in the Frosted shelf view, on Home and in the Library. Mix any color you like.",
        ) {
            val r = (ledgeColor shr 16) and 0xFF
            val g = (ledgeColor shr 8) and 0xFF
            val b = ledgeColor and 0xFF
            fun mix(nr: Int, ng: Int, nb: Int) = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
            Box(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .height(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(ledgeColor).copy(alpha = 0.62f)),
            )
            listOf(Triple("Red", r, Color(0xFFE5484D)), Triple("Green", g, Color(0xFF2FA866)), Triple("Blue", b, Color(0xFF3B82F6))).forEachIndexed { i, (name, v, tint) ->
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = t.ink, fontSize = 14.sp, modifier = Modifier.width(56.dp))
                    PbSlider(
                        value = v.toFloat(),
                        onValueChange = {
                            val n = it.toInt().coerceIn(0, 255)
                            onLedgeColor(when (i) { 0 -> mix(n, g, b); 1 -> mix(r, n, b); else -> mix(r, g, n) })
                        },
                        trackColor = t.ink.copy(alpha = 0.08f),
                        modifier = Modifier.weight(1f),
                        valueRange = 0f..255f,
                        fillColor = tint,
                    )
                    Text(v.toString(), color = t.setSub, fontSize = 13.sp, modifier = Modifier.width(36.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                }
            }
        }
        AsCard(
            "More page",
            if (moreStyle == MoreStyle.Bento) "Big tiles for reading, notes and shelves, shelf spines for your lists, and a short list of app pages."
            else "Five cards you open one at a time, with a field to find a page by name.",
        ) {
            Segmented(MoreStyle.values().map { it to it.label }, moreStyle, onMoreStyle)
        }
        AsCard(
            "Stats header",
            if (statsHeader == com.paperback.app.data.StatsHeader.Own) "Stats has its own title bar: the date, a calendar button and search, with the menu button on the left."
            else "Stats uses the same header as Home and Library (menu, name, search), in the size you chose above.",
        ) {
            Segmented(com.paperback.app.data.StatsHeader.values().map { it to it.label }, statsHeader, onStatsHeader)
        }
        AsCard(
            "Activity chart",
            when (activityStyle) {
                com.paperback.app.data.ActivityStyle.Chart -> "Bars for each day, month or year, as before."
                com.paperback.app.data.ActivityStyle.List -> "A compact list: one thin bar per row, newest first."
                com.paperback.app.data.ActivityStyle.Big -> "A big number and the best and average under it, without a chart."
            },
        ) {
            Segmented(com.paperback.app.data.ActivityStyle.values().map { it to it.label }, activityStyle, onActivityStyle)
        }
        AsCard(
            "App background",
            if (appBackground == com.paperback.app.data.AppBackground.Gray) "Every screen gets the grey look: graphite cards on a dark grey page, or white cards on a light grey page in the light theme."
            else "Black in the dark theme and white in the light theme, with the grey cards you know.",
        ) {
            Segmented(com.paperback.app.data.AppBackground.values().map { it to it.label }, appBackground, onAppBackground)
        }
        AsCard(
            "Stats background",
            if (appBackground == com.paperback.app.data.AppBackground.Gray) "Stats follows the app, which is grey."
            else if (statsBackground == com.paperback.app.data.StatsBackground.Gray) "Graphite cards on a grey page. In the light theme: white cards on a light grey page."
            else "The same black (dark theme) or white (light theme) as the rest of the app.",
        ) {
            Segmented(com.paperback.app.data.StatsBackground.values().map { it to it.label }, statsBackground, onStatsBackground)
        }
        AsCard(
            "Recommendations on Home",
            if (showRecommendations) "Home shows suggestions from your library (\"Recommended for you\", \"Worth reading again\") and from the online catalog (\"Books you might like\", \"New from authors you read\")."
            else "Home leaves out all suggestions. Your Want to read list stays.",
        ) {
            Segmented(listOf(true to "Show", false to "Hide"), showRecommendations, onShowRecommendations)
            Text(
                "See what Paperback thinks you like",
                modifier = Modifier
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onOpenTaste)
                    .padding(vertical = 6.dp, horizontal = 2.dp),
                color = Accent.color,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
            )
            if (hiddenCount > 0) {
                Text(
                    "Bring back $hiddenCount hidden ${if (hiddenCount == 1) "book" else "books"}",
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onForgetHidden)
                        .padding(vertical = 6.dp, horizontal = 2.dp),
                    color = Accent.color,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
        AsCard(
            "Home layout",
            if (homeLayoutName == null) "Home as it always was. Customize it: start from a ready-made layout, hide or add sections, pick how each one looks."
            else "Your layout: $homeLayoutName. Change it again, or go back to Home as it was.",
        ) {
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionPill(if (homeLayoutName == null) "Customize Home" else "Edit layout", onCustomizeHome)
                if (homeLayoutName != null) ActionPill("Use original", onResetHome)
            }
        }
        AsCard(
            "Tapping a book",
            if (openBookPage) "Opens the book's page first: progress, reading timer, entries, notes. Start reading from there."
            else "Opens the reader at once. The page is still there: long-press a book in Library, or tap a book on any shelf page.",
        ) {
            Segmented(listOf(true to "Its page", false to "The reader"), openBookPage, onOpenBookPage)
        }
        AsCard(
            "Swipe to go back",
            "Swipe to the right anywhere on a page to go back one page, as well as the phone's own back gesture. Sliders, charts and lists that scroll sideways keep their swipe.",
        ) {
            Segmented(listOf(true to "On", false to "Off"), swipeBack, onSwipeBack)
        }
        AsCard(
            "Swipe between main pages",
            "Swipe left or right on Home, Library, Stats or Settings to move to the next or the previous one.",
        ) {
            Segmented(listOf(true to "On", false to "Off"), swipeTabs, onSwipeTabs)
        }
        AsCard(
            "Rating scale",
            if (ratingScale == 10) "The number beside the stars is out of 10. The bar still has five stars; each star is 2 points."
            else "The number beside the stars is out of 5.",
        ) {
            Segmented(listOf(5 to "Out of 5", 10 to "Out of 10"), ratingScale, onRatingScale)
        }
        AsCard(
            "Rating steps",
            "How fine a rating is when you slide your finger over the stars: whole numbers, halves (4.5) or quarters (4.75).",
        ) {
            Segmented(listOf(1 to "Whole", 2 to "Halves", 4 to "Quarters"), ratingSteps, onRatingSteps)
        }
        Text(
            "Header: tap one to choose how much room the top bar takes on every screen. Compact and Buttons only give your books the most space.",
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 22.dp),
            color = t.setSub,
            fontSize = 15.sp,
            lineHeight = 21.75.sp,
        )
        SAMPLES.forEachIndexed { index, sample ->
            val on = headerSize == sample.size
            Column(
                Modifier
                    .padding(top = if (index == 0) 14.dp else 10.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .selectable(selected = on, onClick = { onSize(sample.size) }, role = Role.RadioButton)
                    .padding(top = 6.dp),
            ) {
                Row(
                    Modifier.padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(sample.size.label, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    if (sample.note != null) Text(sample.note, color = t.setSub, fontSize = 12.sp)
                    if (sample.isDefault) Badge("Default", selected = false)
                    if (on) Badge("Selected", selected = true)
                }
                val topPad = when (sample.size) {
                    HeaderSize.Compact -> 4.dp
                    HeaderSize.Regular -> 6.dp
                    HeaderSize.Large -> 12.dp
                    HeaderSize.Minimal -> 6.dp
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .border(if (on) 2.dp else 1.dp, if (on) Accent.color else t.asEdge, RoundedCornerShape(22.dp))
                        .padding(start = 12.dp, end = 12.dp, top = topPad, bottom = 12.dp),
                ) {
                    PageHeader(label = "Library", size = sample.size)
                }
            }
        }
    }
}

// ---- About --------------------------------------------------------------------------------------

private class AboutCard(val title: String, val body: List<androidx.compose.ui.text.AnnotatedString>)

/** Settings → About Paperback: the logo, the version, then Credits and Open-source licenses cards. */
@Composable
fun AboutScreen(
    headerSize: HeaderSize,
    version: String,
    iconStyle: IconStyle,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    var open by remember { mutableStateOf<String?>(null) }

    fun text(vararg parts: Pair<Boolean, String>) = buildAnnotatedString {
        parts.forEach { (bold, s) ->
            if (bold) withStyle(SpanStyle(color = t.ink, fontWeight = FontWeight.SemiBold)) { append(s) } else append(s)
        }
    }

    val cards = listOf(
        AboutCard(
            "Credits",
            listOf(
                text(
                    true to "Reading books.",
                    false to " EPUB files are shown with the Readium Kotlin Toolkit, made by EDRLab. PDF pages are drawn by Android's own PDF renderer.",
                ),
                text(
                    true to "Reflow as EPUB.",
                    false to " Text is read out of PDFs with PDFBox for Android, Tom Roush's port of Apache PDFBox. Scanned pages are read on the phone with Google's ML Kit text recognition.",
                ),
                text(
                    true to "Free books.",
                    false to " Discover browses the public catalogs of Standard Ebooks and Project Gutenberg. Paperback is not connected to either of them; the books and covers are theirs.",
                ),
                text(
                    true to "Book catalog.",
                    false to " Trending books, categories, covers, ratings and descriptions on the Search page come from Open Library, a project of the Internet Archive. When Open Library has no description or rating, Google Books is asked instead. Paperback is not connected to either of them. Nothing can be downloaded from these pages; they only tell you about books.",
                ),
                text(
                    true to "Built with",
                    false to " Kotlin, Jetpack Compose and AndroidX.",
                ),
                text(
                    true to "Your data.",
                    false to " Your library, notes, highlights and reading stats stay on this device. There is no account and no tracking. The only things that go online are the catalogs and covers you open in Discover, and, while the online catalog on the Search page is on, searches for books and the genres and authors you like (as search words). Your files, notes and reading times never leave the phone. You can turn the online catalog off at the bottom of the Search page.",
                ),
            ),
        ),
        AboutCard(
            "Open-source licenses",
            listOf(
                text(
                    true to "Readium Kotlin Toolkit",
                    false to " (EDRLab): BSD 3-Clause.",
                ),
                text(
                    true to "Jetpack Compose, AndroidX, Kotlin and kotlinx.coroutines",
                    false to " (Google, JetBrains): Apache License 2.0.",
                ),
                text(
                    true to "PDFBox for Android",
                    false to " (Tom Roush, based on Apache PDFBox): Apache License 2.0.",
                ),
                text(
                    true to "Android desugar JDK libs",
                    false to " (Google): GNU GPL version 2 with the Classpath Exception.",
                ),
                text(
                    true to "Google ML Kit text recognition",
                    false to " is not open source. It is used under the ML Kit terms of service.",
                ),
                text(
                    false to "The libraries above use other open-source libraries of their own, each under its own license. Every copyright notice stays with its author.",
                ),
            ),
        ),
    )

    PbPage("About", headerSize, onMenu, onSearch) {
        Column(Modifier.fillMaxWidth().padding(top = 44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(iconStyle.preview), contentDescription = "Paperback", modifier = Modifier.size(104.dp))
            Text(
                "paperback",
                modifier = Modifier.padding(top = 26.dp),
                color = t.ink,
                fontSize = 46.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = (-0.035).em,
            )
            Text(
                "Version $version",
                modifier = Modifier.padding(top = 10.dp),
                color = t.setSub,
                fontSize = 14.sp,
            )
        }
        Column(Modifier.padding(top = 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            cards.forEach { c ->
                val on = open == c.title
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(t.card)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { open = if (on) null else c.title }
                            .padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            c.title,
                            modifier = Modifier.weight(1f),
                            color = t.ink,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = (-0.01).em,
                        )
                        PbIcon(PbIconName.CaretRight, modifier = Modifier.rotate(if (on) 90f else 0f), size = 22.dp, tint = t.ink)
                    }
                    if (on) {
                        Column(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            c.body.forEach { p -> Text(p, color = t.setSub, fontSize = 14.sp, lineHeight = 21.sp) }
                        }
                    }
                }
            }
        }
    }
}

// ---- Appearance ---------------------------------------------------------------------------------

@Composable
private fun ThemeCard(dark: Boolean, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(28.dp)
    val ring = if (dark) Color(0x2EFFFFFF) else Color(0x1A000000)
    val lineA = if (dark) Color(0xFFCCCCCC) else Color(0xFF444444)
    val line = if (dark) Color(0xFF666666) else Color(0xFF9A9AA0)
    Box(
        modifier
            .height(150.dp)
            .clip(shape)
            .background(if (dark) Color.Black else Color.White)
            .border(if (selected) 3.dp else 1.dp, if (selected) Color(0xFF2330F0) else ring, shape)
            .clickable(onClick = onClick),
    ) {
        Column(Modifier.padding(start = 19.dp, end = 19.dp, top = 20.dp)) {
            Box(Modifier.fillMaxWidth(0.60f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(lineA))
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth(0.85f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(line))
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth(0.50f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(line))
        }
        Text(
            if (dark) "Dark" else "Light",
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 19.dp, bottom = 17.dp),
            color = if (dark) Color.White else Color(0xFF0A0A0A),
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/** Settings → Appearance: Light, Dark or Match system, and the accent colour. */
@Composable
fun AppearanceScreen(
    headerSize: HeaderSize,
    mode: ThemeMode,
    onMode: (ThemeMode) -> Unit,
    accent: Int,
    onAccent: (Int) -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    PbPage("Appearance", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ThemeCard(dark = false, selected = mode == ThemeMode.Light, onClick = { onMode(ThemeMode.Light) }, modifier = Modifier.weight(1f))
                ThemeCard(dark = true, selected = mode == ThemeMode.Dark, onClick = { onMode(ThemeMode.Dark) }, modifier = Modifier.weight(1f))
            }
            val auto = mode == ThemeMode.System
            Row {
                Box(
                    Modifier
                        .height(36.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (auto) t.ink else t.card)
                        .clickable { onMode(ThemeMode.System) }
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Match system", color = if (auto) t.bg else t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
            SectionLabel("Accent")
            AccentPicker(accent, onAccent)
            PbNote(
                "The accent colors buttons, progress and highlights. The app icon stays coral. " +
                    "Page colors and font size for reading are set inside a book (tap the middle of the page) " +
                    "and in Settings → Reader defaults.",
            )
        }
    }
}

// ---- Reader defaults ----------------------------------------------------------------------------

/** Settings → Reader defaults: font size and page colors, the same two choices the reader's controls change. */
@Composable
fun ReaderDefaultsScreen(
    headerSize: HeaderSize,
    fontSize: Double,
    theme: Int,
    look: ReaderLook,
    chromeStyle: Int,
    onFontSize: (Double) -> Unit,
    onTheme: (Int) -> Unit,
    onLook: (ReaderLook) -> Unit,
    onChromeStyle: (Int) -> Unit,
    askKeep: Boolean,
    onAskKeep: (Boolean) -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    var ask by remember { mutableStateOf(askKeep) }
    var controls by remember { mutableIntStateOf(chromeStyle) }
    var size by remember { mutableFloatStateOf(fontSize.toFloat()) }
    var page by remember { mutableIntStateOf(theme) }
    var layout by remember { mutableStateOf(look) }
    // The preview shows the colour the reader will really use: on Auto, white or black following the phone.
    val c = readerColors(ReaderThemes.resolve(page, isSystemInDarkTheme()))
    // The layout controls sit on a settings card, so they use the app's colours, not the page colours.
    val cardColors = ReaderColors(card = t.card, ink = t.ink, chip = t.bg, page = t.bg)
    PbPage("Reader defaults", headerSize, onMenu, onSearch) {
        Text(
            "How books look when you open them. You can also change these while reading.",
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 18.dp),
            color = t.setSub,
            fontSize = 15.sp,
            lineHeight = 21.75.sp,
        )
        AsCard("Font size", "${(size * 100).roundToInt()}% of the book's own size.") {
            PbSlider(
                value = size,
                onValueChange = {
                    size = (it * 10f).roundToInt() / 10f
                    onFontSize(size.toDouble())
                },
                valueRange = 0.6f..2.5f,
                trackColor = t.ink.copy(alpha = 0.15f),
            )
        }
        AsCard("Page colors", "Auto follows your phone: white in the light theme, black in the dark one. Or pick a color.") {
            Spacer(Modifier.height(12.dp))
            ThemePickerRow(cardColors, page) {
                page = it
                onTheme(it)
            }
        }
        AsCard("Reader controls", "The panel at the bottom of the page: compact, with quick settings, with icon tiles, or the settings panel with sliders and an Advanced page.") {
            Spacer(Modifier.height(10.dp))
            Segmented(listOf(0 to "Compact", 1 to "Quick", 2 to "Tiles", 3 to "Panel"), controls) {
                controls = it
                onChromeStyle(it)
            }
        }
        AsCard("Ask to keep a session", "After you close a book, show how long you read and how many pages, and ask whether to keep it. Sessions are saved already, so ignoring the question keeps them. Off: every session is kept without asking.") {
            Spacer(Modifier.height(10.dp))
            Segmented(listOf(true to "On", false to "Off"), ask) {
                ask = it
                onAskKeep(it)
            }
        }
        AsCard("Layout", "Page, text, header and footer: open a folder to change its settings.") {
            Spacer(Modifier.height(10.dp))
            ReaderLookControls(
                look = layout,
                onChange = {
                    layout = it
                    onLook(it)
                },
                c = cardColors,
                showBrightness = false,
            )
        }
        Text(
            "Call me Ishmael. Some years ago—never mind how long precisely—having little or no money in my purse, " +
                "and nothing particular to interest me on shore, I thought I would sail about a little and see the " +
                "watery part of the world.",
            modifier = Modifier
                .padding(top = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(c.page)
                .border(1.dp, t.asEdge, RoundedCornerShape(24.dp))
                .padding(horizontal = (20f * layout.margins).dp, vertical = 20.dp),
            color = c.ink,
            fontFamily = if (!layout.custom) PbSerif else when (layout.fontFamily) {
                1 -> FontFamily.SansSerif
                2 -> FontFamily.Monospace
                else -> FontFamily.Serif
            },
            fontSize = (16f * size).sp,
            lineHeight = (16f * size * (if (layout.custom) layout.lineSpacing else 1.5f)).sp,
            textAlign = if (layout.custom && layout.justify) TextAlign.Justify else TextAlign.Start,
        )
    }
}

// ---- Import -------------------------------------------------------------------------------------

/** Settings → Library & import: add books from the phone. */
@Composable
fun ImportScreen(
    headerSize: HeaderSize,
    busy: Boolean,
    onPick: () -> Unit,
    onDiscover: () -> Unit,
    onLibrary: () -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    PbPage("Import", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(t.card)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("Add books", color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("EPUB and PDF", color = t.sub, fontSize = 13.sp)
                PbButton(if (busy) "Importing…" else "Choose books from your phone", onPick, enabled = !busy)
            }
            PbNote("You can pick several files at once. To fetch books from the internet instead, open Discover.")
            PbButton("Discover free books", onDiscover, ghost = true)
            PbButton("Back to the Library", onLibrary, ghost = true)
        }
    }
}

// ---- Backup & restore ---------------------------------------------------------------------------

/** Settings → Backup & restore: one file with everything Paperback adds to your books. */
@Composable
fun BackupScreen(
    headerSize: HeaderSize,
    counts: BackupCounts?,
    pending: PendingBackup?,
    onSave: () -> Unit,
    onPick: () -> Unit,
    onApply: () -> Unit,
    onCancel: () -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    PbPage("Backup & restore", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(t.card).padding(16.dp)) {
                Text("Your Paperback data", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    (counts?.describe() ?: "Counting…") + ", plus your reading goals and settings.",
                    modifier = Modifier.padding(top = 6.dp),
                    color = t.sub,
                    fontSize = 13.sp,
                )
            }

            PbButton("Save a backup file", onSave)
            PbButton("Restore from a backup file", onPick, ghost = true)
            Text(
                "Also takes the zip from Bookshelf (Settings -> Export). Only what you do not have yet is added: sessions, quotes and books; nothing you already have is changed.",
                color = t.sub,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )

            if (pending != null) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(t.card).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    val fromBookshelf = pending.json.contains("\"platform\":\"bookshelf\"")
                    Text(if (fromBookshelf) "Add this from Bookshelf?" else "Restore this backup?", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    val made = Backup.madeOn(pending.exportedAt)
                    Text(
                        if (fromBookshelf) "New: " + pending.counts.describe() + ". Books you already have are not changed; " +
                            "only the sessions and quotes they are missing are added. Your settings stay as they are; the yearly book goal is taken over only while yours is still the default."
                        else (if (made != null) "Made $made. " else "") + pending.counts.describe() +
                            ". Favorites, ratings, finished marks, reading progress, goals and settings are set to what " +
                            "the backup says; bookmarks, highlights and reading history are added for the books in " +
                            "your library.",
                        color = t.sub,
                        fontSize = 13.sp,
                        lineHeight = 18.2.sp,
                    )
                    PbButton("Restore my data", onApply)
                    PbButton("Cancel", onCancel, ghost = true)
                }
            }

            PbNote(
                "This file holds only what Paperback adds: progress, favorites, ratings, bookmarks, highlights, " +
                    "notes, reading history, goals and settings. The book files themselves are not inside, so add " +
                    "your books to the library again before restoring.",
            )
        }
    }
}
