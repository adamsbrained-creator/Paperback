package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.paperback.app.data.Block
import com.paperback.app.data.BlockType
import com.paperback.app.data.HomeCatalog
import com.paperback.app.data.HomeLayout
import com.paperback.app.ui.theme.pbTokens

/*
 * Wireframes: a block (or a whole Home) as a few grey shapes. The layout gallery, the look pickers and the block
 * list use these instead of the real thing, so they cost nothing to draw however many are on screen at once.
 *
 * Everything is drawn on a 100-unit-wide page; a unit is a hundredth of the width the canvas has.
 */

/** The three colors a wireframe is drawn in. */
internal class WireInk(val faint: Color, val mid: Color, val accent: Color)

@Composable
internal fun rememberWireInk(): WireInk {
    val ink = pbTokens().ink
    val accent = MaterialTheme.colorScheme.primary
    return WireInk(faint = ink.copy(alpha = 0.10f), mid = ink.copy(alpha = 0.30f), accent = accent)
}

private const val TITLE = 7f

private fun hasTitle(block: Block): Boolean =
    HomeCatalog.options[block.type].orEmpty().any { it.key == "title" } && block.opt("title")

/** How tall the block is on the 100-unit page. */
internal fun wireHeight(block: Block): Float {
    val body = when (block.type) {
        BlockType.Greeting -> when (block.style) { "stats" -> 20f; "date" -> 18f; else -> 14f }
        BlockType.Alerts -> 14f
        BlockType.Continue -> when (block.style) { "card" -> 27f; "compact" -> 13f; "hero" -> 45f; else -> 21f }
        BlockType.NextAction -> 14f
        BlockType.Today -> when (block.style) { "strip" -> 9f; "ring" -> 37f; else -> 19f }
        BlockType.Shortcuts -> if (block.style == "grid") 22f else 8f
        BlockType.Quote -> if (block.style == "plain") 24f else 22f
        else -> when (block.style) { // the rows of books
            "spines" -> 24f
            "shelf", "frosted" -> 28f
            "grid" -> 31f
            "list" -> 34f
            else -> 30f
        }
    }
    return body + if (hasTitle(block)) TITLE else 0f
}

private class Pen(val d: DrawScope, val s: Float, val ink: WireInk) {
    fun box(x: Float, y: Float, w: Float, h: Float, r: Float = 2f, c: Color = ink.faint) {
        d.drawRoundRect(c, Offset(x * s, y * s), Size(w * s, h * s), CornerRadius(r * s, r * s))
    }

    fun line(x: Float, y: Float, w: Float, c: Color = ink.mid, h: Float = 2.2f) = box(x, y, w, h, h / 2f, c)

    fun dot(cx: Float, cy: Float, r: Float, c: Color) {
        d.drawCircle(c, r * s, Offset(cx * s, cy * s))
    }

    fun ring(cx: Float, cy: Float, r: Float, width: Float, share: Float) {
        val stroke = Stroke(width = width * s, cap = StrokeCap.Round)
        val topLeft = Offset((cx - r) * s, (cy - r) * s)
        val size = Size(2f * r * s, 2f * r * s)
        d.drawArc(ink.faint, 0f, 360f, false, topLeft, size, style = stroke)
        d.drawArc(ink.accent, -90f, 360f * share, false, topLeft, size, style = stroke)
    }
}

/** Draws [block] with its top edge at [top] (in units). [s] is how many pixels a unit is. */
internal fun DrawScope.drawWire(block: Block, top: Float, s: Float, ink: WireInk) {
    val p = Pen(this, s, ink)
    val y = top + if (hasTitle(block)) TITLE else 0f
    if (hasTitle(block)) p.line(0f, top + 1f, 26f, ink.mid, 2.6f)
    when (block.type) {
        BlockType.Greeting -> when (block.style) {
            "stats" -> {
                p.line(0f, y, 46f, ink.mid, 4.5f)
                p.line(0f, y + 7.5f, 30f, ink.faint, 2.4f)
                for (i in 0..2) p.box(i * 22f, y + 12.5f, 19f, 6f, 3f)
            }
            "date" -> {
                p.line(0f, y, 62f, ink.mid, 6.5f)
                p.line(0f, y + 10f, 36f, ink.faint, 2.4f)
            }
            else -> {
                p.line(0f, y, 46f, ink.mid, 4.5f)
                p.line(0f, y + 7.5f, 30f, ink.faint, 2.4f)
            }
        }
        BlockType.Alerts, BlockType.NextAction -> {
            p.box(0f, y, 100f, 14f, 4f)
            p.line(5f, y + 4f, 52f)
            p.line(5f, y + 8.5f, 36f, ink.mid.copy(alpha = 0.16f))
            p.box(76f, y + 4f, 18f, 6f, 3f, ink.accent.copy(alpha = 0.85f))
        }
        BlockType.Continue -> when (block.style) {
            "card" -> {
                p.box(0f, y, 100f, 27f, 5f)
                p.box(5f, y + 4f, 13f, 19f, 2f, ink.mid.copy(alpha = 0.22f))
                p.line(23f, y + 6f, 46f)
                p.line(23f, y + 11.5f, 30f, ink.mid.copy(alpha = 0.16f))
                p.box(23f, y + 17f, 24f, 6f, 3f, ink.accent.copy(alpha = 0.85f))
            }
            "compact" -> {
                p.box(0f, y, 9f, 13f, 1.8f, ink.mid.copy(alpha = 0.22f))
                p.line(14f, y + 2.5f, 44f)
                p.line(14f, y + 7.5f, 28f, ink.mid.copy(alpha = 0.16f))
                p.dot(92f, y + 6.5f, 5.5f, ink.accent.copy(alpha = 0.85f))
            }
            "hero" -> {
                p.box(30f, y, 40f, 36f, 3f, ink.mid.copy(alpha = 0.22f))
                p.line(28f, y + 39f, 44f, ink.mid, 3f)
                p.line(37f, y + 43f, 26f, ink.faint, 2f)
            }
            else -> {
                p.box(0f, y, 14f, 20f, 2f, ink.mid.copy(alpha = 0.22f))
                p.line(19f, y + 2f, 50f)
                p.line(19f, y + 7.5f, 32f, ink.mid.copy(alpha = 0.16f))
                p.line(19f, y + 13f, 64f, ink.faint, 1.8f)
                p.line(19f, y + 13f, 28f, ink.accent, 1.8f)
            }
        }
        BlockType.Today -> when (block.style) {
            "strip" -> {
                p.box(0f, y, 100f, 9f, 4.5f)
                for (i in 0..3) p.line(5f + i * 24f, y + 3.4f, 16f)
            }
            "ring" -> {
                p.ring(50f, y + 16f, 14f, 3.6f, 0.7f)
                p.line(36f, y + 33f, 28f, ink.mid.copy(alpha = 0.2f), 2f)
            }
            else -> for (i in 0..2) {
                val x = i * 34.5f
                p.box(x, y, 31f, 19f, 4f)
                p.line(x + 4f, y + 4f, 12f, ink.mid, 3f)
                p.line(x + 4f, y + 10.5f, 18f, ink.mid.copy(alpha = 0.16f), 2f)
            }
        }
        BlockType.Shortcuts ->
            if (block.style == "grid") {
                for (i in 0..3) p.box((i % 2) * 51f, y + (i / 2) * 12f, 49f, 10f, 4f)
            } else {
                for (i in 0..3) p.box(i * 25.5f, y, 23f, 8f, 4f)
            }
        BlockType.Quote ->
            if (block.style == "plain") {
                p.line(14f, y + 2f, 72f, ink.mid, 3.2f)
                p.line(20f, y + 8f, 60f, ink.mid, 3.2f)
                p.line(34f, y + 14f, 32f, ink.faint, 2f)
                p.dot(50f, y + 21f, 1.2f, ink.accent)
            } else {
                p.box(0f, y, 100f, 22f, 5f)
                p.line(8f, y + 5f, 80f)
                p.line(8f, y + 10.5f, 66f)
                p.line(8f, y + 16f, 36f, ink.mid.copy(alpha = 0.16f))
            }
        else -> when (block.style) {
            "spines" -> {
                val widths = floatArrayOf(7f, 9f, 6f, 8f, 10f, 7f, 8f, 6f, 9f, 7f)
                val heights = floatArrayOf(20f, 24f, 17f, 22f, 24f, 18f, 21f, 16f, 23f, 19f)
                var x = 0f
                for (i in widths.indices) {
                    p.box(x, y + 24f - heights[i], widths[i], heights[i], 1.2f, if (i % 3 == 0) ink.mid.copy(alpha = 0.22f) else ink.faint)
                    x += widths[i] + 2.4f
                }
            }
            "shelf", "frosted" -> {
                for (i in 0..3) p.box(i * 25f, y, 21f, 24f, 2f, ink.mid.copy(alpha = 0.2f))
                if (block.style == "frosted") p.box(-2f, y + 23f, 104f, 5f, 2.5f, ink.accent.copy(alpha = 0.22f))
                else p.box(-2f, y + 24f, 104f, 3f, 1.5f, ink.mid)
            }
            "grid" -> for (i in 0..7) p.box((i % 4) * 25f, y + (i / 4) * 17f, 21f, 14f, 2f, ink.mid.copy(alpha = 0.2f))
            "list" -> for (i in 0..2) {
                val yy = y + i * 12f
                p.box(0f, yy, 8f, 10f, 1.5f, ink.mid.copy(alpha = 0.22f))
                p.line(13f, yy + 1.4f, 52f)
                p.line(13f, yy + 5.6f, 32f, ink.mid.copy(alpha = 0.16f), 2f)
            }
            else -> for (i in 0..3) {
                p.box(i * 25f, y, 21f, 24f, 2f, ink.mid.copy(alpha = 0.2f))
                p.line(i * 25f, y + 26.5f, 17f, ink.mid.copy(alpha = 0.2f), 2f)
            }
        }
    }
}

/** One block as a thumbnail: the top of it, cropped to [width] by [height]. */
@Composable
internal fun WireThumb(block: Block, width: Dp, height: Dp, modifier: Modifier = Modifier) {
    val ink = rememberWireInk()
    Canvas(modifier.width(width).height(height).clipToBounds()) {
        // the block fills the width, with a little air round it
        val pad = size.width * 0.06f
        val s = (size.width - 2f * pad) / 100f
        translate(pad, pad) { drawWire(block, 0f, s, ink) }
    }
}

/**
 * A whole layout as one picture: the visible blocks in order with the layout's gaps, cropped to [height] and faded out
 * at the bottom into [fade] (the color of whatever the picture sits on).
 */
@Composable
internal fun WireLayout(layout: HomeLayout, height: Dp, fade: Color, modifier: Modifier = Modifier) {
    val ink = rememberWireInk()
    Canvas(modifier.fillMaxWidth().height(height).clipToBounds()) {
        val pad = size.width * 0.08f
        val s = (size.width - 2f * pad) / 100f
        // a Home is 390 dp wide, so a gap of 28 dp is 7.2 units
        val gap = layout.spacing.dp * 100f / 390f
        translate(pad, pad) {
            var y = 0f
            for (block in layout.visibleBlocks) {
                if (y * s > size.height) break
                drawWire(block, y, s, ink)
                y += wireHeight(block) + gap
            }
        }
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, fade), startY = size.height * 0.62f, endY = size.height))
    }
}
