package com.paperback.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.data.catalog.CatalogApi
import com.paperback.app.data.catalog.Categories
import com.paperback.app.data.catalog.Category
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

// Pieces of the online catalog, shared by the Search page, the book page and the "see all" page.

/** A catalog book's cover (Open Library picture, or the title on grey when there is none). */
@Composable
fun CatalogCover(book: CatalogBook, modifier: Modifier = Modifier, size: String = "M") {
    RemoteCover(CatalogApi.coverUrl(book, size), null, book.title, modifier)
}

/** "★ 4.3" for a rating, "" when there is none. */
fun ratingText(rating: Double): String = if (rating > 0.0) "★ ${"%.1f".format(rating)}" else ""

/** A shelf title with "View all" on the right. */
@Composable
fun RowHeader(title: String, modifier: Modifier = Modifier, onAll: (() -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(top = 28.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            title,
            modifier = Modifier.weight(1f),
            color = pbTokens().ink,
            fontFamily = PbSerif,
            fontSize = 21.sp,
            fontWeight = FontWeight.Medium,
        )
        if (onAll != null) {
            Text(
                "View all",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onAll).padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
    }
}

/** One book in a row: cover, title, author and a line under it (the reason, or the rating). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CatalogCard(
    book: CatalogBook,
    modifier: Modifier = Modifier,
    note: String? = null,
    owned: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val t = pbTokens()
    Column(modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Box {
            CatalogCover(book, Modifier.fillMaxWidth())
            if (owned) {
                Text(
                    "In library",
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 7.dp, vertical = 3.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(book.title, color = t.ink, fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (book.author.isNotBlank()) {
            Text(book.firstAuthor(), color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        val line = note ?: ratingText(book.rating)
        if (line.isNotEmpty()) {
            Text(
                line,
                color = if (note != null) MaterialTheme.colorScheme.primary else t.setSub,
                fontSize = 11.sp,
                lineHeight = 14.sp,
                fontStyle = if (note != null) FontStyle.Italic else null,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** The long-press menu of a suggestion: one item, "Not interested". */
@Composable
fun NotInterestedMenu(expanded: Boolean, onClose: () -> Unit, onConfirm: () -> Unit) {
    PbMenu(expanded = expanded, onDismiss = onClose) {
        DropdownMenuItem(text = { Text("Not interested") }, onClick = { onClose(); onConfirm() })
    }
}

/** A [CatalogCard] for a suggestion: long-press it for "Not interested" (no menu when [onDismiss] is null). */
@Composable
fun SuggestionCard(
    book: CatalogBook,
    modifier: Modifier = Modifier,
    note: String? = null,
    owned: Boolean = false,
    onDismiss: ((CatalogBook) -> Unit)? = null,
    onClick: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Box(modifier) {
        CatalogCard(
            book,
            Modifier.fillMaxWidth(),
            note = note,
            owned = owned,
            onLongClick = if (onDismiss != null) ({ menu = true }) else null,
            onClick = onClick,
        )
        if (onDismiss != null) SuggestionMenu(menu, { menu = false }, book) { onDismiss(book) }
    }
}

/** A row of [CatalogCard]s that runs to the screen edges. [notes] maps a book id to the line under its title. */
@Composable
fun CatalogRow(
    books: List<CatalogBook>,
    ownedKeys: Set<String>,
    modifier: Modifier = Modifier,
    notes: Map<String, String> = emptyMap(),
    /** When given, a long-press on a book offers "Not interested". */
    onDismiss: ((CatalogBook) -> Unit)? = null,
    onOpen: (CatalogBook) -> Unit,
) {
    LazyRow(
        modifier = modifier.fullBleed(20.dp),
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        items(books, key = { it.id }) { b ->
            SuggestionCard(
                b,
                Modifier.width(108.dp),
                note = notes[b.id],
                owned = com.paperback.app.catalog.TitleKey.of(b.title) in ownedKeys,
                onDismiss = onDismiss,
            ) { onOpen(b) }
        }
    }
}

/** Grey placeholder cards while a row loads. */
@Composable
fun SkeletonRow(modifier: Modifier = Modifier) {
    LazyRow(
        modifier = modifier.fullBleed(20.dp),
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        items(5) {
            Column(Modifier.width(108.dp)) {
                Box(Modifier.fillMaxWidth().aspectRatio(28f / 41f).clip(RoundedCornerShape(12.dp)).background(pbTokens().card))
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth(0.9f).height(11.dp).clip(RoundedCornerShape(6.dp)).background(pbTokens().card))
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth(0.6f).height(10.dp).clip(RoundedCornerShape(6.dp)).background(pbTokens().card))
            }
        }
    }
}

/** A message in a card, with an optional action ("Try again"). */
@Composable
fun NoteCard(text: String, modifier: Modifier = Modifier, title: String? = null, action: String? = null, onAction: (() -> Unit)? = null) {
    val t = pbTokens()
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        if (title != null) {
            Text(title, color = t.ink, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
        }
        Text(text, color = t.setSub, fontSize = 14.sp, lineHeight = 20.sp)
        if (action != null && onAction != null) {
            Text(
                action,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onAction).padding(vertical = 6.dp, horizontal = 2.dp),
            )
        }
    }
}

private val TILE_TINTS = listOf(
    Color(0xFFF46B4E), Color(0xFF3B82F6), Color(0xFF2E7D5B), Color(0xFF8B5CF6),
    Color(0xFFF6B93B), Color(0xFF1F8A8A), Color(0xFFD62F3A), Color(0xFFEC6FA8),
)

/** The category tiles: two to a row. */
@Composable
fun CategoryGrid(modifier: Modifier = Modifier, onOpen: (Category) -> Unit) {
    val t = pbTokens()
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Categories.all.chunked(2).forEachIndexed { r, pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEachIndexed { c, cat ->
                    val tint = TILE_TINTS[(r * 2 + c) % TILE_TINTS.size]
                    Row(
                        Modifier
                            .weight(1f)
                            .height(58.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(t.card)
                            .clickable { onOpen(cat) }
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.width(8.dp).height(28.dp).clip(RoundedCornerShape(4.dp)).background(tint))
                        Spacer(Modifier.width(12.dp))
                        Text(cat.name, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
