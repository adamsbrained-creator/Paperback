package com.paperback.app.data

/*
 * Signs of how much you liked a book that you never said yourself, worked out from what Paperback already
 * keeps: how fast you read it, and where and when it was published. Plain Kotlin, so it can be tested on its own.
 */
object Implicit {
    private const val DAY = 86_400_000L

    /**
     * How fast you read each finished book compared with your usual pace, by book id (1 = as usual, 2 = twice as
     * fast). Needs the day you started and finished it and its length; empty until there are four such books.
     */
    fun paceRatios(books: List<Book>): Map<String, Double> {
        val rates = HashMap<String, Double>()
        for (b in books) {
            if (!b.finished || b.startedAt <= 0L || b.finishedAt <= b.startedAt) continue
            val pages = b.pageCount
            if (pages < 40) continue
            val days = ((b.finishedAt - b.startedAt) / DAY + 1).toDouble()
            rates[b.id] = pages / days
        }
        if (rates.size < 4) return emptyMap()
        val sorted = rates.values.sorted()
        val median = sorted[sorted.size / 2]
        if (median <= 0.0) return emptyMap()
        return rates.mapValues { it.value / median }
    }

    /** How many highlights you made in each book, by book id; one with a note of your own counts twice. */
    fun highlightCounts(highlights: List<Highlight>): Map<String, Int> {
        val out = HashMap<String, Int>()
        for (h in highlights) out[h.bookId] = (out[h.bookId] ?: 0) + if (h.note.isNotBlank()) 2 else 1
        return out
    }

    /**
     * What the highlights you made in a book say about it: many for its length mean it spoke to you. 0 for a
     * few (under two), then 0.2, 0.5 or 1.0 as they come thicker. [pages] 0 = not known.
     */
    fun markBoost(marks: Int, pages: Int): Double {
        if (marks < 2) return 0.0
        val density = if (pages > 0) marks * 100.0 / pages else marks / 3.0
        return when {
            density >= 1.5 -> 1.0
            density >= 0.6 -> 0.5
            else -> 0.2
        }
    }

    /**
     * "3h 20m to read" for a book of [pages] at your pace ([secondsPerPage] from [Stats.paceSecondsPerPosition], the
     * same pace "time left" uses); null when there is no pace yet or the book is under 20 pages.
     */
    fun readTime(pages: Int, secondsPerPage: Double?): String? {
        if (secondsPerPage == null || pages < 20) return null
        return "${Stats.duration((pages * secondsPerPage).toLong())} to read"
    }

    private val yearPattern = Regex("""\b(1[0-9]{3}|20[0-9]{2})\b""")

    /** The year in a publication date like "1998-06-01" or "June 1998", 0 when there is none. */
    fun yearOf(published: String?): Int {
        if (published.isNullOrBlank()) return 0
        val y = yearPattern.find(published)?.value?.toIntOrNull() ?: return 0
        return if (y in 1000..2100) y else 0
    }
}
