package com.paperback.app.data

/** How long after you leave the reader the "keep this session?" question can still appear. */
private const val KEEP_WINDOW_MS = 15 * 60 * 1000L

/**
 * The entries the reader saved since you were last asked, for the book you read last: what the "keep this session?"
 * question is about. Hand-made entries, timer entries and listening are not asked about; neither are entries older
 * than 15 minutes (they stay saved, as the answer is "keep" unless you say otherwise).
 */
fun pendingKeep(rows: List<ReadingSession>, askedId: Long, now: Long): List<ReadingSession> {
    val fresh = rows.filter {
        it.kind == SessionKind.READ && !it.manual && it.id > askedId &&
            (it.seconds > 0 || it.pages > 0) && now - it.endOrEstimate in 0..KEEP_WINDOW_MS
    }
    val last = fresh.maxByOrNull { it.startMs } ?: return emptyList()
    return fresh.filter { it.bookId == last.bookId }.sortedBy { it.startMs }
}
