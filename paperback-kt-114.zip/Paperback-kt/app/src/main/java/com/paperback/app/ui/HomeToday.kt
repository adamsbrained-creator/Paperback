package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.ActionGo
import com.paperback.app.data.DEFAULT_PINNED
import com.paperback.app.data.Goals
import com.paperback.app.data.HomeAction
import com.paperback.app.data.HomeFigures
import com.paperback.app.data.MAX_PINNED
import com.paperback.app.data.PinnedStat
import com.paperback.app.data.pinnedValue
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

/*
 * Home, round 9: "Today" with the stats you pinned, and the next best action card.
 */

// ---- next best action 2.0 -----------------------------------------------------------------------

/**
 * One suggestion for right now, with a button. "Another idea" shows the next one in line (they are ranked, best first).
 * [canRead] is false when there is no book to open, so a "Read now" button would lead nowhere.
 */
@Composable
fun NextActionCard(actions: List<HomeAction>, canRead: Boolean, onRead: () -> Unit, onGoals: () -> Unit) {
    if (actions.isEmpty()) return
    val t = pbTokens()
    var idea by remember(actions.map { it.id }) { mutableIntStateOf(0) }
    val a = actions[idea % actions.size]
    val showButton = (a.go == ActionGo.Read && canRead) || a.go == ActionGo.Goals
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalHomeRound.current))
            .background(t.card)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Eyebrow("Next best action", Modifier.weight(1f))
            if (actions.size > 1) {
                Text(
                    "Another idea",
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .semantics { contentDescription = "Show another idea" }
                        .clickable(role = Role.Button) { idea = (idea + 1) % actions.size }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(a.title, color = t.ink, fontFamily = PbSerif, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        Text(a.text, modifier = Modifier.padding(top = 2.dp), color = t.setSub, fontSize = 14.sp, lineHeight = 20.sp)
        if (showButton) {
            Spacer(Modifier.height(14.dp))
            if (a.go == ActionGo.Read) PbButton("Read now", onRead) else PbButton("Open goals", onGoals, ghost = true)
        }
    }
}

// ---- the pinned stats ---------------------------------------------------------------------------

/** "Today" with an Edit pill on the right. Either can be left out (Customize Home); with neither the row is empty. */
@Composable
fun TodayHeader(onEdit: () -> Unit, showEdit: Boolean = true, showTitle: Boolean = true) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) { if (showTitle) BlockTitle("Today") }
        if (showEdit) {
            Text(
                "Edit",
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .semantics { contentDescription = "Choose the stats shown under Today" }
                    .clickable(role = Role.Button, onClick = onEdit)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

/** The Stats page a pinned tile opens when tapped (by the page's name in StatsScreen). */
fun statsPageFor(s: PinnedStat): String = when (s) {
    PinnedStat.GoalRing, PinnedStat.Streak, PinnedStat.Shielded, PinnedStat.Week, PinnedStat.Month, PinnedStat.Rest -> "Goals"
    PinnedStat.Today, PinnedStat.Pages, PinnedStat.Pace -> "Activity"
    PinnedStat.Wpm -> "Insights"
    PinnedStat.Books, PinnedStat.BookLeft -> "Books"
}

/** The pinned stats, two to a row. The goal ring is a little wider than the others. */
@Composable
fun PinnedTiles(pinned: List<PinnedStat>, figures: HomeFigures, goals: Goals, hour: Int, onOpen: (PinnedStat) -> Unit = {}) {
    val rows = pinned.chunked(2)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        rows.forEach { pair ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { s ->
                    val weight = if (s == PinnedStat.GoalRing && pair.size == 2) 1.25f else 1f
                    val m = Modifier.weight(weight).fillMaxHeight()
                    if (s == PinnedStat.GoalRing) {
                        GoalRingTile(figures.todaySeconds, goals.minutesPerDay, m, tinyMinutes = goals.tinyMinutes, onClick = { onOpen(s) })
                    } else {
                        val v = pinnedValue(s, figures, goals, hour)
                        StatTile(v.label, v.value, m, sub = v.sub, onClick = { onOpen(s) })
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/** Pick up to [MAX_PINNED] stats; the number on each is its place under Today. */
@Composable
fun PinnedStatsDialog(selected: List<PinnedStat>, onSave: (List<PinnedStat>) -> Unit, onCancel: () -> Unit) {
    val t = pbTokens()
    var picked by remember { mutableStateOf(selected) }
    PbDialog(title = "Pin your stats", onDismiss = onCancel) {
        Text(
            "Pick up to $MAX_PINNED. They show under Today, in the order you tap them.",
            color = t.setSub, fontSize = 14.sp, lineHeight = 20.sp,
        )
        Spacer(Modifier.height(10.dp))
        Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
            PinnedStat.values().forEach { s ->
                val place = picked.indexOf(s)
                val on = place >= 0
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .semantics {
                            contentDescription = "${s.label}. ${s.about}. " + if (on) "Pinned, number ${place + 1}. Tap to unpin." else "Not pinned. Tap to pin."
                        }
                        .clickable(role = Role.Button) {
                            picked = when {
                                on -> picked - s
                                picked.size < MAX_PINNED -> picked + s
                                else -> picked
                            }
                        }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (on) MaterialTheme.colorScheme.primary else t.ink.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (on) Text("${place + 1}", color = MaterialTheme.colorScheme.onPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.label, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text(s.about, color = t.setSub, fontSize = 12.sp, lineHeight = 16.sp)
                    }
                }
            }
        }
        Text(
            "Use the goal ring and the streak",
            modifier = Modifier
                .padding(top = 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .clickable(role = Role.Button) { picked = DEFAULT_PINNED }
                .padding(horizontal = 4.dp, vertical = 6.dp),
            color = MaterialTheme.colorScheme.primary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
        )
        PbDialogButtons(confirm = "Save", onConfirm = { onSave(picked) }, onCancel = onCancel, enabled = picked.isNotEmpty())
    }
}
