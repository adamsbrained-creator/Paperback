package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.Ranker
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.theme.pbTokens

/** The books you saved to read later. Tap for the book's page; long-press to take one off the list. */
@Composable
fun WantToReadScreen(
    items: List<CatalogBook>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenBook: (CatalogBook) -> Unit,
    onRemove: (CatalogBook) -> Unit,
    /** The list in the order of how well each book fits you, with why; empty = no ordering to offer. */
    bestFit: List<Ranker.Pick> = emptyList(),
) {
    val t = pbTokens()
    var menuId by remember { mutableStateOf<String?>(null) }
    var byFit by remember { mutableStateOf(false) }
    val shown = if (byFit && bestFit.isNotEmpty()) bestFit.map { it.book } else items
    val notes = if (byFit) bestFit.filter { it.reason.isNotBlank() }.associate { it.book.id to it.reason } else emptyMap()
    PbListPage("Want to read", headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(12.dp))
        if (bestFit.size > 1) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OrderChip("Saved order", !byFit) { byFit = false }
                OrderChip("Best fit first", byFit) { byFit = true }
            }
            Spacer(Modifier.height(4.dp))
        }
        if (items.isEmpty()) {
            Text(
                "Nothing saved yet. Find a book in Search, open its page and tap Want to read. Books you add to your library leave this list by themselves.",
                color = t.setSub,
                modifier = Modifier.padding(vertical = 16.dp),
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(104.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 112.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(shown, key = { it.id }) { b ->
                    Box {
                        CatalogCard(b, note = notes[b.id], onLongClick = { menuId = b.id }) { onOpenBook(b) }
                        DropdownMenu(
                            expanded = menuId == b.id,
                            onDismissRequest = { menuId = null },
                            shape = RoundedCornerShape(22.dp),
                            containerColor = t.menuBg,
                            tonalElevation = 0.dp,
                            shadowElevation = 12.dp,
                        ) {
                            DropdownMenuItem(text = { Text("Remove from list") }, onClick = { menuId = null; onRemove(b) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    Text(
        text,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) t.ink else t.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        color = if (selected) t.bg else t.ink,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
    )
}
