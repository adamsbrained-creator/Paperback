package com.paperback.app.data

import com.paperback.app.catalog.Ranker

/** The kinds of suggestion Paperback makes, by number: the first five are [Ranker]'s kinds. */
object SuggestionKinds {
    const val GENERAL = Ranker.KIND_GENERAL
    const val BOOK = Ranker.KIND_BOOK
    const val AUTHOR = Ranker.KIND_AUTHOR
    const val SUBJECT = Ranker.KIND_SUBJECT
    const val SERIES = Ranker.KIND_SERIES
    /** A book of your own library on "Recommended for you" or "Worth reading again". */
    const val LIBRARY = 5
    /** "New from authors you read". */
    const val NEW_RELEASE = 6
    /** "Try something different". */
    const val STRETCH = 7

    fun name(kind: Int): String = when (kind) {
        GENERAL -> "Popular with readers like you"
        BOOK -> "Because you liked a book"
        AUTHOR -> "More by an author you like"
        SUBJECT -> "A subject you read a lot"
        SERIES -> "More of a series"
        LIBRARY -> "From your own library"
        NEW_RELEASE -> "New from authors you read"
        STRETCH -> "Something different"
        else -> "Other"
    }
}

/**
 * How you answered one kind of suggestion. [lean] is which way Paperback has learned to lean: 1 = toward this
 * kind (you take them), -1 = away from it, 0 = not decided.
 */
class SuggestionRow(val kind: Int, val label: String, val opened: Int, val saved: Int, val hidden: Int, val lean: Int) {
    val total: Int get() = opened + saved + hidden
}

/**
 * The rows of "How you use suggestions": [counts] is, by kind, how many you opened, saved and hid, and [weights]
 * is how much each online kind has pleased you (see `AppPrefs.kindWeights`, about 1.0 until you answer some).
 * Only kinds you have answered are listed, the most answered first.
 */
fun suggestionRows(counts: Map<Int, List<Int>>, weights: DoubleArray): List<SuggestionRow> =
    counts.entries
        .map { (kind, c) -> SuggestionRow(kind, SuggestionKinds.name(kind), c.getOrElse(0) { 0 }, c.getOrElse(1) { 0 }, c.getOrElse(2) { 0 }, leanOf(weights.getOrNull(kind))) }
        .filter { it.total > 0 }
        .sortedWith(compareByDescending<SuggestionRow> { it.total }.thenBy { it.kind })

private fun leanOf(weight: Double?): Int = when {
    weight == null -> 0
    weight >= 1.1 -> 1
    weight <= 0.9 -> -1
    else -> 0
}
