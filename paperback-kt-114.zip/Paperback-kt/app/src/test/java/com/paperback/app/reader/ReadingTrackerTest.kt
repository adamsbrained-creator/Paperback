package com.paperback.app.reader

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ReadingTrackerTest {
    @Test
    fun partSecondsAreNotLostAtPageTurns() {
        val t = ReadingTracker()
        t.resume(1_000)
        // ten turns, each 1.9 s apart: 19 s of reading (whole-second cutting would have counted 10 s)
        var now = 1_000L
        for (p in 1..10) { now += 1_900; t.onPosition(now, p) }
        assertEquals(19, t.pause(now)!!.seconds)
    }

    @Test
    fun longGapIsCutAtTheCapAndCountsAsABreak() {
        val t = ReadingTracker(capSeconds = 180)
        t.resume(0)
        t.onPosition(60_000, 1)
        t.onPosition(60_000 + 600_000, 2) // ten minutes without a turn
        val f = t.pause(60_000 + 600_000)!!
        assertEquals(60 + 180, f.seconds)
        assertEquals(1, f.breaks)
    }

    @Test
    fun emptyStretchDoesNotKeepAnOldStartTime() {
        val t = ReadingTracker()
        t.resume(1_000)
        assertNull(t.pause(1_200)) // nothing read
        t.resume(500_000)
        t.onPosition(530_000, 1)
        assertEquals(500_000L, t.pause(530_000)!!.startMs)
    }

    @Test
    fun slowReaderGetsALongerIdleLimit() {
        val t = ReadingTracker(capSeconds = 180)
        t.resume(0)
        for (i in 1..8) t.onPosition(i * 100_000L, i) // 100 s a page
        t.onPosition(800_000L + 300_000L, 9) // 5 minutes on one page: normal for this reader
        val f = t.pause(1_100_000L)!!
        assertEquals(1_100, f.seconds)
        assertEquals(0, f.breaks)
    }

    @Test
    fun idleTailAtTheEndIsTrimmed() {
        val t = ReadingTracker(capSeconds = 180)
        t.resume(0)
        for (i in 1..6) t.onPosition(i * 20_000L, i) // 20 s a page
        val f = t.pause(120_000L + 170_000L)!! // left the phone open for ~3 minutes
        assertEquals(120 + 40, f.seconds)
        assertEquals(1, f.breaks)
        assertEquals(290_000L, f.endMs)
    }
}
