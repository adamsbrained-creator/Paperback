package com.paperback.app.catalog;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;

/** How your books become a taste: what a rating, a dropped book or a hidden suggestion is worth. */
public class TasteTest {
    private static final double EPS = 1e-9;

    /** A finished book you rated. */
    private static TasteBook rated(String title, String author, int rating, String... tags) {
        return new TasteBook(title, author, Arrays.asList(tags), rating, 1.0, true, false);
    }

    private static TasteBook plain(boolean finished, int rating, double progress) {
        return new TasteBook("T", "A", Collections.<String>emptyList(), rating, progress, finished, false);
    }

    @Test
    public void ratingValueFollowsTheStars() {
        assertEquals(-2.5, Taste.ratingValue(1), EPS);
        assertEquals(-1.5, Taste.ratingValue(2), EPS);
        assertEquals(0.4, Taste.ratingValue(3), EPS);
        assertEquals(2.0, Taste.ratingValue(4), EPS);
        assertEquals(3.0, Taste.ratingValue(5), EPS);
        assertEquals(1.2, Taste.ratingValue(3.5), EPS); // halfway between 3 and 4 stars
        assertEquals(3.0, Taste.ratingValue(9), EPS); // never beyond 5 stars
    }

    @Test
    public void ratingShiftNeedsEnoughRatings() {
        assertEquals(0.0, Taste.ratingShift(4.8, 4), EPS);
        assertEquals(0.4, Taste.ratingShift(3.0, 5), EPS); // half weight with only five ratings
        assertEquals(0.8, Taste.ratingShift(3.0, 10), EPS);
        assertEquals(-1.0, Taste.ratingShift(4.9, 10), EPS); // never more than a star
        assertEquals(0.0, Taste.ratingShift(3.8, 50), EPS);
    }

    @Test
    public void aFourStarMeansLessFromAGenerousRater() {
        TasteBook four = rated("A", "X", 4);
        double usual = Taste.bookWeight(four, 0.0);
        double generous = Taste.bookWeight(four, -1.0);
        assertEquals(2.8, usual, EPS); // 0.3 added + 2.0 for 4 stars + 0.5 finished
        assertEquals(1.2, generous, EPS);
        assertTrue(usual > generous);
    }

    @Test
    public void hiddenSuggestionsCountAgainst() {
        TasteBook hidden = new TasteBook("T", "A", Collections.<String>emptyList(), 0, 0.0, false, false,
            false, false, true, 0);
        assertEquals(-0.9, Taste.bookWeight(hidden, 0.0), EPS);
    }

    @Test
    public void leavingABookEarlyCountsWorseThanLate() {
        TasteBook early = new TasteBook("T", "A", Collections.<String>emptyList(), 0, 0.1, false, false,
            true, false, false, 0);
        TasteBook late = new TasteBook("T", "A", Collections.<String>emptyList(), 0, 0.6, false, false,
            true, false, false, 0);
        double e = Taste.bookWeight(early, 0.0);
        double l = Taste.bookWeight(late, 0.0);
        assertEquals(-1.66, e, EPS);
        assertEquals(-0.7, l, EPS);
        assertTrue(e < l);
    }

    @Test
    public void aFastUnratedReadCountsMoreThanASlowOne() {
        TasteBook fast = plain(true, 0, 1.0);
        fast.pace = 2.0;
        TasteBook usual = plain(true, 0, 1.0);
        usual.pace = 1.0;
        TasteBook slow = plain(true, 0, 1.0);
        slow.pace = 0.4;
        assertEquals(2.6, Taste.bookWeight(fast, 0.0), EPS);
        assertEquals(1.8, Taste.bookWeight(usual, 0.0), EPS);
        assertEquals(1.4, Taste.bookWeight(slow, 0.0), EPS);
    }

    @Test
    public void paceDoesNotOverrideARating() {
        TasteBook b = rated("A", "X", 4);
        b.pace = 3.0;
        assertEquals(2.8, Taste.bookWeight(b, 0.0), EPS);
    }

    @Test
    public void highlightsAddToTheWeight() {
        TasteBook b = rated("A", "X", 4);
        b.marksBoost = 1.0;
        assertEquals(3.8, Taste.bookWeight(b, 0.0), EPS);
    }

    @Test
    public void aMutedSubjectBlocksBooksThatHaveIt() {
        List<TasteBook> mine = Arrays.asList(
            rated("One", "A", 5, "Fantasy"), rated("Two", "A", 5, "Fantasy"), rated("Three", "B", 5, "Mystery"));
        Taste taste = Taste.of(mine, Collections.singletonList("fantasy"));
        CatalogBook fantasy = new CatalogBook("1", "F", "Z", 2000, 0, 4.0, 100, 1, 1, Arrays.asList("Fantasy", "Dragons"));
        CatalogBook mystery = new CatalogBook("2", "M", "Z", 2000, 0, 4.0, 100, 1, 1, Collections.singletonList("Mystery"));
        assertTrue(taste.blocks(fantasy));
        assertFalse(taste.blocks(mystery));
        assertNull(taste.subject("Fantasy")); // and it is not searched for either
    }

    @Test
    public void eraNeedsFourLikedBooksWithYears() {
        List<TasteBook> few = new ArrayList<TasteBook>();
        for (int i = 0; i < 3; i++) {
            TasteBook b = rated("B" + i, "A", 5, "Fantasy");
            b.year = 1970;
            few.add(b);
        }
        assertEquals(-1.0, Taste.of(few).eraFit(1970), EPS);
        assertNull(Taste.of(few).eraRange());

        List<TasteBook> many = new ArrayList<TasteBook>();
        for (int i = 0; i < 5; i++) {
            TasteBook b = rated("B" + i, "A", 5, "Fantasy");
            b.year = 1960 + i * 5;
            many.add(b);
        }
        Taste taste = Taste.of(many);
        assertTrue(taste.eraFit(1970) > taste.eraFit(2020));
        assertEquals(-1.0, taste.eraFit(0), EPS); // unknown year
        int[] range = taste.eraRange();
        assertNotNull(range);
        assertTrue(range[0] <= 1970 && range[1] >= 1970);
    }

    @Test
    public void lengthIsLearnedFromPages() {
        List<TasteBook> mine = new ArrayList<TasteBook>();
        for (int i = 0; i < 5; i++) {
            TasteBook b = rated("B" + i, "A", 5, "Fantasy");
            b.pages = 300;
            mine.add(b);
        }
        Taste taste = Taste.of(mine);
        assertEquals(300, taste.typicalPages());
        assertTrue(taste.lengthFit(320) > taste.lengthFit(1200));
        assertEquals(-1.0, taste.lengthFit(10), EPS); // too short to be a page count
    }

    @Test
    public void booksYouAddedOrHidAreNotSuggestedAgain() {
        Taste taste = Taste.of(Collections.singletonList(rated("The Dispossessed", "Le Guin", 5, "Science fiction")));
        assertTrue(taste.owns("The Dispossessed"));
        assertFalse(taste.owns("Something Else"));
    }
}
