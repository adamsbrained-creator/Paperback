package com.paperback.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The signs of liking a book that you never said yourself. */
class ImplicitTest {
    private val day = 86_400_000L

    /** A finished book that took [days] days from the day you started it (0 = no dates kept). */
    private fun book(id: String, days: Int = 0, pages: Int = 300) = Book(
        id = id, title = id, author = "A", language = "en", filePath = "/$id.epub", coverPath = null,
        addedAt = 0L, lastOpenedAt = 0L, progress = 1f, position = 0, totalPositions = 0, locatorJson = null,
        finished = true, favorite = false, rating = 0, customPages = pages,
        startedAt = if (days > 0) 100 * day else 0L,
        finishedAt = if (days > 0) 100 * day + (days - 1) * day else 0L,
    )

    @Test
    fun yearIsFoundInAPublicationDate() {
        assertEquals(1998, Implicit.yearOf("1998-06-01"))
        assertEquals(1998, Implicit.yearOf("June 1998"))
        assertEquals(2024, Implicit.yearOf("2024"))
        assertEquals(0, Implicit.yearOf(""))
        assertEquals(0, Implicit.yearOf(null))
        assertEquals(0, Implicit.yearOf("12"))
        assertEquals(0, Implicit.yearOf("2101"))
    }

    @Test
    fun highlightsMeanMoreWhenTheyAreThick() {
        assertEquals(0.0, Implicit.markBoost(1, 300), 0.0)
        assertEquals(0.2, Implicit.markBoost(2, 1000), 0.0) // few for such a long book
        assertEquals(0.5, Implicit.markBoost(3, 300), 0.0)
        assertEquals(1.0, Implicit.markBoost(6, 300), 0.0)
        assertEquals(0.5, Implicit.markBoost(3, 0), 0.0) // length unknown: judged by the count alone
    }

    @Test
    fun aHighlightWithANoteCountsTwice() {
        fun h(book: String, note: String) = Highlight("id", book, "", "text", note, 0, 0f, 0L)
        val counts = Implicit.highlightCounts(listOf(h("a", ""), h("a", "my note"), h("b", "")))
        assertEquals(3, counts["a"])
        assertEquals(1, counts["b"])
    }

    @Test
    fun paceIsComparedWithYourUsualPace() {
        val books = listOf(
            book("fast", 5),    // 60 pages a day
            book("usual1", 10), // 30
            book("usual2", 10),
            book("slow", 30),   // 10
        )
        val ratios = Implicit.paceRatios(books)
        assertEquals(2.0, ratios.getValue("fast"), 1e-9)
        assertEquals(1.0, ratios.getValue("usual1"), 1e-9)
        assertEquals(1.0 / 3.0, ratios.getValue("slow"), 1e-9)
    }

    @Test
    fun paceNeedsFourDatedBooks() {
        val three = listOf(book("a", 5), book("b", 10), book("c", 10))
        assertTrue(Implicit.paceRatios(three).isEmpty())
        // a book with no start date, or a very short one, does not count
        val undated = three + book("d") + book("e", 5, pages = 20)
        assertTrue(Implicit.paceRatios(undated).isEmpty())
    }

    @Test
    fun readTimeUsesYourPace() {
        assertEquals("7h 30m to read", Implicit.readTime(300, 90.0)) // 300 pages at 90 seconds a page
        assertEquals("1h 00m to read", Implicit.readTime(300, 12.0))
        assertEquals("50m to read", Implicit.readTime(50, 60.0))
        assertNull(Implicit.readTime(300, null)) // no pace yet
        assertNull(Implicit.readTime(10, 60.0)) // too short to say
    }
}
