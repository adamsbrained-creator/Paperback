package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneOffset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** The basic reading figures every Stats page is built on. */
class StatsTest {
    private val utc = ZoneOffset.UTC

    private fun session(seconds: Int, pages: Int, startMs: Long = 0L, book: String = "b") =
        ReadingSession(id = 0L, bookId = book, startMs = startMs, seconds = seconds, pages = pages)

    private fun ms(day: LocalDate, hour: Int = 12): Long = day.atStartOfDay(utc).toInstant().toEpochMilli() + hour * 3_600_000L

    private fun book(id: String, finished: Boolean, finishedAt: Long = 0L, lastOpenedAt: Long = 0L, addedAt: Long = 0L) = Book(
        id = id, title = id, author = "A", language = "en", filePath = "/$id.epub", coverPath = null,
        addedAt = addedAt, lastOpenedAt = lastOpenedAt, progress = if (finished) 1f else 0f, position = 0, totalPositions = 0,
        locatorJson = null, finished = finished, favorite = false, rating = 0, finishedAt = finishedAt, customPages = 300,
    )

    @Test
    fun durationIsRoundedToTheMinute() {
        assertEquals("0m", Stats.duration(0))
        assertEquals("0m", Stats.duration(29))
        assertEquals("1m", Stats.duration(30))
        assertEquals("59m", Stats.duration(59 * 60L))
        assertEquals("1h 00m", Stats.duration(3600))
        assertEquals("1h 05m", Stats.duration(3600 + 5 * 60L))
        assertEquals("7h 30m", Stats.duration(27_000))
    }

    @Test
    fun secondsAreAddedUpPerDay() {
        val d1 = LocalDate.of(2026, 11, 10)
        val d2 = LocalDate.of(2026, 11, 11)
        val byDay = Stats.secondsByDay(
            listOf(session(600, 10, ms(d1, 9)), session(900, 15, ms(d1, 21)), session(300, 5, ms(d2))),
            utc,
        )
        assertEquals(1500L, byDay[d1])
        assertEquals(300L, byDay[d2])
    }

    @Test
    fun secondsAreAddedUpPerBook() {
        val bySecs = Stats.secondsByBook(listOf(session(600, 10, book = "a"), session(400, 5, book = "a"), session(100, 1, book = "b")))
        assertEquals(1000L, bySecs["a"])
        assertEquals(100L, bySecs["b"])
    }

    @Test
    fun paceNeedsEnoughReading() {
        assertNull(Stats.paceSecondsPerPosition(listOf(session(2000, 10)))) // under 20 pages
        assertNull(Stats.paceSecondsPerPosition(listOf(session(200, 40)))) // under 5 minutes
        assertEquals(30.0, Stats.paceSecondsPerPosition(listOf(session(900, 30)))!!, 1e-9)
        assertEquals(5.0, Stats.paceSecondsPerPosition(listOf(session(1000, 1000)))!!, 1e-9) // never faster than 5 s a page
        assertEquals(600.0, Stats.paceSecondsPerPosition(listOf(session(20_000, 21)))!!, 1e-9) // never slower than 10 min
    }

    @Test
    fun timeLeftUsesThePace() {
        val unread = book("a", finished = false)
        assertEquals(600L, Stats.timeLeftSeconds(unread, 2.0)) // 300 pages at 2 seconds a page
        assertNull(Stats.timeLeftSeconds(unread, null))
    }

    @Test
    fun theStreakCountsDaysWithAMinute() {
        val today = LocalDate.of(2026, 11, 11)
        val byDay = mapOf(
            today to 120L,
            today.minusDays(1) to 60L,
            today.minusDays(2) to 59L, // a second short of a minute: breaks it
            today.minusDays(3) to 3000L,
        )
        assertEquals(2, Stats.currentStreak(byDay, today))
        // today still open: the streak runs to yesterday
        assertEquals(1, Stats.currentStreak(mapOf(today.minusDays(1) to 300L, today.minusDays(3) to 300L), today))
        assertEquals(0, Stats.currentStreak(emptyMap(), today))
    }

    @Test
    fun booksAreCountedInTheYearTheyWereFinished() {
        val in2025 = ms(LocalDate.of(2025, 12, 31), 23)
        val in2026 = ms(LocalDate.of(2026, 1, 1), 1)
        val books = listOf(
            book("a", true, finishedAt = in2025),
            book("b", true, finishedAt = in2026),
            book("c", true, finishedAt = in2026),
            book("d", false, finishedAt = in2026), // not finished
            book("e", true, finishedAt = 0L, lastOpenedAt = in2026), // no finish date: the last time it was opened
        )
        assertEquals(1, Stats.booksFinishedInYear(books, 2025, utc))
        assertEquals(3, Stats.booksFinishedInYear(books, 2026, utc))
    }
}
