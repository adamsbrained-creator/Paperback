package com.paperback.app.catalog;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;

/** The ranking of online books for someone who loves Le Guin and disliked a romance author. */
public class RankerTest {
    private static final String LE_GUIN = "Ursula K. Le Guin";

    private static Taste taste(String... muted) {
        List<TasteBook> mine = Arrays.asList(
            new TasteBook("The Left Hand of Darkness", LE_GUIN, Arrays.asList("Science fiction", "Fantasy"), 5, 1.0, true, false),
            new TasteBook("The Dispossessed", LE_GUIN, Arrays.asList("Science fiction"), 5, 1.0, true, false),
            new TasteBook("A Wizard of Earthsea", LE_GUIN, Arrays.asList("Fantasy"), 5, 1.0, true, false),
            new TasteBook("Bad Romance", "Bad Author", Arrays.asList("Romance"), 1, 1.0, true, false));
        return Taste.of(mine, Arrays.asList(muted));
    }

    private static CatalogBook book(String id, String title, String author, String... subjects) {
        return new CatalogBook(id, title, author, 1975, 1, 4.1, 500, 20, 1000, Arrays.asList(subjects));
    }

    private static List<CatalogBook> candidates() {
        return Arrays.asList(
            book("c1", "The Lathe of Heaven", LE_GUIN, "Science fiction", "Fantasy"),
            book("c2", "Pasta Every Day", "Chef X", "Cooking"),
            book("c3", "More Romance", "Bad Author", "Romance"),
            book("c4", "The Dispossessed", "Someone Else", "Science fiction"));
    }

    private static List<String> ids(List<Ranker.Pick> picks) {
        List<String> out = new ArrayList<String>();
        for (Ranker.Pick p : picks) out.add(p.book.id);
        return out;
    }

    @Test
    public void theBookByYourAuthorComesFirst() {
        List<Ranker.Pick> picks = Ranker.rank(candidates(), taste(), 10);
        assertFalse(picks.isEmpty());
        assertEquals("c1", picks.get(0).book.id);
    }

    @Test
    public void ownedAndDislikedAuthorsAreLeftOut() {
        List<String> ids = ids(Ranker.rank(candidates(), taste(), 10));
        assertFalse("owned title", ids.contains("c4"));
        assertFalse("author you disliked", ids.contains("c3"));
    }

    @Test
    public void aMutedSubjectKeepsABookOut() {
        List<String> ids = ids(Ranker.rank(candidates(), taste("Fantasy"), 10));
        assertFalse(ids.contains("c1"));
    }

    @Test
    public void kindWeightsScaleTheScore() {
        double base = Ranker.rank(candidates(), taste(), 10).get(0).score;
        double[] half = {0.5, 0.5, 0.5, 0.5, 0.5};
        List<Ranker.Pick> scaled = Ranker.rank(candidates(), taste(), 10, half);
        assertEquals("c1", scaled.get(0).book.id);
        assertEquals(base * 0.5, scaled.get(0).score, 1e-9);
    }

    @Test
    public void picksThatShareAReasonBecomeARow() {
        List<Ranker.Pick> picks = new ArrayList<Ranker.Pick>();
        for (int i = 0; i < 3; i++) {
            picks.add(new Ranker.Pick(book("b" + i, "T" + i, "A"), "Because you liked East of Eden", 5.0 - i,
                Ranker.KIND_BOOK, "East of Eden"));
        }
        picks.add(new Ranker.Pick(book("x1", "X1", "A"), "More by Someone", 4.0, Ranker.KIND_AUTHOR, "Someone"));
        picks.add(new Ranker.Pick(book("x2", "X2", "A"), "More by Someone", 3.9, Ranker.KIND_AUTHOR, "Someone"));
        picks.add(new Ranker.Pick(book("g1", "G1", "A"), "Popular", 1.0, Ranker.KIND_GENERAL, ""));

        List<Ranker.Group> rows = Ranker.group(picks, 3, 2);
        assertEquals(1, rows.size()); // two books are too few for a row, and a general pick has no reason
        assertEquals("Because you liked East of Eden", rows.get(0).title);
        assertEquals(3, rows.get(0).picks.size());
    }

    @Test
    public void aSeriesNeedsOnlyOneBookAndComesFirst() {
        List<Ranker.Pick> picks = new ArrayList<Ranker.Pick>();
        for (int i = 0; i < 3; i++) {
            picks.add(new Ranker.Pick(book("b" + i, "T" + i, "A"), "Because you liked East of Eden", 9.0,
                Ranker.KIND_BOOK, "East of Eden"));
        }
        picks.add(new Ranker.Pick(book("s1", "S1", "A"), "More in the Discworld series", 100.0,
            Ranker.KIND_SERIES, "Discworld"));
        List<Ranker.Group> rows = Ranker.group(picks, 3, 2);
        assertEquals(2, rows.size());
        assertEquals("More in the Discworld series", rows.get(0).title);
        assertTrue(rows.get(1).title.startsWith("Because you liked"));
    }

    @Test
    public void fitPickScoresABookYouAlreadySaved() {
        // the Want to read list has books taste.owns() already, but they can still be put in order
        Ranker.Pick fit = Ranker.fitPick(book("w1", "The Lathe of Heaven", LE_GUIN, "Science fiction"), taste());
        assertTrue(fit != null && fit.score > 0.0);
        Ranker.Pick unrelated = Ranker.fitPick(book("w2", "Pasta Every Day", "Chef X", "Cooking"), taste());
        assertTrue(unrelated == null || unrelated.score < fit.score);
    }
}
