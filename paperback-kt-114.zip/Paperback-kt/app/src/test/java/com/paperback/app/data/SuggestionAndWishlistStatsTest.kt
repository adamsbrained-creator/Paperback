package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneOffset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** "How you use suggestions" and "What became of the books you saved". */
class SuggestionAndWishlistStatsTest {
    private val utc = ZoneOffset.UTC
    private fun ms(d: LocalDate) = d.atStartOfDay(utc).toInstant().toEpochMilli()

    private fun book(title: String, finished: Boolean) = Book(
        id = title, title = title, author = "A", language = "en", filePath = "/$title.epub", coverPath = null,
        addedAt = 0L, lastOpenedAt = 0L, progress = if (finished) 1f else 0f, position = 0, totalPositions = 0,
        locatorJson = null, finished = finished, favorite = false, rating = 0,
    )

    // ---- suggestions ---------------------------------------------------------------------------

    @Test
    fun onlyKindsYouAnsweredAreListedMostAnsweredFirst() {
        val counts = mapOf(
            SuggestionKinds.BOOK to listOf(5, 2, 1),
            SuggestionKinds.AUTHOR to listOf(0, 0, 0),
            SuggestionKinds.SERIES to listOf(1, 0, 0),
            SuggestionKinds.LIBRARY to listOf(0, 0, 3),
        )
        val rows = suggestionRows(counts, DoubleArray(5) { 1.0 })
        assertEquals(listOf(SuggestionKinds.BOOK, SuggestionKinds.LIBRARY, SuggestionKinds.SERIES), rows.map { it.kind })
        assertEquals(8, rows[0].total)
        assertEquals("Because you liked a book", rows[0].label)
    }

    @Test
    fun theLeanFollowsWhatWasLearned() {
        val weights = doubleArrayOf(1.0, 1.2, 0.8, 1.0, 1.0)
        val counts = mapOf(
            SuggestionKinds.BOOK to listOf(3, 0, 0),
            SuggestionKinds.AUTHOR to listOf(0, 0, 3),
            SuggestionKinds.SUBJECT to listOf(1, 1, 1),
            SuggestionKinds.LIBRARY to listOf(0, 0, 2), // no learned weight for your own library
        )
        val lean = suggestionRows(counts, weights).associate { it.kind to it.lean }
        assertEquals(1, lean[SuggestionKinds.BOOK])
        assertEquals(-1, lean[SuggestionKinds.AUTHOR])
        assertEquals(0, lean[SuggestionKinds.SUBJECT])
        assertEquals(0, lean[SuggestionKinds.LIBRARY])
    }

    @Test
    fun shortCountListsAreTreatedAsZeros() {
        val rows = suggestionRows(mapOf(SuggestionKinds.BOOK to listOf(3)), DoubleArray(5) { 1.0 })
        assertEquals(3, rows[0].opened)
        assertEquals(0, rows[0].saved)
        assertEquals(0, rows[0].hidden)
    }

    @Test
    fun everyKindHasAName() {
        for (k in 0..7) assertEquals(false, SuggestionKinds.name(k) == "Other")
        assertEquals("Other", SuggestionKinds.name(99))
    }

    // ---- saved books -----------------------------------------------------------------------------

    @Test
    fun nothingIsSaidUntilABookHasLeftTheList() {
        assertNull(wishlistOutcomes(emptyList(), 3, emptyList(), utc))
    }

    @Test
    fun savedBooksAreFollowedIntoTheLibrary() {
        val oct1 = ms(LocalDate.of(2026, 10, 1))
        val log = listOf(
            WishOutcome("Dune", oct1, ms(LocalDate.of(2026, 10, 11)), added = true), // 10 days
            WishOutcome("Emma", oct1, ms(LocalDate.of(2026, 10, 5)), added = true), // 4 days
            WishOutcome("Ulysses", oct1, ms(LocalDate.of(2026, 10, 20)), added = false),
        )
        val library = listOf(book("Dune", finished = true), book("Emma", finished = false))
        val w = wishlistOutcomes(log, 2, library, utc)!!
        assertEquals(5, w.savedEver) // three that left, two still waiting
        assertEquals(2, w.waiting)
        assertEquals(2, w.added)
        assertEquals(1, w.removed)
        assertEquals(1, w.finished)
        assertEquals(7, w.averageDaysToAdd)
        assertEquals(66, w.addedPercent) // two of the three that left
        assertEquals(50, w.finishedPercent)
    }

    @Test
    fun aBookWithNoSavedDayDoesNotCountInTheAverageWait() {
        val log = listOf(
            WishOutcome("Dune", 0L, ms(LocalDate.of(2026, 10, 11)), added = true),
            WishOutcome("Emma", 0L, ms(LocalDate.of(2026, 10, 12)), added = true),
        )
        assertEquals(-1, wishlistOutcomes(log, 0, emptyList(), utc)!!.averageDaysToAdd)
    }

    @Test
    fun titlesAreMatchedLooselyToFindTheFinishedOnes() {
        val log = listOf(WishOutcome("The Left Hand of Darkness", 0L, 1L, added = true))
        val library = listOf(book("Left Hand of Darkness", finished = true))
        assertEquals(1, wishlistOutcomes(log, 0, library, utc)!!.finished)
    }
}
