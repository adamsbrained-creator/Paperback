package com.paperback.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class BuildSessionsTest {
    private val min = 60_000L

    private fun row(id: Long, book: String, startMin: Int, secs: Int, pages: Int, from: Int, to: Int) =
        ReadingSession(id, book, startMin * min, secs, pages, from, to)

    @Test
    fun closeEntriesFormOneSessionAndKeepTheirRows() {
        val rows = listOf(
            row(1, "a", 0, 120, 3, 10, 13),
            row(2, "a", 3, 300, 5, 13, 18),   // starts 1 min after the first ended
            row(3, "a", 60, 200, 4, 18, 22),  // an hour later: a new session
            row(4, "b", 4, 100, 2, 1, 3),     // another book never joins
        )
        val s = buildSessions(rows).filter { it.bookId == "a" }
        assertEquals(2, s.size)
        assertEquals(listOf(1L, 2L), s[0].rows.map { it.id })
        assertEquals(420L, s[0].seconds)
        assertEquals(8, s[0].pages)
        assertEquals(10, s[0].fromPos)
        assertEquals(18, s[0].toPos)
        assertEquals(listOf(3L), s[1].rows.map { it.id })
    }

    @Test
    fun realEndTimeKeepsALongSittingTogether() {
        // 5 min counted, but it ran 25 min on the clock (pauses); the next entry starts 8 min after the real end
        val a = ReadingSession(1, "a", 0, 300, 5, 1, 6, endMs = 25 * min)
        val b = ReadingSession(2, "a", 33 * min, 120, 2, 6, 8)
        val s = buildSessions(listOf(a, b))
        assertEquals(1, s.size)
        assertEquals(listOf(1L, 2L), s[0].rows.map { it.id })
    }
}

class PendingKeepTest {
    private val min = 60_000L
    private fun row(id: Long, book: String, startMin: Int, secs: Int, kind: Int = 0, manual: Boolean = false) =
        ReadingSession(id, book, startMin * min, secs, 2, kind = kind, manual = manual)

    @Test
    fun asksAboutTheLastBookOnlyAndOnlyRecentReaderEntries() {
        val now = 100 * min
        val rows = listOf(
            row(1, "a", 10, 60),                        // old: stays saved, not asked
            row(2, "a", 90, 120),                       // recent
            row(3, "a", 95, 120),                       // recent, same visit
            row(4, "b", 80, 120),                       // another book, earlier
            row(5, "a", 96, 60, kind = SessionKind.LOGGED, manual = true), // yours: never asked
        )
        assertEquals(listOf(2L, 3L), pendingKeep(rows, 0, now).map { it.id })
        assertEquals(emptyList<Long>(), pendingKeep(rows, 3, now).map { it.id }) // already answered
    }
}
