package com.paperback.app.data

import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneOffset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Goals, streaks and calendars: the maths behind the Goals and Activity pages. */
class GoalStatsTest {
    /** A Wednesday: Monday of its week is Nov 9. */
    private val today = LocalDate.of(2026, 11, 11)
    private fun day(d: Int, month: Int = 11) = LocalDate.of(2026, month, d)
    private val goals = Goals(minutesPerDay = 30, tinyMinutes = 5, restDays = 1)
    private fun history() = GoalHistory(emptyMap(), 30, today)

    private fun book(id: String, finishedAt: Long) = Book(
        id = id, title = id, author = "A", language = "en", filePath = "/$id.epub", coverPath = null,
        addedAt = 0L, lastOpenedAt = 0L, progress = 1f, position = 0, totalPositions = 0, locatorJson = null,
        finished = true, favorite = false, rating = 0, finishedAt = finishedAt,
    )

    // ---- one day -------------------------------------------------------------------------------

    @Test
    fun aDayIsJudgedByTheGoalThenTheTinyGoalThenAMinute() {
        assertEquals(DayState.Met, dayState(1800, 30, 5))
        assertEquals(DayState.Met, dayState(5000, 30, 5))
        assertEquals(DayState.Tiny, dayState(300, 30, 5))
        assertEquals(DayState.Read, dayState(100, 30, 5))
        assertEquals(DayState.Read, dayState(60, 30, 5))
        assertEquals(DayState.Missed, dayState(59, 30, 5))
        assertEquals(DayState.Read, dayState(600, 30, 0)) // no tiny goal set
    }

    @Test
    fun aGoalChangeNeverRewritesThePast() {
        val saved = mapOf(day(1).toEpochDay() to 20, day(5).toEpochDay() to 40)
        val h = GoalHistory(saved, 30, today)
        assertEquals(20, h.minutesOn(day(1, 10))) // before the first save: the first goal
        assertEquals(20, h.minutesOn(day(4)))
        assertEquals(40, h.minutesOn(day(5)))
        assertEquals(40, h.minutesOn(day(10)))
        assertEquals(30, h.minutesOn(today)) // today takes the goal in force now
        assertEquals(30, history().minutesOn(day(3))) // nothing saved: the current goal
    }

    // ---- streaks -------------------------------------------------------------------------------

    @Test
    fun theReadingStreakRunsToTodayOrYesterday() {
        val byDay = mapOf(day(11) to 120L, day(10) to 120L, day(9) to 120L, day(7) to 120L)
        val s = streaks(byDay, history(), goals, today)
        assertEquals(3, s.reading.length)
        assertEquals(today, s.reading.end)
        assertEquals(3, s.readingBest.length)

        // today is still open, so it does not break the run
        val noToday = streaks(mapOf(day(10) to 120L, day(9) to 120L), history(), goals, today)
        assertEquals(2, noToday.reading.length)
        assertEquals(day(10), noToday.reading.end)
    }

    @Test
    fun theBestStreakIsAnEarlierOneWhenItWasLonger() {
        val byDay = HashMap<LocalDate, Long>()
        for (d in 1..5) byDay[day(d)] = 120L // five days in a row, then a gap
        byDay[day(11)] = 120L
        val s = streaks(byDay, history(), goals, today)
        assertEquals(1, s.reading.length)
        assertEquals(5, s.readingBest.length)
        assertEquals(day(5), s.readingBest.end)
    }

    @Test
    fun noReadingMeansNoStreak() {
        val s = streaks(emptyMap(), history(), goals, today)
        assertEquals(0, s.reading.length)
        assertNull(s.reading.end)
        assertEquals(0, s.readingBest.length)
        assertEquals(0, s.shielded.length)
    }

    @Test
    fun theGoalStreakNeedsTheWholeGoalAndTheTinyStreakOnlyAFewMinutes() {
        val byDay = mapOf(day(11) to 1800L, day(10) to 1800L, day(9) to 600L, day(8) to 1800L)
        val s = streaks(byDay, history(), goals, today)
        assertEquals(2, s.goal.length) // the 10 minute day broke it
        assertEquals(4, s.tiny.length) // but every day reached the 5 minute tiny goal
    }

    @Test
    fun aRestDayDoesNotBreakTheProtectedStreak() {
        // Mon 9 read, Tue 10 not, Wed 11 (today) read, and Fri 6, Sat 7, Sun 8 before that
        val byDay = mapOf(day(11) to 120L, day(9) to 120L, day(8) to 120L, day(7) to 120L)
        val s = streaks(byDay, history(), goals, today)
        assertEquals(1, s.reading.length) // the ordinary streak is broken by Tuesday
        assertEquals(4, s.shielded.length) // the protected one counts only the days read, and skips the rest day
        assertEquals(today, s.shielded.end)
    }

    @Test
    fun withNoRestDaysTheProtectedStreakIsTheOrdinaryOne() {
        val byDay = mapOf(day(11) to 120L, day(9) to 120L, day(8) to 120L)
        val s = streaks(byDay, history(), Goals(restDays = 0), today)
        assertEquals(s.reading.length, s.shielded.length)
    }

    @Test
    fun twoMissedDaysInOneWeekBreakAOneRestDayStreak() {
        // Mon 9 and Tue 10 both missed in the same week
        val byDay = mapOf(day(11) to 120L, day(5) to 120L, day(4) to 120L)
        val s = streaks(byDay, history(), goals, today)
        assertEquals(1, s.shielded.length)
    }

    @Test
    fun restDaysStillFreeThisWeekAreCounted() {
        // Tuesday was missed: with one rest day a week, none is left
        val byDay = mapOf(day(11) to 120L, day(9) to 120L)
        val s = streaks(byDay, history(), goals, today)
        assertEquals(1, s.restDays)
        assertEquals(0, s.restLeft)
        // Monday and Tuesday both read: the rest day is still free
        val free = streaks(mapOf(day(11) to 120L, day(10) to 120L, day(9) to 120L), history(), goals, today)
        assertEquals(1, free.restLeft)
    }

    // ---- weeks ---------------------------------------------------------------------------------

    @Test
    fun weeksRunMondayToSunday() {
        val byDay = mapOf(day(9) to 100L, day(15) to 50L, day(8) to 7000L)
        val rows = weeklyProgress(byDay, 60, today)
        assertEquals(8, rows.size)
        val thisWeek = rows.last()
        assertEquals(day(9), thisWeek.start)
        assertTrue(thisWeek.isCurrent)
        assertEquals(150L, thisWeek.seconds) // Mon 9 and Sun 15 are in the same week
        assertEquals(3600L, thisWeek.goalSeconds)
        assertFalse(thisWeek.met)
        val lastWeek = rows[rows.size - 2]
        assertEquals(7000L, lastWeek.seconds) // Sunday 8 belongs to the week before
        assertTrue(lastWeek.met)
        assertEquals(1f, lastWeek.fraction, 0f)
    }

    @Test
    fun theWeekStreakDoesNotBreakBeforeThisWeekIsDone() {
        val byDay = mapOf(day(27, 10) to 4000L, day(3) to 3700L, day(9) to 100L)
        // 60 minutes a week = 3600 seconds
        assertEquals(2 to 2, weekStreak(byDay, 60, today)) // this week is not met yet, and does not break the run
        val met = byDay + (day(10) to 4000L)
        assertEquals(3 to 3, weekStreak(met, 60, today))
        assertEquals(0 to 0, weekStreak(emptyMap(), 60, today))
    }

    @Test
    fun minutesNeededADayToReachTheWeeklyGoal() {
        val none = WeekRow(day(9), 0L, 210 * 60L, true)
        assertEquals(42, weekMinutesPerDayNeeded(none, today)) // 210 minutes over Wed to Sun: 5 days
        val some = WeekRow(day(9), 6000L, 210 * 60L, true)
        assertEquals(22, weekMinutesPerDayNeeded(some, today)) // 110 minutes left over 5 days
        val done = WeekRow(day(9), 13_000L, 210 * 60L, true)
        assertEquals(0, weekMinutesPerDayNeeded(done, today))
    }

    // ---- months --------------------------------------------------------------------------------

    @Test
    fun monthsCollectTimeAndFinishedBooks() {
        val zone = ZoneOffset.UTC
        val byDay = mapOf(day(2) to 1000L, day(10) to 500L, day(20, 10) to 700L)
        val books = listOf(
            book("a", day(3).atStartOfDay(zone).toInstant().toEpochMilli() + 3_600_000L),
            book("b", day(20, 10).atStartOfDay(zone).toInstant().toEpochMilli() + 3_600_000L),
        )
        val rows = monthlyProgress(byDay, books, goals, today, zone)
        assertEquals(6, rows.size)
        val now = rows.last()
        assertEquals(YearMonth.of(2026, 11), now.month)
        assertTrue(now.isCurrent)
        assertEquals(1500L, now.seconds)
        assertEquals(1, now.books)
        assertEquals(900 * 60L, now.goalSeconds)
        val before = rows[rows.size - 2]
        assertEquals(700L, before.seconds)
        assertEquals(1, before.books)
    }

    @Test
    fun minutesNeededADayToReachTheMonthlyGoal() {
        val row = MonthRow(YearMonth.of(2026, 11), 300 * 60L, 0, 900 * 60L, 2, true)
        assertEquals(30, monthMinutesPerDayNeeded(row, today)) // 600 minutes over Nov 11 to 30: 20 days
        val reached = MonthRow(YearMonth.of(2026, 11), 900 * 60L, 0, 900 * 60L, 2, true)
        assertEquals(0, monthMinutesPerDayNeeded(reached, today))
    }

    // ---- the cue under today's ring --------------------------------------------------------------

    @Test
    fun theCueNamesTheNextSmallStep() {
        assertEquals("Goal reached", goalCue(1800, 30, 5))
        assertEquals("Tiny goal done \u00B7 20 min to the full goal", goalCue(600, 30, 5))
        assertEquals("4 min to your tiny goal", goalCue(100, 30, 5))
        assertEquals("20 min to go", goalCue(600, 30, 0))
    }
}
