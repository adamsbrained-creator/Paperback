package com.paperback.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Suggestions from your own library: the next of a series, a book worth reading again, and what to read next. */
class SimilarTest {
    private val day = 86_400_000L
    private val now = 1_800_000_000_000L

    private fun book(
        id: String,
        series: String = "",
        seriesNo: Float = 0f,
        finished: Boolean = false,
        rating: Int = 0,
        progress: Float = 0f,
        finishedAt: Long = 0L,
        lastOpenedAt: Long = 0L,
        favorite: Boolean = false,
        status: Int = 0,
        tags: List<String> = emptyList(),
        filePath: String = "/$id.epub",
    ) = Book(
        id = id, title = "Title $id", author = "Author", language = "en", filePath = filePath, coverPath = null,
        addedAt = now - 400 * day, lastOpenedAt = lastOpenedAt, progress = progress, position = 0, totalPositions = 0,
        locatorJson = null, finished = finished, favorite = favorite, rating = rating, finishedAt = finishedAt,
        tags = tags, status = status, series = series, seriesNo = seriesNo,
    )

    @Test
    fun theNextBookOfASeriesIsSuggested() {
        val books = listOf(
            book("s1", "Dune", 1f, finished = true, rating = 5, finishedAt = now - day),
            book("s2", "Dune", 2f),
            book("s3", "Dune", 3f),
        )
        val next = Similar.nextInSeries(books)
        assertEquals(1, next.size)
        assertEquals("s2", next[0].book.id)
        assertEquals("s1", next[0].because.id)
        assertEquals("Next in Dune", next[0].note)
    }

    @Test
    fun aSeriesYouDidNotLikeIsNotContinued() {
        val books = listOf(book("s1", "Dune", 1f, finished = true, rating = 2), book("s2", "Dune", 2f))
        assertTrue(Similar.nextInSeries(books).isEmpty())
    }

    @Test
    fun aSeriesYouAreAlreadyReadingIsLeftAlone() {
        val books = listOf(
            book("s1", "Dune", 1f, finished = true, rating = 5),
            book("s2", "Dune", 2f, progress = 0.3f),
            book("s3", "Dune", 3f),
        )
        assertTrue(Similar.nextInSeries(books).isEmpty())
    }

    @Test
    fun hiddenBooksAndDroppedBooksAreSkipped() {
        val books = listOf(
            book("s1", "Dune", 1f, finished = true, rating = 5),
            book("s2", "Dune", 2f, status = BookStatus.DROPPED),
            book("s3", "Dune", 3f),
        )
        assertEquals("s3", Similar.nextInSeries(books)[0].book.id)
        assertTrue(Similar.nextInSeries(books, hidden = setOf("s3")).isEmpty())
    }

    @Test
    fun aBookYouLovedLongAgoIsWorthReadingAgain() {
        val books = listOf(
            book("old", finished = true, rating = 5, finishedAt = now - 3 * 365 * day),
            book("recent", finished = true, rating = 5, finishedAt = now - 200 * day),
            book("meh", finished = true, rating = 3, finishedAt = now - 4 * 365 * day),
            book("fav", finished = true, favorite = true, finishedAt = now - 2 * 365 * day),
            book("nofile", finished = true, rating = 5, finishedAt = now - 3 * 365 * day, filePath = ""),
            book("inUse", finished = true, rating = 5, finishedAt = now - 3 * 365 * day, lastOpenedAt = now - 10 * day),
        )
        val again = Similar.rereads(books, nowMs = now)
        assertEquals(listOf("old", "fav"), again.map { it.book.id })
        assertEquals("Finished 3 years ago \u00B7 5 stars", again[0].note)
        assertEquals("Finished 2 years ago \u00B7 a favorite", again[1].note)
        assertTrue(Similar.rereads(books, hidden = setOf("old"), nowMs = now).none { it.book.id == "old" })
    }

    @Test
    fun nextReadAlwaysHasAnAnswerAndPutsASeriesFirst() {
        val books = listOf(
            book("s1", "Dune", 1f, finished = true, rating = 5, tags = listOf("Science fiction"), lastOpenedAt = now - day),
            book("s2", "Dune", 2f, tags = listOf("Science fiction")),
            book("x", tags = listOf("Cooking")),
        )
        val picks = Similar.pickNext(books)
        assertFalse(picks.isEmpty())
        assertEquals("s2", picks[0].book.id)
        assertTrue(picks[0].why.startsWith("Next in Dune"))
        // a book without a file, or one you already opened, is never offered
        assertTrue(Similar.pickNext(listOf(book("nofile", filePath = ""))).isEmpty())
        assertTrue(Similar.pickNext(listOf(book("opened", lastOpenedAt = now))).isEmpty())
    }
}
