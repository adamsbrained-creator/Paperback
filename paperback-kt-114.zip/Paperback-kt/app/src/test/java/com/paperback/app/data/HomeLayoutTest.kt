package com.paperback.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeLayoutTest {

    private fun focus() = HomePresets.build("focus")

    @Test
    fun everyPresetUsesKnownStylesAndHasUniqueIds() {
        for (preset in HomePresets.all) {
            val layout = HomePresets.build(preset.key)
            assertEquals(preset.blocks.size, layout.blocks.size)
            assertEquals(layout.blocks.size, layout.blocks.map { it.id }.toSet().size)
            for (block in layout.blocks) {
                assertTrue(
                    "${preset.key}: ${block.type} has no style '${block.style}'",
                    HomeCatalog.stylesOf(block.type).any { it.key == block.style },
                )
                val known = HomeCatalog.options.getValue(block.type).map { it.key }.toSet()
                assertTrue("${preset.key}: unknown option in ${block.opts.keys}", known.containsAll(block.opts.keys))
            }
        }
    }

    @Test
    fun everyBlockTypeHasStylesAndOptionsAndAGroup() {
        val grouped = HomeCatalog.groups.flatMap { it.types }
        for (type in BlockType.entries) {
            assertTrue("$type has no style", HomeCatalog.stylesOf(type).isNotEmpty())
            assertTrue("$type has no options entry", HomeCatalog.options.containsKey(type))
            assertTrue("$type is in no group", type in grouped)
            assertEquals(type, BlockType.of(type.key))
        }
        assertEquals(grouped.size, grouped.toSet().size)
        assertEquals(BlockType.entries.size, BlockType.entries.map { it.key }.toSet().size)
    }

    @Test
    fun presetKeysAreUniqueAndUnknownOnesFallBackToTheFirst() {
        assertEquals(HomePresets.all.size, HomePresets.all.map { it.key }.toSet().size)
        assertEquals("classic", HomePresets.find("does-not-exist").key)
    }

    @Test
    fun theOriginalHomeIsTheClassicOneUnlessAViewWasPicked() {
        val plain = HomePresets.original()
        assertEquals(HomePresets.build("classic"), plain)
        val picked = HomePresets.original { if (it == BlockType.Recent) "grid" else null }
        assertEquals("grid", picked.blocks.first { it.type == BlockType.Recent }.style)
        assertEquals("spines", picked.blocks.first { it.type == BlockType.Favorites }.style)
        // a look the block does not have is ignored
        val wrong = HomePresets.original { if (it == BlockType.Want) "frosted" else null }
        assertEquals("row", wrong.blocks.first { it.type == BlockType.Want }.style)
    }

    @Test
    fun optionsFallBackToTheirDefaults() {
        val today = Block(1, BlockType.Today, "tiles")
        assertTrue(today.opt("edit"))
        assertFalse(today.withOpt("edit", false).opt("edit"))
        assertFalse(today.opt("no-such-option"))
        assertFalse(Block(2, BlockType.Shortcuts, "pills").opt("import"))
        assertTrue(Block(2, BlockType.Shortcuts, "pills").withOpt("import", true).opt("import"))
    }

    @Test
    fun hidingKeepsTheBlockButNotInTheVisibleList() {
        val layout = focus()
        val hidden = layout.withBlock(layout.blocks[1].copy(hidden = true))
        assertEquals(layout.blocks.size, hidden.blocks.size)
        assertEquals(layout.blocks.size - 1, hidden.visibleBlocks.size)
        assertEquals(1, hidden.hiddenCount)
    }

    @Test
    fun addingPutsTheBlockAfterTheOneGivenOrAtTheEnd() {
        val layout = focus()
        val (after, block) = layout.adding(BlockType.Quote, "card", after = layout.blocks[0].id)
        assertEquals(1, after.blocks.indexOf(block))
        assertTrue(block.id !in layout.blocks.map { it.id })
        val (atEnd, last) = layout.adding(BlockType.Quote, "card", after = null)
        assertEquals(atEnd.blocks.lastIndex, atEnd.blocks.indexOf(last))
    }

    @Test
    fun duplicatingGivesTheCopyANewIdRightAfterTheOriginal() {
        val layout = focus()
        val source = layout.blocks[2]
        val (next, copy) = layout.duplicating(source.id)
        assertNotEquals(source.id, copy!!.id)
        assertEquals(source.copy(id = copy.id), copy)
        assertEquals(3, next.blocks.indexOf(copy))
        assertEquals(layout, layout.duplicating(9999).first)
        assertNull(layout.duplicating(9999).second)
    }

    @Test
    fun removingAndMovingBlocks() {
        val layout = focus()
        val ids = layout.blocks.map { it.id }
        assertEquals(ids - ids[0], layout.removing(ids[0]).blocks.map { it.id })
        assertEquals(listOf(ids[1], ids[0]) + ids.drop(2), layout.moving(0, 1).blocks.map { it.id })
        assertEquals(layout, layout.moving(0, 0))
        assertEquals(layout, layout.moving(-1, 2))
        assertEquals(layout, layout.moving(0, 99))
    }

    @Test
    fun cardCornersRunFromTwelveToThirtyTwoAndSixtyPercentIsTheOldTwentyFour() {
        assertEquals(24f, HomeLayout("x", emptyList()).cardDp, 0.001f)
        assertEquals(12f, HomeLayout("x", emptyList(), round = -3f).cardDp, 0.001f)
        assertEquals(32f, HomeLayout("x", emptyList(), round = 9f).cardDp, 0.001f)
    }

    @Test
    fun codecRoundTripsALayout() {
        val layout = HomePresets.build("gallery").copy(
            spacing = HomeSpacing.Compact,
            titles = HomeTitles.Large,
            dividers = true,
            round = 0.25f,
        )
        val edited = layout.withBlock(layout.blocks[1].copy(hidden = true).withOpt("title", false))
        assertEquals(edited, HomeLayoutCodec.decode(HomeLayoutCodec.encode(edited)))
        for (preset in HomePresets.all) {
            val built = HomePresets.build(preset.key)
            assertEquals(built, HomeLayoutCodec.decode(HomeLayoutCodec.encode(built)))
        }
    }

    @Test
    fun codecRejectsTextThatIsNotALayout() {
        assertNull(HomeLayoutCodec.decode(""))
        assertNull(HomeLayoutCodec.decode("hello"))
        assertNull(HomeLayoutCodec.decode("pb9\nname=x"))
        // the Files app's text must not be mistaken for ours
        assertNull(HomeLayoutCodec.decode("v1\nname=x"))
    }

    @Test
    fun codecSkipsBrokenLinesAndFixesUnknownStyles() {
        val text = """
            pb1
            name=Mine
            round=7
            spacing=Gigantic
            b=1|continue|card|0|
            b=oops
            b=2|favorites|from-the-future|0|title:0
            b=3|spaceship|x|0|
            b=1|today|ring|0|
        """.trimIndent()
        val layout = HomeLayoutCodec.decode(text)!!
        assertEquals("Mine", layout.name)
        assertEquals(1f, layout.round, 0f)
        assertEquals(HomeSpacing.Cozy, layout.spacing)
        // the second block with id 1 and the unknown type are dropped
        assertEquals(listOf(1, 2), layout.blocks.map { it.id })
        assertEquals("spines", layout.blocks[1].style)
        assertFalse(layout.blocks[1].opt("title"))
    }

    @Test
    fun aNameWithALineBreakStaysOneLine() {
        val layout = HomePresets.build("focus").copy(name = "My\nhome")
        assertEquals("My home", HomeLayoutCodec.decode(HomeLayoutCodec.encode(layout))!!.name)
    }
}
