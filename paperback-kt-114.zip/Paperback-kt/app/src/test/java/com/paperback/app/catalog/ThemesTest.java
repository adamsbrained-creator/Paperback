package com.paperback.app.catalog;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;

/** Comparing what descriptions are about. */
public class ThemesTest {
    private static final String FARM_A = "A family works the farm and the land through hard seasons. Loyalty, harvest and family secrets.";
    private static final String FARM_B = "Secrets on the farm: a harvest, the land and a family held together by loyalty.";
    private static final String CANDIDATE_FARM = "A family fights to keep the farm and its land through a hard harvest.";
    private static final String CANDIDATE_SPACE = "A starship crew explores distant galaxies, alien planets and strange signals.";

    private static List<String> others() {
        return Arrays.asList(
            CANDIDATE_FARM,
            CANDIDATE_SPACE,
            "A detective follows clues through a rain-soaked city to catch a clever forger.",
            "Two rival chefs open restaurants on the same street and compete for a famous critic.",
            "A young wizard attends a school of magic and faces an ancient dragon.",
            "An old sailor tells of storms, whales and a ship lost in the northern ocean.");
    }

    private static Themes.Scorer scorer() {
        return new Themes.Scorer(Arrays.asList(FARM_A, FARM_B), Arrays.asList(1.0, 1.0), others());
    }

    @Test
    public void aDescriptionLikeYourBooksScoresHigher() {
        Themes.Scorer s = scorer();
        assertTrue(s.usable());
        assertTrue(s.similarity(CANDIDATE_FARM) > s.similarity(CANDIDATE_SPACE));
    }

    @Test
    public void sharedWordsAreNamed() {
        List<String> shared = scorer().shared(CANDIDATE_FARM, 3);
        assertFalse(shared.isEmpty());
        assertTrue(shared.contains("farm") || shared.contains("land") || shared.contains("harvest") || shared.contains("family"));
        assertTrue(shared.size() <= 3);
    }

    @Test
    public void withoutLikedDescriptionsNothingIsScored() {
        Themes.Scorer s = new Themes.Scorer(Collections.<String>emptyList(), Collections.<Double>emptyList(), others());
        assertFalse(s.usable());
        assertEquals(0.0, s.similarity(CANDIDATE_FARM), 1e-9);
    }

    @Test
    public void emptyTextIsHarmless() {
        Themes.Scorer s = scorer();
        assertEquals(0.0, s.similarity(""), 1e-9);
        assertEquals(0.0, s.similarity(null), 1e-9);
        assertTrue(s.shared("", 3).isEmpty());
    }

    @Test
    public void stemmingJoinsSimpleForms() {
        assertEquals("farm", Themes.stem("farms"));
        assertEquals("story", Themes.stem("stories"));
        assertEquals("walk", Themes.stem("walking"));
        assertEquals("toss", Themes.stem("tossed"));
        assertEquals("boss", Themes.stem("boss"));
    }
}
