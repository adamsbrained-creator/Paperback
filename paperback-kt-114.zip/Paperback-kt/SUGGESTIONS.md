# Paperback: polish and motion (kt-103)

The list of suggestions that came out of reading the whole app, with what was done about each.
**Done** = built in this version. **Next** = a good idea that is bigger or needs a decision.

## Motion: things that move now (Done)

| # | Suggestion | Where |
|---|---|---|
| 1 | **Press feedback.** Anything you tap shrinks a little under the finger and springs back, with the ripple on top | pills, action buttons, dialog buttons, header buttons, the round menu button, menu rows, Library covers, Stats and goal tiles, reader pills / tiles / round buttons |
| 2 | **The menu grows out of the round button** and shrinks back into it; the page dims and clears with it; the close button pops in over it | `MenuSheet.kt` |
| 3 | **Every page change fades in and rises** a few dp instead of snapping | `PaperbackRoot.kt` |
| 4 | **Dialogs rise and settle** instead of appearing | `PbDialog` |
| 5 | **Reader settings sheets slide up** from the bottom edge and sink back (small sheet and the Advanced page) | `ReaderActivity.kt` |
| 6 | **The Advanced page arrives in order**: preview card first, then Layout, Select Font, Typography, Text Alignment, More, 60 ms apart | `Modifier.rise` |
| 7 | **Folders and panels unfold** (Page / Text / Header and footer / Behavior / Selection / Display, Text & Background, All reader settings); the arrow turns instead of swapping between two symbols | `ReaderLookControls.kt`, `ReaderPanelStyle.kt` |
| 8 | **Choices ease between states**: colour of selected pills, font tiles, alignment cards, tool circles, the colour dots (the ring and the gap around the dot), the tick in the round select mark | everywhere above |
| 9 | **The segmented switch has a sliding thumb** (App style, Appearance, and every other place that uses it) | `PbSegmented` |
| 10 | **The preview text glides** to its new size when you tap + or -, and the preview card grows with it | Advanced page |
| 11 | **Page-dots grow** into a pill for the current page of the font grid | Advanced page |
| 12 | **Slider handle swells** while you hold it | `PbSlider` |
| 13 | **The goal ring fills up** when Home opens and counts the percent up; progress bars ease when the value changes | `Components.kt` |
| 14 | **Covers fade in** when they arrive late, instead of popping over the title | `BookCover`, `CoverFill` |
| 15 | **Light haptic tick** on switches, choices and +/- buttons (uses the phone's own setting) | `pbTap(haptic = true)` |

All motion lives in one file, `ui/PbMotion.kt` (durations, the two curves, `pbTap`, `pbTapLong`, `rise`), so the feel can be changed in one place.
The animations follow the phone's "Remove animations" / animator-scale setting by themselves.

## Look (Done)
- The Ligatures switch matches the page colour when off (it used Material's grey before).
- The old Reader settings sheet uses the same turning arrow as the Advanced page, not two text triangles.

## Next (not built; tell me which you want)
1. **Page transitions with direction**: tabs slide left or right according to their order in the bar, details slide in from the right. Needs the navigation host to keep the old page on screen while the new one comes in.
2. **Cover to book page shared transition**: the tapped cover flies to its place on the book page.
3. **Predictive back** (Android 14+): the page shrinks as you swipe from the edge. Needs `enableOnBackInvokedCallback` and moving Back handling to the new API.
4. **Skeleton shimmer** for Discover while a catalog page loads, instead of the spinner.
5. **Staggered Home**: the cards arrive one after another like the Advanced page (`Modifier.rise` is ready, it only has to be put on the Home cards).
6. **A "Reduce motion" switch** in Settings -> Appearance (the system setting already works; this would be for people who want it off only in Paperback).
7. **Reader**: a short fade of the page when you change the font or theme, so the reflow is not a jump (needs a hook into Readium's preferences, so it is a bigger change).
8. **Presets** in Advanced settings: save the current font, size, spacing and colours as "Night", "Commute", and switch with one tap.
9. **A page-turn sound or haptic** option for e-ink-style reading.
10. **Dark-mode check of every screen** on a real phone: I could not run the app here, so the colours of the new animated states are checked by reading, not by eye.
