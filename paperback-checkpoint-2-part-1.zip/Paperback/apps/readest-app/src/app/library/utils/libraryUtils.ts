import { Book, BooksGroup, ReadingStatus } from '@/types/book';
import {
  LibraryGroupByType,
  LibrarySecondarySortByType,
  LibrarySortByType,
} from '@/types/settings';
import {
  formatAuthors,
  formatTitle,
  getBookPageCount,
  getContributorNames,
  isCurrentlyReadingBook,
} from '@/utils/book';
import { md5Fingerprint } from '@/utils/md5';
import type { TranslationFunc } from '@/hooks/useTranslation';
import { stubTranslation as _ } from '@/utils/misc';
import { SIZE_PER_LOC, SIZE_PER_TIME_UNIT } from '@/services/constants';
import { isAudiobook } from '@/utils/audiobook';

/** Valid sort types for the library */
const VALID_SORT_TYPES: LibrarySortByType[] = Object.values(LibrarySortByType);

/** Valid group by types for the library */
const VALID_GROUP_BY_TYPES: LibraryGroupByType[] = Object.values(LibraryGroupByType);

/**
 * Group labels for `groupBy=status`. These are i18n *keys*, not display text:
 * `stubTranslation` only registers them for extraction, and the rendering
 * component applies the real `_()` (see docs/i18n.md). Keys match the ones the
 * status UI already ships, so every locale translates these for free.
 *
 * Typed as a total `Record<ReadingStatus, string>` on purpose: a fifth reading
 * status can't be added without also giving it a label here.
 */
const READING_STATUS_LABELS: Record<ReadingStatus, string> = {
  unread: _('Unread'),
  reading: _('Reading'),
  finished: _('Finished'),
  abandoned: _('On hold'),
};

/**
 * Safely cast a query parameter to LibrarySortByType with fallback.
 * Returns the value if valid, otherwise returns the fallback.
 */
export const ensureLibrarySortByType = (
  value: string | null | undefined,
  fallback: LibrarySortByType,
): LibrarySortByType => {
  if (value && VALID_SORT_TYPES.includes(value as LibrarySortByType)) {
    return value as LibrarySortByType;
  }
  return fallback;
};

/**
 * Safely cast a query parameter to LibrarySecondarySortByType with fallback.
 * Accepts any valid primary sort type plus the literal 'none'.
 */
export const ensureLibrarySecondarySortByType = (
  value: string | null | undefined,
  fallback: LibrarySecondarySortByType,
): LibrarySecondarySortByType => {
  if (value === 'none') return 'none';
  if (value && VALID_SORT_TYPES.includes(value as LibrarySortByType)) {
    return value as LibrarySortByType;
  }
  return fallback;
};

/**
 * Resolve the *effective* primary sort key, applying smart defaults derived
 * from the current `groupBy`. The stored `librarySortBy` is left unchanged;
 * this only substitutes a sensible implicit default when the user is still on
 * auto, so grouping by Series lands an alphabetical-by-series-name listing
 * without any extra clicks.
 *
 * - !isAuto                              -> use stored as-is
 * - groupBy=Series and isAuto            -> Series
 * - everything else                      -> stored
 */
export const resolveEffectivePrimarySort = (
  stored: LibrarySortByType,
  groupBy: LibraryGroupByType,
  isAuto: boolean,
): LibrarySortByType => {
  if (!isAuto) return stored;
  if (groupBy === LibraryGroupByType.Series) return LibrarySortByType.Series;
  return stored;
};

/**
 * Resolve the *effective* secondary sort key, applying smart defaults derived
 * from the current `groupBy`. The stored secondary stays whatever the user
 * picked; this only substitutes 'none' with a sensible implicit default so
 * users get useful behavior out of the box (e.g. drilling into an Author
 * group lands a series-ordered list without any extra clicks).
 *
 * - explicit secondary (any non-'none')  -> use as-is
 * - groupBy=Author and stored='none'     -> Series
 * - everything else                      -> 'none'
 *
 * groupBy=Series doesn't default to anything because `createWithinGroupSorter`
 * already orders by `seriesIndex` for series groups.
 */
export const resolveEffectiveSecondarySort = (
  secondary: LibrarySecondarySortByType,
  groupBy: LibraryGroupByType,
): LibrarySecondarySortByType => {
  if (secondary !== 'none') return secondary;
  if (groupBy === LibraryGroupByType.Author) return LibrarySortByType.Series;
  return 'none';
};

/**
 * Safely cast a query parameter to LibraryGroupByType with fallback.
 * Returns the value if valid, otherwise returns the fallback.
 */
export const ensureLibraryGroupByType = (
  value: string | null | undefined,
  fallback: LibraryGroupByType,
): LibraryGroupByType => {
  if (value && VALID_GROUP_BY_TYPES.includes(value as LibraryGroupByType)) {
    return value as LibraryGroupByType;
  }
  return fallback;
};

/**
 * Find a group by ID from a list of bookshelf items.
 * Works for both manual groups and series/author groups.
 */
export const findGroupById = (
  items: (Book | BooksGroup)[],
  groupId: string,
): BooksGroup | undefined => {
  return items.find((item): item is BooksGroup => 'books' in item && item.id === groupId);
};

/**
 * Get the display name for a group, useful for breadcrumbs.
 */
export const getGroupDisplayName = (
  items: (Book | BooksGroup)[],
  groupId: string,
): string | undefined => {
  const group = findGroupById(items, groupId);
  return group?.displayName || group?.name;
};

/**
 * Expand a list of selection ids (book hashes or group ids from the rendered
 * bookshelf) into the unique book hashes those ids represent.
 *
 * Group ids resolve to every (non-soft-deleted) book in the group's visible
 * rollup — `generateBookshelfItems` already folds nested-folder books into
 * their top-level group, so the rendered `BooksGroup.books` is the source of
 * truth. Standalone book hashes (and any unknown ids) pass through unchanged,
 * letting callers like the bookshelf delete flow collect the right set up
 * front instead of re-deriving it later.
 */
export const expandBookshelfSelection = (ids: string[], items: (Book | BooksGroup)[]): string[] => {
  const hashes = new Set<string>();
  for (const id of ids) {
    const group = findGroupById(items, id);
    if (group) {
      for (const book of group.books) {
        if (!book.deletedAt) hashes.add(book.hash);
      }
    } else {
      hashes.add(id);
    }
  }
  return [...hashes];
};

/**
 * The manual group a selection stands for, if any. Selecting a group tile
 * selects its books (nested folders included), never the group's id, so the
 * group is the rendered folder tile whose books are exactly the selection.
 * Folder tiles are keyed by `md5Fingerprint(name)`; series/author/tag tiles
 * namespace their keys, so they never match.
 */
export const findSelectedManualGroup = (
  ids: string[],
  items: (Book | BooksGroup)[],
): BooksGroup | undefined => {
  const selected = new Set(ids);
  return items.find((item): item is BooksGroup => {
    if (!('books' in item) || item.id !== md5Fingerprint(item.name)) return false;
    const books = item.books.filter((book) => !book.deletedAt);
    return (
      books.length === selected.size &&
      books.every(
        (book) =>
          selected.has(book.hash) &&
          (book.groupName === item.name || !!book.groupName?.startsWith(`${item.name}/`)),
      )
    );
  });
};

// Calibre custom column names and values, flattened for searching (#4811).
const getCalibreColumnsText = (item: Book) =>
  (item.metadata?.calibreColumns ?? [])
    .map(({ name, value }) => `${name} ${Array.isArray(value) ? value.join(' ') : value}`)
    .join(' ');

const normalizeValues = (values: string[]): string[] => [
  ...new Set(values.map((value) => value.trim()).filter(Boolean)),
];

export const getBookSubjects = (book: Book): string[] => {
  return getContributorNames(book.metadata?.subject);
};

export const getBookTags = (book: Book): string[] => normalizeValues(book.tags ?? []);

export const getLibraryTags = (books: Book[]): string[] =>
  normalizeValues(books.filter((book) => !book.deletedAt).flatMap(getBookTags)).sort((a, b) =>
    a.localeCompare(b),
  );

export type TagSelectionState = 'all' | 'some' | 'none';

export const getTagSelectionState = (books: Book[], tag: string): TagSelectionState => {
  const count = books.filter((book) => getBookTags(book).includes(tag)).length;
  return count === 0 ? 'none' : count === books.length ? 'all' : 'some';
};

// Applied to the selected books only, never to the rest of the library.
export interface BookTagEdits {
  add: string[];
  remove: string[];
}

// Returns a new array where only the books whose tags actually change are new
// objects. Tags merge with the metadata group on its own clock, so a changed
// book stamps metadataUpdatedAt like a metadata edit does, leaving updatedAt
// (the Date Read sort key) alone (#6414).
export const applyBookTagEdits = (
  books: Book[],
  selectedHashes: string[],
  edits: BookTagEdits,
  now = Date.now(),
): Book[] =>
  books.map((book) => {
    if (book.deletedAt || !selectedHashes.includes(book.hash)) return book;
    const current = book.tags ?? [];
    const kept = current.filter((tag) => !edits.remove.includes(tag.trim()));
    const added = edits.add.filter((tag) => !kept.some((k) => k.trim() === tag));
    if (kept.length === current.length && added.length === 0) return book;
    return { ...book, tags: [...kept, ...added], metadataUpdatedAt: now };
  });

const getBookValuesText = (book: Book): string =>
  [...getBookTags(book), ...getBookSubjects(book)].join(' ');

export const createBookFilter = (queryTerm: string | null) => (item: Book) => {
  if (!queryTerm) return true;
  if (item.deletedAt) return false;
  let searchTerm: RegExp;
  try {
    searchTerm = new RegExp(queryTerm, 'i');
  } catch {
    const lowerQuery = queryTerm.toLowerCase();
    const title = formatTitle(item.title).toLowerCase();
    const authors = formatAuthors(item.author).toLowerCase();

    return (
      title.includes(lowerQuery) ||
      authors.includes(lowerQuery) ||
      item.format.toLowerCase().includes(lowerQuery) ||
      (item.groupName && item.groupName.toLowerCase().includes(lowerQuery)) ||
      (item.metadata?.description &&
        item.metadata.description.toLowerCase().includes(lowerQuery)) ||
      getBookValuesText(item).toLowerCase().includes(lowerQuery) ||
      getCalibreColumnsText(item).toLowerCase().includes(lowerQuery)
    );
  }
  const title = formatTitle(item.title);
  const authors = formatAuthors(item.author);
  return (
    searchTerm.test(title) ||
    searchTerm.test(authors) ||
    searchTerm.test(item.format) ||
    (item.groupName && searchTerm.test(item.groupName)) ||
    (item.metadata?.description && searchTerm.test(item.metadata?.description)) ||
    searchTerm.test(getBookValuesText(item)) ||
    searchTerm.test(getCalibreColumnsText(item))
  );
};

/**
 * Fraction of the book that has been read, in [0, 1]. `progress` is a 1-based
 * `[current, total]` page pair; books that have never been opened have no
 * progress and read 0 (they sort to the unread end).
 */
const getBookReadRatio = (book: Book): number => {
  const [current, total] = book.progress ?? [];
  if (!current || !total || total <= 0) return 0;
  return current / total;
};

/** Percent read, or `null` when there's no progress to show. A total of 1
 * (e.g. a fixed-layout book with one page) reads as finished (100%). */
export const getProgressPercentage = (book: Book): number | null => {
  if (!book.progress || !book.progress[1]) return null;
  if (book.progress[1] === 1) return 100;
  const percentage = Math.round((book.progress[0] / book.progress[1]) * 100);
  return Math.max(0, Math.min(100, percentage));
};

export const getTimeRemainingMinutes = (
  book: Book,
  medianPageDurationSecs?: number,
): number | undefined => {
  // An audiobook already knows how long it is: `progress` is [seconds,
  // seconds] against `duration`, with no pages and no reading pace involved.
  // Running it through the page estimate turned 7h of listening into 446h and
  // floated every audiobook to the top of a time-remaining sort (#6224).
  if (isAudiobook(book)) {
    const total = book.duration ?? 0;
    const secondsLeft = total - (book.progress?.[0] ?? 0);
    if (!(secondsLeft > 0)) return undefined;
    return Math.max(1, Math.round(secondsLeft / 60));
  }
  const pagesLeft = book.progress ? book.progress[1] - book.progress[0] : undefined;
  if (!pagesLeft) return undefined;
  return convertPagesToTimeRemainingMinutes(pagesLeft, medianPageDurationSecs);
};

export const convertPagesToTimeRemainingMinutes = (
  pagesLeft: number,
  medianPageDurationSecs?: number,
): number => {
  // Prefer the reader's own pace; fall back to the coarse global estimate.
  const minutesPerPage = medianPageDurationSecs
    ? medianPageDurationSecs / 60
    : SIZE_PER_LOC / SIZE_PER_TIME_UNIT;
  return Math.max(1, Math.round(pagesLeft * minutesPerPage));
};

/**
 * Minutes a book still needs, or `undefined` when its tile shows no time at all.
 * Finished, on-hold and unread books render a status badge instead of a time (see
 * `ReadingProgress`), even when they still have pages left — so they have no time
 * to sort by. Sorting and the label must agree on this, hence the shared helper.
 */
export const getDisplayedTimeRemaining = (
  book: Book,
  medianPageDurationSecs?: number,
): number | undefined => {
  const { readingStatus } = book;
  if (readingStatus === 'finished' || readingStatus === 'abandoned' || readingStatus === 'unread') {
    return undefined;
  }
  return getTimeRemainingMinutes(book, medianPageDurationSecs);
};

// A tenth of an hour is still meaningful below 10h (1.6h); above it, a tenth
// stops mattering once there are dozens of hours left.
const roundedHours = (totalMinutes: number): number => {
  const hours = totalMinutes / 60;
  return hours < 10 ? Math.round(hours * 10) / 10 : Math.round(hours);
};

/** The library tile's short form: "45m left" under an hour, "1.6h left" / "11h left" above it. */
export const formatTimeLeft = (totalMinutes: number, _: TranslationFunc): string =>
  totalMinutes < 60
    ? _('{{minutes}}m left', { minutes: totalMinutes })
    : _('{{hours}}h left', { hours: roundedHours(totalMinutes) });

/**
 * Remaining minutes for a shelf item, or `undefined` when its tile can show no
 * time at all — that includes every group, since a group tile renders no progress.
 */
const getShelfItemTimeRemaining = (item: Book | BooksGroup): number | undefined =>
  'books' in item ? undefined : getDisplayedTimeRemaining(item);

/**
 * Wrap a comparator that has *already* had the sort direction applied, so items
 * with no remaining time always land after the ones that have it — ascending and
 * descending alike. "No time" is a bucket, not a value: it must sit outside the
 * sort-order multiplier, otherwise descending would float those items to the top.
 */
export const withTimeRemainingLast =
  <T extends Book | BooksGroup>(sortBy: LibrarySortByType, compare: (a: T, b: T) => number) =>
  (a: T, b: T): number => {
    if (sortBy !== LibrarySortByType.TimeRemaining) return compare(a, b);
    const aTime = getShelfItemTimeRemaining(a);
    const bTime = getShelfItemTimeRemaining(b);
    if (aTime === undefined && bTime === undefined) return 0;
    if (aTime === undefined) return 1;
    if (bTime === undefined) return -1;
    return compare(a, b);
  };

// localeCompare with an options object builds a new collator on every call, which
// is ~20x slower in V8, so title sorts reuse one numeric collator per locale.
const numericCollators = new Map<string, Intl.Collator>();
const compareTitles = (a: string, b: string, uiLanguage: string): number => {
  const locale = uiLanguage || navigator.language;
  let collator = numericCollators.get(locale);
  if (!collator) {
    collator = new Intl.Collator(locale, { numeric: true });
    numericCollators.set(locale, collator);
  }
  return collator.compare(a, b);
};

const compareBookByKey = (
  a: Book,
  b: Book,
  sortBy: string,
  uiLanguage: string,
  pageDurations?: Readonly<Record<string, number>>,
): number => {
  switch (sortBy) {
    case LibrarySortByType.Title: {
      const aTitle = formatTitle(a.title);
      const bTitle = formatTitle(b.title);
      return compareTitles(aTitle, bTitle, uiLanguage);
    }
    case LibrarySortByType.Author: {
      const aAuthors = formatAuthors(a.author, a?.primaryLanguage || 'en', true);
      const bAuthors = formatAuthors(b.author, b?.primaryLanguage || 'en', true);
      return aAuthors.localeCompare(bAuthors, uiLanguage || navigator.language);
    }
    case LibrarySortByType.Updated:
      return new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
    case LibrarySortByType.Created:
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    case LibrarySortByType.Format:
      return a.format.localeCompare(b.format, uiLanguage || navigator.language);
    case LibrarySortByType.Progress:
      return getBookReadRatio(a) - getBookReadRatio(b);
    case LibrarySortByType.Pages:
      return (getBookPageCount(a) ?? 0) - (getBookPageCount(b) ?? 0);
    case LibrarySortByType.Series: {
      // Group by series name first so books of the same series stay consecutive,
      // then order within a series by index. Comparing index alone would interleave
      // series (all #1s, then all #2s) when this key is used as a secondary sort.
      const aSeries = a.metadata?.series || '';
      const bSeries = b.metadata?.series || '';
      const bySeries = aSeries.localeCompare(bSeries, uiLanguage || navigator.language);
      if (bySeries !== 0) return bySeries;
      return (a.metadata?.seriesIndex || 0) - (b.metadata?.seriesIndex || 0);
    }
    case LibrarySortByType.Published: {
      const aPublished = a.metadata?.published || '0001-01-01';
      const bPublished = b.metadata?.published || '0001-01-01';

      // Handle cases where published date might not exist
      if (!aPublished && !bPublished) return 0;
      if (!aPublished) return 1; // Books without published date go to the end
      if (!bPublished) return -1;

      // Try to parse dates - handle various date formats
      const aDate = new Date(aPublished).getTime();
      const bDate = new Date(bPublished).getTime();

      // If dates are invalid (NaN), fall back to string comparison
      if (isNaN(aDate) && isNaN(bDate)) {
        return aPublished.localeCompare(bPublished, uiLanguage || navigator.language);
      }
      if (isNaN(aDate)) return 1;
      if (isNaN(bDate)) return -1;

      return aDate - bDate;
    }
    case LibrarySortByType.TimeRemaining: {
      const aTime = getDisplayedTimeRemaining(a, pageDurations?.[a.hash]);
      const bTime = getDisplayedTimeRemaining(b, pageDurations?.[b.hash]);
      // Never subtract two Infinities here: NaN makes the comparator inconsistent
      // and Array.sort then scatters the no-time books through the shelf.
      if (aTime === undefined && bTime === undefined) return 0;
      if (aTime === undefined) return 1;
      if (bTime === undefined) return -1;
      return aTime - bTime;
    }
    default:
      return new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
  }
};

/**
 * @param secondarySortBy - Optional tiebreaker key applied when the primary
 *   comparison returns 0. Pass `'none'` (or omit) to disable. A Series secondary
 *   orders by series name then index; ties on both fall through to the primary tie.
 * @param sortAscending - Direction of the primary key (default ascending).
 * @param secondaryAscending - Direction of the secondary key (default ascending).
 *   Independent of the primary direction (issue #5119), so callers must NOT apply
 *   their own direction multiplier on top of this comparator.
 */
export const createBookSorter =
  (
    sortBy: string,
    uiLanguage: string,
    secondarySortBy: LibrarySecondarySortByType = 'none',
    sortAscending: boolean = true,
    secondaryAscending: boolean = true,
    pageDurations?: Readonly<Record<string, number>>,
  ) =>
  (a: Book, b: Book): number => {
    const primary = compareBookByKey(a, b, sortBy, uiLanguage, pageDurations);
    if (primary !== 0) return primary * (sortAscending ? 1 : -1);
    if (secondarySortBy === 'none') return 0;
    return (
      compareBookByKey(a, b, secondarySortBy, uiLanguage, pageDurations) *
      (secondaryAscending ? 1 : -1)
    );
  };

/**
 * Pick the books for the recently-read shelf: most-recently-read first, capped
 * at `count`. Only currently-reading books qualify (see `isCurrentlyReadingBook`):
 * finished, abandoned and freshly-imported books are left off. Recency uses
 * `updatedAt` (the library's "Updated" sort key) so the row matches the app's
 * existing sort convention. NB: `updatedAt` is last-modified (also bumped by
 * status/metadata edits and sync), not strictly last-read. Independent of the
 * main shelf's sort/grouping — always a flat, recency slice.
 */
export const selectRecentShelfBooks = (books: Book[], count: number): Book[] => {
  const byRecency = createBookSorter(LibrarySortByType.Updated, '');
  return books
    .filter(isCurrentlyReadingBook)
    .sort((a, b) => -byRecency(a, b))
    .slice(0, count);
};

/**
 * Build a `groupName -> max(book.updatedAt)` map for all groups touched by
 * the given books. Each book bumps both its direct group and every ancestor
 * group along its path (e.g. a book in "Literature/Fiction" also bumps
 * "Literature"), so parent groups don't sink just because their direct
 * members are stale.
 */
export const buildGroupNameUpdatedAt = (books: Book[]): Map<string, number> => {
  const map = new Map<string, number>();
  for (const book of books) {
    if (!book.groupName || !book.updatedAt) continue;
    let path: string | undefined = book.groupName;
    while (path) {
      const prev = map.get(path) ?? 0;
      if (book.updatedAt > prev) map.set(path, book.updatedAt);
      const slash = path.lastIndexOf('/');
      path = slash === -1 ? undefined : path.slice(0, slash);
    }
  }
  return map;
};

export const getBreadcrumbs = (currentPath: string) => {
  if (!currentPath) return [];
  const segments = currentPath.split('/');
  return segments.map((segment, index) => ({
    name: segment,
    path: segments.slice(0, index + 1).join('/'),
  }));
};

/**
 * Parse a combined author string into individual author names.
 * Handles common separators like ", ", " & ", " and ".
 */
export const parseAuthors = (authorString: string): string[] => {
  if (!authorString || !authorString.trim()) {
    return [];
  }

  // Split by common separators: comma, ampersand, "and"
  // Use regex to handle variations with different spacing
  const authors = authorString
    .split(/\s*(?:,|&|\band\b)\s*/i)
    .map((author) => author.trim())
    .filter((author) => author.length > 0);

  return authors;
};

/**
 * Create groups from books based on the groupBy setting.
 * Returns a mix of BooksGroup and ungrouped Book items.
 */
export const createBookGroups = (
  books: Book[],
  groupBy: LibraryGroupByType,
): (Book | BooksGroup)[] => {
  // Filter out deleted books
  const activeBooks = books.filter((book) => !book.deletedAt);

  if (groupBy === LibraryGroupByType.None) {
    return activeBooks;
  }

  if (groupBy === LibraryGroupByType.Series) {
    return createSeriesGroups(activeBooks);
  }

  if (groupBy === LibraryGroupByType.Author) {
    return createAuthorGroups(activeBooks);
  }

  if (groupBy === LibraryGroupByType.Tag) {
    return createValueGroups(activeBooks, 'tag', getBookTags);
  }

  if (groupBy === LibraryGroupByType.Subject) {
    return createValueGroups(activeBooks, 'subject', getBookSubjects);
  }
  if (groupBy === LibraryGroupByType.Status) {
    return createValueGroups(
      activeBooks,
      'status',
      // `readingStatus` is an optional annotation, not a lifecycle field:
      // nothing stamps it at import, and opening a book *clears* 'unread' back
      // to `undefined`. Grouping on it alone therefore partitions badly — on a
      // real 750-book library it dropped 414 never-opened books out of the
      // shelf entirely and left "Unread" holding the 1 book that had been
      // manually re-marked. So derive both ends instead: 'reading' from the
      // predicate the recently-read shelf and home-screen widget already share
      // (#1010 asks for exactly that shelf), and 'unread' as the resting state
      // for a book with no status and no progress. Every book lands in exactly
      // one bucket and nothing is left ungrouped.
      (book) =>
        isCurrentlyReadingBook(book)
          ? ['reading' satisfies ReadingStatus]
          : [book.readingStatus ?? ('unread' satisfies ReadingStatus)],
      (status) => READING_STATUS_LABELS[status as ReadingStatus] ?? status,
    );
  }

  // 'group' mode is handled separately by generateBookshelfItems
  return activeBooks;
};

/**
 * Group books by series metadata.
 * Books without series appear as individual items.
 */
const createSeriesGroups = (books: Book[]): (Book | BooksGroup)[] => {
  const seriesMap = new Map<string, Book[]>();
  const ungroupedBooks: Book[] = [];

  for (const book of books) {
    const seriesName = book.metadata?.series?.trim();

    if (seriesName) {
      const existing = seriesMap.get(seriesName);
      if (existing) {
        existing.push(book);
      } else {
        seriesMap.set(seriesName, [book]);
      }
    } else {
      ungroupedBooks.push(book);
    }
  }

  const groups: BooksGroup[] = Array.from(seriesMap.entries()).map(([seriesName, seriesBooks]) => ({
    id: md5Fingerprint(`series:${seriesName}`),
    name: seriesName,
    displayName: seriesName,
    books: seriesBooks,
    updatedAt: Math.max(...seriesBooks.map((b) => b.updatedAt)),
  }));

  return [...groups, ...ungroupedBooks];
};

/**
 * Group books by author.
 * Books with multiple authors appear in ALL matching author groups.
 * Books without author appear as individual items.
 */
const createAuthorGroups = (books: Book[]): (Book | BooksGroup)[] => {
  const authorMap = new Map<string, Book[]>();
  const ungroupedBooks: Book[] = [];

  for (const book of books) {
    const authorString = book.author?.trim();

    if (!authorString) {
      ungroupedBooks.push(book);
      continue;
    }

    const authors = parseAuthors(authorString);

    if (authors.length === 0) {
      ungroupedBooks.push(book);
      continue;
    }

    // Add book to each author's group
    for (const author of authors) {
      const existing = authorMap.get(author);
      if (existing) {
        existing.push(book);
      } else {
        authorMap.set(author, [book]);
      }
    }
  }

  const groups: BooksGroup[] = Array.from(authorMap.entries()).map(([authorName, authorBooks]) => ({
    id: md5Fingerprint(`author:${authorName}`),
    name: authorName,
    displayName: authorName,
    books: authorBooks,
    updatedAt: Math.max(...authorBooks.map((b) => b.updatedAt)),
  }));

  return [...groups, ...ungroupedBooks];
};

const createValueGroups = (
  books: Book[],
  namespace: 'tag' | 'subject' | 'status',
  getValues: (book: Book) => string[],
  /**
   * Maps an internal value to a translation *key*. Supply this only for
   * namespaces whose values are enums we own; the resulting groups are flagged
   * `localized` so the UI translates them. Omit it for user-authored values
   * (tags, subjects) so a tag literally named "Unread" renders verbatim.
   */
  getDisplayKey?: (value: string) => string,
): (Book | BooksGroup)[] => {
  const valueMap = new Map<string, Book[]>();
  const ungroupedBooks: Book[] = [];
  for (const book of books) {
    const values = getValues(book);
    if (!values.length) {
      ungroupedBooks.push(book);
      continue;
    }
    for (const value of values) {
      const existing = valueMap.get(value);
      if (existing) existing.push(book);
      else valueMap.set(value, [book]);
    }
  }

  const groups = Array.from(valueMap, ([name, groupBooks]): BooksGroup => {
    const group: BooksGroup = {
      id: md5Fingerprint(`${namespace}:${name}`),
      name,
      displayName: getDisplayKey ? getDisplayKey(name) : name,
      books: groupBooks,
      updatedAt: Math.max(...groupBooks.map(({ updatedAt }) => updatedAt)),
    };
    if (getDisplayKey) group.localized = true;
    return group;
  });
  return [...groups, ...ungroupedBooks];
};

export const resolveCurrentShelfBooks = (
  books: Book[],
  groupBy: LibraryGroupByType,
  groupId = '',
  manualGroupName?: string,
): Book[] => {
  const activeBooks = books.filter((book) => !book.deletedAt);
  if (!groupId) return activeBooks;
  if (groupBy === LibraryGroupByType.None) return [];
  if (groupBy === LibraryGroupByType.Group) {
    if (!manualGroupName) return [];
    const descendantPrefix = `${manualGroupName}/`;
    return activeBooks.filter(
      ({ groupName }) => groupName === manualGroupName || groupName?.startsWith(descendantPrefix),
    );
  }
  return findGroupById(createBookGroups(activeBooks, groupBy), groupId)?.books ?? [];
};

/**
 * Create a sorter for books within a group.
 * For series groups: sort by seriesIndex first (always ascending), then by global sort for items without index.
 * For other groupings: when a secondary key is supplied, sort by secondary key first (in its own
 *   direction), with the primary global sort as tiebreaker. Without secondary, follow global sort setting.
 * @param sortAscending - When true (default), sort direction is ascending. Series index is always
 *   ascending regardless of this flag; the flag affects the fallback / primary tiebreaker only.
 * @param secondarySortBy - When non-'none', acts as the *primary* within-group ordering for
 *   non-series groupings (matches the user's mental model: "group by author, then sort by series"
 *   should land series order inside each author).
 * @param secondaryAscending - Direction of the secondary key, independent of `sortAscending`
 *   (issue #5119).
 */
export const createWithinGroupSorter =
  (
    groupBy: LibraryGroupByType,
    sortBy: LibrarySortByType,
    uiLanguage: string,
    sortAscending: boolean = true,
    secondarySortBy: LibrarySecondarySortByType = 'none',
    secondaryAscending: boolean = true,
    pageDurations?: Readonly<Record<string, number>>,
  ) =>
  (a: Book, b: Book): number => {
    const sortDirection = sortAscending ? 1 : -1;

    if (groupBy === LibraryGroupByType.Series) {
      const aIndex = a.metadata?.seriesIndex;
      const bIndex = b.metadata?.seriesIndex;

      // Both have series index - always sort ascending by index
      if (aIndex != null && bIndex != null) {
        return aIndex - bIndex;
      }

      // Only one has series index - the one with index comes first
      if (aIndex != null) return -1;
      if (bIndex != null) return 1;

      // Neither has series index - fall back to global sort with direction
      return (
        createBookSorter(sortBy, uiLanguage, 'none', true, true, pageDurations)(a, b) *
        sortDirection
      );
    }

    // For author and other non-series groupings: when a secondary key is provided,
    // use it as the within-group primary order with the global key as tiebreaker.
    if (secondarySortBy !== 'none') {
      const bySecondary = compareBookByKey(a, b, secondarySortBy, uiLanguage, pageDurations);
      if (bySecondary !== 0) return bySecondary * (secondaryAscending ? 1 : -1);
      return (
        createBookSorter(sortBy, uiLanguage, 'none', true, true, pageDurations)(a, b) *
        sortDirection
      );
    }

    return (
      createBookSorter(sortBy, uiLanguage, 'none', true, true, pageDurations)(a, b) * sortDirection
    );
  };

/**
 * Get the sort value from a book for comparison with groups.
 */
export const getBookSortValue = (book: Book, sortBy: LibrarySortByType): number | string => {
  switch (sortBy) {
    case LibrarySortByType.Title:
      return formatTitle(book.title);

    case LibrarySortByType.Author:
      return formatAuthors(book.author, book?.primaryLanguage || 'en', true);

    case LibrarySortByType.Updated:
      return book.updatedAt;

    case LibrarySortByType.Created:
      return book.createdAt;

    case LibrarySortByType.Format:
      return book.format;

    case LibrarySortByType.Progress:
      return getBookReadRatio(book);

    case LibrarySortByType.Pages:
      return getBookPageCount(book) ?? 0;

    case LibrarySortByType.Published: {
      const published = book.metadata?.published;
      if (!published) return 0;
      const publishedTime = new Date(published).getTime();
      return isNaN(publishedTime) ? 0 : publishedTime;
    }

    case LibrarySortByType.TimeRemaining:
      // Return Infinity if a book does not have time remaining (ie. if the book is unread or finished) so it is sorted after books with time remaining
      return getTimeRemainingMinutes(book) ?? Infinity;

    default:
      return book.updatedAt;
  }
};

/**
 * Get the aggregate sort value from a group for sorting groups.
 */
export const getGroupSortValue = (
  group: BooksGroup,
  sortBy: LibrarySortByType,
  groupBy?: LibraryGroupByType,
): number | string => {
  const books = group.books;

  if (books.length === 0) {
    return sortBy === LibrarySortByType.Title ||
      sortBy === LibrarySortByType.Series ||
      sortBy === LibrarySortByType.Author ||
      sortBy === LibrarySortByType.Format
      ? group.name
      : 0;
  }

  switch (sortBy) {
    case LibrarySortByType.Title:
    case LibrarySortByType.Series:
    case LibrarySortByType.Format:
      return group.name;

    case LibrarySortByType.Author: {
      if (groupBy === LibraryGroupByType.Author) {
        // Author group: format the group name (single author) with last-name-first
        return formatAuthors(group.name, 'en', true);
      }
      if (groupBy === LibraryGroupByType.Series) {
        // Series group: use the first book's author for sorting
        const firstBook = books[0]!;
        return formatAuthors(firstBook.author, firstBook.primaryLanguage || 'en', true);
      }
      // Custom/other groups: fall back to group name
      return group.name;
    }

    case LibrarySortByType.Updated:
      // Return the most recent updatedAt
      return Math.max(...books.map((b) => b.updatedAt));

    case LibrarySortByType.Created:
      // Return the most recent createdAt
      return Math.max(...books.map((b) => b.createdAt));

    case LibrarySortByType.Progress:
      // Return the most-progressed book's read ratio
      return Math.max(...books.map((b) => getBookReadRatio(b)));

    case LibrarySortByType.Pages:
      // Return the group's total page count
      return books.reduce((sum, b) => sum + (getBookPageCount(b) ?? 0), 0);

    case LibrarySortByType.Published: {
      // Return the most recent published date
      const publishedDates = books
        .map((b) => b.metadata?.published)
        .filter((d): d is string => !!d)
        .map((d) => new Date(d).getTime())
        .filter((t) => !isNaN(t));

      return publishedDates.length > 0 ? Math.max(...publishedDates) : 0;
    }

    case LibrarySortByType.TimeRemaining:
      // Return book with least amount of time remaining
      return Math.min(...books.map((b) => getTimeRemainingMinutes(b) ?? Infinity));

    default:
      return Math.max(...books.map((b) => b.updatedAt));
  }
};

/**
 * Compare two sort values (string or number) for sorting.
 */
export const compareSortValues = (
  aValue: number | string,
  bValue: number | string,
  uiLanguage: string,
  sortBy?: LibrarySortByType,
): number => {
  // String comparison for text-based sorts
  if (typeof aValue === 'string' && typeof bValue === 'string') {
    return sortBy === LibrarySortByType.Title
      ? compareTitles(aValue, bValue, uiLanguage)
      : aValue.localeCompare(bValue, uiLanguage || navigator.language);
  }

  // Numeric comparison for date-based sorts
  if (typeof aValue === 'number' && typeof bValue === 'number') {
    return aValue - bValue;
  }

  return 0;
};

/**
 * Create a sorter for groups themselves based on sort criteria.
 */
export const createGroupSorter =
  (sortBy: LibrarySortByType, uiLanguage: string, groupBy?: LibraryGroupByType) =>
  (a: BooksGroup, b: BooksGroup): number => {
    const aValue = getGroupSortValue(a, sortBy, groupBy);
    const bValue = getGroupSortValue(b, sortBy, groupBy);

    return compareSortValues(aValue, bValue, uiLanguage, sortBy);
  };

/**
 * Build a new Book with an explicit reading status. Stamps both `updatedAt`
 * (so the library sync picks it up) and `readingStatusUpdatedAt` (so the
 * field-level merge resolves status independently of progress). Use this for
 * every deliberate status edit so the timestamp is never forgotten.
 */
export const withReadingStatus = (book: Book, status: ReadingStatus | undefined): Book => {
  const now = Date.now();
  return { ...book, readingStatus: status, readingStatusUpdatedAt: now, updatedAt: now };
};

type ReadingStatusFields = Pick<Book, 'readingStatus' | 'readingStatusUpdatedAt'>;

/**
 * Field-level last-writer-wins for reading status: return whichever side's
 * status was set more recently (ties → `a`). Missing timestamp = epoch 0.
 * The book row's `updatedAt` is dominated by page-turn progress, so status
 * must be resolved by its own timestamp or progress would clobber it.
 */
export const pickFresherReadingStatus = (
  a: ReadingStatusFields,
  b: ReadingStatusFields,
): ReadingStatusFields => {
  const at = (x: ReadingStatusFields) => x.readingStatusUpdatedAt ?? 0;
  const winner = at(a) >= at(b) ? a : b;
  return {
    readingStatus: winner.readingStatus,
    readingStatusUpdatedAt: winner.readingStatusUpdatedAt,
  };
};

type CoverFields = Pick<Book, 'coverHash' | 'coverUpdatedAt'>;
type CoverSyncFields = Pick<
  Book,
  'coverHash' | 'coverUpdatedAt' | 'coverDownloadedAt' | 'deletedAt' | 'uploadedAt'
>;

const coverMs = (t?: number | null) => t ?? 0;

/**
 * Decide whether a peer should (re)download a book's cover from the cloud
 * (issue #4544). True when the synced book is in the cloud AND either:
 *  - this device has never fetched the cover (first download), or
 *  - a newer cover edit exists (synced `coverUpdatedAt` strictly newer) whose
 *    content hash differs from the local one.
 *
 * Gating on `coverUpdatedAt` (not just the hash) prevents two failure modes:
 *  - churn: once a device adopts the synced `coverUpdatedAt` after downloading,
 *    the comparison stops firing on every subsequent sync;
 *  - the unpushed-local-edit race: a device that just edited its cover (newer
 *    local `coverUpdatedAt`) is not made to overwrite it with the stale cloud
 *    copy before its own push lands.
 */
export const needsCoverRefresh = (local: CoverSyncFields, synced: CoverSyncFields): boolean => {
  if (synced.deletedAt || !synced.uploadedAt) return false;
  if (!local.coverDownloadedAt) return true; // first download
  if (!synced.coverHash) return false; // nothing to compare (legacy book)
  if (coverMs(synced.coverUpdatedAt) <= coverMs(local.coverUpdatedAt)) return false;
  return synced.coverHash !== local.coverHash;
};

/**
 * Field-level last-writer-wins for the cover, by `coverUpdatedAt` (ties →
 * `local`, which already holds the file). Mirrors {@link pickFresherReadingStatus}:
 * the row's `updatedAt` is dominated by page-turn progress, so the cover must be
 * resolved by its own timestamp or progress would clobber a cover edit.
 */
export const pickFresherCover = (local: CoverFields, synced: CoverFields): CoverFields =>
  coverMs(synced.coverUpdatedAt) > coverMs(local.coverUpdatedAt)
    ? { coverHash: synced.coverHash, coverUpdatedAt: synced.coverUpdatedAt }
    : { coverHash: local.coverHash, coverUpdatedAt: local.coverUpdatedAt };

type MetadataFields = Pick<Book, 'title' | 'author' | 'tags' | 'metadata' | 'metadataUpdatedAt'>;

/**
 * Field-level last-writer-wins for the metadata group (title, author, tags,
 * metadata), by `metadataUpdatedAt` (issue #5438). Mirrors
 * {@link pickFresherReadingStatus} / {@link pickFresherCover}: the row's
 * `updatedAt` is dominated by page-turn progress, so a metadata edit must be
 * resolved by its own timestamp or reading the book on another device would
 * clobber it. Returns null when neither side's stamp is strictly fresher —
 * notably the unstamped legacy case — so the caller keeps the row-level
 * winner's fields (legacy behavior) instead of grafting.
 */
export const pickFresherMetadata = (
  local: MetadataFields,
  synced: MetadataFields,
): MetadataFields | null => {
  const localMs = local.metadataUpdatedAt ?? 0;
  const syncedMs = synced.metadataUpdatedAt ?? 0;
  if (localMs === syncedMs) return null;
  const winner = localMs > syncedMs ? local : synced;
  return {
    title: winner.title,
    author: winner.author,
    tags: winner.tags,
    metadata: winner.metadata,
    metadataUpdatedAt: winner.metadataUpdatedAt,
  };
};
