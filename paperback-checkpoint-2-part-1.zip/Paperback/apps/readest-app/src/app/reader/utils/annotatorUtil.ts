import { Overlayer } from 'foliate-js/overlayer.js';
import { HIGHLIGHT_COLOR_HEX } from '@/services/constants';
import {
  BookNote,
  BooknoteGroup,
  DEFAULT_HIGHLIGHT_COLORS,
  HighlightColor,
  HighlightStyle,
  ViewSettings,
} from '@/types/book';
import { uniqueId } from '@/utils/misc';
import { nextBooknoteStamp } from '@/utils/booknoteStamp';
import { SystemSettings } from '@/types/settings';
import { FoliateView, NOTE_PREFIX } from '@/types/view';
import { Point, snapRangeToWords } from '@/utils/sel';
import { expandAllRenderedSections, removeGlobalAnnotationOverlays } from './globalAnnotations';

export const isDefaultHighlightColor = (
  color: HighlightColor,
): color is (typeof DEFAULT_HIGHLIGHT_COLORS)[number] => {
  return (DEFAULT_HIGHLIGHT_COLORS as readonly string[]).includes(color);
};

export const getHighlightColorHex = (
  settings: SystemSettings,
  color?: HighlightColor,
): string | undefined => {
  if (!color) return undefined;
  if (color.startsWith('#')) return color;
  const customColors = settings.globalReadSettings.customHighlightColors;
  return customColors?.[color] ?? HIGHLIGHT_COLOR_HEX[color];
};

/**
 * Returns a user-defined label for the given color, or `undefined` when none is set.
 * Callers that want to fall back to a translated default name should handle that in
 * the component layer (where `useTranslation` is available).
 */
export const getHighlightColorLabel = (
  settings: SystemSettings,
  color: HighlightColor,
): string | undefined => {
  const { defaultHighlightLabels, userHighlightColors } = settings.globalReadSettings;
  if (color.startsWith('#')) {
    const hex = color.trim().toLowerCase();
    const entry = userHighlightColors?.find((c) => c.hex === hex);
    return entry?.label?.trim() || undefined;
  }
  if (isDefaultHighlightColor(color)) {
    return defaultHighlightLabels?.[color]?.trim() || undefined;
  }
  return undefined;
};

const ALL_HIGHLIGHT_STYLES: readonly HighlightStyle[] = ['highlight', 'underline', 'squiggly'];

export interface ExportFilter {
  excludedColors: HighlightColor[];
  excludedStyles: HighlightStyle[];
}

export interface FilteredExportGroups {
  groups: BooknoteGroup[];
  distinctColors: HighlightColor[];
  distinctStyles: HighlightStyle[];
  applyColorFilter: boolean;
  applyStyleFilter: boolean;
}

/**
 * Filter chapter groups for annotation export by highlight color and style (#4801).
 *
 * Exclusions (not inclusions) are stored so an empty filter exports everything and
 * colors/styles introduced later are included by default. A dimension is only
 * filtered when at least two distinct values are present, so a filter row the user
 * cannot see can never silently drop notes. Notes without a color/style (e.g.
 * bookmarks) always pass. Groups left empty by the filter are dropped.
 *
 * `distinctColors` is ordered by the default palette first, then custom colors in
 * first-seen order; `distinctStyles` follows the canonical highlight/underline/
 * squiggly order — both drive the filter UI.
 */
export function filterExportGroups(
  groups: BooknoteGroup[],
  { excludedColors, excludedStyles }: ExportFilter,
): FilteredExportGroups {
  const { colors: distinctColors, styles: distinctStyles } = collectAnnotationFacets(
    groups.flatMap((group) => group.booknotes),
  );

  const applyColorFilter = distinctColors.length >= 2;
  const applyStyleFilter = distinctStyles.length >= 2;

  const keep = (note: BookNote) =>
    (!applyColorFilter || !note.color || !excludedColors.includes(note.color)) &&
    (!applyStyleFilter || !note.style || !excludedStyles.includes(note.style));

  const filtered = groups
    .map((group) => ({ ...group, booknotes: group.booknotes.filter(keep) }))
    .filter((group) => group.booknotes.length > 0);

  return { groups: filtered, distinctColors, distinctStyles, applyColorFilter, applyStyleFilter };
}

export function getExternalDragHandle(
  currentStart: Point,
  currentEnd: Point,
  externalDragPoint?: Point | null,
): 'start' | 'end' | null {
  if (!externalDragPoint) return null;
  const distToStart = Math.hypot(
    externalDragPoint.x - currentStart.x,
    externalDragPoint.y - currentStart.y,
  );
  const distToEnd = Math.hypot(
    externalDragPoint.x - currentEnd.x,
    externalDragPoint.y - currentEnd.y,
  );
  return distToStart < distToEnd ? 'start' : 'end';
}

export function toParentViewportPoint(doc: Document, x: number, y: number): Point {
  const frameElement = doc.defaultView?.frameElement;
  const frameRect = frameElement?.getBoundingClientRect() ?? { top: 0, left: 0, width: 0 };
  // Fixed-layout pages are iframes shrunk to fit with a CSS transform.
  const scale = frameElement?.clientWidth ? frameRect.width / frameElement.clientWidth : 1;
  return { x: frameRect.left + x * scale, y: frameRect.top + y * scale };
}

export interface HandlePositions {
  start: Point;
  end: Point;
}

/**
 * Window-coordinate positions for a pair of range-edit drag handles: the
 * start handle anchors at the leading edge of the range's first line rect,
 * the end handle at the trailing edge of its last one.
 */
export function getHandlePositionsFromRange(
  bookKey: string,
  range: Range,
  isVertical: boolean,
): HandlePositions | null {
  const gridFrame = document.querySelector(`#gridcell-${bookKey}`);
  if (!gridFrame) return null;

  const rects = Array.from(range.getClientRects());
  if (rects.length === 0) return null;

  const firstRect = rects[0]!;
  const lastRect = rects[rects.length - 1]!;
  const frameElement = range.commonAncestorContainer.ownerDocument?.defaultView?.frameElement;
  const frameRect = frameElement?.getBoundingClientRect() ?? { top: 0, left: 0 };

  return {
    start: {
      x: frameRect.left + (isVertical ? firstRect.right : firstRect.left),
      y: frameRect.top + firstRect.top,
    },
    end: {
      x: frameRect.left + (isVertical ? lastRect.left : lastRect.right),
      y: frameRect.top + lastRect.bottom,
    },
  };
}

/**
 * Build a word-snapped Range between two window-coordinate points by
 * hit-testing every rendered section document. Returns the document and
 * section index the range landed in, or `null` when neither point maps
 * into the same document.
 */
export function buildRangeFromPoints(
  view: FoliateView | null,
  startPoint: Point,
  endPoint: Point,
): { range: Range; index: number; doc: Document } | null {
  const contents = view?.renderer.getContents();
  if (!contents || contents.length === 0) return null;

  // the point is from viewport, need to adjust to each content's coordinate
  const findPositionAtPoint = (doc: Document, x: number, y: number) => {
    const frameElement = doc.defaultView?.frameElement;
    const frameRect = frameElement?.getBoundingClientRect() ?? { top: 0, left: 0 };
    const adjustedX = x - frameRect.left;
    const adjustedY = y - frameRect.top;

    if (doc.caretPositionFromPoint) {
      const pos = doc.caretPositionFromPoint(adjustedX, adjustedY);
      if (pos) return { node: pos.offsetNode, offset: pos.offset };
    }
    if (doc.caretRangeFromPoint) {
      const range = doc.caretRangeFromPoint(adjustedX, adjustedY);
      if (range) return { node: range.startContainer, offset: range.startOffset };
    }
    return null;
  };

  for (const content of contents) {
    const { doc, index } = content;
    if (!doc) continue;

    const startPos = findPositionAtPoint(doc, startPoint.x, startPoint.y);
    const endPos = findPositionAtPoint(doc, endPoint.x, endPoint.y);
    if (!startPos || !endPos) continue;

    const range = doc.createRange();
    try {
      const positionComparison = startPos.node.compareDocumentPosition(endPos.node);
      const needsSwap =
        positionComparison & Node.DOCUMENT_POSITION_PRECEDING ||
        (startPos.node === endPos.node && startPos.offset > endPos.offset);

      if (needsSwap) {
        range.setStart(endPos.node, endPos.offset);
        range.setEnd(startPos.node, startPos.offset);
      } else {
        range.setStart(startPos.node, startPos.offset);
        range.setEnd(endPos.node, endPos.offset);
      }

      if (range.collapsed) {
        return null;
      }

      snapRangeToWords(range);
    } catch (e) {
      console.warn('Failed to create range:', e);
      return null;
    }
    return { range, index: index ?? 0, doc };
  }
  return null;
}

/**
 * Remove any overlays drawn for a BookNote from the given view.
 *
 * A single BookNote can have up to two overlays attached:
 *   - a highlight/underline/squiggly overlay (keyed by the raw CFI)
 *   - a note bubble overlay (keyed by `${NOTE_PREFIX}${cfi}`)
 *
 * The set of overlays drawn is defined by the progress-sync effect in
 * Annotator.tsx, and this helper mirrors those filters so that deleting
 * an annotation from the sidebar clears every overlay that was drawn
 * for it, not just the note bubble.
 */
export function removeBookNoteOverlays(view: FoliateView | null, note: BookNote): void {
  if (!view) return;
  if (note.type !== 'annotation') return;
  if (note.style) {
    view.addAnnotation({ ...note, value: note.cfi }, true);
  }
  if (note.note && note.note.trim().length > 0) {
    view.addAnnotation({ ...note, value: `${NOTE_PREFIX}${note.cfi}` }, true);
  }
  if (note.global) removeGlobalAnnotationOverlays(view, note);
}

/**
 * The "Annotate" action eagerly creates an empty highlight as the anchor for the
 * note the user is about to type, so the selection stays visible while the editor
 * is open. If the user cancels without saving, that placeholder must be torn down
 * so it doesn't leak into the booknotes list (#4791).
 *
 * Tombstones the live annotation identified by `placeholderId` in `booknotes`
 * (mutating in place, matching the surrounding highlight handlers) and returns it
 * so the caller can remove its overlay. Returns null — leaving `booknotes`
 * untouched — when there's nothing to clean up: no live annotation with that id,
 * or the record already carries note text (the user saved, so it's real now).
 */
export function removeEmptyAnnotationPlaceholder(
  booknotes: BookNote[],
  placeholderId: string,
  now: number,
): BookNote | null {
  const index = booknotes.findIndex(
    (note) =>
      note.id === placeholderId &&
      note.type === 'annotation' &&
      !note.deletedAt &&
      !note.note?.trim(),
  );
  if (index === -1) return null;
  const placeholder = booknotes[index]!;
  booknotes[index] = { ...placeholder, deletedAt: nextBooknoteStamp(placeholder, now) };
  return placeholder;
}

/**
 * Build a persistent highlight BookNote for a TTS-spoken sentence, or return
 * `null` when one already exists at the same CFI (idempotent — pressing the
 * hotkey twice on the same sentence must not create a duplicate).
 *
 * `now` is injected so the result is deterministic for tests. A soft-deleted
 * note (`deletedAt`) or a non-annotation note (e.g. a bookmark) at the same CFI
 * does not block creation — it mirrors the live-annotation predicate used by
 * the selection-based highlight path in Annotator.tsx.
 */
export function buildTTSSentenceHighlight(
  annotations: BookNote[],
  params: {
    cfi: string;
    text: string;
    style: HighlightStyle;
    color: HighlightColor;
    page?: number;
  },
  now: number,
): BookNote | null {
  const exists = annotations.some(
    (a) => a.cfi === params.cfi && a.type === 'annotation' && a.style && !a.deletedAt,
  );
  if (exists) return null;
  return {
    id: uniqueId(),
    type: 'annotation',
    note: '',
    createdAt: now,
    updatedAt: now,
    ...params,
  };
}

export type AnnotationDrawKind = 'bubble' | 'highlight' | 'underline' | 'squiggly' | 'none';

/** Overlay styles the reader draws: the annotation styles plus the extra
 *  strokes only the TTS highlight offers. */
export type OverlayStyle = HighlightStyle | 'strikethrough' | 'outline';

/**
 * Color to draw an annotation or TTS overlay in.
 *
 * On B&W e-ink the highlight overlay is composited with `mix-blend-mode:
 * difference` at full opacity (see `useTheme.ts`), so its color is an inversion
 * mask rather than paint: difference is `|backdrop - source|`, so white swaps
 * page and ink around each other while black is the identity and leaves the
 * page untouched. Masking with the theme background therefore erased every
 * highlight on a dark page, and since overlays keep the fill they were drawn
 * with, going back to light stayed broken until reload (#5667). One mask
 * inverts both themes, so it must not follow the theme at all.
 *
 * The remaining styles are stroked without a blend mode and take the theme ink.
 */
export function getAnnotationOverlayColor<T extends string | undefined>(
  style: OverlayStyle,
  hexColor: T,
  { isBwEink, isDarkMode }: { isBwEink: boolean; isDarkMode: boolean },
): T | string {
  if (!isBwEink) return hexColor;
  if (style === 'highlight') return '#ffffff';
  return isDarkMode ? '#ffffff' : '#000000';
}

/**
 * Decide what an overlay should draw for an annotation. The bubble vs.
 * highlight choice keys off the overlay's `value` prefix — NOT `annotation.note`
 * — so a single unified record draws BOTH its highlight overlay (value = cfi)
 * and its note bubble (value = `${NOTE_PREFIX}${cfi}`).
 */
export function decideAnnotationDraw(
  value: string | undefined,
  style: HighlightStyle | undefined,
): AnnotationDrawKind {
  if (value?.startsWith(NOTE_PREFIX)) return 'bubble';
  if (style === 'highlight') return 'highlight';
  if (style === 'underline' || style === 'squiggly') return style;
  return 'none';
}

/**
 * Style callback for foliate's `draw-annotation` overlay event. Shared by the
 * main view (Annotator) and the footnote popup view (FootnotePopup, which
 * draws mapped copies of annotations inside the popup document).
 */
export function drawAnnotationOverlay(
  detail: {
    draw: (func: unknown, opts?: Record<string, unknown>) => void;
    annotation: BookNote & { value?: string };
    doc: Document;
    range: Range;
  },
  ctx: {
    settings: SystemSettings;
    viewSettings: ViewSettings;
    isDarkMode: boolean;
    isMobile: boolean;
  },
): void {
  const { draw, annotation, doc, range } = detail;
  const { settings, viewSettings, isDarkMode, isMobile } = ctx;
  const isBwEink = viewSettings.isEink && !viewSettings.isColorEink;
  const { style, color, value } = annotation;
  const hexColor = getHighlightColorHex(settings, color);
  // Choose what to draw from the overlay's `value` (cfi vs NOTE_PREFIX+cfi),
  // not from `annotation.note`: a unified record (style + note) is added as
  // two overlays and must draw a highlight for the cfi overlay AND a bubble
  // for the note overlay. Keying off `note` drew only the bubble (#4511).
  const kind = decideAnnotationDraw(value, style);
  const startElement = () => {
    const node = range.startContainer;
    return node.nodeType === 1 ? (node as Element) : node.parentElement!;
  };
  if (kind === 'bubble') {
    const { writingMode } = doc.defaultView!.getComputedStyle(startElement());
    draw(Overlayer.bubble, { writingMode });
  } else if (kind === 'highlight') {
    draw(Overlayer.highlight, {
      color: getAnnotationOverlayColor('highlight', hexColor, { isBwEink, isDarkMode }),
      vertical: viewSettings.vertical,
    });
  } else if (kind === 'underline' || kind === 'squiggly') {
    const { writingMode, lineHeight, fontSize } = doc.defaultView!.getComputedStyle(startElement());
    const fontSizeValue = parseFloat(fontSize) || viewSettings.defaultFontSize;
    const lineHeightValue = parseFloat(lineHeight) || viewSettings.lineHeight * fontSizeValue;
    const strokeWidth = 2;
    const verticalCompensation = isMobile ? 0 : -1;
    const horizontalCompensation = isMobile ? -1 : 0;
    const padding = viewSettings.vertical
      ? (lineHeightValue - fontSizeValue) / 2 - strokeWidth + verticalCompensation
      : (lineHeightValue - fontSizeValue) / 2 - strokeWidth + horizontalCompensation;
    draw(Overlayer[kind], {
      writingMode,
      color: getAnnotationOverlayColor(kind, hexColor, { isBwEink, isDarkMode }),
      padding,
    });
  }
}

/**
 * Index of the live (`!deletedAt`) annotation record at `cfi`, or -1. Used when
 * adding a note so it attaches to the existing highlight instead of creating a
 * second record at the same position.
 */
export function findAnnotationAtCfi(booknotes: BookNote[], cfi: string): number {
  return booknotes.findIndex(
    (note) => note.type === 'annotation' && note.cfi === cfi && !note.deletedAt,
  );
}

/**
 * Merge a freshly-built restyle (`restyled`, carrying the new style/color) onto
 * an `existing` annotation, preserving the parts a restyle must not lose: the
 * record id, its note text, the selected text, the original creation time, and
 * the `global` flag. Without preserving `note`, recoloring a unified annotation
 * would wipe the note. Fields the restyle does not set (sync anchors such as
 * `xpointer0`/`xpointer1`, which stay valid for the unchanged cfi) carry over.
 */
export function mergeRestyledAnnotation(existing: BookNote, restyled: BookNote): BookNote {
  return {
    ...existing,
    ...restyled,
    id: existing.id,
    createdAt: existing.createdAt,
    note: existing.note,
    text: existing.text ?? restyled.text,
    global: existing.global || restyled.global,
  };
}

export type AnnotationFilterKind = 'all' | 'notes';

/** Highlights, notes and handwriting: what the annotations hub lists. */
export const isAnnotationEntry = (note: BookNote) =>
  note.type === 'annotation' || note.type === 'ink';

export interface BooknoteFilter {
  kind: AnnotationFilterKind;
  query: string;
  excludedColors?: HighlightColor[];
  excludedStyles?: HighlightStyle[];
}

/**
 * Filter source material for the annotations hub.
 *
 * Tombstones and non-annotation records are always excluded. All includes
 * every annotation, while With notes selects annotations carrying a note body.
 * Query and facet filters compose with that kind filter.
 */
export function filterBooknotes(notes: BookNote[], filter: BooknoteFilter): BookNote[] {
  const { kind, excludedColors, excludedStyles } = filter;
  const lowercaseQuery = filter.query.trim().toLowerCase();
  return notes.filter((note) => {
    if (note.deletedAt) return false;
    if (!isAnnotationEntry(note)) return false;
    if (kind === 'notes' && !note.note) return false;
    if (note.color && excludedColors?.includes(note.color)) return false;
    if (note.style && excludedStyles?.includes(note.style)) return false;
    if (!lowercaseQuery) return true;
    const textMatch = note.text?.toLowerCase().includes(lowercaseQuery) || false;
    const noteMatch = note.note?.toLowerCase().includes(lowercaseQuery) || false;
    return textMatch || noteMatch;
  });
}

export interface AnnotationFacets {
  colors: HighlightColor[];
  styles: HighlightStyle[];
}

/**
 * Distinct colors and styles present among live notes: default palette
 * colors first (palette order), then custom colors in first-seen order;
 * styles in canonical highlight/underline/squiggly order. Drives the hub
 * toolbar's facet row and filterExportGroups' filter UI.
 */
export function collectAnnotationFacets(notes: BookNote[]): AnnotationFacets {
  const colorsSeen = new Set<HighlightColor>();
  const stylesSeen = new Set<HighlightStyle>();
  for (const note of notes) {
    if (note.deletedAt) continue;
    if (note.color) colorsSeen.add(note.color);
    if (note.style) stylesSeen.add(note.style);
  }
  const colors = [
    ...DEFAULT_HIGHLIGHT_COLORS.filter((color) => colorsSeen.has(color)),
    ...[...colorsSeen].filter((color) => !isDefaultHighlightColor(color)),
  ];
  const styles = ALL_HIGHLIGHT_STYLES.filter((style) => stylesSeen.has(style));
  return { colors, styles };
}

export interface AnnotationHubCounts {
  annotations: number;
}

/**
 * Non-overlapping source-material totals for the annotations hub. Annotations
 * carrying notes still count once as annotations; the With notes chip is a
 * subset filter rather than another count bucket.
 */
export function summarizeAnnotationHub(notes: BookNote[]): AnnotationHubCounts {
  let annotations = 0;
  for (const note of notes) {
    if (note.deletedAt) continue;
    if (isAnnotationEntry(note)) annotations += 1;
  }
  return { annotations };
}

export type NoteBubbleTransition = 'add' | 'remove' | 'none';

/**
 * Decide how an inline note edit changes the note-bubble overlay. The bubble
 * exists iff the note body is non-empty (trim-based, matching
 * removeBookNoteOverlays): appearing text adds it, cleared text removes it
 * (the highlight itself stays, per the unified-annotation rule), and a pure
 * content change needs no redraw because the bubble renders no text.
 */
export function decideNoteBubbleTransition(before: string, after: string): NoteBubbleTransition {
  const had = before.trim().length > 0;
  const has = after.trim().length > 0;
  if (!had && has) return 'add';
  if (had && !has) return 'remove';
  return 'none';
}

/**
 * Apply a note-bubble transition to every rendered view of the book,
 * mirroring the overlay calls in Notebook.handleSaveNote.
 */
export function applyNoteBubbleTransition(
  views: FoliateView[],
  note: BookNote,
  transition: NoteBubbleTransition,
): void {
  if (transition === 'none') return;
  for (const view of views) {
    view.addAnnotation({ ...note, value: `${NOTE_PREFIX}${note.cfi}` }, transition === 'remove');
    // The copies of a global annotation carry the bubble too: redraw them.
    if (note.global) {
      removeGlobalAnnotationOverlays(view, note);
      expandAllRenderedSections(view, note);
    }
  }
}
