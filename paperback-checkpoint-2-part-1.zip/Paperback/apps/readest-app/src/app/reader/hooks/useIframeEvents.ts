import { useEffect, useRef } from 'react';
import { useReaderStore } from '@/store/readerStore';
import { useBookDataStore } from '@/store/bookDataStore';
import { eventDispatcher } from '@/utils/event';
import { MAX_ZOOM_LEVEL, MIN_ZOOM_LEVEL } from '@/services/constants';
import { createWheelGestureDetector } from '@/app/reader/utils/wheelGesture';
import {
  beginLayeredTurnTouch,
  cancelLayeredTurnTouch,
  endLayeredTurnTouch,
} from '@/app/reader/utils/iframeEventHandlers';
import { NATIVE_CAPTURED_TURN_ATTRIBUTE } from '@/app/reader/utils/turnGestureArena';
import { getCapturedTurnStyle } from '@/app/reader/hooks/useCapturedTurn';
import {
  dispatchTouchInterceptors,
  isLayeredTurnGestureActive,
  TOUCH_TAP_SLOP_PX,
  TOUCH_SWIPE_THRESHOLD_PX,
  TouchDetail,
} from './useTouchInterceptor';
import { hasVerticalPanning } from './usePagination';

export const useMouseEvent = (
  bookKey: string,
  handlePageFlip: (msg: MessageEvent | React.MouseEvent<HTMLDivElement, MouseEvent>) => void,
) => {
  const { hoveredBookKey } = useReaderStore();
  // Keep the latest handlePageFlip in a ref so the wheel-driven flip path
  // always invokes the most recent closure, independent of when listeners
  // were registered.
  const handlePageFlipRef = useRef(handlePageFlip);
  useEffect(() => {
    handlePageFlipRef.current = handlePageFlip;
  }, [handlePageFlip]);
  // Filters the raw wheel stream so a touch-surface mouse (e.g. Magic Mouse)
  // — which emits a flood of tiny events plus an inertial momentum tail for
  // one physical gesture — flips exactly one page instead of cascading
  // through several. See wheelGesture.ts.
  const wheelDetectorRef = useRef<ReturnType<typeof createWheelGestureDetector> | null>(null);
  if (!wheelDetectorRef.current) {
    wheelDetectorRef.current = createWheelGestureDetector();
  }
  const handleMouseEvent = (msg: MessageEvent | React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    if (msg instanceof MessageEvent) {
      if (msg.data && msg.data.bookKey === bookKey) {
        if (msg.data.type === 'iframe-wheel') {
          if (msg.data.ctrlKey) {
            // Pinch/ctrl-wheel zoom is not a page-turn gesture — drop any
            // travel accumulated so far so it can't bleed into a later flip.
            wheelDetectorRef.current!.reset();
            if (msg.data.deltaY > 0) {
              eventDispatcher.dispatch('zoom-out', { factor: Math.abs(msg.data.deltaY) / 100 });
            } else if (msg.data.deltaY < 0) {
              eventDispatcher.dispatch('zoom-in', { factor: Math.abs(msg.data.deltaY) / 100 });
            }
          } else if (msg.data.nativeScrollY) {
            // The page scrolls within itself (fit-width or zoomed PDF): this
            // gesture belongs to the scroll, and only a fresh one at the edge
            // turns the page.
            wheelDetectorRef.current!.suppress(Date.now());
          } else {
            const flip = wheelDetectorRef.current!.feed({
              deltaX: msg.data.deltaX ?? 0,
              deltaY: msg.data.deltaY ?? 0,
              deltaMode: msg.data.deltaMode ?? 0,
              timeStamp: Date.now(),
            });
            if (flip) {
              handlePageFlipRef.current(
                new MessageEvent('message', {
                  data: { ...msg.data, deltaX: flip.deltaX, deltaY: flip.deltaY },
                }),
              );
            }
          }
        } else {
          handlePageFlip(msg);
        }
      }
    } else if (msg.type !== 'wheel') {
      handlePageFlip(msg);
    }
  };

  useEffect(() => {
    window.addEventListener('message', handleMouseEvent);
    return () => {
      window.removeEventListener('message', handleMouseEvent);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookKey, hoveredBookKey]);

  return {
    onClick: handlePageFlip,
    onWheel: handleMouseEvent,
  };
};

// Opens the image gallery / table zoom viewer when the iframe reports that the
// user tapped an image or table (reflowable books only). See the
// `iframe-open-media` producer in iframeEventHandlers.ts.
export const useOpenMediaEvent = (
  bookKey: string,
  handleImagePress: (src: string) => void,
  handleTablePress: (html: string) => void,
) => {
  const handleOpenMedia = (msg: MessageEvent) => {
    if (msg.data && msg.data.bookKey === bookKey && msg.data.type === 'iframe-open-media') {
      if (msg.data.elementType === 'image') {
        handleImagePress(msg.data.src);
      } else if (msg.data.elementType === 'table') {
        handleTablePress(msg.data.html);
      }
    }
  };

  useEffect(() => {
    window.addEventListener('message', handleOpenMedia);
    return () => {
      window.removeEventListener('message', handleOpenMedia);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookKey]);
};

interface IframeTouch {
  clientX: number;
  clientY: number;
  screenX: number;
  screenY: number;
}

interface IframeTouchEvent {
  timeStamp: number;
  targetTouches: IframeTouch[];
  changedTouches?: IframeTouch[];
}

// A two-finger gesture only becomes a pinch once the fingers' separation
// changes by at least this many pixels AND that change outweighs how far the
// pair has travelled together. On touchscreen laptops (e.g. Surface) users
// scroll with two fingers moving the same direction, which nudges the spacing
// a little; the deadzone keeps that from being read as an accidental zoom.
const PINCH_ACTIVATION_THRESHOLD = 24;
// Once the pair has translated this far together we lock the gesture as a
// two-finger scroll and stop looking for a pinch for the rest of it.
const TWO_FINGER_PAN_THRESHOLD = 12;

export const useTouchEvent = (bookKey: string) => {
  const { getBookData } = useBookDataStore();
  const { hoveredBookKey, setHoveredBookKey, getViewSettings, getView } = useReaderStore();

  const touchStartRef = useRef<IframeTouch | null>(null);
  const touchEndRef = useRef<IframeTouch | null>(null);
  const touchStartTimeRef = useRef<number | null>(null);
  const touchEndTimeRef = useRef<number | null>(null);
  const touchConsumedRef = useRef(false);
  const layeredTurnOwnedRef = useRef(false);
  const layeredTurnCandidateRef = useRef(false);
  // Two fingers on a fixed-layout book start in a "pending" state: we wait to
  // see whether they spread/converge (pinch) or slide together (scroll) before
  // committing. isPinchingRef only flips true once a pinch is confirmed.
  const pinchPendingRef = useRef(false);
  // Reflowable books do not pinch-zoom, but a second finger must still end the
  // single-finger arena. Keep the whole multi-touch sequence latched out until
  // every finger is up so the remaining finger cannot inherit the old start.
  const reflowableMultiTouchRef = useRef(false);

  const isLifecycleManagedLayeredTurn = () => isLayeredTurnGestureActive(bookKey);
  const isLayeredTurnCandidate = () => {
    const viewSettings = getViewSettings(bookKey);
    if (!viewSettings) return false;
    // `fixed-layout.js` animates nothing of its own and ignores `turn-style`,
    // so a fixed-layout book is only a candidate where the Tauri captured
    // pipeline drives its turn — and not while it pans (readest#6239).
    if (getBookData(bookKey)?.isFixedLayout && !getCapturedTurnStyle(viewSettings, true)) {
      return false;
    }
    const renderer = getView(bookKey)?.renderer;
    const turnStyle =
      renderer?.getAttribute?.('turn-style') ??
      renderer?.getAttribute?.(NATIVE_CAPTURED_TURN_ATTRIBUTE);
    return (
      (turnStyle === 'slide' || turnStyle === 'curl' || turnStyle === 'push') &&
      viewSettings.animated &&
      !viewSettings.scrolled &&
      !viewSettings.isEink &&
      !viewSettings.disableSwipe
    );
  };
  const isPinchingRef = useRef(false);
  const initialTouch0Ref = useRef<IframeTouch | null>(null);
  const initialTouch1Ref = useRef<IframeTouch | null>(null);
  const initialPinchDistRef = useRef(0);
  const initialZoomRef = useRef(100);
  const lastPinchRatioRef = useRef(1);

  const getTouchDistance = (t0: IframeTouch, t1: IframeTouch) => {
    // Use screenX/screenY instead of clientX/clientY because pinchZoom
    // applies a CSS transform to the iframe's parent, which changes the
    // iframe's coordinate space and causes clientX/clientY to oscillate
    const dx = t1.screenX - t0.screenX;
    const dy = t1.screenY - t0.screenY;
    return Math.sqrt(dx * dx + dy * dy);
  };

  const buildTouchDetail = (
    phase: TouchDetail['phase'],
    touch: IframeTouch,
    touchStart: IframeTouch,
    startTime: number | null,
    endTime: number | null,
  ): TouchDetail => ({
    phase,
    touch: { screenX: touch.screenX, screenY: touch.screenY },
    touchStart: { screenX: touchStart.screenX, screenY: touchStart.screenY },
    deltaX: touch.screenX - touchStart.screenX,
    deltaY: touch.screenY - touchStart.screenY,
    deltaT: endTime !== null && startTime !== null ? endTime - startTime : 0,
  });

  const clearSingleTouchState = () => {
    touchStartRef.current = null;
    touchEndRef.current = null;
    touchStartTimeRef.current = null;
    touchEndTimeRef.current = null;
    touchConsumedRef.current = false;
    layeredTurnOwnedRef.current = false;
    layeredTurnCandidateRef.current = false;
  };

  const preventDirectTouchDefault = (e: IframeTouchEvent | React.TouchEvent<HTMLDivElement>) => {
    // Forwarded iframe messages are plain data. React events originate on the
    // paginator's parent surface (header/footer/margins) and must explicitly
    // suppress the compatibility click once a layered turn owns the touch.
    if ('preventDefault' in e) e.preventDefault();
  };

  // A native captured turn has already claimed only when its move was consumed.
  // Cancel it exactly once before a second finger discards the single-finger
  // baseline; unclaimed starts need no synthetic lifecycle event.
  const cancelClaimedSingleTouch = (
    e: IframeTouchEvent | React.TouchEvent<HTMLDivElement>,
    fallbackTouch: IframeTouch,
  ) => {
    const touchStart = touchStartRef.current;
    if (!touchConsumedRef.current || !touchStart) return;
    const touch = touchEndRef.current ?? fallbackTouch;
    const endTime = 'timeStamp' in e ? e.timeStamp : Date.now();
    dispatchTouchInterceptors(
      bookKey,
      buildTouchDetail('cancel', touch, touchStart, touchStartTimeRef.current, endTime),
    );
  };

  const latchReflowableMultiTouch = (
    e: IframeTouchEvent | React.TouchEvent<HTMLDivElement>,
    t0: IframeTouch | undefined,
    t1: IframeTouch | undefined,
  ) => {
    if (!t0 || !t1 || getBookData(bookKey)?.isFixedLayout) return false;
    cancelLayeredTurnTouch(bookKey);
    if (!reflowableMultiTouchRef.current) {
      reflowableMultiTouchRef.current = true;
      cancelClaimedSingleTouch(e, t0);
    }
    clearSingleTouchState();
    return true;
  };

  const onTouchStart = (e: IframeTouchEvent | React.TouchEvent<HTMLDivElement>) => {
    layeredTurnOwnedRef.current = false;
    layeredTurnCandidateRef.current = false;
    const t0 = e.targetTouches[0] as IframeTouch | undefined;
    const t1 = e.targetTouches[1] as IframeTouch | undefined;
    if (reflowableMultiTouchRef.current) {
      cancelLayeredTurnTouch(bookKey);
      return;
    }
    // iframeEventHandlers owns the lifecycle for forwarded iframe messages.
    // Starting it again after postMessage delivery could erase a claim made by
    // a raw move that arrived while the start message was still queued.
    if ('preventDefault' in e) beginLayeredTurnTouch(bookKey);
    if (t0 && t1) {
      const bookData = getBookData(bookKey);
      if (bookData?.isFixedLayout) {
        cancelLayeredTurnTouch(bookKey);
        // The pinch branch owns the gesture from here. A captured curl the
        // first finger already claimed would otherwise sit frozen over the
        // page until the next touchstart (readest#6239).
        cancelClaimedSingleTouch(e, t0);
        pinchPendingRef.current = true;
        isPinchingRef.current = false;
        initialTouch0Ref.current = t0;
        initialTouch1Ref.current = t1;
        initialPinchDistRef.current = getTouchDistance(t0, t1);
        initialZoomRef.current = getViewSettings(bookKey)?.zoomLevel ?? 100;
        lastPinchRatioRef.current = 1;
        clearSingleTouchState();
        return;
      }
      latchReflowableMultiTouch(e, t0, t1);
      return;
    }
    if (!t0) {
      cancelLayeredTurnTouch(bookKey);
      return;
    }
    layeredTurnCandidateRef.current = isLayeredTurnCandidate();
    touchStartRef.current = t0;
    touchStartTimeRef.current = 'timeStamp' in e ? e.timeStamp : Date.now();
    touchConsumedRef.current = false;
    const detail = buildTouchDetail(
      'start',
      t0,
      t0,
      touchStartTimeRef.current,
      touchStartTimeRef.current,
    );
    dispatchTouchInterceptors(bookKey, detail);
  };

  const onTouchMove = (e: IframeTouchEvent | React.TouchEvent<HTMLDivElement>) => {
    const t0 = e.targetTouches[0] as IframeTouch | undefined;
    const t1 = e.targetTouches[1] as IframeTouch | undefined;
    if (reflowableMultiTouchRef.current || latchReflowableMultiTouch(e, t0, t1)) return;
    if ((pinchPendingRef.current || isPinchingRef.current) && t0 && t1) {
      if (pinchPendingRef.current) {
        const init0 = initialTouch0Ref.current;
        const init1 = initialTouch1Ref.current;
        if (!init0 || !init1) return;
        const currentDist = getTouchDistance(t0, t1);
        const separationDelta = Math.abs(currentDist - initialPinchDistRef.current);
        // How far the finger pair has slid together (midpoint travel). A pinch
        // keeps the midpoint roughly still while the separation changes; a
        // two-finger scroll moves the midpoint while the separation barely
        // shifts.
        const panX = (t0.screenX - init0.screenX + (t1.screenX - init1.screenX)) / 2;
        const panY = (t0.screenY - init0.screenY + (t1.screenY - init1.screenY)) / 2;
        const panDist = Math.sqrt(panX * panX + panY * panY);
        if (separationDelta >= PINCH_ACTIVATION_THRESHOLD && separationDelta > panDist) {
          // Confirmed pinch. Re-baseline the distance so the zoom starts at 1x
          // from here — the deadzone travel is absorbed rather than snapping.
          pinchPendingRef.current = false;
          isPinchingRef.current = true;
          initialPinchDistRef.current = currentDist;
        } else if (panDist >= TWO_FINGER_PAN_THRESHOLD && panDist >= separationDelta) {
          // Two-finger scroll — bow out and let the page scroll natively.
          pinchPendingRef.current = false;
          return;
        } else {
          return; // not enough movement to decide yet
        }
      }
      const currentDist = getTouchDistance(t0, t1);
      if (initialPinchDistRef.current > 0) {
        const ratio = currentDist / initialPinchDistRef.current;
        lastPinchRatioRef.current = ratio;
        const renderer = getView(bookKey)?.renderer;
        renderer?.pinchZoom?.(ratio);
      }
      return;
    }
    if (!touchStartRef.current) return;
    const touch = t0;
    if (touch) {
      touchEndRef.current = touch;
      touchEndTimeRef.current = 'timeStamp' in e ? e.timeStamp : Date.now();
      const detail = buildTouchDetail(
        'move',
        touch,
        touchStartRef.current,
        touchStartTimeRef.current,
        touchEndTimeRef.current,
      );
      if (dispatchTouchInterceptors(bookKey, detail)) {
        touchConsumedRef.current = true;
        preventDirectTouchDefault(e);
        return;
      }
    }
    if (touchConsumedRef.current) return;
    // Layered turns own toolbar synchronization through their
    // snapshot lifecycle. A second store update here would start the normal
    // fade while the View Transition snapshot is being composed.
    if (isLifecycleManagedLayeredTurn()) layeredTurnOwnedRef.current = true;
    if (layeredTurnOwnedRef.current) return;
    const { current: touchStart } = touchStartRef;
    const { current: touchEnd } = touchEndRef;
    if (layeredTurnCandidateRef.current && touchEnd) {
      const deltaX = touchEnd.screenX - touchStart.screenX;
      const deltaY = touchEnd.screenY - touchStart.screenY;
      // The paginator's direction-aware arena may still claim this gesture.
      // Do not hide the toolbar while ownership is pending: if it claims later,
      // its snapshot lifecycle takes over; otherwise touchend runs the generic
      // behavior.
      if (Math.abs(deltaX) > Math.abs(deltaY)) return;
    }
    if (hoveredBookKey && touchEnd) {
      const viewSettings = getViewSettings(bookKey)!;
      const deltaY = touchEnd.screenY - touchStart.screenY;
      const deltaX = touchEnd.screenX - touchStart.screenX;
      if (Math.hypot(deltaX, deltaY) < TOUCH_TAP_SLOP_PX) return;
      // Paginated books turn pages with horizontal swipes in every writing mode
      // (vertical ones included, readest#624), so only that hides the bars; a
      // vertical swipe is left to the swipe-up toggle on touchend.
      if (!viewSettings!.scrolled) {
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) >= TOUCH_SWIPE_THRESHOLD_PX) {
          setHoveredBookKey(null);
        }
      } else {
        setHoveredBookKey(null);
      }
    }
  };

  const onTouchEnd = (e: IframeTouchEvent | React.TouchEvent<HTMLDivElement>) => {
    layeredTurnCandidateRef.current = false;
    if (reflowableMultiTouchRef.current) {
      if (e.targetTouches.length === 0) {
        reflowableMultiTouchRef.current = false;
        cancelLayeredTurnTouch(bookKey);
        clearSingleTouchState();
      }
      return;
    }
    if (isPinchingRef.current || pinchPendingRef.current) {
      const t0 = e.targetTouches[0] as IframeTouch | undefined;
      const t1 = e.targetTouches[1] as IframeTouch | undefined;
      if (t0 && t1) return; // still two fingers down
      const wasPinching = isPinchingRef.current;
      isPinchingRef.current = false;
      pinchPendingRef.current = false;
      initialTouch0Ref.current = null;
      initialTouch1Ref.current = null;
      // Only commit a zoom if a pinch was actually confirmed. A gesture that
      // stayed pending (jitter) or resolved to a scroll leaves zoom untouched.
      const renderer = getView(bookKey)?.renderer;
      if (wasPinching && renderer && initialPinchDistRef.current > 0) {
        renderer.pinchEnd?.();
        const newZoom = Math.round(initialZoomRef.current * lastPinchRatioRef.current);
        const clampedZoom = Math.max(MIN_ZOOM_LEVEL, Math.min(MAX_ZOOM_LEVEL, newZoom));
        eventDispatcher.dispatch('pinch-zoom', { zoomLevel: clampedZoom });
      }
      touchStartRef.current = null;
      touchEndRef.current = null;
      layeredTurnOwnedRef.current = false;
      cancelLayeredTurnTouch(bookKey);
      return;
    }
    if (e.targetTouches.length === 0) endLayeredTurnTouch(bookKey);
    if (!touchStartRef.current) {
      layeredTurnOwnedRef.current = false;
      return;
    }

    // A single-finger touchend has no active targetTouches. changedTouches
    // carries the actual release point; using the last move instead made fast
    // and slow curls commit differently and under-reported the gesture time.
    const touch = e.changedTouches?.[0] ?? e.targetTouches[0];
    if (touch) {
      touchEndRef.current = touch;
    }
    touchEndTimeRef.current = 'timeStamp' in e ? e.timeStamp : Date.now();

    const { current: touchStart } = touchStartRef;
    const { current: touchEnd } = touchEndRef;

    // Dispatch end to interceptors, then check if the gesture was consumed
    let endConsumed = false;
    if (touchEnd && touchStart) {
      const detail = buildTouchDetail(
        'end',
        touchEnd,
        touchStart,
        touchStartTimeRef.current,
        touchEndTimeRef.current,
      );
      endConsumed = dispatchTouchInterceptors(bookKey, detail);
    }

    if (touchConsumedRef.current || endConsumed) {
      preventDirectTouchDefault(e);
      touchConsumedRef.current = false;
      touchStartRef.current = null;
      touchEndRef.current = null;
      layeredTurnOwnedRef.current = false;
      return;
    }

    if (layeredTurnOwnedRef.current) {
      preventDirectTouchDefault(e);
      touchStartRef.current = null;
      touchEndRef.current = null;
      layeredTurnOwnedRef.current = false;
      return;
    }

    if (touchEnd && touchStart && isLifecycleManagedLayeredTurn()) {
      const deltaX = touchEnd.screenX - touchStart.screenX;
      const deltaY = touchEnd.screenY - touchStart.screenY;
      if (Math.abs(deltaX) >= TOUCH_SWIPE_THRESHOLD_PX && Math.abs(deltaX) > Math.abs(deltaY)) {
        touchStartRef.current = null;
        touchEndRef.current = null;
        layeredTurnOwnedRef.current = false;
        return;
      }
    }

    if (touchEnd && touchStart) {
      const deltaX = touchEnd.screenX - touchStart.screenX;
      const deltaY = touchEnd.screenY - touchStart.screenY;
      if (Math.hypot(deltaX, deltaY) < TOUCH_TAP_SLOP_PX) {
        // A clean tap is handled once by iframe-single-click. Mutating the
        // toolbar here as well makes the touchend hide it and the following
        // synthesized click immediately show it again (or vice versa).
        touchConsumedRef.current = false;
        touchStartRef.current = null;
        touchEndRef.current = null;
        layeredTurnOwnedRef.current = false;
        return;
      }
    }

    // Gesture was not consumed — handle hover bar toggle
    if (touchEnd && touchStart) {
      const windowWidth = window.innerWidth;
      const deltaY = touchEnd.screenY - touchStart.screenY;
      const deltaX = touchEnd.screenX - touchStart.screenX;
      if (
        deltaY < -10 &&
        Math.abs(deltaY) > Math.abs(deltaX) * 2 &&
        Math.abs(deltaX) < windowWidth * 0.3
      ) {
        const viewSettings = getViewSettings(bookKey)!;
        const bookData = getBookData(bookKey)!;
        // On a fixed-layout page that can pan vertically (e.g. fit-width in
        // landscape overflows vertically even at 100% zoom) an upward swipe
        // is a pan, not a toggle-the-bars gesture (#5142).
        if (
          !viewSettings!.scrolled &&
          (!bookData.isFixedLayout || !hasVerticalPanning(getView(bookKey), viewSettings))
        ) {
          setHoveredBookKey(hoveredBookKey ? null : bookKey);
        }
      } else {
        if (hoveredBookKey) {
          setHoveredBookKey(null);
        }
      }
    }

    touchConsumedRef.current = false;
    touchStartRef.current = null;
    touchEndRef.current = null;
    layeredTurnOwnedRef.current = false;
  };

  const onTouchCancel = (e: IframeTouchEvent | React.TouchEvent<HTMLDivElement>) => {
    layeredTurnCandidateRef.current = false;
    const preventCompatibilityClick = touchConsumedRef.current || layeredTurnOwnedRef.current;
    cancelLayeredTurnTouch(bookKey);
    if (preventCompatibilityClick) preventDirectTouchDefault(e);
    if (reflowableMultiTouchRef.current) {
      if (e.targetTouches.length === 0) reflowableMultiTouchRef.current = false;
      clearSingleTouchState();
      return;
    }
    if (isPinchingRef.current || pinchPendingRef.current) {
      getView(bookKey)?.renderer.pinchEnd?.();
      isPinchingRef.current = false;
      pinchPendingRef.current = false;
      initialTouch0Ref.current = null;
      initialTouch1Ref.current = null;
    }

    const touchStart = touchStartRef.current;
    const touch =
      (e.changedTouches?.[0] as IframeTouch | undefined) ??
      (e.targetTouches[0] as IframeTouch | undefined) ??
      touchEndRef.current ??
      touchStart;
    const endTime = 'timeStamp' in e ? e.timeStamp : Date.now();
    if (touchStart && touch) {
      dispatchTouchInterceptors(
        bookKey,
        buildTouchDetail('cancel', touch, touchStart, touchStartTimeRef.current, endTime),
      );
    }

    touchConsumedRef.current = false;
    touchStartRef.current = null;
    touchEndRef.current = null;
    touchStartTimeRef.current = null;
    touchEndTimeRef.current = null;
    layeredTurnOwnedRef.current = false;
  };

  const handleTouch = (msg: MessageEvent) => {
    if (msg.data && msg.data.bookKey === bookKey) {
      if (msg.data.type === 'iframe-touchstart') {
        onTouchStart(msg.data);
      } else if (msg.data.type === 'iframe-touchmove') {
        onTouchMove(msg.data);
      } else if (msg.data.type === 'iframe-touchend') {
        onTouchEnd(msg.data);
      } else if (msg.data.type === 'iframe-touchcancel') {
        onTouchCancel(msg.data);
      }
    }
  };

  useEffect(() => {
    window.addEventListener('message', handleTouch);
    return () => {
      window.removeEventListener('message', handleTouch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hoveredBookKey]);

  return {
    onTouchStart,
    onTouchMove,
    onTouchEnd,
    onTouchCancel,
  };
};
