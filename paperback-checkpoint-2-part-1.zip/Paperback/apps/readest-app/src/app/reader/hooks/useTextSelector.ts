import { useEffect, useRef } from 'react';
import { BookNote } from '@/types/book';
import { Insets } from '@/types/misc';
import { useEnv } from '@/context/EnvContext';
import { useReaderStore } from '@/store/readerStore';
import { useBookDataStore } from '@/store/bookDataStore';
import { getOSPlatform } from '@/utils/misc';
import { eventDispatcher } from '@/utils/event';
import { LONG_HOLD_THRESHOLD } from '@/services/constants';
import { setSelectionSuppressed } from '@/utils/bridge';
import { LINK_TOUCH_HOLD_CLASS, TEXT_SELECTED_CLASS } from '@/utils/style';
import {
  focusCaretWindowPos,
  getCaretPointFromPoint,
  getWordRangeFromPoint,
  isHyphenHandleBugProneRange,
  isPointerInsideSelection,
  Point,
  rangeFromAnchorToPoint,
  repairJumpedSelectionRange,
  TextSelection,
  trimRangeWhitespaceAroundPoint,
} from '@/utils/sel';
import { Corner, useAutoPageTurn } from './useAutoPageTurn';
import { useInstantAnnotation } from './useInstantAnnotation';
import {
  applyCrossDocSegments,
  buildCrossDocSegments,
  CrossDocSegment,
  findContentAtPoint,
  getCaretPosition,
  getCaretPositionInText,
  isTextAtPoint,
  rangeBetweenPositions,
  rangeFromPositions,
  SectionAnchor,
  SelectionBounds,
  setNativeDragFrozen,
  toDocPoint,
} from '../utils/crossDocSelection';
import { toParentViewportPoint } from '../utils/annotatorUtil';
import { getContextMenuImage } from '../utils/iframeEventHandlers';

// Instant-highlight quick action: on touch a plain tap and a swipe are both
// page-turn gestures, so the highlight must not engage on pointer-down or it
// swallows the tap/swipe (an Android tap-to-paginate regression). It only engages
// after the finger has held still on the text for this long; a tap releases first
// and a swipe moves first, so both fall through to pagination. Mouse input is not
// gated — a click vs. a press-drag is already unambiguous.
const INSTANT_HOLD_MS = 300;
// Movement past this many CSS px during the hold means the user is swiping, not
// settling in to highlight, so the pending engagement is cancelled.
const INSTANT_HOLD_MOVE_PX = 10;
// How far a pointer must travel before it counts as dragging a selection rather
// than resting on it. A long press drifts a pixel or two, and taking that drift
// for a drag let the long-press selection arm the corner turn by itself.
const SELECTION_DRAG_SLOP_PX = 10;
// Ignore tiny pointer jitter, but preserve a deliberate double-click-drag even
// when it only extends the selection into adjacent whitespace.
const DOUBLE_CLICK_DRAG_MOVE_PX = 3;

export const useTextSelector = (
  bookKey: string,
  contentInsets: Insets,
  setSelection: React.Dispatch<React.SetStateAction<TextSelection | null>>,
  setEditingAnnotation: React.Dispatch<React.SetStateAction<BookNote | null>>,
  setExternalDragPoint: React.Dispatch<React.SetStateAction<Point | null>>,
  getAnnotationText: (range: Range) => Promise<string>,
  handleDismissPopup: () => void,
) => {
  const { appService } = useEnv();
  const { getBookData } = useBookDataStore();
  const { getView, getViewSettings, getProgress } = useReaderStore();
  const view = getView(bookKey);
  const bookData = getBookData(bookKey);
  const osPlatform = getOSPlatform();

  // Corner-dwell auto page-turn (#1354), now driven by every selection gesture
  // through a shared engagement point — see useAutoPageTurn.
  const {
    isAutoTurning,
    turnHint,
    cornerAtPoint,
    noteCorner,
    noteAutoTurnPoint,
    cancel: cancelAutoTurn,
    onAfterTurn,
  } = useAutoPageTurn(bookKey, contentInsets);

  const isPopuped = useRef(false);
  const isUpToPopup = useRef(false);
  const isTextSelected = useRef(false);
  const isTouchStarted = useRef(false);
  // A touch selectionchange deferred until the gesture ends: iOS streams
  // selectionchange while a finger drags the system selection handles, and
  // the Annotator hides the popup on every touchmove — re-showing it per
  // change made the annotation toolbar flash. Processed in handleTouchEnd.
  const pendingTouchSelection = useRef(false);
  const selectionPosition = useRef<number | null>(null);
  const lastPointerType = useRef<string>('mouse');
  // Whether a pointer drag (mouse/touch selection) is currently in progress.
  // Desktop selections defer to pointerup, but a keyboard selection adjustment
  // (#4728) has no pointer drag — handleSelectionchange uses this to refresh the
  // popup/range for keyboard-driven changes while still deferring mid-drag.
  const isPointerDown = useRef(false);
  // Tracked from the moves themselves rather than from pointerdown, because a
  // WebKit selection handle drag delivers moves without a matching down.
  const pointerDragActive = useRef(false);
  const selectionDragging = useRef(false);
  // Where this gesture's pointer travel is measured from — the first move of the
  // gesture, for the same reason.
  const dragOriginRef = useRef<Point | null>(null);
  const isInstantAnnotating = useRef(false);
  const isInstantAnnotated = useRef(false);
  const annotationStartPoint = useRef<Point | null>(null);
  // The element instant annotating set `user-select: none` on, so the exact same
  // element is restored on release (the pointerup target may differ once the
  // finger has moved across nodes).
  const instantAnnotationTarget = useRef<HTMLElement | null>(null);
  // Cleanup for the listeners an instant-annotating gesture holds: the
  // after-turn re-emit (a corner auto-turn rebuilds the preview from the held
  // position onto the new page) and the release outside every page.
  const instantGestureCleanup = useRef<(() => void) | null>(null);
  // Pending instant-highlight still-hold (touch/pen). While a hold is in flight
  // these remember the press so the timer can engage at the same spot; the gate
  // is armed in handlePointerDown and dropped by a release or a swipe.
  const instantHoldTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const instantHoldTarget = useRef<HTMLElement | null>(null);
  const instantHoldStartClient = useRef<Point | null>(null);
  const instantHoldStartWindow = useRef<{ x: number; y: number } | null>(null);
  // Pending image long press on iOS (#6574): where the touch went down and the
  // timer that opens the image menu if it stays there.
  const imageHold = useRef<{ timer: ReturnType<typeof setTimeout>; x: number; y: number } | null>(
    null,
  );
  // Latest pointer position in window coords (from pointermove or, on Android,
  // native touchmove): an auto-turn engagement signal alongside the caret, and
  // the finger position the Android hyphen repair rebuilds from.
  const pointerPos = useRef<{ x: number; y: number } | null>(null);
  const mouseDoubleClickRef = useRef<{ x: number; y: number; moved: boolean } | null>(null);

  // Android hyphen selection-bounds bug (#1553): the selection anchor captured
  // at the first selectionchange of a touch gesture, plus whether that initial
  // range is prone to the bug (starts at the first word of a hyphenated
  // paragraph). Evaluated once per gesture.
  const gestureInitialRef = useRef<{ node: Node; offset: number; prone: boolean } | null>(null);
  // While we mutate the DOM selection ourselves (handle suppression, custom
  // handle drags), selectionchange events are echoes of our own writes —
  // handleSelectionchange must ignore them. Cleared on a delay because
  // selectionchange dispatches a task after the mutation.
  const programmaticSelectionRef = useRef(false);
  const programmaticClearTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Cross-page selection (#5809). Fixed-layout pages are separate iframes, so a
  // selection dragged onto the next page is kept as one native selection per
  // page and published as a single TextSelection with `segments`.
  // The DOM-anchored start of a mouse selection drag, captured at pointer-down.
  const dragAnchorRef = useRef<SectionAnchor | null>(null);
  // Live state while the pointer/finger is over a page other than the anchor's.
  // `frozen`: the anchor page's native drag has been frozen (mouse path).
  const crossDocRef = useRef<{
    anchor: SectionAnchor;
    segments: CrossDocSegment[];
    frozen: boolean;
  } | null>(null);

  // #5427: whether the native layer is currently refusing the system
  // selection toolbar (MainActivity hands out a no-op ActionMode while set).
  const selectionMenuSuppressedRef = useRef(false);

  // Chromium can (re)show the floating selection ActionMode through paths
  // that never fire a cancelable contextmenu event (handle-drag release,
  // window focus regain, TextClassifier callbacks), so handleContextmenu's
  // preventDefault alone cannot keep it off Readest's own toolbar. Keep the
  // native gate set exactly while reader text is selected — with no reader
  // selection the flag is off, so system Cut/Copy/Paste menus in editable
  // fields keep working.
  const syncSelectionMenuSuppression = (suppressed: boolean) => {
    if (selectionMenuSuppressedRef.current === suppressed) return;
    selectionMenuSuppressedRef.current = suppressed;
    setSelectionSuppressed({ target: 'menu', suppressed }).catch(() => {});
  };

  const guardProgrammaticSelection = () => {
    if (programmaticClearTimer.current) clearTimeout(programmaticClearTimer.current);
    programmaticSelectionRef.current = true;
  };

  const releaseProgrammaticSelection = () => {
    if (programmaticClearTimer.current) clearTimeout(programmaticClearTimer.current);
    programmaticClearTimer.current = setTimeout(() => {
      programmaticSelectionRef.current = false;
    }, 150);
  };

  const getContents = () => getView(bookKey)?.renderer?.getContents?.() ?? [];

  // The cross-page selection (#5809) exists only for fixed-layout pages in
  // scroll mode, where the next page is on screen to continue onto. Reflowable
  // books and paginated fixed layout keep the single-document behaviour.
  const crossPageEnabled = () => !!bookData?.isFixedLayout && !!getViewSettings(bookKey)?.scrolled;

  // Extend the selection anchored at `anchor` to the page under `point`
  // (window coords): the anchor page to its edge, pages between in full, the
  // target page up to the caret under the point. Returns whether a cross-page
  // state is active afterwards; over the anchor page itself the state is left
  // (the native drag takes over again).
  const extendCrossDocTo = (anchor: SectionAnchor, point: Point): boolean => {
    const contents = getContents();
    const target = findContentAtPoint(contents, point);
    if (!target) return !!crossDocRef.current;
    if (target.doc === anchor.doc) {
      clearCrossDoc();
      return false;
    }
    const local = toDocPoint(target.doc, point);
    const caret = local && getCaretPositionInText(target.doc, local.x, local.y);
    if (!caret) return !!crossDocRef.current;
    const segments = buildCrossDocSegments(anchor, { ...target, pos: caret }, contents);
    if (segments.length === 0) return !!crossDocRef.current;
    // Our own writes: their selectionchange echoes are not user input.
    guardProgrammaticSelection();
    applyCrossDocSegments(segments, contents, anchor);
    crossDocRef.current = { anchor, segments, frozen: crossDocRef.current?.frozen ?? false };
    return true;
  };

  // Leave the cross-page state. Unless `keepSelections` (committing), the
  // other pages' parts are cleared so only the anchor page's selection remains.
  const clearCrossDoc = (keepSelections = false) => {
    const state = crossDocRef.current;
    if (!state) return;
    crossDocRef.current = null;
    if (state.frozen) setNativeDragFrozen(state.anchor.doc, false);
    if (!keepSelections) {
      for (const { doc } of state.segments) {
        if (doc !== state.anchor.doc) doc.getSelection()?.removeAllRanges();
      }
    }
    releaseProgrammaticSelection();
  };

  // Publish the per-page parts as one selection: all their text joined, the
  // range/cfi/index anchored on the first part (#5809).
  const makeCrossDocSelection = async (segments: CrossDocSegment[], handlesSuppressed = false) => {
    const parts: { range: Range; index: number; text: string }[] = [];
    for (const segment of segments) {
      const range = rangeFromPositions(segment.doc, segment.start, segment.end);
      if (!range) continue;
      const text = await getAnnotationText(range);
      if (!text.trim()) continue;
      parts.push({ range, index: segment.index, text });
    }
    const first = parts[0];
    if (!first) return false;
    isTextSelected.current = true;
    const progress = getProgress(bookKey);
    setSelection({
      key: bookKey,
      text: parts.map((part) => part.text).join(' '),
      cfi: view?.getCFI(first.index, first.range),
      page: bookData?.isFixedLayout ? first.index + 1 : progress?.page || 0,
      range: first.range,
      index: first.index,
      segments: parts.length > 1 ? parts : undefined,
      handlesSuppressed,
    });
    return true;
  };

  // Drive a selection from the app's own handles (SelectionRangeEditor): the
  // dragged end follows `point` (window coords) while `anchor` stays put. Over
  // the anchor's page the selection is rebuilt there; over another page it
  // continues across pages (#5809). Resolves to the selection's new outer
  // bounds, or null when the point is over no page.
  const dragSelectionTo = async (
    anchor: SectionAnchor,
    point: Point,
    commit: boolean,
  ): Promise<SelectionBounds | null> => {
    const rangeBounds = (doc: Document, index: number, range: Range): SelectionBounds => ({
      start: { doc, index, pos: { node: range.startContainer, offset: range.startOffset } },
      end: { doc, index, pos: { node: range.endContainer, offset: range.endOffset } },
    });
    const segmentBounds = (segments: CrossDocSegment[]): SelectionBounds | null => {
      const first = segments[0];
      const last = segments.at(-1);
      if (!first || !last) return null;
      return {
        start: { doc: first.doc, index: first.index, pos: first.start },
        end: { doc: last.doc, index: last.index, pos: last.end },
      };
    };
    // A release that resolves to no new range (off any page, or collapsed on the
    // anchor) still commits what the drag has built so far.
    const commitLive = async (): Promise<SelectionBounds | null> => {
      const segments = crossDocRef.current?.segments ?? [];
      if (segments.length > 0) {
        clearCrossDoc(true);
        await makeCrossDocSelection(segments, true);
        return segmentBounds(segments);
      }
      // The drag's writes held the programmatic guard; the drag is over, so let
      // later selectionchange events through again.
      releaseProgrammaticSelection();
      const sel = anchor.doc.getSelection();
      if (!sel || !isValidSelection(sel)) return null;
      await makeSelection(sel, anchor.index, false, true);
      return rangeBounds(anchor.doc, anchor.index, sel.getRangeAt(0));
    };

    if (!crossPageEnabled()) {
      // Single-document drag (reflowable books, paginated fixed layout): the
      // range runs from the anchor to the caret under the point in the anchor's
      // own document, exactly as the handles always worked.
      const feRect = anchor.doc.defaultView?.frameElement?.getBoundingClientRect();
      const range = rangeFromAnchorToPoint(
        anchor.doc,
        anchor.pos.node,
        anchor.pos.offset,
        point.x - (feRect?.left ?? 0),
        point.y - (feRect?.top ?? 0),
      );
      if (!range) return commit ? commitLive() : null;
      await applyProgrammaticSelection(range, anchor.index, commit);
      return rangeBounds(anchor.doc, anchor.index, range);
    }
    const target = findContentAtPoint(getContents(), point);
    if (!target) return commit ? commitLive() : null;
    if (target.doc === anchor.doc) {
      clearCrossDoc();
      const local = toDocPoint(anchor.doc, point);
      const caret = local && getCaretPositionInText(anchor.doc, local.x, local.y);
      const range = caret && rangeBetweenPositions(anchor.doc, anchor.pos, caret);
      if (!range) return commit ? commitLive() : null;
      await applyProgrammaticSelection(range, anchor.index, commit);
      return rangeBounds(anchor.doc, anchor.index, range);
    }
    if (!extendCrossDocTo(anchor, point)) return commit ? commitLive() : null;
    const segments = crossDocRef.current?.segments ?? [];
    if (commit) {
      clearCrossDoc(true);
      await makeCrossDocSelection(segments, true);
    }
    return segmentBounds(segments);
  };

  // Android, fixed-layout pages in scroll mode (#5809): the native selection
  // handles can't leave their page iframe (their touches never reach the page),
  // so once a touch gesture has made a selection swap them for the app's own
  // handles, which drag across pages. A selection that goes empty for one
  // painted frame drops its native handles; `handlesSuppressed` then brings up
  // the SelectionRangeEditor.
  const suppressNativeHandlesForPages = async () => {
    if (sanitizedGestureRef.current || !gestureInitialRef.current) return;
    if (!crossPageEnabled()) return;
    const content = getContents().find(
      (c) => c.doc && c.index != null && isValidSelection(c.doc.getSelection()!),
    );
    if (!content || content.index == null) return;
    const { doc, index } = content;
    const win = doc.defaultView;
    const sel = doc.getSelection();
    if (!win || !sel) return;
    sanitizedGestureRef.current = true;
    const range = sel.getRangeAt(0).cloneRange();
    guardProgrammaticSelection();
    sel.removeAllRanges();
    await new Promise<void>((resolve) =>
      win.requestAnimationFrame(() => win.requestAnimationFrame(() => resolve())),
    );
    // Bail if a competing gesture touched the selection while we waited.
    if (sel.rangeCount > 0 || range.collapsed) {
      releaseProgrammaticSelection();
      return;
    }
    sel.addRange(range);
    releaseProgrammaticSelection();
    await makeSelection(sel, index, false, true);
  };

  // A lookup popup opening over a live selection can never stack above the
  // platform's own selection grabbers: iOS draws them (and the callout bar) as
  // UIKit views over the whole web layer, so they are outside the DOM and no
  // z-index reaches them. #5213 rules out just deselecting — the selection has
  // to survive the lookup so its dismiss lands back on the toolbar — so take
  // the grabbers away instead and leave the selection.
  //
  // Same trick as suppressNativeHandlesForPages: a selection that goes empty
  // for one painted frame drops its native handles, and re-adding the range
  // programmatically doesn't bring them back (the engine only draws them for a
  // user-initiated selection). `handlesSuppressed` then hands the job to the
  // app's own handles, which do stack below the popup.
  const suppressNativeSelectionHandles = async () => {
    // Desktop has no grabbers to take away, and the dance would only churn the
    // selection the popup is anchored to.
    if (!appService?.isMobile) return;
    const content = getContents().find(
      (c) => c.doc && c.index != null && isValidSelection(c.doc.getSelection()!),
    );
    if (!content) return;
    const doc = content.doc;
    const win = doc.defaultView;
    const sel = doc.getSelection();
    if (!win || !sel) return;
    const range = sel.getRangeAt(0).cloneRange();
    guardProgrammaticSelection();
    sel.removeAllRanges();
    await new Promise<void>((resolve) =>
      win.requestAnimationFrame(() => win.requestAnimationFrame(() => resolve())),
    );
    // Bail if a competing gesture touched the selection while we waited: the
    // range we cloned is no longer the one on screen.
    if (sel.rangeCount > 0 || range.collapsed) {
      releaseProgrammaticSelection();
      return;
    }
    sel.addRange(range);
    releaseProgrammaticSelection();
    setSelection((prev) => (prev ? { ...prev, handlesSuppressed: true } : prev));
  };

  // Put back a selection the app dropped itself (#6213). The instant dictionary
  // quick action deselects as it opens so no platform selection UI paints over
  // the popup; when the lookup closes the word has to be selectable again, or
  // there is no route left to highlighting or copying it (re-selecting with a
  // quick action armed just opens the dictionary again).
  //
  // The re-add is programmatic, so the native grabbers stay away — the engine
  // only draws them for a user-initiated selection — and the selectionchange
  // echo is ignored. The published TextSelection is deliberately left untouched:
  // a new object there would read as a fresh selection in the Annotator and run
  // the quick action a second time.
  const restoreSelectionRange = (range: Range) => {
    const doc = range.startContainer.ownerDocument;
    const sel = doc?.getSelection();
    if (!sel || range.collapsed) return false;
    guardProgrammaticSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    releaseProgrammaticSelection();
    if (sel.rangeCount === 0) return false;
    isTextSelected.current = true;
    return true;
  };

  const {
    isInstantAnnotationEnabled,
    handleInstantAnnotationPointerDown,
    handleInstantAnnotationEngage,
    handleInstantAnnotationPointerMove,
    handleInstantAnnotationPointerCancel,
    handleInstantAnnotationPointerUp,
    reapplyInstantAnnotation,
  } = useInstantAnnotation({
    bookKey,
    getAnnotationText,
    setSelection,
    setEditingAnnotation,
    setExternalDragPoint,
  });

  const isValidSelection = (sel: Selection) => {
    return sel && sel.toString().trim().length > 0 && sel.rangeCount > 0;
  };

  const makeSelection = async (
    sel: Selection,
    index: number,
    rebuildRange = false,
    handlesSuppressed = false,
    trimPoint?: { node: Node; offset: number } | null,
  ) => {
    isTextSelected.current = true;
    const liveRange = sel.getRangeAt(0);
    if (rebuildRange) {
      sel.removeAllRanges();
      sel.addRange(liveRange);
    }
    // One page holds the live selection: drop a stale one left on another page
    // (the far part of an earlier cross-page selection), guarded so its
    // selectionchange doesn't dismiss the popup this selection is opening.
    const ownerDoc = liveRange.startContainer?.ownerDocument;
    const stale = crossPageEnabled()
      ? getContents().filter((c) => c.doc && c.doc !== ownerDoc && c.doc.getSelection()?.rangeCount)
      : [];
    if (stale.length > 0) {
      guardProgrammaticSelection();
      stale.forEach((c) => c.doc.getSelection()?.removeAllRanges());
      releaseProgrammaticSelection();
    }
    // Selection.getRangeAt() returns the live, associated Range by reference.
    // Clone only for double-click normalization so native touch paths retain
    // their established Range behavior and browser handles stay untouched.
    const range = trimPoint ? liveRange.cloneRange() : liveRange;
    if (trimPoint) trimRangeWhitespaceAroundPoint(range, trimPoint.node, trimPoint.offset);
    const progress = getProgress(bookKey);
    setSelection({
      key: bookKey,
      text: await getAnnotationText(range),
      cfi: view?.getCFI(index, range),
      page: bookData?.isFixedLayout ? index + 1 : progress?.page || 0,
      range,
      index,
      handlesSuppressed,
    });
  };

  const startInstantAnnotating = (
    doc: Document,
    index: number,
    pointerId: number,
    target: HTMLElement,
    startPoint: Point,
  ) => {
    isInstantAnnotating.current = true;
    isInstantAnnotated.current = false;
    annotationStartPoint.current = startPoint;
    instantAnnotationTarget.current = target;
    if (view) view.renderer.scrollLocked = true;
    target.style.userSelect = 'none';
    instantGestureCleanup.current?.();
    const unsubscribeTurn = onAfterTurn(() => reapplyInstantAnnotation());
    // A turn that hides the page the drag started on (a PDF portrait spread
    // shows one page at a time) sends the release to the reader window rather
    // than to any page, so finish the highlight from there too.
    const releaseOutsidePages = (ev: PointerEvent) => {
      if (ev.pointerId === pointerId) handlePointerUp(doc, index, ev);
    };
    window.addEventListener('pointerup', releaseOutsidePages);
    instantGestureCleanup.current = () => {
      unsubscribeTurn();
      window.removeEventListener('pointerup', releaseOutsidePages);
    };
  };

  const stopInstantAnnotating = () => {
    isInstantAnnotating.current = false;
    isInstantAnnotated.current = false;
    annotationStartPoint.current = null;
    if (view) view.renderer.scrollLocked = false;
    instantGestureCleanup.current?.();
    instantGestureCleanup.current = null;
    if (instantAnnotationTarget.current) {
      instantAnnotationTarget.current.style.userSelect = '';
      instantAnnotationTarget.current = null;
    }
  };

  // Drop a pending still-hold without engaging (tap released early, finger
  // swiped, or the gesture was cancelled).
  const cancelInstantHold = () => {
    if (instantHoldTimer.current) {
      clearTimeout(instantHoldTimer.current);
      instantHoldTimer.current = null;
    }
    instantHoldTarget.current = null;
    instantHoldStartClient.current = null;
    instantHoldStartWindow.current = null;
  };

  // Begin the touch still-hold: engage the instant annotation only once the
  // finger has stayed put on the text for INSTANT_HOLD_MS. preventDefault is NOT
  // called here, so a tap or swipe that bows out keeps its native page-turn.
  // The native long-press selection needs no suppression here: instant mode
  // makes the content non-selectable at the stylesheet level (getStyles) —
  // JS-applied user-select at pointer-down proved too late for iOS WebKit's
  // long-press recognizer.
  const armInstantHold = (doc: Document, index: number, ev: PointerEvent) => {
    const feRect = doc.defaultView?.frameElement?.getBoundingClientRect();
    instantHoldTarget.current = ev.target as HTMLElement;
    instantHoldStartClient.current = { x: ev.clientX, y: ev.clientY };
    instantHoldStartWindow.current = {
      x: ev.clientX + (feRect?.left ?? 0),
      y: ev.clientY + (feRect?.top ?? 0),
    };
    if (instantHoldTimer.current) clearTimeout(instantHoldTimer.current);
    instantHoldTimer.current = setTimeout(() => {
      instantHoldTimer.current = null;
      const target = instantHoldTarget.current;
      const startClient = instantHoldStartClient.current;
      const start = instantHoldStartWindow.current;
      const now = pointerPos.current;
      cancelInstantHold();
      if (!target || !startClient) return;
      // Backstop the move-driven cancel: if the finger drifted during the hold,
      // treat it as a swipe and bow out.
      if (start && now && Math.hypot(now.x - start.x, now.y - start.y) > INSTANT_HOLD_MOVE_PX) {
        handleInstantAnnotationPointerCancel();
        return;
      }
      startInstantAnnotating(doc, index, ev.pointerId, target, startClient);
      // Preview the word under the finger right away (the feedback the
      // suppressed system long-press selection used to give); a release
      // without a drag commits it and opens the range editor.
      handleInstantAnnotationEngage(doc, index);
    }, INSTANT_HOLD_MS);
  };

  // While a still-hold is pending, a move past the threshold means the user is
  // swiping to turn the page — cancel so the swipe isn't swallowed.
  const maybeCancelInstantHoldOnMove = () => {
    const start = instantHoldStartWindow.current;
    const now = pointerPos.current;
    if (!instantHoldTimer.current || !start || !now) return;
    if (Math.hypot(now.x - start.x, now.y - start.y) > INSTANT_HOLD_MOVE_PX) {
      cancelInstantHold();
      handleInstantAnnotationPointerCancel();
    }
  };

  // Whether the pointer has actually travelled since this gesture began. A
  // pointermove arriving is not a drag: on touch every move looks like one, so
  // without this a long press that drifted a pixel marked its own selection as
  // dragged, and a finger then resting at the page edge flipped the page.
  const noteDragTravel = (): boolean => {
    const now = pointerPos.current;
    if (!now) return false;
    const origin = dragOriginRef.current;
    if (!origin) {
      dragOriginRef.current = now;
      return false;
    }
    return Math.hypot(now.x - origin.x, now.y - origin.y) > SELECTION_DRAG_SLOP_PX;
  };

  // A new gesture: nothing is a drag yet.
  const beginSelectionDrag = () => {
    pointerDragActive.current = false;
    selectionDragging.current = false;
    dragOriginRef.current = null;
  };

  // The gesture is over: drop the per-gesture drag latches and any pending
  // corner turn (with the edge mark it drew). Leaving the latches set let a
  // later move with no drag of its own inherit them and turn the page.
  const endSelectionDrag = () => {
    pointerDragActive.current = false;
    selectionDragging.current = false;
    dragOriginRef.current = null;
    cancelAutoTurn();
  };

  // Opens Readest's image menu for the image at the event's point, if any.
  const openImageMenu = (
    event: Pick<MouseEvent, 'target' | 'clientX' | 'clientY'>,
    isTouch: boolean,
  ): boolean => {
    const { clientX, clientY } = event;
    const doc = (event.target as Node).ownerDocument!;
    // A long press on text selects it, PDF text over a scanned page included.
    if (isTouch && isTextAtPoint(doc, clientX, clientY)) return false;
    const getImage = getContextMenuImage(event);
    if (!getImage) return false;
    const { x, y } = toParentViewportPoint(doc, clientX, clientY);
    eventDispatcher.dispatch('image-context-menu', { bookKey, getImage, x, y });
    return true;
  };

  const cancelImageHold = () => {
    if (imageHold.current) clearTimeout(imageHold.current.timer);
    imageHold.current = null;
  };

  // iOS WebKit fires no contextmenu for a long press, so a touch held still on
  // an image opens the image menu here. A release, a move past the slop or a
  // pointercancel (WebKit taking the touch to scroll) drops it.
  const armImageHold = (ev: PointerEvent) => {
    cancelImageHold();
    const { target, clientX, clientY } = ev;
    const timer = setTimeout(() => {
      imageHold.current = null;
      openImageMenu({ target, clientX, clientY }, true);
    }, LONG_HOLD_THRESHOLD);
    imageHold.current = { timer, x: clientX, y: clientY };
  };

  const handlePointerDown = (doc: Document, index: number, ev: PointerEvent) => {
    beginSelectionDrag();
    lastPointerType.current = ev.pointerType;
    if (appService?.isAndroidApp && ev.pointerType === 'touch') {
      doc.documentElement.classList.add(LINK_TOUCH_HOLD_CLASS);
    }
    if (appService?.isIOSApp && ev.pointerType === 'touch') armImageHold(ev);
    isPointerDown.current = true;
    clearCrossDoc();
    dragAnchorRef.current = null;

    if (isInstantAnnotationEnabled()) {
      const eligible = handleInstantAnnotationPointerDown(doc, index, ev);
      if (!eligible) return;
      const isTouch = ev.pointerType === 'touch' || ev.pointerType === 'pen';
      if (isTouch) {
        // Touch: gate behind a still hold so a tap or swipe still turns the page.
        armInstantHold(doc, index, ev);
      } else {
        // Mouse: a press-drag is an unambiguous highlight intent; engage at once.
        ev.preventDefault();
        startInstantAnnotating(doc, index, ev.pointerId, ev.target as HTMLElement, {
          x: ev.clientX,
          y: ev.clientY,
        });
      }
    }

    // Cross-page drag (#5809): remember where a mouse selection drag starts so
    // it can continue onto an adjacent page iframe.
    if (
      !isInstantAnnotating.current &&
      ev.pointerType === 'mouse' &&
      ev.button === 0 &&
      crossPageEnabled() &&
      isTextAtPoint(doc, ev.clientX, ev.clientY)
    ) {
      const pos = getCaretPosition(doc, ev.clientX, ev.clientY);
      if (pos) dragAnchorRef.current = { doc, index, pos };
    }
  };

  // UI Events exposes the current click count on mousedown (`detail`). Record
  // the second primary-button press before pointerup publishes the native word
  // selection, so any browser-added separator can be removed exactly once.
  const handleMouseDown = (ev: MouseEvent) => {
    const doubleClickEnabled = !getViewSettings(bookKey)?.disableDoubleClick;
    mouseDoubleClickRef.current =
      doubleClickEnabled && ev.button === 0 && ev.detail === 2
        ? { x: ev.clientX, y: ev.clientY, moved: false }
        : null;
  };

  const handlePointerMove = (doc: Document, index: number, ev: PointerEvent) => {
    const doubleClick = mouseDoubleClickRef.current;
    if (
      doubleClick &&
      ev.pointerType === 'mouse' &&
      Math.hypot(ev.clientX - doubleClick.x, ev.clientY - doubleClick.y) >=
        DOUBLE_CLICK_DRAG_MOVE_PX
    ) {
      doubleClick.moved = true;
    }
    const hold = imageHold.current;
    if (hold && Math.hypot(ev.clientX - hold.x, ev.clientY - hold.y) > INSTANT_HOLD_MOVE_PX) {
      cancelImageHold();
    }
    // The listener lives on the book iframe's document, so ev.clientX/Y are in
    // the (very wide, multi-column) iframe viewport. Map to window coordinates
    // via the iframe element's on-screen rect, like the selection caret.
    const feRect = doc.defaultView?.frameElement?.getBoundingClientRect();
    pointerPos.current = {
      x: ev.clientX + (feRect?.left ?? 0),
      y: ev.clientY + (feRect?.top ?? 0),
    };
    maybeCancelInstantHoldOnMove();
    if (isInstantAnnotating.current) {
      // In scroll mode, detect gesture direction before committing to annotation.
      // Cancel if the gesture is along the scroll axis (vertical for normal, horizontal
      // for vertical writing mode) since the user likely intends to scroll.
      if (!isInstantAnnotated.current && annotationStartPoint.current) {
        const dx = Math.abs(ev.clientX - annotationStartPoint.current.x);
        const dy = Math.abs(ev.clientY - annotationStartPoint.current.y);
        const distance = Math.sqrt(dx * dx + dy * dy);
        const viewSettings = getViewSettings(bookKey);
        const isScrollGesture = viewSettings?.vertical ? dy < 3 * dx : dx < 3 * dy;
        if (distance >= 10 && isScrollGesture) {
          stopInstantAnnotating();
          handleInstantAnnotationPointerCancel();
          return;
        }
      }
      ev.preventDefault();
      // Sticky once a preview is drawn: a later move that can't resolve (the
      // pointer has left the start page) must not re-arm the scroll-gesture
      // check above, which would cancel the highlight mid-drag.
      isInstantAnnotated.current =
        handleInstantAnnotationPointerMove(doc, index, ev) || isInstantAnnotated.current;
      // Cross-page instant highlight: feed the finger corner into the same dwell
      // machine native selection uses, so the page turns and the highlight
      // continues across the boundary (the start is DOM-anchored in
      // useInstantAnnotation so it survives the scroll).
      noteAutoTurnPoint(getViewSettings(bookKey)?.scrolled ? null : pointerPos.current);
      return;
    }

    // Cross-page drag (#5809): the browser keeps delivering a mouse drag to the
    // iframe it started in, even once the pointer is over another page iframe.
    // Over another page, extend the selection into it and freeze the origin
    // page's native drag (which would otherwise chase the out-of-frame pointer);
    // back over the origin page the native drag resumes.
    const dragAnchor = dragAnchorRef.current;
    if (dragAnchor && ev.pointerType === 'mouse' && ev.buttons & 1 && pointerPos.current) {
      if (extendCrossDocTo(dragAnchor, pointerPos.current)) {
        const state = crossDocRef.current;
        if (state && !state.frozen) {
          setNativeDragFrozen(dragAnchor.doc, true);
          state.frozen = true;
        }
      }
    }

    // Pointer-driven auto page-turn (#1354) for web/desktop/iOS, where the
    // pointer is the reliable, stable signal at the corner. Android uses the
    // caret in handleSelectionchange (no pointermove during a selection drag).
    // Android uses native touchmove (handleNativeTouchMove) — the iframe
    // pointermove doesn't fire there during a native selection drag.
    const isAndroid = osPlatform === 'android' && appService?.isAndroidApp;
    if (isAndroid) return;
    const viewSettings = getViewSettings(bookKey);
    const sel = doc.getSelection();
    const valid = !!sel && isValidSelection(sel);
    // Only an active drag arms the turn: the zone reaches past the text, so a
    // mouse merely moving there with a selection on screen would otherwise turn
    // the page on its own. For a mouse that means a held button; for any pointer
    // it means the finger has actually travelled, not just twitched.
    const dragging =
      noteDragTravel() && (ev.pointerType === 'mouse' ? (ev.buttons & 1) !== 0 : true);
    pointerDragActive.current = dragging;
    const armed = valid && dragging && selectionDragging.current;
    const corner = !viewSettings?.scrolled && armed ? pointerCornerNow() : null;
    noteCorner(corner, (c) => inCorner(c, doc));
  };

  // Native touchmove — the pointer engagement signal during a native
  // selection drag when the webview withholds DOM moves. The native x/y
  // are physical device pixels relative to the window; convert to CSS px.
  const handleNativeTouchMove = (x: number, y: number, doc: Document) => {
    const dpr = window.devicePixelRatio || 1;
    pointerPos.current = { x: x / dpr, y: y / dpr };
    pointerDragActive.current = noteDragTravel();
    maybeCancelInstantHoldOnMove();
    const viewSettings = getViewSettings(bookKey);
    // Instant highlight has no DOM selection (user-select is off); feed the
    // finger corner directly so the drag can turn the page across boundaries.
    if (isInstantAnnotating.current) {
      noteAutoTurnPoint(viewSettings?.scrolled ? null : pointerPos.current);
      return;
    }
    const sel = doc.getSelection();
    const valid = !!sel && isValidSelection(sel);
    const armed = valid && pointerDragActive.current && selectionDragging.current;
    const corner = !viewSettings?.scrolled && armed ? pointerCornerNow() : null;
    noteCorner(corner, (c) => inCorner(c, doc));
    return armed;
  };

  const handlePointerCancel = (doc: Document, _index: number, _ev: PointerEvent) => {
    isPointerDown.current = false;
    cancelImageHold();
    doc.documentElement.classList.remove(LINK_TOUCH_HOLD_CLASS);
    mouseDoubleClickRef.current = null;
    clearCrossDoc();
    dragAnchorRef.current = null;
    // A pending still-hold that never engaged: drop it so a swipe-takeover
    // (Android fires pointercancel when the browser starts scrolling) keeps its
    // native page-turn instead of being swallowed.
    cancelInstantHold();
    // In the mobile apps the native-touch bridge reports the real release,
    // even when the webview cancels DOM pointer events during a selection
    // handle drag. Keep the dwell and drag latches until that native release.
    // Everywhere else pointercancel IS the end: no pointerup or touchend
    // follows it, so this is the only chance to drop the turn and the edge mark.
    if (!appService?.isAndroidApp && !appService?.isIOSApp) endSelectionDrag();
    if (isInstantAnnotating.current) {
      stopInstantAnnotating();
      handleInstantAnnotationPointerCancel();
    }
  };

  // Android (#1553): when a touch selection starts on the first word of a
  // hyphenated paragraph, Blink paints the start handle on the paragraph's
  // last hyphen and drag gestures re-anchor the selection base there. At
  // gesture end: restore the intended range if the anchor jumped, then clear
  // and re-add the selection through the Selection API — a selection that goes
  // empty for one painted frame loses its touch-handle visibility, so the
  // broken native handles disappear (the app's own handles take over) while
  // the highlight stays.
  const sanitizedGestureRef = useRef(false);
  const sanitizeAndroidHyphenSelection = async (doc: Document, index: number) => {
    if (sanitizedGestureRef.current) return;
    const sel = doc.getSelection();
    const win = doc.defaultView;
    if (!sel || !win || !isValidSelection(sel)) return;
    // Only act when THIS gesture produced a selection — a tap that merely
    // dismisses an existing selection must not re-assert it here.
    const initial = gestureInitialRef.current;
    if (!initial) return;
    const viewSettings = getViewSettings(bookKey);
    // The initial range is prone (long-press on the first word), or the
    // gesture dragged the selection start back onto a hyphenated paragraph
    // start (upward selection) — either way the painted start bound is bogus.
    const prone =
      initial.prone || isHyphenHandleBugProneRange(sel.getRangeAt(0), viewSettings?.vertical);
    if (!prone) return;
    sanitizedGestureRef.current = true;
    let finalRange = sel.getRangeAt(0);
    if (initial.prone) {
      // The corrupted drag can leave EITHER selection end at the bogus bound
      // (base re-anchor or extent overshoot). The trustworthy facts are the
      // gesture-initial anchor and the finger position (pointerPos, reset at
      // touchstart and fed by native touchmove): rebuild between those when
      // the gesture moved; otherwise fall back to the anchor-jump repair.
      const p = pointerPos.current;
      const feRect = win.frameElement?.getBoundingClientRect();
      const clamped = p
        ? rangeFromAnchorToPoint(
            doc,
            initial.node,
            initial.offset,
            p.x - (feRect?.left ?? 0),
            p.y - (feRect?.top ?? 0),
          )
        : null;
      const repaired = clamped ?? repairJumpedSelectionRange(sel, initial.node, initial.offset);
      if (repaired) finalRange = repaired;
    }
    guardProgrammaticSelection();
    sel.removeAllRanges();
    await new Promise<void>((resolve) =>
      win.requestAnimationFrame(() => win.requestAnimationFrame(() => resolve())),
    );
    // A competing gesture may have touched the selection while we waited —
    // e.g. a tap collapses the old selection to a caret at the tapped point,
    // which can also mutate `finalRange` in place. Re-asserting then would
    // resurrect a stale (or collapsed) selection, so bail out instead.
    if (sel.rangeCount > 0 || finalRange.collapsed) {
      releaseProgrammaticSelection();
      return;
    }
    sel.addRange(finalRange);
    releaseProgrammaticSelection();
    await makeSelection(sel, index, false, true);
  };

  // Replace the live DOM selection from the custom selection handles. Guarded
  // so the resulting selectionchange echoes are ignored; a commit refreshes
  // the selection state (and thus the popup) once the drag ends.
  const applyProgrammaticSelection = async (range: Range, index: number, commit: boolean) => {
    const doc = range.startContainer.ownerDocument;
    const sel = doc?.getSelection();
    if (!doc || !sel) return;
    guardProgrammaticSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    if (commit) {
      releaseProgrammaticSelection();
      await makeSelection(sel, index, false, true);
    }
  };

  // A double-click / touch double-tap on a word: select the word (like a
  // long-press selection) and route it through the same selection state that
  // drives the quick action / annotation toolbar. Desktop native selection is
  // finalized in handlePointerUp; touch double-tap still needs this synthesized
  // range when the platform has no native word-select gesture.
  const handleDoubleClick = async (doc: Document, index: number, x: number, y: number) => {
    if (isInstantAnnotating.current) return;
    const sel = doc.getSelection();
    if (!sel || isValidSelection(sel)) return;
    const range = getWordRangeFromPoint(doc, x, y);
    if (!range) return;
    guardProgrammaticSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    releaseProgrammaticSelection();
    // With the instant-highlight stylesheet suppression active, WebKit may
    // refuse the programmatic selection on non-selectable content.
    if (sel.rangeCount === 0) return;
    // No isUpToPopup latch here: a double-tap is two taps both consumed by the
    // double-click detection, so no trailing single-click follows that would
    // dismiss the popup — the next deliberate tap should dismiss it normally.
    await makeSelection(sel, index, false);
  };

  const handlePointerUp = async (doc: Document, index: number, ev?: PointerEvent) => {
    isPointerDown.current = false;
    cancelImageHold();
    doc.documentElement.classList.remove(LINK_TOUCH_HOLD_CLASS);
    endSelectionDrag();
    const mouseDoubleClick = mouseDoubleClickRef.current;
    mouseDoubleClickRef.current = null;
    dragAnchorRef.current = null;

    // Cross-page drag (#5809): the release ends the drag; commit the per-page
    // parts as one selection (re-applied, so a native drag that fought the
    // anchor page's part mid-gesture can't leave it stale).
    if (crossDocRef.current) {
      const { anchor } = crossDocRef.current;
      if (ev) {
        const feRect = doc.defaultView?.frameElement?.getBoundingClientRect();
        extendCrossDocTo(anchor, {
          x: ev.clientX + (feRect?.left ?? 0),
          y: ev.clientY + (feRect?.top ?? 0),
        });
      }
      const segments = crossDocRef.current?.segments ?? [];
      if (segments.length > 0) {
        guardProgrammaticSelection();
        applyCrossDocSegments(segments, getContents(), anchor);
        clearCrossDoc(true);
        isUpToPopup.current = true;
        await makeCrossDocSelection(segments);
        return;
      }
    }
    // A tap (or a long-press shorter than the hold) that never engaged: drop the
    // pending still-hold so the tap falls through to a page turn.
    if (instantHoldTimer.current) cancelInstantHold();
    if (isInstantAnnotating.current && ev) {
      stopInstantAnnotating();
      const handled = await handleInstantAnnotationPointerUp(doc, index, ev);
      if (handled === 'editor') {
        // The hold committed a word highlight and left the range editor open.
        // Consume the trailing click with the "this release leads to a popup"
        // latch (same as the selection popup flow) — the 200ms isTextSelected
        // latch below would let the click dismiss the fresh editor instead.
        isUpToPopup.current = true;
        return;
      }
      if (handled) {
        isTextSelected.current = true;
        setTimeout(() => {
          isTextSelected.current = false;
        }, 200);
        return;
      } else {
        // If instant annotation was not created, we let the event propagate
        // as an iframe click event which relies on a mousedown event
        (ev.target as Element)?.dispatchEvent(
          new MouseEvent('mousedown', {
            ...ev,
            bubbles: true,
            cancelable: true,
          }),
        );
      }
    }

    // Available on iOS and Desktop, fired at touchend or mouseup
    // Note that on Android, we mock pointer events with native touch events
    const sel = doc.getSelection() as Selection;
    if (isValidSelection(sel)) {
      const isPointerInside = ev && isPointerInsideSelection(sel, ev);
      let trimPoint: { node: Node; offset: number } | null = null;
      if (
        isPointerInside &&
        ev.pointerType === 'mouse' &&
        mouseDoubleClick &&
        !mouseDoubleClick.moved
      ) {
        trimPoint = getCaretPointFromPoint(doc, mouseDoubleClick.x, mouseDoubleClick.y);
      }

      // iOS no longer needs a special path: the native plugin
      // (ContextMenuSuppressor) suppresses the system selection menu, so
      // iOS selections go through the same path as desktop.
      if (isPointerInside) {
        isUpToPopup.current = true;
        makeSelection(sel, index, true, false, trimPoint);
      } else if (appService?.isAndroidApp) {
        isUpToPopup.current = false;
      }
    }

    if (osPlatform === 'android' && appService?.isAndroidApp) {
      await sanitizeAndroidHyphenSelection(doc, index);
      await suppressNativeHandlesForPages();
    }
  };
  const handleTouchStart = () => {
    lastPointerType.current = 'touch';
    isTouchStarted.current = true;
    beginSelectionDrag();
    pendingTouchSelection.current = false;
    gestureInitialRef.current = null;
    sanitizedGestureRef.current = false;
    // Pointer positions are per-gesture: a stale point from a previous touch
    // must not steer this gesture's selection repair. Touch moves re-feed it.
    pointerPos.current = null;
  };
  const handleTouchMove = (ev: TouchEvent) => {
    if (isInstantAnnotating.current) {
      ev.preventDefault();
    }
  };
  // Ends the touch gesture and processes a selectionchange that was deferred
  // while the finger was down (see handleSelectionchange): the selection state
  // updates once, so the annotation popup appears once, at the release. The
  // Android native-touch bridge calls this without a doc (it never defers).
  const handleTouchEnd = (doc?: Document, index?: number) => {
    isTouchStarted.current = false;
    isPointerDown.current = false;
    cancelInstantHold();
    endSelectionDrag();
    if (!pendingTouchSelection.current) return;
    pendingTouchSelection.current = false;
    if (!doc || index === undefined) return;
    const sel = doc.getSelection();
    if (sel && isValidSelection(sel)) {
      if (selectionPosition.current === null) {
        selectionPosition.current = view?.renderer?.containerPosition ?? null;
      }
      makeSelection(sel, index, false);
    } else if (isTextSelected.current) {
      handleDismissPopup();
      isTextSelected.current = false;
    }
  };

  const handleTouchCancel = () => {
    isTouchStarted.current = false;
    isPointerDown.current = false;
    pendingTouchSelection.current = false;
    endSelectionDrag();
    cancelInstantHold();
  };

  // The corner the latest pointer (pointermove / native touchmove) position is
  // in, reading a finger dragged off the page as the edge it left by.
  const pointerCornerNow = (): Corner | null => cornerAtPoint(pointerPos.current, true);
  // The corner the selection caret (focus) is in.
  const caretCornerNow = (doc: Document): Corner | null => {
    const sel = doc.getSelection();
    if (!sel || !isValidSelection(sel)) return null;
    return cornerAtPoint(focusCaretWindowPos(doc, sel));
  };
  // Whether any input signal (pointer/touch or caret) is currently in corner `c`.
  // Injected into the dwell machine as the native-selection liveness predicate so
  // the page only turns while the caret OR the finger is still in the corner.
  const inCorner = (c: Corner, doc: Document): boolean =>
    (pointerDragActive.current && pointerCornerNow() === c) || caretCornerNow(doc) === c;

  const handleSelectionchange = (doc: Document, index: number) => {
    const sel = doc.getSelection() as Selection;
    doc.documentElement.classList.toggle(TEXT_SELECTED_CLASS, sel?.isCollapsed === false);

    // Echo of our own programmatic selection writes (handle suppression or a
    // custom-handle drag) — not user input.
    if (programmaticSelectionRef.current) return;

    // Available on iOS, Android and Desktop, fired when the selection is changed.
    // On Android native app, this is the primary way to detect text selection.
    // On web with touch/pen in scroll mode, pointerup never fires (pointercancel
    // fires instead when browser takes over for scrolling), so we also handle
    // selectionchange for touch/pen input to pick up native text selections.
    const isAndroid = osPlatform === 'android' && appService?.isAndroidApp;
    const isTouchInput = lastPointerType.current === 'touch' || lastPointerType.current === 'pen';
    const viewSettings = getViewSettings(bookKey);

    // Only a selection that moves while a pointer is dragging arms the turn: the
    // long-press that creates one must not, or a finger that then rests at the
    // page edge would flip pages.
    if (isValidSelection(sel) && pointerDragActive.current) selectionDragging.current = true;

    if (isAndroid) syncSelectionMenuSuppression(isValidSelection(sel));

    // First selection of an Android touch gesture: remember the anchor and
    // whether it is prone to the hyphen bounds bug (#1553), before any
    // drag-extension can corrupt it.
    if (isAndroid && !gestureInitialRef.current && isValidSelection(sel) && sel.anchorNode) {
      gestureInitialRef.current = {
        node: sel.anchorNode,
        offset: sel.anchorOffset,
        prone: isHyphenHandleBugProneRange(sel.getRangeAt(0), viewSettings?.vertical),
      };
    }

    // Auto page-turn (#1354): the selection caret is one of the engagement
    // signals on every platform (and the only one on Android during a native
    // selection drag, where pointer/touch-move don't fire). Feed it into the same
    // dwell machine the pointer uses, under the same gate: without it a
    // long-press that lands a caret in a corner would turn the page by itself.
    if (isValidSelection(sel) && selectionDragging.current) {
      noteCorner(!viewSettings?.scrolled ? caretCornerNow(doc) : null, (c) => inCorner(c, doc));
    } else {
      cancelAutoTurn();
    }

    // Desktop mouse selections defer to pointerup, but a keyboard selection
    // adjustment (#4728) has no pointerup — process it as long as a pointer drag
    // isn't in progress (mid-drag still defers to pointerup).
    if (!isAndroid && !isTouchInput && isPointerDown.current) return;
    // Touch drags in paginated mode (iOS/web): the system handle drag streams
    // selectionchange while the Annotator's touchmove handler hides the popup;
    // processing each change re-showed it and made the toolbar flash. Defer to
    // the gesture end (handleTouchEnd). Scroll mode keeps the immediate path —
    // there the gesture can end in pointercancel with no processing after it.
    // Android keeps it too: selectionchange is its primary selection signal
    // and its popup-hiding touchmove never fires.
    if (!isAndroid && isTouchInput && isTouchStarted.current && !viewSettings?.scrolled) {
      pendingTouchSelection.current = true;
      return;
    }
    if (isValidSelection(sel)) {
      if (selectionPosition.current === null) {
        // Save the absolute container scroll, not `renderer.start` — the
        // latter is section-relative, so restoring it as `containerPosition`
        // snaps multi-section paginated views back to the first rendered
        // section (#873-related Android regression).
        selectionPosition.current = view?.renderer?.containerPosition ?? null;
      }
      makeSelection(sel, index, false);
    } else {
      // Selection cleared (e.g. clicking outside the selection).
      // Dismiss immediately on all platforms.
      if (isTextSelected.current) {
        handleDismissPopup();
        isTextSelected.current = false;
      }
      selectionPosition.current = null;
    }
  };
  const handleScroll = () => {
    // Prevent the container from scrolling when text is selected in paginated mode
    // FIXME: this is a workaround for issue #873
    if (osPlatform !== 'android' || !appService?.isAndroidApp) return;

    const viewSettings = getViewSettings(bookKey);
    if (viewSettings?.scrolled) return;

    // Don't fight a deliberate auto page-turn (#1354): without this the pin
    // below snaps the container straight back to the selection-start page and
    // the turn never sticks (the Android-only failure mode).
    if (isAutoTurning.current) return;

    if (isTextSelected.current && view?.renderer && selectionPosition.current !== null) {
      view.renderer.containerPosition = selectionPosition.current;
    }
  };

  const handleShowPopup = (showPopup: boolean) => {
    setTimeout(() => {
      if (showPopup && !isPopuped.current) {
        isUpToPopup.current = false;
      }
      isPopuped.current = showPopup;
    }, 500);
  };

  const handleUpToPopup = () => {
    isUpToPopup.current = true;
  };

  const handleContextmenu = (event: Event) => {
    const isTouch =
      !!appService?.isMobile ||
      lastPointerType.current === 'touch' ||
      lastPointerType.current === 'pen';
    // Images get Readest's own menu, from a right-click or, on Android, a long
    // press (#6574): the webview's differs per engine and offers "Copy image
    // address" for a blob URL nobody can use (#6558).
    if (openImageMenu(event as MouseEvent, isTouch)) event.preventDefault();
    // The desktop webview's own menu (Back / Refresh / Print...) has no place in
    // the reading area (#6668); the web build keeps the browser's for extensions.
    if (appService?.isDesktopApp) event.preventDefault();
    if (isTouch) {
      event.preventDefault();
      event.stopPropagation();
      return false;
    }
    return;
  };

  useEffect(() => {
    const handleSingleClick = (): boolean => {
      if (isUpToPopup.current) {
        isUpToPopup.current = false;
        return true;
      }
      if (isTextSelected.current) {
        handleDismissPopup();
        isTextSelected.current = false;
        // Look the view up now: the one captured at mount can be undefined (#6583).
        getView(bookKey)?.deselect();
        return true;
      }
      if (isPopuped.current) {
        handleDismissPopup();
        return true;
      }
      return false;
    };

    eventDispatcher.onSync('iframe-single-click', handleSingleClick);
    // After any auto page-turn, re-anchor the Android selection scroll-pin to the
    // page we landed on (the #873 pin in handleScroll). Harmless when nothing is
    // pinned (instant highlight / range editors carry no DOM selection).
    const unsubAfterTurn = onAfterTurn(() => {
      selectionPosition.current =
        getView(bookKey)?.renderer?.containerPosition ?? selectionPosition.current;
    });
    return () => {
      eventDispatcher.offSync('iframe-single-click', handleSingleClick);
      unsubAfterTurn();
      instantGestureCleanup.current?.();
      if (instantHoldTimer.current) clearTimeout(instantHoldTimer.current);
      cancelImageHold();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    isTextSelected,
    isInstantAnnotating,
    handleScroll,
    handleTouchStart,
    handleTouchMove,
    handleTouchEnd,
    handleTouchCancel,
    handleMouseDown,
    handlePointerDown,
    handlePointerMove,
    handleNativeTouchMove,
    handlePointerCancel,
    handlePointerUp,
    handleDoubleClick,
    handleSelectionchange,
    handleShowPopup,
    handleUpToPopup,
    handleContextmenu,
    dragSelectionTo,
    suppressNativeSelectionHandles,
    restoreSelectionRange,
    // The shared corner auto-turn feed/cancel/subscribe, re-exposed so the range
    // editors can drive the same machine from their overlay handle drags.
    noteAutoTurnPoint,
    cancelAutoTurn,
    onAutoTurn: onAfterTurn,
    turnHint,
  };
};
