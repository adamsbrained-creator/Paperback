import clsx from 'clsx';
import React, { useMemo, useRef } from 'react';
import { MdEdit, MdDelete, MdContentCopy } from 'react-icons/md';
import { PiBookmarkSimple, PiHighlighter, PiNotePencil, PiScribbleLoop } from 'react-icons/pi';

import { useEnv } from '@/context/EnvContext';
import { BookNote, HighlightColor } from '@/types/book';
import { useSettingsStore } from '@/store/settingsStore';
import { useReaderStore } from '@/store/readerStore';
import { useNotebookStore } from '@/store/notebookStore';
import { useBookDataStore } from '@/store/bookDataStore';
import { useTranslation } from '@/hooks/useTranslation';
import { useResponsiveSize } from '@/hooks/useResponsiveSize';
import { useLongPress } from '@/hooks/useLongPress';
import { eventDispatcher } from '@/utils/event';
import { isCfiInLocation } from '@/utils/cfi';
import { buildAnnotationUrl } from '@/utils/deeplink';
import { buildAnnotationCopyMarkdown } from '@/utils/note';
import { writeTextToClipboard } from '@/utils/clipboard';
import { nextBooknoteStamp } from '@/utils/booknoteStamp';
import { DEFAULT_NOTE_EXPORT_CONFIG } from '@/services/constants';
import { removeBookNoteOverlays } from '../../utils/annotatorUtil';
import { parseNoteMarkdown } from '../../utils/noteMarkdown';
import { useSaveBooknoteNoteText } from '../../hooks/useSaveBooknoteNoteText';
import { useInlineTextEditor } from '../../hooks/useInlineTextEditor';
import TextButton from '@/components/TextButton';
import TextEditor from '@/components/TextEditor';
import { BooknoteTimeLabel } from './BooknoteTime';

/** The icon and name that lead an item, by what it is. */
const kindOf = (item: BookNote) => {
  if (item.type === 'bookmark') return { label: 'Bookmark', Icon: PiBookmarkSimple };
  if (item.type === 'ink') return { label: 'Drawing', Icon: PiScribbleLoop };
  if (item.note) return { label: 'Note', Icon: PiNotePencil };
  return { label: 'Highlight', Icon: PiHighlighter };
};

interface BooknoteItemProps {
  bookKey: string;
  item: BookNote;
  isNearest?: boolean;
  onClick?: () => void;
  inlineNoteEditing?: boolean;
}

const BooknoteItem: React.FC<BooknoteItemProps> = ({
  bookKey,
  item,
  isNearest,
  onClick,
  inlineNoteEditing,
}) => {
  const _ = useTranslation();
  const { envConfig, appService } = useEnv();
  const { settings } = useSettingsStore();
  const { getConfig, saveConfig, updateBooknotes } = useBookDataStore();
  const { getProgress, getView, getViewsById, getViewSettings } = useReaderStore();
  const { setNotebookEditAnnotation, setNotebookVisible } = useNotebookStore();

  const globalReadSettings = settings.globalReadSettings;
  const customColors = globalReadSettings.customHighlightColors;

  const { text, cfi, note } = item;
  const kind = kindOf(item);
  const kindIconSize = useResponsiveSize(12);
  const isBookmark = item.type === 'bookmark';
  const saveBooknoteNoteText = useSaveBooknoteNoteText(bookKey);
  const saveBookmarkText = (draftText: string) => {
    const config = getConfig(bookKey);
    if (!config || !draftText) return;
    const { booknotes: annotations = [] } = config;
    const existingIndex = annotations.findIndex((annotation) => item.id === annotation.id);
    if (existingIndex === -1) return;
    annotations[existingIndex]!.updatedAt = nextBooknoteStamp(annotations[existingIndex]!);
    annotations[existingIndex]!.text = draftText;
    const updatedConfig = updateBooknotes(bookKey, annotations);
    if (updatedConfig) {
      saveConfig(envConfig, bookKey, updatedConfig, settings);
    }
  };
  const { editorRef, draftText, setDraftText, inlineEditMode, startEdit, cancelEdit, save } =
    useInlineTextEditor((draftText) => {
      if (isBookmark) return saveBookmarkText(draftText);
      else return saveBooknoteNoteText(item.id, draftText);
    });
  const separatorWidth = useResponsiveSize(3);
  const size18 = useResponsiveSize(18);

  const progress = getProgress(bookKey);
  // Active highlight: keep visual "current" state but don't scroll from the
  // item itself anymore — the parent (virtualized) BooknoteView handles
  // scrolling via virtuosoRef.scrollToIndex, avoiding N getBoundingClientRect
  // calls when the list grows large.
  const isCurrent = useMemo(
    () => isCfiInLocation(cfi, progress?.location) || !!isNearest,
    [cfi, progress?.location, isNearest],
  );

  // parseNoteMarkdown is heavy when called on every list scroll re-render
  // across hundreds of items. Cache by note text — note edits change
  // item.note and bust the cache automatically.
  const noteHtml = useMemo(() => (note ? parseNoteMarkdown(note) : ''), [note]);

  // iOS WebKit applies :hover at touchstart, so every scroll touch would expand
  // the card under the finger (#6568). There a long press reveals the actions
  // instead, and the click that iOS sends after it must not navigate.
  const revealOnHover = !appService?.isIOSApp;
  const itemRef = useRef<HTMLLIElement>(null);
  const longPressedRef = useRef(false);
  const { handlers: longPressHandlers } = useLongPress(
    {
      onLongPress: () => {
        longPressedRef.current = true;
        itemRef.current?.focus({ preventScroll: true });
      },
      threshold: 300,
    },
    [],
  );

  const handleClickItem = (event: React.MouseEvent | React.KeyboardEvent) => {
    event.preventDefault();
    if (event.type === 'click' && longPressedRef.current) {
      longPressedRef.current = false;
      return;
    }
    eventDispatcher.dispatch('navigate', { bookKey, cfi });

    onClick?.();
    getView(bookKey)?.goTo(cfi);
  };

  const deleteNote = (note: BookNote) => {
    if (!bookKey) return;
    const config = getConfig(bookKey);
    if (!config) return;
    const { booknotes = [] } = config;
    booknotes.forEach((item) => {
      if (item.id === note.id) {
        item.deletedAt = nextBooknoteStamp(item);
        const views = getViewsById(bookKey.split('-')[0]!);
        views.forEach((view) => removeBookNoteOverlays(view, item));
      }
    });
    const updatedConfig = updateBooknotes(bookKey, booknotes);
    if (updatedConfig) {
      saveConfig(envConfig, bookKey, updatedConfig, settings);
    }
  };

  const editNote = (note: BookNote) => {
    setNotebookVisible(true);
    setNotebookEditAnnotation(note);
  };

  const buildSourceMarkdown = () => {
    const bookHash = item.bookHash || bookKey.split('-')[0]!;
    const linkType =
      getViewSettings(bookKey)?.noteExportConfig?.linkType ?? DEFAULT_NOTE_EXPORT_CONFIG.linkType;
    const url = buildAnnotationUrl({ bookHash, noteId: item.id, cfi: item.cfi }, linkType);
    const linkLabel = item.page
      ? _('Page: {{number}}', { number: item.page })
      : _('Open in Paperback');
    return {
      bookHash,
      markdown: buildAnnotationCopyMarkdown({
        text: item.text,
        note: item.note,
        noteLabel: _('Note'),
        url,
        linkLabel,
      }),
    };
  };

  const handleCopyLink = () => {
    const { markdown } = buildSourceMarkdown();
    void writeTextToClipboard(markdown);
    eventDispatcher.dispatch('toast', {
      type: 'info',
      message: _('Copied to clipboard'),
      className: 'whitespace-nowrap',
      timeout: 2000,
    });
  };

  const editBookmark = () => startEdit(text || '');

  const editNoteInline = () => startEdit(item.note || '');

  if (inlineEditMode) {
    return (
      <div
        data-testid='booknote-note-editor'
        className={clsx(
          'border-base-300 content group relative my-2 cursor-pointer rounded-lg p-2',
          isCurrent ? 'bg-base-300/85 hover:bg-base-300' : 'hover:bg-base-300/55 bg-base-100',
          'transition-all duration-300 ease-in-out',
        )}
      >
        {/* Same anatomy as AnnotationNoteEditor — the field, then a
            bottom-right Cancel/Save row — so a note reads the same whichever
            editor opened it. This one keeps its content height: it sits in a
            list row, not in a sized popup or sheet. */}
        <div className='flex flex-col gap-2 p-2'>
          <TextEditor
            className='leading-normal!'
            ref={editorRef}
            value={draftText}
            onChange={setDraftText}
            onSave={save}
            onEscape={cancelEdit}
            placeholder={isBookmark ? undefined : _('Add Note')}
            spellCheck={false}
            autoFocus
          />
          <div className='flex shrink-0 justify-end gap-3' dir='ltr'>
            <TextButton onClick={cancelEdit}>{_('Cancel')}</TextButton>
            <TextButton onClick={save} disabled={isBookmark && !draftText}>
              {_('Save')}
            </TextButton>
          </div>
        </div>
      </div>
    );
  }

  const isEditable =
    !!item.note || isBookmark || (!!inlineNoteEditing && item.type === 'annotation');
  const actionButtonReveal = clsx(
    'group-focus-within:opacity-100',
    revealOnHover && 'group-hover:opacity-100',
  );

  return (
    <li
      // eslint-disable-next-line jsx-a11y/no-noninteractive-element-to-interactive-role
      role='button'
      aria-current={isCurrent ? 'page' : undefined}
      className={clsx(
        'booknote-item border-base-300 content group relative my-2 cursor-pointer rounded-lg p-2',
        isCurrent
          ? 'bg-base-300/85 hover:bg-base-300 focus:bg-base-300'
          : 'hover:bg-base-300/55 focus:bg-base-300/55 bg-base-100',
        'transition-all duration-300 ease-in-out',
      )}
      ref={itemRef}
      tabIndex={0}
      onClick={handleClickItem}
      {...(!revealOnHover && {
        onPointerDown: (e: React.PointerEvent) => {
          longPressedRef.current = false;
          longPressHandlers.onPointerDown(e);
        },
        onPointerMove: longPressHandlers.onPointerMove,
        onPointerUp: longPressHandlers.onPointerUp,
        onPointerCancel: longPressHandlers.onPointerCancel,
        onPointerLeave: longPressHandlers.onPointerLeave,
      })}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          handleClickItem(e);
        } else {
          e.stopPropagation();
        }
      }}
    >
      <div className='flex items-start gap-2'>
        <span
          role='img'
          aria-label={_(kind.label)}
          className='bg-base-content/10 text-base-content/60 flex h-5 w-5 shrink-0 items-center justify-center rounded-full'
        >
          <kind.Icon size={kindIconSize} aria-hidden='true' />
        </span>
        <div
          className={clsx('min-h-4 min-w-0 flex-1 p-0 transition-all duration-300 ease-in-out')}
          style={
            {
              '--top-override': '0.7rem',
              '--end-override': '0.3rem',
            } as React.CSSProperties
          }
        >
          {item.note && (
            <div
              className='content prose prose-sm font-size-sm'
              dir='auto'
              dangerouslySetInnerHTML={{ __html: noteHtml }}
            ></div>
          )}
          <div className='flex items-start'>
            {item.note && (
              <div
                className='me-2 mt-2.5 min-h-full self-stretch rounded-xl bg-gray-300'
                style={{
                  minWidth: `${separatorWidth}px`,
                }}
              ></div>
            )}
            <div className={clsx('content font-size-sm line-clamp-3', item.note && 'mt-2')}>
              <span
                className={clsx(
                  'booknote-text inline leading-normal',
                  item.note && 'content font-size-xs text-base-content',
                  (item.style === 'underline' || item.style === 'squiggly') &&
                    'underline decoration-2',
                  item.style === 'highlight' && 'rounded-[4px] px-[2px] py-[1px]',
                  item.style === 'squiggly' && 'decoration-wavy',
                )}
                style={
                  {
                    ...(item.style === 'highlight'
                      ? {
                          backgroundColor: `color-mix(in srgb, ${customColors[item.color as HighlightColor] || item.color} calc(var(--overlayer-highlight-opacity, 0.3) * 100%), transparent)`,
                        }
                      : {}),
                    ...(item.style === 'underline' || item.style === 'squiggly'
                      ? {
                          textDecorationColor: `color-mix(in srgb, ${customColors[item.color as HighlightColor] || item.color} 80%, transparent)`,
                        }
                      : {}),
                  } as React.CSSProperties
                }
              >
                {text || (item.type === 'ink' ? _('Drawing') : '')}
              </span>
            </div>
          </div>
        </div>
      </div>
      {/* eslint-disable-next-line jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions */}
      <div
        className={clsx(
          'max-h-0 overflow-hidden p-0',
          'transition-[max-height] duration-300 ease-in-out',
          'group-focus-within:overflow-visible',
          isEditable ? 'group-focus-within:max-h-12' : 'group-focus-within:max-h-8',
          revealOnHover && 'group-hover:overflow-visible',
          revealOnHover && (isEditable ? 'group-hover:max-h-12' : 'group-hover:max-h-8'),
        )}
        style={
          {
            '--bottom-override': 0,
          } as React.CSSProperties
        }
        // This is needed to prevent the parent onClick from being triggered
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className={clsx(
            'flex cursor-default items-center justify-between py-2',
            isEditable && 'flex-col',
          )}
        >
          <div className='flex w-full items-center gap-1 truncate'>
            <span className='truncate text-sm text-gray-500 sm:text-xs'>
              {item.page ? _('p {{page}}' + ' · ', { page: item.page }) : ''}
            </span>
            <BooknoteTimeLabel createdAt={item.createdAt} />
          </div>
          <div
            className={clsx('flex items-center justify-end gap-4', isEditable && 'w-full')}
            dir='ltr'
          >
            <button
              onClick={handleCopyLink}
              className={clsx(
                'btn btn-ghost btn-xs text-base-content p-0 opacity-0 transition duration-300 ease-in-out hover:border-transparent hover:bg-transparent',
                actionButtonReveal,
              )}
              aria-label={_('Copy')}
            >
              <MdContentCopy size={size18} />
            </button>

            <button
              onClick={deleteNote.bind(null, item)}
              className={clsx(
                'btn btn-ghost btn-xs p-0 text-red-500 opacity-0 transition duration-300 ease-in-out hover:border-transparent hover:bg-transparent',
                actionButtonReveal,
              )}
              aria-label={_('Delete')}
            >
              <MdDelete size={size18} />
            </button>

            {isEditable && (
              <button
                onClick={
                  item.type === 'bookmark'
                    ? editBookmark
                    : inlineNoteEditing
                      ? editNoteInline
                      : editNote.bind(null, item)
                }
                className={clsx(
                  'btn btn-ghost btn-xs p-0 text-blue-500 opacity-0 transition duration-300 ease-in-out hover:border-transparent hover:bg-transparent',
                  actionButtonReveal,
                )}
                aria-label={item.note || item.type === 'bookmark' ? _('Edit') : _('Add Note')}
              >
                <MdEdit size={size18} />
              </button>
            )}
          </div>
        </div>
      </div>
    </li>
  );
};

// Memoize: BooknoteView re-renders on every progress tick / config change.
// Without React.memo each tick would re-render every visible note row even
// though their props are unchanged. Default shallow compare is enough since
// `item` and `onClick` are stable references from the parent's useMemo /
// useCallback.
export default React.memo(BooknoteItem);
