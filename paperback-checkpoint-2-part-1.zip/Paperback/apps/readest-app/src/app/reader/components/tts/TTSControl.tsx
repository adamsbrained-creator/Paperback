import clsx from 'clsx';
import React, { useEffect, useRef, useState } from 'react';
import { useThemeStore } from '@/store/themeStore';
import { useReaderStore } from '@/store/readerStore';
import { useTranslation } from '@/hooks/useTranslation';
import { useTTSControl } from '@/app/reader/hooks/useTTSControl';
import { useTTSDownloads } from '@/app/reader/hooks/useTTSDownloads';
import { Insets } from '@/types/misc';
import { eventDispatcher } from '@/utils/event';
import TTSMiniPlayer from './TTSMiniPlayer';
import TTSPlayerSheet from './TTSPlayerSheet';
import { useMiniPlayerAutoHide } from './useMiniPlayerAutoHide';

interface TTSControlProps {
  bookKey: string;
  gridInsets: Insets;
}

const TTSControl: React.FC<TTSControlProps> = ({ bookKey, gridInsets }) => {
  const _ = useTranslation();
  const { safeAreaInsets } = useThemeStore();
  const { getViewSettings } = useReaderStore();

  const [showPlayerSheet, setShowPlayerSheet] = useState(false);
  const backButtonTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [shouldMountBackButton, setShouldMountBackButton] = useState(false);
  const [isBackButtonVisible, setIsBackButtonVisible] = useState(false);

  const tts = useTTSControl({
    bookKey,
    onRequestHidePanel: () => setShowPlayerSheet(false),
  });

  const downloads = useTTSDownloads(
    bookKey,
    tts.getController,
    showPlayerSheet,
    tts.ttsClientsInited,
  );
  const activeSectionIndex = tts.ttsSectionIndex;

  const viewSettings = getViewSettings(bookKey);
  const isEink = viewSettings?.isEink ?? false;
  const playerStyle = viewSettings?.ttsPlayerStyle ?? 'full';
  const hasTimeline = tts.ttsClientsInited && tts.handleSupportsPlaybackInfo();
  const audioTransport = tts.ttsClientsInited && tts.audioTransport;
  const miniPlayerMounted = tts.showIndicator && !showPlayerSheet;
  const buffering = !tts.ttsClientsInited || tts.buffering;
  const miniPlayerVisible = useMiniPlayerAutoHide(
    bookKey,
    playerStyle,
    miniPlayerMounted,
    buffering,
  );

  useEffect(() => {
    if (tts.showBackToCurrentTTSLocation) {
      setShouldMountBackButton(true);
      const fadeInTimeout = setTimeout(() => {
        setIsBackButtonVisible(true);
      }, 10);
      return () => clearTimeout(fadeInTimeout);
    } else {
      setIsBackButtonVisible(false);
      if (backButtonTimeoutRef.current) {
        clearTimeout(backButtonTimeoutRef.current);
      }
      backButtonTimeoutRef.current = setTimeout(() => {
        setShouldMountBackButton(false);
      }, 300);
      return;
    }
  }, [tts.showBackToCurrentTTSLocation]);

  // The full player opens whenever the mini player shows, even while the
  // clients initialize: it fills in its voices once they are ready.
  const handleExpand = () => {
    tts.refreshTtsLang();
    setShowPlayerSheet(true);
  };

  const handleStop = () => {
    eventDispatcher.dispatch('tts-stop', { bookKey });
  };

  return (
    <>
      {shouldMountBackButton && (
        <div
          className={clsx(
            'absolute left-1/2 top-0 z-50 -translate-x-1/2',
            'transition-opacity duration-300',
            isBackButtonVisible ? 'opacity-100' : 'opacity-0',
            safeAreaInsets?.top ? '' : 'py-1',
          )}
          style={{
            top: `${safeAreaInsets?.top || 0}px`,
          }}
        >
          <button
            onClick={tts.handleBackToCurrentTTSLocation}
            className={clsx(
              'not-eink:bg-base-300 eink-bordered whitespace-nowrap rounded-full px-4 py-2 font-sans text-sm shadow-lg',
              safeAreaInsets?.top ? 'h-11' : 'h-9',
            )}
          >
            {_('Back to Read Aloud')}
          </button>
        </div>
      )}
      {/* One surface at a time: the sheet replaces the mini player while open.
          Mounts on showIndicator alone so the card appears the moment the
          session starts, before the TTS clients finish initializing. */}
      {miniPlayerMounted && (
        <TTSMiniPlayer
          bookKey={bookKey}
          isPlaying={tts.isPlaying}
          buffering={buffering}
          isEink={isEink}
          visible={miniPlayerVisible}
          hasTimeline={hasTimeline}
          audioTransport={audioTransport}
          timeoutTimestamp={tts.timeoutTimestamp}
          chapterRemainingSec={tts.chapterRemainingSec}
          gridInsets={gridInsets}
          onTogglePlay={tts.handleTogglePlay}
          onBackward={tts.handleBackward}
          onForward={tts.handleForward}
          onStop={handleStop}
          onExpand={handleExpand}
          onGetPlaybackInfo={tts.handleGetPlaybackInfo}
        />
      )}
      {showPlayerSheet && (
        <TTSPlayerSheet
          bookKey={bookKey}
          isOpen={showPlayerSheet}
          clientsReady={tts.ttsClientsInited}
          ttsLang={tts.ttsLang}
          isPlaying={tts.isPlaying}
          hasTimeline={hasTimeline}
          audioTransport={audioTransport}
          timeoutOption={tts.timeoutOption}
          timeoutTimestamp={tts.timeoutTimestamp}
          chapterRemainingSec={tts.chapterRemainingSec}
          onClose={() => setShowPlayerSheet(false)}
          onTogglePlay={tts.handleTogglePlay}
          onBackward={tts.handleBackward}
          onForward={tts.handleForward}
          loopState={tts.loopState}
          onToggleLoop={tts.handleToggleLoop}
          onGetLyricLoopRange={tts.handleGetLyricLoopRange}
          onSetRate={tts.handleSetRate}
          onGetVoices={tts.handleGetVoices}
          onSetVoice={tts.handleSetVoice}
          onGetVoiceId={tts.handleGetVoiceId}
          onSelectTimeout={tts.handleSelectTimeout}
          onSeek={tts.handleSeekTo}
          onSeekPreview={tts.handleSeekPreview}
          onGetPlaybackInfo={tts.handleGetPlaybackInfo}
          supportsLyrics={tts.supportsLyrics}
          buffering={tts.buffering}
          onGetLyrics={tts.handleGetLyrics}
          onGetActiveIndex={tts.handleGetLyricActiveIndex}
          onGetLyricPage={tts.handleGetLyricPage}
          onPlayFromLyric={tts.handlePlayFromLyric}
          downloads={downloads}
          activeSectionIndex={activeSectionIndex}
        />
      )}
    </>
  );
};

export default TTSControl;
