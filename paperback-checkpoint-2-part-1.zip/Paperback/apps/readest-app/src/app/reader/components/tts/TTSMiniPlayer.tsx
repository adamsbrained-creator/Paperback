import clsx from 'clsx';
import { useLayoutEffect, useState } from 'react';
import {
  MdAlarm,
  MdClose,
  MdKeyboardArrowLeft,
  MdKeyboardArrowRight,
  MdKeyboardDoubleArrowLeft,
  MdKeyboardDoubleArrowRight,
  MdOutlinePause,
  MdPauseCircleFilled,
  MdPlayArrow,
  MdPlayCircleFilled,
  MdSkipNext,
  MdSkipPrevious,
} from 'react-icons/md';
import { RiForward30Line, RiReplay15Line } from 'react-icons/ri';
import { Insets } from '@/types/misc';
import { useEnv } from '@/context/EnvContext';
import { useReaderStore } from '@/store/readerStore';
import { useBookProgress } from '@/store/readerProgressStore';
import { useBookDataStore } from '@/store/bookDataStore';
import { useThemeStore } from '@/store/themeStore';
import { useResponsiveSize } from '@/hooks/useResponsiveSize';
import { useTranslation } from '@/hooks/useTranslation';
import { formatCompactTime, formatPlaybackTime } from '@/utils/time';
import { isForcedMobileLayout } from '../../utils/mobileLayout';
import { TTSPlaybackInfo, usePlaybackInfo } from './usePlaybackInfo';
import { useCountdownLabel } from './useCountdownLabel';
import { formatRate } from './SpeedRuler';
import BufferingRing from './BufferingRing';
import { getTTSMiniPlayerBottomOffset } from '../../utils/ttsMiniPlayerPosition';

// Playback-settings glyph: a hex nut whose top-right edge is left open so
// the current speed sits in the gap (podcast-player convention). The number
// juts past the icon box on purpose; the button reserves room for it.
const SpeedSettingsIcon = ({ size, label }: { size: number; label: string }) => (
  <span className='relative inline-flex shrink-0'>
    <svg
      width={size}
      height={size}
      viewBox='0 0 24 24'
      fill='none'
      stroke='currentColor'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
      aria-hidden='true'
    >
      {/* Edges numbered clockwise from the top: the path starts two thirds
          into edge 2 (only its trailing third draws), runs through edges
          3-6, and stops at edge 1's midpoint (only its leading half draws).
          The opening between the two partial edges carries the speed label. */}
      <path d='M19.33 9.46 L20.8 12 L16.4 19.62 L7.6 19.62 L3.2 12 L7.6 4.38 L12 4.38' />
      <circle cx='12' cy='12' r='3.2' />
    </svg>
    <span className='absolute start-[56%] top-[5%] text-[9px] font-semibold leading-none tabular-nums'>
      {label}
    </span>
  </span>
);

type TTSMiniPlayerProps = {
  bookKey: string;
  isPlaying: boolean;
  // Playing, but nothing audible yet — the play/pause button wears a ring.
  buffering: boolean;
  isEink: boolean;
  visible: boolean;
  hasTimeline: boolean;
  // A paired audiobook has no sentences to step by: the small step is the
  // audiobook player's 30s forward / 15s back skip and the large step moves
  // by audiobook chapter, with the glyphs and labels of an audio player
  // (#5863).
  audioTransport: boolean;
  timeoutTimestamp: number;
  chapterRemainingSec: number | null;
  gridInsets: Insets;
  onTogglePlay: () => void;
  onBackward: (byMark: boolean) => void;
  onForward: (byMark: boolean) => void;
  onStop: () => void;
  onExpand: () => void;
  onGetPlaybackInfo: () => TTSPlaybackInfo | null;
};

// Mini-player shown while a TTS session is active: passive progress line with
// buffer-ahead fill on the card's bottom edge and, per the ttsPlayerStyle
// setting, one of two card layouts. 'full' (the default) is the 0.11.18 card:
// book cover, book title, chapter + timestamps line, and a sentence-only
// transport with a filled play blob; it rides with the reader chrome and fades
// out with it (see useMiniPlayerAutoHide). 'minimal' is chrome-free — no cover,
// no titles, plain glyphs — showing the remaining time alone plus the same
// paragraph/sentence transport vocabulary as the full player sheet (#5101 —
// the paragraph skips matter to eyes-off listeners); it stays up for the whole
// session, which is why it is the style that reserves a band of book text.
const TTSMiniPlayer = ({
  bookKey,
  isPlaying,
  buffering,
  isEink,
  visible,
  hasTimeline,
  audioTransport,
  timeoutTimestamp,
  chapterRemainingSec,
  gridInsets,
  onTogglePlay,
  onBackward,
  onForward,
  onStop,
  onExpand,
  onGetPlaybackInfo,
}: TTSMiniPlayerProps) => {
  const _ = useTranslation();
  const { appService } = useEnv();
  const isIPhoneDuo = useThemeStore((s) => s.isIPhoneDuo);
  const { hoveredBookKey, setHoveredBookKey, getViewSettings, bottomBarTab } = useReaderStore();
  const { getBookData } = useBookDataStore();
  const progress = useBookProgress(bookKey);
  const playback = usePlaybackInfo({ bookKey, isEink, onGetPlaybackInfo });
  const timerLabel = useCountdownLabel(timeoutTimestamp);
  const iconSize14 = useResponsiveSize(14);
  const iconSize20 = useResponsiveSize(20);
  const iconSize26 = useResponsiveSize(26);
  const iconSize28 = useResponsiveSize(28);
  const iconSize40 = useResponsiveSize(40);

  const book = getBookData(bookKey)?.book;
  const sectionLabel = progress?.sectionLabel;

  // Stack above whatever occupies the bottom edge: the bottom bar (or its
  // expanded action panel) while it is shown, the footer info band once it is
  // dismissed, or a 16px resting offset. Mirrors FooterBar's mobile/desktop
  // layout split (see forceMobileLayout there) to pick the right bar height.
  const viewSettings = getViewSettings(bookKey);
  const barVisible = hoveredBookKey === bookKey;
  const safeAreaMargin = appService?.hasSafeAreaInset ? gridInsets.bottom * 0.33 : 0;
  const forceMobileLayout = isForcedMobileLayout(appService?.isMobile, isIPhoneDuo);
  const usesMobileBar = forceMobileLayout || window.innerWidth < 640 || window.innerHeight < 640;

  // A book can carry a coverImageUrl that no longer resolves (cover never
  // extracted, file pruned). Showing the browser's broken-image glyph in the
  // card is worse than showing no cover at all.
  const [coverFailed, setCoverFailed] = useState(false);

  const [panelTopOffset, setPanelTopOffset] = useState(0);
  useLayoutEffect(() => {
    const cell = document.getElementById(`gridcell-${bookKey}`);
    const footer = barVisible ? cell?.querySelector<HTMLElement>('.footer-bar') : null;
    if (!cell || !footer) {
      setPanelTopOffset(0);
      return;
    }
    const panel = bottomBarTab
      ? footer.querySelector<HTMLElement>(`.footerbar-${bottomBarTab}-mobile`)
      : null;
    const measure = () => {
      // offsetTop ignores both the footer's slide and the panel's CSS translate.
      // A fixed footer uses viewport coordinates; an absolute footer is relative
      // to its offset parent (the book cell, including when a sidebar is pinned).
      const parent = footer.offsetParent;
      const footerTop =
        footer.offsetTop + (parent ? parent.getBoundingClientRect().top + parent.clientTop : 0);
      const settledTop = panel?.getBoundingClientRect().height
        ? footerTop + footer.clientTop + panel.offsetTop
        : footerTop;
      setPanelTopOffset(
        Math.max(0, Math.round(cell.getBoundingClientRect().bottom - settledTop - safeAreaMargin)),
      );
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(cell);
    observer.observe(footer);
    if (panel) observer.observe(panel);
    return () => observer.disconnect();
  }, [barVisible, bottomBarTab, bookKey, safeAreaMargin]);

  const bottomOffset = viewSettings
    ? getTTSMiniPlayerBottomOffset(viewSettings, { barVisible, usesMobileBar, panelTopOffset })
    : 16;
  const playerStyle = viewSettings?.ttsPlayerStyle ?? 'full';

  const { ready, position, total, measuredFraction } = playback;
  const forceHours = total >= 3600;
  const playedPct = ready && total > 0 ? Math.min((position / total) * 100, 100) : 0;
  const bufferedPct = ready ? Math.max(playedPct, Math.min(measuredFraction, 1) * 100) : 0;
  const remainingSec = Math.max(total - position, 0);
  // The full style keeps the 0.11.18 "elapsed · -remaining" string. The minimal
  // style shows the remaining time alone, compactly (#5310): elapsed is the
  // half nobody listens by, and dropping it stops the pair from being chopped
  // off at anything but the smallest UI font size.
  const elapsedLabel = hasTimeline && ready ? formatPlaybackTime(position, forceHours) : '';
  const remainingLabel =
    hasTimeline && ready ? `-${formatPlaybackTime(remainingSec, forceHours)}` : '';
  // Books with no playback timeline fall back to the chapter estimate. The
  // full style has room to say what the number means; the minimal style spends
  // its one slot on the number alone, in the same counting-down form as the
  // timeline case so the two never read as different quantities.
  const chapterLabel =
    chapterRemainingSec !== null
      ? _('{{time}} left in chapter', { time: formatPlaybackTime(chapterRemainingSec) })
      : '';
  const timeLabel = elapsedLabel ? `${elapsedLabel} · ${remainingLabel}` : chapterLabel;
  const compactLabel =
    hasTimeline && ready
      ? `-${formatCompactTime(remainingSec)}`
      : chapterRemainingSec !== null
        ? `-${formatCompactTime(chapterRemainingSec)}`
        : '';

  return (
    <div
      role='status'
      aria-label={`${_('Reading aloud')}: ${book?.title ?? ''}`}
      className={clsx(
        'absolute z-40 inset-x-4 sm:inset-x-0 sm:mx-auto sm:w-full sm:max-w-md',
        'transition-[bottom,opacity] duration-300',
        visible ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-0',
      )}
      style={{
        bottom: `${bottomOffset}px`,
        marginBottom: `${safeAreaMargin}px`,
        // iPhone Duo's status-bar strip reports as a large left/right inset
        // (#6307); clear it without losing the card's inset-x-4 margin. Width
        // auto so the card fits between the offsets in a book cell narrower
        // than max-w-md plus the strip (two books side by side).
        ...(isIPhoneDuo
          ? {
              left: `${16 + gridInsets.left}px`,
              right: `${16 + gridInsets.right}px`,
              width: 'auto',
            }
          : {}),
      }}
      onMouseEnter={() => !appService?.isMobile && setHoveredBookKey('')}
      onTouchStart={() => !appService?.isMobile && setHoveredBookKey('')}
    >
      <div className='not-eink:bg-base-300 eink-bordered relative overflow-hidden rounded-2xl shadow-lg'>
        {hasTimeline && (
          // E-ink has no legible grey tints: delineate the track with a crisp
          // 1px hairline, drop the buffer fill, and paint progress solid.
          <div
            aria-hidden='true'
            className={clsx(
              'audio-track not-eink:bg-neutral-content/15 absolute inset-x-0 bottom-0 h-[3px]',
              'eink:bg-base-100 eink:border-base-content eink:border-t eink:h-[5px]',
            )}
          >
            <div
              className='audio-buffered-part bg-base-content/35 eink:hidden absolute inset-y-0 left-0'
              style={{ width: `${bufferedPct}%` }}
            />
            <div
              className='audio-played-part not-eink:bg-primary eink:bg-base-content absolute inset-y-0 left-0'
              style={{ width: `${playedPct}%` }}
            />
          </div>
        )}
        {playerStyle === 'full' ? (
          <div className='text-base-content flex h-14 items-center gap-1 px-2'>
            <div
              role='button'
              tabIndex={0}
              onClick={onExpand}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') onExpand();
              }}
              aria-label={_('Open Read Aloud player')}
              className='flex min-w-0 flex-1 cursor-pointer items-center gap-2'
            >
              {book?.coverImageUrl && !coverFailed ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={book.coverImageUrl}
                  alt=''
                  className='h-10 w-10 shrink-0 rounded-lg object-cover'
                  onError={() => setCoverFailed(true)}
                />
              ) : null}
              <div className='flex min-w-0 flex-col'>
                <span className='truncate text-sm'>{book?.title ?? ''}</span>
                {(sectionLabel || timeLabel) && (
                  <span className='text-base-content/70 truncate text-xs tabular-nums'>
                    {[sectionLabel, timeLabel].filter(Boolean).join(' · ')}
                  </span>
                )}
              </div>
            </div>
            {timerLabel && (
              <span className='shrink-0 text-xs tabular-nums opacity-70'>{timerLabel}</span>
            )}
            <div dir='ltr' className='flex shrink-0 items-center gap-1'>
              <button
                type='button'
                className='shrink-0 rounded-full p-1'
                aria-label={audioTransport ? _('Back 15 Seconds') : _('Previous Sentence')}
                onClick={() => onBackward(true)}
              >
                {audioTransport ? (
                  <RiReplay15Line size={iconSize26} />
                ) : (
                  <MdSkipPrevious size={iconSize28} />
                )}
              </button>
              <button
                type='button'
                className='relative shrink-0 rounded-full p-0.5'
                aria-label={isPlaying ? _('Pause') : _('Play')}
                aria-busy={buffering}
                onClick={onTogglePlay}
              >
                {isPlaying ? (
                  <MdPauseCircleFilled size={iconSize40} />
                ) : (
                  <MdPlayCircleFilled size={iconSize40} />
                )}
                {/* Hugging the filled glyph: the drawn circle only fills about
                    five sixths of the icon box, so the ring tracks the box
                    rather than standing off from it. */}
                {buffering && <BufferingRing size={iconSize40 - 2} isEink={isEink} />}
              </button>
              <button
                type='button'
                className='shrink-0 rounded-full p-1'
                aria-label={audioTransport ? _('Forward 30 Seconds') : _('Next Sentence')}
                onClick={() => onForward(true)}
              >
                {audioTransport ? (
                  <RiForward30Line size={iconSize26} />
                ) : (
                  <MdSkipNext size={iconSize28} />
                )}
              </button>
              <button
                type='button'
                className='shrink-0 rounded-full p-1'
                aria-label={_('Stop reading aloud')}
                onClick={onStop}
              >
                <MdClose size={iconSize20} />
              </button>
            </div>
          </div>
        ) : (
          // A symmetric transport (#5636): one between-spread row whose item
          // widths mirror about the middle -- a fixed box at each end, two skip
          // glyphs each side -- so the equal gaps land the play glyph on the
          // card's exact midpoint, where it doubles as a halfway mark against
          // the progress line on the bottom edge, and the remaining time sits
          // on the far right where it hangs over the un-played part of that
          // line. The spreading is also what keeps "<<" and "<" from being
          // mistaken for each other on a phone (#5310). The row is dir=ltr
          // because the progress line it annotates fills physically
          // left-to-right.
          <div dir='ltr' className='text-base-content flex h-14 items-center justify-between px-3'>
            {/* Visible route into the full player: a settings glyph carrying
                the live speed as a superscript (the sheet is where speed and
                voice live). The time text expands too, but text alone reads
                as a label, not an affordance. */}
            <button
              type='button'
              aria-label={_('Playback settings')}
              onClick={onExpand}
              className='text-base-content/70 flex w-14 shrink justify-center rounded-full p-1'
            >
              <SpeedSettingsIcon
                size={iconSize26}
                label={formatRate(viewSettings?.ttsRate ?? 1.0)}
              />
            </button>
            <button
              type='button'
              className='shrink-0 rounded-full p-1'
              aria-label={audioTransport ? _('Previous Chapter') : _('Previous Paragraph')}
              onClick={() => onBackward(false)}
            >
              {audioTransport ? (
                <MdSkipPrevious size={iconSize26} />
              ) : (
                <MdKeyboardDoubleArrowLeft size={iconSize26} />
              )}
            </button>
            <button
              type='button'
              className='shrink-0 rounded-full p-1'
              aria-label={audioTransport ? _('Back 15 Seconds') : _('Previous Sentence')}
              onClick={() => onBackward(true)}
            >
              {audioTransport ? (
                <RiReplay15Line size={iconSize26} />
              ) : (
                <MdKeyboardArrowLeft size={iconSize26} />
              )}
            </button>
            <button
              type='button'
              className='relative shrink-0 rounded-full p-1'
              aria-label={isPlaying ? _('Pause') : _('Play')}
              aria-busy={buffering}
              onClick={onTogglePlay}
            >
              {/* Same canvas size for both glyphs, or the row shifts on toggle. */}
              {isPlaying ? <MdOutlinePause size={iconSize26} /> : <MdPlayArrow size={iconSize26} />}
              {buffering && <BufferingRing size={iconSize26 + 8} isEink={isEink} />}
            </button>
            <button
              type='button'
              className='shrink-0 rounded-full p-1'
              aria-label={audioTransport ? _('Forward 30 Seconds') : _('Next Sentence')}
              onClick={() => onForward(true)}
            >
              {audioTransport ? (
                <RiForward30Line size={iconSize26} />
              ) : (
                <MdKeyboardArrowRight size={iconSize26} />
              )}
            </button>
            {/* No stop button on purpose (#5310): five transport glyphs already
                crowd a phone, and an accidental hit on a sixth ends the
                session. Stopping lives on the same toolbar TTS button that
                started it. */}
            <button
              type='button'
              className='shrink-0 rounded-full p-1'
              aria-label={audioTransport ? _('Next Chapter') : _('Next Paragraph')}
              onClick={() => onForward(false)}
            >
              {audioTransport ? (
                <MdSkipNext size={iconSize26} />
              ) : (
                <MdKeyboardDoubleArrowRight size={iconSize26} />
              )}
            </button>
            <div
              role='button'
              tabIndex={0}
              onClick={onExpand}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') onExpand();
              }}
              aria-label={_('Open Read Aloud player')}
              className='flex w-14 min-w-0 cursor-pointer flex-col items-center justify-center gap-0.5'
            >
              {/* A fixed 4rem box matching the settings glyph's, not a flexible
                  or content-sized one: the latter would re-position every glyph
                  each time the label changes width ("-9:59" -> "-10:00"), and
                  the mirrored pair is what keeps the play glyph centered.
                  Scales with the UI font since both the box and the text are
                  rem-based (#5310). Default shrink is deliberate: on a tiny
                  card at a large font scale the box gives way and the label
                  truncates, rather than pushing a transport glyph off the
                  edge. An armed sleep timer stacks on its own line so it can
                  never squeeze the time into truncation. */}
              {compactLabel && (
                // max-w-full is load-bearing: a nowrap span is a flex item in a
                // column, and without it the cross size resolves to the text's
                // width and spills over the transport instead of truncating.
                <span className='text-base-content max-w-full truncate text-sm font-medium tabular-nums'>
                  {compactLabel}
                </span>
              )}
              {timerLabel && (
                <span className='text-base-content/60 flex shrink-0 items-center gap-0.5 text-xs tabular-nums'>
                  <MdAlarm size={iconSize14} aria-hidden='true' />
                  {timerLabel}
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TTSMiniPlayer;
