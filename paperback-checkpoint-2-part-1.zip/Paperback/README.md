# Paperback

A personal ebook reader for Android: its own design (coral, black and white; Outfit and Newsreader), reading stats,
goals and history, notes and bookmarks, favorites, ratings, wishlist, collections, dictionary and backup. The
reading engine comes from Readest; everything about accounts, cloud and paid services has been cut out.

## What is in it

- **Stays:** the reader, Discover (OPDS catalogs), read aloud, dictionaries, Word Lens, the audiobooks player, speed
  reading, highlights and notes, statistics, import and backup, Nearby BookDrop, Pagebound, clip-a-web-page-to-EPUB.
- **Gone:** Readest Cloud and all sync, sign-in, payments, the AI assistant, the translator, and the Hardcover,
  Audiobookshelf, Notion, Readwise, KOReader and file-sync connections.
- See `CHANGELOG.md` for what each version changed and where to look on the phone.

## Layout

| Path | What it is |
|---|---|
| `apps/readest-app/src` | The app (Next.js). Paperback's screens are in `app/(paperback)`, `app/stats`, `components/paperback` |
| `apps/readest-app/src-tauri` | The Android shell (Rust, Tauri v2) |
| `packages/` | Code packages downloaded at build time (see below) |
| `submodules.txt` | Which packages, from where, at which version |
| `scripts/fetch-submodules.sh` | Downloads them |
| `data/icons` | Launcher icon |
| `apps/readest-app/data/wordlens` | Word Lens data |
| `apps/readest-app/src/components/paperback/platform.ts` | The one file through which Paperback's screens import the reader engine |

## Building

1. `bash scripts/fetch-submodules.sh` (downloads `packages/*` and two plugins; about 7 seconds)
2. `pnpm install`
3. The Android build and signing step, as in your `android.yml`

The GitHub workflow has to be changed to match: **remove** the step that downloads Readest and the step that runs
`apply.mjs`, and **add** step 1 above before `pnpm install`. Everything else in the workflow stays.

## What was not checked

The cut was done without being able to install packages or compile (the work environment has no access to the
package registries). It was checked by type-checking the whole app against the original, which found and fixed
the references to removed code it could see. The type-check could not see inside React hook results (the React
types were not installable), so a leftover there would only show up in a real build or on the phone. The first
real build is the next test; if it fails, send the log of the red step.
