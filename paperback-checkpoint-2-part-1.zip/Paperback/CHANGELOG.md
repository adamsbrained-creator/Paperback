# What changed, build by build

## Readest's name out of the app, shorter build (this version)
- **Text:** the app now says Paperback instead of Readest in the About window, the app lock, the quote cards
  ("via Paperback"), annotation export/import, the share and nearby-sharing screens, the widget, the web-clip
  messages and the page titles, in English and in all 34 translations. Kept on purpose, because they are true:
  "Help improve Readest" and its consent text (the opt-in analytics still go to Readest's service, off by default),
  and the two OPDS messages about Readest's web proxy. The About window keeps the credit to Readest, the AGPL
  notice and the link to Readest's source; its Readest terms/privacy/community links are gone.
- **Android:** the Readest web link (web.readest.com) no longer opens Paperback, and the theme is named
  Theme.paperback. The `readest://` link scheme is still registered (renaming it touches the link code).
- **Removed files:** the Apple project (`src-tauri/gen/apple`), the macOS signing profiles and the macOS-only config.
  The Android build never used them.
- **Build:** the workflow now builds only the APK (`--apk`). Before, it also built a Play Store bundle (.aab) that
  nothing used, which compiled the Rust code a third time (about 5 minutes).

## Standalone: Readest is cut out of the repo
This repo is now the whole app. The build no longer downloads Readest and no longer runs `apply.mjs`.
- **Removed:** Readest Cloud and all sync, Send to Readest, BookOrbit link, sign-in/accounts, payments and
  subscriptions, the AI assistant, the translator (and its reader buttons), and the Hardcover, Audiobookshelf,
  Notion, Readwise, KOReader and file-sync (WebDAV, S3, Google Drive, OneDrive, iCloud) connections. The
  "Auto-Retrieve Metadata" button in the book editor went with them (it only worked through Readest's server).
  Source code went from about 246,000 to about 174,000 lines (-29%).
- **Kept:** the reader, Discover (OPDS), read aloud, dictionaries, Word Lens, the audiobooks player, speed reading,
  highlights and notes, statistics, import/backup, nearby sharing (Nearby BookDrop), Pagebound, clip-a-web-page-to-EPUB,
  and Readest's About page.
- **Settings:** Settings → Integrations now has three rows: OPDS Catalogs, Nearby BookDrop, Pagebound.
- **Build:** source maps are no longer produced, and the build step that uploaded them is gone.
  `scripts/fetch-submodules.sh` downloads the seven small code packages (foliate-js and others, listed in
  `submodules.txt`) at the exact versions this repo was cut from.
- **Build fix:** `packages/swift-rs` and `packages/tauri-runtime-cef-stub` (small folders from Readest's own repo that the
  root `Cargo.toml` patches in; they are not downloaded by `fetch-submodules.sh`) are now part of the repo. Without them
  the Android build stopped at `cargo build` ("patch location packages/swift-rs does not contain packages").
- **Also gone:** Readest's workflows, Docker/Nix files, the KOReader/Calibre/CrossPoint/browser-extension projects,
  release scripts for other stores, and the tests of removed code.
- **Not changed yet:** the Rust side (`src-tauri`) and the dependency lists (`package.json`, lockfiles). Nothing
  could be compiled or installed while cutting, so those are left for a build that can check them.

Newest first. Each entry says where to look on the phone.

## Signed builds and a build from a zip
- Builds are signed with one permanent key (`paperback.jks`), so a new APK installs over the old one without
  uninstalling. Uninstall once (the very first time with this key), see README → Set up, step 4.
- New workflow **Paperback APK from zip**: upload `paperback-repo.zip` to the repo and run it; no need to upload
  the files one by one. Works from a phone. See README → Building from a zip.
- The build log prints the key fingerprint and which key signed the APK. The unit-test step now also runs the
  Activity and Milestones tests.

## Menu: Library added, Dictionary moved to More
- The menu card now reads Home, **Library**, Discover, Collections, Bookmarks, Stats, Settings, More. Library opens
  your library (the same page as the Library tab) and uses the three-books icon. **Dictionary** is no longer in the
  card; it is still under More → Your notes. Code: `components/paperback/MenuSheet.tsx`.

## New app icon: three books
- The launcher icon is now the pink-coral gradient with three books and "paperback" underneath. It fills the whole
  square (Android cuts it to the phone's icon shape) and is drawn a little smaller so nothing is clipped by a round
  mask. The file is `data/icons/paperback.png`. The logo mark inside the app (headers, About) is unchanged for now.

## Stats: the Milestones page
- Stats → **Milestones** (second tab). Ten lifetime counters with five tiers each: Books Read, Pages Read, Reading
  Sessions, Reading Hours, Words Saved, Books Rated, Quotes Saved, Longest Streak, Epic Books (500+ pages) and
  Notes Written. Each card shows its tier dots, your number against the next tier, and a progress bar. Tap a card
  for its tiers sheet (the date each tier was unlocked, and how many are left for the next one).
- **Next up** (top card) is the milestone closest to its next tier. Books gets a shelf of spines, the others a bar.
  "about N days" appears when you have read or saved something toward it in the last 90 days.
- **Timeline** (next to Progress): when each tier was unlocked, plus firsts (first book added / finished, first
  quote, first note), books added (10, 25, 50, …) and your longest book, grouped by month, filter Books / Reading /
  Notes.
- Where the numbers come from: finished books and their dates from your library, pages / sessions / hours / streak
  from the reading statistics, quotes and notes from your highlights and notes, saved words and ratings from your
  shelves. Ratings are saved without a date, so Books Rated tiers show "Unlocked" instead of a date.
- The first time you open Milestones the app reads the notes of every book (a moment on a big library).
- The "What are milestones?" card remembers if you closed it.
- Code: `app/stats/components/MilestonesView.tsx`, `TierSheet.tsx`, `services/statistics/milestonesStats.ts` (with
  tests), `styles/paperback-milestones.css`.

## Stats overhaul: the Activity page
- Menu or tab bar → **Stats**. The page now has five tabs under the title: **Activity**, **Milestones**, **Books**,
  **History**, **Insights**. Activity and Milestones are built; the other three are empty pages for later.
- **Activity**, top to bottom: the reading chart (Time or Pages; Weekly, Monthly, Yearly or All time; the arrows or the
  date in the middle move to another week, month or year, and tapping the date opens a picker), streak / pages /
  finished, the daily goal ring with the last seven days, six detail tiles (pace, average session, sessions, longest
  session, best day, average a day), the 18-week reading rhythm, reading patterns (a 24-hour clock plus time of day and
  day of week, tap a slice for its count), and your most read books.
- The chart's dashed line and the daily goal use the minutes goal from **Reading goals** (default 30).
- **View sessions** (under the chart) opens every session by year and month, newest month open. Sessions now show the
  pages they covered. The older *Reading history* menu link opens this screen.
- **Reading goals** (daily goal card) opens the existing goals screen. The phone's back button returns to Activity.
- Gone: the old Stats / Goals / History tab strip and its Overview page (everything on it is now on Activity).
- Code: `app/stats/` (`page.tsx`, `components/ActivityView.tsx`, `PatternsCard.tsx`, `SessionsScreen.tsx`,
  `PeriodDialog.tsx`, `StatsNav.tsx`, `PlaceholderView.tsx`), `services/statistics/activityStats.ts` (all the numbers,
  with tests), `styles/paperback-stats.css`. Delete `app/stats/components/StatsView.tsx` and `HistoryView.tsx`.

## Less Readest in the build
- Readest's sign-in, account, subscription, share-link, updater and server (`api`) pages are no longer compiled
  into the app: about 15,000 lines. Nothing on the phone should look different. They were not reachable from
  Paperback, and the Android app is a static export that cannot run Readest's server routes anyway.
- If something that worked before now shows a blank or "not found" page, tell me which screen.

## Scrapbook links back to the book
- Everything sent to Scrapbook (a Journal note, a highlight, a note on a highlight) now ends with an **Open in Paperback**
  link. In Scrapbook, tap it and Paperback opens that book, at the highlighted passage when there is one.
- It uses Readest's own `readest://book/…` links, which Paperback already understood, so Paperback needed no new
  permission. The Scrapbook app needs the matching update (see the Scrapbook zip): it makes the link tappable and files
  things sent from Paperback in a **Paperback** box (made the first time).
- If the book is no longer in your library, Paperback says "Book not in your library".
- Code: `paperbackLink` in `services/paperback/scrapbook.ts` (tested against Readest's own link reader).

## Highlights → Scrapbook
- Menu → **Notes & highlights**: every card has a small round share button in its top right corner. The same button is
  on the cards on a book's **Journal** page.
- It opens the phone's share sheet; choose **Scrapbook** and its "Save to Scrapbook" screen opens with the text.
  A plain highlight arrives as a **Quote** scrap: "the passage" and, underneath, "— Author, Book, p. 12".
  A note you wrote arrives as a normal scrap: your note, then the passage, then the source.
- Without a share sheet the text is copied and a short message says so.
- Code: `SendToScrapbook.tsx`, `scrapbookHighlight` in `services/paperback/scrapbook.ts` (with tests).

## Journal → Scrapbook
- Home or Library → a book → **Journal** (the page with your note): under *My note* there is now **Send to Scrapbook**.
  It opens the phone's share sheet with the book title, your note and the author; choose **Scrapbook** and its
  "Save to Scrapbook" screen opens with it (the book title becomes the scrap's title; pick the box and Save).
- The button is greyed out while the note is empty. It sends what is in the box, saved or not.
- Needs the Scrapbook app installed. Without a share sheet the text is copied instead.
- Code: `shareToApps` in `platform.ts` (Readest's share plugin), `services/paperback/scrapbook.ts`.

## Paperback's own Library
- **Library** (menu → Library, or the Library tab) is built from the new designs, with the standard header (menu ·
  "paperback" · search, "Library" underneath and a "8 books" chip) that follows **Header size**:
  - **Shelves** (home layout): a *Continue reading* card, then *Also reading*, *Not started*, *Favorites* (an empty
    one explains how to add) and *Finished*. **See all** opens that shelf in *All books*.
  - **All books**: filter chips (All, Reading, Not started, Favorites, Finished), a sort menu (Recently opened,
    Recently added, Title, Author), grid or list, and **+** to import books. Back returns to the shelves.
  - **Tap** a book to read it; **press and hold** for the book sheet: Resume, Pin for today, Add to Favorites,
    Add to collection, Mark as finished, Book details, Remove from library (asks first).
  - **Empty library**: Import books and Discover free books.
  - Books without a cover get a drawn cover in a colour taken from the book.
- **Import** works inside Paperback (the + on All books, the Library's empty screen, or Settings → Library & import):
  pick several files at once.
- **Readest's Library is gone from the app.** Opening a file from another app, restoring the last books and links
  are handled by Paperback's own launch screen (`Boot`). Readest's library code is deleted before the build
  (about 16,000 lines), so building takes less.
- Authors → an author opens *All books* searched for that author. Settings → **Reader defaults** opens Readest's reader
  settings window. Backup & restore → *Back up or restore books and notes* opens Readest's backup window.
- **No longer available** (they lived only in Readest's Library): importing a whole folder, watched folders, cloud
  sync of the library, the transfer queue, send-to-Readest links, searching inside book text from Search, tagging
  and grouping books, and editing book details from the library. Ask when you want any of them back in Paperback's
  own style.

## Same header on every screen
- Screens now get Settings' header: round menu button, "paperback", round search button, and the screen's name
  underneath, plus the round menu button at the bottom right. It follows **Settings → App style → Header size**
  (Compact, Regular, Large), so changing the size changes it everywhere.
- On: Discover, Collections, a single collection (its name underneath), Book details, Bookmarks, Dictionary,
  Currently reading, Recently read, Finished, Authors, Notes & highlights, Search, Favorites, Wishlist, Genres,
  Import, Appearance (was "Themes") and Backup & restore (was "Backup"). Home and Stats keep their own headers,
  because they have their own designs.
- Home: the "p" mark next to the wordmark is gone, only "paperback" is left.
- A long title underneath is cut with "…" instead of wrapping.
- On the Search screen the header's search button puts the cursor in the search field.
- Code: `components/paperback/PageTop.tsx`; a screen opts in with `<Shell title='…' pageHeader>`.

## Discover (catalog browser) redesign
- Menu → Discover → pick a catalog: the "paperback" header with **Discover** under it, then the toolbar:
  back, forward, catalog home, a pill search field, add to My Catalogs (**+**) and close (**✕**). Disabled
  arrows are greyed. The round menu button and its pop-up are here too.
- Loading shows the coral spinner with "Loading…".
- Closing a catalog (✕ or Android Back at its first page) now returns to the Discover list instead of
  Readest's library.
- Feeds, book pages and search results are still Readest's, with the earlier soft cards and rounded covers;
  they will follow when you send their designs.
- Code: the toolbar is a copy of Readest's `Navigation.tsx` kept in `files/` (see `NOTICE.md`).

## New menu
- Tap the menu button (top left, or the round button at the bottom right): a small card pops up above the round
  button with Home, Discover, Collections, Bookmarks, Dictionary, Stats and Settings. The page you are on is
  highlighted with a coral dot, and the round button turns into a close button.
- **More** (last row, not in the design) opens the older full list, so Favorites, Wishlist, Authors, Genres,
  Recently read and Reading history stay reachable. Set `SHOW_MORE = false` in `MenuSheet.tsx` to remove it.

## About redesign
- Menu → Settings → About Paperback: the logo tile, a large "paperback" and "Version 1.0.0 · personal build",
  then **Credits** and **Open-source licenses** cards. The header follows your Header size.
- Until those two get their own pages, tapping a card opens its text in place (the old "Your data" note is
  inside Credits).

## Settings redesign + header size
- Menu → Settings looks like the new design: the **Daily goal** card (ring, minutes today, Edit), then Reading,
  Look and Library groups of rows, About, and a round menu button at the bottom right.
- Menu → Settings → **App style**: pick a **Header size** (Compact, Regular, Large) with a live sample of each.
  It is saved on the device. For now it changes the header on Settings and App style; other screens take it as
  they are redesigned.
- Placeholders that only keep the look: *Reader defaults* shows "Roboto · 16" and *Library & import* shows
  "Import, sync" (not read from real settings yet).

## New logo and icon set
- App icon: the **bookmark p** (logo A): white mark on coral. Launcher icon after installing.
- Header: the mark sits next to the "paperback" wordmark on Home and Library.
- Menu → Settings → About Paperback: the logo tile replaces the cover fan.
- Every icon in the app is now Paperback's own set (24 px grid, 1.9 px stroke, round ends) instead of
  Phosphor: tab bar, header buttons, Settings rows, search fields, bookmarks. The active tab fills in.
  Library uses the layers icon. Code: `components/paperback/icons.tsx` and `Logo.tsx`.

## Discover looks like Paperback
- Menu → Discover → pick Project Gutenberg (or any catalog): the page now starts with a serif **Discover**
  title and a Home button, the toolbar buttons are round chips, the search field is a pill, catalog
  entries are soft rounded cards and book covers are rounded with a soft shadow.
- Everything it does (browse, search, download into your library) is still Readest's.
- Newsreader (the serif font) is now available in the whole app, not only in the Paperback screens.

## Library list now belongs to Paperback
- Paperback keeps its own saved copy of your book list (`paperback.catalog.v1`), so Home, Library and
  Stats show instantly at launch instead of waiting for Readest to load. Tapping a book in the first
  moments says "still loading" instead of doing nothing.
- All screens use Paperback's own book type (`services/paperback/library.ts`); Readest's book object is
  only used to draw covers and open the reader (through `components/paperback/platform.ts`).
- **Check:** open the app with Wi-Fi on, close it fully, open it again: Home should appear at once.

## New app icon
- White square with "Paperback" in Outfit, like the Binder icon.

## Home layout: Pile
- Settings → Themes → **Home layout** → *Pile*: a heap of your recent covers with your latest note on top,
  a streak badge, and Reading / Finished shelves. *Classic* is the earlier layout.

## Library: Bento view
- A fifth view next to Shelf, Grid, List and Stacks: tiles for your latest covers, a progress tile and your
  latest highlights.

## Smaller changes
- Reader menu: the bottom dock sits on a page-coloured strip, so the "pages left" text no longer peeks out
  at its corners.
- Stats → Most read: percentages now say "% of time" (they are your share of reading time, not book progress).
- Build: frees disk space first (the last build ran out near the end); runs the new library tests.
