package com.paperback.app.catalog;

import java.util.Collections;
import java.util.List;

/** What the recommender needs to know about one of your books. */
public final class TasteBook {
    public final String title;
    public final String author;
    public final List<String> tags;
    /** Your rating, 0 = none. */
    public final int rating;
    /** 0..1 */
    public final double progress;
    public final boolean finished;
    public final boolean favorite;
    /** Dropped, or started a little a long time ago and left. */
    public final boolean dropped;
    /** On your Want to read list: interest in a book you have not read. */
    public final boolean wanted;
    /** A suggestion you said you are not interested in. */
    public final boolean dismissed;
    /** Days since you last touched it, 0 = not known. */
    public final int ageDays;

    public TasteBook(String title, String author, List<String> tags, int rating, double progress,
                     boolean finished, boolean favorite) {
        this(title, author, tags, rating, progress, finished, favorite, false, false, false, 0);
    }

    public TasteBook(String title, String author, List<String> tags, int rating, double progress,
                     boolean finished, boolean favorite, boolean dropped, boolean wanted, boolean dismissed,
                     int ageDays) {
        this.title = title == null ? "" : title;
        this.author = author == null ? "" : author;
        this.tags = tags == null ? Collections.<String>emptyList() : tags;
        this.rating = rating;
        this.progress = progress;
        this.finished = finished;
        this.favorite = favorite;
        this.dropped = dropped;
        this.wanted = wanted;
        this.dismissed = dismissed;
        this.ageDays = ageDays;
    }
}
