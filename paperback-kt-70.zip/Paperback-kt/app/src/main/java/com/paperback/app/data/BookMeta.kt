package com.paperback.app.data

import com.paperback.app.data.opds.OpdsText

/*
 * What Paperback knows about a book beyond its title: genres / tags, description, publisher, date.
 * Everything here is plain Kotlin (no Android), so it can be tested on its own.
 */

/** Extra facts about a book that a catalog already told us (Discover), used when the file itself says nothing. */
class ImportHints(
    val subjects: List<String> = emptyList(),
    val description: String? = null,
    val publisher: String? = null,
    val published: String? = null,
    /** Where the book came from ("file", "gutenberg", "standardebooks", "reflow", a catalog's name...); null = "file". */
    val source: String? = null,
)

/** The book facts read from a file (and the catalog), ready to store. */
class BookExtras(
    val tags: List<String>,
    val description: String,
    val publisher: String,
    val published: String,
)

object Tags {
    /** Words some catalogs use as a "subject" that say nothing about what the book is about. */
    private val noise = setOf(
        "text", "sound", "image", "dataset", "software", "collection", "service", "event",
        "moving image", "still image", "interactive resource", "physical object", "ebook", "e-book",
    )
    private val code = Regex("^[A-Z]{3}[0-9]{6}$|^[0-9][0-9. /-]*$")

    /**
     * Turns the raw subject lines of a book into short, clean tags.
     *  - "England -- Fiction" becomes two tags, "England" and "Fiction" (Project Gutenberg writes them that way)
     *  - lines with a colon ("LoCC: Language and Literatures"), subject codes and words like "Text" are dropped
     *  - the same tag in different capitals counts once; the first spelling is kept
     */
    fun clean(raw: List<String>, max: Int = 16): List<String> {
        val seen = LinkedHashMap<String, String>()
        for (line in raw) {
            for (piece in line.split(" -- ", "--", ";", "\n", "|")) {
                var s = piece.replace(Regex("\\s+"), " ").trim().trimEnd('.', ',', ' ')
                if (s.length < 2 || s.length > 40) continue
                if (s.contains(':')) continue
                if (code.matches(s)) continue
                val key = s.lowercase()
                if (key in noise) continue
                if (s[0].isLowerCase()) s = s.replaceFirstChar { it.uppercaseChar() }
                if (!seen.containsKey(key)) seen[key] = s
                if (seen.size >= max) return seen.values.toList()
            }
        }
        return seen.values.toList()
    }

    /** tag -> books that have it, most books first, then A to Z. */
    fun counts(books: List<Book>): List<Pair<String, Int>> {
        val map = LinkedHashMap<String, Pair<String, Int>>()
        for (b in books) for (t in b.tags) {
            val key = t.lowercase()
            val cur = map[key]
            map[key] = if (cur == null) t to 1 else cur.first to (cur.second + 1)
        }
        return map.values.sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first.lowercase() })
    }

    fun has(book: Book, tag: String): Boolean = book.tags.any { it.equals(tag, ignoreCase = true) }
}

object Authors {
    /** author -> number of books, most books first, then A to Z. Books with no author are left out. */
    fun counts(books: List<Book>): List<Pair<String, Int>> {
        val map = LinkedHashMap<String, Pair<String, Int>>()
        for (b in books) {
            val name = b.author.trim()
            if (name.isEmpty()) continue
            val key = name.lowercase()
            val cur = map[key]
            map[key] = if (cur == null) name to 1 else cur.first to (cur.second + 1)
        }
        return map.values.sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first.lowercase() })
    }

    /** True when [author] is the book's author, or one of them ("A; B" and "A & B" have two). */
    fun has(book: Book, author: String): Boolean {
        val want = author.trim()
        return book.author.trim().equals(want, ignoreCase = true) ||
            splitAuthors(book.author).any { it.equals(want, ignoreCase = true) }
    }
}

object BookText {
    private val summaryPart = Regex("Summary:\\s*(.+?)(?:\\n\\s*\\n[A-Z][A-Za-z ]{2,30}:|\\z)", RegexOption.DOT_MATCHES_ALL)
    private val autoNote = Regex("\\s*\\(This is an automatically generated summary\\.\\)", RegexOption.IGNORE_CASE)

    /**
     * A description as plain text. Project Gutenberg's "description" is the whole catalogue record (title, notes,
     * credits, reading level...); when it has a Summary part, only that part is kept.
     */
    fun description(raw: String?): String {
        val plain = OpdsText.plain(raw)
        if (plain.isEmpty()) return ""
        val found = summaryPart.find(plain)?.groupValues?.get(1)?.let { autoNote.replace(it, "").trim() }
        return if (!found.isNullOrEmpty()) found else plain
    }

    /** "1998-06-01T00:00:00Z" -> "1998-06-01"; anything else is kept as it is. */
    fun date(raw: String?): String {
        val s = raw?.trim().orEmpty()
        return if (Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}.*").matches(s)) s.take(10) else s
    }
}

/** Ways to order the Library. */
enum class BookSort(val label: String) {
    Added("Recently added"),
    Opened("Recently read"),
    Title("Title"),
    Author("Author"),
    Rating("Rating"),
    Progress("Progress"),
    Custom("My order"),
    ;

    fun apply(books: List<Book>): List<Book> = when (this) {
        Added -> books.sortedByDescending { it.addedAt }
        Opened -> books.sortedWith(compareByDescending<Book> { it.lastOpenedAt }.thenByDescending { it.addedAt })
        Title -> books.sortedBy { it.title.lowercase() }
        Author -> books.sortedWith(compareBy<Book> { it.author.isBlank() }.thenBy { it.author.lowercase() }.thenBy { it.title.lowercase() })
        Rating -> books.sortedWith(compareByDescending<Book> { it.rating10 }.thenBy { it.title.lowercase() })
        Progress -> books.sortedWith(compareByDescending<Book> { it.progress }.thenBy { it.title.lowercase() })
        // books you placed come first, in your order; the rest follow, newest first
        Custom -> books.sortedWith(compareBy<Book> { it.shelfOrder == 0 }.thenBy { it.shelfOrder }.thenByDescending { it.addedAt })
    }
}

/** A suggested [book] from your library; [because] is the book of yours behind it, [note] replaces "Because you liked ...". */
class Recommendation(val book: Book, val because: Book, val note: String? = null)

/** "Books like this one" and "Recommended for you", worked out only from your own library. */
object Similar {
    /** How alike two books are: shared tags (as a share of all their tags) and the same author. 0 = nothing in common. */
    fun score(a: Book, b: Book): Double {
        var s = 0.0
        val ta = a.tags.map { it.lowercase() }.toSet()
        val tb = b.tags.map { it.lowercase() }.toSet()
        if (ta.isNotEmpty() && tb.isNotEmpty()) {
            val shared = ta.intersect(tb).size
            if (shared > 0) s += 3.0 * shared / ta.union(tb).size
        }
        if (a.author.isNotBlank() && Authors.has(a, b.author)) s += 2.0
        return s
    }

    fun like(book: Book, books: List<Book>, limit: Int = 12): List<Book> =
        books.asSequence()
            .filter { it.id != book.id }
            .map { it to score(book, it) }
            .filter { it.second > 0.0 }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
            .toList()

    /** How much a book you have already read tells us you like this kind of book. */
    private fun taste(b: Book): Double {
        if (b.rating in 1..2 || b.status == BookStatus.DROPPED) return 0.0
        var w = 0.0
        if (b.rating >= 4) w += 3.0 else if (b.rating == 3) w += 1.0
        if (b.favorite) w += 2.0
        if (b.finished && b.rating == 0) w += 1.0
        return w
    }

    /**
     * The next unread book of each series you are working through: the one after the last you finished, as long
     * as you did not rate that one low and are not reading another of the series. The series you read last first.
     */
    fun nextInSeries(books: List<Book>, hidden: Set<String> = emptySet()): List<Recommendation> {
        val out = ArrayList<Pair<Recommendation, Long>>()
        val groups = books.filter { it.series.isNotBlank() && it.seriesNo > 0f }.groupBy { it.series.trim().lowercase() }
        for (group in groups.values) {
            val last = group.filter { it.finished }.maxByOrNull { it.seriesNo } ?: continue
            if (last.rating in 1..2) continue
            if (group.any { !it.finished && it.isReading && it.status != BookStatus.DROPPED }) continue
            val next = group
                .filter { !it.finished && it.seriesNo > last.seriesNo && it.status != BookStatus.DROPPED && it.id !in hidden }
                .minByOrNull { it.seriesNo } ?: continue
            out += Recommendation(next, last, "Next in ${next.series.trim()}") to maxOf(last.finishedAt, last.lastOpenedAt)
        }
        return out.sortedByDescending { it.second }.map { it.first }
    }

    /** Books you have not started, ranked by how much they resemble what you rated high, favorited or finished. */
    fun recommend(books: List<Book>, limit: Int = 10, hidden: Set<String> = emptySet()): List<Recommendation> {
        val next = nextInSeries(books, hidden)
        val liked = books.map { it to taste(it) }.filter { it.second > 0.0 }
        if (liked.isEmpty()) return next.take(limit)
        val out = ArrayList<Pair<Recommendation, Double>>()
        val taken = next.map { it.book.id }.toSet()
        for (c in books) {
            if (c.finished || c.isReading || c.lastOpenedAt > 0L || c.id in hidden || c.id in taken) continue
            var total = 0.0
            var best: Book? = null
            var bestGain = 0.0
            for ((l, w) in liked) {
                if (l.id == c.id) continue
                val gain = w * score(c, l)
                total += gain
                if (gain > bestGain) {
                    bestGain = gain
                    best = l
                }
            }
            if (total > 0.0 && best != null) out += Recommendation(c, best) to total
        }
        return (next + out.sortedByDescending { it.second }.map { it.first }).take(limit)
    }
}
