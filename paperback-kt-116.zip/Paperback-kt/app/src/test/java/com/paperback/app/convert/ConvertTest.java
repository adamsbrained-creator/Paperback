package com.paperback.app.convert;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.imageio.ImageIO;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class ConvertTest {
    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    private File write(String name, byte[] data) throws IOException {
        File f = tmp.newFile(name);
        FileOutputStream o = new FileOutputStream(f);
        o.write(data);
        o.close();
        return f;
    }

    private File zip(String name, String[] names, byte[][] data) throws IOException {
        File f = tmp.newFile(name);
        ZipOutputStream z = new ZipOutputStream(new FileOutputStream(f));
        for (int i = 0; i < names.length; i++) {
            z.putNextEntry(new ZipEntry(names[i]));
            z.write(data[i]);
            z.closeEntry();
        }
        z.close();
        return f;
    }

    private File convert(File in, String name) throws Exception {
        BookFormat f = BookFormat.detect(in, name);
        assertTrue(f.needsConversion());
        File out = tmp.newFile("out-" + System.nanoTime() + ".epub");
        BookConverter.convert(in, name, f, out);
        return out;
    }

    private String entry(File epub, String name) throws IOException {
        ZipFile z = new ZipFile(epub);
        try {
            InputStream in = z.getInputStream(z.getEntry(name));
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return new String(b.toByteArray(), "UTF-8");
        } finally {
            z.close();
        }
    }

    @Test
    public void textBecomesEpubWithChapters() throws Exception {
        String t = "My Story\n\nChapter 1\n\nHello there.\n\nChapter 2\n\nCafé again.\n";
        File out = convert(write("story.txt", t.getBytes("UTF-8")), "story.txt");
        assertEquals("application/epub+zip", entry(out, "mimetype"));
        String nav = entry(out, "OEBPS/nav.xhtml");
        assertTrue(nav, nav.contains("Chapter 1") && nav.contains("Chapter 2"));
    }

    @Test
    public void windows1251TextIsDecoded() throws Exception {
        byte[] b = "Привет, мир! Это текст на русском.".getBytes("windows-1251");
        File out = convert(write("ru.txt", b), "ru.txt");
        assertTrue(entry(out, "OEBPS/text/p0001.xhtml").contains("Привет"));
    }

    @Test
    public void fb2KeepsMetadata() throws Exception {
        String x = "<?xml version=\"1.0\" encoding=\"utf-8\"?><FictionBook xmlns=\"http://www.gribuser.ru/xml/fictionbook/2.0\"><description><title-info>"
                + "<author><first-name>Ann</first-name><last-name>Writer</last-name></author><book-title>Blue Book</book-title><lang>en</lang></title-info></description>"
                + "<body><section><title><p>One</p></title><p>Text.</p></section></body></FictionBook>";
        File out = convert(write("b.fb2", x.getBytes("UTF-8")), "b.fb2");
        String opf = entry(out, "OEBPS/content.opf");
        assertTrue(opf, opf.contains("Blue Book") && opf.contains("Ann Writer"));
    }

    @Test
    public void comicBecomesFixedLayout() throws Exception {
        BufferedImage img = new BufferedImage(20, 30, BufferedImage.TYPE_INT_RGB);
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        ImageIO.write(img, "png", b);
        File cbz = zip("c.cbz", new String[] {"p10.png", "p2.png"}, new byte[][] {b.toByteArray(), b.toByteArray()});
        File out = convert(cbz, "c.cbz");
        String opf = entry(out, "OEBPS/content.opf");
        assertTrue(opf.contains("pre-paginated"));
        assertTrue(entry(out, "OEBPS/text/p0001.xhtml").contains("p0001.png"));
    }

    @Test
    public void docxKeepsHeadingsAndText() throws Exception {
        String w = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"";
        String doc = "<w:document " + w + "><w:body><w:p><w:pPr><w:pStyle w:val=\"Heading1\"/></w:pPr><w:r><w:t>Intro</w:t></w:r></w:p>"
                + "<w:p><w:r><w:t>Body text.</w:t></w:r></w:p></w:body></w:document>";
        String styles = "<w:styles " + w + "><w:style w:type=\"paragraph\" w:styleId=\"Heading1\"><w:name w:val=\"heading 1\"/></w:style></w:styles>";
        File f = zip("d.docx", new String[] {"word/document.xml", "word/styles.xml"}, new byte[][] {doc.getBytes("UTF-8"), styles.getBytes("UTF-8")});
        File out = convert(f, "d.docx");
        String page = entry(out, "OEBPS/text/p0001.xhtml");
        assertTrue(page, page.contains("<h1") && page.contains("Body text."));
    }

    @Test
    public void unsupportedFormatsAreRecognised() throws Exception {
        File f = write("x.cbr", "Rar!\u001a\u0007\u0000 rest".getBytes("ISO-8859-1"));
        assertEquals(BookFormat.UNSUPPORTED, BookFormat.detect(f, "x.cbr"));
    }

    @Test
    public void garbageGivesAMessageNotACrash() throws Exception {
        File f = write("bad.docx", "not a zip".getBytes("UTF-8"));
        File out = tmp.newFile("o.epub");
        try {
            BookConverter.convert(f, "bad.docx", BookFormat.DOCX, out);
            fail();
        } catch (ConvertException e) {
            assertTrue(e.getMessage().length() > 0);
        }
    }
}
