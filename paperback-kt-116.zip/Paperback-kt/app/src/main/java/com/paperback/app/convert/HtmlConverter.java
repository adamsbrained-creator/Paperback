package com.paperback.app.convert;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Turns the sloppy HTML found in books (MOBI, AZW3, web pages) into clean XHTML that an EPUB reader accepts: unclosed
 * tags are closed, unknown tags are dropped, scripts and heads are removed, and only the attributes that matter stay.
 *
 * <p>The text can be given as the raw bytes of the book read as ISO-8859-1 (one character per byte). Then the numbers
 * in the book (an old MOBI link points at a byte) are positions in the string, and [charset] says how to read the
 * letters. With a null charset the string is already real text.
 */
final class HtmlConverter {

    /** What the book's own addresses become. */
    interface Env {
        /** The address for a link, or null when it can't be kept (the words stay, the link goes). [filepos] is an old MOBI link's number, or -1. */
        String href(String raw, int filepos);

        /** The path of a picture as a page of the book writes it (such as "../images/i1.jpg"), or null to leave the picture out. */
        String image(String src, String recindex);
    }

    /** A heading found in the text: the table of contents is made from these when the book has none. */
    static final class Heading {
        final int level;
        final String text;
        final String id;

        Heading(int level, String text, String id) {
            this.level = level;
            this.text = text;
            this.id = id;
        }
    }

    private static final Set<String> VOID = set("br", "hr", "img", "wbr", "col", "input", "area", "base", "embed", "source", "track", "param", "meta", "link");
    private static final Set<String> SKIP = set("script", "style", "head", "title", "noscript", "template", "object", "iframe", "audio", "video", "canvas");
    private static final Set<String> BLOCK = set("address", "article", "aside", "blockquote", "center", "details", "dialog", "dir",
            "div", "dl", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header",
            "hgroup", "hr", "main", "menu", "nav", "ol", "p", "pre", "section", "table", "ul", "li", "dd", "dt");
    private static final Set<String> KEEP = set("p", "div", "span", "h1", "h2", "h3", "h4", "h5", "h6", "br", "hr", "b", "strong",
            "i", "em", "u", "s", "del", "ins", "sup", "sub", "small", "big", "blockquote", "pre", "code", "cite", "q", "abbr",
            "dfn", "kbd", "samp", "var", "mark", "ul", "ol", "li", "dl", "dt", "dd", "table", "thead", "tbody", "tfoot", "tr",
            "td", "th", "caption", "colgroup", "col", "figure", "figcaption", "section", "article", "aside", "header", "footer",
            "ruby", "rt", "rp", "rb", "bdi", "bdo", "time", "address", "details", "summary");
    private static final Set<String> TEXT_ALIGN = set("p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "td", "th", "caption");

    private static Set<String> set(String... v) {
        return new HashSet<String>(Arrays.asList(v));
    }

    private final Charset charset;
    private final boolean keepClass;
    private final boolean keepStyle;
    private final Env env;
    private final String idPrefix;

    /** Headings of the last text converted. */
    final List<Heading> headings = new ArrayList<Heading>();
    /** Positions (in the string given) of the anchors that were written, as asked for in [convert]. */
    final Set<Integer> anchorsWritten = new LinkedHashSet<Integer>();

    // working state
    private String s;
    private int to;
    private StringBuilder out;
    private String[] src = new String[64];
    private String[] dst = new String[64];
    private int depth;
    private int headingFrame = -1;
    private int headingLevel;
    private String headingId;
    private StringBuilder headingText;
    private int headingCount;
    private int[] anchors = new int[0];
    private int nextAnchor;

    HtmlConverter(Charset charset, boolean keepClass, boolean keepStyle, Env env, String idPrefix) {
        this.charset = charset;
        this.keepClass = keepClass;
        this.keepStyle = keepStyle;
        this.env = env;
        this.idPrefix = idPrefix;
    }

    /** The anchor an [offset] gets, e.g. "fp1234"; links written by the caller must use the same names. */
    static String anchorName(int offset) {
        return "fp" + offset;
    }

    /**
     * Converts text[from, to) and returns what goes into the body. [anchorOffsets] (sorted) are places in the string
     * that get an empty anchor of their own, because something else in the book links to them.
     */
    String convert(String text, int from, int end, int[] anchorOffsets) {
        s = text;
        to = end;
        out = new StringBuilder(Math.max(256, (end - from) + (end - from) / 4));
        depth = 0;
        headingFrame = -1;
        anchors = anchorOffsets == null ? new int[0] : anchorOffsets;
        nextAnchor = 0;
        while (nextAnchor < anchors.length && anchors[nextAnchor] < from) nextAnchor++;

        int i = from;
        while (i < to) {
            int lt = s.indexOf('<', i);
            if (lt < 0 || lt >= to) {
                text(i, to);
                i = to;
                break;
            }
            if (lt > i) text(i, lt);
            i = tag(lt);
        }
        flushAnchors(to);
        closeTo(0);
        return out.toString();
    }

    // ---------------------------------------------------------------------------------------------
    // text

    private void text(int a, int b) {
        // anchors that fall inside the text split it in two
        while (nextAnchor < anchors.length && anchors[nextAnchor] < b) {
            int at = anchors[nextAnchor];
            if (at <= a) {
                writeAnchor(anchors[nextAnchor++]);
                continue;
            }
            int cut = at;
            if (charset != null && "UTF-8".equalsIgnoreCase(charset.name())) {
                while (cut < b && (s.charAt(cut) & 0xC0) == 0x80) cut++; // never inside a multi-byte letter
            }
            if (cut >= b) break;
            emitText(a, cut);
            a = cut;
            writeAnchor(anchors[nextAnchor++]);
        }
        emitText(a, b);
    }

    private void emitText(int a, int b) {
        if (b <= a) return;
        String raw = s.substring(a, b);
        String t = Entities.decode(decode(raw));
        Xml.escTo(out, t, 0, t.length());
        if (headingText != null) headingText.append(t);
    }

    private String decode(String seg) {
        if (charset == null) return seg;
        boolean ascii = true;
        for (int k = 0; k < seg.length(); k++) {
            if (seg.charAt(k) > 127) {
                ascii = false;
                break;
            }
        }
        if (ascii) return seg;
        return new String(seg.getBytes(Charset.forName("ISO-8859-1")), charset);
    }

    private void writeAnchor(int offset) {
        if (anchorsWritten.add(offset)) out.append("<a id=\"").append(anchorName(offset)).append("\"></a>");
    }

    /** Writes the anchors whose place is before [limit]. */
    private void flushAnchors(int limit) {
        while (nextAnchor < anchors.length && anchors[nextAnchor] < limit) writeAnchor(anchors[nextAnchor++]);
    }

    // ---------------------------------------------------------------------------------------------
    // tags

    /** Reads the tag that starts at [lt] and returns where the text goes on. */
    private int tag(int lt) {
        if (s.startsWith("<!--", lt)) {
            int e = s.indexOf("-->", lt + 4);
            return e < 0 || e >= to ? to : e + 3;
        }
        if (s.startsWith("<![CDATA[", lt)) {
            int e = s.indexOf("]]>", lt + 9);
            int stop = e < 0 || e >= to ? to : e;
            String raw = decode(s.substring(lt + 9, stop));
            Xml.escTo(out, raw, 0, raw.length());
            return e < 0 || e >= to ? to : e + 3;
        }
        if (lt + 1 >= to) {
            out.append("&lt;");
            return to;
        }
        char c = s.charAt(lt + 1);
        if (c == '!' || c == '?') {
            int e = s.indexOf('>', lt + 2);
            return e < 0 || e >= to ? to : e + 1;
        }
        boolean closing = c == '/';
        int p = lt + (closing ? 2 : 1);
        if (p >= to || !isNameStart(s.charAt(p))) {
            // a lone "<" in the text
            flushAnchors(lt + 1);
            out.append("&lt;");
            return lt + 1;
        }
        int ne = p;
        while (ne < to && isNameChar(s.charAt(ne))) ne++;
        String name = s.substring(p, ne).toLowerCase(Locale.ROOT);

        // attributes
        List<String[]> attrs = closing ? null : new ArrayList<String[]>(4);
        boolean selfClose = false;
        int i = ne;
        while (i < to) {
            char ch = s.charAt(i);
            if (ch == '>') {
                i++;
                break;
            }
            if (ch == '/') {
                selfClose = true;
                i++;
                continue;
            }
            if (Character.isWhitespace(ch)) {
                i++;
                continue;
            }
            int an = i;
            while (i < to) {
                char x = s.charAt(i);
                if (Character.isWhitespace(x) || x == '=' || x == '>' || (x == '/' && i + 1 < to && s.charAt(i + 1) == '>')) break;
                i++;
            }
            String attrName = s.substring(an, i).toLowerCase(Locale.ROOT);
            while (i < to && Character.isWhitespace(s.charAt(i))) i++;
            String value = "";
            if (i < to && s.charAt(i) == '=') {
                i++;
                while (i < to && Character.isWhitespace(s.charAt(i))) i++;
                if (i < to && (s.charAt(i) == '"' || s.charAt(i) == '\'')) {
                    char q = s.charAt(i);
                    int e = s.indexOf(q, i + 1);
                    if (e < 0 || e >= to) e = to;
                    value = s.substring(i + 1, e);
                    i = Math.min(to, e + 1);
                } else {
                    int vs = i;
                    while (i < to && !Character.isWhitespace(s.charAt(i)) && s.charAt(i) != '>') i++;
                    if (i > vs && s.charAt(i - 1) == '/' && i < to && s.charAt(i) == '>') {
                        i--;
                        selfClose = true;
                    }
                    value = s.substring(vs, i);
                }
            }
            if (!closing && attrName.length() > 0) attrs.add(new String[] {attrName, value});
        }
        int end = i;

        // anchors that point into or before this tag go before it
        flushAnchors(end);

        if (closing) {
            endTag(name);
            return end;
        }
        return startTag(name, attrs, selfClose, end);
    }

    private static boolean isNameStart(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    private static boolean isNameChar(char c) {
        return isNameStart(c) || (c >= '0' && c <= '9') || c == ':' || c == '-' || c == '_' || c == '.';
    }

    private static String attr(List<String[]> attrs, String name) {
        for (String[] a : attrs) if (a[0].equals(name)) return a[1];
        return null;
    }

    private String value(String raw) {
        return Entities.decode(decode(raw));
    }

    private int startTag(String name, List<String[]> attrs, boolean selfClose, int tagEnd) {
        if (SKIP.contains(name)) {
            if (selfClose) return tagEnd;
            // everything up to the matching end tag is dropped; a head also ends where the body begins
            int e = indexOfIgnoreCase("</" + name, tagEnd);
            int stop = e < 0 ? to : e;
            if (name.equals("head")) {
                int body = indexOfIgnoreCase("<body", tagEnd);
                if (body >= 0 && body < stop) stop = body;
            }
            return stop;
        }
        if (name.equals("html") || name.equals("body") || name.equals("meta") || name.equals("link") || name.equals("base")) return tagEnd;

        if (name.equals("img") || name.equals("image")) {
            String srcAttr = attr(attrs, "src");
            if (srcAttr == null) srcAttr = attr(attrs, "xlink:href");
            if (srcAttr == null) srcAttr = attr(attrs, "href");
            String rec = attr(attrs, "hirecindex");
            if (rec == null || rec.length() == 0) rec = attr(attrs, "recindex");
            String path = env.image(srcAttr == null ? "" : value(srcAttr), rec);
            if (path != null) {
                String alt = attr(attrs, "alt");
                out.append("<img src=\"").append(Xml.esc(path)).append("\" alt=\"").append(Xml.esc(alt == null ? "" : value(alt))).append("\"/>");
            }
            return tagEnd;
        }
        if (name.equals("svg") || name.equals("g") || name.equals("font") || name.equals("nobr")) {
            return tagEnd; // the tag goes, what is inside stays
        }

        String outName;
        if (name.equals("center")) outName = "div";
        else if (name.equals("strike")) outName = "s";
        else if (name.equals("tt")) outName = "code";
        else if (name.equals("acronym")) outName = "abbr";
        else if (name.equals("dir") || name.equals("menu")) outName = "ul";
        else if (name.equals("listing") || name.equals("xmp")) outName = "pre";
        else if (name.equals("a")) outName = "a";
        else if (KEEP.contains(name)) outName = name;
        else return tagEnd; // unknown tag: dropped, its content stays

        beforeStart(name);

        // attributes
        StringBuilder at = new StringBuilder();
        String id = null;
        String idAttr = attr(attrs, "id");
        if (idAttr != null && idAttr.length() > 0) id = Xml.id(value(idAttr));
        String style = null;
        String alignAttr = attr(attrs, "align");
        if (name.equals("center")) style = "text-align:center";
        else if (alignAttr != null && TEXT_ALIGN.contains(name)) {
            String al = alignAttr.trim().toLowerCase(Locale.ROOT);
            if (al.equals("center") || al.equals("right") || al.equals("left") || al.equals("justify")) style = "text-align:" + al;
        }
        if (keepStyle) {
            String st = attr(attrs, "style");
            if (st != null) {
                String cleaned = value(st).replaceAll("(?i)url\\([^)]*\\)", "none").replace('"', '\'').trim();
                if (cleaned.length() > 0) style = style == null ? cleaned : cleaned + ";" + style;
            }
        }
        if (name.equals("a")) {
            String nameAttr = attr(attrs, "name");
            if (id == null && nameAttr != null && nameAttr.length() > 0) id = Xml.id(value(nameAttr));
            String hrefRaw = attr(attrs, "href");
            int filepos = -1;
            String fp = attr(attrs, "filepos");
            if (fp != null) {
                try {
                    filepos = Integer.parseInt(fp.trim());
                } catch (NumberFormatException e) {
                    filepos = -1;
                }
            }
            String href = null;
            if (hrefRaw != null || filepos >= 0) href = env.href(hrefRaw == null ? "" : value(hrefRaw), filepos);
            if (href == null && id == null) return tagEnd; // a link that goes nowhere: only its words stay
            if (href != null) at.append(" href=\"").append(Xml.esc(href)).append('"');
        }
        if (headingFrame < 0 && outName.length() == 2 && outName.charAt(0) == 'h' && Character.isDigit(outName.charAt(1))) {
            if (id == null) id = idPrefix + "h" + (++headingCount);
        }
        if (id != null) at.append(" id=\"").append(Xml.esc(id)).append('"');
        if (keepClass) {
            String cl = attr(attrs, "class");
            if (cl != null && cl.trim().length() > 0) at.append(" class=\"").append(Xml.esc(value(cl).trim())).append('"');
        }
        if (style != null) at.append(" style=\"").append(Xml.esc(style)).append('"');
        if (name.equals("td") || name.equals("th")) {
            for (String k : new String[] {"colspan", "rowspan"}) {
                String v = attr(attrs, k);
                if (v != null && v.trim().matches("\\d{1,3}")) at.append(' ').append(k).append("=\"").append(v.trim()).append('"');
            }
        }
        if (name.equals("ol")) {
            String v = attr(attrs, "start");
            if (v != null && v.trim().matches("\\d{1,5}")) at.append(" start=\"").append(v.trim()).append('"');
        }

        if (VOID.contains(outName)) {
            out.append('<').append(outName).append(at).append("/>");
            return tagEnd;
        }
        out.append('<').append(outName).append(at).append('>');
        if (selfClose) {
            out.append("</").append(outName).append('>');
            return tagEnd;
        }
        push(name, outName);
        if (headingFrame < 0 && outName.length() == 2 && outName.charAt(0) == 'h' && Character.isDigit(outName.charAt(1))) {
            headingFrame = depth - 1;
            headingLevel = outName.charAt(1) - '0';
            headingId = id;
            headingText = new StringBuilder();
        }
        return tagEnd;
    }

    private void endTag(String name) {
        if (name.equals("br")) {
            out.append("<br/>");
            return;
        }
        for (int k = depth - 1; k >= 0; k--) {
            if (src[k].equals(name)) {
                closeTo(k);
                return;
            }
        }
        // no such open tag: the stray end tag is ignored
    }

    private void push(String srcName, String outName) {
        if (depth == src.length) {
            src = Arrays.copyOf(src, depth * 2);
            dst = Arrays.copyOf(dst, depth * 2);
        }
        src[depth] = srcName;
        dst[depth] = outName;
        depth++;
    }

    /** Closes the open tags down to and including the one at [index]. */
    private void closeTo(int index) {
        while (depth > index) {
            depth--;
            out.append("</").append(dst[depth]).append('>');
            if (depth == headingFrame) {
                String t = Xml.squash(headingText.toString());
                if (t.length() > 0 && headingId != null) headings.add(new Heading(headingLevel, t, headingId));
                headingFrame = -1;
                headingText = null;
                headingId = null;
            }
        }
    }

    /** The rules of HTML for which open tags a new tag closes ("li" closes the previous "li", a block closes a "p"). */
    private void beforeStart(String name) {
        if (BLOCK.contains(name)) {
            for (int k = depth - 1; k >= 0; k--) {
                String f = src[k];
                if (f.equals("p")) {
                    closeTo(k);
                    break;
                }
                if (f.equals("td") || f.equals("th") || f.equals("table") || f.equals("caption")) break;
            }
        }
        if (name.equals("li")) {
            closeUp(new String[] {"li"}, new String[] {"ul", "ol"});
        } else if (name.equals("dt") || name.equals("dd")) {
            closeUp(new String[] {"dt", "dd"}, new String[] {"dl"});
        } else if (name.equals("tr")) {
            closeUp(new String[] {"tr"}, new String[] {"table"});
        } else if (name.equals("td") || name.equals("th")) {
            closeUp(new String[] {"td", "th"}, new String[] {"tr", "table"});
        } else if (name.equals("thead") || name.equals("tbody") || name.equals("tfoot")) {
            closeUp(new String[] {"thead", "tbody", "tfoot"}, new String[] {"table"});
        }
    }

    /** Closes the nearest open tag named in [targets], looking no further up than a tag named in [walls]. */
    private void closeUp(String[] targets, String[] walls) {
        for (int k = depth - 1; k >= 0; k--) {
            String f = src[k];
            for (String w : walls) if (f.equals(w)) return;
            for (String x : targets) {
                if (f.equals(x)) {
                    closeTo(k);
                    return;
                }
            }
        }
    }

    private int indexOfIgnoreCase(String needle, int from) {
        int n = needle.length();
        for (int i = from; i + n <= to; i++) {
            if (s.regionMatches(true, i, needle, 0, n)) return i;
        }
        return -1;
    }
}
