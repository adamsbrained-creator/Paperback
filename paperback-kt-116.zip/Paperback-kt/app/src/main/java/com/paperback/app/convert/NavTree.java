package com.paperback.app.convert;

import java.util.ArrayList;
import java.util.List;

/** Builds a nested table of contents from entries that only know their level (1 = chapter, 2 = section...). */
final class NavTree {
    private final List<EpubBuilder.Nav> root;
    private final List<EpubBuilder.Nav> stack = new ArrayList<EpubBuilder.Nav>();
    private final List<Integer> levels = new ArrayList<Integer>();

    NavTree(List<EpubBuilder.Nav> root) {
        this.root = root;
    }

    void add(int level, String title, String href) {
        EpubBuilder.Nav item = new EpubBuilder.Nav(title, href);
        while (!levels.isEmpty() && levels.get(levels.size() - 1) >= level) {
            levels.remove(levels.size() - 1);
            stack.remove(stack.size() - 1);
        }
        if (stack.isEmpty()) root.add(item);
        else stack.get(stack.size() - 1).children.add(item);
        stack.add(item);
        levels.add(level);
    }
}
