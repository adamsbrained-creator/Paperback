package com.paperback.app.convert;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Word (.docx): headings, paragraphs, bold/italic/underline, lists, tables, links, pictures and footnotes become an EPUB.
 * Page layout, headers, footers, text boxes and tracked-deletion text are left out.
 */
final class DocxBook {
    private DocxBook() {
    }

    private static final long MAX_XML = 150L * 1024 * 1024;
    private static final String HEADING_RE = "heading\\s*([1-9])";

    // ---------------------------------------------------------------------------------------------
    // what the pieces of a Word file look like once read

    private static final class Style {
        String name = "";
        String basedOn;
        int outline = -1;
        String numId;
        int ilvl;
    }

    private static final class Block {
        int heading; // 1..6 for a heading
        boolean title; // the "Title" style
        int list = -1; // nesting level of a list item, -1 when it is not one
        boolean ordered;
        String numId = "";
        String id;
        String html = ""; // the inside of the paragraph, or a whole table when raw
        String plain = "";
        boolean raw;
        boolean quote;
    }

    /** Everything the main text refers to by name. */
    private static final class Ctx {
        final Map<String, Style> styles = new HashMap<String, Style>();
        final Map<String, String> numToAbs = new HashMap<String, String>();
        final Map<String, Map<Integer, String>> absFmt = new HashMap<String, Map<Integer, String>>();
        final Map<String, String> footnotes = new HashMap<String, String>(); // "fn_3" -> html
        String defaultLang;
        final Map<String, String> imagePaths = new LinkedHashMap<String, String>(); // zip entry -> path in the epub
        final Map<String, ZipEntry> entries = new HashMap<String, ZipEntry>(); // lower-case name -> entry
        ZipFile zip;
        EpubBuilder book;

        int headingLevel(String styleId, int directOutline) {
            if (directOutline >= 0 && directOutline <= 5) return directOutline + 1;
            String id = styleId;
            for (int depth = 0; id != null && depth < 8; depth++) {
                Style s = styles.get(id);
                if (s == null) break;
                String n = s.name.toLowerCase(Locale.ROOT).trim();
                Matcher m = Pattern.compile(HEADING_RE).matcher(n);
                if (m.matches()) return Integer.parseInt(m.group(1));
                if (s.outline >= 0) return s.outline <= 5 ? s.outline + 1 : 0;
                id = s.basedOn;
            }
            return 0;
        }

        String styleName(String styleId) {
            Style s = styleId == null ? null : styles.get(styleId);
            return s == null ? "" : s.name.toLowerCase(Locale.ROOT).trim();
        }

        /** The list a style puts its paragraphs in ("List Bullet"), found through the style or the ones it is based on. */
        Style numbered(String styleId) {
            String id = styleId;
            for (int depth = 0; id != null && depth < 8; depth++) {
                Style s = styles.get(id);
                if (s == null) return null;
                if (s.numId != null) return s;
                id = s.basedOn;
            }
            return null;
        }

        boolean ordered(String numId, int ilvl) {
            String abs = numToAbs.get(numId);
            Map<Integer, String> levels = abs == null ? null : absFmt.get(abs);
            String fmt = levels == null ? null : levels.get(ilvl);
            if (fmt == null && levels != null) fmt = levels.get(0);
            if (fmt == null) return false;
            return !fmt.equals("bullet") && !fmt.equals("none");
        }

        /** Where a picture inside the Word file goes in the epub, or null when it can't be shown. */
        String image(String target) {
            if (target == null) return null;
            String t = target.replace('\\', '/');
            String full = t.startsWith("/") ? t.substring(1) : normalize("word/" + t);
            String low = full.toLowerCase(Locale.ROOT);
            String ext = low.substring(low.lastIndexOf('.') + 1);
            String mime = mediaType(ext);
            ZipEntry e = entries.get(low);
            if (mime == null || e == null) return null;
            String have = imagePaths.get(low);
            if (have != null) return have;
            String path = "images/d" + (imagePaths.size() + 1) + "." + (ext.equals("jpeg") ? "jpg" : ext);
            imagePaths.put(low, path);
            final ZipFile z = zip;
            final ZipEntry entry = e;
            book.resources.add(new EpubBuilder.Resource(path, mime, new EpubBuilder.Source() {
                public InputStream open() throws IOException {
                    return z.getInputStream(entry);
                }
            }));
            return path;
        }
    }

    private static String mediaType(String ext) {
        if (ext.equals("png")) return "image/png";
        if (ext.equals("jpg") || ext.equals("jpeg")) return "image/jpeg";
        if (ext.equals("gif")) return "image/gif";
        if (ext.equals("bmp")) return "image/bmp";
        if (ext.equals("webp")) return "image/webp";
        if (ext.equals("svg")) return "image/svg+xml";
        return null; // emf, wmf, tiff: no e-reader shows them
    }

    private static String normalize(String path) {
        List<String> out = new ArrayList<String>();
        for (String s : path.split("/")) {
            if (s.length() == 0 || s.equals(".")) continue;
            if (s.equals("..")) {
                if (!out.isEmpty()) out.remove(out.size() - 1);
            } else {
                out.add(s);
            }
        }
        StringBuilder b = new StringBuilder();
        for (String s : out) b.append(b.length() == 0 ? "" : "/").append(s);
        return b.toString();
    }

    // ---------------------------------------------------------------------------------------------

    static void convert(File in, String name, File out) throws IOException, ConvertException {
        ZipFile zip = new ZipFile(in);
        try {
            Ctx x = new Ctx();
            x.zip = zip;
            Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (!e.isDirectory()) x.entries.put(e.getName().toLowerCase(Locale.ROOT), e);
            }
            ZipEntry docEntry = x.entries.get("word/document.xml");
            if (docEntry == null) throw new ConvertException("This Word file has no text in it.");

            EpubBuilder book = new EpubBuilder();
            x.book = book;
            book.title = BookConverter.titleFromName(name);
            String[] core = readCore(x);

            try {
                Handlers.Styles sh = new Handlers.Styles(x);
                parseEntry(x, "word/styles.xml", sh);
                parseEntry(x, "word/numbering.xml", new Handlers.Numbering(x));
                Map<String, String[]> relsMain = rels(x, "word/_rels/document.xml.rels");
                for (String kind : new String[] {"footnotes", "endnotes"}) {
                    if (x.entries.get("word/" + kind + ".xml") == null) continue;
                    BodyHandler nh = new BodyHandler(x, rels(x, "word/_rels/" + kind + ".xml.rels"), true, kind.equals("footnotes") ? "fn_" : "en_");
                    parseEntry(x, "word/" + kind + ".xml", nh);
                }
                BodyHandler body = new BodyHandler(x, relsMain, false, "");
                parseEntry(x, "word/document.xml", body);
                build(x, book, body, core, name, in.length());
            } catch (SAXException e) {
                throw new ConvertException("This Word file couldn't be read.", e);
            }
            book.write(out);
        } finally {
            try {
                zip.close();
            } catch (IOException ignored) {
            }
        }
    }

    private static void build(Ctx x, EpubBuilder book, BodyHandler body, String[] core, String name, long size) throws ConvertException {
        List<Block> blocks = body.blocks;
        if (blocks.isEmpty()) throw new ConvertException("This Word file has no text in it.");

        boolean hasH1 = false;
        for (Block b : blocks) if (b.heading == 1) hasH1 = true;
        String firstTitle = "";
        for (Block b : blocks) {
            if (b.title) {
                if (firstTitle.length() == 0) firstTitle = b.plain;
                if (!hasH1) b.heading = 1; // a document with a Title and nothing else to divide it by
            }
        }
        // metadata
        if (core[0].length() > 0) book.title = core[0];
        else if (firstTitle.length() > 0) book.title = firstTitle;
        for (String a : core[1].split("[;]")) if (a.trim().length() > 0) book.authors.add(a.trim());
        for (String s : core[2].split("[,;]")) if (s.trim().length() > 0) book.subjects.add(s.trim());
        book.description = core[3];
        String lang = core[4].length() > 0 ? core[4] : (x.defaultLang == null ? "" : x.defaultLang);
        if (lang.matches("[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*")) book.language = lang;
        if (core[5].length() >= 4 && core[5].substring(0, 4).matches("\\d{4}")) book.date = core[5].length() >= 10 ? core[5].substring(0, 10) : core[5];
        book.identifier = BookConverter.identifier("docx", book.title, size);

        // pages: split where the top heading level starts, and never let one page grow past a few hundred kilobytes
        int minLevel = 0;
        for (Block b : blocks) if (b.heading > 0 && (minLevel == 0 || b.heading < minLevel)) minLevel = b.heading;
        int splitLevel = minLevel >= 1 && minLevel <= 2 ? minLevel : 0;
        List<List<Block>> groups = new ArrayList<List<Block>>();
        List<Block> cur = new ArrayList<Block>();
        int curSize = 0;
        for (Block b : blocks) {
            boolean starts = b.heading > 0 && b.heading <= splitLevel;
            boolean big = curSize > 120000 && b.list < 0;
            if ((starts || big) && !cur.isEmpty()) {
                groups.add(cur);
                cur = new ArrayList<Block>();
                curSize = 0;
            }
            cur.add(b);
            curSize += b.html.length() + 16;
        }
        if (!cur.isEmpty()) groups.add(cur);

        // notes go last, in the order they were mentioned
        String notesHtml = null;
        if (!body.noteOrder.isEmpty()) {
            StringBuilder nb = new StringBuilder("<h1 id=\"notes\">Notes</h1>\n");
            int n = 0;
            for (String id : body.noteOrder) {
                n++;
                String h = x.footnotes.get(id);
                if (h == null) h = "<p></p>";
                String back = "<a href=\"\u0001ref_" + id + "\u0002\">" + n + ".</a> ";
                int p = h.indexOf("<p");
                int gt = p >= 0 ? h.indexOf('>', p) : -1;
                h = gt >= 0 ? h.substring(0, gt + 1) + back + h.substring(gt + 1) : "<p>" + back + "</p>" + h;
                nb.append("<div class=\"note\" id=\"").append(id).append("\">").append(h).append("</div>\n");
            }
            notesHtml = nb.toString();
        }

        List<String> bodies = new ArrayList<String>();
        List<String> files = new ArrayList<String>();
        for (List<Block> g : groups) {
            bodies.add(render(g, false));
            files.add(String.format(Locale.ROOT, "text/p%04d.xhtml", files.size() + 1));
        }
        if (notesHtml != null) {
            bodies.add(notesHtml);
            files.add(String.format(Locale.ROOT, "text/p%04d.xhtml", files.size() + 1));
        }

        // which page holds each anchor, so links between pages can be written
        Map<String, String> where = new HashMap<String, String>();
        Pattern idp = Pattern.compile("\\sid=\"([^\"]+)\"");
        for (int i = 0; i < bodies.size(); i++) {
            Matcher m = idp.matcher(bodies.get(i));
            while (m.find()) if (!where.containsKey(m.group(1))) where.put(m.group(1), files.get(i).substring(files.get(i).lastIndexOf('/') + 1));
        }
        Pattern link = Pattern.compile("\u0001([^\u0002]*)\u0002");
        for (int i = 0; i < bodies.size(); i++) {
            Matcher m = link.matcher(bodies.get(i));
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                String id = m.group(1);
                String page = where.get(id);
                m.appendReplacement(sb, Matcher.quoteReplacement((page == null ? "" : page) + "#" + id));
            }
            m.appendTail(sb);
            String html = sb.toString();
            EpubBuilder.Part part = new EpubBuilder.Part(files.get(i), html);
            String t = "";
            if (i < groups.size()) {
                for (Block b : groups.get(i)) {
                    if (b.heading > 0) {
                        t = b.plain;
                        break;
                    }
                }
            } else {
                t = "Notes";
            }
            part.title = t.length() > 0 ? t : (i == 0 ? book.title : "Part " + (i + 1));
            book.parts.add(part);
        }

        // table of contents
        NavTree tree = new NavTree(book.nav);
        boolean firstHasHeading = false;
        for (Block b : groups.get(0)) if (b.heading > 0 && b.heading <= 4 && b.plain.length() > 0) firstHasHeading = true;
        if (!firstHasHeading && groups.size() > 1) tree.add(1, book.title, files.get(0));
        for (int i = 0; i < groups.size(); i++) {
            for (Block b : groups.get(i)) {
                if (b.heading > 0 && b.heading <= 4 && b.plain.length() > 0) {
                    String t = b.plain.length() > 150 ? b.plain.substring(0, 150) : b.plain;
                    tree.add(b.heading, t, files.get(i) + "#" + b.id);
                }
            }
        }
        if (notesHtml != null) tree.add(1, "Notes", files.get(files.size() - 1) + "#notes");
        if (book.nav.isEmpty()) book.nav.add(new EpubBuilder.Nav(book.title, files.get(0)));
    }

    /** The paragraphs of one page as XHTML, with runs of list items turned into nested lists. */
    private static String render(List<Block> blocks, boolean notes) {
        StringBuilder out = new StringBuilder();
        List<Boolean> ordered = new ArrayList<Boolean>();
        List<Boolean> liOpen = new ArrayList<Boolean>();
        Map<String, Integer> counters = new HashMap<String, Integer>();
        for (Block b : blocks) {
            if (b.list >= 0 && !notes) {
                int level = Math.min(b.list, 8);
                if (ordered.isEmpty() || (ordered.size() == 1 && level == 0 && ordered.get(0) != b.ordered)) {
                    closeLists(out, ordered, liOpen, 0);
                    openList(out, ordered, liOpen, b, counters, true);
                }
                while (ordered.size() - 1 < level) {
                    int top = liOpen.size() - 1;
                    if (!liOpen.get(top)) {
                        out.append("<li>");
                        liOpen.set(top, true);
                    }
                    openList(out, ordered, liOpen, b, counters, false);
                }
                closeLists(out, ordered, liOpen, level + 1);
                int top = liOpen.size() - 1;
                if (liOpen.get(top)) out.append("</li>\n");
                out.append("<li>").append(b.html);
                liOpen.set(top, true);
                if (level == 0) counters.put(b.numId, (counters.containsKey(b.numId) ? counters.get(b.numId) : 0) + 1);
                continue;
            }
            closeLists(out, ordered, liOpen, 0);
            if (b.raw) {
                out.append(b.html).append('\n');
            } else if (b.heading > 0 && !notes) {
                out.append("<h").append(b.heading).append(" id=\"").append(b.id).append("\">").append(b.html).append("</h").append(b.heading).append(">\n");
            } else if (b.title && !notes) {
                out.append("<p class=\"title\" style=\"text-align:center;font-size:1.8em;font-weight:bold;margin:1.5em 0\">").append(b.html).append("</p>\n");
            } else if (b.heading > 0 || b.title) {
                out.append("<p><strong>").append(b.html).append("</strong></p>\n");
            } else if (b.list >= 0) {
                out.append("<p>").append(b.html).append("</p>\n");
            } else if (b.quote) {
                out.append("<blockquote>").append(b.html).append("</blockquote>\n");
            } else {
                out.append(b.html).append('\n');
            }
        }
        closeLists(out, ordered, liOpen, 0);
        return out.toString();
    }

    private static void openList(StringBuilder out, List<Boolean> ordered, List<Boolean> liOpen, Block b, Map<String, Integer> counters, boolean top) {
        ordered.add(b.ordered);
        liOpen.add(false);
        if (b.ordered) {
            int done = top && counters.containsKey(b.numId) ? counters.get(b.numId) : 0;
            out.append(done > 0 ? "<ol start=\"" + (done + 1) + "\">\n" : "<ol>\n");
        } else {
            out.append("<ul>\n");
        }
    }

    /** Closes lists until only [keep] are open. */
    private static void closeLists(StringBuilder out, List<Boolean> ordered, List<Boolean> liOpen, int keep) {
        while (ordered.size() > keep) {
            int top = ordered.size() - 1;
            if (liOpen.get(top)) out.append("</li>\n");
            out.append(ordered.get(top) ? "</ol>\n" : "</ul>\n");
            ordered.remove(top);
            liOpen.remove(top);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // reading the small files

    private static void parseEntry(Ctx x, String name, DefaultHandler h) throws IOException, SAXException, ConvertException {
        ZipEntry e = x.entries.get(name);
        if (e == null) return;
        if (e.getSize() > MAX_XML) throw new ConvertException("This Word file is too big to be converted on this phone.");
        InputStream in = x.zip.getInputStream(e);
        try {
            SAXParserFactory f = SAXParserFactory.newInstance();
            f.setNamespaceAware(false);
            f.setValidating(false);
            String[][] features = {
                {"http://xml.org/sax/features/external-general-entities", "false"},
                {"http://xml.org/sax/features/external-parameter-entities", "false"},
                {"http://apache.org/xml/features/nonvalidating/load-external-dtd", "false"},
            };
            for (String[] ft : features) {
                try {
                    f.setFeature(ft[0], Boolean.parseBoolean(ft[1]));
                } catch (Exception ignored) {
                    // this parser doesn't have the switch
                }
            }
            f.newSAXParser().parse(new InputSource(in), h);
        } catch (ParserConfigurationException ex) {
            throw new SAXException(ex);
        } finally {
            in.close();
        }
    }

    /** Relationships: id -> {type, target, mode}. */
    private static Map<String, String[]> rels(Ctx x, String name) throws IOException, SAXException, ConvertException {
        final Map<String, String[]> map = new HashMap<String, String[]>();
        parseEntry(x, name, new DefaultHandler() {
            @Override
            public void startElement(String uri, String local, String q, Attributes a) {
                if (q.equals("Relationship") && a.getValue("Id") != null) {
                    map.put(a.getValue("Id"), new String[] {String.valueOf(a.getValue("Type")), a.getValue("Target"), a.getValue("TargetMode")});
                }
            }
        });
        return map;
    }

    /** title, author, subject, description, language, created */
    private static String[] readCore(Ctx x) throws IOException, ConvertException {
        final String[] v = {"", "", "", "", "", ""};
        try {
            parseEntry(x, "docprops/core.xml", new DefaultHandler() {
                private int field = -1;
                private StringBuilder text = new StringBuilder();

                @Override
                public void startElement(String uri, String local, String q, Attributes a) {
                    field = q.equals("dc:title") ? 0 : q.equals("dc:creator") ? 1 : q.equals("cp:keywords") ? 2 : q.equals("dc:description") ? 3
                            : q.equals("dc:language") ? 4 : q.equals("dcterms:created") ? 5 : -1;
                    text.setLength(0);
                }

                @Override
                public void characters(char[] ch, int s, int l) {
                    if (field >= 0) text.append(ch, s, l);
                }

                @Override
                public void endElement(String uri, String local, String q) {
                    if (field >= 0 && v[field].length() == 0) v[field] = Xml.squash(text.toString());
                    field = -1;
                }
            });
            if (v[2].length() == 0) {
                // dc:subject is kept as a subject too when there are no keywords
                final String[] subject = {""};
                parseEntry(x, "docprops/core.xml", new DefaultHandler() {
                    private boolean on;
                    private final StringBuilder text = new StringBuilder();

                    @Override
                    public void startElement(String uri, String local, String q, Attributes a) {
                        on = q.equals("dc:subject");
                        text.setLength(0);
                    }

                    @Override
                    public void characters(char[] ch, int s, int l) {
                        if (on) text.append(ch, s, l);
                    }

                    @Override
                    public void endElement(String uri, String local, String q) {
                        if (on) subject[0] = Xml.squash(text.toString());
                        on = false;
                    }
                });
                v[2] = subject[0];
            }
        } catch (SAXException ignored) {
            // the details are a nicety; the book is still readable without them
        }
        return v;
    }

    /** The two small files that say what styles and lists are. */
    private static final class Handlers {
        static final class Styles extends DefaultHandler {
            private final Ctx x;
            private String id;
            private Style cur;
            private boolean inDefaults;

            Styles(Ctx x) {
                this.x = x;
            }

            @Override
            public void startElement(String uri, String local, String q, Attributes a) {
                if (q.equals("w:docDefaults")) inDefaults = true;
                else if (q.equals("w:lang") && x.defaultLang == null && (inDefaults || cur == null) && a.getValue("w:val") != null) x.defaultLang = a.getValue("w:val");
                else if (q.equals("w:style")) {
                    id = a.getValue("w:styleId");
                    cur = new Style();
                } else if (cur != null) {
                    String v = a.getValue("w:val");
                    if (q.equals("w:name") && v != null) cur.name = v;
                    else if (q.equals("w:basedOn")) cur.basedOn = v;
                    else if (q.equals("w:outlineLvl") && v != null) cur.outline = parseInt(v, -1);
                    else if (q.equals("w:numId")) cur.numId = "0".equals(v) ? null : v;
                    else if (q.equals("w:ilvl")) cur.ilvl = parseInt(v, 0);
                }
            }

            @Override
            public void endElement(String uri, String local, String q) {
                if (q.equals("w:docDefaults")) inDefaults = false;
                else if (q.equals("w:style")) {
                    if (id != null && cur != null) x.styles.put(id, cur);
                    cur = null;
                    id = null;
                }
            }
        }

        static final class Numbering extends DefaultHandler {
            private final Ctx x;
            private String abs;
            private String num;
            private int lvl;

            Numbering(Ctx x) {
                this.x = x;
            }

            @Override
            public void startElement(String uri, String local, String q, Attributes a) {
                String v = a.getValue("w:val");
                if (q.equals("w:abstractNum")) {
                    abs = a.getValue("w:abstractNumId");
                    if (abs != null) x.absFmt.put(abs, new HashMap<Integer, String>());
                } else if (q.equals("w:lvl")) {
                    lvl = parseInt(a.getValue("w:ilvl"), 0);
                } else if (q.equals("w:numFmt") && abs != null && v != null) {
                    Map<Integer, String> m = x.absFmt.get(abs);
                    if (m != null && !m.containsKey(lvl)) m.put(lvl, v);
                } else if (q.equals("w:num")) {
                    num = a.getValue("w:numId");
                } else if (q.equals("w:abstractNumId") && num != null && v != null) {
                    x.numToAbs.put(num, v);
                }
            }

            @Override
            public void endElement(String uri, String local, String q) {
                if (q.equals("w:abstractNum")) abs = null;
                else if (q.equals("w:num")) num = null;
            }
        }
    }

    private static int parseInt(String s, int fallback) {
        try {
            return s == null ? fallback : Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    // ---------------------------------------------------------------------------------------------

    /** Reads the body of document.xml (or of footnotes.xml and endnotes.xml, where each note becomes a small set of blocks). */
    private static final class BodyHandler extends DefaultHandler {
        final Ctx x;
        final Map<String, String[]> rels;
        final boolean notesFile;
        final String notePrefix;
        final List<Block> blocks = new ArrayList<Block>();
        final List<String> noteOrder = new ArrayList<String>();
        private final Set<String> usedIds = new HashSet<String>();
        private final List<String> pendingAnchors = new ArrayList<String>();
        private int headingCount;

        // skipping what is not wanted (fallbacks of drawings, text boxes)
        private int skip;

        // the paragraph being read
        private boolean inP;
        private StringBuilder p = new StringBuilder();
        private StringBuilder plain = new StringBuilder();
        private boolean hasContent;
        private boolean hasImage;
        private String pStyle;
        private int pOutline = -1;
        private String pNumId;
        private int pIlvl;
        private String jc;
        private boolean inPPr;

        // the run being read
        private boolean inRun;
        private boolean inRPr;
        private boolean inT;
        private StringBuilder run = new StringBuilder();
        private boolean bold, ital, und, strike, sup, sub;
        private String rStyle;
        private String alt = "";
        private final List<Boolean> links = new ArrayList<Boolean>();

        // tables
        private final List<StringBuilder> tables = new ArrayList<StringBuilder>();
        private final List<StringBuilder> cells = new ArrayList<StringBuilder>();
        private final List<Integer> spans = new ArrayList<Integer>();

        // a footnote being read
        private String noteId;
        private int noteStart;
        private boolean noteSkipped;

        BodyHandler(Ctx x, Map<String, String[]> rels, boolean notesFile, String notePrefix) {
            this.x = x;
            this.rels = rels;
            this.notesFile = notesFile;
            this.notePrefix = notePrefix;
        }

        private static boolean on(Attributes a) {
            String v = a.getValue("w:val");
            return v == null || !(v.equals("0") || v.equals("false") || v.equals("off") || v.equals("none"));
        }

        private String anchorId(String bookmark) {
            return "bm_" + Xml.id(bookmark);
        }

        @Override
        public void startElement(String uri, String local, String q, Attributes a) {
            if (q.equals("mc:Fallback") || q.equals("w:txbxContent")) {
                skip++;
                return;
            }
            if (skip > 0) return;
            String v = a.getValue("w:val");
            if (q.equals("w:p")) {
                inP = true;
                p = new StringBuilder();
                plain = new StringBuilder();
                hasContent = false;
                hasImage = false;
                pStyle = null;
                pOutline = -1;
                pNumId = null;
                pIlvl = 0;
                jc = null;
                for (String id : pendingAnchors) p.append("<a id=\"").append(id).append("\"></a>");
                pendingAnchors.clear();
            } else if (q.equals("w:pPr")) {
                inPPr = true;
            } else if (q.equals("w:pStyle") && inP) {
                pStyle = v;
            } else if (q.equals("w:outlineLvl") && inP && inPPr) {
                pOutline = parseInt(v, -1);
            } else if (q.equals("w:ilvl") && inP && inPPr) {
                pIlvl = parseInt(v, 0);
            } else if (q.equals("w:numId") && inP && inPPr) {
                pNumId = v;
            } else if (q.equals("w:jc") && inP && inPPr) {
                jc = v;
            } else if (q.equals("w:r")) {
                inRun = true;
                run = new StringBuilder();
                bold = false;
                ital = false;
                und = false;
                strike = false;
                sup = false;
                sub = false;
                rStyle = null;
            } else if (q.equals("w:rPr")) {
                inRPr = inRun;
            } else if (inRun && inRPr) {
                if (q.equals("w:b")) bold = on(a);
                else if (q.equals("w:i")) ital = on(a);
                else if (q.equals("w:u")) und = on(a);
                else if (q.equals("w:strike") || q.equals("w:dstrike")) strike = on(a);
                else if (q.equals("w:vertAlign")) {
                    sup = "superscript".equals(v);
                    sub = "subscript".equals(v);
                } else if (q.equals("w:rStyle")) rStyle = v;
            } else if (q.equals("w:t") && inRun) {
                inT = true;
            } else if (q.equals("w:tab") && inRun && !inPPr) {
                run.append('\u2003');
                plain.append(' ');
            } else if ((q.equals("w:br") || q.equals("w:cr")) && inRun) {
                if (!"page".equals(a.getValue("w:type"))) run.append("<br/>");
            } else if (q.equals("w:noBreakHyphen") && inRun) {
                run.append('-');
                plain.append('-');
            } else if (q.equals("w:hyperlink") && inP) {
                String href = null;
                String rid = a.getValue("r:id");
                String anchor = a.getValue("w:anchor");
                if (rid != null) {
                    String[] r = rels.get(rid);
                    if (r != null && r[1] != null && safeLink(r[1])) {
                        href = Xml.esc(r[1].trim());
                    }
                } else if (anchor != null) {
                    href = "\u0001" + anchorId(anchor) + "\u0002";
                }
                if (href != null) p.append("<a href=\"").append(href).append("\">");
                links.add(href != null);
            } else if (q.equals("w:bookmarkStart")) {
                String n = a.getValue("w:name");
                if (n != null && !n.startsWith("_GoBack") && !notesFile) {
                    String id = anchorId(n);
                    if (usedIds.add(id)) {
                        if (inP) p.append("<a id=\"").append(id).append("\"></a>");
                        else if (!tables.isEmpty() && !cells.isEmpty()) cells.get(cells.size() - 1).append("<a id=\"").append(id).append("\"></a>");
                        else pendingAnchors.add(id);
                    }
                }
            } else if (q.equals("wp:docPr")) {
                String d = a.getValue("descr");
                if (d == null || d.trim().length() == 0) d = a.getValue("title");
                alt = d == null ? "" : d;
            } else if (q.equals("a:blip") && inRun) {
                image(a.getValue("r:embed"));
            } else if (q.equals("v:imagedata") && inRun) {
                image(a.getValue("r:id"));
            } else if ((q.equals("w:footnoteReference") || q.equals("w:endnoteReference")) && inRun && !notesFile) {
                String key = (q.equals("w:footnoteReference") ? "fn_" : "en_") + a.getValue("w:id");
                if (x.footnotes.containsKey(key)) {
                    if (!noteOrder.contains(key)) noteOrder.add(key);
                    int n = noteOrder.indexOf(key) + 1;
                    run.append("<a id=\"ref_").append(key).append("\" href=\"\u0001").append(key).append("\u0002\" epub:type=\"noteref\"><sup>").append(n).append("</sup></a>");
                    plain.append(' ');
                    hasContent = true;
                }
            } else if (q.equals("w:tbl")) {
                tables.add(new StringBuilder("<table>"));
            } else if (q.equals("w:tr") && !tables.isEmpty()) {
                tables.get(tables.size() - 1).append("<tr>");
            } else if (q.equals("w:tc") && !tables.isEmpty()) {
                cells.add(new StringBuilder());
                spans.add(1);
            } else if (q.equals("w:gridSpan") && !spans.isEmpty()) {
                spans.set(spans.size() - 1, Math.max(1, Math.min(parseInt(v, 1), 50)));
            } else if ((q.equals("w:footnote") || q.equals("w:endnote")) && notesFile) {
                String type = a.getValue("w:type");
                noteSkipped = type != null && !type.equals("normal");
                noteId = notePrefix + a.getValue("w:id");
                noteStart = blocks.size();
            }
        }

        private static boolean safeLink(String t) {
            String l = t.trim().toLowerCase(Locale.ROOT);
            return l.startsWith("http://") || l.startsWith("https://") || l.startsWith("mailto:") || l.startsWith("tel:");
        }

        private void image(String rid) {
            if (rid == null) return;
            String[] r = rels.get(rid);
            if (r == null || "External".equals(r[2])) return;
            String path = x.image(r[1]);
            if (path == null) return;
            run.append("<img src=\"../").append(path).append("\" alt=\"").append(Xml.esc(alt)).append("\"/>");
            hasContent = true;
            hasImage = true;
            alt = "";
        }

        @Override
        public void characters(char[] ch, int start, int length) {
            if (skip > 0 || !inT) return;
            run.append(Xml.esc(new String(ch, start, length)));
            plain.append(ch, start, length);
            for (int i = start; i < start + length; i++) {
                if (!Character.isWhitespace(ch[i])) {
                    hasContent = true;
                    break;
                }
            }
        }

        @Override
        public void endElement(String uri, String local, String q) {
            if (q.equals("mc:Fallback") || q.equals("w:txbxContent")) {
                if (skip > 0) skip--;
                return;
            }
            if (skip > 0) return;
            if (q.equals("w:t")) inT = false;
            else if (q.equals("w:pPr")) inPPr = false;
            else if (q.equals("w:rPr")) inRPr = false;
            else if (q.equals("w:r")) endRun();
            else if (q.equals("w:hyperlink")) {
                if (!links.isEmpty() && links.remove(links.size() - 1) && inP) p.append("</a>");
            } else if (q.equals("w:p")) endParagraph();
            else if (q.equals("w:tc") && !cells.isEmpty() && !tables.isEmpty()) {
                StringBuilder c = cells.remove(cells.size() - 1);
                int span = spans.remove(spans.size() - 1);
                tables.get(tables.size() - 1).append(span > 1 ? "<td colspan=\"" + span + "\">" : "<td>").append(c.length() == 0 ? "&#160;" : c.toString()).append("</td>");
            } else if (q.equals("w:tr") && !tables.isEmpty()) {
                tables.get(tables.size() - 1).append("</tr>");
            } else if (q.equals("w:tbl") && !tables.isEmpty()) {
                StringBuilder t = tables.remove(tables.size() - 1);
                if (t.indexOf("<tr>") >= 0) {
                    t.append("</table>");
                    if (!cells.isEmpty()) {
                        cells.get(cells.size() - 1).append(t);
                    } else {
                        Block b = new Block();
                        b.raw = true;
                        b.html = t.toString();
                        blocks.add(b);
                    }
                }
            } else if ((q.equals("w:footnote") || q.equals("w:endnote")) && notesFile && noteId != null) {
                List<Block> mine = new ArrayList<Block>(blocks.subList(noteStart, blocks.size()));
                while (blocks.size() > noteStart) blocks.remove(blocks.size() - 1);
                if (!noteSkipped) x.footnotes.put(noteId, render(mine, true));
                noteId = null;
            }
        }

        private void endRun() {
            inRun = false;
            inRPr = false;
            inT = false;
            if (run.length() == 0) return;
            String name = x.styleName(rStyle);
            boolean b = bold || name.equals("strong");
            boolean i = ital || name.equals("emphasis");
            String s = run.toString();
            if (!inP) return;
            boolean imageOnly = s.startsWith("<img") || s.startsWith("<a id=\"ref_");
            if (!imageOnly) {
                if (strike) s = "<s>" + s + "</s>";
                if (und) s = "<u>" + s + "</u>";
                if (i) s = "<em>" + s + "</em>";
                if (b) s = "<strong>" + s + "</strong>";
                if (sup) s = "<sup>" + s + "</sup>";
                else if (sub) s = "<sub>" + s + "</sub>";
            }
            p.append(s);
        }

        private void endParagraph() {
            inP = false;
            inPPr = false;
            while (!links.isEmpty()) {
                if (links.remove(links.size() - 1)) p.append("</a>");
            }
            String inner = p.toString();
            String text = Xml.squash(plain.toString());
            boolean inCell = !cells.isEmpty();
            if (!hasContent) {
                if (inner.length() == 0) return;
                // only anchors: keep them so links to them still work
                if (inCell) cells.get(cells.size() - 1).append(inner);
                else {
                    Block b = new Block();
                    b.raw = true;
                    b.html = "<p>" + inner + "</p>";
                    blocks.add(b);
                }
                return;
            }
            Block b = new Block();
            b.html = inner;
            b.plain = text;
            int level = x.headingLevel(pStyle, pOutline);
            String sname = x.styleName(pStyle);
            boolean isTitle = sname.equals("title");
            if (level > 0 && (text.length() == 0 || hasImage && text.length() == 0)) level = 0;
            String num = pNumId;
            int ilvl = pIlvl;
            if (num == null && level == 0 && !isTitle) {
                Style ns = x.numbered(pStyle);
                if (ns != null) {
                    num = ns.numId;
                    ilvl = ns.ilvl;
                }
            }
            boolean list = false;
            boolean ordered = false;
            if (level == 0 && !isTitle) {
                if (num != null && !num.equals("0")) {
                    list = true;
                    ordered = x.ordered(num, ilvl);
                } else if (sname.startsWith("list bullet")) {
                    list = true;
                    num = "bullet";
                } else if (sname.startsWith("list number")) {
                    list = true;
                    ordered = true;
                    num = "number";
                }
            }
            if (inCell) {
                String cls = "center".equals(jc) ? " style=\"text-align:center\"" : "";
                String lead = list ? (ordered ? "" : "\u2022 ") : "";
                String open = level > 0 || isTitle ? "<p" + cls + "><strong>" : "<p" + cls + ">";
                String close = level > 0 || isTitle ? "</strong></p>" : "</p>";
                cells.get(cells.size() - 1).append(open).append(lead).append(inner).append(close);
                return;
            }
            if (level > 0) {
                b.heading = level;
                b.id = "h" + (++headingCount);
                blocks.add(b);
                usedIds.add(b.id);
                return;
            }
            if (isTitle) {
                b.title = true;
                b.id = "h" + (++headingCount);
                usedIds.add(b.id);
                blocks.add(b);
                return;
            }
            if (list) {
                b.list = Math.max(0, ilvl);
                b.ordered = ordered;
                b.numId = num == null ? "" : num;
                blocks.add(b);
                return;
            }
            String attrs = "";
            if (hasImage && text.length() == 0) attrs = " class=\"img\"";
            else if ("center".equals(jc)) attrs = " class=\"center\"";
            else if ("right".equals(jc) || "end".equals(jc)) attrs = " style=\"text-align:right\"";
            b.html = "<p" + attrs + ">" + inner + "</p>";
            b.quote = sname.equals("quote") || sname.equals("intense quote");
            blocks.add(b);
        }
    }
}
