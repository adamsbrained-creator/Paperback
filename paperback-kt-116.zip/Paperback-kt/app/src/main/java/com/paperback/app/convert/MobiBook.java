package com.paperback.app.convert;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Kindle and Mobipocket books: .mobi, .azw, .azw3, .prc (and old PalmDOC .pdb text). Both generations are read:
 * the old format (one long piece of HTML, links by byte position) and KF8 / AZW3 (skeleton and fragment tables,
 * style sheets, links by fragment number). Books with DRM, and the old Huffman compression, are refused with a clear message.
 */
final class MobiBook {
    private MobiBook() {
    }

    private static final int NULL = -1; // 0xFFFFFFFF read as an int
    private static final Charset LATIN1 = Charset.forName("ISO-8859-1");
    private static final int SPLIT_AT = 250000;

    static void convert(File in, String fileName, File out) throws IOException, ConvertException {
        byte[] data = BookConverter.readAll(in);
        Palm palm = new Palm(data);
        byte[] r0 = palm.rec(0);
        if (r0.length < 16) throw new ConvertException("This file is not a valid MOBI book.");
        int compression = u16(r0, 0);
        if (u16(r0, 12) != 0) throw drm();

        boolean hasMobi = r0.length >= 20 && r0[16] == 'M' && r0[17] == 'O' && r0[18] == 'B' && r0[19] == 'I';
        if (!hasMobi) { // a PalmDOC: plain text records and nothing else
            byte[] text = text(palm, 0, u16(r0, 8), compression, 0);
            TextBook.plainText(text, fileName, out);
            return;
        }

        Header h0 = new Header(r0);
        Header h = h0;
        int base = 0;
        Map<Integer, List<byte[]>> exth = h0.exth;
        // a file with an old book and a KF8 book in it: the KF8 one starts after a "BOUNDARY" record
        List<byte[]> k8 = h0.version != 8 ? h0.exth.get(121) : null;
        if (k8 != null && !k8.isEmpty()) {
            int idx = (int) be(k8.get(0));
            if (idx > 0 && idx < palm.n && new String(palm.rec(idx - 1), LATIN1).startsWith("BOUNDARY")) {
                Header hk = new Header(palm.rec(idx));
                if (hk.version == 8) {
                    h = hk;
                    base = idx;
                    exth = new HashMap<Integer, List<byte[]>>(h0.exth);
                    exth.putAll(hk.exth);
                }
            }
        }
        if (h.crypto != 0) throw drm();
        if (h.compression == 17480) {
            throw new ConvertException("This MOBI uses an old compression (Huffman) that Paperback can't read yet. Re-save it with Calibre as EPUB or AZW3.");
        }
        if (h.compression != 1 && h.compression != 2) throw new ConvertException("This MOBI uses a compression that isn't supported.");

        Charset cs = h.codepage == 65001 ? Charset.forName("UTF-8") : TextCodec.charset("windows-" + h.codepage, "windows-1252");
        byte[] raw = text(palm, base, h.textRecords, h.compression, h.extraFlags);
        if (raw.length == 0) throw new ConvertException("This MOBI has no text in it.");

        EpubBuilder book = new EpubBuilder();
        details(book, h, h0, exth, r0, palm, base, cs, fileName);
        book.identifier = BookConverter.identifier("mobi", book.title + book.authors, data.length);

        Images images = new Images(palm, data, h.firstImage == NULL ? -1 : base + h.firstImage);
        int coverNo = -1;
        List<byte[]> cov = exth.get(201);
        if (cov != null && !cov.isEmpty()) coverNo = (int) be(cov.get(0)) + 1;

        if (h.version == 8) kf8(book, palm, base, h, raw, cs, images, coverNo);
        else mobi6(book, palm, base, h, raw, cs, images, coverNo);

        images.addTo(book, coverNo);
        book.write(out);
    }

    private static ConvertException drm() {
        return new ConvertException("This book is protected by DRM (copy protection), so Paperback can't open it. Only DRM-free books can be added.");
    }

    // ---------------------------------------------------------------------------------------------
    // the PalmDB container

    private static final class Palm {
        final byte[] d;
        final int n;
        final int[] off;

        Palm(byte[] d) throws ConvertException {
            this.d = d;
            if (d.length < 80) throw new ConvertException("This file is not a valid MOBI book.");
            n = u16(d, 76);
            if (n < 2 || 78 + n * 8 > d.length) throw new ConvertException("This file is not a valid MOBI book.");
            off = new int[n + 1];
            for (int i = 0; i < n; i++) off[i] = u32(d, 78 + i * 8);
            off[n] = d.length;
            for (int i = 0; i < n; i++) {
                if (off[i] < 0 || off[i] > d.length || (i > 0 && off[i] < off[i - 1])) throw new ConvertException("This MOBI is damaged.");
            }
        }

        byte[] rec(int i) {
            if (i < 0 || i >= n) return new byte[0];
            return Arrays.copyOfRange(d, off[i], Math.max(off[i], Math.min(off[i + 1], d.length)));
        }
    }

    static int u16(byte[] b, int o) {
        if (o + 2 > b.length) return 0;
        return ((b[o] & 0xFF) << 8) | (b[o + 1] & 0xFF);
    }

    static int u32(byte[] b, int o) {
        if (o + 4 > b.length) return 0;
        return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }

    private static long be(byte[] b) {
        long v = 0;
        for (int i = 0; i < b.length && i < 8; i++) v = (v << 8) | (b[i] & 0xFF);
        return v;
    }

    private static final class Header {
        int compression, textRecords, crypto, headerLen, codepage, version, fullNameOff, fullNameLen, locale;
        int firstImage = NULL, extraFlags, ncx = NULL, fdst = NULL, frag = NULL, skel = NULL;
        final Map<Integer, List<byte[]>> exth = new LinkedHashMap<Integer, List<byte[]>>();

        Header(byte[] r) {
            compression = u16(r, 0);
            textRecords = u16(r, 8);
            crypto = u16(r, 12);
            headerLen = u32(r, 20);
            codepage = u32(r, 28);
            version = u32(r, 36);
            fullNameOff = u32(r, 84);
            fullNameLen = u32(r, 88);
            locale = u32(r, 92);
            firstImage = u32(r, 108);
            int exthFlags = u32(r, 128);
            if (headerLen >= 228) extraFlags = u32(r, 0xF0) & 0xFFFF;
            if (headerLen >= 232) ncx = u32(r, 0xF4);
            if (version == 8) {
                fdst = u32(r, 0xC0);
                if (headerLen >= 244) {
                    frag = u32(r, 0xF8);
                    skel = u32(r, 0xFC);
                }
            }
            if ((exthFlags & 0x40) != 0) readExth(r, 16 + headerLen);
        }

        private void readExth(byte[] r, int at) {
            if (at + 12 > r.length || r[at] != 'E' || r[at + 1] != 'X' || r[at + 2] != 'T' || r[at + 3] != 'H') return;
            int count = u32(r, at + 8);
            int p = at + 12;
            for (int i = 0; i < count && p + 8 <= r.length; i++) {
                int type = u32(r, p);
                int len = u32(r, p + 4);
                if (len < 8 || p + len > r.length) break;
                List<byte[]> list = exth.get(type);
                if (list == null) {
                    list = new ArrayList<byte[]>(1);
                    exth.put(type, list);
                }
                list.add(Arrays.copyOfRange(r, p + 8, p + len));
                p += len;
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // the text

    /** The text of the book: every text record unpacked and joined. The extra bytes Kindle adds at the end of a record are dropped. */
    private static byte[] text(Palm palm, int base, int records, int compression, int extraFlags) throws ConvertException {
        ByteArrayOutputStream all = new ByteArrayOutputStream(records * 4096 + 1024);
        byte[] buf = new byte[1 << 16];
        for (int i = 1; i <= records && base + i < palm.n; i++) {
            int start = palm.off[base + i];
            int end = palm.off[base + i + 1];
            end -= trailing(palm.d, start, end, extraFlags);
            if (end < start) end = start;
            if (compression == 2) {
                int n = unpack(palm.d, start, end, buf);
                all.write(buf, 0, n);
            } else {
                all.write(palm.d, start, end - start);
            }
        }
        return all.toByteArray();
    }

    /** How many bytes at the end of a record are not text (see the "extra data flags" of the header). */
    private static int trailing(byte[] d, int start, int end, int flags) {
        int size = end - start;
        int num = 0;
        int f = flags >> 1;
        while (f != 0) {
            if ((f & 1) != 0) num += trailingEntry(d, start, size - num);
            f >>= 1;
        }
        if ((flags & 1) != 0 && size - num - 1 >= 0) num += (d[start + size - num - 1] & 0x3) + 1;
        return Math.min(num, size);
    }

    private static int trailingEntry(byte[] d, int start, int size) {
        int bitpos = 0;
        int result = 0;
        while (true) {
            if (size <= 0) return result;
            int v = d[start + size - 1] & 0xFF;
            result |= (v & 0x7F) << bitpos;
            bitpos += 7;
            size--;
            if ((v & 0x80) != 0 || bitpos >= 28 || size == 0) return result;
        }
    }

    /** PalmDOC compression (a form of LZ77). Returns the number of bytes written to [o]. */
    static int unpack(byte[] in, int start, int end, byte[] o) {
        int i = start;
        int p = 0;
        while (i < end && p < o.length - 16) {
            int c = in[i++] & 0xFF;
            if (c >= 1 && c <= 8) {
                for (int k = 0; k < c && i < end; k++) o[p++] = in[i++];
            } else if (c < 128) {
                o[p++] = (byte) c;
            } else if (c >= 192) {
                o[p++] = ' ';
                o[p++] = (byte) (c ^ 128);
            } else {
                if (i >= end) break;
                int pair = (c << 8) | (in[i++] & 0xFF);
                int dist = (pair >> 3) & 0x7FF;
                int len = (pair & 7) + 3;
                if (dist == 0 || dist > p) break;
                for (int k = 0; k < len && p < o.length; k++, p++) o[p] = o[p - dist];
            }
        }
        return p;
    }

    // ---------------------------------------------------------------------------------------------
    // pictures

    private static final class Images {
        final Palm palm;
        final byte[] data;
        final int first;
        final Map<Integer, String> used = new LinkedHashMap<Integer, String>(); // picture number (1-based) -> path

        Images(Palm palm, byte[] data, int first) {
            this.palm = palm;
            this.data = data;
            this.first = first;
        }

        private String kind(int number) {
            if (first < 0) return null;
            int rec = first + number - 1;
            if (number < 1 || rec >= palm.n) return null;
            int s = palm.off[rec];
            int e = palm.off[rec + 1];
            if (e - s < 8) return null;
            byte[] d = data;
            if ((d[s] & 0xFF) == 0xFF && (d[s + 1] & 0xFF) == 0xD8) return "jpg";
            if ((d[s] & 0xFF) == 0x89 && d[s + 1] == 'P' && d[s + 2] == 'N' && d[s + 3] == 'G') return "png";
            if (d[s] == 'G' && d[s + 1] == 'I' && d[s + 2] == 'F') return "gif";
            if (d[s] == 'R' && d[s + 1] == 'I' && d[s + 2] == 'F' && d[s + 3] == 'F') return "webp";
            return null;
        }

        /** The path (as written inside a page in text/) of picture [number], or null if there is no such picture. */
        String path(int number, String from) {
            String ext = kind(number);
            if (ext == null) return null;
            String p = "images/i" + number + "." + ext;
            used.put(number, p);
            return from + p;
        }

        void addTo(EpubBuilder book, int coverNo) {
            if (coverNo > 0 && !used.containsKey(coverNo)) {
                String ext = kind(coverNo);
                if (ext != null) used.put(coverNo, "images/i" + coverNo + "." + ext);
            }
            for (Map.Entry<Integer, String> e : used.entrySet()) {
                int rec = first + e.getKey() - 1;
                String path = e.getValue();
                String ext = path.substring(path.lastIndexOf('.') + 1);
                EpubBuilder.Resource r = new EpubBuilder.Resource(path, ext.equals("png") ? "image/png" : ext.equals("gif") ? "image/gif"
                        : ext.equals("webp") ? "image/webp" : "image/jpeg", Arrays.copyOfRange(data, palm.off[rec], palm.off[rec + 1]));
                r.cover = e.getKey() == coverNo;
                book.resources.add(r);
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // the book's details

    private static void details(EpubBuilder book, Header h, Header h0, Map<Integer, List<byte[]>> exth, byte[] r0, Palm palm, int base,
                                Charset cs, String fileName) {
        String title = ex(exth, 503, cs);
        if (title.length() == 0) {
            byte[] rb = base == 0 ? r0 : palm.rec(base);
            if (h.fullNameOff > 0 && h.fullNameLen > 0 && h.fullNameOff + h.fullNameLen <= rb.length) {
                title = Xml.squash(new String(rb, h.fullNameOff, h.fullNameLen, cs));
            }
        }
        book.title = title.length() > 0 ? title : BookConverter.titleFromName(fileName);
        List<byte[]> au = exth.get(100);
        if (au != null) {
            for (byte[] a : au) {
                String s = Xml.squash(new String(a, cs));
                String[] parts = s.split(",");
                if (parts.length == 2 && parts[0].trim().indexOf(' ') < 0) s = parts[1].trim() + " " + parts[0].trim(); // "Doe, John"
                if (s.length() > 0 && !book.authors.contains(s)) book.authors.add(s);
            }
        }
        book.publisher = ex(exth, 101, cs);
        String desc = ex(exth, 103, cs);
        book.description = Xml.squash(Entities.decode(desc.replaceAll("(?s)<[^>]*>", " ")));
        List<byte[]> subj = exth.get(105);
        if (subj != null) {
            for (byte[] s : subj) {
                for (String x : new String(s, cs).split("[;/]")) {
                    String t = Xml.squash(x);
                    if (t.length() > 0 && !book.subjects.contains(t)) book.subjects.add(t);
                }
            }
        }
        Matcher dm = Pattern.compile("^(\\d{4})(?:-(\\d{2}))?(?:-(\\d{2}))?").matcher(ex(exth, 106, cs));
        if (dm.find()) book.date = dm.group(0);
        String lang = ex(exth, 524, cs).toLowerCase(Locale.ROOT);
        if (!lang.matches("[a-z]{2,3}(-[a-z0-9]{2,8})?")) lang = localeLanguage(h.locale != 0 ? h.locale : h0.locale);
        if (lang.length() > 0) book.language = lang;
        if (ex(exth, 527, cs).equalsIgnoreCase("rtl")) book.rtl = true;
    }

    private static String ex(Map<Integer, List<byte[]>> exth, int type, Charset cs) {
        List<byte[]> l = exth.get(type);
        if (l == null || l.isEmpty()) return "";
        return Xml.squash(new String(l.get(0), cs));
    }

    private static String localeLanguage(int locale) {
        switch (locale & 0xFF) {
            case 1: return "ar";
            case 5: return "cs";
            case 6: return "da";
            case 7: return "de";
            case 8: return "el";
            case 9: return "en";
            case 10: return "es";
            case 11: return "fi";
            case 12: return "fr";
            case 13: return "he";
            case 14: return "hu";
            case 16: return "it";
            case 17: return "ja";
            case 18: return "ko";
            case 19: return "nl";
            case 20: return "no";
            case 21: return "pl";
            case 22: return "pt";
            case 24: return "ro";
            case 25: return "ru";
            case 29: return "sv";
            case 30: return "th";
            case 31: return "tr";
            case 34: return "uk";
            case 4: return "zh";
            default: return "";
        }
    }

    // ---------------------------------------------------------------------------------------------
    // indexes (INDX records): skeleton, fragment and contents tables of KF8, the contents table of old books

    private static final class Index {
        final List<String> keys = new ArrayList<String>();
        final List<Map<Integer, int[]>> tags = new ArrayList<Map<Integer, int[]>>();
        final Map<Integer, String> cncx = new HashMap<Integer, String>();
    }

    /** Reads the index whose header record is record [rec] (an absolute record number). */
    private static Index readIndex(Palm palm, int rec, Charset cs) throws ConvertException {
        byte[] head = palm.rec(rec);
        if (head.length < 192 || head[0] != 'I' || head[1] != 'N' || head[2] != 'D' || head[3] != 'X') {
            throw new ConvertException("This MOBI has a damaged index.");
        }
        int dataRecords = u32(head, 24);
        int ncncx = u32(head, 52);
        int tagx = u32(head, 180);
        if (dataRecords < 0 || dataRecords > 10000 || tagx <= 0 || tagx + 12 > head.length) throw new ConvertException("This MOBI has a damaged index.");
        if (head[tagx] != 'T' || head[tagx + 1] != 'A' || head[tagx + 2] != 'G' || head[tagx + 3] != 'X') throw new ConvertException("This MOBI has a damaged index.");
        int firstEntry = u32(head, tagx + 4);
        int controlBytes = u32(head, tagx + 8);
        List<int[]> tagx4 = new ArrayList<int[]>();
        for (int i = tagx + 12; i + 4 <= tagx + firstEntry && i + 4 <= head.length; i += 4) {
            tagx4.add(new int[] {head[i] & 0xFF, head[i + 1] & 0xFF, head[i + 2] & 0xFF, head[i + 3] & 0xFF});
        }

        Index ix = new Index();
        for (int c = 0; c < ncncx; c++) { // the strings the entries point to
            byte[] r = palm.rec(rec + 1 + dataRecords + c);
            int p = 0;
            while (p < r.length) {
                int[] v = varint(r, p);
                if (v[1] == 0) break;
                int len = v[0];
                if (len > 0 && p + v[1] + len <= r.length) ix.cncx.put(c * 0x10000 + p, new String(r, p + v[1], len, Charset.forName("UTF-8")));
                p += v[1] + len;
            }
        }
        for (int i = 1; i <= dataRecords; i++) {
            byte[] r = palm.rec(rec + i);
            if (r.length < 28 || r[0] != 'I') continue;
            int idxt = u32(r, 20);
            int count = u32(r, 24);
            if (idxt <= 0 || idxt + 4 + count * 2 > r.length || r[idxt] != 'I') continue;
            for (int k = 0; k < count; k++) {
                int a = u16(r, idxt + 4 + k * 2);
                int b = k + 1 < count ? u16(r, idxt + 4 + (k + 1) * 2) : idxt;
                if (a >= r.length || b <= a) continue;
                int keyLen = r[a] & 0xFF;
                if (a + 1 + keyLen > b) continue;
                ix.keys.add(new String(r, a + 1, keyLen, LATIN1));
                ix.tags.add(tagMap(r, a + 1 + keyLen, b, tagx4, controlBytes));
            }
        }
        return ix;
    }

    /** {value, bytes used} of the variable-width number at [p]: seven bits per byte, and the last byte has its top bit set. */
    private static int[] varint(byte[] b, int p) {
        int v = 0;
        int n = 0;
        while (p + n < b.length) {
            int x = b[p + n] & 0xFF;
            v = (v << 7) | (x & 0x7F);
            n++;
            if ((x & 0x80) != 0) return new int[] {v, n};
            if (n > 5) break;
        }
        return new int[] {v, 0};
    }

    private static Map<Integer, int[]> tagMap(byte[] r, int start, int end, List<int[]> tags, int controlBytes) {
        Map<Integer, int[]> out = new LinkedHashMap<Integer, int[]>();
        List<int[]> wanted = new ArrayList<int[]>(); // {tag, valueCount (-1 = use bytes), valueBytes, valuesPerEntry}
        int cb = 0;
        int dataStart = start + controlBytes;
        for (int[] t : tags) {
            if (t[3] == 1) {
                cb++;
                continue;
            }
            if (start + cb >= end) break;
            int mask = t[2];
            int value = (r[start + cb] & 0xFF) & mask;
            if (value == 0) continue;
            if (value == mask) {
                if (Integer.bitCount(mask) > 1) {
                    int[] v = varint(r, dataStart);
                    dataStart += v[1];
                    wanted.add(new int[] {t[0], -1, v[0], t[1]});
                } else {
                    wanted.add(new int[] {t[0], 1, 0, t[1]});
                }
            } else {
                int m = mask;
                int val = value;
                while ((m & 1) == 0) {
                    m >>= 1;
                    val >>= 1;
                }
                wanted.add(new int[] {t[0], val, 0, t[1]});
            }
        }
        for (int[] w : wanted) {
            List<Integer> vals = new ArrayList<Integer>();
            if (w[1] >= 0) {
                for (int k = 0; k < w[1] * w[3]; k++) {
                    int[] v = varint(r, dataStart);
                    if (v[1] == 0) break;
                    dataStart += v[1];
                    vals.add(v[0]);
                }
            } else {
                int used = 0;
                while (used < w[2]) {
                    int[] v = varint(r, dataStart);
                    if (v[1] == 0) break;
                    dataStart += v[1];
                    used += v[1];
                    vals.add(v[0]);
                }
            }
            int[] arr = new int[vals.size()];
            for (int k = 0; k < arr.length; k++) arr[k] = vals.get(k);
            out.put(w[0], arr);
        }
        return out;
    }

    /** One line of the book's own table of contents. */
    private static final class TocEntry {
        final String label;
        final int pos;      // old books: byte position in the text; KF8: -1
        final int fid;      // KF8: fragment number; old books: -1
        final int off;
        final int depth;

        TocEntry(String label, int pos, int fid, int off, int depth) {
            this.label = label;
            this.pos = pos;
            this.fid = fid;
            this.off = off;
            this.depth = depth;
        }
    }

    private static List<TocEntry> readNcx(Palm palm, int rec, Charset cs, boolean kf8) {
        List<TocEntry> out = new ArrayList<TocEntry>();
        try {
            Index ix = readIndex(palm, rec, cs);
            for (Map<Integer, int[]> t : ix.tags) {
                int[] label = t.get(3);
                if (label == null || label.length == 0) continue;
                String text = ix.cncx.get(label[0]);
                if (text == null) continue;
                text = Xml.squash(text);
                if (text.length() == 0) continue;
                int[] hl = t.get(4);
                int depth = hl != null && hl.length > 0 ? hl[0] : 0;
                if (kf8) {
                    int[] pf = t.get(6);
                    if (pf == null || pf.length < 2) continue;
                    out.add(new TocEntry(text, -1, pf[0], pf[1], depth));
                } else {
                    int[] pos = t.get(1);
                    if (pos == null || pos.length == 0) continue;
                    out.add(new TocEntry(text, pos[0], -1, 0, depth));
                }
            }
        } catch (ConvertException e) {
            // a damaged contents table: the headings of the text are used instead
        } catch (RuntimeException e) {
            out.clear();
        }
        return out;
    }

    // ---------------------------------------------------------------------------------------------
    // old books (Mobipocket): one stream of HTML

    private static void mobi6(EpubBuilder book, Palm palm, int base, Header h, byte[] raw, final Charset cs, final Images images, int coverNo)
            throws IOException, ConvertException {
        final String s = new String(raw, LATIN1);
        List<TocEntry> toc = h.ncx != NULL ? readNcx(palm, base + h.ncx, cs, false) : new ArrayList<TocEntry>();

        // where the links point to
        TreeSet<Integer> targets = new TreeSet<Integer>();
        Matcher fp = Pattern.compile("(?i)filepos\\s*=\\s*[\"']?(\\d+)").matcher(s);
        while (fp.find()) {
            try {
                int v = Integer.parseInt(fp.group(1));
                if (v >= 0 && v < s.length()) targets.add(v);
            } catch (NumberFormatException ignored) {
                // not a position
            }
        }
        for (TocEntry e : toc) if (e.pos >= 0 && e.pos < s.length()) targets.add(e.pos);
        final int[] anchors = new int[targets.size()];
        int ai = 0;
        for (int t : targets) anchors[ai++] = t;

        // pages: cut where the book says "page break", and where a page would be too long
        List<Integer> starts = new ArrayList<Integer>();
        starts.add(0);
        Matcher pb = Pattern.compile("(?i)<mbp:pagebreak[^>]*>").matcher(s);
        while (pb.find()) if (pb.end() > starts.get(starts.size() - 1)) starts.add(pb.end());
        List<Integer> cut = new ArrayList<Integer>();
        for (int i = 0; i < starts.size(); i++) {
            int a = starts.get(i);
            int b = i + 1 < starts.size() ? starts.get(i + 1) : s.length();
            cut.add(a);
            int at = a;
            while (b - at > SPLIT_AT + 50000) {
                int split = nextBlock(s, at + SPLIT_AT, b);
                if (split < 0) break;
                cut.add(split);
                at = split;
            }
        }
        final int[] st = new int[cut.size()];
        for (int i = 0; i < st.length; i++) st[i] = cut.get(i);

        final HtmlConverter.Env env = new HtmlConverter.Env() {
            public String href(String raw, int filepos) {
                if (filepos >= 0) {
                    if (filepos >= s.length()) return null;
                    return "@@P" + partOf(st, filepos) + "@@#" + HtmlConverter.anchorName(filepos);
                }
                String r = raw.trim();
                String low = r.toLowerCase(Locale.ROOT);
                if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("mailto:")) return r;
                return null;
            }

            public String image(String src, String recindex) {
                if (recindex == null || !recindex.trim().matches("\\d{1,6}")) return null;
                return images.path(Integer.parseInt(recindex.trim()), "../");
            }
        };

        List<String> bodies = new ArrayList<String>();
        List<List<HtmlConverter.Heading>> headings = new ArrayList<List<HtmlConverter.Heading>>();
        List<Boolean> hasAnchor = new ArrayList<Boolean>();
        for (int i = 0; i < st.length; i++) {
            int to = i + 1 < st.length ? st[i + 1] : s.length();
            HtmlConverter conv = new HtmlConverter(cs, false, false, env, "p" + i);
            bodies.add(conv.convert(s, st[i], to, anchors));
            headings.add(conv.headings);
            hasAnchor.add(!conv.anchorsWritten.isEmpty());
        }
        List<Integer> keep = new ArrayList<Integer>();
        int[] newNo = new int[st.length];
        Arrays.fill(newNo, -1);
        for (int i = 0; i < bodies.size(); i++) {
            if (hasContent(bodies.get(i)) || hasAnchor.get(i)) {
                newNo[i] = keep.size();
                keep.add(i);
            }
        }
        if (keep.isEmpty()) throw new ConvertException("This MOBI has no text in it.");
        Pattern ph = Pattern.compile("@@P(\\d+)@@");
        for (int k = 0; k < keep.size(); k++) {
            String body = resolvePlaceholders(bodies.get(keep.get(k)), ph, newNo);
            EpubBuilder.Part part = new EpubBuilder.Part(String.format(Locale.ROOT, "text/p%04d.xhtml", k + 1), body);
            part.title = book.title;
            book.parts.add(part);
        }

        NavTree tree = new NavTree(book.nav);
        if (!toc.isEmpty()) {
            for (TocEntry e : toc) {
                if (e.pos < 0 || e.pos >= s.length()) continue;
                int part = newNo[partOf(st, e.pos)];
                if (part < 0) continue;
                tree.add(e.depth + 1, e.label, book.parts.get(part).file + "#" + HtmlConverter.anchorName(e.pos));
            }
        }
        if (book.nav.isEmpty()) {
            for (int k = 0; k < keep.size(); k++) {
                for (HtmlConverter.Heading hd : headings.get(keep.get(k))) {
                    if (hd.level <= 3) tree.add(hd.level, hd.text, book.parts.get(k).file + "#" + hd.id);
                }
            }
        }
        if (book.nav.isEmpty()) book.nav.add(new EpubBuilder.Nav(book.title, book.parts.get(0).file));
    }

    private static boolean hasContent(String body) {
        return body.contains("<img") || Xml.squash(body.replaceAll("(?s)<[^>]*>", " ")).length() > 0;
    }

    private static String resolvePlaceholders(String body, Pattern ph, int[] newNo) {
        if (body.indexOf("@@P") < 0) return body;
        Matcher m = ph.matcher(body);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            int old = Integer.parseInt(m.group(1));
            int now = old >= 0 && old < newNo.length ? newNo[old] : -1;
            m.appendReplacement(sb, now < 0 ? "" : Matcher.quoteReplacement(String.format(Locale.ROOT, "p%04d.xhtml", now + 1)));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** Index of the part [starts] that contains position [pos]. */
    private static int partOf(int[] starts, int pos) {
        int lo = 0;
        int hi = starts.length - 1;
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (starts[mid] <= pos) lo = mid;
            else hi = mid - 1;
        }
        return lo;
    }

    /** The start of the next paragraph, heading or block at or after [from], where a long page can be cut. */
    private static int nextBlock(String s, int from, int limit) {
        int i = from;
        while (i < limit) {
            int lt = s.indexOf('<', i);
            if (lt < 0 || lt + 2 >= limit) return -1;
            char c = Character.toLowerCase(s.charAt(lt + 1));
            char d = Character.toLowerCase(s.charAt(lt + 2));
            if ((c == 'p' && (d == ' ' || d == '>')) || (c == 'h' && Character.isDigit(d)) || (c == 'd' && d == 'i')) return lt;
            i = lt + 1;
        }
        return -1;
    }

    // ---------------------------------------------------------------------------------------------
    // KF8 (AZW3): skeletons with fragments inserted, style sheets as separate "flows"

    private static final Pattern POS_LINK = Pattern.compile("kindle:pos:fid:([0-9A-Va-v]{1,8}):off:([0-9A-Va-v]{1,12})");
    private static final Pattern FLOW_LINK = Pattern.compile("kindle:flow:([0-9A-Va-v]{1,8})\\?mime=([A-Za-z0-9/+.\\-]+)");
    private static final Pattern EMBED = Pattern.compile("kindle:embed:([0-9A-Va-v]{1,8})(?:\\?mime=[A-Za-z0-9/+.\\-]+)?");

    private static int base32(String s) {
        try {
            return Integer.parseInt(s, 32);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static final class Frag {
        final int insertPos;
        final int file;
        final int length;

        Frag(int insertPos, int file, int length) {
            this.insertPos = insertPos;
            this.file = file;
            this.length = length;
        }
    }

    private static void kf8(EpubBuilder book, Palm palm, int base, Header h, byte[] raw, Charset cs, final Images images, int coverNo)
            throws IOException, ConvertException {
        if (h.skel == NULL || h.frag == NULL) throw new ConvertException("This AZW3 has no text structure and can't be read.");
        // the flows: the first is the markup, the others are style sheets and so on
        List<int[]> flows = new ArrayList<int[]>();
        if (h.fdst != NULL) {
            byte[] f = palm.rec(base + h.fdst);
            if (f.length >= 12 && f[0] == 'F' && f[1] == 'D' && f[2] == 'S' && f[3] == 'T') {
                int secStart = u32(f, 4);
                int num = u32(f, 8);
                for (int i = 0; i < num && secStart + i * 8 + 8 <= f.length; i++) {
                    int a = u32(f, secStart + i * 8);
                    int b = u32(f, secStart + i * 8 + 4);
                    if (a >= 0 && b >= a && b <= raw.length) flows.add(new int[] {a, b});
                }
            }
        }
        if (flows.isEmpty()) flows.add(new int[] {0, raw.length});
        String markup = new String(raw, flows.get(0)[0], flows.get(0)[1] - flows.get(0)[0], LATIN1);

        List<int[]> skels = new ArrayList<int[]>(); // {fragment count, start, length}
        Index si = readIndex(palm, base + h.skel, cs);
        for (Map<Integer, int[]> t : si.tags) {
            int[] c = t.get(1);
            int[] p = t.get(6);
            if (c == null || p == null || p.length < 2) continue;
            skels.add(new int[] {c[0], p[0], p[1]});
        }
        List<Frag> frags = new ArrayList<Frag>();
        Index fi = readIndex(palm, base + h.frag, cs);
        for (int i = 0; i < fi.tags.size(); i++) {
            Map<Integer, int[]> t = fi.tags.get(i);
            int[] file = t.get(3);
            int[] p = t.get(6);
            if (p == null || p.length < 2) continue;
            int insert;
            try {
                insert = Integer.parseInt(fi.keys.get(i).trim());
            } catch (NumberFormatException e) {
                continue;
            }
            frags.add(new Frag(insert, file == null || file.length == 0 ? 0 : file[0], p[1]));
        }
        if (skels.isEmpty()) throw new ConvertException("This AZW3 has no text and can't be read.");

        // put every file together: its skeleton with its fragments inserted
        List<String> parts = new ArrayList<String>();
        List<int[]> span = new ArrayList<int[]>(); // {start, length} of each file in the text numbering the links use
        int fragPtr = 0;
        for (int[] sk : skels) {
            int skelPos = sk[1];
            int baseptr = skelPos + sk[2];
            if (skelPos < 0 || baseptr > markup.length()) throw new ConvertException("This AZW3 is damaged.");
            StringBuilder part = new StringBuilder(markup.substring(skelPos, baseptr));
            for (int i = 0; i < sk[0] && fragPtr < frags.size(); i++, fragPtr++) {
                Frag f = frags.get(fragPtr);
                int len = Math.min(f.length, markup.length() - baseptr);
                if (len < 0) len = 0;
                String slice = markup.substring(baseptr, baseptr + len);
                int at = Math.max(0, Math.min(f.insertPos - skelPos, part.length()));
                // a position inside a tag is moved to after the tag
                int lt = part.lastIndexOf("<", Math.max(0, at - 1));
                int gt = part.lastIndexOf(">", Math.max(0, at - 1));
                if (at > 0 && lt > gt) {
                    int close = part.indexOf(">", at);
                    if (close >= 0) at = close + 1;
                }
                part.insert(at, slice);
                baseptr += len;
            }
            parts.add(part.toString());
            span.add(new int[] {skelPos, baseptr - skelPos});
        }

        // where the links and the contents list point to: (fragment number, offset) -> (file, place in the file)
        List<TocEntry> toc = h.ncx != NULL ? readNcx(palm, base + h.ncx, cs, true) : new ArrayList<TocEntry>();
        List<TreeSet<Integer>> targets = new ArrayList<TreeSet<Integer>>();
        for (int i = 0; i < parts.size(); i++) targets.add(new TreeSet<Integer>());
        for (int i = 0; i < parts.size(); i++) {
            Matcher m = POS_LINK.matcher(parts.get(i));
            while (m.find()) {
                int[] where = locate(base32(m.group(1)), base32(m.group(2)), frags, span, parts);
                if (where != null) targets.get(where[0]).add(where[1]);
            }
        }
        for (TocEntry e : toc) {
            int[] where = locate(e.fid, e.off, frags, span, parts);
            if (where != null) targets.get(where[0]).add(where[1]);
        }

        // style sheets
        final Map<Integer, String> cssPath = new LinkedHashMap<Integer, String>();
        final Images img = images;
        for (int f = 1; f < flows.size(); f++) {
            int[] r = flows.get(f);
            String text = new String(raw, r[0], r[1] - r[0], LATIN1);
            String head = text.length() > 200 ? text.substring(0, 200).trim() : text.trim();
            if (head.startsWith("<")) continue; // SVG and the like are not carried over
            String css = new String(text.getBytes(LATIN1), cs);
            css = css.replaceAll("(?is)@font-face\\s*\\{[^}]*\\}", "");
            Matcher em = EMBED.matcher(css);
            StringBuffer sb = new StringBuffer();
            while (em.find()) {
                String p = img.path(base32(em.group(1)), "../");
                em.appendReplacement(sb, p == null ? "none" : Matcher.quoteReplacement(p));
            }
            em.appendTail(sb);
            css = sb.toString().replaceAll("url\\(\\s*none\\s*\\)", "none").replaceAll("(?i)kindle:[^)\\s;\"']*", "");
            String path = "css/f" + f + ".css";
            cssPath.put(f, path);
            book.resources.add(new EpubBuilder.Resource(path, "text/css", css.getBytes(Charset.forName("UTF-8"))));
        }

        final List<String> partNames = new ArrayList<String>();
        for (int i = 0; i < parts.size(); i++) partNames.add(String.format(Locale.ROOT, "p%04d.xhtml", i + 1));
        final List<int[]> spanF = span;
        final List<Frag> fragsF = frags;
        final List<String> partsF = parts;
        HtmlConverter.Env env = new HtmlConverter.Env() {
            public String href(String raw, int filepos) {
                String r = raw.trim();
                Matcher m = POS_LINK.matcher(r);
                if (m.find()) {
                    int[] where = locate(base32(m.group(1)), base32(m.group(2)), fragsF, spanF, partsF);
                    if (where == null) return null;
                    return partNames.get(where[0]) + "#" + HtmlConverter.anchorName(where[1]);
                }
                String low = r.toLowerCase(Locale.ROOT);
                if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("mailto:")) return r;
                if (r.startsWith("#") && r.length() > 1) return "#" + Xml.id(r.substring(1));
                return null;
            }

            public String image(String src, String recindex) {
                Matcher m = EMBED.matcher(src);
                if (!m.find()) return null;
                return img.path(base32(m.group(1)), "../");
            }
        };

        List<List<HtmlConverter.Heading>> headings = new ArrayList<List<HtmlConverter.Heading>>();
        for (int i = 0; i < parts.size(); i++) {
            String text = parts.get(i);
            TreeSet<Integer> t = targets.get(i);
            int[] anchors = new int[t.size()];
            int k = 0;
            for (int v : t) anchors[k++] = v;
            HtmlConverter conv = new HtmlConverter(cs, true, true, env, "p" + i);
            String body = conv.convert(text, 0, text.length(), anchors);
            headings.add(conv.headings);
            EpubBuilder.Part part = new EpubBuilder.Part("text/" + partNames.get(i), body);
            part.title = book.title;
            Matcher fl = FLOW_LINK.matcher(text);
            while (fl.find()) {
                String p = cssPath.get(base32(fl.group(1)));
                if (p != null && fl.group(2).toLowerCase(Locale.ROOT).contains("css") && !part.styles.contains(p)) part.styles.add(p);
            }
            book.parts.add(part);
        }

        NavTree tree = new NavTree(book.nav);
        for (TocEntry e : toc) {
            int[] where = locate(e.fid, e.off, frags, span, parts);
            if (where == null) continue;
            tree.add(e.depth + 1, e.label, book.parts.get(where[0]).file + "#" + HtmlConverter.anchorName(where[1]));
        }
        if (book.nav.isEmpty()) {
            for (int i = 0; i < book.parts.size(); i++) {
                for (HtmlConverter.Heading hd : headings.get(i)) {
                    if (hd.level <= 3) tree.add(hd.level, hd.text, book.parts.get(i).file + "#" + hd.id);
                }
            }
        }
        if (book.nav.isEmpty()) book.nav.add(new EpubBuilder.Nav(book.title, book.parts.get(0).file));
    }

    /**
     * Turns a link target of KF8 (fragment number, offset in that fragment) into {file number, place in that file}.
     * The place is the start of the tag that holds it.
     */
    private static int[] locate(int fid, int off, List<Frag> frags, List<int[]> span, List<String> parts) {
        if (fid < 0 || fid >= frags.size() || off < 0) return null;
        Frag f = frags.get(fid);
        int pos = f.insertPos + off;
        // the file that holds the position (positions are counted over all files, in order)
        for (int i = 0; i < span.size(); i++) {
            int[] sp = span.get(i);
            if (pos >= sp[0] && pos < sp[0] + sp[1]) {
                int local = pos - sp[0];
                String text = parts.get(i);
                if (local > text.length()) local = text.length();
                // inside a tag: back to where the tag begins
                int lt = text.lastIndexOf('<', Math.max(0, local - 1));
                int gt = text.lastIndexOf('>', Math.max(0, local - 1));
                if (local > 0 && lt > gt) local = lt;
                return new int[] {i, local};
            }
        }
        return null;
    }
}
