package com.paperback.app.convert;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

/** Reads the width and height of a picture from its first bytes, without decoding it (so it works without Android). */
final class ImageSize {
    private ImageSize() {
    }

    /** {width, height}, or null when the kind of picture is not known or the header is damaged. */
    static int[] of(InputStream raw) {
        try {
            BufferedInputStream in = new BufferedInputStream(raw, 8192);
            in.mark(40);
            byte[] h = new byte[32];
            int n = readFully(in, h, 32);
            if (n < 12) return null;
            if ((h[0] & 0xFF) == 0x89 && h[1] == 'P' && h[2] == 'N' && h[3] == 'G') { // PNG
                return n < 24 ? null : new int[] {be32(h, 16), be32(h, 20)};
            }
            if (h[0] == 'G' && h[1] == 'I' && h[2] == 'F') return new int[] {le16(h, 6), le16(h, 8)};
            if (h[0] == 'B' && h[1] == 'M' && n >= 26) return new int[] {Math.abs(le32(h, 18)), Math.abs(le32(h, 22))};
            if (h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F' && h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') {
                return webp(h, n);
            }
            if ((h[0] & 0xFF) == 0xFF && (h[1] & 0xFF) == 0xD8) { // JPEG
                in.reset();
                return jpeg(in);
            }
            return null;
        } catch (IOException e) {
            return null;
        }
    }

    private static int[] webp(byte[] h, int n) {
        if (n < 30 || h[12] != 'V' || h[13] != 'P' || h[14] != '8') return null;
        if (h[15] == ' ') return new int[] {le16(h, 26) & 0x3FFF, le16(h, 28) & 0x3FFF};
        if (h[15] == 'L') {
            int b = (h[21] & 0xFF) | ((h[22] & 0xFF) << 8) | ((h[23] & 0xFF) << 16) | ((h[24] & 0xFF) << 24);
            return new int[] {(b & 0x3FFF) + 1, ((b >> 14) & 0x3FFF) + 1};
        }
        if (h[15] == 'X') {
            int w = ((h[24] & 0xFF) | ((h[25] & 0xFF) << 8) | ((h[26] & 0xFF) << 16)) + 1;
            int hh = ((h[27] & 0xFF) | ((h[28] & 0xFF) << 8) | ((h[29] & 0xFF) << 16)) + 1;
            return new int[] {w, hh};
        }
        return null;
    }

    /** Walks the segments of a JPEG until the "start of frame", which holds the size. */
    private static int[] jpeg(InputStream in) throws IOException {
        if (in.read() != 0xFF || in.read() != 0xD8) return null;
        for (int guard = 0; guard < 4096; guard++) {
            int b = in.read();
            while (b != 0xFF) {
                if (b < 0) return null;
                b = in.read();
            }
            int marker = in.read();
            while (marker == 0xFF) marker = in.read();
            if (marker < 0) return null;
            if (marker == 0xD8 || marker == 0x01 || (marker >= 0xD0 && marker <= 0xD7)) continue; // no length
            int len = (in.read() << 8) | in.read();
            if (len < 2) return null;
            boolean frame = marker >= 0xC0 && marker <= 0xCF && marker != 0xC4 && marker != 0xC8 && marker != 0xCC;
            if (frame) {
                int precision = in.read();
                int h = (in.read() << 8) | in.read();
                int w = (in.read() << 8) | in.read();
                return precision < 0 || w <= 0 || h <= 0 ? null : new int[] {w, h};
            }
            long left = len - 2;
            while (left > 0) {
                long s = in.skip(left);
                if (s <= 0) {
                    if (in.read() < 0) return null;
                    s = 1;
                }
                left -= s;
            }
        }
        return null;
    }

    private static int readFully(InputStream in, byte[] b, int len) throws IOException {
        int total = 0;
        while (total < len) {
            int r = in.read(b, total, len - total);
            if (r < 0) break;
            total += r;
        }
        return total;
    }

    private static int be32(byte[] b, int o) {
        return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }

    private static int le16(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
    }

    private static int le32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }
}
