package com.paperback.app.convert;

/** Escaping for the XML a book is written in. */
final class Xml {
    private Xml() {
    }

    /** Text for an element's content or an attribute: escapes the five special characters and drops characters XML can't hold. */
    static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length() + 16);
        escTo(b, s, 0, s.length());
        return b.toString();
    }

    static void escTo(StringBuilder b, CharSequence s, int from, int to) {
        for (int i = from; i < to; i++) {
            char c = s.charAt(i);
            if (c == '&') b.append("&amp;");
            else if (c == '<') b.append("&lt;");
            else if (c == '>') b.append("&gt;");
            else if (c == '"') b.append("&quot;");
            else if (c == 0x9 || c == 0xA || c == 0xD || (c >= 0x20 && c <= 0xD7FF) || (c >= 0xE000 && c <= 0xFFFD)) b.append(c);
            else if (Character.isHighSurrogate(c) && i + 1 < to && Character.isLowSurrogate(s.charAt(i + 1))) {
                b.append(c).append(s.charAt(i + 1));
                i++;
            }
        }
    }

    /** An id that is valid in XML: letters, digits, "-", "_" and "."; it starts with a letter. */
    static String id(String s) {
        StringBuilder b = new StringBuilder(s.length() + 2);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c > 127;
            b.append(ok ? c : '_');
        }
        if (b.length() == 0) return "x";
        char f = b.charAt(0);
        if (!((f >= 'a' && f <= 'z') || (f >= 'A' && f <= 'Z') || f == '_' || f > 127)) b.insert(0, 'x');
        return b.toString();
    }

    /** Collapses runs of white space to one space and trims the ends. */
    static String squash(String s) {
        StringBuilder b = new StringBuilder(s.length());
        boolean space = true;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c) || c == ' ') {
                if (!space) b.append(' ');
                space = true;
            } else {
                b.append(c);
                space = false;
            }
        }
        int n = b.length();
        if (n > 0 && b.charAt(n - 1) == ' ') b.setLength(n - 1);
        return b.toString();
    }
}
