package com.paperback.app.convert;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Comics: a zip (.cbz) or a tar (.cbt) of page pictures becomes a fixed-layout EPUB with one picture per page. The
 * pictures are copied as they are, not re-encoded, so the file is about as big as the comic was. A ComicInfo.xml
 * inside gives the title, writer, summary and the right-to-left flag for manga.
 */
final class ComicBook {
    private ComicBook() {
    }

    private static final class Page {
        final String name;
        final long size;
        final EpubBuilder.Source source;

        Page(String name, long size, EpubBuilder.Source source) {
            this.name = name;
            this.size = size;
            this.source = source;
        }
    }

    static void convert(File in, String fileName, boolean tar, File out) throws IOException, ConvertException {
        ZipFile zip = null;
        try {
            List<Page> pages = new ArrayList<Page>();
            String info = null;
            if (tar) {
                info = readTar(in, pages);
            } else {
                zip = new ZipFile(in);
                info = readZip(zip, pages);
            }
            if (pages.isEmpty()) throw new ConvertException("There are no page pictures in this comic.");
            Collections.sort(pages, new Comparator<Page>() {
                public int compare(Page a, Page b) {
                    return natural(a.name.toLowerCase(Locale.ROOT), b.name.toLowerCase(Locale.ROOT));
                }
            });

            EpubBuilder book = new EpubBuilder();
            book.fixedLayout = true;
            book.title = BookConverter.titleFromName(fileName);
            applyInfo(book, info);
            book.identifier = BookConverter.identifier("comic", book.title, in.length());

            int no = 0;
            int lastW = 1200;
            int lastH = 1800;
            for (Page p : pages) {
                no++;
                String ext = extensionOf(p.name);
                int[] size = null;
                InputStream probe = p.source.open();
                try {
                    size = ImageSize.of(probe);
                } finally {
                    probe.close();
                }
                if (size != null && size[0] > 0 && size[1] > 0) {
                    lastW = size[0];
                    lastH = size[1];
                }
                String imagePath = String.format(Locale.ROOT, "images/p%04d.%s", no, ext);
                EpubBuilder.Resource res = new EpubBuilder.Resource(imagePath, mediaType(ext), p.source);
                res.cover = no == 1;
                book.resources.add(res);
                String body = "<img src=\"../" + imagePath + "\" alt=\"\" width=\"" + lastW + "\" height=\"" + lastH + "\"/>";
                EpubBuilder.Part part = new EpubBuilder.Part(String.format(Locale.ROOT, "text/p%04d.xhtml", no), body);
                part.viewport = "width=" + lastW + ", height=" + lastH;
                part.title = "Page " + no;
                book.parts.add(part);
            }
            book.nav.add(new EpubBuilder.Nav(book.title, book.parts.get(0).file));
            book.write(out);
        } finally {
            if (zip != null) {
                try {
                    zip.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static boolean isPage(String name) {
        String low = name.toLowerCase(Locale.ROOT);
        if (!BookFormat.isImageName(low)) return false;
        if (low.startsWith("__macosx/") || low.contains("/__macosx/")) return false;
        String base = low.substring(low.lastIndexOf('/') + 1);
        return !base.startsWith("."); // hidden files, "._page.jpg"
    }

    private static String readZip(final ZipFile zip, List<Page> pages) throws IOException {
        String info = null;
        Enumeration<? extends ZipEntry> en = zip.entries();
        while (en.hasMoreElements()) {
            final ZipEntry e = en.nextElement();
            if (e.isDirectory()) continue;
            String name = e.getName();
            String low = name.toLowerCase(Locale.ROOT);
            if (low.equals("comicinfo.xml") || low.endsWith("/comicinfo.xml")) {
                info = new String(readAll(zip.getInputStream(e), 1 << 20), "UTF-8");
            } else if (isPage(name)) {
                pages.add(new Page(name, e.getSize(), new EpubBuilder.Source() {
                    public InputStream open() throws IOException {
                        return zip.getInputStream(e);
                    }
                }));
            }
        }
        return info;
    }

    /** Reads the headers of a tar file: where each picture starts and how long it is. */
    private static String readTar(final File file, List<Page> pages) throws IOException {
        String info = null;
        RandomAccessFile raf = new RandomAccessFile(file, "r");
        try {
            long pos = 0;
            long total = raf.length();
            byte[] h = new byte[512];
            String longName = null;
            while (pos + 512 <= total) {
                raf.seek(pos);
                raf.readFully(h);
                boolean empty = true;
                for (int i = 0; i < 512 && empty; i++) if (h[i] != 0) empty = false;
                if (empty) break;
                String name = cString(h, 0, 100);
                String prefix = cString(h, 345, 155);
                if (prefix.length() > 0 && new String(h, 257, 5, "ISO-8859-1").equals("ustar")) name = prefix + "/" + name;
                final long size = octal(h, 124, 12);
                char type = (char) (h[156] & 0xFF);
                final long data = pos + 512;
                pos = data + ((size + 511) / 512) * 512;
                if (type == 'L') { // a GNU long file name: the data is the name of the next entry
                    byte[] nameBytes = new byte[(int) Math.min(size, 4096)];
                    raf.seek(data);
                    raf.readFully(nameBytes);
                    longName = cString(nameBytes, 0, nameBytes.length);
                    continue;
                }
                if (type == 'x') { // a pax header: "path=" overrides the name of the next entry
                    byte[] rec = new byte[(int) Math.min(size, 16384)];
                    raf.seek(data);
                    raf.readFully(rec);
                    Matcher m = Pattern.compile("\\d+ path=([^\\n]*)\\n").matcher(new String(rec, "UTF-8"));
                    if (m.find()) longName = m.group(1);
                    continue;
                }
                if (longName != null) {
                    name = longName;
                    longName = null;
                }
                if (type != '0' && type != 0) continue;
                String low = name.toLowerCase(Locale.ROOT);
                if (low.equals("comicinfo.xml") || low.endsWith("/comicinfo.xml")) {
                    byte[] b = new byte[(int) Math.min(size, 1 << 20)];
                    raf.seek(data);
                    raf.readFully(b);
                    info = new String(b, "UTF-8");
                } else if (isPage(name)) {
                    pages.add(new Page(name, size, new EpubBuilder.Source() {
                        public InputStream open() throws IOException {
                            return new TarSlice(file, data, size);
                        }
                    }));
                }
            }
        } finally {
            raf.close();
        }
        return info;
    }

    /** One file inside a tar, read as a stream of its own. */
    private static final class TarSlice extends InputStream {
        private final FileInputStream in;
        private long left;

        TarSlice(File file, long start, long size) throws IOException {
            in = new FileInputStream(file);
            long s = start;
            while (s > 0) {
                long k = in.skip(s);
                if (k <= 0) throw new IOException("Can't read the comic");
                s -= k;
            }
            left = size;
        }

        @Override
        public int read() throws IOException {
            if (left <= 0) return -1;
            int b = in.read();
            if (b >= 0) left--;
            return b;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int r = in.read(b, off, (int) Math.min(len, left));
            if (r > 0) left -= r;
            return r;
        }

        @Override
        public void close() throws IOException {
            in.close();
        }
    }

    private static String cString(byte[] b, int off, int len) {
        int e = off;
        while (e < off + len && e < b.length && b[e] != 0) e++;
        try {
            return new String(b, off, e - off, "UTF-8");
        } catch (java.io.UnsupportedEncodingException x) {
            return new String(b, off, e - off);
        }
    }

    private static long octal(byte[] b, int off, int len) {
        long v = 0;
        for (int i = off; i < off + len; i++) {
            int c = b[i];
            if (c >= '0' && c <= '7') v = v * 8 + (c - '0');
            else if (v > 0 || c == 0) break;
        }
        return v;
    }

    private static byte[] readAll(InputStream in, int limit) throws IOException {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && bo.size() < limit) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }

    // ---------------------------------------------------------------------------------------------

    private static void applyInfo(EpubBuilder book, String xml) {
        if (xml == null) return;
        String title = tag(xml, "Title");
        String series = tag(xml, "Series");
        String number = tag(xml, "Number");
        if (title.length() > 0) book.title = title;
        else if (series.length() > 0) book.title = series + (number.length() > 0 ? " #" + number : "");
        String writer = tag(xml, "Writer");
        if (writer.length() == 0) writer = tag(xml, "Penciller");
        for (String w : writer.split("[,;]")) if (w.trim().length() > 0) book.authors.add(w.trim());
        for (String g : tag(xml, "Genre").split("[,;]")) if (g.trim().length() > 0) book.subjects.add(g.trim());
        book.publisher = tag(xml, "Publisher");
        book.description = tag(xml, "Summary");
        String lang = tag(xml, "LanguageISO");
        if (lang.matches("[A-Za-z]{2,3}(-[A-Za-z]{2,4})?")) book.language = lang;
        String year = tag(xml, "Year");
        if (year.matches("\\d{4}")) {
            String month = tag(xml, "Month");
            book.date = year + (month.matches("\\d{1,2}") ? "-" + (month.length() == 1 ? "0" + month : month) : "");
        }
        if (tag(xml, "Manga").equalsIgnoreCase("YesAndRightToLeft")) book.rtl = true;
    }

    private static String tag(String xml, String name) {
        Matcher m = Pattern.compile("(?is)<" + name + "\\b[^>]*>(.*?)</" + name + ">").matcher(xml);
        if (!m.find()) return "";
        String v = m.group(1).replaceAll("(?s)<!\\[CDATA\\[(.*?)\\]\\]>", "$1");
        return Xml.squash(Entities.decode(v));
    }

    private static String extensionOf(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        String ext = n.substring(n.lastIndexOf('.') + 1);
        return ext.equals("jpeg") ? "jpg" : ext;
    }

    private static String mediaType(String ext) {
        if (ext.equals("jpg")) return "image/jpeg";
        if (ext.equals("png")) return "image/png";
        if (ext.equals("gif")) return "image/gif";
        if (ext.equals("webp")) return "image/webp";
        if (ext.equals("bmp")) return "image/bmp";
        if (ext.equals("avif")) return "image/avif";
        return "application/octet-stream";
    }

    /** "page2" before "page10": numbers inside names are compared as numbers. */
    static int natural(String a, String b) {
        int i = 0;
        int j = 0;
        while (i < a.length() && j < b.length()) {
            char x = a.charAt(i);
            char y = b.charAt(j);
            if (Character.isDigit(x) && Character.isDigit(y)) {
                int si = i;
                int sj = j;
                while (i < a.length() && Character.isDigit(a.charAt(i))) i++;
                while (j < b.length() && Character.isDigit(b.charAt(j))) j++;
                String na = a.substring(si, i).replaceFirst("^0+(?=.)", "");
                String nb = b.substring(sj, j).replaceFirst("^0+(?=.)", "");
                if (na.length() != nb.length()) return na.length() < nb.length() ? -1 : 1;
                int c = na.compareTo(nb);
                if (c != 0) return c;
            } else {
                if (x != y) return x < y ? -1 : 1;
                i++;
                j++;
            }
        }
        return Integer.compare(a.length() - i, b.length() - j);
    }
}
