package com.paperback.app.convert;

/** A book that can't be turned into an EPUB. The message is written for the person and is shown as it is. */
public final class ConvertException extends Exception {
    private static final long serialVersionUID = 1L;

    public ConvertException(String message) {
        super(message);
    }

    public ConvertException(String message, Throwable cause) {
        super(message, cause);
    }
}
