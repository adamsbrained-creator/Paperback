package com.paperback.app.convert;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;

/** Reads the bytes of a text file as text without being told the encoding (which a .txt file never says). */
final class TextCodec {
    private TextCodec() {
    }

    static Charset charset(String name, String fallback) {
        try {
            return Charset.forName(name.trim());
        } catch (Exception e) {
            return Charset.forName(fallback);
        }
    }

    /** The text of [b]: a byte-order mark decides first, then valid UTF-8, then the usual single-byte code pages. */
    static String decode(byte[] b) {
        String s = decodeRaw(b);
        return s.length() > 0 && s.charAt(0) == '﻿' ? s.substring(1) : s;
    }

    private static String decodeRaw(byte[] b) {
        int n = b.length;
        if (n >= 3 && (b[0] & 0xFF) == 0xEF && (b[1] & 0xFF) == 0xBB && (b[2] & 0xFF) == 0xBF) {
            return new String(b, 3, n - 3, charset("UTF-8", "UTF-8"));
        }
        if (n >= 2 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xFE) return new String(b, 2, n - 2, charset("UTF-16LE", "UTF-8"));
        if (n >= 2 && (b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0xFF) return new String(b, 2, n - 2, charset("UTF-16BE", "UTF-8"));

        // UTF-16 without a mark: every other byte is zero in text that is mostly Latin letters
        int sample = Math.min(n, 4000);
        int evenZero = 0;
        int oddZero = 0;
        for (int i = 0; i < sample; i++) {
            if (b[i] == 0) {
                if ((i & 1) == 0) evenZero++;
                else oddZero++;
            }
        }
        if (sample >= 8 && oddZero * 3 > sample && evenZero * 20 < sample) return new String(b, charset("UTF-16LE", "UTF-8"));
        if (sample >= 8 && evenZero * 3 > sample && oddZero * 20 < sample) return new String(b, charset("UTF-16BE", "UTF-8"));

        if (isUtf8(b)) return new String(b, charset("UTF-8", "UTF-8"));
        return new String(b, singleByteCharset(b));
    }

    static boolean isUtf8(byte[] b) {
        try {
            Charset.forName("UTF-8").newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b));
            return true;
        } catch (CharacterCodingException e) {
            return false;
        }
    }

    /**
     * Which single-byte code page a file that is not UTF-8 is most likely in. Windows-1252 (Western Europe) unless the
     * bytes say Cyrillic (windows-1251) or Central European letters (windows-1250: Czech, Polish, Slovak, Hungarian).
     */
    static Charset singleByteCharset(byte[] b) {
        int high = 0;
        int cyr = 0;
        int ce1 = 0; // bytes that are letters in windows-1250 and nothing a Western text uses
        int ce2 = 0; // bytes that are also seen in Western text (š, ž) but never alone in a Czech or Polish one
        int ce3 = 0; // ą ł: superscript 1 and 3 in a Western text
        for (byte x : b) {
            int v = x & 0xFF;
            if (v < 0x80) continue;
            high++;
            if (v >= 0xC0) cyr++;
            if (v == 0x8D || v == 0x8F || v == 0x9D) ce1++;
            if (v == 0x8A || v == 0x8E || v == 0x9A || v == 0x9E) ce2++;
            if (v == 0xB9 || v == 0xB3) ce3++;
        }
        if (high == 0) return charset("windows-1252", "ISO-8859-1");
        if (high * 10 > b.length * 3 && cyr * 10 > high * 8) return charset("windows-1251", "ISO-8859-1");
        if (ce1 >= 1 || ce2 >= 3 || ce3 >= 3) return charset("windows-1250", "ISO-8859-1");
        return charset("windows-1252", "ISO-8859-1");
    }
}
