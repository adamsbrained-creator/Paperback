package com.paperback.app.convert;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Writes an EPUB 3 file from parts the converters made: XHTML pages, pictures, a table of contents and the book's
 * details. Every converter in this package ends here, so a MOBI, an FB2 or a comic opens in the same reader as an EPUB.
 * The output is the same for the same input (fixed dates).
 */
public final class EpubBuilder {

    /** Where the bytes of a picture or a style sheet come from; opened once, when the file is written. */
    public interface Source {
        InputStream open() throws IOException;
    }

    /** One page of the book. [body] is what goes inside the body element, already valid XHTML. */
    public static final class Part {
        /** Path inside the OEBPS folder, such as "text/p001.xhtml". */
        public final String file;
        public final String body;
        public String title = "";
        /** For fixed-layout pages: "width=800, height=1200". */
        public String viewport;
        /** Extra style sheets for this page, as paths inside the OEBPS folder. */
        public final List<String> styles = new ArrayList<String>();

        public Part(String file, String body) {
            this.file = file;
            this.body = body;
        }
    }

    /** A picture, a font or a style sheet. */
    public static final class Resource {
        public final String path;
        public final String mediaType;
        final byte[] data;
        final Source source;
        public boolean cover;

        public Resource(String path, String mediaType, byte[] data) {
            this.path = path;
            this.mediaType = mediaType;
            this.data = data;
            this.source = null;
        }

        public Resource(String path, String mediaType, Source source) {
            this.path = path;
            this.mediaType = mediaType;
            this.data = null;
            this.source = source;
        }
    }

    /** A line of the table of contents. */
    public static final class Nav {
        public final String title;
        /** Path inside the OEBPS folder, with an optional "#anchor". */
        public final String href;
        public final List<Nav> children = new ArrayList<Nav>();

        public Nav(String title, String href) {
            this.title = title;
            this.href = href;
        }
    }

    public String title = "Untitled";
    public final List<String> authors = new ArrayList<String>();
    public String language = "en";
    public String identifier = "urn:paperback:converted";
    public String publisher = "";
    public String description = "";
    /** A date such as "2011-05-01" or just "2011". */
    public String date = "";
    public final List<String> subjects = new ArrayList<String>();
    /** Pages turn from right to left (manga, Arabic, Hebrew). */
    public boolean rtl;
    /** Every page is a picture of a fixed size (comics). */
    public boolean fixedLayout;
    public String css = DEFAULT_CSS;

    public final List<Part> parts = new ArrayList<Part>();
    public final List<Resource> resources = new ArrayList<Resource>();
    public final List<Nav> nav = new ArrayList<Nav>();

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final Set<String> RTL_LANGUAGES = new HashSet<String>(Arrays.asList("ar", "he", "fa", "ur", "yi", "ps", "sd", "ug", "dv"));

    public static final String DEFAULT_CSS =
            "body { margin: 0; line-height: 1.45; }\n"
                    + "h1, h2, h3, h4, h5, h6 { line-height: 1.25; margin: 1.6em 0 0.6em; page-break-after: avoid; break-after: avoid; }\n"
                    + "h1 { font-size: 1.6em; }\n"
                    + "h2 { font-size: 1.3em; }\n"
                    + "h3 { font-size: 1.15em; }\n"
                    + "h4, h5, h6 { font-size: 1em; }\n"
                    + "p { margin: 0 0 0.85em; }\n"
                    + "blockquote { margin: 1em 1.5em; }\n"
                    + "pre { white-space: pre-wrap; word-wrap: break-word; }\n"
                    + "hr { border: 0; height: 1.2em; margin: 1.2em 0; text-align: center; }\n"
                    + "hr:after { content: \"* * *\"; letter-spacing: 0.3em; }\n"
                    + "ul, ol { margin: 0 0 0.85em; padding-left: 1.6em; }\n"
                    + "li { margin: 0 0 0.3em; }\n"
                    + "table { border-collapse: collapse; margin: 1em 0; }\n"
                    + "td, th { border: 1px solid #8884; padding: 0.25em 0.5em; vertical-align: top; }\n"
                    + "img { max-width: 100%; height: auto; }\n"
                    + ".img { text-align: center; margin: 1em 0; }\n"
                    + ".center { text-align: center; }\n"
                    + ".poem { margin: 1em 1.5em; }\n"
                    + ".stanza { margin: 0 0 1em; }\n"
                    + ".epigraph { margin: 1em 0 1em 3em; font-style: italic; }\n"
                    + ".author { text-align: right; font-style: italic; }\n"
                    + ".subtitle { text-align: center; font-weight: bold; margin: 1.2em 0 0.6em; }\n"
                    + ".empty { height: 1em; }\n"
                    + ".note { font-size: 0.9em; }\n";

    private static final String FIXED_CSS =
            "html, body { margin: 0; padding: 0; }\n"
                    + "img { display: block; margin: 0; padding: 0; max-width: none; }\n";

    /** Writes the file. [out] is replaced if it exists. */
    public void write(File out) throws IOException {
        if (parts.isEmpty()) throw new IOException("The book has no pages");
        String lang = language == null || language.trim().length() == 0 ? "en" : language.trim();
        boolean right = rtl || RTL_LANGUAGES.contains(lang.toLowerCase().split("[-_]")[0]);

        File tmp = new File(out.getPath() + ".part");
        ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp), 64 * 1024));
        boolean ok = false;
        try {
            long fixed = new GregorianCalendar(2000, 0, 1, 0, 0, 0).getTimeInMillis();

            // the mimetype entry comes first and is stored, not compressed
            byte[] mime = "application/epub+zip".getBytes(UTF8);
            ZipEntry me = new ZipEntry("mimetype");
            me.setMethod(ZipEntry.STORED);
            me.setSize(mime.length);
            me.setCompressedSize(mime.length);
            CRC32 crc = new CRC32();
            crc.update(mime);
            me.setCrc(crc.getValue());
            me.setTime(fixed);
            zip.putNextEntry(me);
            zip.write(mime);
            zip.closeEntry();

            zip.setLevel(6);
            putText(zip, "META-INF/container.xml", fixed,
                    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                            + "<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\">\n"
                            + "  <rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles>\n"
                            + "</container>\n");
            putText(zip, "OEBPS/style.css", fixed, fixedLayout ? FIXED_CSS : css);

            Set<String> written = new HashSet<String>();
            for (Part p : parts) {
                putText(zip, "OEBPS/" + p.file, fixed, pageXhtml(p, lang, right));
                written.add(p.file);
            }
            for (Resource r : resources) {
                if (!written.add(r.path)) continue;
                boolean packed = r.mediaType.startsWith("text/") || r.mediaType.contains("xml") || r.mediaType.contains("svg");
                zip.setLevel(packed ? 6 : 0); // pictures are already compressed
                if (r.data != null) {
                    ZipEntry e = new ZipEntry("OEBPS/" + r.path);
                    e.setTime(fixed);
                    zip.putNextEntry(e);
                    zip.write(r.data);
                    zip.closeEntry();
                } else {
                    ZipEntry e = new ZipEntry("OEBPS/" + r.path);
                    e.setTime(fixed);
                    zip.putNextEntry(e);
                    InputStream in = r.source.open();
                    try {
                        byte[] buf = new byte[32 * 1024];
                        int n;
                        while ((n = in.read(buf)) > 0) zip.write(buf, 0, n);
                    } finally {
                        in.close();
                    }
                    zip.closeEntry();
                }
            }
            zip.setLevel(6);
            putText(zip, "OEBPS/nav.xhtml", fixed, navXhtml(lang));
            putText(zip, "OEBPS/content.opf", fixed, opf(lang, right, written));
            ok = true;
        } finally {
            try {
                zip.close();
            } catch (IOException ignored) {
            }
            if (!ok) tmp.delete();
        }
        if (out.exists() && !out.delete()) {
            tmp.delete();
            throw new IOException("Can't replace " + out);
        }
        if (!tmp.renameTo(out)) {
            tmp.delete();
            throw new IOException("Can't write " + out);
        }
    }

    // ---------------------------------------------------------------------------------------------

    private String pageXhtml(Part p, String lang, boolean right) {
        StringBuilder b = new StringBuilder(p.body.length() + 600);
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        b.append("<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\" lang=\"")
                .append(Xml.esc(lang)).append("\" xml:lang=\"").append(Xml.esc(lang)).append('"');
        if (right) b.append(" dir=\"rtl\"");
        b.append(">\n<head><meta charset=\"utf-8\"/><title>")
                .append(Xml.esc(p.title.length() > 0 ? p.title : title)).append("</title>");
        if (p.viewport != null) b.append("<meta name=\"viewport\" content=\"").append(Xml.esc(p.viewport)).append("\"/>");
        b.append("<link rel=\"stylesheet\" type=\"text/css\" href=\"").append(up(p.file)).append("style.css\"/>");
        for (String s : p.styles) {
            b.append("<link rel=\"stylesheet\" type=\"text/css\" href=\"").append(up(p.file)).append(Xml.esc(s)).append("\"/>");
        }
        b.append("</head>\n<body>\n").append(p.body).append("\n</body>\n</html>\n");
        return b.toString();
    }

    /** "../" for every folder a file sits in: "text/p1.xhtml" is "../". */
    private static String up(String file) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < file.length(); i++) if (file.charAt(i) == '/') b.append("../");
        return b.toString();
    }

    private String navXhtml(String lang) {
        StringBuilder b = new StringBuilder();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        b.append("<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\" lang=\"")
                .append(Xml.esc(lang)).append("\" xml:lang=\"").append(Xml.esc(lang)).append("\">\n");
        b.append("<head><meta charset=\"utf-8\"/><title>Contents</title></head>\n<body>\n");
        b.append("<nav epub:type=\"toc\" id=\"toc\"><h1>Contents</h1>\n");
        List<Nav> list = nav;
        if (list.isEmpty()) {
            list = new ArrayList<Nav>();
            list.add(new Nav(title, parts.get(0).file));
        }
        appendNav(b, list);
        b.append("</nav>\n</body>\n</html>\n");
        return b.toString();
    }

    private static void appendNav(StringBuilder b, List<Nav> list) {
        b.append("<ol>\n");
        for (Nav e : list) {
            b.append("<li><a href=\"").append(Xml.esc(e.href)).append("\">")
                    .append(Xml.esc(e.title.trim().length() == 0 ? "Untitled" : e.title)).append("</a>");
            if (!e.children.isEmpty()) {
                b.append('\n');
                appendNav(b, e.children);
            }
            b.append("</li>\n");
        }
        b.append("</ol>\n");
    }

    private String opf(String lang, boolean right, Set<String> written) {
        StringBuilder b = new StringBuilder();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        b.append("<package xmlns=\"http://www.idpf.org/2007/opf\" version=\"3.0\" unique-identifier=\"bookid\" xml:lang=\"")
                .append(Xml.esc(lang)).append("\" prefix=\"rendition: http://www.idpf.org/vocab/rendition/#\">\n");
        b.append("<metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\">\n");
        b.append("<dc:identifier id=\"bookid\">").append(Xml.esc(identifier)).append("</dc:identifier>\n");
        b.append("<dc:title>").append(Xml.esc(title)).append("</dc:title>\n");
        b.append("<dc:language>").append(Xml.esc(lang)).append("</dc:language>\n");
        for (String a : authors) {
            if (a != null && a.trim().length() > 0) b.append("<dc:creator>").append(Xml.esc(a.trim())).append("</dc:creator>\n");
        }
        if (publisher != null && publisher.trim().length() > 0) {
            b.append("<dc:publisher>").append(Xml.esc(publisher.trim())).append("</dc:publisher>\n");
        }
        if (description != null && description.trim().length() > 0) {
            b.append("<dc:description>").append(Xml.esc(description.trim())).append("</dc:description>\n");
        }
        for (String s : subjects) {
            if (s != null && s.trim().length() > 0) b.append("<dc:subject>").append(Xml.esc(s.trim())).append("</dc:subject>\n");
        }
        if (date != null && date.trim().length() > 0) b.append("<dc:date>").append(Xml.esc(date.trim())).append("</dc:date>\n");
        b.append("<meta property=\"dcterms:modified\">2000-01-01T00:00:00Z</meta>\n");
        if (fixedLayout) {
            b.append("<meta property=\"rendition:layout\">pre-paginated</meta>\n");
            b.append("<meta property=\"rendition:orientation\">auto</meta>\n");
        }
        String coverId = null;
        int k = 1;
        StringBuilder items = new StringBuilder();
        for (Resource r : resources) {
            if (!written.contains(r.path)) continue;
            String id = "r" + (k++);
            items.append("<item id=\"").append(id).append("\" href=\"").append(Xml.esc(r.path)).append("\" media-type=\"")
                    .append(Xml.esc(r.mediaType)).append('"');
            if (r.cover && coverId == null) {
                coverId = id;
                items.append(" properties=\"cover-image\"");
            }
            items.append("/>\n");
        }
        if (coverId != null) b.append("<meta name=\"cover\" content=\"").append(coverId).append("\"/>\n");
        b.append("</metadata>\n<manifest>\n");
        b.append("<item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/>\n");
        b.append("<item id=\"css\" href=\"style.css\" media-type=\"text/css\"/>\n");
        int i = 1;
        for (Part p : parts) {
            b.append("<item id=\"s").append(i++).append("\" href=\"").append(Xml.esc(p.file))
                    .append("\" media-type=\"application/xhtml+xml\"/>\n");
        }
        b.append(items);
        b.append("</manifest>\n<spine");
        if (right) b.append(" page-progression-direction=\"rtl\"");
        b.append(">\n");
        for (int j = 1; j < i; j++) b.append("<itemref idref=\"s").append(j).append("\"/>\n");
        b.append("</spine>\n</package>\n");
        return b.toString();
    }

    private static void putText(ZipOutputStream zip, String name, long time, String text) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(time);
        zip.putNextEntry(e);
        zip.write(text.getBytes(UTF8));
        zip.closeEntry();
    }
}
