package com.paperback.app.convert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** The kinds of book file Paperback knows, and how to tell them apart (by what is inside first, by the name second). */
public enum BookFormat {
    /** Opened by the reader as it is. */
    EPUB,
    /** Opened by the PDF viewer as it is. */
    PDF,
    TEXT, MARKDOWN, HTML,
    /** FictionBook, also when zipped (.fb2.zip, .fbz). */
    FB2,
    /** Kindle and Mobipocket: .mobi, .azw, .azw3, .prc, and the old PalmDOC .pdb. */
    MOBI,
    DOCX,
    /** A comic: a zip (.cbz) or a tar (.cbt) of page pictures. */
    COMIC_ZIP, COMIC_TAR,
    /** A kind of book Paperback knows by name but can't read (CBR, DJVU, RTF...). */
    UNSUPPORTED,
    UNKNOWN;

    /** True for the formats that are turned into an EPUB when they are added. */
    public boolean needsConversion() {
        switch (this) {
            case TEXT: case MARKDOWN: case HTML: case FB2: case MOBI: case DOCX: case COMIC_ZIP: case COMIC_TAR:
                return true;
            default:
                return false;
        }
    }

    /** The short name shown to people ("MOBI", "comic"). */
    public String label() {
        switch (this) {
            case TEXT: return "text";
            case MARKDOWN: return "Markdown";
            case HTML: return "web page";
            case FB2: return "FB2";
            case MOBI: return "MOBI";
            case DOCX: return "Word";
            case COMIC_ZIP: case COMIC_TAR: return "comic";
            case EPUB: return "EPUB";
            case PDF: return "PDF";
            default: return "book";
        }
    }

    private static final String[] IMAGE_EXT = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".avif"};

    static boolean isImageName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String e : IMAGE_EXT) if (n.endsWith(e)) return true;
        return false;
    }

    /** The format of [file], whose name was [name] when it was picked (the file on disk may have another name). */
    public static BookFormat detect(File file, String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        byte[] head = new byte[4096];
        int len = 0;
        try {
            InputStream in = new FileInputStream(file);
            try {
                int r;
                while (len < head.length && (r = in.read(head, len, head.length - len)) > 0) len += r;
            } finally {
                in.close();
            }
        } catch (IOException e) {
            return UNKNOWN;
        }
        if (len == 0) return UNKNOWN;

        if (len >= 4 && head[0] == '%' && head[1] == 'P' && head[2] == 'D' && head[3] == 'F') return PDF;
        if (len >= 4 && head[0] == 'P' && head[1] == 'K' && (head[2] == 3 || head[2] == 5)) return detectZip(file, n);
        if (len >= 4 && head[0] == 'R' && head[1] == 'a' && head[2] == 'r' && head[3] == '!') return UNSUPPORTED;
        if (len >= 6 && (head[0] & 0xFF) == 0x37 && (head[1] & 0xFF) == 0x7A && (head[2] & 0xFF) == 0xBC && (head[3] & 0xFF) == 0xAF) return UNSUPPORTED;
        if (len >= 5 && head[0] == '{' && head[1] == '\\' && head[2] == 'r' && head[3] == 't' && head[4] == 'f') return UNSUPPORTED;
        if (len >= 4 && (head[0] & 0xFF) == 0xD0 && (head[1] & 0xFF) == 0xCF && (head[2] & 0xFF) == 0x11 && (head[3] & 0xFF) == 0xE0) return UNSUPPORTED;
        if (len >= 8 && head[0] == 'A' && head[1] == 'T' && head[2] == '&' && head[3] == 'T' && head[4] == 'F') return UNSUPPORTED; // DjVu
        if (len >= 8 && head[0] == 'I' && head[1] == 'T' && head[2] == 'O' && head[3] == 'L' && head[4] == 'I' && head[5] == 'T') return UNSUPPORTED; // LIT
        if (len >= 4 && head[0] == 'C' && head[1] == 'O' && head[2] == 'N' && head[3] == 'T') return UNSUPPORTED; // Kindle KFX container

        // PalmDB: the type and creator of the database sit at byte 60
        if (len >= 68) {
            String tc = new String(head, 60, 8, Charset.forName("ISO-8859-1"));
            if (tc.equals("BOOKMOBI") || tc.equals("TEXtREAd")) return MOBI;
        }
        if (len >= 262 && head[257] == 'u' && head[258] == 's' && head[259] == 't' && head[260] == 'a' && head[261] == 'r') return COMIC_TAR;

        String text = new String(head, 0, Math.min(len, 2048), Charset.forName("ISO-8859-1"));
        if (text.contains("<FictionBook")) return FB2;
        String lower = text.toLowerCase(Locale.ROOT);
        boolean markup = lower.contains("<html") || lower.contains("<!doctype html") || lower.contains("<body");

        // by name
        if (n.endsWith(".fb2")) return FB2;
        if (n.endsWith(".md") || n.endsWith(".markdown") || n.endsWith(".mkd")) return MARKDOWN;
        if (n.endsWith(".html") || n.endsWith(".htm") || n.endsWith(".xhtml") || n.endsWith(".xht")) return HTML;
        if (markup) return HTML;
        if (n.endsWith(".txt") || n.endsWith(".text") || n.endsWith(".asc") || n.endsWith(".log")) return looksLikeText(head, len) ? TEXT : UNKNOWN;
        if (n.endsWith(".cbr") || n.endsWith(".cb7") || n.endsWith(".djvu") || n.endsWith(".djv") || n.endsWith(".lit") || n.endsWith(".lrf")
                || n.endsWith(".rtf") || n.endsWith(".doc") || n.endsWith(".odt") || n.endsWith(".kfx")) return UNSUPPORTED;
        // a file with no extension at all that reads as text
        if (n.indexOf('.') < 0 && looksLikeText(head, len)) return TEXT;
        return UNKNOWN;
    }

    private static boolean looksLikeText(byte[] b, int len) {
        if (len == 0) return false;
        int odd = 0;
        for (int i = 0; i < len; i++) {
            int v = b[i] & 0xFF;
            if (v == 0 && len > 2) {
                // UTF-16 text has zero bytes; a byte-order mark says so
                if ((b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xFE) return true;
                if ((b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0xFF) return true;
                return false;
            }
            if (v < 9 || (v > 13 && v < 32)) odd++;
        }
        return odd * 50 < len;
    }

    private static BookFormat detectZip(File file, String lowerName) {
        ZipFile zip = null;
        try {
            zip = new ZipFile(file);
            boolean container = false;
            boolean word = false;
            boolean office = false;
            boolean fb2 = false;
            int images = 0;
            int entries = 0;
            Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String name = e.getName();
                String low = name.toLowerCase(Locale.ROOT);
                entries++;
                if (low.equals("meta-inf/container.xml")) container = true;
                else if (low.equals("word/document.xml")) word = true;
                else if (low.startsWith("xl/") || low.startsWith("ppt/") || low.equals("content.xml")) office = true;
                else if (low.endsWith(".fb2")) fb2 = true;
                else if (isImageName(low) && !low.startsWith("__macosx/")) images++;
            }
            if (container) return EPUB;
            if (word) return DOCX;
            if (office) return UNSUPPORTED;
            if (fb2 && entries <= 4) return FB2;
            if (images > 0 && images * 2 >= entries) return COMIC_ZIP;
            return UNKNOWN;
        } catch (IOException e) {
            return UNKNOWN;
        } finally {
            if (zip != null) {
                try {
                    zip.close();
                } catch (IOException ignored) {
                }
            }
        }
    }
}
