package com.paperback.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Block
import com.paperback.app.data.Book
import com.paperback.app.data.Goals
import com.paperback.app.data.HomeFigures
import com.paperback.app.data.PinnedStat
import com.paperback.app.data.Similar
import com.paperback.app.data.Stats
import com.paperback.app.data.goalCue
import com.paperback.app.data.pinnedValue
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/*
 * The looks of the blocks Customize Home adds to Home, and the pieces Home and the constructor share:
 * the corner radius and title size of the layout, the frame the editor draws around a block, and the note
 * a block shows in the editor when it has nothing to show yet.
 */

/** The corner radius of Home's cards. 24 dp, as they always were, unless a layout from Customize Home says otherwise. */
internal val LocalHomeRound = compositionLocalOf { 24.dp }

/** True when the layout asks for big section titles. */
internal val LocalHomeLargeTitles = compositionLocalOf { false }

/**
 * Set while Home is drawn inside Customize Home. Blocks are not usable there. With an [onSelect] each block gets a
 * frame and a tap picks it ([selectedId] is the picked one); without it the whole Home is just a picture.
 */
class HomePreview(val selectedId: Int?, val onSelect: ((Int) -> Unit)?)

/** A section title: the small grey label, or a big one when the layout asks for it. */
@Composable
internal fun BlockTitle(text: String, modifier: Modifier = Modifier) {
    if (LocalHomeLargeTitles.current) {
        Text(text, modifier = modifier, color = pbTokens().ink, fontFamily = PbSerif, fontSize = 22.sp, fontWeight = FontWeight.Medium)
    } else {
        Eyebrow(text, modifier)
    }
}

// ---- the editor's helpers --------------------------------------------------------------------------

/** Keeps whatever is inside from reacting to touches, and optionally makes the whole thing one tap target. */
@Composable
internal fun Inert(onClick: (() -> Unit)?, content: @Composable () -> Unit) {
    Box {
        content()
        Box(
            Modifier
                .matchParentSize()
                .then(
                    if (onClick != null) {
                        Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
                    } else {
                        Modifier.pointerInput(Unit) { detectTapGestures { } }
                    },
                ),
        )
    }
}

/** The dashed frame (solid and in the accent when picked) the editor draws around a block, with its name on top when picked. */
@Composable
internal fun EditableFrame(block: Block, selected: Boolean, onSelect: () -> Unit, content: @Composable () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    val outline = pbTokens().setSub.copy(alpha = 0.55f)
    val dashed = remember { PathEffect.dashPathEffect(floatArrayOf(14f, 10f)) }
    val radius = LocalHomeRound.current + 6.dp
    Box(
        Modifier
            .fillMaxWidth()
            .drawWithContent {
                drawContent()
                val w = (if (selected) 4.dp else 2.5.dp).toPx()
                val pad = 8.dp.toPx()
                drawRoundRect(
                    color = if (selected) accent else outline,
                    topLeft = Offset(-pad + w / 2, -pad + w / 2),
                    size = Size(size.width + 2 * pad - w, size.height + 2 * pad - w),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius.toPx()),
                    style = Stroke(width = w, pathEffect = if (selected) null else dashed),
                )
            },
    ) {
        Inert(onClick = onSelect, content = content)
        if (selected) {
            Text(
                block.title,
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 8.dp)
                    .offset(y = (-31).dp)
                    .clip(CircleShape)
                    .background(accent)
                    // room below the letters, or the tail of a "g" is cut off
                    .padding(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 6.dp),
            )
        }
    }
}

/** What the editor shows for a block that has nothing to show yet (it would be missing from the real Home). */
@Composable
internal fun EmptyBlockNote(block: Block) {
    val t = pbTokens()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalHomeRound.current))
            .background(t.card)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Text(block.title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(block.type.empty, color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

/** A thin line between two blocks. */
@Composable
internal fun HomeDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(pbTokens().rule))
}

// ---- Greeting ---------------------------------------------------------------------------------------

/** "Good evening" with the date, optionally with chips for the streak and today's minutes, or just the big date. */
@Composable
internal fun GreetingBlock(style: String, showDate: Boolean, streak: Int, minutesToday: Int) {
    val t = pbTokens()
    val now = remember { LocalDateTime.now() }
    val hello = when {
        now.hour < 5 -> "Good night"
        now.hour < 12 -> "Good morning"
        now.hour < 18 -> "Good afternoon"
        else -> "Good evening"
    }
    val day = remember { now.format(DateTimeFormatter.ofPattern("EEEE")) }
    val rest = remember { now.format(DateTimeFormatter.ofPattern("d MMMM")) }
    if (style == "date") {
        Column(Modifier.fillMaxWidth()) {
            Text(day, color = t.ink, fontFamily = PbSerif, fontSize = 36.sp, lineHeight = 40.sp, fontWeight = FontWeight.Medium)
            Text(rest, color = MaterialTheme.colorScheme.primary, fontFamily = PbSerif, fontSize = 36.sp, lineHeight = 40.sp, fontWeight = FontWeight.Medium)
        }
        return
    }
    Column(Modifier.fillMaxWidth()) {
        Text(hello, color = t.ink, fontFamily = PbSerif, fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Medium)
        if (showDate) Text("$day, $rest", color = t.setSub, fontSize = 15.sp, modifier = Modifier.padding(top = 2.dp))
        if (style == "stats") {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoChip(if (streak > 0) "$streak-day streak" else "No streak yet", strong = streak > 0)
                InfoChip("$minutesToday min today", strong = false)
            }
        }
    }
}

@Composable
private fun InfoChip(text: String, strong: Boolean) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    Text(
        text,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (strong) primary.copy(alpha = 0.14f) else t.card)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        color = if (strong) primary else t.ink,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        maxLines = 1,
    )
}

// ---- Continue reading -------------------------------------------------------------------------------

/**
 * The book you are in, in one of four looks. With no book to open it is the "add your first books" card.
 * [title], [button], [left] and [picker] are the block's switches.
 */
@Composable
internal fun ContinueBlock(
    style: String,
    next: Book?,
    pace: Double?,
    title: Boolean,
    button: Boolean,
    left: Boolean,
    picker: Boolean,
    pickNext: ((Int) -> List<Similar.NextPick>)?,
    pickMoods: List<Int>,
    onOpen: (Book) -> Unit,
    onRead: (Book) -> Unit,
    onDetails: (Book) -> Unit,
    onImport: () -> Unit,
    onDiscover: () -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        if (title) {
            BlockTitle("Continue reading")
            Spacer(Modifier.height(12.dp))
        }
        if (next == null) {
            LibraryEmpty(onImport = onImport, onDiscover = onDiscover)
            return@Column
        }
        val timeLeft = if (left) Stats.timeLeftSeconds(next, pace)?.let { " · ${Stats.duration(it)} left" } ?: "" else ""
        val label = if (next.isReading) "Resume reading" else "Start reading"
        when (style) {
            "card" -> ContinueCard(next, timeLeft, button, if (next.isReading) "Resume" else "Start", onOpen, onRead, onDetails)
            "compact" -> ContinueCompact(next, timeLeft, button, onOpen, onRead, onDetails)
            "hero" -> ContinueHero(next, timeLeft, button, label, onOpen, onRead, onDetails)
            else -> ContinueClassic(next, timeLeft, button, label, onOpen, onRead, onDetails)
        }
        // when nothing is half-read, help choose what to start
        if (picker && !next.isReading && pickNext != null && remember(pickNext) { pickNext(0).isNotEmpty() }) {
            Spacer(Modifier.height(10.dp))
            NextReadPicker(pickNext, pickMoods, onRead = onRead, onDetails = onDetails)
        }
    }
}

/** The look Home always had: a big cover on the left, the details beside it, the pill button below. */
@Composable
private fun ContinueClassic(next: Book, timeLeft: String, button: Boolean, label: String, onOpen: (Book) -> Unit, onRead: (Book) -> Unit, onDetails: (Book) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        BookCover(next, Modifier.width(132.dp).clickable { onOpen(next) })
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(
                next.title,
                modifier = Modifier.clickable { onDetails(next) },
                fontFamily = PbSerif,
                fontSize = 22.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
            if (next.author.isNotBlank()) {
                Text(next.author, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(14.dp))
            if (next.currentPage > 0 && next.pageCount > 0) {
                Text("Page ${next.currentPage} of ${next.pageCount}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
            Spacer(Modifier.height(8.dp))
            ProgressTrack(next.progress)
            Spacer(Modifier.height(8.dp))
            Text("${next.percent}%$timeLeft", fontSize = 14.sp)
        }
    }
    if (button) {
        Spacer(Modifier.height(18.dp))
        PbButton(label, onClick = { onRead(next) })
    }
}

/** A card: small cover, title, progress and a coral pill. */
@Composable
private fun ContinueCard(next: Book, timeLeft: String, button: Boolean, pill: String, onOpen: (Book) -> Unit, onRead: (Book) -> Unit, onDetails: (Book) -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalHomeRound.current))
            .background(t.card)
            .padding(14.dp),
    ) {
        BookCover(next, Modifier.width(96.dp).clickable { onOpen(next) })
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                next.title,
                modifier = Modifier.clickable { onDetails(next) },
                color = t.ink,
                fontFamily = PbSerif,
                fontSize = 19.sp,
                lineHeight = 23.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            if (next.author.isNotBlank()) {
                Text(next.author, color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(12.dp))
            ProgressTrack(next.progress)
            Spacer(Modifier.height(6.dp))
            Text("${next.percent}%$timeLeft", color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (button) {
                Spacer(Modifier.height(12.dp))
                AccentPill(pill, onClick = { onRead(next) })
            }
        }
    }
}

/** One slim row: tiny cover, title, a thin progress line and a round play button. */
@Composable
private fun ContinueCompact(next: Book, timeLeft: String, button: Boolean, onOpen: (Book) -> Unit, onRead: (Book) -> Unit, onDetails: (Book) -> Unit) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalHomeRound.current))
            .background(t.card)
            .clickable { onDetails(next) }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BookCover(next, Modifier.width(48.dp).clickable { onOpen(next) })
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(next.title, color = t.ink, fontFamily = PbSerif, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${next.percent}%$timeLeft", color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            ProgressTrack(next.progress, height = 4.dp)
        }
        if (button) {
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier
                    .size(44.dp)
                    .pbTap({ onRead(next) }, CircleShape, role = Role.Button)
                    .background(primary),
                contentAlignment = Alignment.Center,
            ) {
                PbIcon(PbIconName.Play, size = 20.dp, tint = MaterialTheme.colorScheme.onPrimary, filled = true, contentDescription = "Read")
            }
        }
    }
}

/** A big cover in the middle, the title under it and the button below. */
@Composable
private fun ContinueHero(next: Book, timeLeft: String, button: Boolean, label: String, onOpen: (Book) -> Unit, onRead: (Book) -> Unit, onDetails: (Book) -> Unit) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        BookCover(next, Modifier.width(176.dp).clickable { onOpen(next) })
        Spacer(Modifier.height(18.dp))
        Text(
            next.title,
            modifier = Modifier.fillMaxWidth().clickable { onDetails(next) },
            color = t.ink,
            fontFamily = PbSerif,
            fontSize = 24.sp,
            lineHeight = 29.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (next.author.isNotBlank()) {
            Text(next.author, modifier = Modifier.fillMaxWidth(), color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(16.dp))
        ProgressTrack(next.progress, Modifier.fillMaxWidth(0.7f))
        Spacer(Modifier.height(8.dp))
        val page = if (next.currentPage > 0 && next.pageCount > 0) "Page ${next.currentPage} of ${next.pageCount} · " else ""
        Text("$page${next.percent}%$timeLeft", color = t.setSub, fontSize = 13.sp, textAlign = TextAlign.Center)
        if (button) {
            Spacer(Modifier.height(18.dp))
            PbButton(label, onClick = { onRead(next) })
        }
    }
}

/** A small coral pill button. */
@Composable
private fun AccentPill(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    Box(
        modifier
            .height(40.dp)
            .pbTap(onClick, RoundedCornerShape(20.dp), role = Role.Button)
            .background(primary)
            .padding(horizontal = 22.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = MaterialTheme.colorScheme.onPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

// ---- Today: the strip and the big ring --------------------------------------------------------------

/** The pinned stats as small cards in one row you swipe sideways. */
@Composable
internal fun PinnedStrip(pinned: List<PinnedStat>, figures: HomeFigures, goals: Goals, hour: Int, onOpen: (PinnedStat) -> Unit) {
    val t = pbTokens()
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        pinned.forEach { s ->
            val v = pinnedValue(s, figures, goals, hour)
            Column(
                Modifier
                    .width(128.dp)
                    .pbTap({ onOpen(s) }, RoundedCornerShape(LocalHomeRound.current), pressedScale = 0.975f, onClickLabel = "Open in Stats", role = Role.Button)
                    .background(t.card)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
            ) {
                Text(v.label, color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(v.value, color = t.ink, fontFamily = PbSerif, fontSize = 22.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Today's goal as one big ring in a card, with the minutes and the streak beside it. */
@Composable
internal fun BigGoalRing(figures: HomeFigures, goals: Goals, onClick: () -> Unit) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    val minutes = (figures.todaySeconds / 60L).toInt()
    val fraction = (figures.todaySeconds / 60f / goals.minutesPerDay.coerceAtLeast(1)).coerceIn(0f, 1f)
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { armed = true }
    val shown by animateFloatAsState(if (armed) fraction else 0f, tween(900, easing = PbEaseOut), label = "bigRing")
    Row(
        Modifier
            .fillMaxWidth()
            .pbTap(onClick, RoundedCornerShape(LocalHomeRound.current), pressedScale = 0.985f, onClickLabel = "Open in Stats", role = Role.Button)
            .background(t.card)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Box(Modifier.size(104.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(104.dp)) {
                val stroke = 10.dp.toPx()
                val inset = stroke / 2f
                val arc = Size(size.width - stroke, size.height - stroke)
                drawArc(t.rule, 0f, 360f, false, topLeft = Offset(inset, inset), size = arc, style = Stroke(width = stroke))
                if (shown > 0.001f) {
                    drawArc(primary, -90f, 360f * shown, false, topLeft = Offset(inset, inset), size = arc, style = Stroke(width = stroke, cap = StrokeCap.Round))
                } else {
                    drawCircle(primary, radius = stroke / 2f, center = Offset(size.width / 2f, inset))
                }
            }
            Text("${Math.round(shown * 100f)}%", color = t.ink, fontFamily = PbSerif, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        }
        Column(Modifier.weight(1f)) {
            Text("Daily goal", color = t.setSub, fontSize = 13.sp)
            Text("$minutes of ${goals.minutesPerDay} min", color = t.ink, fontFamily = PbSerif, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            if (goals.tinyMinutes > 0) {
                Text(goalCue(figures.todaySeconds, goals.minutesPerDay, goals.tinyMinutes), color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(
                if (figures.streak > 0) "${figures.streak}-day streak" else "Read today to start a streak",
                color = primary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

// ---- Shortcuts --------------------------------------------------------------------------------------

private class Shortcut(val key: String, val label: String, val icon: PbIconName, val go: () -> Unit)

/** Buttons that open Library, Stats, Discover and Import: one row, or two-by-two tiles. [shown] are the keys switched on. */
@Composable
internal fun ShortcutsBlock(
    style: String,
    shown: Set<String>,
    onLibrary: () -> Unit,
    onStats: () -> Unit,
    onDiscover: () -> Unit,
    onImport: () -> Unit,
) {
    val t = pbTokens()
    val items = listOf(
        Shortcut("library", "Library", PbIconName.Library, onLibrary),
        Shortcut("stats", "Stats", PbIconName.Stats, onStats),
        Shortcut("discover", "Discover", PbIconName.Discover, onDiscover),
        Shortcut("import", "Import", PbIconName.ImportFile, onImport),
    ).filter { it.key in shown }
    if (items.isEmpty()) return
    val round = LocalHomeRound.current
    if (style == "grid") {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { s ->
                        Row(
                            Modifier
                                .weight(1f)
                                .height(64.dp)
                                .pbTap(s.go, RoundedCornerShape(round), pressedScale = 0.97f, role = Role.Button)
                                .background(t.card)
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                                PbIcon(s.icon, size = 20.dp, tint = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(s.label, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    } else {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items.forEach { s ->
                Column(
                    Modifier
                        .weight(1f)
                        .pbTap(s.go, RoundedCornerShape(round), pressedScale = 0.96f, role = Role.Button)
                        .background(t.card)
                        .padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    PbIcon(s.icon, size = 24.dp, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    Text(s.label, color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
            }
        }
    }
}

// ---- Quote ------------------------------------------------------------------------------------------

/** The passage of the day as big text on the page, with no card. */
@Composable
internal fun QuotePlain(text: String, note: String, bookTitle: String, chapter: String) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth()) {
        Eyebrow("Quote of the day")
        Spacer(Modifier.height(10.dp))
        Text("“${text.trim().take(320)}”", color = t.ink, fontFamily = PbSerif, fontSize = 22.sp, lineHeight = 32.sp)
        if (note.isNotBlank()) Text(note.trim().take(200), color = t.setSub, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(10.dp))
        Text(bookTitle, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        if (chapter.isNotBlank()) Text(chapter, color = t.setSub, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
    }
}
