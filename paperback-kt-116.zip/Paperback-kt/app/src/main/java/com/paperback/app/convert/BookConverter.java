package com.paperback.app.convert;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.UUID;

/**
 * Turns a book file in one of the other formats into an EPUB, which the reader opens like any other book.
 * Plain Java with no Android, so it can be tested on a computer. Usage: [BookFormat.detect], and for a format that
 * [BookFormat.needsConversion], [convert].
 */
public final class BookConverter {
    private BookConverter() {
    }

    /** What the app tells people it can add. */
    public static final String SUPPORTED = "EPUB, PDF, MOBI, AZW3, FB2, DOCX, CBZ, TXT, Markdown and HTML";

    private static final long MAX_BYTES = 256L * 1024 * 1024;

    /** Converts [in] (named [name] when it was picked) to the EPUB [out]. [out] is not left behind when this fails. */
    public static void convert(File in, String name, BookFormat format, File out) throws ConvertException {
        try {
            switch (format) {
                case TEXT:
                    TextBook.plainText(readAll(in), name, out);
                    break;
                case MARKDOWN:
                    TextBook.markdown(readAll(in), name, out);
                    break;
                case HTML:
                    TextBook.html(readAll(in), name, out);
                    break;
                case FB2:
                    Fb2Book.convert(in, name, out);
                    break;
                case MOBI:
                    MobiBook.convert(in, name, out);
                    break;
                case DOCX:
                    DocxBook.convert(in, name, out);
                    break;
                case COMIC_ZIP:
                    ComicBook.convert(in, name, false, out);
                    break;
                case COMIC_TAR:
                    ComicBook.convert(in, name, true, out);
                    break;
                default:
                    throw new ConvertException(unsupportedMessage(name));
            }
        } catch (ConvertException e) {
            out.delete();
            throw e;
        } catch (OutOfMemoryError e) {
            out.delete();
            throw new ConvertException("This book is too big to be converted on this phone.");
        } catch (IOException e) {
            out.delete();
            throw new ConvertException("This " + format.label() + " file couldn't be read.", e);
        } catch (RuntimeException e) {
            out.delete();
            throw new ConvertException("This " + format.label() + " file couldn't be read.", e);
        }
    }

    /** What to tell the person about a file of a kind that can't be opened. */
    public static String unsupportedMessage(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".cbr") || n.endsWith(".rar")) return "RAR comics (CBR) can't be opened. Save the comic as CBZ first.";
        if (n.endsWith(".cb7") || n.endsWith(".7z")) return "7-Zip comics (CB7) can't be opened. Save the comic as CBZ first.";
        if (n.endsWith(".doc") || n.endsWith(".rtf") || n.endsWith(".odt")) return "Word .doc, RTF and ODT files can't be opened. Save it as DOCX, EPUB or PDF first.";
        if (n.endsWith(".djvu") || n.endsWith(".djv")) return "DjVu books can't be opened. Save it as PDF or EPUB first.";
        if (n.endsWith(".lit") || n.endsWith(".lrf")) return "LIT and LRF books can't be opened. Save it as EPUB first.";
        if (n.endsWith(".kfx")) return "Kindle KFX files can't be opened. Get the AZW3 or MOBI version instead.";
        return "This kind of file can't be opened. Paperback reads " + SUPPORTED + ".";
    }

    /** A readable title from a file name: "my_book-v2.fb2.zip" is "my book-v2". */
    static String titleFromName(String name) {
        String n = name == null ? "" : name;
        int slash = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (slash >= 0) n = n.substring(slash + 1);
        String known = ".zip .fb2 .fbz .mobi .azw .azw3 .azw4 .prc .pdb .epub .txt .text .md .markdown .html .htm .xhtml .docx .cbz .cbt ";
        while (true) {
            int dot = n.lastIndexOf('.');
            if (dot <= 0) break;
            String ext = n.substring(dot).toLowerCase(Locale.ROOT);
            if (!known.contains(ext + " ")) break;
            n = n.substring(0, dot);
        }
        n = n.replace('_', ' ').trim().replaceAll("\\s+", " ");
        return n.length() == 0 ? "Untitled" : n;
    }

    /** The same book always gets the same identifier, so converting twice gives the same file. */
    static String identifier(String kind, String title, long size) {
        return "urn:uuid:" + UUID.nameUUIDFromBytes((kind + "|" + title + "|" + size).getBytes()).toString();
    }

    static byte[] readAll(File f) throws IOException, ConvertException {
        if (f.length() > MAX_BYTES) throw new ConvertException("This file is too big to be converted on a phone.");
        InputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream((int) Math.max(1024, f.length()));
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }

    static byte[] readAll(InputStream in, long limit) throws IOException {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[64 * 1024];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > limit) throw new IOException("Too big");
                bo.write(buf, 0, n);
            }
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }
}
