package com.paperback.app.convert;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/** FictionBook 2 (.fb2, and .fb2.zip / .fbz): chapters, poems, footnotes, pictures and the book's details. */
final class Fb2Book {
    private Fb2Book() {
    }

    private static final long MAX = 200L * 1024 * 1024;

    static void convert(File in, String fileName, File out) throws IOException, ConvertException {
        byte[] data = load(in);
        String xml = decodeXml(data);
        data = null;
        Handler h = new Handler();
        try {
            parse(xml, h);
        } catch (SAXException e) {
            // many files in the wild have a bare "&" or stray control characters: clean them and try once more
            h = new Handler();
            try {
                parse(sanitize(xml), h);
            } catch (SAXException e2) {
                throw new ConvertException("This FB2 file is damaged and can't be read.", e2);
            }
        }
        h.finish(fileName, in.length(), out);
    }

    private static byte[] load(File in) throws IOException, ConvertException {
        byte[] head = new byte[4];
        java.io.FileInputStream fi = new java.io.FileInputStream(in);
        int n;
        try {
            n = fi.read(head);
        } finally {
            fi.close();
        }
        if (n == 4 && head[0] == 'P' && head[1] == 'K') {
            ZipFile zip = new ZipFile(in);
            try {
                Enumeration<? extends ZipEntry> en = zip.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    if (!e.isDirectory() && e.getName().toLowerCase(Locale.ROOT).endsWith(".fb2")) {
                        return BookConverter.readAll(zip.getInputStream(e), MAX);
                    }
                }
            } finally {
                zip.close();
            }
            throw new ConvertException("There is no FB2 book inside this zip.");
        }
        return BookConverter.readAll(in);
    }

    /** The text of the file, read in the encoding its first line names (windows-1251 is common in Russian libraries). */
    private static String decodeXml(byte[] data) {
        String head = new String(data, 0, Math.min(data.length, 300), Charset.forName("ISO-8859-1"));
        Matcher m = Pattern.compile("<\\?xml[^>]*encoding\\s*=\\s*[\"']([^\"']+)[\"']").matcher(head);
        boolean bom = data.length >= 2 && (((data[0] & 0xFF) == 0xFF && (data[1] & 0xFF) == 0xFE) || ((data[0] & 0xFF) == 0xFE && (data[1] & 0xFF) == 0xFF));
        String s;
        if (!bom && m.find()) s = new String(data, TextCodec.charset(m.group(1), "UTF-8"));
        else s = TextCodec.decode(data);
        if (s.length() > 0 && s.charAt(0) == '\uFEFF') s = s.substring(1);
        return s;
    }

    private static String sanitize(String xml) {
        StringBuilder b = new StringBuilder(xml.length());
        for (int i = 0; i < xml.length(); i++) {
            char c = xml.charAt(i);
            if (c == 0x9 || c == 0xA || c == 0xD || (c >= 0x20 && c <= 0xD7FF) || (c >= 0xE000 && c <= 0xFFFD) || Character.isSurrogate(c)) b.append(c);
        }
        return b.toString().replaceAll("&(?!(?:amp|lt|gt|quot|apos|#\\d+|#x[0-9a-fA-F]+);)", "&amp;");
    }

    private static void parse(String xml, DefaultHandler h) throws IOException, SAXException {
        try {
            SAXParserFactory f = SAXParserFactory.newInstance();
            f.setNamespaceAware(false);
            f.setValidating(false);
            String[][] features = {
                {"http://xml.org/sax/features/external-general-entities", "false"},
                {"http://xml.org/sax/features/external-parameter-entities", "false"},
                {"http://apache.org/xml/features/nonvalidating/load-external-dtd", "false"},
            };
            for (String[] ft : features) {
                try {
                    f.setFeature(ft[0], Boolean.parseBoolean(ft[1]));
                } catch (Exception ignored) {
                    // this parser doesn't have the switch
                }
            }
            f.newSAXParser().parse(new InputSource(new StringReader(xml)), h);
        } catch (ParserConfigurationException e) {
            throw new SAXException(e);
        }
    }

    // ---------------------------------------------------------------------------------------------

    private static final Set<String> STRUCTURE = new HashSet<String>(java.util.Arrays.asList(
            "body", "section", "poem", "stanza", "table", "tr", "epigraph", "cite", "annotation", "history", "title-info", "description"));
    private static final Set<String> INLINE_PARENTS = new HashSet<String>(java.util.Arrays.asList(
            "p", "v", "subtitle", "text-author", "strong", "emphasis", "a", "td", "th", "style", "sub", "sup", "strikethrough", "code", "title"));
    private static final int SPLIT_DEPTH2_AT = 30000;

    private static final class Binary {
        final String type;
        final byte[] data;

        Binary(String type, byte[] data) {
            this.type = type;
            this.data = data;
        }
    }

    private static final class Head {
        final int level;
        final String title;
        final int page;
        final String id;

        Head(int level, String title, int page, String id) {
            this.level = level;
            this.title = title;
            this.page = page;
            this.id = id;
        }
    }

    private static final class Handler extends DefaultHandler {
        final List<String> stack = new ArrayList<String>();
        final List<String> closers = new ArrayList<String>();

        // the book's details
        String bookTitle = "";
        final List<String> authors = new ArrayList<String>();
        final List<String> subjects = new ArrayList<String>();
        String lang = "";
        String publisher = "";
        String date = "";
        String year = "";
        String coverId = "";
        final StringBuilder annotation = new StringBuilder();
        String[] author;

        // capture of single values in the description
        StringBuilder capture;
        String captureKey;

        // binaries
        String binId;
        String binType;
        StringBuilder binBuf;
        final Map<String, Binary> binaries = new HashMap<String, Binary>();

        // the body
        final List<StringBuilder> pages = new ArrayList<StringBuilder>();
        final List<String> pageTitles = new ArrayList<String>();
        final List<Head> heads = new ArrayList<Head>();
        final Map<String, Integer> idPage = new HashMap<String, Integer>();
        final Set<String> usedImages = new HashSet<String>();
        boolean inBody;
        boolean notesBody;
        boolean mainSeen;
        int sectionDepth;
        int headCount;
        int notesPage = -1;
        StringBuilder titleHtml;
        StringBuilder titlePlain;
        boolean titleFirst;
        boolean titleInNotes;
        boolean titleMinor;
        int titleDepth;

        StringBuilder page() {
            if (pages.isEmpty()) {
                pages.add(new StringBuilder());
                pageTitles.add("");
            }
            return pages.get(pages.size() - 1);
        }

        void newPage() {
            if (pages.isEmpty() || pages.get(pages.size() - 1).length() > 0) {
                pages.add(new StringBuilder());
                pageTitles.add("");
            }
        }

        StringBuilder out() {
            return titleHtml != null ? titleHtml : page();
        }

        String parent() {
            return stack.size() >= 2 ? stack.get(stack.size() - 2) : "";
        }

        boolean inside(String name) {
            return stack.contains(name);
        }

        @Override
        public void startElement(String uri, String local, String qName, Attributes a) {
            String n = local(qName);
            stack.add(n);
            String closer = "";
            if (binBuf == null && n.equals("binary")) {
                binId = a.getValue("id");
                binType = a.getValue("content-type");
                binBuf = new StringBuilder();
                closers.add("");
                return;
            }
            if (inside("description")) {
                description(n, a);
                closers.add("");
                return;
            }
            if (n.equals("body")) {
                inBody = true;
                String name = a.getValue("name");
                notesBody = (name != null && (name.equalsIgnoreCase("notes") || name.equalsIgnoreCase("comments"))) || mainSeen;
                if (!notesBody) mainSeen = true;
                if (notesBody) {
                    newPage();
                    notesPage = pages.size() - 1;
                    pageTitles.set(notesPage, "Notes");
                }
                sectionDepth = 0;
                closers.add("");
                return;
            }
            if (!inBody) {
                closers.add("");
                return;
            }
            StringBuilder o = out();
            if (n.equals("section")) {
                sectionDepth++;
                if (!notesBody && (sectionDepth == 1 || (sectionDepth == 2 && page().length() > SPLIT_DEPTH2_AT))) newPage();
                String id = a.getValue("id");
                if (id != null && id.length() > 0) {
                    String x = Xml.id(id);
                    page().append("<a id=\"").append(Xml.esc(x)).append("\"></a>");
                    idPage.put(x, pages.size() - 1);
                }
            } else if (n.equals("title")) {
                titleHtml = new StringBuilder();
                titlePlain = new StringBuilder();
                titleFirst = true;
                titleInNotes = notesBody;
                // the title of a poem, a cite or a table is a line in the text, not a chapter
                titleMinor = parent().equals("poem") || parent().equals("cite") || parent().equals("epigraph") || parent().equals("stanza");
                titleDepth = sectionDepth;
            } else if (n.equals("p")) {
                if (titleHtml != null) {
                    if (!titleFirst) {
                        titleHtml.append("<br/>");
                        titlePlain.append(' ');
                    }
                    titleFirst = false;
                } else {
                    o.append(notesBody ? "<p class=\"note\">" : "<p>");
                    closer = "</p>\n";
                }
            } else if (n.equals("empty-line")) {
                o.append("<div class=\"empty\"></div>\n");
            } else if (n.equals("subtitle")) {
                o.append("<p class=\"subtitle\">");
                closer = "</p>\n";
            } else if (n.equals("epigraph")) {
                o.append("<div class=\"epigraph\">\n");
                closer = "</div>\n";
            } else if (n.equals("text-author")) {
                o.append("<p class=\"author\">");
                closer = "</p>\n";
            } else if (n.equals("poem")) {
                o.append("<div class=\"poem\">\n");
                closer = "</div>\n";
            } else if (n.equals("stanza")) {
                o.append("<div class=\"stanza\">\n");
                closer = "</div>\n";
            } else if (n.equals("v")) {
                o.append("<p class=\"v\">");
                closer = "</p>\n";
            } else if (n.equals("cite")) {
                o.append("<blockquote>\n");
                closer = "</blockquote>\n";
            } else if (n.equals("table")) {
                o.append("<table>\n");
                closer = "</table>\n";
            } else if (n.equals("tr")) {
                o.append("<tr>");
                closer = "</tr>\n";
            } else if (n.equals("td") || n.equals("th")) {
                o.append('<').append(n);
                for (String k : new String[] {"colspan", "rowspan"}) {
                    String v = a.getValue(k);
                    if (v != null && v.matches("\\d{1,3}")) o.append(' ').append(k).append("=\"").append(v).append('"');
                }
                o.append('>');
                closer = "</" + n + ">";
            } else if (n.equals("strong") || n.equals("sub") || n.equals("sup") || n.equals("code")) {
                o.append('<').append(n).append('>');
                closer = "</" + n + ">";
            } else if (n.equals("emphasis")) {
                o.append("<em>");
                closer = "</em>";
            } else if (n.equals("strikethrough")) {
                o.append("<s>");
                closer = "</s>";
            } else if (n.equals("style")) {
                o.append("<span>");
                closer = "</span>";
            } else if (n.equals("a")) {
                String href = href(a);
                if (href != null && href.startsWith("#") && href.length() > 1) {
                    o.append("<a href=\"#").append(Xml.esc(Xml.id(href.substring(1)))).append("\">");
                    closer = "</a>";
                } else if (href != null && (href.startsWith("http://") || href.startsWith("https://") || href.startsWith("mailto:"))) {
                    o.append("<a href=\"").append(Xml.esc(href)).append("\">");
                    closer = "</a>";
                }
            } else if (n.equals("image")) {
                String href = href(a);
                if (href != null && href.startsWith("#") && href.length() > 1) {
                    String id = href.substring(1);
                    usedImages.add(id);
                    boolean inline = INLINE_PARENTS.contains(parent());
                    String img = "<img src=\"../images/@@IMG:" + Xml.id(id) + "@@\" alt=\"\"/>";
                    o.append(inline ? img : "<div class=\"img\">" + img + "</div>\n");
                }
            }
            closers.add(closer);
        }

        private void description(String n, Attributes a) {
            boolean titleInfo = stack.contains("title-info");
            boolean publishInfo = stack.contains("publish-info");
            if (titleInfo) {
                if (n.equals("author") && parent().equals("title-info")) {
                    author = new String[4];
                } else if (n.equals("image") && stack.contains("coverpage")) {
                    String href = href(a);
                    if (href != null && href.startsWith("#")) coverId = href.substring(1);
                } else if (n.equals("p") && stack.contains("annotation")) {
                    if (annotation.length() > 0) annotation.append(' ');
                } else if (n.equals("book-title") || n.equals("genre") || n.equals("lang") || n.equals("date")
                        || (author != null && (n.equals("first-name") || n.equals("middle-name") || n.equals("last-name") || n.equals("nickname")))) {
                    capture = new StringBuilder();
                    captureKey = n;
                }
            } else if (publishInfo && (n.equals("publisher") || n.equals("year"))) {
                capture = new StringBuilder();
                captureKey = n;
            }
        }

        @Override
        public void characters(char[] ch, int start, int length) {
            if (binBuf != null) {
                binBuf.append(ch, start, length);
                return;
            }
            if (capture != null) {
                capture.append(ch, start, length);
                return;
            }
            if (inside("description")) {
                if (stack.contains("annotation") && stack.contains("title-info")) annotation.append(ch, start, length);
                return;
            }
            if (!inBody) return;
            String parent = stack.isEmpty() ? "" : stack.get(stack.size() - 1);
            boolean blank = true;
            for (int i = start; i < start + length && blank; i++) if (!Character.isWhitespace(ch[i])) blank = false;
            if (blank && STRUCTURE.contains(parent)) return;
            Xml.escTo(out(), new String(ch, start, length), 0, length);
            if (titlePlain != null) titlePlain.append(ch, start, length);
        }

        @Override
        public void endElement(String uri, String local, String qName) {
            String n = local(qName);
            String closer = closers.isEmpty() ? "" : closers.remove(closers.size() - 1);
            if (!stack.isEmpty()) stack.remove(stack.size() - 1);
            if (n.equals("binary") && binBuf != null) {
                try {
                    byte[] d = Base64.getMimeDecoder().decode(binBuf.toString().trim());
                    if (binId != null && d.length > 0) binaries.put(binId, new Binary(binType, d));
                } catch (IllegalArgumentException ignored) {
                    // a damaged picture is left out
                }
                binBuf = null;
                return;
            }
            if (capture != null && n.equals(captureKey)) {
                String v = Xml.squash(capture.toString());
                capture = null;
                if (n.equals("book-title")) bookTitle = v;
                else if (n.equals("genre")) {
                    String g = genre(v);
                    if (g.length() > 0 && !subjects.contains(g)) subjects.add(g);
                } else if (n.equals("lang")) lang = v.toLowerCase(Locale.ROOT);
                else if (n.equals("date")) date = v;
                else if (n.equals("publisher")) publisher = v;
                else if (n.equals("year")) year = v;
                else if (author != null) {
                    int k = n.equals("first-name") ? 0 : n.equals("middle-name") ? 1 : n.equals("last-name") ? 2 : 3;
                    author[k] = v;
                }
                return;
            }
            if (n.equals("author") && author != null && stack.contains("title-info")) {
                StringBuilder name = new StringBuilder();
                for (int k = 0; k < 3; k++) {
                    if (author[k] != null && author[k].length() > 0) {
                        if (name.length() > 0) name.append(' ');
                        name.append(author[k]);
                    }
                }
                if (name.length() == 0 && author[3] != null) name.append(author[3]);
                if (name.length() > 0) authors.add(name.toString());
                author = null;
                return;
            }
            if (!inBody) return;
            if (n.equals("title") && titleHtml != null) {
                finishTitle();
                return;
            }
            if (n.equals("section")) {
                sectionDepth--;
            } else if (n.equals("body")) {
                inBody = false;
                notesBody = false;
            }
            if (closer.length() > 0) out().append(closer);
        }

        private void finishTitle() {
            String html = titleHtml.toString();
            String plain = Xml.squash(titlePlain.toString());
            titleHtml = null;
            titlePlain = null;
            if (html.trim().length() == 0) return;
            StringBuilder p = page();
            if (titleMinor) {
                p.append("<p class=\"subtitle\">").append(html).append("</p>\n");
                return;
            }
            if (titleInNotes && titleDepth > 0) {
                p.append("<p class=\"note\"><strong>").append(html).append("</strong></p>\n");
                return;
            }
            String id = "t" + (++headCount);
            if (titleDepth == 0) {
                p.append("<h1 id=\"").append(id).append("\">").append(html).append("</h1>\n");
                if (pageTitles.get(pages.size() - 1).length() == 0) pageTitles.set(pages.size() - 1, plain);
                return;
            }
            int h = Math.min(6, titleDepth + 1);
            p.append("<h").append(h).append(" id=\"").append(id).append("\">").append(html).append("</h").append(h).append(">\n");
            if (plain.length() > 0) {
                heads.add(new Head(Math.min(4, titleDepth), plain, pages.size() - 1, id));
                if (pageTitles.get(pages.size() - 1).length() == 0) pageTitles.set(pages.size() - 1, plain);
            }
        }

        // ------------------------------------------------------------------------------------------

        void finish(String fileName, long size, File out) throws IOException, ConvertException {
            EpubBuilder book = new EpubBuilder();
            book.title = bookTitle.length() > 0 ? bookTitle : BookConverter.titleFromName(fileName);
            book.authors.addAll(authors);
            book.subjects.addAll(subjects);
            if (lang.matches("[a-z]{2,3}(-[a-z]{2,4})?")) book.language = lang;
            book.publisher = publisher;
            String ann = Xml.squash(annotation.toString());
            book.description = ann.length() > 1500 ? ann.substring(0, 1500) + "…" : ann;
            String d = date.length() > 0 ? date : year;
            Matcher dm = Pattern.compile("^(\\d{4})(?:-(\\d{2}))?(?:-(\\d{2}))?").matcher(d);
            if (dm.find()) book.date = dm.group(0);
            book.identifier = BookConverter.identifier("fb2", book.title + authors, size);

            // pictures, under names that carry their kind
            Map<String, String> imagePath = new HashMap<String, String>();
            int k = 0;
            Set<String> wanted = new HashSet<String>(usedImages);
            if (coverId.length() > 0) wanted.add(coverId);
            List<String> order = new ArrayList<String>(wanted);
            java.util.Collections.sort(order);
            for (String id : order) {
                Binary b = binaries.get(id);
                if (b == null) continue;
                String ext = extension(b);
                String path = "images/b" + (++k) + "." + ext;
                imagePath.put(Xml.id(id), path);
                EpubBuilder.Resource r = new EpubBuilder.Resource(path, ext.equals("png") ? "image/png" : ext.equals("gif") ? "image/gif"
                        : ext.equals("webp") ? "image/webp" : "image/jpeg", b.data);
                r.cover = id.equals(coverId);
                book.resources.add(r);
            }

            int no = 0;
            List<Integer> partOfPage = new ArrayList<Integer>();
            for (int i = 0; i < pages.size(); i++) {
                if (pages.get(i).toString().trim().length() == 0) {
                    partOfPage.add(-1);
                    continue;
                }
                partOfPage.add(no++);
            }
            if (no == 0) throw new ConvertException("This book has no text in it.");
            Pattern img = Pattern.compile("<img src=\"\\.\\./images/@@IMG:([^@\"]*)@@\" alt=\"\"/>");
            Pattern link = Pattern.compile("href=\"#([^\"]*)\"");
            for (int i = 0; i < pages.size(); i++) {
                int part = partOfPage.get(i);
                if (part < 0) continue;
                String body = pages.get(i).toString();
                Matcher im = img.matcher(body);
                StringBuffer sb = new StringBuffer();
                while (im.find()) {
                    String path = imagePath.get(im.group(1));
                    im.appendReplacement(sb, path == null ? "" : Matcher.quoteReplacement("<img src=\"../" + path + "\" alt=\"\"/>"));
                }
                im.appendTail(sb);
                Matcher lm = link.matcher(sb.toString());
                StringBuffer sb2 = new StringBuffer();
                while (lm.find()) {
                    Integer target = idPage.get(lm.group(1));
                    String rep;
                    if (target == null) rep = lm.group(1).startsWith("t") ? lm.group(0) : "";
                    else {
                        int tp = partOfPage.get(target);
                        rep = tp < 0 ? "" : tp == part ? lm.group(0) : "href=\"" + String.format(Locale.ROOT, "p%04d.xhtml", tp + 1) + "#" + lm.group(1) + "\"";
                    }
                    lm.appendReplacement(sb2, Matcher.quoteReplacement(rep));
                }
                lm.appendTail(sb2);
                EpubBuilder.Part p = new EpubBuilder.Part(String.format(Locale.ROOT, "text/p%04d.xhtml", part + 1), sb2.toString());
                p.title = pageTitles.get(i).length() > 0 ? pageTitles.get(i) : book.title;
                book.parts.add(p);
            }
            NavTree tree = new NavTree(book.nav);
            for (Head h : heads) {
                int part = partOfPage.get(h.page);
                if (part >= 0) tree.add(h.level, h.title, book.parts.get(part).file + "#" + h.id);
            }
            if (notesPage >= 0 && partOfPage.get(notesPage) >= 0 && !book.nav.isEmpty()) {
                book.nav.add(new EpubBuilder.Nav("Notes", book.parts.get(partOfPage.get(notesPage)).file));
            }
            if (book.nav.isEmpty()) book.nav.add(new EpubBuilder.Nav(book.title, book.parts.get(0).file));
            book.write(out);
        }
    }

    private static String local(String qName) {
        int c = qName.indexOf(':');
        return (c >= 0 ? qName.substring(c + 1) : qName).toLowerCase(Locale.ROOT);
    }

    /** The target of a link or picture: xlink:href, l:href or plain href. */
    private static String href(Attributes a) {
        for (int i = 0; i < a.getLength(); i++) {
            String q = a.getQName(i);
            if (q.equals("href") || q.endsWith(":href")) return a.getValue(i).trim();
        }
        return null;
    }

    private static String extension(Binary b) {
        byte[] d = b.data;
        if (d.length > 4 && (d[0] & 0xFF) == 0x89 && d[1] == 'P') return "png";
        if (d.length > 3 && d[0] == 'G' && d[1] == 'I' && d[2] == 'F') return "gif";
        if (d.length > 12 && d[0] == 'R' && d[1] == 'I' && d[8] == 'W') return "webp";
        if (d.length > 2 && (d[0] & 0xFF) == 0xFF && (d[1] & 0xFF) == 0xD8) return "jpg";
        String t = b.type == null ? "" : b.type.toLowerCase(Locale.ROOT);
        return t.contains("png") ? "png" : t.contains("gif") ? "gif" : "jpg";
    }

    private static final String[][] GENRES = {
        {"sf_fantasy", "Fantasy"}, {"fantasy", "Fantasy"}, {"sf", "Science fiction"}, {"sf_space", "Science fiction"}, {"sf_action", "Science fiction"},
        {"sf_epic", "Science fiction"}, {"sf_social", "Science fiction"}, {"sf_history", "Alternative history"}, {"sf_horror", "Horror"}, {"sf_heroic", "Fantasy"},
        {"det_classic", "Detective"}, {"det_police", "Detective"}, {"det_action", "Thriller"}, {"det_hard", "Detective"}, {"detective", "Detective"},
        {"det_history", "Historical mystery"}, {"thriller", "Thriller"}, {"love_contemporary", "Romance"}, {"love_history", "Historical romance"},
        {"love_detective", "Romance"}, {"love", "Romance"}, {"prose_classic", "Classics"}, {"prose_history", "Historical fiction"},
        {"prose_contemporary", "Contemporary fiction"}, {"prose_su_classics", "Classics"}, {"prose_rus_classic", "Classics"}, {"prose", "Fiction"},
        {"adv_history", "Historical adventure"}, {"adventure", "Adventure"}, {"adv_geo", "Adventure"}, {"adv_maritime", "Adventure"},
        {"child_tale", "Fairy tales"}, {"child_prose", "Children's"}, {"child_verse", "Children's"}, {"children", "Children's"},
        {"humor", "Humor"}, {"humor_prose", "Humor"}, {"poetry", "Poetry"}, {"dramaturgy", "Drama"}, {"antique", "Classics"},
        {"nonf_biography", "Biography"}, {"nonf_publicism", "Essays"}, {"nonfiction", "Non-fiction"}, {"sci_history", "History"},
        {"sci_philosophy", "Philosophy"}, {"sci_psychology", "Psychology"}, {"sci_popular", "Popular science"}, {"sci_politics", "Politics"},
        {"science", "Science"}, {"religion", "Religion"}, {"home", "Home"}, {"computers", "Computers"}, {"comp_programming", "Programming"},
    };

    static String genre(String code) {
        String c = code.trim().toLowerCase(Locale.ROOT);
        for (String[] g : GENRES) if (g[0].equals(c)) return g[1];
        return "";
    }
}
