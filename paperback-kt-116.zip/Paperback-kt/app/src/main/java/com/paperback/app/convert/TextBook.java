package com.paperback.app.convert;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Plain text, Markdown and web pages (.txt, .md, .html) as books. */
final class TextBook {
    private TextBook() {
    }

    // ---------------------------------------------------------------------------------------------
    // the pieces a text is made of, and how they become pages

    /** A paragraph, a heading or a scene break, already as XHTML. */
    static final class Piece {
        final String xhtml;
        /** 0 for ordinary text, 1 (biggest) to 6 for a heading. */
        final int level;
        final String title;
        final String id;

        Piece(String xhtml, int level, String title, String id) {
            this.xhtml = xhtml;
            this.level = level;
            this.title = title;
            this.id = id;
        }
    }

    private static final int CHUNK = 60000;

    /** Cuts the pieces into pages at the main headings (or every so many letters when there are none) and fills the contents list. */
    static void build(EpubBuilder book, List<Piece> pieces, String bookTitle) throws ConvertException {
        int main = 0;
        for (Piece p : pieces) if (p.level >= 1 && p.level <= 2) main++;
        int splitLevel = main >= 2 ? 2 : 0;

        StringBuilder cur = new StringBuilder();
        String curTitle = "";
        List<String[]> pages = new ArrayList<String[]>(); // {title, body}
        List<Object[]> heads = new ArrayList<Object[]>(); // {level, title, id, page index}
        for (Piece p : pieces) {
            boolean startsPage = p.level >= 1 && p.level <= splitLevel && cur.length() > 0;
            boolean tooBig = p.level == 0 && cur.length() > CHUNK;
            if (startsPage || tooBig) {
                pages.add(new String[] {curTitle, cur.toString()});
                cur.setLength(0);
                curTitle = "";
            }
            if (p.level >= 1 && curTitle.length() == 0) curTitle = p.title;
            if (p.level >= 1 && p.level <= 3 && p.title.length() > 0) heads.add(new Object[] {p.level, p.title, p.id, pages.size()});
            cur.append(p.xhtml).append('\n');
        }
        if (cur.length() > 0) pages.add(new String[] {curTitle, cur.toString()});
        if (pages.isEmpty()) throw new ConvertException("This file has no text in it.");

        int no = 0;
        for (String[] page : pages) {
            EpubBuilder.Part part = new EpubBuilder.Part(String.format(Locale.ROOT, "text/p%04d.xhtml", ++no), page[1]);
            part.title = page[0].length() > 0 ? page[0] : bookTitle;
            book.parts.add(part);
        }
        NavTree tree = new NavTree(book.nav);
        for (Object[] h : heads) {
            tree.add((Integer) h[0], (String) h[1], book.parts.get((Integer) h[3]).file + "#" + h[2]);
        }
        if (book.nav.isEmpty()) book.nav.add(new EpubBuilder.Nav(bookTitle, book.parts.get(0).file));
    }

    // ---------------------------------------------------------------------------------------------
    // plain text

    private static final String KW_PART = "part|book|volume|act|díl|část|kniha|teil|buch|partie|livre|parte|libro|часть|книга|część|księga|deel|del";
    private static final String KW_OTHER = "chapter|section|scene|letter|canto|stave|kapitola|kapitel|chapitre|capítulo|capitulo|capitolo|глава|rozdział|hoofdstuk|kapittel|luku|osa";
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final String NUM = "(?:[IVXLCDM]+|\\d{1,4}|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|first|second|third|fourth|fifth|last)";
    private static final Pattern NUMBERED = Pattern.compile("^(" + KW_PART + "|" + KW_OTHER + ")\\s+" + NUM + "(?:[\\s.:\\-–—)]+.{0,60})?$", FLAGS);
    private static final Pattern STANDALONE = Pattern.compile("^(?:prologue|epilogue|preface|foreword|introduction|afterword|appendix|acknowledg(?:e)?ments|"
            + "prolog|epilog|úvod|předmluva|doslov|vorwort|einleitung|nachwort|préface|épilogue|prólogo|epílogo|prefazione|"
            + "пролог|эпилог|предисловие|введение|послесловие|dedication|contents)[.:]?$", FLAGS);
    private static final Pattern ROMAN = Pattern.compile("^(?=[IVXLCDM])M{0,3}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})[.]?$");
    private static final Pattern RULE = Pattern.compile("^[\\s*\\-_=~#.•·]{3,}$");
    private static final Pattern UNDERSCORE_EM = Pattern.compile("(?<![\\p{L}\\p{N}_])_([^_\\n]{1,120}?)_(?![\\p{L}\\p{N}_])");

    static void plainText(byte[] data, String fileName, File out) throws IOException, ConvertException {
        String text = TextCodec.decode(data);
        String[] raw = text.replace("\r\n", "\n").replace('\r', '\n').replace('\f', '\n').split("\n", -1);
        String[] lines = new String[raw.length];
        int nonEmpty = 0;
        int gaps = 0;
        boolean prevBlank = true;
        boolean seen = false;
        List<Integer> lengths = new ArrayList<Integer>();
        for (int i = 0; i < raw.length; i++) {
            String l = raw[i].replace("\t", "    ");
            int e = l.length();
            while (e > 0 && Character.isWhitespace(l.charAt(e - 1))) e--;
            lines[i] = l.substring(0, e);
            boolean blank = lines[i].trim().length() == 0;
            if (!blank) {
                nonEmpty++;
                lengths.add(lines[i].trim().length());
                if (prevBlank && seen) gaps++;
                seen = true;
            }
            prevBlank = blank;
        }
        if (nonEmpty == 0) throw new ConvertException("This file has no text in it.");
        Collections.sort(lengths);
        int p90 = lengths.get(Math.min(lengths.size() - 1, (int) (lengths.size() * 0.9)));

        String title = BookConverter.titleFromName(fileName);
        String author = "";
        String language = "";
        for (int i = 0; i < Math.min(lines.length, 80); i++) {
            String l = lines[i].trim();
            if (l.regionMatches(true, 0, "Title:", 0, 6) && l.length() > 7) title = l.substring(6).trim();
            else if (l.regionMatches(true, 0, "Author:", 0, 7) && l.length() > 8) author = l.substring(7).trim();
            else if (l.regionMatches(true, 0, "Language:", 0, 9) && l.length() > 10) language = languageCode(l.substring(9).trim());
        }

        boolean blankSeparated = gaps >= 2 && gaps * 20 >= nonEmpty;
        List<Object[]> blocks = new ArrayList<Object[]>(); // {kind, text, level}: kind 'p' paragraph, 'l' lines, 'h' heading, 'r' rule
        if (blankSeparated) {
            List<String> group = new ArrayList<String>();
            for (int i = 0; i <= lines.length; i++) {
                String l = i < lines.length ? lines[i] : "";
                if (l.trim().length() > 0) {
                    group.add(l);
                    continue;
                }
                if (group.isEmpty()) continue;
                addGroup(blocks, group, p90);
                group = new ArrayList<String>();
            }
            // a heading followed by a short line without a full stop is the heading's own title
            for (int i = 0; i + 1 < blocks.size(); i++) {
                Object[] a = blocks.get(i);
                Object[] b = blocks.get(i + 1);
                if (a[0].equals('h') && b[0].equals('p')) {
                    String bt = (String) b[1];
                    if (bt.length() <= 60 && !bt.matches(".*[.!?,;:]$") && !isHeadingText(bt, false)) {
                        a[1] = a[1] + " — " + bt;
                        blocks.remove(i + 1);
                    }
                }
            }
        } else {
            int wrapped = 0;
            for (int len : lengths) if (len >= p90 * 0.6) wrapped++;
            boolean hardWrapped = nonEmpty >= 20 && p90 >= 45 && p90 <= 110 && wrapped >= lengths.size() * 0.6;
            StringBuilder para = new StringBuilder();
            String prev = "";
            for (String l : lines) {
                String t = l.trim();
                if (t.length() == 0) {
                    flush(blocks, para);
                    prev = "";
                    continue;
                }
                if (t.length() <= 60 && isHeadingText(t, false)) {
                    flush(blocks, para);
                    blocks.add(new Object[] {'h', t, levelOf(t)});
                    prev = "";
                    continue;
                }
                if (RULE.matcher(t).matches()) {
                    flush(blocks, para);
                    blocks.add(new Object[] {'r', "", 0});
                    prev = "";
                    continue;
                }
                if (!hardWrapped) {
                    blocks.add(new Object[] {'p', t, 0});
                    continue;
                }
                boolean indented = l.startsWith("  ");
                boolean endsSentence = prev.length() > 0 && prev.matches(".*[.!?:\"”’»)]$") && prev.length() < p90 * 0.75;
                if (para.length() > 0 && (indented || endsSentence)) flush(blocks, para);
                if (para.length() > 0) para.append(joiner(para, t));
                para.append(t);
                prev = t;
            }
            flush(blocks, para);
        }

        List<Piece> pieces = new ArrayList<Piece>();
        int n = 0;
        for (Object[] b : blocks) {
            char kind = (Character) b[0];
            String t = (String) b[1];
            if (kind == 'h') {
                int level = (Integer) b[2];
                String id = "h" + (++n);
                pieces.add(new Piece("<h" + level + " id=\"" + id + "\">" + inline(t) + "</h" + level + ">", level, t, id));
            } else if (kind == 'r') {
                pieces.add(new Piece("<hr/>", 0, "", ""));
            } else if (kind == 'l') {
                pieces.add(new Piece("<p>" + t.replace("\n", "<br/>\n") + "</p>", 0, "", ""));
            } else {
                pieces.add(new Piece("<p>" + inline(t) + "</p>", 0, "", ""));
            }
        }
        // lines kept apart ('l') are already inline-formatted by addGroup
        EpubBuilder book = new EpubBuilder();
        book.title = title;
        if (author.length() > 0) book.authors.add(author);
        if (language.length() > 0) book.language = language;
        book.identifier = BookConverter.identifier("txt", title, data.length);
        build(book, pieces, title);
        book.write(out);
    }

    /** A short line that can be the title under "CHAPTER I.": no sentence punctuation, or one short full stop. */
    private static boolean looksLikeTitle(String t) {
        if (t.length() == 0 || t.length() > 60 || t.matches(".*[!?,;:]$")) return false;
        if (t.endsWith(".")) return t.length() <= 45 && t.split("\\s+").length <= 6;
        return true;
    }

    private static void addGroup(List<Object[]> blocks, List<String> group, int p90) {
        // "CHAPTER I." with its title (and maybe the text) on the lines right under it, no blank line between
        if (group.size() >= 2 && group.get(0).trim().length() <= 70 && isHeadingText(group.get(0).trim(), false)) {
            String head = group.get(0).trim().replaceAll("[.:]$", "");
            int k = 1;
            while (k < group.size() && k <= 2 && looksLikeTitle(group.get(k).trim())) {
                head += " — " + group.get(k).trim().replaceAll("\\.$", "");
                k++;
            }
            blocks.add(new Object[] {'h', head, levelOf(group.get(0).trim())});
            if (k < group.size()) addGroup(blocks, new ArrayList<String>(group.subList(k, group.size())), p90);
            return;
        }
        if (group.size() == 1) {
            String t = group.get(0).trim();
            if (RULE.matcher(t).matches()) {
                blocks.add(new Object[] {'r', "", 0});
                return;
            }
            if (t.length() <= 70 && isHeadingText(t, true)) {
                blocks.add(new Object[] {'h', t, levelOf(t)});
                return;
            }
        }
        boolean keepLines = group.size() >= 2;
        if (keepLines) {
            for (int i = 0; i < group.size() - 1; i++) {
                if (group.get(i).trim().length() >= p90 * 0.75) {
                    keepLines = false;
                    break;
                }
            }
        }
        if (keepLines) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < group.size(); i++) {
                if (i > 0) b.append('\n');
                b.append(inline(group.get(i).trim()));
            }
            blocks.add(new Object[] {'l', b.toString(), 0});
            return;
        }
        StringBuilder b = new StringBuilder();
        for (String l : group) {
            String t = l.trim();
            if (b.length() > 0) b.append(joiner(b, t));
            b.append(t);
        }
        blocks.add(new Object[] {'p', b.toString(), 0});
    }

    private static void flush(List<Object[]> blocks, StringBuilder para) {
        if (para.length() > 0) {
            blocks.add(new Object[] {'p', para.toString(), 0});
            para.setLength(0);
        }
    }

    /** A space between two lines that were one paragraph; none after a hyphen that cut a word. */
    private static String joiner(CharSequence before, String next) {
        int n = before.length();
        if (n >= 2 && before.charAt(n - 1) == '-' && Character.isLetter(before.charAt(n - 2))
                && next.length() > 0 && Character.isLowerCase(next.charAt(0))) return "";
        return " ";
    }

    private static boolean isHeadingText(String t, boolean allowBare) {
        if (NUMBERED.matcher(t).matches() || STANDALONE.matcher(t).matches()) return true;
        return allowBare && t.length() >= 1 && t.length() <= 9 && ROMAN.matcher(t).matches() && !(t.length() == 1 && "CDLM".contains(t));
    }

    private static int levelOf(String t) {
        return Pattern.compile("^(" + KW_PART + ")\\b", FLAGS).matcher(t).find() ? 1 : 2;
    }

    /** Text with Project Gutenberg's _italics_ marks turned into emphasis; everything else is escaped. */
    private static String inline(String t) {
        String e = Xml.esc(t);
        return UNDERSCORE_EM.matcher(e).replaceAll("<em>$1</em>");
    }

    private static String languageCode(String name) {
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (n.length() == 2 || (n.length() == 5 && n.charAt(2) == '-')) return n;
        String[][] map = {{"english", "en"}, {"german", "de"}, {"french", "fr"}, {"spanish", "es"}, {"italian", "it"}, {"czech", "cs"},
                {"russian", "ru"}, {"polish", "pl"}, {"dutch", "nl"}, {"portuguese", "pt"}, {"finnish", "fi"}, {"swedish", "sv"},
                {"latin", "la"}, {"greek", "el"}, {"hungarian", "hu"}, {"danish", "da"}, {"norwegian", "no"}};
        for (String[] m : map) if (n.startsWith(m[0])) return m[1];
        return "";
    }

    // ---------------------------------------------------------------------------------------------
    // Markdown

    private static final Pattern ATX = Pattern.compile("^ {0,3}(#{1,6})\\s+(.*?)\\s*#*\\s*$");
    private static final Pattern MD_RULE = Pattern.compile("^ {0,3}([-*_])(?:\\s*\\1){2,}\\s*$");
    private static final Pattern FENCE = Pattern.compile("^ {0,3}(```|~~~)");
    private static final Pattern LIST_ITEM = Pattern.compile("^(\\s*)([-*+]|\\d{1,9}[.)])\\s+(.*)$");
    private static final Pattern TABLE_SEP = Pattern.compile("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?\\s*$");
    private static final Pattern MD_CODE = Pattern.compile("(`+)(.+?)\\1");

    static void markdown(byte[] data, String fileName, File out) throws IOException, ConvertException {
        String text = TextCodec.decode(data).replace("\r\n", "\n").replace('\r', '\n');
        List<String> lines = new ArrayList<String>(Arrays.asList(text.split("\n", -1)));
        String title = "";
        String author = "";
        // front matter between two "---" lines
        if (lines.size() > 2 && lines.get(0).trim().equals("---")) {
            int end = -1;
            for (int i = 1; i < Math.min(lines.size(), 60); i++) {
                if (lines.get(i).trim().equals("---") || lines.get(i).trim().equals("...")) {
                    end = i;
                    break;
                }
            }
            if (end > 0) {
                for (int i = 1; i < end; i++) {
                    String l = lines.get(i);
                    if (l.regionMatches(true, 0, "title:", 0, 6)) title = unquote(l.substring(6));
                    else if (l.regionMatches(true, 0, "author:", 0, 7)) author = unquote(l.substring(7));
                }
                lines = new ArrayList<String>(lines.subList(end + 1, lines.size()));
            }
        }
        List<Piece> pieces = new ArrayList<Piece>();
        int[] counter = {0};
        mdBlocks(lines, pieces, counter);
        if (pieces.isEmpty()) throw new ConvertException("This file has no text in it.");
        if (title.length() == 0) {
            for (Piece p : pieces) {
                if (p.level == 1) {
                    title = p.title;
                    break;
                }
            }
        }
        if (title.length() == 0) title = BookConverter.titleFromName(fileName);
        EpubBuilder book = new EpubBuilder();
        book.title = title;
        if (author.length() > 0) book.authors.add(author);
        book.identifier = BookConverter.identifier("md", title, data.length);
        build(book, pieces, title);
        book.write(out);
    }

    private static String unquote(String s) {
        String t = s.trim();
        if (t.length() >= 2 && ((t.startsWith("\"") && t.endsWith("\"")) || (t.startsWith("'") && t.endsWith("'")))) t = t.substring(1, t.length() - 1);
        return t;
    }

    private static void mdBlocks(List<String> lines, List<Piece> out, int[] counter) {
        int i = 0;
        int n = lines.size();
        while (i < n) {
            String line = lines.get(i);
            if (line.trim().length() == 0) {
                i++;
                continue;
            }
            Matcher fence = FENCE.matcher(line);
            if (fence.find()) {
                String mark = fence.group(1);
                StringBuilder code = new StringBuilder();
                i++;
                while (i < n && !lines.get(i).trim().startsWith(mark)) {
                    code.append(lines.get(i)).append('\n');
                    i++;
                }
                i++;
                out.add(new Piece("<pre><code>" + Xml.esc(code.toString()) + "</code></pre>", 0, "", ""));
                continue;
            }
            Matcher atx = ATX.matcher(line);
            if (atx.matches()) {
                heading(out, counter, atx.group(1).length(), atx.group(2));
                i++;
                continue;
            }
            if (MD_RULE.matcher(line).matches()) {
                out.add(new Piece("<hr/>", 0, "", ""));
                i++;
                continue;
            }
            if (line.trim().startsWith(">")) {
                List<String> inner = new ArrayList<String>();
                while (i < n && lines.get(i).trim().startsWith(">")) {
                    String l = lines.get(i).trim().substring(1);
                    inner.add(l.startsWith(" ") ? l.substring(1) : l);
                    i++;
                }
                List<Piece> sub = new ArrayList<Piece>();
                mdBlocks(inner, sub, new int[] {0});
                StringBuilder b = new StringBuilder("<blockquote>");
                for (Piece p : sub) b.append(p.xhtml);
                out.add(new Piece(b.append("</blockquote>").toString(), 0, "", ""));
                continue;
            }
            if (LIST_ITEM.matcher(line).matches() && !MD_RULE.matcher(line).matches()) {
                StringBuilder html = new StringBuilder();
                i = mdList(lines, i, html);
                out.add(new Piece(html.toString(), 0, "", ""));
                continue;
            }
            if (line.indexOf('|') >= 0 && i + 1 < n && TABLE_SEP.matcher(lines.get(i + 1)).matches()) {
                StringBuilder html = new StringBuilder("<table>\n<thead><tr>");
                for (String c : cells(line)) html.append("<th>").append(mdInline(c)).append("</th>");
                html.append("</tr></thead>\n<tbody>\n");
                i += 2;
                while (i < n && lines.get(i).trim().length() > 0 && lines.get(i).indexOf('|') >= 0) {
                    html.append("<tr>");
                    for (String c : cells(lines.get(i))) html.append("<td>").append(mdInline(c)).append("</td>");
                    html.append("</tr>\n");
                    i++;
                }
                out.add(new Piece(html.append("</tbody></table>").toString(), 0, "", ""));
                continue;
            }
            // a paragraph: lines up to a blank line or the start of another block; "===" or "---" under it makes it a heading
            StringBuilder para = new StringBuilder();
            while (i < n) {
                String l = lines.get(i);
                if (l.trim().length() == 0) break;
                if (para.length() > 0) {
                    if (l.matches("^ {0,3}=+\\s*$") || l.matches("^ {0,3}-+\\s*$")) {
                        heading(out, counter, l.trim().startsWith("=") ? 1 : 2, para.toString());
                        para.setLength(0);
                        i++;
                        break;
                    }
                    if (ATX.matcher(l).matches() || FENCE.matcher(l).find() || l.trim().startsWith(">") || MD_RULE.matcher(l).matches()
                            || LIST_ITEM.matcher(l).matches()) break;
                    para.append(lines.get(i - 1).endsWith("  ") ? "\n" : " ");
                }
                para.append(l.trim());
                i++;
            }
            if (para.length() > 0) {
                out.add(new Piece("<p>" + mdInline(para.toString()).replace("\n", "<br/>\n") + "</p>", 0, "", ""));
            }
        }
    }

    private static List<String> cells(String row) {
        String r = row.trim();
        if (r.startsWith("|")) r = r.substring(1);
        if (r.endsWith("|")) r = r.substring(0, r.length() - 1);
        List<String> out = new ArrayList<String>();
        for (String c : r.split("\\|", -1)) out.add(c.trim());
        return out;
    }

    private static void heading(List<Piece> out, int[] counter, int level, String raw) {
        String plain = Xml.squash(mdPlain(raw));
        if (plain.length() == 0) return;
        String id = "h" + (++counter[0]);
        out.add(new Piece("<h" + level + " id=\"" + id + "\">" + mdInline(raw.trim()) + "</h" + level + ">", level, plain, id));
    }

    /** One list (and the lists inside it). Returns the next line to read. */
    private static int mdList(List<String> lines, int start, StringBuilder html) {
        Matcher first = LIST_ITEM.matcher(lines.get(start));
        first.matches();
        int baseIndent = first.group(1).length();
        boolean ordered = Character.isDigit(first.group(2).charAt(0));
        html.append(ordered ? "<ol>\n" : "<ul>\n");
        int i = start;
        int n = lines.size();
        while (i < n) {
            Matcher m = LIST_ITEM.matcher(lines.get(i));
            if (!m.matches() || m.group(1).length() != baseIndent) break;
            StringBuilder item = new StringBuilder(m.group(3).trim());
            List<String> nested = new ArrayList<String>();
            i++;
            while (i < n) {
                String l = lines.get(i);
                if (l.trim().length() == 0) {
                    // a blank line ends the item unless more of it follows, indented
                    if (i + 1 < n && lines.get(i + 1).length() > baseIndent + 1 && lines.get(i + 1).substring(0, baseIndent + 1).trim().length() == 0) {
                        i++;
                        continue;
                    }
                    break;
                }
                Matcher lm = LIST_ITEM.matcher(l);
                if (lm.matches() && lm.group(1).length() <= baseIndent) break;
                if (lm.matches()) nested.add(l);
                else if (!nested.isEmpty()) nested.add(l);
                else item.append(' ').append(l.trim());
                i++;
            }
            html.append("<li>").append(mdInline(item.toString()));
            if (!nested.isEmpty()) {
                html.append('\n');
                int j = 0;
                while (j < nested.size()) {
                    Matcher nm = LIST_ITEM.matcher(nested.get(j));
                    if (nm.matches()) j = mdList(nested, j, html);
                    else j++;
                }
            }
            html.append("</li>\n");
        }
        html.append(ordered ? "</ol>" : "</ul>");
        return i;
    }

    private static String mdPlain(String s) {
        return s.replaceAll("!?\\[([^\\]]*)\\]\\([^)]*\\)", "$1").replaceAll("[*_`~]", "");
    }

    private static String mdInline(String s) {
        StringBuilder out = new StringBuilder();
        Matcher code = MD_CODE.matcher(s);
        int last = 0;
        while (code.find()) {
            out.append(mdSpans(s.substring(last, code.start())));
            out.append("<code>").append(Xml.esc(code.group(2).trim())).append("</code>");
            last = code.end();
        }
        out.append(mdSpans(s.substring(last)));
        return out.toString();
    }

    private static String mdSpans(String raw) {
        String t = Xml.esc(raw);
        t = t.replaceAll("!\\[([^\\]]*)\\]\\([^)]*\\)", "$1"); // pictures are not carried over
        Matcher link = Pattern.compile("\\[([^\\]]+)\\]\\(([^)\\s]+)(?:\\s+&quot;[^)]*&quot;)?\\)").matcher(t);
        StringBuffer sb = new StringBuffer();
        while (link.find()) {
            String url = link.group(2);
            String rep = url.startsWith("http://") || url.startsWith("https://") || url.startsWith("mailto:") || url.startsWith("#")
                    ? "<a href=\"" + Matcher.quoteReplacement(url) + "\">" + Matcher.quoteReplacement(link.group(1)) + "</a>"
                    : Matcher.quoteReplacement(link.group(1));
            link.appendReplacement(sb, rep);
        }
        link.appendTail(sb);
        t = sb.toString();
        t = t.replaceAll("&lt;((?:https?://|mailto:)[^\\s&]+)&gt;", "<a href=\"$1\">$1</a>");
        t = t.replaceAll("\\*\\*(.+?)\\*\\*|__(.+?)__", "<strong>$1$2</strong>");
        t = t.replaceAll("\\*(?!\\s)(.+?)(?<!\\s)\\*", "<em>$1</em>");
        t = t.replaceAll("(?<![\\p{L}\\p{N}_])_(?!\\s)(.+?)(?<!\\s)_(?![\\p{L}\\p{N}_])", "<em>$1</em>");
        t = t.replaceAll("~~(.+?)~~", "<s>$1</s>");
        return t;
    }

    // ---------------------------------------------------------------------------------------------
    // web pages

    static void html(byte[] data, String fileName, File out) throws IOException, ConvertException {
        String text = decodeHtml(data);
        String title = "";
        Matcher tm = Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(text);
        if (tm.find()) title = Xml.squash(Entities.decode(tm.group(1).replaceAll("(?s)<[^>]*>", "")));
        String author = "";
        Matcher am = Pattern.compile("(?is)<meta\\s[^>]*name\\s*=\\s*[\"']?author[\"']?[^>]*content\\s*=\\s*[\"']([^\"']*)[\"']").matcher(text);
        if (am.find()) author = Xml.squash(Entities.decode(am.group(1)));
        if (title.length() == 0) title = BookConverter.titleFromName(fileName);

        HtmlConverter.Env env = new HtmlConverter.Env() {
            public String href(String raw, int filepos) {
                String r = raw.trim();
                String low = r.toLowerCase(Locale.ROOT);
                if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("mailto:")) return r;
                if (r.startsWith("#") && r.length() > 1) return "#" + Xml.id(r.substring(1));
                return null;
            }

            public String image(String src, String recindex) {
                return null; // a single page has no picture files to carry along
            }
        };
        HtmlConverter conv = new HtmlConverter(null, false, false, env, "");
        String body = conv.convert(text, 0, text.length(), null);
        if (Xml.squash(body.replaceAll("(?s)<[^>]*>", "")).length() == 0) throw new ConvertException("This page has no text in it.");

        EpubBuilder book = new EpubBuilder();
        book.title = title;
        if (author.length() > 0) book.authors.add(author);
        Matcher lm = Pattern.compile("(?is)<html[^>]*\\slang\\s*=\\s*[\"']?([A-Za-z\\-]{2,8})").matcher(text);
        if (lm.find()) book.language = lm.group(1);
        book.identifier = BookConverter.identifier("html", title, data.length);
        EpubBuilder.Part part = new EpubBuilder.Part("text/p0001.xhtml", body);
        part.title = title;
        book.parts.add(part);
        NavTree tree = new NavTree(book.nav);
        for (HtmlConverter.Heading h : conv.headings) {
            if (h.level <= 3) tree.add(h.level, h.text, part.file + "#" + h.id);
        }
        book.write(out);
    }

    /** The text of a page: a byte-order mark or the page's own "charset" first, then the same guesses as for a .txt file. */
    private static String decodeHtml(byte[] data) {
        int n = Math.min(data.length, 4096);
        String head = new String(data, 0, n, Charset.forName("ISO-8859-1"));
        Matcher cs = Pattern.compile("(?i)charset\\s*=\\s*[\"']?\\s*([A-Za-z0-9_\\-:.]+)").matcher(head);
        boolean bom = data.length >= 2 && (((data[0] & 0xFF) == 0xFF && (data[1] & 0xFF) == 0xFE) || ((data[0] & 0xFF) == 0xFE && (data[1] & 0xFF) == 0xFF)
                || (data.length >= 3 && (data[0] & 0xFF) == 0xEF && (data[1] & 0xFF) == 0xBB && (data[2] & 0xFF) == 0xBF));
        if (!bom && cs.find()) {
            String name = cs.group(1);
            if (!name.equalsIgnoreCase("utf-8") && !name.equalsIgnoreCase("utf8")) {
                try {
                    return new String(data, Charset.forName(name));
                } catch (Exception ignored) {
                    // an unknown name: fall through to the guess
                }
            }
        }
        return TextCodec.decode(data);
    }
}
