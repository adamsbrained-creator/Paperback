package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.DictEntry
import com.paperback.app.data.DictionaryApi
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.SavedWord
import com.paperback.app.data.WordLookup
import com.paperback.app.data.lookupFigures
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** What a look-up shows: waiting, the entry, no entry, or a problem (usually no internet). */
sealed interface DictState {
    data object Loading : DictState
    data class Found(val entry: DictEntry) : DictState
    data object Missing : DictState
    data class Failed(val message: String) : DictState
}

/** Looks [word] up online (Wiktionary) and gives the state to show. [lang] prefers that language's entry. */
@Composable
fun rememberDefinition(word: String, lang: String): DictState {
    val state by produceState<DictState>(DictState.Loading, word, lang) {
        value = DictState.Loading
        value = withContext(Dispatchers.IO) { DictionaryApi.define(word, lang) }.fold(
            onSuccess = { e -> if (e == null) DictState.Missing else DictState.Found(e) },
            onFailure = { DictState.Failed("Could not reach the dictionary. Check your internet connection.") },
        )
    }
    return state
}

/** The meanings of one look-up, in the colours it is given (the app's, or the reader's). */
@Composable
fun DictionaryResult(word: String, state: DictState, ink: Color, sub: Color) {
    when (state) {
        DictState.Loading -> Text("Looking up “$word”…", color = sub, fontSize = 14.sp)
        DictState.Missing -> Text("No entry for “$word”. Check the spelling, or try the word's base form.", color = sub, fontSize = 14.sp, lineHeight = 20.sp)
        is DictState.Failed -> Text(state.message, color = sub, fontSize = 14.sp, lineHeight = 20.sp)
        is DictState.Found -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(state.entry.word, color = ink, fontFamily = PbSerif, fontSize = 24.sp, fontWeight = FontWeight.Medium)
            Text(state.entry.language, color = sub, fontSize = 12.sp)
            state.entry.senses.forEach { s ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (s.partOfSpeech.isNotBlank()) Text(s.partOfSpeech.lowercase(), color = sub, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    s.meanings.forEachIndexed { i, m ->
                        Text("${i + 1}. $m", color = ink, fontSize = 15.sp, lineHeight = 21.sp)
                    }
                }
            }
        }
    }
}

/** Menu -> More -> Dictionary: look a word up, save it, and see your saved words and how often you look things up. */
@Composable
fun DictionaryScreen(
    saved: List<SavedWord>,
    lookups: List<WordLookup>,
    sessions: List<ReadingSession>,
    books: List<Book>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onLookup: (String) -> Unit,
    onSave: (SavedWord) -> Unit,
    onRemove: (String) -> Unit,
) {
    val t = pbTokens()
    var field by rememberSaveable { mutableStateOf("") }
    var word by rememberSaveable { mutableStateOf("") }
    val byId = remember(books) { books.associateBy { it.id } }
    val figures = remember(saved, lookups, sessions, books) { lookupFigures(saved, lookups, sessions, books) }
    val state = if (word.isBlank()) null else rememberDefinition(word, "")
    val isSaved = word.isNotBlank() && saved.any { it.word.equals(word.trim(), ignoreCase = true) }

    fun go() {
        val w = DictionaryApi.clean(field)
        if (w.isEmpty()) return
        word = w
        onLookup(w)
    }

    PbListPage("Dictionary", headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(14.dp))
        PbField(
            value = field,
            onValueChange = { field = it },
            placeholder = "Look up a word",
            leading = PbIconName.Search,
            onClear = { field = ""; word = "" },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { go() }),
        )
        Spacer(Modifier.height(10.dp))
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (state != null) {
                item(key = "result") {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(t.card).padding(18.dp)) {
                        DictionaryResult(word, state, t.ink, t.setSub)
                        if (state is DictState.Found) {
                            Spacer(Modifier.height(14.dp))
                            if (isSaved) PbButton("Remove from saved words", { onRemove(word) }, ghost = true)
                            else PbButton("Save word", {
                                onSave(SavedWord(state.entry.word, System.currentTimeMillis(), "", state.entry.short, state.entry.lang, ""))
                            })
                        }
                    }
                }
            }
            item(key = "figures") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(t.card).padding(18.dp)) {
                    DictFigure("Saved words", "${figures.saved}")
                    DictFigure("Look-ups", "${figures.lookups}")
                    DictFigure("Per 1,000 words read", figures.perThousand?.let { "%.1f".format(it) } ?: "–")
                    figures.hardest?.let { (b, rate) -> DictFigure("Most look-ups", b.title + " · " + "%.1f".format(rate)) }
                    if (figures.perThousand == null) {
                        Text(
                            "The rate shows once you have read about 2,000 words and looked something up.",
                            color = t.setSub, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }
            }
            if (saved.isEmpty()) {
                item(key = "empty") {
                    Text(
                        "Words you save show up here. In the reader, select a word and tap Dictionary.",
                        color = t.setSub, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                    )
                }
            } else {
                items(saved, key = { it.word.lowercase() }) { w ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(t.card).padding(start = 16.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(w.word, color = t.ink, fontFamily = PbSerif, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                            if (w.definition.isNotBlank()) {
                                Text(w.definition, color = t.setSub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                            byId[w.bookId]?.let { Text(it.title, color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        }
                        QuietAction("Remove", onClick = { onRemove(w.word) })
                    }
                }
            }
        }
    }
}

@Composable
private fun DictFigure(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.setSub, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
