package com.paperback.app.tts

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URI
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.SSLSocketFactory

/** One voice in the picker. [id] is what the engine wants ("ru-RU-DmitryNeural" or a system voice name). */
class TtsVoice(val id: String, val name: String, val lang: String, val variant: String? = null, val offline: Boolean = false)

/** A word as the engine reports it: where in the audio it starts (seconds) and how long it lasts, plus its text. */
class WordBoundary(val startSec: Double, val durationSec: Double, val text: String)

class EdgeAudio(val bytes: ByteArray, val boundaries: List<WordBoundary>)

/**
 * Microsoft Edge's "Read aloud" neural voices, the same service the TypeScript app uses (libs/edgeTTS.ts): one WebSocket per
 * sentence, MP3 back, plus the time of every word. No Android code in here, so it can be tested on a laptop.
 */
object EdgeSpeech {
    private const val URL = "wss://api.msedgeservices.com/tts/cognitiveservices/websocket/v1"
    private const val TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val CHROMIUM = "143.0.3650.75"
    private val MAJOR = CHROMIUM.substringBefore('.')

    private val RAW_VOICES: Map<String, String> = linkedMapOf(
        "af-ZA" to "af-ZA-AdriNeural,af-ZA-WillemNeural",
        "am-ET" to "am-ET-AmehaNeural,am-ET-MekdesNeural",
        "ar-AE" to "ar-AE-FatimaNeural,ar-AE-HamdanNeural",
        "ar-BH" to "ar-BH-AliNeural,ar-BH-LailaNeural",
        "ar-DZ" to "ar-DZ-AminaNeural,ar-DZ-IsmaelNeural",
        "ar-EG" to "ar-EG-SalmaNeural,ar-EG-ShakirNeural",
        "ar-IQ" to "ar-IQ-BasselNeural,ar-IQ-RanaNeural",
        "ar-JO" to "ar-JO-SanaNeural,ar-JO-TaimNeural",
        "ar-KW" to "ar-KW-FahedNeural,ar-KW-NouraNeural",
        "ar-LB" to "ar-LB-LaylaNeural,ar-LB-RamiNeural",
        "ar-LY" to "ar-LY-ImanNeural,ar-LY-OmarNeural",
        "ar-MA" to "ar-MA-JamalNeural,ar-MA-MounaNeural",
        "ar-OM" to "ar-OM-AbdullahNeural,ar-OM-AyshaNeural",
        "ar-QA" to "ar-QA-AmalNeural,ar-QA-MoazNeural",
        "ar-SA" to "ar-SA-HamedNeural,ar-SA-ZariyahNeural",
        "ar-SY" to "ar-SY-AmanyNeural,ar-SY-LaithNeural",
        "ar-TN" to "ar-TN-HediNeural,ar-TN-ReemNeural",
        "ar-YE" to "ar-YE-MaryamNeural,ar-YE-SalehNeural",
        "az-AZ" to "az-AZ-BabekNeural,az-AZ-BanuNeural",
        "bg-BG" to "bg-BG-BorislavNeural,bg-BG-KalinaNeural",
        "bn-BD" to "bn-BD-NabanitaNeural,bn-BD-PradeepNeural",
        "bn-IN" to "bn-IN-BashkarNeural,bn-IN-TanishaaNeural",
        "bs-BA" to "bs-BA-GoranNeural,bs-BA-VesnaNeural",
        "ca-ES" to "ca-ES-EnricNeural,ca-ES-JoanaNeural",
        "cs-CZ" to "cs-CZ-AntoninNeural,cs-CZ-VlastaNeural",
        "cy-GB" to "cy-GB-AledNeural,cy-GB-NiaNeural",
        "da-DK" to "da-DK-ChristelNeural,da-DK-JeppeNeural",
        "de-AT" to "de-AT-IngridNeural,de-AT-JonasNeural",
        "de-CH" to "de-CH-JanNeural,de-CH-LeniNeural",
        "de-DE" to "de-DE-AmalaNeural,de-DE-ConradNeural,de-DE-FlorianMultilingualNeural,de-DE-KatjaNeural,de-DE-KillianNeural,de-DE-SeraphinaMultilingualNeural",
        "el-GR" to "el-GR-AthinaNeural,el-GR-NestorasNeural",
        "en-AU" to "en-AU-NatashaNeural,en-AU-WilliamNeural",
        "en-CA" to "en-CA-ClaraNeural,en-CA-LiamNeural",
        "en-GB" to "en-GB-LibbyNeural,en-GB-MaisieNeural,en-GB-RyanNeural,en-GB-SoniaNeural,en-GB-ThomasNeural",
        "en-HK" to "en-HK-SamNeural,en-HK-YanNeural",
        "en-IE" to "en-IE-ConnorNeural,en-IE-EmilyNeural",
        "en-IN" to "en-IN-NeerjaExpressiveNeural,en-IN-NeerjaNeural,en-IN-PrabhatNeural",
        "en-KE" to "en-KE-AsiliaNeural,en-KE-ChilembaNeural",
        "en-NG" to "en-NG-AbeoNeural,en-NG-EzinneNeural",
        "en-NZ" to "en-NZ-MitchellNeural,en-NZ-MollyNeural",
        "en-PH" to "en-PH-JamesNeural,en-PH-RosaNeural",
        "en-SG" to "en-SG-LunaNeural,en-SG-WayneNeural",
        "en-TZ" to "en-TZ-ElimuNeural,en-TZ-ImaniNeural",
        "en-US" to "en-US-AnaNeural,en-US-AndrewMultilingualNeural,en-US-AndrewNeural,en-US-AriaNeural,en-US-AvaMultilingualNeural,en-US-AvaNeural,en-US-BrianMultilingualNeural,en-US-BrianNeural,en-US-ChristopherNeural,en-US-EmmaMultilingualNeural,en-US-EmmaNeural,en-US-EricNeural,en-US-GuyNeural,en-US-JennyNeural,en-US-MichelleNeural,en-US-RogerNeural,en-US-SteffanNeural",
        "es-AR" to "es-AR-ElenaNeural,es-AR-TomasNeural",
        "es-BO" to "es-BO-MarceloNeural,es-BO-SofiaNeural",
        "es-CL" to "es-CL-CatalinaNeural,es-CL-LorenzoNeural",
        "es-CO" to "es-CO-GonzaloNeural,es-CO-SalomeNeural",
        "es-CR" to "es-CR-JuanNeural,es-CR-MariaNeural",
        "es-CU" to "es-CU-BelkysNeural,es-CU-ManuelNeural",
        "es-DO" to "es-DO-EmilioNeural,es-DO-RamonaNeural",
        "es-EC" to "es-EC-AndreaNeural,es-EC-LuisNeural",
        "es-ES" to "es-ES-AlvaroNeural,es-ES-ElviraNeural,es-ES-XimenaNeural",
        "es-US" to "es-US-AlonsoNeural,es-US-PalomaNeural",
        "et-EE" to "et-EE-AnuNeural,et-EE-KertNeural",
        "fa-IR" to "fa-IR-DilaraNeural,fa-IR-FaridNeural",
        "fi-FI" to "fi-FI-HarriNeural,fi-FI-NooraNeural",
        "fil-PH" to "fil-PH-AngeloNeural,fil-PH-BlessicaNeural",
        "fr-BE" to "fr-BE-CharlineNeural,fr-BE-GerardNeural",
        "fr-CA" to "fr-CA-AntoineNeural,fr-CA-JeanNeural,fr-CA-SylvieNeural,fr-CA-ThierryNeural",
        "fr-CH" to "fr-CH-ArianeNeural,fr-CH-FabriceNeural",
        "fr-FR" to "fr-FR-DeniseNeural,fr-FR-EloiseNeural,fr-FR-HenriNeural,fr-FR-RemyMultilingualNeural,fr-FR-VivienneMultilingualNeural",
        "ga-IE" to "ga-IE-ColmNeural,ga-IE-OrlaNeural",
        "gl-ES" to "gl-ES-RoiNeural,gl-ES-SabelaNeural",
        "gu-IN" to "gu-IN-DhwaniNeural,gu-IN-NiranjanNeural",
        "he-IL" to "he-IL-AvriNeural,he-IL-HilaNeural",
        "hi-IN" to "hi-IN-MadhurNeural,hi-IN-SwaraNeural",
        "hr-HR" to "hr-HR-GabrijelaNeural,hr-HR-SreckoNeural",
        "hu-HU" to "hu-HU-NoemiNeural,hu-HU-TamasNeural",
        "id-ID" to "id-ID-ArdiNeural,id-ID-GadisNeural",
        "is-IS" to "is-IS-GudrunNeural,is-IS-GunnarNeural",
        "it-IT" to "it-IT-DiegoNeural,it-IT-ElsaNeural,it-IT-GiuseppeMultilingualNeural,it-IT-IsabellaNeural",
        "iu-Cans-CA" to "iu-Cans-CA-SiqiniqNeural,iu-Cans-CA-TaqqiqNeural",
        "iu-Latn-CA" to "iu-Latn-CA-SiqiniqNeural,iu-Latn-CA-TaqqiqNeural",
        "ja-JP" to "ja-JP-KeitaNeural,ja-JP-NanamiNeural",
        "jv-ID" to "jv-ID-DimasNeural,jv-ID-SitiNeural",
        "ka-GE" to "ka-GE-EkaNeural,ka-GE-GiorgiNeural",
        "kk-KZ" to "kk-KZ-AigulNeural,kk-KZ-DauletNeural",
        "km-KH" to "km-KH-PisethNeural,km-KH-SreymomNeural",
        "kn-IN" to "kn-IN-GaganNeural,kn-IN-SapnaNeural",
        "ko-KR" to "ko-KR-HyunsuMultilingualNeural,ko-KR-InJoonNeural,ko-KR-SunHiNeural",
        "lo-LA" to "lo-LA-ChanthavongNeural,lo-LA-KeomanyNeural",
        "lt-LT" to "lt-LT-LeonasNeural,lt-LT-OnaNeural",
        "lv-LV" to "lv-LV-EveritaNeural,lv-LV-NilsNeural",
        "mk-MK" to "mk-MK-AleksandarNeural,mk-MK-MarijaNeural",
        "ml-IN" to "ml-IN-MidhunNeural,ml-IN-SobhanaNeural",
        "mn-MN" to "mn-MN-BataaNeural,mn-MN-YesuiNeural",
        "mr-IN" to "mr-IN-AarohiNeural,mr-IN-ManoharNeural",
        "ms-MY" to "ms-MY-OsmanNeural,ms-MY-YasminNeural",
        "mt-MT" to "mt-MT-GraceNeural,mt-MT-JosephNeural",
        "my-MM" to "my-MM-NilarNeural,my-MM-ThihaNeural",
        "nb-NO" to "nb-NO-FinnNeural,nb-NO-PernilleNeural",
        "ne-NP" to "ne-NP-HemkalaNeural,ne-NP-SagarNeural",
        "nl-BE" to "nl-BE-ArnaudNeural,nl-BE-DenaNeural",
        "nl-NL" to "nl-NL-ColetteNeural,nl-NL-FennaNeural,nl-NL-MaartenNeural",
        "pl-PL" to "pl-PL-MarekNeural,pl-PL-ZofiaNeural",
        "ps-AF" to "ps-AF-GulNawazNeural,ps-AF-LatifaNeural",
        "pt-BR" to "pt-BR-AntonioNeural,pt-BR-FranciscaNeural,pt-BR-ThalitaMultilingualNeural",
        "pt-PT" to "pt-PT-DuarteNeural,pt-PT-RaquelNeural",
        "ro-RO" to "ro-RO-AlinaNeural,ro-RO-EmilNeural",
        "ru-RU" to "ru-RU-DmitryNeural,ru-RU-SvetlanaNeural",
        "si-LK" to "si-LK-SameeraNeural,si-LK-ThiliniNeural",
        "sk-SK" to "sk-SK-LukasNeural,sk-SK-ViktoriaNeural",
        "sl-SI" to "sl-SI-PetraNeural,sl-SI-RokNeural",
        "so-SO" to "so-SO-MuuseNeural,so-SO-UbaxNeural",
        "sq-AL" to "sq-AL-AnilaNeural,sq-AL-IlirNeural",
        "sr-RS" to "sr-RS-NicholasNeural,sr-RS-SophieNeural",
        "su-ID" to "su-ID-JajangNeural,su-ID-TutiNeural",
        "sv-SE" to "sv-SE-MattiasNeural,sv-SE-SofieNeural",
        "sw-KE" to "sw-KE-RafikiNeural,sw-KE-ZuriNeural",
        "sw-TZ" to "sw-TZ-DaudiNeural,sw-TZ-RehemaNeural",
        "ta-IN" to "ta-IN-PallaviNeural,ta-IN-ValluvarNeural",
        "ta-LK" to "ta-LK-KumarNeural,ta-LK-SaranyaNeural",
        "ta-MY" to "ta-MY-KaniNeural,ta-MY-SuryaNeural",
        "ta-SG" to "ta-SG-AnbuNeural,ta-SG-VenbaNeural",
        "te-IN" to "te-IN-MohanNeural,te-IN-ShrutiNeural",
        "th-TH" to "th-TH-NiwatNeural,th-TH-PremwadeeNeural",
        "tr-TR" to "tr-TR-AhmetNeural,tr-TR-EmelNeural",
        "uk-UA" to "uk-UA-OstapNeural,uk-UA-PolinaNeural",
        "ur-IN" to "ur-IN-GulNeural,ur-IN-SalmanNeural",
        "ur-PK" to "ur-PK-AsadNeural,ur-PK-UzmaNeural",
        "uz-UZ" to "uz-UZ-MadinaNeural,uz-UZ-SardorNeural",
        "vi-VN" to "vi-VN-HoaiMyNeural,vi-VN-NamMinhNeural",
        "zh-CN" to "zh-CN-XiaoxiaoNeural,zh-CN-XiaoyiNeural,zh-CN-YunjianNeural,zh-CN-YunxiNeural,zh-CN-YunxiaNeural,zh-CN-YunyangNeural,zh-CN-liaoning-XiaobeiNeural,zh-CN-shaanxi-XiaoniNeural",
        "zh-HK" to "zh-HK-HiuGaaiNeural,zh-HK-HiuMaanNeural,zh-HK-WanLungNeural",
        "zh-TW" to "zh-TW-HsiaoChenNeural,zh-TW-HsiaoYuNeural,zh-TW-YunJheNeural",
        "zu-ZA" to "zu-ZA-ThandoNeural,zu-ZA-ThembaNeural",
    )

    /** Every Edge voice, sorted by language then name. */
    val voices: List<TtsVoice> by lazy {
        RAW_VOICES.flatMap { (lang, ids) ->
            ids.split(',').map { id ->
                val name = id.removePrefix("$lang-").removeSuffix("Neural")
                val variant = Regex("(Multilingual|Expressive)$").find(name)?.value
                if (variant != null) TtsVoice(id, name.dropLast(variant.length), lang, variant.lowercase())
                else TtsVoice(id, name, lang)
            }
        }
    }

    // ---- the Sec-MS-GEC token (a port of generateSecMsGec) -------------------------------------------

    private val GEC_PREFIX = intArrayOf(
        0x79706f43, 0x68676972, 0x43282074, 0x694d2029, 0x736f7263, 0x2074666f, 0x70726f43, 0x7461726f,
        0x2e6e6f69, 0x6c6c4120, 0x67697220, 0x20737468, 0x65736572, 0x64657672, 0x0000002e,
    )
    private const val GEC_PREFIX_LENGTH = 57

    private fun rol16(x: Int): Int = (x shl 16) or (x ushr 16)

    private fun words(bytes: ByteArray): IntArray {
        val padded = ByteArray(((bytes.size + 7) / 8) * 8)
        System.arraycopy(bytes, 0, padded, 0, bytes.size)
        return IntArray(padded.size / 4) { i ->
            (padded[i * 4].toInt() and 0xff) or ((padded[i * 4 + 1].toInt() and 0xff) shl 8) or
                ((padded[i * 4 + 2].toInt() and 0xff) shl 16) or ((padded[i * 4 + 3].toInt() and 0xff) shl 24)
        }
    }

    private fun cs64WordSwap(w: IntArray, a: Int, b: Int): IntArray {
        var acc = 0
        var last = 0
        var i = 0
        while (i < w.size) {
            val x = w[i]
            val y = w[i + 1]
            var t = rol16(rol16(x) * 0xef0569fb.toInt() + x * a)
            var q = t * 0x76f50f34
            acc = acc + rol16(q) * 0xc3efea97.toInt() + q
            t = rol16(rol16(y) * 0xc31713db.toInt() + y * b)
            q = t * 0x1881ce3c
            last = rol16(q) * 0x35bd1ec9 + q
            acc += last
            i += 2
        }
        return intArrayOf(last, acc)
    }

    private fun cs64Reversible(w: IntArray, a: Int, b: Int): IntArray {
        var state = 0
        var acc = 0
        var i = 0
        while (i < w.size) {
            state = (state + w[i]) * a
            for (c in intArrayOf(0xcf98b111.toInt(), 0x87085b9f.toInt(), 0x12ceb96d, 0x257e1d83)) state = rol16(state) * c
            var t = (w[i + 1] + state) * b
            t = rol16(t) * 0xa27416f5.toInt()
            t = rol16(rol16(t) * 0xd38396ff.toInt())
            acc += state
            state = rol16(t * 0x7c932b89) * 0xbfa49f69.toInt()
            acc += state
            i += 2
        }
        return intArrayOf(state, acc)
    }

    private fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02X".format(it.toInt() and 0xff) }

    private fun le(a: Int, b: Int): ByteArray = ByteArray(8) { i ->
        val v = if (i < 4) a else b
        ((v ushr ((i % 4) * 8)) and 0xff).toByte()
    }

    /** The token Edge wants on every connection; it changes every five minutes. [nowMs] is only for tests. */
    fun secMsGec(nowMs: Long = System.currentTimeMillis()): String {
        var ticks = nowMs / 1000 + 11644473600L
        ticks -= ticks % 300
        ticks *= 10_000_000L
        val suffix = "$ticks$TOKEN".toByteArray(Charsets.UTF_8)
        val data = ByteArray(maxOf(GEC_PREFIX_LENGTH + suffix.size, GEC_PREFIX.size * 4))
        GEC_PREFIX.forEachIndexed { i, w ->
            for (k in 0 until 4) data[i * 4 + k] = ((w ushr (8 * k)) and 0xff).toByte()
        }
        System.arraycopy(suffix, 0, data, GEC_PREFIX_LENGTH, suffix.size)
        val digest = MessageDigest.getInstance("SHA-256").digest(data)
        val w = words(data)
        val keys = words(digest)
        val a = keys[0] or 1
        val b = keys[1] or 1
        val s = cs64WordSwap(w, a, b)
        val r = cs64Reversible(w, a, b)
        return hex(le(s[0] xor r[0], s[1] xor r[1])) + "-" + hex(digest)
    }

    // ---- one sentence ---------------------------------------------------------------------------------

    private val random = SecureRandom()

    private fun randomHex(bytes: Int): String = hex(ByteArray(bytes).also { random.nextBytes(it) })

    fun ssml(lang: String, text: String, voice: String): String {
        val safe = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return "<speak version=\"1.0\" xml:lang=\"$lang\"><voice name=\"$voice\"><prosody rate=\"1\">$safe</prosody></voice></speak>"
    }

    private fun stamp(): String =
        SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
            .format(java.util.Date()) + " GMT+0000 (Coordinated Universal Time)"

    /**
     * Speaks [text] with [voice] and returns the MP3 and word times. Blocking: call it from a background thread.
     * [onOpen] receives the connection so the caller can close it to cancel.
     */
    fun synthesize(lang: String, text: String, voice: String, url: String = URL, onOpen: (WebSocketClient) -> Unit = {}): EdgeAudio {
        val id = randomHex(16)
        val query = "ConnectionId=$id&Ocp-Apim-Subscription-Key=$TOKEN&Sec-MS-GEC=${secMsGec()}&Sec-MS-GEC-Version=2-$CHROMIUM"
        val headers = linkedMapOf(
            "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$MAJOR.0.0.0 Safari/537.36 Edg/$MAJOR.0.0.0",
            "Accept-Language" to "en-US,en;q=0.9",
            "Pragma" to "no-cache",
            "Cache-Control" to "no-cache",
            "Origin" to "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold",
            "Cookie" to "muid=${randomHex(16)};",
        )
        val ws = WebSocketClient("$url?$query", headers, timeoutMs = 20_000)
        try {
            ws.connect()
            onOpen(ws)
            val date = stamp()
            ws.sendText(
                "Content-Type: application/json; charset=utf-8\r\nPath: speech.config\r\nX-Timestamp: $date\r\n\r\n" +
                    "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":false,\"wordBoundaryEnabled\":true}," +
                    "\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}",
            )
            ws.sendText(
                "Content-Type: application/ssml+xml\r\nPath: ssml\r\nX-RequestId: $id\r\nX-Timestamp: $date\r\n\r\n" + ssml(lang, text, voice),
            )
            val audio = ByteArrayOutputStream()
            val boundaries = ArrayList<WordBoundary>()
            while (true) {
                val msg = ws.receive() ?: throw IOException("Connection closed before the audio was complete.")
                if (msg.text != null) {
                    val (h, body) = splitMessage(msg.text)
                    when (h["Path"]) {
                        "audio.metadata" -> boundaries += parseBoundaries(body)
                        "turn.end" -> break
                    }
                } else if (msg.binary != null) {
                    val b = msg.binary
                    if (b.size >= 2) {
                        val headerLength = ((b[0].toInt() and 0xff) shl 8) or (b[1].toInt() and 0xff)
                        if (b.size > headerLength + 2) audio.write(b, 2 + headerLength, b.size - headerLength - 2)
                    }
                }
            }
            if (audio.size() == 0) throw NoAudioException()
            return EdgeAudio(audio.toByteArray(), boundaries)
        } finally {
            ws.close()
        }
    }

    /** Edge answered but had nothing to say (the sentence was only symbols, say). Retrying will not help. */
    class NoAudioException : IOException("No audio data received.")

    fun splitMessage(message: String): Pair<Map<String, String>, String> {
        val lines = message.split('\n')
        val headers = HashMap<String, String>()
        var idx = 0
        while (idx < lines.size) {
            val line = lines[idx].trim()
            if (line.isEmpty()) break
            val colon = line.indexOf(':')
            if (colon >= 0) headers[line.substring(0, colon).trim()] = line.substring(colon + 1).trim()
            idx++
        }
        val body = lines.drop(idx + 1).joinToString("\n")
        return headers to body
    }

    private val BOUNDARY = Regex("\"Offset\"\\s*:\\s*(\\d+)\\s*,\\s*\"Duration\"\\s*:\\s*(\\d+)\\s*,\\s*\"text\"\\s*:\\s*\\{\\s*\"Text\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")

    /** Reads the word times out of an audio.metadata message (100-nanosecond ticks in, seconds out). */
    fun parseBoundaries(body: String): List<WordBoundary> {
        if (!body.contains("WordBoundary")) return emptyList()
        return BOUNDARY.findAll(body).mapNotNull { m ->
            val text = unescape(m.groupValues[3])
            if (text.isEmpty()) null
            else WordBoundary(m.groupValues[1].toLong() / 1e7, m.groupValues[2].toLong() / 1e7, text)
        }.toList()
    }

    private fun unescape(s: String): String {
        if (s.indexOf('\\') < 0) return s
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (val n = s[i + 1]) {
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    'r' -> sb.append('\r')
                    'u' -> if (i + 5 < s.length) {
                        sb.append(s.substring(i + 2, i + 6).toIntOrNull(16)?.toChar() ?: '?')
                        i += 4
                    }
                    else -> sb.append(n)
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }
}

/** What a WebSocket delivered: text or bytes. */
class WsMessage(val text: String?, val binary: ByteArray?)

/**
 * A small blocking WebSocket client (RFC 6455): enough for one request / response conversation over wss:// (or ws:// for tests).
 * Written here so the app needs no extra library. Closing it from another thread makes a blocked [receive] fail, which is how
 * a sentence is cancelled.
 */
class WebSocketClient(private val url: String, private val headers: Map<String, String>, private val timeoutMs: Int = 20_000) {
    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private val random = SecureRandom()
    @Volatile private var closed = false

    fun connect() {
        val uri = URI(url)
        val secure = uri.scheme.equals("wss", true) || uri.scheme.equals("https", true)
        val port = if (uri.port > 0) uri.port else if (secure) 443 else 80
        val host = uri.host
        val plain = Socket()
        plain.connect(InetSocketAddress(host, port), timeoutMs)
        plain.soTimeout = timeoutMs
        val s: Socket = if (secure) (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(plain, host, port, true) else plain
        socket = s
        if (closed) { s.close(); throw IOException("Cancelled") }
        input = BufferedInputStream(s.getInputStream(), 16 * 1024)
        output = s.getOutputStream()

        val keyBytes = ByteArray(16).also { random.nextBytes(it) }
        val key = Base64.getEncoder().encodeToString(keyBytes)
        val path = (uri.rawPath.ifEmpty { "/" }) + (uri.rawQuery?.let { "?$it" } ?: "")
        val req = StringBuilder()
        req.append("GET $path HTTP/1.1\r\n")
        req.append("Host: $host\r\n")
        req.append("Upgrade: websocket\r\nConnection: Upgrade\r\n")
        req.append("Sec-WebSocket-Key: $key\r\nSec-WebSocket-Version: 13\r\n")
        for ((k, v) in headers) req.append("$k: $v\r\n")
        req.append("\r\n")
        output!!.write(req.toString().toByteArray(Charsets.ISO_8859_1))
        output!!.flush()

        val status = readLine() ?: throw IOException("No answer from the speech service.")
        if (!status.contains(" 101")) throw IOException("The speech service refused the connection: $status")
        var accept: String? = null
        while (true) {
            val line = readLine() ?: throw IOException("Connection closed during the handshake.")
            if (line.isEmpty()) break
            if (line.startsWith("Sec-WebSocket-Accept:", true)) accept = line.substringAfter(':').trim()
        }
        val expected = Base64.getEncoder().encodeToString(
            MessageDigest.getInstance("SHA-1").digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray(Charsets.ISO_8859_1)),
        )
        if (accept != null && accept != expected) throw IOException("Bad WebSocket handshake.")
    }

    private fun readLine(): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input!!.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
    }

    @Synchronized
    private fun sendFrame(opcode: Int, payload: ByteArray) {
        val out = output ?: throw IOException("Not connected")
        val len = payload.size
        val head = ByteArrayOutputStream()
        head.write(0x80 or opcode)
        when {
            len < 126 -> head.write(0x80 or len)
            len < 65536 -> { head.write(0x80 or 126); head.write(len shr 8); head.write(len and 0xff) }
            else -> { head.write(0x80 or 127); for (i in 7 downTo 0) head.write(((len.toLong() shr (8 * i)) and 0xff).toInt()) }
        }
        val mask = ByteArray(4).also { random.nextBytes(it) }
        head.write(mask)
        val masked = ByteArray(len) { i -> (payload[i].toInt() xor mask[i % 4].toInt()).toByte() }
        out.write(head.toByteArray())
        out.write(masked)
        out.flush()
    }

    fun sendText(text: String) = sendFrame(1, text.toByteArray(Charsets.UTF_8))

    private fun readFully(n: Int): ByteArray {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input!!.read(buf, off, n - off)
            if (r < 0) throw EOFException("Connection closed")
            off += r
        }
        return buf
    }

    /** Waits for the next message; null when the other side closed the connection. */
    fun receive(): WsMessage? {
        var assembling: ByteArrayOutputStream? = null
        var firstOpcode = 0
        while (true) {
            val h = try { readFully(2) } catch (e: EOFException) { return null }
            val fin = (h[0].toInt() and 0x80) != 0
            val opcode = h[0].toInt() and 0x0f
            val masked = (h[1].toInt() and 0x80) != 0
            var len = (h[1].toInt() and 0x7f).toLong()
            if (len == 126L) { val e = readFully(2); len = (((e[0].toInt() and 0xff) shl 8) or (e[1].toInt() and 0xff)).toLong() }
            else if (len == 127L) { val e = readFully(8); len = 0; for (b in e) len = (len shl 8) or (b.toLong() and 0xff) }
            if (len > 64 * 1024 * 1024) throw IOException("Message too large")
            val mask = if (masked) readFully(4) else null
            val payload = readFully(len.toInt())
            if (mask != null) for (i in payload.indices) payload[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
            when (opcode) {
                8 -> return null
                9 -> { sendFrame(10, payload); continue }
                10 -> continue
                1, 2 -> { firstOpcode = opcode; assembling = ByteArrayOutputStream().also { it.write(payload) } }
                0 -> assembling?.write(payload)
                else -> continue
            }
            if (fin) {
                val data = assembling?.toByteArray() ?: continue
                return if (firstOpcode == 1) WsMessage(String(data, Charsets.UTF_8), null) else WsMessage(null, data)
            }
        }
    }

    fun close() {
        closed = true
        try { socket?.close() } catch (_: Exception) {}
    }
}
