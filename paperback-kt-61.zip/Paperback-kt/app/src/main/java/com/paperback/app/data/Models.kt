package com.paperback.app.data

data class Book(
    val id: String,              // SHA-256 of the file
    val title: String,
    val author: String,
    val language: String,
    val filePath: String,
    val coverPath: String?,
    val addedAt: Long,
    val lastOpenedAt: Long,      // 0 = never opened
    val progress: Float,         // 0..1 across the whole book
    val position: Int,           // Readium "position" (about one page), 0 = unread
    val totalPositions: Int,
    val locatorJson: String?,    // where to resume
    val finished: Boolean,
    val favorite: Boolean,
    val rating: Int,             // 0..5
    val journal: String = "",    // your own notes about the book
    val finishedAt: Long = 0L,   // 0 = unknown / not finished
    val tags: List<String> = emptyList(), // genres and subjects, cleaned (see Tags)
    val description: String = "",
    val publisher: String = "",
    val published: String = "",  // "1998-06-01", or just a year
    val metaRead: Boolean = true, // false until the file's own details have been read (older books are read once, after the update)
    val rating10: Float = 0f,    // your rating on a 0..10 scale, with halves and quarters; `rating` is this rounded to 1..5 stars
    val customPages: Int = 0,    // the page count you set (0 = the file's own count)
    val spineColor: Int = 0,     // ARGB colour of the spine on the shelves, 0 = chosen automatically
    val shelfOrder: Int = 0,     // place in "My order" in the Library, 0 = not placed
    val startedAt: Long = 0L,    // first day you read it (ms), 0 = unknown; the earliest reading entry sets it
    val ratedAt: Long = 0L,      // when the rating was last set (ms), 0 = unknown
    val status: Int = 0,         // BookStatus: 0 = normal, 1 = paused, 2 = dropped
    val statusAt: Long = 0L,     // when it was paused or dropped (ms)
    val droppedPct: Int = 0,     // percent read when you paused or dropped it
    val source: String = "",     // where the book came from: "file", "gutenberg", "calibre", "catalog", "bookshelf"...
    val format: String = "",     // how you read it: "ebook", "paper", "hardcover", "audiobook", "mixed", "other"; "" = from the file
    val series: String = "",     // series name, "" = none
    val seriesNo: Float = 0f,    // place in the series, 0 = not set
    val words: Int = 0,          // word count of the book, 0 = not counted yet
) {
    /** The page count that applies: yours if you set one, else the file's. */
    val pageCount: Int get() = com.paperback.app.catalog.PageMath.total(customPages, totalPositions)

    /** The page you are on, in [pageCount]. */
    val currentPage: Int get() = com.paperback.app.catalog.PageMath.current(customPages, totalPositions, position, progress.toDouble(), finished)

    /** False for a book added without a file (from the catalog or a Bookshelf import): it can be tracked, not read. */
    val hasFile: Boolean get() = filePath.isNotBlank()

    val isReading: Boolean get() = !finished && (progress > 0f || position > 1)
    val percent: Int get() = (progress * 100).toInt().coerceIn(0, 100)

    /** PDFs are opened by Paperback's own page viewer; everything else goes through Readium. */
    val isPdf: Boolean get() = filePath.endsWith(".pdf", ignoreCase = true)
}

/** Everything the Edit book page can change in one go. A null page or place means "leave it as it is". */
data class BookEdits(
    val title: String,
    val author: String,
    val description: String,
    val publisher: String,
    val published: String,
    val tags: List<String>,
    val language: String,
    val customPages: Int,        // 0 = use the file's count
    val currentPage: Int?,       // in the page count that applies after this change
    val spineColor: Int,         // 0 = automatic
    val shelfPosition: Int?,     // 1 = first in "My order"
    val format: String? = null,  // how you read it (see Formats); null = leave as it is
    val series: String? = null,  // series name, "" = none; null = leave as it is
    val seriesNo: Float? = null, // place in the series, 0 = not set
    val words: Int? = null,      // word count, 0 = not counted
)

data class ReadingSession(
    val id: Long,
    val bookId: String,
    val startMs: Long,
    val seconds: Int,
    val pages: Int,
    /** The first and last page (Readium position) of the session, 0 = not known. */
    val fromPos: Int = 0,
    val toPos: Int = 0,
    /** True when you set it (timer, hand-made or edited entry); false when the reader counted it. */
    val manual: Boolean = false,
    /** SessionKind: 0 = the reader counted it, 1 = listening (read-aloud), 2 = timer or hand-made entry. */
    val kind: Int = 0,
    /** Chapters you went through in this entry, 0 = not noted. */
    val chapters: Int = 0,
)

/** What a [ReadingSession] was. Stored in its own column; older rows are 0 or (when you made them) 2. */
object SessionKind {
    const val READ = 0
    const val LISTEN = 1
    const val LOGGED = 2
}

object BookStatus {
    const val NORMAL = 0
    const val PAUSED = 1
    const val DROPPED = 2
}

/** One time through a book: started, finished, and the rating you gave that time. A re-read is a second row. */
data class Reading(
    val id: Long,
    val bookId: String,
    val startedAt: Long,   // 0 = unknown
    val finishedAt: Long,
    val rating10: Float,   // 0 = not rated
)

data class Bookmark(
    val id: String,
    val bookId: String,
    val locatorJson: String,
    val position: Int,      // Readium position (about one page)
    val progress: Float,    // 0..1 across the book
    val createdAt: Long,
)

data class Highlight(
    val id: String,
    val bookId: String,
    val locatorJson: String,
    val text: String,       // the selected passage
    val note: String,       // "" for a plain highlight
    val color: Int,         // ARGB
    val progress: Float,
    val createdAt: Long,
)

object HighlightColors {
    val YELLOW = 0xFFFFE066.toInt()
    val CORAL = 0xFFF46B4E.toInt()
    val GREEN = 0xFF7BD88F.toInt()
    val BLUE = 0xFF6CB4FF.toInt()
    val DEFAULT = YELLOW
    val all = listOf(YELLOW, CORAL, GREEN, BLUE)
}

data class BookCollection(
    val id: String,
    val name: String,
    val createdAt: Long,
)
