package com.paperback.app.tts

/** A word of a sentence with the time it starts, as characters [start, end) of the spoken text. */
class TimedWord(val startSec: Double, val start: Int, val end: Int)

object TtsAlign {
    /**
     * Matches the words Edge reports to places in the sentence we asked it to speak, in order. A word that can't be found
     * (Edge spoke a number out, say) is skipped, and the next one carries on from where the last was found.
     */
    fun words(text: String, boundaries: List<WordBoundary>): List<TimedWord> {
        val out = ArrayList<TimedWord>(boundaries.size)
        var cursor = 0
        for (b in boundaries) {
            val w = b.text.trim()
            if (w.isEmpty()) continue
            var at = text.indexOf(w, cursor)
            if (at < 0) at = text.indexOf(w, cursor, ignoreCase = true)
            if (at < 0 || at - cursor > 40) continue
            out += TimedWord(b.startSec, at, at + w.length)
            cursor = at + w.length
        }
        return out
    }

    /** The index of the word being said at [positionSec], or -1 before the first word. */
    fun indexAt(words: List<TimedWord>, positionSec: Double): Int {
        var lo = 0
        var hi = words.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (words[mid].startSec <= positionSec) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }

    /**
     * Where the sound really ends: the end of the last word plus a short tail. Edge pads every sentence with most of a
     * second of silence, which would make the reading drag.
     */
    fun speechEndSec(boundaries: List<WordBoundary>): Double? {
        val last = boundaries.lastOrNull() ?: return null
        return last.startSec + last.durationSec + 0.22
    }

    /** Finds [word] in the page's own sentence text, from [cursor] on. Returns its start, or -1. */
    fun findInQuote(quote: String, word: String, cursor: Int): Int {
        val w = word.trim()
        if (w.isEmpty()) return -1
        var at = quote.indexOf(w, cursor)
        if (at < 0) at = quote.indexOf(w, cursor, ignoreCase = true)
        return at
    }
}
