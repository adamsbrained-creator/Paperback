package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.Subjects
import com.paperback.app.data.Book
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.catalog.CatalogApi
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.catalog.CatalogDetails
import com.paperback.app.data.catalog.Load
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

/** "12,400" -> "12.4k" for big counts. */
private fun compact(n: Int): String = when {
    n >= 10_000 -> "${n / 1000}k"
    n >= 1_000 -> "%.1fk".format(n / 1000.0)
    else -> n.toString()
}

private fun stars(rating: Double): String {
    val full = Math.round(rating).toInt().coerceIn(0, 5)
    return "★".repeat(full) + "☆".repeat(5 - full)
}

/**
 * A book from the online catalog: cover, rating, year, description, genres, and more by the author. It has no
 * book to read; if you own it, the page says so and opens your copy.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CatalogBookScreen(
    book: CatalogBook,
    owned: Book?,
    wished: Boolean,
    onToggleWish: () -> Unit,
    onAddWithoutFile: (pages: Int, tags: List<String>) -> Unit,
    ownedKeys: Set<String>,
    catalog: CatalogController,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenOwned: (Book) -> Unit,
    onOpenCatalogBook: (CatalogBook) -> Unit,
    onBrowse: (kind: String, value: String) -> Unit,
) {
    val t = pbTokens()
    val uri = LocalUriHandler.current
    var descOpen by remember(book.id) { mutableStateOf(false) }

    val details by produceState<Load<CatalogDetails>>(Load.Loading, book.id) {
        value = catalog.details(book).fold({ Load.Ready(it) }, { Load.Failed(it.message ?: "") })
    }
    val dv = details
    val d: CatalogDetails? = if (dv is Load.Ready) dv.value else null
    val rating = if ((d?.rating ?: 0.0) > 0.0) d!!.rating else book.rating
    val votes = if ((d?.rating ?: 0.0) > 0.0) d!!.ratingCount else book.ratingCount
    val genres = remember(d, book) { Subjects.clean(book.subjects + (d?.subjects ?: emptyList()), 10) }
    val author = book.firstAuthor()

    val byAuthor by produceState<List<CatalogBook>>(emptyList(), book.id) {
        value = if (author.isBlank()) emptyList()
        else catalog.list("author", author).getOrNull()?.books.orEmpty().filter { it.id != book.id }.take(12)
    }
    val topic = remember(genres) { genres.firstOrNull { !Subjects.isGeneric(it) } ?: genres.firstOrNull() }
    val alike by produceState<List<CatalogBook>>(emptyList(), book.id, topic) {
        value = if (topic == null) emptyList()
        else catalog.list("subject", topic).getOrNull()?.books.orEmpty()
            .filter { it.id != book.id && it.firstAuthor() != author }.take(12)
    }

    PbPage("Book", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            CatalogCover(book, Modifier.width(176.dp), size = "L")
        }
        Spacer(Modifier.height(20.dp))
        Text(
            book.title,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            color = t.ink,
            fontFamily = PbSerif,
            fontSize = 26.sp,
            lineHeight = 32.sp,
            fontWeight = FontWeight.Medium,
        )
        if (author.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                book.author,
                modifier = Modifier.fillMaxWidth().clickable { onBrowse("author", author) },
                textAlign = TextAlign.Center,
                color = t.setSub,
                fontSize = 16.sp,
            )
        }
        if (rating > 0.0) {
            Spacer(Modifier.height(10.dp))
            Text(
                "${stars(rating)}  ${"%.1f".format(rating)}" + if (votes > 0) "  ·  ${compact(votes)} ratings" else "",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
            )
        }

        Spacer(Modifier.height(18.dp))
        if (owned != null) {
            PbButton("In your library · Open", onClick = { onOpenOwned(owned) })
        } else {
            PbButton(if (wished) "\u2713 On your Want to read list" else "Want to read", onClick = onToggleWish, ghost = wished)
            Spacer(Modifier.height(10.dp))
            PbButton("Add to library without a file", onClick = { onAddWithoutFile(d?.pages ?: 0, genres) })
            Spacer(Modifier.height(10.dp))
            NoteCard(
                "Paperback doesn't sell or lend books. Add it without a file to rate it, mark it finished and log your reading, or get the file and add it with the + button in Library. If you add the file later, everything you recorded moves to it.",
                title = "Not in your library",
            )
            Spacer(Modifier.height(10.dp))
            PbButton("View on Open Library", onClick = { uri.openUri(CatalogApi.pageUrl(book)) }, ghost = true)
        }

        // the numbers
        val facts = buildList {
            if (book.year > 0) add("First published" to book.year.toString())
            val read = d?.alreadyRead ?: 0
            val want = d?.wantToRead ?: 0
            if (read > 0) add("Have read" to compact(read))
            if (want > 0) add("Want to read" to compact(want))
            if ((d?.pages ?: 0) > 0) add("Pages" to d!!.pages.toString())
            if (book.editions > 0) add("Editions" to book.editions.toString())
        }
        if (facts.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            facts.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { (label, value) -> StatTile(label, value, Modifier.weight(1f)) }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        // about
        SectionLabel("About this book")
        val text = d?.description.orEmpty()
        when {
            dv is Load.Loading -> Text("Loading…", color = t.setSub, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 4.dp))
            text.isBlank() -> Text(
                if (dv is Load.Failed) dv.message else "The catalog has no description for this book.",
                color = t.setSub,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            else -> {
                val long = text.length > 320
                Text(
                    text,
                    color = t.ink,
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    maxLines = if (descOpen || !long) Int.MAX_VALUE else 6,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
                if (long) {
                    Text(
                        if (descOpen) "Show less" else "Read more",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { descOpen = !descOpen }.padding(horizontal = 4.dp, vertical = 8.dp),
                    )
                }
            }
        }

        if (genres.isNotEmpty()) {
            SectionLabel("Genres")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                genres.forEach { g -> TagChip(g) { onBrowse("subject", g) } }
            }
        }

        val reason = remember(book.id) { catalog.reasonFor(book.id) }
        if (reason != null) {
            Spacer(Modifier.height(16.dp))
            Text(
                "Recommended: $reason",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }

        if (byAuthor.isNotEmpty()) {
            RowHeader("More by $author", onAll = { onBrowse("author", author) })
            CatalogRow(byAuthor, ownedKeys, onOpen = onOpenCatalogBook)
        }
        if (alike.isNotEmpty() && topic != null) {
            RowHeader("More $topic", onAll = { onBrowse("subject", topic) })
            CatalogRow(alike, ownedKeys, onOpen = onOpenCatalogBook)
        }

        Spacer(Modifier.height(28.dp))
        Text(
            "Book information from Open Library" + if (d?.credit == "Google Books") " and Google Books." else ".",
            color = t.setSub,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}
