package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/** Everything the book's Progress page shows about the way you read this one book. Pure functions. */
class BookInsights(
    val sessions: Int,
    val seconds: Long,
    val avgSeconds: Long,
    val bestSeconds: Long,
    val bestPages: Int,
    val avgPages: Int,
    /** Minutes per page turned; null until pages were counted. */
    val minPerPage: Double?,
    val firstMs: Long,
    val lastMs: Long,
    val readingDays: Int,
    /** Days from first reading to finish, for a finished book. */
    val daysToFinish: Int?,
    /** A guess for a book in progress: time left at your pace, spread over the days you usually read. */
    val estimatedFinish: LocalDate?,
    val listenSeconds: Long,
    /** Pages turned in each session, oldest first (the last [MAX_POINTS]). */
    val sessionPages: List<Int>,
    /** Pages turned so far after each of those sessions. */
    val cumulativePages: List<Int>,
    /** Which stretches of the book you have read, each as a start and end between 0 and 1. */
    val coverage: List<Pair<Float, Float>>,
)

const val MAX_POINTS = 40

fun bookInsights(book: Book, rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): BookInsights? {
    val mine = rows.filter { it.bookId == book.id && (it.seconds > 0 || it.pages > 0) }
    if (mine.isEmpty()) return null
    val merged = buildSessions(mine)
    val seconds = merged.sumOf { it.seconds }
    val pages = merged.sumOf { it.pages }
    val first = merged.minOf { it.startMs }
    val last = merged.maxOf { it.endMs }
    val days = merged.map { dateOf(it.startMs, zone) }.toSet().size

    val finishDays = if (book.finished) {
        val start = if (book.startedAt in 1..first) book.startedAt else first
        (ChronoUnit.DAYS.between(dateOf(start, zone), dateOf(finishedAtMs(book), zone)).toInt() + 1).coerceAtLeast(1)
    } else null

    var estimate: LocalDate? = null
    if (!book.finished && book.pageCount > 0 && pages >= 10 && seconds >= 300) {
        val left = Stats.timeLeftSeconds(book, seconds.toDouble() / pages)
        val perDay = seconds.toDouble() / days.coerceAtLeast(1)
        if (left != null && perDay > 0) estimate = today.plusDays(Math.ceil(left / perDay).toLong().coerceIn(0L, 3650L))
    }

    var running = 0
    val cumulative = merged.map { running += it.pages; running }
    val from = (merged.size - MAX_POINTS).coerceAtLeast(0)

    val total = book.totalPositions
    val coverage = if (total > 0) {
        merged.filter { it.fromPos > 0 && it.toPos > it.fromPos }
            .map { (it.fromPos.toFloat() / total).coerceIn(0f, 1f) to (it.toPos.toFloat() / total).coerceIn(0f, 1f) }
    } else emptyList()

    val best = merged.maxByOrNull { it.seconds }
    return BookInsights(
        sessions = merged.size,
        seconds = seconds,
        avgSeconds = seconds / merged.size,
        bestSeconds = best?.seconds ?: 0L,
        bestPages = merged.maxOfOrNull { it.pages } ?: 0,
        avgPages = pages / merged.size,
        minPerPage = if (pages > 0 && seconds > 0) seconds / 60.0 / pages else null,
        firstMs = first,
        lastMs = last,
        readingDays = days,
        daysToFinish = finishDays,
        estimatedFinish = estimate,
        listenSeconds = mine.filter { it.kind == SessionKind.LISTEN }.sumOf { it.seconds.toLong() },
        sessionPages = merged.drop(from).map { it.pages },
        cumulativePages = cumulative.drop(from),
        coverage = coverage,
    )
}
