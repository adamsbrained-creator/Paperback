package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.Consistency
import com.paperback.app.data.ForecastRow
import com.paperback.app.data.Goals
import com.paperback.app.data.MonthCompare
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Records
import com.paperback.app.data.Speed
import com.paperback.app.data.StatNames
import com.paperback.app.data.Stats
import com.paperback.app.data.YearPace
import com.paperback.app.data.commas
import com.paperback.app.data.consistency
import com.paperback.app.data.finishForecast
import com.paperback.app.data.inDaysText
import com.paperback.app.data.monthCompare
import com.paperback.app.data.readingRecords
import com.paperback.app.data.readingSpeed
import com.paperback.app.data.yearPace
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** Where a tap on the Insights page goes. The Stats screen builds this from the app's navigation. */
class InsightsLinks(
    /** Stats -> History, on that day. */
    val history: (day: LocalDate) -> Unit,
    val book: (bookId: String) -> Unit,
    /** A shelf of books: "done-2026" is the books finished in 2026. */
    val shelf: (kind: String) -> Unit,
)

private val FORECAST_ACCENTS = listOf(StatsAccent.Blue, StatsAccent.Mint, StatsAccent.Pink, StatsAccent.Yellow)

private fun dayText(d: LocalDate) = "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"

private fun minText(seconds: Long) = Stats.duration(seconds)

/**
 * Stats -> Insights: how this month compares, consistency, reading speed, records, finish estimates and the pace of
 * the year. Every card opens something: History on a day, a book, or the books finished this year.
 */
@Composable
fun InsightsScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    goals: Goals,
    links: InsightsLinks,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val zone = remember { ZoneId.systemDefault() }
    val nowMs = remember { System.currentTimeMillis() }
    val today = remember { LocalDate.now(zone) }

    if (sessions.isEmpty()) {
        Box(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("No insights yet", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Read for a few days and what stands out will show up here.",
                    color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center,
                )
            }
        }
        return
    }

    val month = remember(sessions) { monthCompare(sessions, today, zone) }
    val cons = remember(sessions) { consistency(sessions, today, zone) }
    val speed = remember(sessions) { readingSpeed(sessions, today, zone) }
    val rec = remember(sessions) { readingRecords(sessions, zone) }
    val forecast = remember(books, sessions) { finishForecast(books, sessions, today, zone) }
    val finished = remember(books) { Stats.booksFinishedInYear(books, today.year, zone) }
    val year = remember(finished, goals.booksPerYear) { yearPace(finished, goals.booksPerYear, nowMs, zone) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "month") { MonthCard(month) { links.history(today) } }
        item(key = "consistency") { ConsistencyCard(cons) { links.history(today) } }
        item(key = "speed") { SpeedCard(speed, links) }
        item(key = "records-label") {
            CardLabel("Your records", Modifier.padding(start = 4.dp, top = 12.dp))
        }
        item(key = "records") { RecordsTiles(rec, links) }
        if (forecast.isNotEmpty()) {
            item(key = "forecast") { ForecastCard(forecast, links) }
        }
        item(key = "year") {
            YearCard(year, onOpen = if (year.finished > 0) ({ links.shelf("done-${year.year}") }) else null)
        }
    }
}

// ---- shared bits ----------------------------------------------------------------------------

/** A grey card. With [onTap] it is clickable (and announced as a button). */
@Composable
private fun InsightCard(description: String, onTap: (() -> Unit)?, content: @Composable () -> Unit) {
    val t = pbTokens()
    val tap = if (onTap != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button, onClick = onTap) else Modifier
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(t.card)
            .semantics(mergeDescendants = true) { contentDescription = description }
            .then(tap)
            .padding(horizontal = 20.dp, vertical = 18.dp),
    ) { content() }
}

/** The title of a card with a small note at the right: "Reading speed" ... "pages per hour". */
@Composable
private fun CardHead(title: String, note: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
        Text(title, modifier = Modifier.weight(1f), color = t.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(10.dp))
        Text(note, color = t.setSub, fontSize = 14.sp)
    }
}

/** A big number with its unit after it, on one baseline. */
@Composable
private fun NumberUnit(number: String, unit: String?, color: Color, size: Int = 44) {
    val t = pbTokens()
    Row {
        Text(
            number,
            modifier = Modifier.alignByBaseline(),
            color = color,
            fontFamily = PbSerif,
            fontSize = size.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.02).em,
            maxLines = 1,
        )
        if (unit != null) {
            Text(unit, modifier = Modifier.alignByBaseline().padding(start = 6.dp), color = t.setSub, fontSize = 16.sp, maxLines = 1)
        }
    }
}

// ---- this month against last ----------------------------------------------------------------

@Composable
private fun MonthCard(m: MonthCompare, onOpen: () -> Unit) {
    val t = pbTokens()
    val pct = m.pct
    val up = pct != null && pct >= 0
    val em = if (up) inkOf(StatsAccent.Mint) else inkOf(StatsAccent.Pink)
    val sentence: AnnotatedString = buildAnnotatedString {
        when {
            pct == null -> {
                append("You've read ")
                withStyle(SpanStyle(color = em)) { append(minText(m.cur)) }
                append(" this month.")
            }
            pct == 0 -> append("You're reading about the same as last month.")
            else -> {
                append("You're reading ")
                withStyle(SpanStyle(color = em)) { append("${abs(pct)}% ${if (up) "more" else "less"}") }
                append(" than ${m.prevName}.")
            }
        }
    }
    val maxSeconds = max(1L, max(m.cur, m.prev))
    InsightCard("${m.monthName} so far: ${minText(m.cur)}. Open History.", onOpen) {
        CardLabel("${m.monthName} so far")
        Spacer(Modifier.height(12.dp))
        Text(sentence, color = t.ink, fontFamily = PbSerif, fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(16.dp))
        CompareRow(m.monthName.take(3), m.cur, maxSeconds, StatsAccent.Blue, 1f)
        Spacer(Modifier.height(10.dp))
        CompareRow(m.prevName.take(3), m.prev, maxSeconds, StatsAccent.Yellow, 0.55f)
        Text(
            "${m.monthName} is compared with the same days of ${m.prevName}.",
            modifier = Modifier.padding(top = 12.dp),
            color = t.setSub,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun CompareRow(label: String, seconds: Long, maxSeconds: Long, color: Color, alpha: Float) {
    val t = pbTokens()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.width(48.dp), color = t.ink, fontSize = 15.sp)
        Box(Modifier.weight(1f)) {
            PctBar(max(0.02f, seconds.toFloat() / maxSeconds), color.copy(alpha = alpha), 10.dp)
        }
        Text(minText(seconds), modifier = Modifier.width(64.dp), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
    }
}

// ---- consistency ----------------------------------------------------------------------------

@Composable
private fun ConsistencyCard(c: Consistency, onOpen: () -> Unit) {
    val t = pbTokens()
    InsightCard("Consistency: ${c.activeDays} of ${c.of} days. Open History.", onOpen) {
        CardLabel("Consistency")
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            RingArc(c.pct, StatsAccent.Mint, 104.dp, 12.dp) {
                Text("${(c.pct * 100).roundToInt()}%", color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                NumberUnit("${c.activeDays}", "of ${c.of} days", t.ink, size = 40)
                Text(
                    "You opened a book on ${c.activeDays} of the last ${c.of} days.",
                    modifier = Modifier.padding(top = 4.dp),
                    color = t.setSub,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("${c.streak}d", color = inkOf(StatsAccent.Yellow), fontFamily = PbSerif, fontSize = 30.sp, fontWeight = FontWeight.Medium)
                Text("Streak", color = t.setSub, fontSize = 13.sp)
            }
            Column(Modifier.weight(1f)) {
                Text("${c.longestStreak}d", color = t.ink, fontFamily = PbSerif, fontSize = 30.sp, fontWeight = FontWeight.Medium)
                Text("Best streak", color = t.setSub, fontSize = 13.sp)
            }
        }
    }
}

/** A ring filled [value] (0..1) of the way round from the top, with [content] in the middle. */
@Composable
private fun RingArc(value: Float, color: Color, size: Dp, stroke: Dp, content: @Composable () -> Unit) {
    val track = trackColor()
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = stroke.toPx()
            val d = this.size.minDimension - sw
            val tl = Offset(sw / 2f, sw / 2f)
            drawArc(track, 0f, 360f, false, topLeft = tl, size = Size(d, d), style = Stroke(sw))
            val v = value.coerceIn(0f, 1f)
            if (v > 0f) {
                drawArc(color, -90f, 360f * v, false, topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
            }
        }
        content()
    }
}

// ---- reading speed --------------------------------------------------------------------------

private const val BAR_AREA = 62

@Composable
private fun SpeedCard(speed: Speed, links: InsightsLinks) {
    val t = pbTokens()
    val yellow = StatsAccent.Yellow
    val best = speed.best
    val maxPace = max(1, speed.months.maxOf { it.pace })
    InsightCard("Reading speed: ${if (speed.current > 0) "${speed.current} pages per hour" else "not enough reading yet"}.", null) {
        CardHead("Reading speed", "pages per hour")
        Spacer(Modifier.height(14.dp))
        NumberUnit(if (speed.current > 0) "${speed.current}" else "\u2013", if (speed.current > 0) "p/h" else null, inkOf(yellow))
        Text(
            if (best != null) "Fastest month: ${best.label} \u00B7 ${best.pace} p/h" else "Read a little longer to see how your speed changes.",
            modifier = Modifier.padding(top = 6.dp),
            color = t.setSub,
            fontSize = 14.sp,
        )
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().height((BAR_AREA + 48).dp)) {
            speed.months.forEach { s ->
                val top = best != null && best.label == s.label && s.pace == best.pace
                val h = if (s.pace > 0) max(10, ((s.pace.toFloat() / maxPace) * BAR_AREA).roundToInt()) else 6
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(horizontal = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .semantics(mergeDescendants = true) {
                            contentDescription = "${s.label}: ${if (s.pace > 0) "${s.pace} pages per hour" else "not enough reading"}. Open that month in History."
                        }
                        .clickable(onClickLabel = "Open that month", role = Role.Button) { links.history(s.firstDay) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    if (s.pace > 0) {
                        Text("${s.pace}", color = if (top) inkOf(yellow) else t.setSub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(3.dp))
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(h.dp)
                            .clip(RoundedCornerShape(7.dp))
                            .background(
                                when {
                                    s.pace <= 0 -> yellow.copy(alpha = 0.25f)
                                    top -> yellow
                                    else -> yellow.copy(alpha = 0.55f)
                                },
                            ),
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(s.label, color = t.setSub, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}

// ---- records --------------------------------------------------------------------------------

@Composable
private fun RecordsTiles(rec: Records, links: InsightsLinks) {
    val bestDay = rec.bestDay
    val longest = rec.longestSession
    val bestWeek = rec.bestWeek
    val most = rec.mostPages
    val zone = remember { ZoneId.systemDefault() }
    val longestDay = longest?.let { java.time.Instant.ofEpochMilli(it.startMs).atZone(zone).toLocalDate() }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TileRow(
            { m ->
                StatTile(
                    "Best day", StatsAccent.Blue, m,
                    onTap = if (bestDay != null) ({ links.history(bestDay.date) }) else null,
                    description = if (bestDay != null) "Best day, ${dayText(bestDay.date)}. Open that day." else "Best day: none yet.",
                ) {
                    BigNumber(if (bestDay != null) minText(bestDay.seconds) else "\u2013")
                    if (bestDay != null) TileSub(dayText(bestDay.date))
                }
            },
            { m ->
                StatTile(
                    "Longest session", StatsAccent.Mint, m,
                    onTap = if (longest != null && longestDay != null) ({ links.history(longestDay) }) else null,
                    description = if (longestDay != null) "Longest session, ${dayText(longestDay)}. Open that day." else "Longest session: none yet.",
                ) {
                    BigNumber(if (longest != null) minText(longest.seconds) else "\u2013")
                    if (longestDay != null) TileSub(dayText(longestDay))
                }
            },
        )
        TileRow(
            { m ->
                StatTile(
                    "Best week", StatsAccent.Pink, m,
                    onTap = if (bestWeek != null) ({ links.history(bestWeek.start) }) else null,
                    description = if (bestWeek != null) "Best week, from ${dayText(bestWeek.start)}. Open that week." else "Best week: none yet.",
                ) {
                    BigNumber(if (bestWeek != null) minText(bestWeek.seconds) else "\u2013")
                    if (bestWeek != null) TileSub("from ${dayText(bestWeek.start)}")
                }
            },
            { m ->
                StatTile(
                    "Most pages a day", StatsAccent.Yellow, m,
                    onTap = if (most != null) ({ links.history(most.date) }) else null,
                    description = if (most != null) "Most pages in a day, ${dayText(most.date)}. Open that day." else "Most pages in a day: none yet.",
                ) {
                    BigNumber(if (most != null) commas(most.pages) else "\u2013")
                    if (most != null) TileSub("${StatNames.WEEKDAYS_SHORT[StatNames.weekdayIndex(most.date)]} ${dayText(most.date)}")
                }
            },
        )
    }
}

// ---- when you will finish -------------------------------------------------------------------

@Composable
private fun ForecastCard(rows: List<ForecastRow>, links: InsightsLinks) {
    val t = pbTokens()
    InsightCard("When you'll finish: ${rows.size} ${if (rows.size == 1) "book" else "books"} at your pace.", null) {
        CardHead("When you'll finish", "at your pace")
        Spacer(Modifier.height(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            rows.forEachIndexed { i, r ->
                val ac = FORECAST_ACCENTS[i % FORECAST_ACCENTS.size]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .semantics(mergeDescendants = true) { contentDescription = "${r.book.title}. Open book details." }
                        .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(r.book.id) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BookCover(r.book, Modifier.width(42.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.book.title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${commas(r.pagesLeft)} ${if (r.pagesLeft == 1) "page" else "pages"} left \u00B7 ${minText(r.secondsLeft)} of reading",
                            color = t.setSub,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                        )
                    }
                    if (r.days != null) {
                        Spacer(Modifier.width(8.dp))
                        Text(
                            inDaysText(r.days),
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(ac.copy(alpha = 0.14f))
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                            color = inkOf(ac),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}

// ---- the year -------------------------------------------------------------------------------

@Composable
private fun YearCard(y: YearPace, onOpen: (() -> Unit)?) {
    val t = pbTokens()
    val mint = StatsAccent.Mint
    val mark = minOf(100f, (y.expected.toFloat() / max(1, y.goal)) * 100f)
    InsightCard("Books in ${y.year}: ${y.finished} of ${y.goal}.${if (onOpen != null) " Show the books." else ""}", onOpen) {
        CardHead("Books in ${y.year}", "goal ${y.goal}")
        Spacer(Modifier.height(14.dp))
        NumberUnit("${y.finished}", "of ${y.goal}", inkOf(mint))
        Spacer(Modifier.height(10.dp))
        YearBar(minOf(1f, y.finished.toFloat() / max(1, y.goal)), mark / 100f, mint)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                if (y.finished >= y.expected) "On pace or ahead" else "${y.expected - y.finished} behind the line",
                color = t.setSub, fontSize = 14.sp,
            )
            Text(
                if (y.projected > 0) "${y.projected} by December at this rate" else "",
                color = t.setSub, fontSize = 14.sp,
            )
        }
    }
}

/** The books-so-far bar with a dotted mark where a straight line through the year would be today. */
@Composable
private fun YearBar(fraction: Float, mark: Float, color: Color) {
    val track = trackColor()
    val dots = pbTokens().setSub
    Canvas(Modifier.fillMaxWidth().height(26.dp)) {
        val h = 10.dp.toPx()
        val top = (size.height - h) / 2f
        val r = CornerRadius(h / 2f)
        drawRoundRect(track, topLeft = Offset(0f, top), size = Size(size.width, h), cornerRadius = r)
        val w = max(h, size.width * fraction.coerceIn(0f, 1f)).coerceAtMost(size.width)
        drawRoundRect(color, topLeft = Offset(0f, top), size = Size(w, h), cornerRadius = r)
        val x = (size.width * mark.coerceIn(0f, 1f)).coerceIn(2.dp.toPx(), size.width - 2.dp.toPx())
        for (k in -1..1) drawCircle(dots, radius = 1.6.dp.toPx(), center = Offset(x, size.height / 2f + k * 7.dp.toPx()))
    }
}
