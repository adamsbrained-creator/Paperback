package com.paperback.app.tts

/**
 * Turns one XHTML file of a book into sentences to speak. Pure Kotlin (no Android), so it can be tested on a laptop.
 *
 * The text is read the way a browser's `document.body.textContent` would read it: every text node in order, entities
 * decoded, whitespace left alone. That matters because the reader draws the spoken sentence by *searching for its text*
 * (Readium decorations find a quote plus the few characters around it), so the quote and its neighbours must be the
 * page's own characters and not a tidied copy. What is *spoken* is a tidied copy ([TtsSentence.text]).
 */
class TtsSentence(
    /** What the voice says: whitespace collapsed, invisible characters gone. */
    val text: String,
    /** The page's own text for this sentence (trimmed), used to find and mark it on the page. */
    val quote: String,
    /** A few characters of the page just before / after the quote, so a repeated sentence is found in the right place. */
    val before: String,
    val after: String,
    /** Which paragraph of the file it belongs to (0, 1, 2...). Previous / next paragraph steps by this. */
    val paragraph: Int,
    /** Where it starts in the file's text, 0..1, for saving the reading position. */
    val progression: Double,
    val heading: Boolean,
)

class TtsChapter(
    val index: Int,
    val href: String,
    val sentences: List<TtsSentence>,
)

object TtsHtml {
    private const val CONTEXT = 40
    private const val MAX_SENTENCE = 360

    private val BLOCKS = setOf(
        "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "ul", "ol", "blockquote", "tr", "td", "th", "table", "dt", "dd", "dl",
        "pre", "section", "article", "aside", "header", "footer", "figure", "figcaption", "caption", "hr", "br", "body", "nav", "main",
    )
    private val SKIP_CONTENT = setOf("script", "style", "head", "title", "svg", "math")

    private val ENTITIES = mapOf(
        "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ", "shy" to "­",
        "mdash" to "—", "ndash" to "–", "hellip" to "…", "laquo" to "«", "raquo" to "»", "lsquo" to "‘", "rsquo" to "’",
        "ldquo" to "“", "rdquo" to "”", "sbquo" to "‚", "bdquo" to "„", "copy" to "©", "reg" to "®", "deg" to "°",
        "middot" to "·", "bull" to "•", "times" to "×", "euro" to "€", "pound" to "£", "sect" to "§", "para" to "¶",
        "thinsp" to " ", "ensp" to " ", "emsp" to " ", "zwj" to "‍", "zwnj" to "‌",
    )

    private class Para(val start: Int, val end: Int, val heading: Boolean)

    /** Reads [html] and returns its sentences, in order. [href] is only carried along. */
    fun chapter(index: Int, href: String, html: String): TtsChapter {
        val body = StringBuilder()
        val paras = ArrayList<Para>()
        var paraStart = -1
        var inHeading = 0
        var headingPara = false
        var skipDepth = 0
        var skipTag = ""

        fun closePara() {
            if (paraStart >= 0 && body.length > paraStart) paras += Para(paraStart, body.length, headingPara)
            paraStart = -1
            headingPara = false
        }

        var i = 0
        val n = html.length
        // Before <body> only the head can exist; anything inside <head> is skipped by SKIP_CONTENT.
        while (i < n) {
            val c = html[i]
            if (c == '<') {
                if (html.startsWith("<!--", i)) {
                    val e = html.indexOf("-->", i + 4)
                    i = if (e < 0) n else e + 3
                    continue
                }
                if (html.startsWith("<![CDATA[", i)) {
                    val e = html.indexOf("]]>", i + 9)
                    val raw = html.substring(i + 9, if (e < 0) n else e)
                    if (skipDepth == 0) {
                        if (paraStart < 0) paraStart = body.length
                        body.append(raw)
                    }
                    i = if (e < 0) n else e + 3
                    continue
                }
                if (i + 1 < n && (html[i + 1] == '!' || html[i + 1] == '?')) {
                    val e = html.indexOf('>', i + 1)
                    i = if (e < 0) n else e + 1
                    continue
                }
                // a tag: find its end, honouring quotes inside attribute values
                var j = i + 1
                var quote = 0.toChar()
                while (j < n) {
                    val d = html[j]
                    if (quote != 0.toChar()) {
                        if (d == quote) quote = 0.toChar()
                    } else if (d == '"' || d == '\'') {
                        quote = d
                    } else if (d == '>') break
                    j++
                }
                val inner = html.substring(i + 1, minOf(j, n))
                i = minOf(j + 1, n)
                if (inner.isEmpty() || !(inner[0].isLetter() || inner[0] == '/')) {
                    // a stray "<": treat as text
                    if (skipDepth == 0) {
                        if (paraStart < 0) paraStart = body.length
                        body.append('<').append(inner)
                    }
                    continue
                }
                val closing = inner[0] == '/'
                val from = if (closing) 1 else 0
                var nameEnd = from
                while (nameEnd < inner.length && !inner[nameEnd].isWhitespace() && inner[nameEnd] != '/') nameEnd++
                val name = inner.substring(from, nameEnd).lowercase().substringAfter(':')
                val selfClosing = inner.endsWith("/")

                if (skipDepth > 0) {
                    if (name == skipTag) {
                        if (closing) skipDepth-- else if (!selfClosing) skipDepth++
                    }
                    continue
                }
                if (!closing && name in SKIP_CONTENT && !selfClosing) {
                    closePara()
                    skipDepth = 1
                    skipTag = name
                    continue
                }
                if (name in BLOCKS) {
                    closePara()
                    if (name.length == 2 && name[0] == 'h' && name[1] in '1'..'6') {
                        if (closing) inHeading = 0 else inHeading = 1
                    }
                    if (!closing && inHeading == 1) headingPara = true
                }
                continue
            }
            // text up to the next tag
            val e = html.indexOf('<', i).let { if (it < 0) n else it }
            if (skipDepth == 0) {
                val chunk = decode(html.substring(i, e))
                if (chunk.isNotEmpty()) {
                    if (paraStart < 0) {
                        paraStart = body.length
                        if (inHeading == 1) headingPara = true
                    }
                    body.append(chunk)
                }
            }
            i = e
        }
        closePara()

        val text = body.toString()
        val sentences = ArrayList<TtsSentence>()
        var paragraphNo = 0
        for (p in paras) {
            val raw = text.substring(p.start, p.end)
            if (raw.none { it.isLetterOrDigit() }) continue
            var made = 0
            for (r in split(raw)) {
                val piece = raw.substring(r.first, r.last + 1)
                val trimmed = piece.trim()
                val spoken = speakable(trimmed)
                if (spoken.none { it.isLetterOrDigit() }) continue
                val absStart = p.start + r.first + (piece.length - piece.trimStart().length)
                val absEnd = absStart + trimmed.length
                sentences += TtsSentence(
                    text = spoken,
                    quote = trimmed,
                    before = text.substring(maxOf(0, absStart - CONTEXT), absStart),
                    after = text.substring(absEnd, minOf(text.length, absEnd + CONTEXT)),
                    paragraph = paragraphNo,
                    progression = if (text.isEmpty()) 0.0 else absStart.toDouble() / text.length,
                    heading = p.heading,
                )
                made++
            }
            if (made > 0) paragraphNo++
        }
        return TtsChapter(index, href, sentences)
    }

    /** Collapses whitespace and drops characters that are never spoken. */
    fun speakable(s: String): String {
        val sb = StringBuilder(s.length)
        var space = false
        for (ch in s) {
            when {
                ch == '­' || ch == '​' || ch == '‌' || ch == '‍' || ch == '﻿' -> {}
                ch.isWhitespace() || ch == ' ' -> space = sb.isNotEmpty()
                else -> {
                    if (space) sb.append(' ')
                    space = false
                    sb.append(ch)
                }
            }
        }
        return sb.toString()
    }

    fun decode(s: String): String {
        if (s.indexOf('&') < 0) return s
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '&') {
                val semi = s.indexOf(';', i + 1)
                if (semi in (i + 2)..(i + 10)) {
                    val name = s.substring(i + 1, semi)
                    val rep: String? = when {
                        name.startsWith("#x") || name.startsWith("#X") -> name.substring(2).toIntOrNull(16)?.let { cp(it) }
                        name.startsWith("#") -> name.substring(1).toIntOrNull()?.let { cp(it) }
                        else -> ENTITIES[name]
                    }
                    if (rep != null) {
                        sb.append(rep)
                        i = semi + 1
                        continue
                    }
                }
            }
            sb.append(c)
            i++
        }
        return sb.toString()
    }

    private fun cp(code: Int): String? = if (code in 1..0x10FFFF && code !in 0xD800..0xDFFF) String(Character.toChars(code)) else null

    // ---- sentences -------------------------------------------------------------------------------

    private val ABBREVIATIONS = setOf(
        "mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "mt", "vs", "etc", "no", "fig", "gen", "col", "lt", "capt", "sgt", "rev", "hon",
        "inc", "ltd", "co", "approx", "dept", "est", "e.g", "i.e", "cf", "al", "p", "pp", "vol", "ch",
        // Russian / Ukrainian / Czech
        "г", "гг", "т", "д", "п", "см", "стр", "им", "ул", "рис", "пр", "тов", "акад", "проф", "доц", "руб", "коп", "тыс", "млн", "млрд",
        "tzv", "např", "atd", "resp", "mj", "tj", "popř",
    )
    private const val TERMINATORS = ".!?…。！？‼⁇⁈⁉"
    private const val CLOSERS = "\"'»”’)]}›」』）”’"

    /** Splits one paragraph into sentence ranges (inclusive of the whitespace that follows each, so the ranges tile it). */
    fun split(para: String): List<IntRange> {
        val out = ArrayList<IntRange>()
        var start = 0
        var i = 0
        val n = para.length
        while (i < n) {
            val c = para[i]
            if (c in TERMINATORS) {
                var j = i + 1
                while (j < n && para[j] in TERMINATORS) j++ // "?!", "..."
                while (j < n && para[j] in CLOSERS) j++
                val cjk = c in "。！？"
                val atEnd = j >= n
                val gap = j < n && (para[j].isWhitespace() || para[j] == ' ')
                if (atEnd || gap || cjk) {
                    var k = j
                    while (k < n && (para[k].isWhitespace() || para[k] == ' ')) k++
                    if (atEnd || cjk || shouldBreak(para, start, i, c, k)) {
                        out += start until k
                        start = k
                        i = k
                        continue
                    }
                }
                i = j
                continue
            }
            i++
        }
        if (start < n) out += start until n
        return splitLong(para, out)
    }

    private fun shouldBreak(p: String, sentenceStart: Int, termIndex: Int, term: Char, next: Int): Boolean {
        if (next >= p.length) return true
        if (term == '.') {
            // the word just before the full stop
            var w = termIndex
            while (w > sentenceStart && (p[w - 1].isLetter() || p[w - 1] == '.')) w--
            val word = p.substring(w, termIndex).lowercase()
            if (word.length == 1 && word[0].isLetter()) return false // an initial: "J. Smith", "А. С. Пушкин"
            if (word in ABBREVIATIONS) return false
        }
        // "..." or "…" followed by a lower-case letter carries on
        if ((term == '.' || term == '…') && p[next].isLowerCase()) return false
        return true
    }

    /** A very long sentence is cut at a semicolon or comma so the voice (and the highlight) can move along. */
    private fun splitLong(p: String, ranges: List<IntRange>): List<IntRange> {
        if (ranges.none { it.last - it.first + 1 > MAX_SENTENCE }) return ranges
        val out = ArrayList<IntRange>()
        for (r in ranges) {
            if (r.last - r.first + 1 <= MAX_SENTENCE) {
                out += r
                continue
            }
            var s = r.first
            while (r.last + 1 - s > MAX_SENTENCE) {
                var cut = -1
                val limit = s + MAX_SENTENCE
                var k = s + MAX_SENTENCE / 3
                while (k < limit && k <= r.last) {
                    val ch = p[k]
                    if ((ch == ';' || ch == ',' || ch == ':' || ch == '—') && k + 1 <= r.last && p[k + 1].isWhitespace()) cut = k + 1
                    k++
                }
                if (cut < 0) {
                    // no punctuation: break at the last space before the limit
                    var sp = limit
                    while (sp > s + MAX_SENTENCE / 3 && !p[sp].isWhitespace()) sp--
                    cut = if (sp > s + MAX_SENTENCE / 3) sp + 1 else limit
                }
                while (cut <= r.last && p[cut].isWhitespace()) cut++
                out += s until cut
                s = cut
            }
            if (s <= r.last) out += s..r.last
        }
        return out
    }

    // ---- language ---------------------------------------------------------------------------------

    /** Guesses a language from the alphabet of [sample], or null when it is Latin script (then the book's own language is used). */
    fun languageOfScript(sample: String): String? {
        var cyr = 0; var han = 0; var kana = 0; var hang = 0; var arab = 0; var heb = 0; var greek = 0; var thai = 0; var latin = 0; var deva = 0
        for (ch in sample.take(2000)) {
            when (Character.UnicodeScript.of(ch.code)) {
                Character.UnicodeScript.CYRILLIC -> cyr++
                Character.UnicodeScript.HAN -> han++
                Character.UnicodeScript.HIRAGANA, Character.UnicodeScript.KATAKANA -> kana++
                Character.UnicodeScript.HANGUL -> hang++
                Character.UnicodeScript.ARABIC -> arab++
                Character.UnicodeScript.HEBREW -> heb++
                Character.UnicodeScript.GREEK -> greek++
                Character.UnicodeScript.THAI -> thai++
                Character.UnicodeScript.DEVANAGARI -> deva++
                Character.UnicodeScript.LATIN -> latin++
                else -> {}
            }
        }
        val total = cyr + han + kana + hang + arab + heb + greek + thai + latin + deva
        if (total < 20) return null
        fun big(x: Int) = x * 2 > total
        return when {
            big(cyr) -> "ru"
            kana > 0 && big(kana + han) -> "ja"
            big(han) -> "zh"
            big(hang) -> "ko"
            big(arab) -> "ar"
            big(heb) -> "he"
            big(greek) -> "el"
            big(thai) -> "th"
            big(deva) -> "hi"
            else -> null
        }
    }
}
