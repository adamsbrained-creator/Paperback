package com.paperback.app.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.reflow.EpubWriter
import com.paperback.app.reflow.NoTextException
import com.paperback.app.reflow.PdfReflower
import com.paperback.app.reflow.ReflowException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication
import org.readium.r2.shared.publication.services.cover
import org.readium.r2.shared.publication.services.positions
import java.io.File
import java.security.MessageDigest
import java.util.UUID

sealed interface ImportOutcome {
    data class Added(val title: String, val id: String = "") : ImportOutcome
    data class Duplicate(val name: String, val id: String = "") : ImportOutcome
    data class Unsupported(val name: String) : ImportOutcome
    data class Failed(val name: String) : ImportOutcome
}

sealed interface ReflowOutcome {
    data class Done(val id: String, val title: String) : ReflowOutcome
    data class Exists(val id: String) : ReflowOutcome
    data class Failed(val message: String) : ReflowOutcome
}

class Repository(
    private val context: Context,
    private val db: PaperbackDb,
    private val readium: Readium,
) {
    private val _books = MutableStateFlow<List<Book>>(emptyList())
    val books: StateFlow<List<Book>> = _books.asStateFlow()

    private val _sessions = MutableStateFlow<List<ReadingSession>>(emptyList())
    /** What the stats use: the reader's own counting, minus the stretches you took over with the timer or an entry. */
    val sessions: StateFlow<List<ReadingSession>> = _sessions.asStateFlow()

    private val _rawSessions = MutableStateFlow<List<ReadingSession>>(emptyList())
    /** Every stored session, nothing left out: for the entry editor and for backups. */
    val rawSessions: StateFlow<List<ReadingSession>> = _rawSessions.asStateFlow()

    private fun publishSessions() {
        val raw = db.allSessions()
        val spans = raw.map {
            com.paperback.app.catalog.Coverage.Span(it.id, it.bookId, it.startMs, it.startMs + it.seconds * 1000L, it.manual, it.fromPos, it.toPos)
        }
        val covered = com.paperback.app.catalog.Coverage.covered(spans)
        _rawSessions.value = raw
        _sessions.value = raw.filter { it.id !in covered }
    }

    private val _collections = MutableStateFlow<List<BookCollection>>(emptyList())
    val collections: StateFlow<List<BookCollection>> = _collections.asStateFlow()

    /** collection id -> ids of the books in it */
    private val _membership = MutableStateFlow<Map<String, Set<String>>>(emptyMap())
    val membership: StateFlow<Map<String, Set<String>>> = _membership.asStateFlow()

    private val _allHighlights = MutableStateFlow<List<Highlight>>(emptyList())
    val allHighlights: StateFlow<List<Highlight>> = _allHighlights.asStateFlow()

    private val _allBookmarks = MutableStateFlow<List<Bookmark>>(emptyList())
    val allBookmarks: StateFlow<List<Bookmark>> = _allBookmarks.asStateFlow()

    private val booksDir = File(context.filesDir, "books").apply { mkdirs() }
    private val coversDir = File(context.filesDir, "covers").apply { mkdirs() }

    suspend fun refresh() = withContext(Dispatchers.IO) {
        _books.value = db.allBooks()
        publishSessions()
        _collections.value = db.allCollections()
        _membership.value = db.collectionMembers()
        _allHighlights.value = db.allHighlights()
        _allBookmarks.value = db.allBookmarks()
    }

    // ---- import ---------------------------------------------------------------------------

    suspend fun importBook(uri: Uri): ImportOutcome = withContext(Dispatchers.IO) {
        val name = displayName(uri) ?: "book.epub"
        val ext = name.substringAfterLast('.', "epub").lowercase().takeIf { it.length in 2..5 } ?: "epub"
        val tmp = File(context.cacheDir, "import-${System.nanoTime()}.$ext")
        val digest = MessageDigest.getInstance("SHA-256")

        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: return@withContext ImportOutcome.Failed(name)
            input.use { src ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = src.read(buf)
                        if (n < 0) break
                        digest.update(buf, 0, n)
                        out.write(buf, 0, n)
                    }
                }
            }
        } catch (e: Exception) {
            tmp.delete()
            return@withContext ImportOutcome.Failed(name)
        }

        val id = digest.digest().joinToString("") { "%02x".format(it) }
        finishImport(tmp, id, name, ext)
    }

    /**
     * Adds a book file that is already on this device (a Discover download). [file] is a temporary file: it is
     * moved into the library, or deleted when the book is a duplicate or can't be read.
     */
    suspend fun importFile(file: File, displayName: String, hints: ImportHints? = null): ImportOutcome = withContext(Dispatchers.IO) {
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            file.inputStream().use { src ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = src.read(buf)
                    if (n < 0) break
                    digest.update(buf, 0, n)
                }
            }
        } catch (e: Exception) {
            file.delete()
            return@withContext ImportOutcome.Failed(displayName)
        }
        val id = digest.digest().joinToString("") { "%02x".format(it) }
        val ext = displayName.substringAfterLast('.', "epub").lowercase().takeIf { it.length in 2..5 } ?: "epub"
        finishImport(file, id, displayName, ext, hints)
    }

    /**
     * Adds a catalog book to the library with no file: it can be rated, marked finished and given entries, but not
     * read. [pages] (0 = unknown) becomes its page count. Adding the same book twice does nothing.
     */
    suspend fun addLogOnly(cb: CatalogBook, pages: Int, tags: List<String>, cover: ByteArray?): String = withContext(Dispatchers.IO) {
        val key = cb.title.trim().lowercase() + "|" + cb.firstAuthor().lowercase()
        val id = "log-" + MessageDigest.getInstance("SHA-1").digest(key.toByteArray()).joinToString("") { "%02x".format(it) }.take(16)
        var coverPath: String? = null
        if (cover != null) {
            val bmp = runCatching { android.graphics.BitmapFactory.decodeByteArray(cover, 0, cover.size) }.getOrNull()
            if (bmp != null) {
                val file = File(coversDir, "$id.jpg")
                val ok = runCatching { file.outputStream().use { scaleDown(bmp, 480).compress(Bitmap.CompressFormat.JPEG, 88, it) } }.isSuccess
                if (ok) coverPath = file.path
            }
        }
        val added = db.insertBook(
            Book(
                id = id, title = cb.title, author = cb.author, language = "",
                filePath = "", coverPath = coverPath,
                addedAt = System.currentTimeMillis(), lastOpenedAt = 0L,
                progress = 0f, position = 0, totalPositions = 0, locatorJson = null,
                finished = false, favorite = false, rating = 0,
                tags = tags, published = if (cb.year > 0) cb.year.toString() else "", metaRead = true,
            ),
        )
        if (added && pages > 0) db.setCustomPages(id, pages)
        refresh()
        id
    }

    /**
     * Fills a book kept without a file from the catalog: cover, genres, description, year and page count. Only what is
     * still empty is filled; nothing you entered is replaced.
     */
    suspend fun applyCatalog(id: String, cb: CatalogBook?, details: com.paperback.app.data.catalog.CatalogDetails?, cover: ByteArray?, replaceCover: Boolean = false) = withContext(Dispatchers.IO) {
        val b = db.allBooks().firstOrNull { it.id == id && !it.hasFile } ?: return@withContext
        if ((b.coverPath == null || replaceCover) && cover != null) {
            val bmp = runCatching { android.graphics.BitmapFactory.decodeByteArray(cover, 0, cover.size) }.getOrNull()
            if (bmp != null) {
                // a new file name, so the old picture is not kept on screen from the image cache
                val file = File(coversDir, "$id-${System.currentTimeMillis()}.jpg")
                val ok = runCatching { file.outputStream().use { scaleDown(bmp, 480).compress(Bitmap.CompressFormat.JPEG, 88, it) } }.isSuccess
                if (ok) {
                    val old = b.coverPath
                    db.setCoverPath(id, file.path)
                    if (old != null && File(old).parentFile == coversDir) File(old).delete()
                }
            }
        }
        val tags = b.tags.ifEmpty { Tags.clean((cb?.subjects ?: emptyList()) + (details?.subjects ?: emptyList())) }
        val description = b.description.ifBlank { details?.description.orEmpty() }
        val published = b.published.ifBlank { if (cb != null && cb.year > 0) cb.year.toString() else "" }
        db.setMeta(id, BookExtras(tags, description, b.publisher, published))
        val pages = details?.pages ?: 0
        if (b.customPages == 0 && pages > 0) db.setCustomPages(id, pages)
        refresh()
    }

    /** A file was just added: if a book of the same title was kept without a file, everything you recorded moves to it. */
    private fun adoptLogOnly(newId: String, title: String, newCover: String?) {
        val old = db.allBooks().firstOrNull { !it.hasFile && it.id != newId && TitleKey.same(it.title, title) } ?: return
        db.adoptLogOnly(old, newId)
        val oldCover = old.coverPath ?: return
        if (newCover == null) db.setCoverPath(newId, oldCover) // the file has no cover of its own: keep the one you had
        else if (File(oldCover).parentFile == coversDir) File(oldCover).delete()
    }

    /** The part of an import that is the same for every source: duplicate check, move, read, store. */
    private suspend fun finishImport(tmp: File, id: String, name: String, ext: String, hints: ImportHints? = null): ImportOutcome {
        if (db.hasBook(id)) {
            tmp.delete()
            return ImportOutcome.Duplicate(name, id)
        }

        // A PDF is recognised by its first bytes, so a file without the right name still works.
        val isPdf = ext == "pdf" || PdfDoc.looksLikePdf(tmp)
        val dest = File(booksDir, "$id.${if (isPdf) "pdf" else ext}")
        if (!tmp.renameTo(dest)) {
            tmp.copyTo(dest, overwrite = true)
            tmp.delete()
        }
        if (isPdf) return finishPdfImport(dest, id, name)

        val publication = readium.open(dest)
        if (publication == null) {
            dest.delete()
            return ImportOutcome.Failed(name)
        }

        return try {
            if (!publication.conformsTo(Publication.Profile.EPUB)) {
                dest.delete()
                return ImportOutcome.Unsupported(name)
            }

            val title = publication.metadata.title?.takeIf { it.isNotBlank() }
                ?: name.substringBeforeLast('.')
            val author = publication.metadata.authors.joinToString(", ") { it.name }
            val language = publication.metadata.languages.firstOrNull() ?: ""
            val total = publication.positions().size
            val extras = epubExtras(publication, hints)

            val coverPath = publication.cover()?.let { bmp ->
                val file = File(coversDir, "$id.jpg")
                val scaled = scaleDown(bmp, 480)
                file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                file.path
            }

            db.insertBook(
                Book(
                    id = id, title = title, author = author, language = language,
                    filePath = dest.path, coverPath = coverPath,
                    addedAt = System.currentTimeMillis(), lastOpenedAt = 0L,
                    progress = 0f, position = 0, totalPositions = total, locatorJson = null,
                    finished = false, favorite = false, rating = 0,
                    tags = extras.tags, description = extras.description,
                    publisher = extras.publisher, published = extras.published, metaRead = true,
                ),
            )
            adoptLogOnly(id, title, coverPath)
            refresh()
            ImportOutcome.Added(title, id)
        } finally {
            publication.close()
        }
    }

    /**
     * Genres, description, publisher and date: from the EPUB's own details first, then from what the catalog said
     * (Project Gutenberg's EPUBs carry subjects but no summary; its catalog has the summary).
     */
    private fun epubExtras(publication: Publication, hints: ImportHints?): BookExtras {
        val m = publication.metadata
        val ownSubjects = runCatching { m.subjects.map { it.name } }.getOrDefault(emptyList())
        val tags = Tags.clean(ownSubjects + (hints?.subjects ?: emptyList()))
        val description = BookText.description(m.description).ifEmpty { BookText.description(hints?.description) }
        val publisher = runCatching { m.publishers.joinToString(", ") { it.name } }.getOrDefault("")
            .ifBlank { hints?.publisher?.trim().orEmpty() }
        val published = BookText.date(runCatching { m.published?.toString() }.getOrNull()).ifEmpty { BookText.date(hints?.published) }
        return BookExtras(tags, description, publisher, published)
    }

    /**
     * Books added before this version have no genres or description stored. Read them from the files once, quietly,
     * after the app starts. Books that can't be read are marked done too, so this never repeats.
     */
    suspend fun backfillMeta() = withContext(Dispatchers.IO) {
        var changed = false
        for (b in db.allBooks()) {
            if (b.metaRead) continue
            var extras = BookExtras(emptyList(), "", "", "")
            if (!b.isPdf) {
                val file = File(b.filePath)
                val publication = if (file.exists()) runCatching { readium.open(file) }.getOrNull() else null
                if (publication != null) {
                    try {
                        extras = epubExtras(publication, null)
                    } finally {
                        publication.close()
                    }
                }
            }
            db.setMeta(b.id, extras)
            changed = true
        }
        if (changed) refresh()
    }

    /** The PDF half of an import: page count and cover from the first page, title from the file name. */
    private suspend fun finishPdfImport(dest: File, id: String, name: String): ImportOutcome {
        val doc = PdfDoc.open(dest)
        if (doc == null) {
            dest.delete()
            return ImportOutcome.Failed(name)
        }
        return try {
            val title = PdfDoc.titleFromFileName(name)
            val coverPath = runCatching {
                val (pw, ph) = doc.pageSize(0)
                val w = 480
                val h = (w.toFloat() * ph / pw).toInt().coerceIn(200, 1400)
                val bmp = doc.render(0, w, h)
                val file = File(coversDir, "$id.jpg")
                file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                file.path
            }.getOrNull()
            db.insertBook(
                Book(
                    id = id, title = title, author = "", language = "",
                    filePath = dest.path, coverPath = coverPath,
                    addedAt = System.currentTimeMillis(), lastOpenedAt = 0L,
                    progress = 0f, position = 0, totalPositions = doc.pageCount, locatorJson = null,
                    finished = false, favorite = false, rating = 0,
                ),
            )
            adoptLogOnly(id, title, coverPath)
            refresh()
            ImportOutcome.Added(title, id)
        } finally {
            doc.close()
        }
    }

    /**
     * Makes a reflowable EPUB copy of a PDF and adds it to the library as a separate book. The PDF is not touched.
     * [onProgress] gets (pages read, total pages, whether the pages are being read by text recognition, which is slower
     * and happens when the PDF is a scan). Cancelling the calling coroutine stops the work.
     */
    suspend fun reflowPdf(book: Book, onProgress: (Int, Int, Boolean) -> Unit): ReflowOutcome = withContext(Dispatchers.IO) {
        val pdf = File(book.filePath)
        if (!pdf.exists()) return@withContext ReflowOutcome.Failed("The PDF file is missing.")
        val stamp = System.nanoTime()
        val work = File(context.cacheDir, "reflow-$stamp").apply { mkdirs() }
        val out = File(context.cacheDir, "reflow-$stamp.epub")
        val job = coroutineContext[Job]
        val meta = EpubWriter.Meta().apply {
            title = "${book.title} (EPUB)"
            author = book.author
            language = book.language.ifBlank { "en" }
            identifier = "urn:paperback:reflow:${book.id}"
            cover = book.coverPath?.let { File(it) }?.takeIf { it.exists() }
        }
        try {
            try {
                PdfReflower.convert(context, pdf, out, work, meta) { page, total ->
                    onProgress(page, total, false)
                    job?.isActive != false
                }
            } catch (e: NoTextException) {
                // a scan: the pages are pictures, so read them with text recognition instead
                out.delete()
                onProgress(0, book.totalPositions.coerceAtLeast(1), true)
                val pages = ReflowOcr.read(pdf) { page, total -> onProgress(page, total, true) }
                    ?: return@withContext ReflowOutcome.Failed("Couldn't read this PDF.")
                PdfReflower.convertRecognised(pages, DEFAULT_OCR_DPI, out, meta)
            }
        } catch (e: ReflowException) {
            out.delete()
            return@withContext ReflowOutcome.Failed(e.message ?: "This PDF can't be reflowed.")
        } catch (e: java.util.concurrent.CancellationException) {
            out.delete()
            throw e
        } catch (e: Throwable) {
            out.delete()
            return@withContext ReflowOutcome.Failed("Something went wrong while converting this PDF.")
        }
        val hints = ImportHints(subjects = book.tags, description = book.description.ifBlank { null })
        when (val r = importFile(out, "${book.title} (EPUB).epub", hints)) {
            is ImportOutcome.Added -> ReflowOutcome.Done(r.id, r.title)
            is ImportOutcome.Duplicate -> ReflowOutcome.Exists(r.id)
            else -> ReflowOutcome.Failed("The converted book couldn't be opened.")
        }
    }

    private companion object {
        const val DEFAULT_OCR_DPI = 230f
    }

    private fun displayName(uri: Uri): String? =
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()

    private fun scaleDown(bmp: Bitmap, maxSide: Int): Bitmap {
        val side = maxOf(bmp.width, bmp.height)
        if (side <= maxSide) return bmp
        val k = maxSide.toFloat() / side
        return Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
    }

    // ---- reading progress -----------------------------------------------------------------

    suspend fun markOpened(id: String) = withContext(Dispatchers.IO) {
        db.touchOpened(id, System.currentTimeMillis())
    }

    suspend fun saveProgress(id: String, locator: Locator) = withContext(Dispatchers.IO) {
        val progress = (locator.locations.totalProgression ?: 0.0).toFloat().coerceIn(0f, 1f)
        val position = locator.locations.position ?: 0
        db.updateProgress(id, locator.toJSON().toString(), progress, position, System.currentTimeMillis())
        if (progress >= 0.99f) db.setFinished(id, true)
    }

    /** PDF progress: [page] is 1-based. The first page is 0%, the last is 100%. */
    suspend fun savePdfProgress(id: String, page: Int, total: Int) = withContext(Dispatchers.IO) {
        val progress = pdfProgress(page, total)
        db.updateProgress(id, pdfLocatorJson(page, progress), progress, page, System.currentTimeMillis())
        if (progress >= 0.99f) db.setFinished(id, true)
    }

    suspend fun addPdfBookmark(bookId: String, page: Int, total: Int) = withContext(Dispatchers.IO) {
        val progress = pdfProgress(page, total)
        db.insertBookmark(
            Bookmark(
                id = UUID.randomUUID().toString(),
                bookId = bookId,
                locatorJson = pdfLocatorJson(page, progress),
                position = page,
                progress = progress,
                createdAt = System.currentTimeMillis(),
            ),
        )
    }

    private fun pdfProgress(page: Int, total: Int): Float =
        if (total > 1) ((page - 1f) / (total - 1f)).coerceIn(0f, 1f) else 1f

    /** A place in a PDF written the same way as a Readium locator, so bookmarks and backups treat it alike. */
    private fun pdfLocatorJson(page: Int, progress: Float): String =
        org.json.JSONObject()
            .put("href", "book.pdf")
            .put("type", "application/pdf")
            .put("locations", org.json.JSONObject().put("position", page).put("totalProgression", progress.toDouble()))
            .toString()

    suspend fun addSession(bookId: String, startMs: Long, seconds: Int, pages: Int, fromPos: Int = 0, toPos: Int = 0, kind: Int = SessionKind.READ) = withContext(Dispatchers.IO) {
        db.insertSession(bookId, startMs, seconds, pages, fromPos, toPos, kind = kind)
        _books.value = db.allBooks() // a first entry sets the book's start date
        publishSessions()
    }

    /** Saves the minutes goal for today (the goal changes the future, never the days already saved). */
    suspend fun recordGoalToday(minutes: Int) = withContext(Dispatchers.IO) {
        db.recordGoalDay(java.time.LocalDate.now().toEpochDay(), minutes)
    }

    /** Every finished reading of every book, and the goal saved for each day: what the history stats use. */
    suspend fun readings(): List<Reading> = withContext(Dispatchers.IO) { db.allReadings() }
    suspend fun goalDays(): Map<Long, Int> = withContext(Dispatchers.IO) { db.goalDays() }

    /** Pauses or drops a book (or puts it back with [BookStatus.NORMAL]), remembering the percent you had read. */
    suspend fun setStatus(bookId: String, status: Int) = withContext(Dispatchers.IO) {
        val b = _books.value.firstOrNull { it.id == bookId } ?: return@withContext
        db.setStatus(bookId, status, System.currentTimeMillis(), b.percent)
        _books.value = db.allBooks()
    }

    /** Where a book came from, how you read it, its series and word count. Null leaves a field as it is. */
    suspend fun setBookFacts(bookId: String, source: String? = null, format: String? = null, series: String? = null, seriesNo: Float? = null, words: Int? = null) = withContext(Dispatchers.IO) {
        db.setBookFacts(bookId, source, format, series, seriesNo, words)
        _books.value = db.allBooks()
    }

    /** Saves a reading entry made by hand or with the timer (id 0 = a new one) and reloads the history. */
    suspend fun saveEntry(id: Long, bookId: String, startMs: Long, seconds: Int, pages: Int, fromPos: Int, toPos: Int) = withContext(Dispatchers.IO) {
        if (id == 0L) db.insertSession(bookId, startMs, seconds, pages, fromPos, toPos, manual = true)
        else db.updateSession(id, startMs, seconds, pages, fromPos, toPos)
        _books.value = db.allBooks()
        publishSessions()
        moveForward(bookId, toPos, startMs + seconds * 1000L)
    }

    /**
     * Pages logged in an entry or with the timer move the book forward too, the same as reading it in Paperback
     * would. Never backwards: an old entry added later does not undo where you are. [page] is in the page count that applies.
     */
    private fun moveForward(bookId: String, page: Int, atMs: Long = 0L) {
        if (page <= 0) return
        val book = _books.value.firstOrNull { it.id == bookId } ?: return
        val total = book.pageCount
        if (total <= 0 || page <= book.currentPage) return
        val progress = com.paperback.app.catalog.PageMath.progressForPage(page, total).toFloat()
        val position = com.paperback.app.catalog.PageMath.positionFor(page, total, book.totalPositions)
        db.setPlace(bookId, progress, position)
        if (page >= total) {
            db.setFinished(bookId, true)
            // the book was finished when this entry ended, not when it was typed in
            if (!book.finished && atMs > 0L) db.setFinishedAt(bookId, atMs)
        }
        _books.value = db.allBooks()
    }

    /** Sets the page you are on by hand (in the page count that applies). 0 = not started. */
    suspend fun setCurrentPage(id: String, page: Int) = withContext(Dispatchers.IO) {
        val book = _books.value.firstOrNull { it.id == id } ?: return@withContext
        val total = book.pageCount
        val p = if (total > 0) page.coerceIn(0, total) else page.coerceAtLeast(0)
        val progress = com.paperback.app.catalog.PageMath.progressForPage(p, total).toFloat()
        db.setPlace(id, progress, com.paperback.app.catalog.PageMath.positionFor(p, total, book.totalPositions))
        if (total > 0 && p >= total) db.setFinished(id, true)
        refresh()
    }

    suspend fun deleteEntry(id: Long) = withContext(Dispatchers.IO) {
        db.deleteSession(id)
        publishSessions()
    }

    // ---- bookmarks, highlights, notes -----------------------------------------------------

    suspend fun bookmarks(bookId: String): List<Bookmark> = withContext(Dispatchers.IO) { db.bookmarksFor(bookId) }

    suspend fun addBookmark(bookId: String, locator: Locator) = withContext(Dispatchers.IO) {
        db.insertBookmark(
            Bookmark(
                id = UUID.randomUUID().toString(),
                bookId = bookId,
                locatorJson = locator.toJSON().toString(),
                position = locator.locations.position ?: 0,
                progress = (locator.locations.totalProgression ?: 0.0).toFloat(),
                createdAt = System.currentTimeMillis(),
            ),
        )
    }

    suspend fun removeBookmark(id: String) = withContext(Dispatchers.IO) { db.deleteBookmark(id) }

    suspend fun highlights(bookId: String): List<Highlight> = withContext(Dispatchers.IO) { db.highlightsFor(bookId) }

    suspend fun addHighlight(bookId: String, locator: Locator, text: String, note: String, color: Int) =
        withContext(Dispatchers.IO) {
            db.insertHighlight(
                Highlight(
                    id = UUID.randomUUID().toString(),
                    bookId = bookId,
                    locatorJson = locator.toJSON().toString(),
                    text = text,
                    note = note,
                    color = color,
                    progress = (locator.locations.totalProgression ?: 0.0).toFloat(),
                    createdAt = System.currentTimeMillis(),
                ),
            )
        }

    suspend fun updateHighlight(id: String, note: String, color: Int) = withContext(Dispatchers.IO) {
        db.updateHighlight(id, note, color)
    }

    suspend fun removeHighlight(id: String) = withContext(Dispatchers.IO) { db.deleteHighlight(id) }

    // ---- shelf actions --------------------------------------------------------------------

    suspend fun setFavorite(id: String, value: Boolean) = withContext(Dispatchers.IO) {
        db.setFlag(id, "favorite", value)
        refresh()
    }

    suspend fun setFinished(id: String, value: Boolean) = withContext(Dispatchers.IO) {
        db.setFinished(id, value)
        refresh()
    }

    suspend fun setRating(id: String, stars: Int) = withContext(Dispatchers.IO) {
        db.setRating(id, stars)
        refresh()
    }

    /** Saves everything from the Edit book page, in an order that keeps the page maths right. */
    suspend fun applyEdits(id: String, e: BookEdits) = withContext(Dispatchers.IO) {
        db.setDetails(id, e.title.trim().ifEmpty { _books.value.firstOrNull { it.id == id }?.title.orEmpty() }, e.author.trim(), e.description.trim(), e.publisher.trim(), e.published.trim(), e.tags, e.language.trim())
        db.setCustomPages(id, e.customPages)
        db.setSpineColor(id, e.spineColor)
        db.setBookFacts(id, format = e.format, series = e.series, seriesNo = e.seriesNo, words = e.words)
        _books.value = db.allBooks()
        e.currentPage?.let { page ->
            val book = _books.value.firstOrNull { it.id == id }
            if (book != null) {
                val total = book.pageCount
                val p = if (total > 0) page.coerceIn(0, total) else page.coerceAtLeast(0)
                val progress = com.paperback.app.catalog.PageMath.progressForPage(p, total).toFloat()
                db.setPlace(id, progress, com.paperback.app.catalog.PageMath.positionFor(p, total, book.totalPositions))
                if (total > 0 && p >= total) db.setFinished(id, true)
            }
        }
        refresh()
        e.shelfPosition?.let { pos ->
            val ordered = BookSort.Custom.apply(_books.value).map { it.id }.toMutableList()
            if (ordered.remove(id)) {
                ordered.add((pos - 1).coerceIn(0, ordered.size), id)
                db.setShelfOrders(ordered)
                refresh()
            }
        }
    }

    /** [value] is on the 0..10 scale. */
    suspend fun setRating10(id: String, value: Double) = withContext(Dispatchers.IO) {
        db.setRating10(id, value)
        refresh()
    }

    suspend fun setDetails(id: String, title: String, author: String, description: String, publisher: String, published: String, tags: List<String>, language: String) =
        withContext(Dispatchers.IO) {
            db.setDetails(id, title.trim(), author.trim(), description.trim(), publisher.trim(), published.trim(), tags, language.trim())
            refresh()
        }

    suspend fun setCustomPages(id: String, pages: Int) = withContext(Dispatchers.IO) {
        db.setCustomPages(id, pages)
        refresh()
    }

    suspend fun setSpineColor(id: String, argb: Int) = withContext(Dispatchers.IO) {
        db.setSpineColor(id, argb)
        refresh()
    }

    /** A picture from the phone becomes the cover. Returns false when it can't be read as an image. */
    suspend fun setCover(id: String, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        val bmp = runCatching {
            context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
        }.getOrNull() ?: return@withContext false
        val file = File(coversDir, "$id-${System.currentTimeMillis()}.jpg")
        val ok = runCatching {
            val scaled = scaleDown(bmp, 720)
            file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        }.isSuccess
        if (!ok) return@withContext false
        val old = _books.value.firstOrNull { it.id == id }?.coverPath
        db.setCoverPath(id, file.path)
        if (old != null && File(old).parentFile == coversDir) File(old).delete()
        refresh()
        true
    }

    /** Puts the book at place [position] (1 = first) in "My order", and numbers the others around it. */
    suspend fun setShelfPosition(id: String, position: Int) = withContext(Dispatchers.IO) {
        val ordered = com.paperback.app.data.BookSort.Custom.apply(_books.value).map { it.id }.toMutableList()
        if (!ordered.remove(id)) return@withContext
        ordered.add((position - 1).coerceIn(0, ordered.size), id)
        db.setShelfOrders(ordered)
        refresh()
    }

    suspend fun setJournal(id: String, text: String) = withContext(Dispatchers.IO) {
        db.setJournal(id, text)
        refresh()
    }

    // ---- collections ----------------------------------------------------------------------

    suspend fun createCollection(name: String) = withContext(Dispatchers.IO) {
        db.upsertCollection(BookCollection(UUID.randomUUID().toString(), name.trim(), System.currentTimeMillis()))
        refresh()
    }

    suspend fun renameCollection(c: BookCollection, name: String) = withContext(Dispatchers.IO) {
        db.upsertCollection(c.copy(name = name.trim()))
        refresh()
    }

    suspend fun deleteCollection(id: String) = withContext(Dispatchers.IO) {
        db.deleteCollection(id)
        refresh()
    }

    suspend fun setMember(collectionId: String, bookId: String, member: Boolean) = withContext(Dispatchers.IO) {
        db.setMember(collectionId, bookId, member)
        refresh()
    }

    // ---- notes across books ---------------------------------------------------------------

    suspend fun deleteHighlight(id: String) = withContext(Dispatchers.IO) {
        db.deleteHighlight(id)
        refresh()
    }

    suspend fun deleteBookmark(id: String) = withContext(Dispatchers.IO) {
        db.deleteBookmark(id)
        refresh()
    }

    suspend fun remove(book: Book) = withContext(Dispatchers.IO) {
        db.deleteBook(book.id)
        File(book.filePath).delete()
        book.coverPath?.let { File(it).delete() }
        refresh()
    }
}
