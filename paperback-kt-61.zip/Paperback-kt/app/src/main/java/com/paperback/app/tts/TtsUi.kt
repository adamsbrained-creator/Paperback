package com.paperback.app.tts

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.reader.ReaderColors
import com.paperback.app.reader.readerColors
import com.paperback.app.ui.PbIcon
import com.paperback.app.ui.PbIconName
import com.paperback.app.ui.PbSlider
import com.paperback.app.ui.theme.PbSerif

/** Where the sheet is: the player itself, or one of the pages it opens. */
private enum class SheetView { Main, Speed, Voice, Timer, Offline }

/** The sleep timer's choices, same list as the TypeScript player (getTTSTimeoutOptions). */
private val TIMER_OPTIONS = listOf(
    "No timeout" to 0,
    "End of chapter" to SLEEP_END_OF_CHAPTER,
    "1 minute" to 60,
    "3 minutes" to 180,
    "5 minutes" to 300,
    "10 minutes" to 600,
    "20 minutes" to 1200,
    "30 minutes" to 1800,
    "45 minutes" to 2700,
    "1 hour" to 3600,
    "2 hours" to 7200,
    "3 hours" to 10800,
    "4 hours" to 14400,
    "6 hours" to 21600,
    "8 hours" to 28800,
)

private fun clock(seconds: Int): String {
    val s = seconds.coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

/**
 * Everything the read-aloud feature draws over the reader: the mini player, the full player sheet and the
 * "Back to Read Aloud" button. Does nothing while no session is running for this book.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TtsOverlay(bookId: String, themeIndex: Int, chromeVisible: Boolean, modifier: Modifier = Modifier) {
    val session = TtsHub.session
    if (session == null || session.book.bookId != bookId || !session.active) return
    val c = readerColors(themeIndex)
    Box(modifier.fillMaxSize()) {
        if (!session.following && !session.sheetOpen) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .padding(top = if (chromeVisible) 76.dp else 12.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(c.card)
                    .clickable { session.followAgain() }
                    .padding(horizontal = 18.dp, vertical = 11.dp),
            ) { Text("Back to Read Aloud", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
        }
        if (session.sheetOpen) {
            TtsSheet(session, c)
        } else {
            TtsMiniPlayer(
                session, c,
                Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .padding(start = 16.dp, end = 16.dp, bottom = if (chromeVisible) 236.dp else 16.dp),
            )
        }
    }
}

// ---- the mini player ------------------------------------------------------------------------------------

@Composable
private fun TtsMiniPlayer(s: TtsSession, c: ReaderColors, modifier: Modifier) {
    val accent = MaterialTheme.colorScheme.primary
    val (at, total) = s.timeInfo()
    val cover = remember(s.book.bookId) { s.coverBitmap() }
    val label = buildString {
        append(s.chapterTitle)
        if (total > 0) append(" · ${clock(at)} · -${clock(total - at)}")
    }
    Box(modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(c.card)) {
        if (s.prefs.playerStyle == "minimal") {
            Row(
                Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    TtsPrefs.formatRate(s.rate), color = c.ink.copy(alpha = 0.75f), fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(52.dp).clickable { s.sheetOpen = true }.padding(vertical = 12.dp), textAlign = TextAlign.Center,
                )
                TransportIcon(PbIconName.DoubleLeft, c, 24.dp, "Previous paragraph") { s.stepParagraph(-1) }
                TransportIcon(PbIconName.CaretLeft, c, 24.dp, "Previous sentence") { s.stepSentence(-1) }
                PlayButton(s, c, accent, 40.dp)
                TransportIcon(PbIconName.CaretRight, c, 24.dp, "Next sentence") { s.stepSentence(1) }
                TransportIcon(PbIconName.DoubleRight, c, 24.dp, "Next paragraph") { s.stepParagraph(1) }
                Text(
                    if (total > 0) "-" + clock(total - at) else "", color = c.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(52.dp).clickable { s.sheetOpen = true }.padding(vertical = 12.dp), textAlign = TextAlign.Center,
                )
            }
        } else {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { s.sheetOpen = true },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (cover != null) {
                        Image(
                            cover.asImageBitmap(), null,
                            Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop,
                        )
                        Spacer(Modifier.width(10.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(s.book.title, color = c.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            s.notice ?: label, color = c.ink.copy(alpha = 0.7f), fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                if (s.sleepFiresAt > 0L) {
                    Text(sleepLabel(s), color = c.ink.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp))
                }
                TransportIcon(PbIconName.SkipPrev, c, 26.dp, "Previous sentence") { s.stepSentence(-1) }
                PlayButton(s, c, accent, 40.dp)
                TransportIcon(PbIconName.SkipNext, c, 26.dp, "Next sentence") { s.stepSentence(1) }
                TransportIcon(PbIconName.Close, c, 20.dp, "Stop reading aloud") { s.stop() }
            }
        }
        // a thin progress line along the bottom edge
        Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(c.ink.copy(alpha = 0.12f))) {
            val f = if (total > 0) (at.toFloat() / total).coerceIn(0f, 1f) else 0f
            Box(Modifier.fillMaxWidth(f).fillMaxHeight().background(accent))
        }
    }
}

@Composable
private fun sleepLabel(s: TtsSession): String {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(s.sleepFiresAt) {
        while (s.sleepFiresAt > 0L) {
            now = System.currentTimeMillis()
            kotlinx.coroutines.delay(1000)
        }
    }
    val left = ((s.sleepFiresAt - now) / 1000).toInt()
    return if (left > 0) clock(left) else ""
}

@Composable
private fun TransportIcon(icon: PbIconName, c: ReaderColors, size: androidx.compose.ui.unit.Dp, description: String, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        PbIcon(icon, size = size, tint = c.ink, strokeWidth = 2.1f, contentDescription = description)
    }
}

/** The round play / pause button; it shows a spinning ring while the voice is still getting the sentence ready. */
@Composable
private fun PlayButton(s: TtsSession, c: ReaderColors, accent: Color, size: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(accent).clickable { s.togglePlay() },
        contentAlignment = Alignment.Center,
    ) {
        PbIcon(
            if (s.playing) PbIconName.Pause else PbIconName.Play,
            size = size * 0.5f, tint = MaterialTheme.colorScheme.onPrimary, filled = true,
            contentDescription = if (s.playing) "Pause" else "Play",
        )
        if (s.playing && s.buffering) {
            androidx.compose.material3.CircularProgressIndicator(
                modifier = Modifier.size(size - 4.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary,
            )
        }
    }
}

// ---- the player sheet -----------------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TtsSheet(s: TtsSession, c: ReaderColors) {
    var view by remember { mutableStateOf(SheetView.Main) }
    val close = { s.sheetOpen = false }
    BackHandler { if (view == SheetView.Main) close() else view = SheetView.Main }
    LaunchedEffect(Unit) {
        s.loadSystemVoices()
        s.loadCustomVoices()
    }
    val screenHeight = androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { close() },
    ) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                // the player is tall; the pages it opens are only as tall as they need to be (up to 72% of the screen)
                .then(
                    if (view == SheetView.Main) Modifier.fillMaxHeight(0.84f)
                    else Modifier.heightIn(max = (screenHeight * 0.72f).dp),
                )
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(c.card)
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
                .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                .padding(horizontal = 18.dp, vertical = 10.dp),
        ) {
            // the grab bar
            Box(Modifier.align(Alignment.CenterHorizontally).width(40.dp).height(4.dp).clip(CircleShape).background(c.ink.copy(alpha = 0.25f)))
            Spacer(Modifier.height(8.dp))
            when (view) {
                SheetView.Main -> MainView(s, c, onView = { view = it }, onClose = close)
                SheetView.Speed -> SubPage("Speed", c, { view = SheetView.Main }) { SpeedView(s, c) }
                SheetView.Voice -> SubPage("Select voice", c, { view = SheetView.Main }) { VoiceView(s, c) { view = SheetView.Main } }
                SheetView.Timer -> SubPage("Set timeout", c, { view = SheetView.Main }) { TimerView(s, c) { view = SheetView.Main } }
                SheetView.Offline -> SubPage("Offline audio", c, { view = SheetView.Main }) { OfflineView(s, c) }
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.ColumnScope.SubPage(title: String, c: ReaderColors, onBack: () -> Unit, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
        TransportIcon(PbIconName.CaretLeft, c, 22.dp, "Back", onBack)
        Text(title, color = c.ink, fontFamily = PbSerif, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(start = 4.dp))
    }
    Column(Modifier.fillMaxWidth().weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(top = 8.dp, bottom = 16.dp)) { content() }
}

@Composable
private fun androidx.compose.foundation.layout.ColumnScope.MainView(s: TtsSession, c: ReaderColors, onView: (SheetView) -> Unit, onClose: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    val cover = remember(s.book.bookId) { s.coverBitmap() }
    val (at, total) = s.timeInfo()

    // book, chapter and the A− / A+ buttons of the sentence view
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (cover != null) {
            Image(cover.asImageBitmap(), null, Modifier.height(48.dp).width(34.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(s.book.title, color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.notice ?: s.chapterTitle, color = c.ink.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        val canDown = s.prefs.lyricSize > 0
        val canUp = s.prefs.lyricSize < TtsPrefs.LYRIC_SIZES.lastIndex
        Text(
            "A−", color = c.ink.copy(alpha = if (canDown) 0.8f else 0.25f), fontSize = 20.sp,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(enabled = canDown) { s.prefs.setLyricSize(s.prefs.lyricSize - 1) }.padding(horizontal = 10.dp, vertical = 6.dp),
        )
        Text(
            "A+", color = c.ink.copy(alpha = if (canUp) 0.8f else 0.25f), fontSize = 20.sp,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(enabled = canUp) { s.prefs.setLyricSize(s.prefs.lyricSize + 1) }.padding(horizontal = 10.dp, vertical = 6.dp),
        )
    }
    Spacer(Modifier.height(6.dp))

    LyricsView(s, c, Modifier.weight(1f).fillMaxWidth())

    // scrubber
    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (total > 0) (at.toFloat() / total).coerceIn(0f, 1f) else 0f
    PbSlider(
        value = drag ?: fraction,
        onValueChange = { drag = it },
        onValueChangeFinished = { drag?.let { s.seekFraction(it) }; drag = null },
        trackColor = c.ink.copy(alpha = 0.15f),
        modifier = Modifier.padding(top = 6.dp),
    )
    val shown = ((drag ?: fraction) * total).toInt()
    Row(Modifier.fillMaxWidth()) {
        Text(clock(shown), color = c.ink.copy(alpha = 0.75f), fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text("-" + clock(total - shown), color = c.ink.copy(alpha = 0.75f), fontSize = 12.sp)
    }

    // transport
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        ModeButton(PbIconName.PauseAfter, s.prefs.pauseAfterSentence, c, "Pause after each sentence") { s.prefs.setPauseAfterSentence(!s.prefs.pauseAfterSentence) }
        TransportIcon(PbIconName.DoubleLeft, c, 24.dp, "Previous paragraph") { s.stepParagraph(-1) }
        TransportIcon(PbIconName.CaretLeft, c, 28.dp, "Previous sentence") { s.stepSentence(-1) }
        PlayButton(s, c, accent, 56.dp)
        TransportIcon(PbIconName.CaretRight, c, 28.dp, "Next sentence") { s.stepSentence(1) }
        TransportIcon(PbIconName.DoubleRight, c, 24.dp, "Next paragraph") { s.stepParagraph(1) }
        val loopLabel = when (s.loopState) {
            LoopState.Off -> "A-B"
            LoopState.A -> "A-"
            LoopState.B -> "A-B"
        }
        Box(
            Modifier.size(width = 44.dp, height = 36.dp).clip(RoundedCornerShape(18.dp))
                .background(if (s.loopState == LoopState.Off) Color.Transparent else c.chip)
                .clickable { s.toggleLoop() },
            contentAlignment = Alignment.Center,
        ) {
            Text(loopLabel, color = c.ink.copy(alpha = if (s.loopState == LoopState.Off) 0.6f else 1f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }

    // speed / voice / timer
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Tile(c, Modifier.weight(1f), { onView(SheetView.Speed) }, "Speed") {
            Text(TtsPrefs.formatRate(s.rate), color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Tile(c, Modifier.weight(1f), { onView(SheetView.Voice) }, s.voice?.name ?: "Voice") {
            PbIcon(PbIconName.Voice, size = 18.dp, tint = c.ink)
        }
        Tile(
            c, Modifier.weight(1f), { onView(SheetView.Timer) },
            when {
                s.sleepOption == SLEEP_END_OF_CHAPTER -> "End of chapter"
                s.sleepFiresAt > 0L -> sleepLabel(s)
                else -> "Sleep timer"
            },
        ) { PbIcon(PbIconName.Alarm, size = 18.dp, tint = c.ink) }
    }

    // offline audio (Edge voices only: the phone's voices already work offline)
    val edge = s.voice?.id?.startsWith(SYSTEM_PREFIX) == false
    if (edge) {
        LaunchedEffect(s.voice?.id) { s.refreshDownloads() }
        val rows = s.downloadRows
        val done = rows.count { s.downloads[it.first]?.complete == true }
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(16.dp)).background(c.chip)
                .clickable { onView(SheetView.Offline) }.padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PbIcon(PbIconName.ImportFile, size = 22.dp, tint = c.ink)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Offline Audio", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("$done of ${rows.size} downloaded", color = c.ink.copy(alpha = 0.65f), fontSize = 12.sp)
            }
            PbIcon(PbIconName.CaretRight, size = 18.dp, tint = c.ink)
        }
    }
}

@Composable
private fun ModeButton(icon: PbIconName, on: Boolean, c: ReaderColors, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 40.dp, height = 36.dp).clip(RoundedCornerShape(18.dp)).background(if (on) c.chip else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { PbIcon(icon, size = 20.dp, tint = c.ink.copy(alpha = if (on) 1f else 0.6f), contentDescription = description) }
}

@Composable
private fun Tile(c: ReaderColors, modifier: Modifier, onClick: () -> Unit, caption: String, top: @Composable () -> Unit) {
    Column(
        modifier.height(56.dp).clip(RoundedCornerShape(14.dp)).background(c.chip).clickable(onClick = onClick).padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        top()
        Text(caption, color = c.ink.copy(alpha = 0.65f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ---- the sentence view -----------------------------------------------------------------------------------

/** The chapter as a list of sentences, the one being said in a card; tap a sentence to read from there. */
@Composable
private fun LyricsView(s: TtsSession, c: ReaderColors, modifier: Modifier) {
    val lines = s.lines
    val active = s.sentenceIndex
    val state = rememberLazyListState()
    val size = TtsPrefs.LYRIC_SIZES[s.prefs.lyricSize.coerceIn(0, TtsPrefs.LYRIC_SIZES.lastIndex)]
    val loop = s.loopRange()
    LaunchedEffect(active, lines.size) {
        if (active in lines.indices) {
            // keep the sentence being said a little below the top, with the next ones visible under it
            val target = (active - 2).coerceAtLeast(0)
            if (state.layoutInfo.totalItemsCount == 0) state.scrollToItem(target) else state.animateScrollToItem(target)
        }
    }
    LazyColumn(modifier, state = state, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        itemsIndexed(lines) { i, line ->
            val on = i == active
            val inLoop = loop != null && i in loop
            Text(
                line,
                color = c.ink.copy(alpha = if (on) 1f else 0.5f),
                fontSize = size.sp,
                lineHeight = (size * 1.35f).sp,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (on) c.chip else if (inLoop) c.chip.copy(alpha = 0.5f) else Color.Transparent)
                    .clickable { s.playFrom(i) }
                    .padding(horizontal = 14.dp, vertical = if (on) 10.dp else 5.dp),
            )
        }
    }
}

// ---- speed, voice, sleep timer, offline audio ---------------------------------------------------------------

@Composable
private fun SpeedView(s: TtsSession, c: ReaderColors) {
    Text(TtsPrefs.formatRate(s.rate), color = c.ink, fontSize = 40.sp, fontFamily = PbSerif, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    PbSlider(
        value = s.rate,
        onValueChange = { s.setRate(it) },
        valueRange = TtsPrefs.SPEED_MIN..TtsPrefs.SPEED_MAX,
        trackColor = c.ink.copy(alpha = 0.15f),
        modifier = Modifier.padding(vertical = 12.dp),
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        listOf(0.5f, 1.0f, 1.5f, 2.0f, 2.5f, 3.0f).forEach { Text(String.format("%.1f", it), color = c.ink.copy(alpha = 0.6f), fontSize = 12.sp) }
    }
    Spacer(Modifier.height(16.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { preset ->
            val on = kotlin.math.abs(s.rate - preset) < 0.01f
            Text(
                TtsPrefs.formatRate(preset),
                color = if (on) MaterialTheme.colorScheme.onPrimary else c.ink,
                fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                    .background(if (on) MaterialTheme.colorScheme.primary else c.chip)
                    .clickable { s.setRate(preset) }.padding(vertical = 10.dp),
            )
        }
    }
}

@Composable
private fun VoiceView(s: TtsSession, c: ReaderColors, done: () -> Unit) {
    val groups = s.voiceGroups()
    val current = s.voice?.id
    for (g in groups) {
        Text(
            "${g.name}: ${g.voices.size} voices", color = c.ink.copy(alpha = 0.6f), fontSize = 13.sp,
            modifier = Modifier.padding(start = 4.dp, top = 12.dp, bottom = 4.dp),
        )
        for (v in g.voices) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { s.setVoice(v); done() }.padding(horizontal = 4.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
                    if (v.id == current) PbIcon(PbIconName.Check, size = 20.dp, tint = MaterialTheme.colorScheme.primary)
                }
                Text(v.name, color = c.ink, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                val badge = when (v.variant) { "multilingual" -> "Multilingual"; "expressive" -> "Expressive"; else -> null }
                if (badge != null) {
                    Text(badge, color = c.ink.copy(alpha = 0.7f), fontSize = 11.sp, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(c.chip).padding(horizontal = 8.dp, vertical = 3.dp))
                }
            }
        }
    }
    if (groups.isEmpty()) Text("No voices for this language.", color = c.ink.copy(alpha = 0.7f), fontSize = 14.sp, modifier = Modifier.padding(8.dp))
}

@Composable
private fun TimerView(s: TtsSession, c: ReaderColors, done: () -> Unit) {
    for ((label, value) in TIMER_OPTIONS) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { s.setSleep(value); done() }.padding(horizontal = 4.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
                if (s.sleepOption == value) PbIcon(PbIconName.Check, size = 20.dp, tint = MaterialTheme.colorScheme.primary)
            }
            Text(label, color = c.ink, fontSize = 16.sp, modifier = Modifier.padding(start = 6.dp))
        }
    }
}

@Composable
private fun OfflineView(s: TtsSession, c: ReaderColors) {
    LaunchedEffect(s.voice?.id) { s.refreshDownloads() }
    val rows = s.downloadRows
    Text(
        "Download a chapter and it plays without internet, in the same voice. Chapters you listen to are also kept for a while (Settings → Read aloud).",
        color = c.ink.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp),
    )
    if (s.voice?.id?.startsWith(CUSTOM_PREFIX) == true) {
        Text(
            "This voice is your own service: a download sends every sentence of the chapter to it, and it may charge for that.",
            color = c.ink.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp),
        )
    }
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "Download all", color = c.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(c.chip).clickable { s.downloadAll() }.padding(horizontal = 14.dp, vertical = 9.dp),
        )
        Text(
            "Stop", color = c.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(c.chip).clickable { s.cancelDownloads() }.padding(horizontal = 14.dp, vertical = 9.dp),
        )
    }
    for ((index, title) in rows) {
        val st = s.downloads[index]
        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    title, color = if (index == s.chapterIndex) MaterialTheme.colorScheme.primary else c.ink, fontSize = 15.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    when {
                        st == null -> "…"
                        st.complete -> "Downloaded"
                        st.running -> "Downloading ${st.done} / ${st.total}"
                        st.done > 0 -> "${st.done} / ${st.total} sentences"
                        else -> "${st.total} sentences"
                    },
                    color = c.ink.copy(alpha = 0.6f), fontSize = 12.sp,
                )
            }
            val label = when {
                st == null -> null
                st.running -> null
                st.complete -> "Delete"
                else -> "Download"
            }
            if (label != null) {
                Text(
                    label, color = c.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(c.chip)
                        .clickable { if (st?.complete == true) s.deleteDownload(index) else s.downloadChapter(index) }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
    }
}
