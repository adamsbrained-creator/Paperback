package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.GoalStyle
import com.paperback.app.ui.theme.PbSerif

/** The daily goal on Stats -> Activity, drawn in the look chosen in Settings -> App style. */
@Composable
fun GoalMeter(
    style: GoalStyle,
    fraction: Float,
    readMinutes: Int,
    goalMinutes: Int,
    book: Book?,
    modifier: Modifier = Modifier,
) {
    val f = fraction.coerceIn(0f, 1f)
    when {
        style == GoalStyle.Cover && book != null -> GoalCover(f, readMinutes, goalMinutes, book, modifier)
        style == GoalStyle.Bar -> GoalBar(f, readMinutes, goalMinutes, modifier)
        else -> GoalRing(f, readMinutes, goalMinutes, modifier)
    }
}

/** A closed ring that fills clockwise from the top, with a soft glow once the goal is reached. */
@Composable
private fun GoalRing(fraction: Float, readMinutes: Int, goalMinutes: Int, modifier: Modifier) {
    val t = pbTokens()
    val coral = MaterialTheme.colorScheme.primary
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
                val sw = size.width * 0.085f
                val inset = sw
                val arc = Size(size.width - 2 * inset, size.height - 2 * inset)
                val topLeft = Offset(inset, inset)
                drawArc(t.ink.copy(alpha = 0.08f), 0f, 360f, false, topLeft, arc, style = Stroke(sw))
                if (fraction >= 1f) {
                    drawArc(coral.copy(alpha = 0.22f), -90f, 360f, false, topLeft, arc, style = Stroke(sw * 1.7f))
                }
                if (fraction > 0f) {
                    drawArc(coral, -90f, 360f * fraction, false, topLeft, arc, style = Stroke(sw, cap = StrokeCap.Round))
                } else {
                    drawCircle(coral, sw / 2f, Offset(size.width / 2f, inset))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$readMinutes", color = t.ink, fontFamily = PbSerif, fontSize = 46.sp, fontWeight = FontWeight.Medium)
                Text("of $goalMinutes min today", color = t.setSub, fontSize = 13.sp)
            }
        }
    }
}

/** One wide rounded bar, with the minutes above it. */
@Composable
private fun GoalBar(fraction: Float, readMinutes: Int, goalMinutes: Int, modifier: Modifier) {
    val t = pbTokens()
    val coral = MaterialTheme.colorScheme.primary
    Column(modifier.fillMaxWidth().padding(top = 6.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("$readMinutes", color = t.ink, fontFamily = PbSerif, fontSize = 46.sp, fontWeight = FontWeight.Medium)
            Text(
                " of $goalMinutes min today",
                color = t.setSub, fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 9.dp),
            )
        }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(22.dp)
                .clip(RoundedCornerShape(50))
                .background(t.ink.copy(alpha = 0.08f)),
        ) {
            if (fraction > 0f) {
                Box(
                    Modifier
                        .fillMaxWidth(fraction.coerceAtLeast(0.04f))
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(50))
                        .background(coral),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0", color = t.setSub, fontSize = 11.sp)
            Text("${goalMinutes}m", color = t.setSub, fontSize = 11.sp)
        }
    }
}

/** The cover of the book you read today, shaded at the top and lit from the bottom up as the goal fills. */
@Composable
private fun GoalCover(fraction: Float, readMinutes: Int, goalMinutes: Int, book: Book, modifier: Modifier) {
    val t = pbTokens()
    val shape = RoundedCornerShape(12.dp)
    Row(modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(120.dp).aspectRatio(2f / 3f)) {
            CoverFill(book, shape, Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            if (fraction < 1f) {
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth()
                        .fillMaxHeight(1f - fraction)
                        .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                        .background(Color.Black.copy(alpha = 0.72f)),
                )
            }
        }
        Spacer(Modifier.width(20.dp))
        Column(Modifier.weight(1f)) {
            Text("$readMinutes", color = t.ink, fontFamily = PbSerif, fontSize = 46.sp, fontWeight = FontWeight.Medium)
            Text("of $goalMinutes min today", color = t.setSub, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Text(book.title, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}
