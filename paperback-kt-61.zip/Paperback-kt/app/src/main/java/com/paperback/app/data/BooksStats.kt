package com.paperback.app.data

import java.time.ZoneId
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/*
 * Everything the Stats -> Books page shows, and the shelves it opens (Languages, Ratings, Epic books), as plain
 * functions over the library list. A port of the TypeScript app's booksStats.ts and shelfStats.ts.
 *
 * Differences from the TypeScript app: ratings are stored on the book here (not in a separate table), the page
 * count of a book is the one the book shows (its own count or the one you set), and "newest" is the book last
 * opened or added.
 */

/** "Neil Gaiman; Terry Pratchett" and "A & B" count as two authors. */
fun splitAuthors(raw: String): List<String> =
    raw.split(Regex(";|\\s&\\s|\\sand\\s", RegexOption.IGNORE_CASE)).map { it.trim() }.filter { it.isNotEmpty() }

/** "ru" -> "Russian", "en-GB" -> "English"; "" when there is no language. */
fun languageName(code: String): String {
    val base = code.trim().lowercase().split('-', '_').firstOrNull().orEmpty()
    if (base.isEmpty()) return ""
    val name = Locale.forLanguageTag(base).getDisplayLanguage(Locale.ENGLISH)
    return if (name.isBlank()) base else name
}

/** Your rating as 1..5 stars, 0 when the book is not rated. */
fun ratingStars(b: Book): Int = when {
    b.rating in 1..5 -> b.rating
    b.rating10 > 0f -> (b.rating10 / 2f).roundToInt().coerceIn(1, 5)
    else -> 0
}

/** When a book was last touched: opened, or else added. */
private fun touchedAt(b: Book): Long = max(b.lastOpenedAt, b.addedAt)

class ProgressRow(val book: Book, val pct: Int)
class AuthorChip(val name: String, val count: Int)
class LongestRead(val book: Book, val pages: Int)

class BooksOverview(
    val total: Int,
    val finished: Int,
    val reading: Int,
    /** The longest finished book, in pages; null when there is none. */
    val longest: LongestRead?,
    /** Display names, A to Z. */
    val languages: List<String>,
    /** Books being read, furthest along first. */
    val progress: List<ProgressRow>,
    val authors: List<AuthorChip>,
    val rated: Int,
    /** Average of the ratings (1..5), or null when no book is rated. */
    val avgRating: Double?,
    /** The newest few books, for the covers on the Library card. */
    val recent: List<Book>,
)

fun booksOverview(books: List<Book>): BooksOverview {
    val finished = books.filter { it.finished }
    val reading = books.filter { it.isReading }

    var longest: LongestRead? = null
    for (b in finished) {
        val pages = b.pageCount
        val cur = longest
        if (pages > 0 && (cur == null || pages > cur.pages)) longest = LongestRead(b, pages)
    }

    val languages = books.map { languageName(it.language) }.filter { it.isNotEmpty() }.toSortedSet().toList()

    val progress = reading.map { ProgressRow(it, it.percent) }.sortedByDescending { it.pct }

    val byAuthor = LinkedHashMap<String, Pair<String, Int>>()
    for (b in books) {
        for (a in splitAuthors(b.author)) {
            val key = a.lowercase()
            val cur = byAuthor[key]
            byAuthor[key] = if (cur == null) a to 1 else cur.first to (cur.second + 1)
        }
    }
    val authors = byAuthor.values
        .map { AuthorChip(it.first, it.second) }
        .sortedWith(compareByDescending<AuthorChip> { it.count }.thenBy { it.name.lowercase() })

    val stars = books.map { ratingStars(it) }.filter { it > 0 }

    return BooksOverview(
        total = books.size,
        finished = finished.size,
        reading = reading.size,
        longest = longest,
        languages = languages,
        progress = progress,
        authors = authors,
        rated = stars.size,
        avgRating = if (stars.isEmpty()) null else stars.average(),
        recent = books.sortedByDescending { touchedAt(it) }.take(3),
    )
}

// ---- shelves --------------------------------------------------------------------------------

class ShelfBook(
    val book: Book,
    /** The small line under the cover. */
    val meta: String,
    /** The pill on the cover: "4★". */
    val badge: String? = null,
)

class ShelfSection(val title: String?, val books: List<ShelfBook>)

class ShelfView(
    val title: String,
    val sub: String,
    val sections: List<ShelfSection>,
    /** Number of books in all sections. */
    val total: Int,
    /** Shown when there is nothing on the shelf. */
    val empty: String,
)

const val SHELF_LANGS = "langs"
const val SHELF_RATED = "rated"
const val SHELF_EPIC = "epic"

private fun booksText(n: Int) = "$n ${if (n == 1) "book" else "books"}"

private fun statusMeta(b: Book): String = when {
    b.finished -> "Finished"
    b.isReading -> "${b.percent}% read"
    else -> "Not started"
}

private const val NO_LANGUAGE = "Language not set"

/**
 * The shelf of the books behind a number on Stats: "langs", "rated", "epic", or "done-2026" (the books finished in
 * that year). Null for any other kind.
 */
fun buildShelf(kind: String, books: List<Book>, nowMs: Long = System.currentTimeMillis()): ShelfView? = when (kind) {
    // every book by language, the biggest group first
    SHELF_LANGS -> {
        val groups = LinkedHashMap<String, MutableList<ShelfBook>>()
        for (b in books.sortedBy { it.title.lowercase() }) {
            val name = languageName(b.language).ifEmpty { NO_LANGUAGE }
            groups.getOrPut(name) { mutableListOf() }.add(ShelfBook(b, statusMeta(b)))
        }
        val sections = groups.entries
            .sortedWith(
                compareBy<Map.Entry<String, MutableList<ShelfBook>>> { it.key == NO_LANGUAGE }
                    .thenByDescending { it.value.size }
                    .thenBy { it.key },
            )
            .map { ShelfSection("${it.key} \u00B7 ${it.value.size}", it.value) }
        val n = groups.keys.count { it != NO_LANGUAGE }
        ShelfView(
            title = "Languages",
            sub = "$n ${if (n == 1) "language" else "languages"} \u00B7 ${booksText(books.size)}",
            sections = sections,
            total = books.size,
            empty = "No books yet.",
        )
    }

    // rated books by stars, then the ones still waiting for a rating
    SHELF_RATED -> {
        val sections = ArrayList<ShelfSection>()
        for (stars in 5 downTo 1) {
            val list = books.filter { ratingStars(it) == stars }
                .sortedBy { it.title.lowercase() }
                .map { ShelfBook(it, statusMeta(it), "$stars\u2605") }
            if (list.isNotEmpty()) sections.add(ShelfSection("$stars ${if (stars == 1) "star" else "stars"} \u00B7 ${list.size}", list))
        }
        val ratedCount = sections.sumOf { it.books.size }
        val waiting = books.filter { ratingStars(it) == 0 }
            // finished books first: those are the ones worth rating
            .sortedWith(compareByDescending<Book> { it.finished }.thenBy { it.title.lowercase() })
            .map { ShelfBook(it, statusMeta(it)) }
        if (waiting.isNotEmpty()) sections.add(ShelfSection("Not rated yet \u00B7 ${waiting.size}", waiting))
        ShelfView(
            title = "Ratings",
            sub = "$ratedCount of ${books.size} rated",
            sections = sections,
            total = books.size,
            empty = "No books yet.",
        )
    }

    // finished books of EPIC_PAGES or more, longest first
    SHELF_EPIC -> {
        val rows = books.filter { isEpic(it) }
            .sortedByDescending { it.pageCount }
            .map { ShelfBook(it, "${commas(it.pageCount)} ${if (it.pageCount == 1) "page" else "pages"}") }
        ShelfView(
            title = "Epic books",
            sub = "$EPIC_PAGES+ pages \u00B7 ${booksText(rows.size)}",
            sections = listOf(ShelfSection(null, rows)),
            total = rows.size,
            empty = "No finished books of $EPIC_PAGES+ pages yet.",
        )
    }

    else -> doneShelf(kind, books, nowMs)
}

/** "done-2026": the books finished in 2026, newest first. */
private fun doneShelf(kind: String, books: List<Book>, nowMs: Long): ShelfView? {
    if (!kind.startsWith("done-")) return null
    val year = kind.removePrefix("done-").toIntOrNull() ?: return null
    val zone = ZoneId.systemDefault()
    val rows = books
        .filter { it.finished && finishedDate(it, zone).year == year }
        .sortedByDescending { finishedAtMs(it) }
        .map { ShelfBook(it, "Finished ${shortDateLabel(finishedAtMs(it), nowMs, zone)}") }
    return ShelfView(
        title = "Finished",
        sub = "$year \u00B7 ${booksText(rows.size)}",
        sections = listOf(ShelfSection(null, rows)),
        total = rows.size,
        empty = "No books finished in $year.",
    )
}
