package com.paperback.app.tts

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * What the read-aloud feature remembers. The names and defaults follow the TypeScript app's TTSConfig
 * (ttsRate, ttsPauseAfterSentence, ttsHighlightGranularity, ttsHighlightOptions, ttsPlayerStyle, ttsMediaMetadata) and its audio cache
 * settings. Every value is Compose state, so a screen showing it updates when it changes.
 */
class TtsPrefs(context: Context) {
    private val sp = context.getSharedPreferences("tts", Context.MODE_PRIVATE)

    /** 0.5 .. 3.0 */
    var rate by mutableFloatStateOf(sp.getFloat("rate", 1.0f).coerceIn(SPEED_MIN, SPEED_MAX))
        private set

    @JvmName("applyRate")

    fun setRate(v: Float) {
        rate = ((v / SPEED_STEP).let { Math.round(it) } * SPEED_STEP).coerceIn(SPEED_MIN, SPEED_MAX)
        sp.edit().putFloat("rate", rate).apply()
    }

    var pauseAfterSentence by mutableStateOf(sp.getBoolean("pauseAfterSentence", false))
        private set

    @JvmName("applyPauseAfterSentence")

    fun setPauseAfterSentence(v: Boolean) {
        pauseAfterSentence = v
        sp.edit().putBoolean("pauseAfterSentence", v).apply()
    }

    /** "word" or "sentence" */
    var granularity by mutableStateOf(sp.getString("granularity", "word") ?: "word")
        private set

    @JvmName("applyGranularity")

    fun setGranularity(v: String) {
        granularity = v
        sp.edit().putString("granularity", v).apply()
    }

    /** "highlight" or "underline" */
    var style by mutableStateOf(sp.getString("style", "highlight") ?: "highlight")
        private set

    @JvmName("applyStyle")

    fun setStyle(v: String) {
        style = v
        sp.edit().putString("style", v).apply()
    }

    /** ARGB */
    var color by mutableIntStateOf(sp.getInt("color", DEFAULT_COLOR))
        private set

    @JvmName("applyColor")

    fun setColor(v: Int) {
        color = v
        sp.edit().putInt("color", v).apply()
    }

    /** "full" or "minimal" */
    var playerStyle by mutableStateOf(sp.getString("playerStyle", "full") ?: "full")
        private set

    @JvmName("applyPlayerStyle")

    fun setPlayerStyle(v: String) {
        playerStyle = v
        sp.edit().putString("playerStyle", v).apply()
    }

    /** What the lock screen shows and how often it changes: "sentence", "paragraph" or "chapter". */
    var mediaMetadata by mutableStateOf(sp.getString("mediaMetadata", "sentence") ?: "sentence")
        private set

    @JvmName("applyMediaMetadata")

    fun setMediaMetadata(v: String) {
        mediaMetadata = v
        sp.edit().putString("mediaMetadata", v).apply()
    }

    var cacheEnabled by mutableStateOf(sp.getBoolean("cacheEnabled", true))
        private set

    @JvmName("applyCacheEnabled")

    fun setCacheEnabled(v: Boolean) {
        cacheEnabled = v
        sp.edit().putBoolean("cacheEnabled", v).apply()
    }

    var cacheBudgetMb by mutableIntStateOf(sp.getInt("cacheBudgetMb", 200))
        private set

    @JvmName("applyCacheBudgetMb")

    fun setCacheBudgetMb(v: Int) {
        cacheBudgetMb = v
        sp.edit().putInt("cacheBudgetMb", v).apply()
    }

    /** Index into [LYRIC_SIZES]. */
    var lyricSize by mutableIntStateOf(sp.getInt("lyricSize", 1).coerceIn(0, LYRIC_SIZES.lastIndex))
        private set

    @JvmName("applyLyricSize")

    fun setLyricSize(v: Int) {
        lyricSize = v.coerceIn(0, LYRIC_SIZES.lastIndex)
        sp.edit().putInt("lyricSize", lyricSize).apply()
    }

    /** The speech services you added yourself (Settings → Read aloud → Voice services). */
    var services by mutableStateOf(readServices())
        private set

    private fun readServices(): List<CustomService> = try {
        val arr = org.json.JSONArray(sp.getString("services", "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i -> runCatching { CustomService.fromJson(arr.getJSONObject(i)) }.getOrNull() }
    } catch (e: Exception) {
        emptyList()
    }

    private fun persistServices() {
        val arr = org.json.JSONArray()
        services.forEach { arr.put(it.toJson()) }
        sp.edit().putString("services", arr.toString()).apply()
    }

    fun saveService(service: CustomService) {
        services = if (services.any { it.id == service.id }) services.map { if (it.id == service.id) service else it } else services + service
        persistServices()
    }

    fun deleteService(id: String) {
        services = services.filter { it.id != id }
        persistServices()
    }

    /** The service and voice name behind a "svc:" voice id (only while the service is switched on). */
    fun customFor(voiceId: String): Pair<CustomService, String>? {
        if (!voiceId.startsWith(CUSTOM_PREFIX)) return null
        val rest = voiceId.removePrefix(CUSTOM_PREFIX)
        val cut = rest.indexOf(':')
        if (cut < 0) return null
        val service = services.firstOrNull { it.id == rest.substring(0, cut) && it.enabled } ?: return null
        return service to rest.substring(cut + 1)
    }

    /** What makes the same text sound different on one service, so saved audio is not reused after you change it. */
    fun customScope(voiceId: String): String? =
        customFor(voiceId)?.first?.let { "${it.baseUrl.trim()}|${it.model.trim()}|${it.instructions.trim()}" }

    /** The voice picked for a language (two letters), or null to let the app choose. */
    fun voiceFor(lang: String): String? = sp.getString("voice_" + lang2(lang), null)

    fun setVoiceFor(lang: String, voiceId: String) {
        sp.edit().putString("voice_" + lang2(lang), voiceId).apply()
    }

    companion object {
        const val SPEED_MIN = 0.5f
        const val SPEED_MAX = 3.0f
        const val SPEED_STEP = 0.05f
        const val DEFAULT_COLOR = 0xFF808080.toInt()

        /** The sizes the A− / A+ buttons of the sentence view step through (sp). */
        val LYRIC_SIZES = listOf(12, 14, 16, 18, 20, 24, 28, 32, 38)

        /** The same quick colours as the TypeScript settings. */
        val QUICK_COLORS = listOf(0xFFFFD700.toInt(), 0xFF00CED1.toInt(), 0xFFFF69B4.toInt(), 0xFF90EE90.toInt(), 0xFFFFA500.toInt(), DEFAULT_COLOR)

        fun lang2(lang: String): String = lang.lowercase().substringBefore('-').substringBefore('_').take(3).ifEmpty { "en" }

        fun formatRate(rate: Float): String = "${"%.2f".format(java.util.Locale.US, rate).trimEnd('0').trimEnd('.')}×"
    }
}
