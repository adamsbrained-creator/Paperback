package com.paperback.app.tts

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat

/**
 * Keeps the voice alive with the screen off: a media notification with Previous / Play-Pause / Next / Stop, and a media session so
 * the lock screen, headphones and Bluetooth buttons work. The session itself ([TtsSession]) does the reading; this only shows it.
 * (The TypeScript app has the same in libs/mediaSession.ts.)
 */
class TtsService : Service() {
    private var mediaSession: MediaSession? = null
    private var foreground = false
    private var lastCoverFor: String? = null
    private var lastCover: android.graphics.Bitmap? = null

    /** Keeps the processor awake while the book is being read, so the voice does not stall with the screen off. */
    private var wakeLock: android.os.PowerManager.WakeLock? = null

    private fun holdAwake(on: Boolean) {
        if (on) {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                wakeLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "paperback:readaloud").apply { setReferenceCounted(false) }
            }
            // Released when reading pauses or stops, and in onDestroy.
            wakeLock?.let { if (!it.isHeld) it.acquire() }
        } else {
            wakeLock?.let { if (it.isHeld) it.release() }
        }
    }

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            TtsHub.session?.pause() // headphones pulled out
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val channel = NotificationChannel(CHANNEL, "Read aloud", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Controls for the book being read aloud"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        mediaSession = MediaSession(this, "paperback-tts").apply {
            setCallback(
                object : MediaSession.Callback() {
                    override fun onPlay() { TtsHub.session?.play() }
                    override fun onPause() { TtsHub.session?.pause() }
                    override fun onSkipToNext() { TtsHub.session?.stepSentence(1) }
                    override fun onSkipToPrevious() { TtsHub.session?.stepSentence(-1) }
                    override fun onFastForward() { TtsHub.session?.stepParagraph(1) }
                    override fun onRewind() { TtsHub.session?.stepParagraph(-1) }
                    override fun onStop() { TtsHub.session?.stop() }
                },
            )
            isActive = true
        }
        ContextCompat.registerReceiver(this, noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY), ContextCompat.RECEIVER_NOT_EXPORTED)
        show()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val session = TtsHub.session
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> session?.togglePlay()
            ACTION_NEXT -> session?.stepSentence(1)
            ACTION_PREV -> session?.stepSentence(-1)
            ACTION_STOP -> session?.stop()
        }
        if (session == null || !session.active) {
            stopSelf()
            return START_NOT_STICKY
        }
        show()
        return START_NOT_STICKY
    }

    /** Builds the notification for the current state and shows it (as a foreground service, so the voice is not killed). */
    private fun show() {
        val s = TtsHub.session
        if (s == null || !s.active) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foreground = false
            stopSelf()
            return
        }
        val playing = s.playing
        holdAwake(playing)
        val cover = if (lastCoverFor == s.book.bookId) lastCover else s.coverBitmap().also { lastCover = it; lastCoverFor = s.book.bookId }

        mediaSession?.let { ms ->
            ms.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, s.notificationText())
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, s.book.title)
                    .putString(MediaMetadata.METADATA_KEY_ALBUM, s.chapterTitle)
                    .apply { if (cover != null) putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, cover) }
                    .build(),
            )
            ms.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                            PlaybackState.ACTION_FAST_FORWARD or PlaybackState.ACTION_REWIND or PlaybackState.ACTION_STOP,
                    )
                    .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, if (playing) 1f else 0f)
                    .build(),
            )
        }

        fun action(icon: Int, label: String, act: String, code: Int): Notification.Action =
            Notification.Action.Builder(
                Icon.createWithResource(this, icon),
                label,
                PendingIntent.getService(this, code, Intent(this, TtsService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT),
            ).build()

        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val builder = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_headset)
            .setContentTitle(s.book.title)
            .setContentText(s.notificationText())
            .setSubText(s.chapterTitle)
            .setContentIntent(open)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action(android.R.drawable.ic_media_previous, "Previous sentence", ACTION_PREV, 1))
            .addAction(
                if (playing) action(android.R.drawable.ic_media_pause, "Pause", ACTION_PLAY_PAUSE, 2)
                else action(android.R.drawable.ic_media_play, "Play", ACTION_PLAY_PAUSE, 2),
            )
            .addAction(action(android.R.drawable.ic_media_next, "Next sentence", ACTION_NEXT, 3))
            .addAction(action(android.R.drawable.ic_menu_close_clear_cancel, "Stop", ACTION_STOP, 4))
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(mediaSession?.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2),
            )
        if (cover != null) builder.setLargeIcon(cover)
        val notification = builder.build()

        if (!foreground) {
            // Android 12+ can refuse to enter the foreground from the background; the notification is shown anyway.
            val entered = runCatching {
                if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                else startForeground(NOTIFICATION_ID, notification)
            }.isSuccess
            if (!entered) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification)
            foreground = entered
        } else {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification)
        }
        if (!playing) stopForeground(STOP_FOREGROUND_DETACH).also { foreground = false }
    }

    override fun onDestroy() {
        instance = null
        runCatching { unregisterReceiver(noisy) }
        holdAwake(false)
        mediaSession?.run { isActive = false; release() }
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "tts_playback"
        private const val NOTIFICATION_ID = 4711
        private const val ACTION_PLAY_PAUSE = "com.paperback.app.tts.PLAY_PAUSE"
        private const val ACTION_NEXT = "com.paperback.app.tts.NEXT"
        private const val ACTION_PREV = "com.paperback.app.tts.PREV"
        private const val ACTION_STOP = "com.paperback.app.tts.STOP"

        @Volatile
        private var instance: TtsService? = null

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, TtsService::class.java))
        }

        fun stop(context: Context) {
            instance?.let { it.stopForeground(STOP_FOREGROUND_REMOVE); it.stopSelf() }
                ?: context.stopService(Intent(context, TtsService::class.java))
        }

        /** Redraws the notification (play / pause, a new sentence). */
        fun refresh() {
            instance?.show()
        }
    }
}
