package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/*
 * Everything the Stats -> Insights page shows, as plain functions: this month against last month, consistency,
 * reading speed, records, finish estimates and the year's pace. A port of the TypeScript app's insightsStats.ts.
 * No Android, no clock: `today` and `nowMs` are passed in.
 *
 * As on the Activity page, "pages" here are the pages turned in the reading sessions (not distinct pages), and a day
 * counts as a reading day from one minute of reading.
 */

private const val MIN_SPEED_SECONDS = 600L
private const val DAY_SECONDS_MIN = 60L

private fun summaryOf(rows: List<ReadingSession>): Summary = computeSummary(rows, buildSessions(rows))

private fun startMs(d: LocalDate, zone: ZoneId): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()

// ---- this month against last month ----------------------------------------------------------

class MonthCompare(
    /** Seconds read this calendar month so far, and in the same first days of the previous month. */
    val cur: Long,
    val prev: Long,
    val curPages: Int,
    val prevPages: Int,
    /** Percent change against the same days of last month; null without a base. */
    val pct: Int?,
    val monthName: String,
    val prevName: String,
)

/** This month so far, against the same stretch (the first N days) of last month. */
fun monthCompare(rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): MonthCompare {
    val curFrom = today.withDayOfMonth(1)
    val prevFrom = curFrom.minusMonths(1)
    val prevTo = prevFrom.plusDays(min(today.dayOfMonth, prevFrom.lengthOfMonth()).toLong())
    val curMs = startMs(curFrom, zone)
    val prevFromMs = startMs(prevFrom, zone)
    val prevToMs = startMs(prevTo, zone)
    val a = summaryOf(rows.filter { it.startMs >= curMs })
    val b = summaryOf(rows.filter { it.startMs >= prevFromMs && it.startMs < prevToMs })
    return MonthCompare(
        cur = a.seconds,
        prev = b.seconds,
        curPages = a.pages,
        prevPages = b.pages,
        pct = pctDelta(a.seconds, b.seconds),
        monthName = StatNames.MONTHS[curFrom.monthValue - 1],
        prevName = StatNames.MONTHS[prevFrom.monthValue - 1],
    )
}

// ---- consistency ----------------------------------------------------------------------------

class Consistency(
    val activeDays: Int,
    val of: Int,
    /** 0..1 */
    val pct: Float,
    val streak: Int,
    val longestStreak: Int,
)

/** On how many of the last 30 days did you read (at least a minute)? */
fun consistency(rows: List<ReadingSession>, today: LocalDate, zone: ZoneId, days: Int = 30): Consistency {
    val byDay = Stats.secondsByDay(rows, zone)
    var active = 0
    for (i in 0 until days) if ((byDay[today.minusDays(i.toLong())] ?: 0L) >= DAY_SECONDS_MIN) active++
    val current = Stats.currentStreak(byDay, today)
    return Consistency(
        activeDays = active,
        of = days,
        pct = active.toFloat() / days,
        streak = current,
        longestStreak = max(Stats.longestStreak(byDay), current),
    )
}

// ---- reading speed --------------------------------------------------------------------------

class SpeedMonth(
    /** "May" */
    val label: String,
    /** Pages per hour, 0 when too little was read. */
    val pace: Int,
    /** The first day of the month (for opening History there). */
    val firstDay: LocalDate,
)

class Speed(
    /** Pages per hour over the last 60 days (0 when there is too little reading). */
    val current: Int,
    /** The last six months, oldest first. */
    val months: List<SpeedMonth>,
    val best: SpeedMonth?,
)

fun readingSpeed(rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): Speed {
    val thisMonth = today.withDayOfMonth(1)
    val months = (5 downTo 0).map { i ->
        val from = thisMonth.minusMonths(i.toLong())
        val to = from.plusMonths(1)
        val fromMs = startMs(from, zone)
        val toMs = startMs(to, zone)
        val s = summaryOf(rows.filter { it.startMs >= fromMs && it.startMs < toMs })
        // A month with under ten minutes of reading says nothing about speed.
        SpeedMonth(StatNames.MONTHS_SHORT[from.monthValue - 1], if (s.seconds >= MIN_SPEED_SECONDS) s.pagesPerHour else 0, from)
    }
    val recentMs = startMs(today.minusDays(59), zone)
    val recent = summaryOf(rows.filter { it.startMs >= recentMs })
    var best: SpeedMonth? = null
    for (m in months) {
        val b = best
        if (m.pace > 0 && (b == null || m.pace > b.pace)) best = m
    }
    return Speed(if (recent.seconds >= MIN_SPEED_SECONDS) recent.pagesPerHour else 0, months, best)
}

// ---- records --------------------------------------------------------------------------------

class WeekTotal(val start: LocalDate, val seconds: Long)
class DayPages(val date: LocalDate, val pages: Int)

class Records(
    val bestDay: DayTotal?,
    val longestSession: Session?,
    /** The best Monday-to-Sunday week by time read. */
    val bestWeek: WeekTotal?,
    val mostPages: DayPages?,
)

fun readingRecords(rows: List<ReadingSession>, zone: ZoneId): Records {
    val byDay = Stats.secondsByDay(rows, zone).filterValues { it > 0 }.toSortedMap()

    var bestDay: DayTotal? = null
    val weeks = java.util.TreeMap<LocalDate, Long>()
    for ((d, s) in byDay) {
        val b = bestDay
        if (b == null || s > b.seconds) bestDay = DayTotal(d, s) // the earlier day wins a tie
        val monday = d.minusDays((d.dayOfWeek.value - 1).toLong())
        weeks[monday] = (weeks[monday] ?: 0L) + s
    }
    var bestWeek: WeekTotal? = null
    for ((monday, s) in weeks) {
        val b = bestWeek
        if (b == null || s > b.seconds) bestWeek = WeekTotal(monday, s)
    }

    val pagesByDay = rows.groupBy { dateOf(it.startMs, zone) }.mapValues { (_, l) -> l.sumOf { it.pages } }.toSortedMap()
    var mostPages: DayPages? = null
    for ((d, p) in pagesByDay) {
        val b = mostPages
        if (p > 0 && (b == null || p > b.pages)) mostPages = DayPages(d, p)
    }

    return Records(bestDay, buildSessions(rows).maxByOrNull { it.seconds }, bestWeek, mostPages)
}

// ---- when you will finish -------------------------------------------------------------------

class ForecastRow(
    val book: Book,
    val pagesLeft: Int,
    /** Reading time left at your pace, in seconds. */
    val secondsLeft: Long,
    /** Days until you finish at your recent pace of reading days; null when that cannot be told. */
    val days: Int?,
)

/** For the books in progress: how long is left, and about when you would finish. */
fun finishForecast(books: List<Book>, rows: List<ReadingSession>, today: LocalDate, zone: ZoneId, limit: Int = 4): List<ForecastRow> {
    val fromMs = startMs(today.minusDays(59), zone)
    val overall = summaryOf(rows.filter { it.startMs >= fromMs })
    val pace = if (overall.seconds >= MIN_SPEED_SECONDS) overall.pagesPerHour else 0

    // Seconds read on an average day you read, in the last 30 days.
    val byDay = Stats.secondsByDay(rows, zone)
    var total = 0L
    var active = 0
    for (i in 0 until 30) {
        val s = byDay[today.minusDays(i.toLong())] ?: 0L
        if (s >= DAY_SECONDS_MIN) {
            total += s
            active++
        }
    }
    val perDay = if (active > 0) total.toDouble() / active else 0.0
    val daysActive = active / 30.0 // the share of days you read at all

    val byBook = rows.groupBy { it.bookId }
    val out = ArrayList<ForecastRow>()
    for (b in books) {
        if (!b.isReading || b.pageCount <= 0) continue
        val pagesLeft = b.pageCount - b.currentPage
        if (pagesLeft <= 0) continue
        // Prefer the pace on this very book once it has enough reading, else the overall one.
        val own = summaryOf(byBook[b.id].orEmpty())
        val bookPace = if (own.seconds >= MIN_SPEED_SECONDS) own.pagesPerHour else pace
        if (bookPace <= 0) continue
        val secondsLeft = Math.round(pagesLeft.toDouble() / bookPace * 3600)
        val readingDays = if (perDay > 0) ceil(secondsLeft / perDay).toInt() else null
        out.add(
            ForecastRow(
                book = b,
                pagesLeft = pagesLeft,
                secondsLeft = secondsLeft,
                days = if (readingDays != null && daysActive > 0) max(1, ceil(readingDays / daysActive).toInt()) else null,
            ),
        )
    }
    return out.sortedBy { it.secondsLeft }.take(limit)
}

/** "about a day" / "about 5 days" / "about 3 weeks" / "about 2 months". */
fun inDaysText(days: Int): String = when {
    days <= 1 -> "about a day"
    days < 21 -> "about $days days"
    days < 70 -> "about ${Math.round(days / 7.0)} weeks"
    else -> "about ${Math.round(days / 30.0)} months"
}

// ---- the year -------------------------------------------------------------------------------

class YearPace(
    val year: Int,
    val finished: Int,
    val goal: Int,
    /** Books a straight line through the year would have by today. */
    val expected: Int,
    /** Where the year ends up at this rate. */
    val projected: Int,
    /** 0..1 of the year that has passed. */
    val elapsed: Double,
)

fun yearPace(finished: Int, goal: Int, nowMs: Long, zone: ZoneId): YearPace {
    val year = dateOf(nowMs, zone).year
    val start = startMs(LocalDate.of(year, 1, 1), zone)
    val end = startMs(LocalDate.of(year + 1, 1, 1), zone)
    val elapsed = ((nowMs - start).toDouble() / (end - start)).coerceIn(0.0001, 1.0)
    return YearPace(
        year = year,
        finished = finished,
        goal = goal,
        expected = floor(goal * elapsed).toInt(),
        projected = if (elapsed < 0.04) finished else (finished / elapsed).roundToInt(),
        elapsed = elapsed,
    )
}
