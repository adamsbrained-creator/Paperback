package com.paperback.app.tts

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.ui.AsCard
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.PbButton
import com.paperback.app.ui.PbField
import com.paperback.app.ui.PbNote
import com.paperback.app.ui.PbPage
import com.paperback.app.ui.PbSlider
import com.paperback.app.ui.Segmented
import com.paperback.app.ui.theme.pbTokens
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Settings → Read aloud (the TypeScript app's TTSPanel and the audio cache section): speed, how the spoken
 * text is marked on the page, the player's look, what the lock screen shows and how much audio is kept.
 */
@Composable
fun TtsSettingsScreen(headerSize: HeaderSize, onMenu: () -> Unit, onSearch: () -> Unit) {
    val t = pbTokens()
    val context = LocalContext.current
    val p = TtsHub.prefs(context)
    val cache = remember { TtsAudioCache(context.applicationContext) }
    var bytes by remember { mutableLongStateOf(cache.sizeBytes()) }
    // the service being edited; "new" is the form for adding one
    var editing by remember { mutableStateOf<CustomService?>(null) }
    var adding by remember { mutableStateOf(false) }
    if (editing != null || adding) {
        BackHandler { editing = null; adding = false }
        ServiceEditor(headerSize, p, editing, onMenu, onSearch) { editing = null; adding = false }
        return
    }

    PbPage("Read aloud", headerSize, onMenu, onSearch) {
        Text(
            "Have the book read to you with natural voices. Start it with the headphones button in the reader.",
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 18.dp),
            color = t.setSub, fontSize = 15.sp, lineHeight = 21.75.sp,
        )
        AsCard("Speed", "${TtsPrefs.formatRate(p.rate)} — also changed in the player.") {
            PbSlider(
                value = p.rate,
                onValueChange = { p.setRate(it) },
                valueRange = TtsPrefs.SPEED_MIN..TtsPrefs.SPEED_MAX,
                trackColor = t.ink.copy(alpha = 0.15f),
            )
        }
        AsCard("Pause after each sentence", "A short stop after every sentence, so you can follow along slowly.") {
            Segmented(listOf(true to "On", false to "Off"), p.pauseAfterSentence) { p.setPauseAfterSentence(it) }
        }
        AsCard("Highlight", "What is marked on the page while it is read.") {
            Segmented(listOf("word" to "Word by word", "sentence" to "Sentence"), p.granularity) { p.setGranularity(it) }
        }
        AsCard("Marker style", "") {
            Segmented(listOf("highlight" to "Highlight", "underline" to "Underline"), p.style) { p.setStyle(it) }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.padding(horizontal = 2.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (color in TtsPrefs.QUICK_COLORS) {
                    val on = p.color == color
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(color))
                            .then(if (on) Modifier.border(3.dp, t.ink, CircleShape) else Modifier)
                            .clickable { p.setColor(color) },
                    )
                }
            }
        }
        AsCard("Player", "The bar that appears over the page while reading aloud.") {
            Segmented(listOf("full" to "Full", "minimal" to "Minimal"), p.playerStyle) { p.setPlayerStyle(it) }
        }
        AsCard("Lock screen", "What the notification shows, and how often it changes.") {
            Segmented(
                listOf("sentence" to "Sentence", "paragraph" to "Paragraph", "chapter" to "Chapter"),
                p.mediaMetadata,
            ) { p.setMediaMetadata(it) }
        }
        AsCard("Keep audio", "Sentences you listened to stay on the phone, so hearing them again costs no data.") {
            Segmented(listOf(true to "On", false to "Off"), p.cacheEnabled) { p.setCacheEnabled(it) }
            if (p.cacheEnabled) {
                Spacer(Modifier.height(14.dp))
                Text("Up to ${p.cacheBudgetMb} MB", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                PbSlider(
                    value = p.cacheBudgetMb.toFloat(),
                    onValueChange = { p.setCacheBudgetMb(((it / 50f).roundToInt() * 50).coerceIn(50, 2000)) },
                    valueRange = 50f..2000f,
                    trackColor = t.ink.copy(alpha = 0.15f),
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Clear saved audio  ·  ${"%.1f".format(java.util.Locale.US, bytes / 1_048_576.0)} MB",
                color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(t.bg)
                    .clickable {
                        cache.clearLive()
                        bytes = cache.sizeBytes()
                    }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }
        PbNote("Chapters you download for offline listening are not removed by this.")
        AsCard("Voice services", "Your own speech services (OpenAI, Kokoro, SiliconFlow, LocalAI...). Their voices join the voice picker in the player.") {
            Spacer(Modifier.height(8.dp))
            for (service in p.services) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { editing = service }.padding(vertical = 10.dp, horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                        Text(service.name, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text(
                            "${service.model} · ${service.baseUrl}", color = t.setSub, fontSize = 12.sp,
                            maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        )
                    }
                    Text(if (service.enabled) "On" else "Off", color = t.setSub, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            PbButton("Add a service", { adding = true }, ghost = false)
        }
        PbNote("Sentences go straight from this phone to the service, with your key. A service may charge for the text it speaks.")
    }
}

/** The form for adding or changing one of your speech services, with a Test button that speaks a sample. */
@Composable
private fun ServiceEditor(
    headerSize: HeaderSize,
    prefs: TtsPrefs,
    service: CustomService?,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onDone: () -> Unit,
) {
    val t = pbTokens()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(service?.name ?: "") }
    var baseUrl by remember { mutableStateOf(service?.baseUrl ?: CustomService.BASE_URL_PRESETS[0]) }
    var apiKey by remember { mutableStateOf(service?.apiKey ?: "") }
    var model by remember { mutableStateOf(service?.model ?: CustomService.MODEL_PRESETS[0]) }
    var instructions by remember { mutableStateOf(service?.instructions ?: "") }
    var enabled by remember { mutableStateOf(service?.enabled ?: true) }
    var testing by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    var failed by remember { mutableStateOf(false) }
    val ready = name.isNotBlank() && baseUrl.isNotBlank() && model.isNotBlank()

    fun draft() = CustomService(service?.id ?: CustomService.newId(), name.trim(), baseUrl.trim(), apiKey.trim(), model.trim(), instructions.trim(), enabled)

    PbPage(if (service == null) "Add a service" else service.name, headerSize, onMenu, onSearch) {
        Text(
            "Any service that answers the OpenAI speech API (POST /audio/speech). Sentences go from this phone straight to it.",
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 18.dp, bottom = 6.dp),
            color = t.setSub, fontSize = 15.sp, lineHeight = 21.75.sp,
        )
        FieldLabel("Name")
        PbField(name, { name = it; result = null }, "OpenAI")
        FieldLabel("Base URL")
        PbField(baseUrl, { baseUrl = it; result = null }, "https://api.openai.com/v1")
        Chips(CustomService.BASE_URL_PRESETS, baseUrl) { baseUrl = it; result = null }
        FieldLabel("API key")
        PbField(apiKey, { apiKey = it; result = null }, "Optional for servers on your own network", visualTransformation = PasswordVisualTransformation())
        FieldLabel("Model")
        PbField(model, { model = it; result = null }, "gpt-4o-mini-tts")
        Chips(CustomService.MODEL_PRESETS, model) { model = it; result = null }
        FieldLabel("Instructions")
        PbField(instructions, { instructions = it; result = null }, "Optional: a speaking style, for models that take one", singleLine = false, minLines = 3)
        FieldLabel("Use this service")
        Segmented(listOf(true to "On", false to "Off"), enabled) { enabled = it }

        result?.let {
            Text(
                it, color = if (failed) com.paperback.app.ui.DangerRed else t.setSub, fontSize = 14.sp,
                modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 16.dp),
            )
        }
        Spacer(Modifier.height(18.dp))
        PbButton(if (testing) "Testing..." else "Test (lists the voices and speaks a sample)", {
            testing = true
            result = null
            scope.launch {
                try {
                    val d = draft()
                    val voices = CustomSpeech.listVoices(d)
                    val audio = CustomSpeech.synthesize(d, voices.first(), "Hello! This is how this voice sounds.")
                    val file = java.io.File(context.cacheDir, "tts_test.mp3").also { it.writeBytes(audio.bytes) }
                    val mp = android.media.MediaPlayer()
                    mp.setDataSource(file.path)
                    mp.setOnPreparedListener { it.start() }
                    mp.setOnCompletionListener { it.release() }
                    mp.setOnErrorListener { player, _, _ -> player.release(); true }
                    mp.prepareAsync()
                    failed = false
                    result = "${voices.size} voices available. Playing a sample."
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failed = true
                    result = e.message ?: "The service could not be reached."
                } finally {
                    testing = false
                }
            }
        }, ghost = true, enabled = ready && !testing)
        Spacer(Modifier.height(10.dp))
        PbButton("Save", {
            prefs.saveService(draft())
            onDone()
        }, enabled = ready)
        if (service != null) {
            Spacer(Modifier.height(10.dp))
            PbButton("Delete this service", {
                prefs.deleteService(service.id)
                onDone()
            }, ghost = true, destructive = true)
        }
        PbNote("The key is kept in this app's private storage on the phone, not encrypted.")
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(text, color = pbTokens().setSub, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp, top = 16.dp, bottom = 6.dp))
}

/** Tappable examples under a field (the TypeScript editor offers the same as a drop-down list). */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun Chips(options: List<String>, selected: String, onPick: (String) -> Unit) {
    val t = pbTokens()
    androidx.compose.foundation.layout.FlowRow(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (o in options) {
            val on = o == selected
            Text(
                o, color = if (on) t.bg else t.ink, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(if (on) t.ink else t.card).clickable { onPick(o) }.padding(horizontal = 12.dp, vertical = 7.dp),
            )
        }
    }
}
