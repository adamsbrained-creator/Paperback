package com.paperback.app.tts

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicReference

/** Voice ids of your own services look like "svc:<service id>:<voice>". */
const val CUSTOM_PREFIX = "svc:"

fun customVoiceId(serviceId: String, voice: String) = "$CUSTOM_PREFIX$serviceId:$voice"

/**
 * A speech service you set up yourself: anything that answers the OpenAI speech API (`POST {baseUrl}/audio/speech`), such as OpenAI,
 * Kokoro-FastAPI, SiliconFlow or LocalAI. Same fields as the TypeScript app's CustomTTSService.
 */
class CustomService(
    val id: String,
    val name: String,
    /** For example https://api.openai.com/v1 */
    val baseUrl: String,
    val apiKey: String,
    val model: String,
    /** Style instructions for models that take them (gpt-4o-mini-tts). */
    val instructions: String,
    val enabled: Boolean,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("baseUrl", baseUrl).put("apiKey", apiKey)
        .put("model", model).put("instructions", instructions).put("enabled", enabled)

    companion object {
        fun fromJson(o: JSONObject): CustomService = CustomService(
            id = o.getString("id"),
            name = o.optString("name"),
            baseUrl = o.optString("baseUrl"),
            apiKey = o.optString("apiKey"),
            model = o.optString("model"),
            instructions = o.optString("instructions"),
            enabled = o.optBoolean("enabled", true),
        )

        fun newId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(12)

        val BASE_URL_PRESETS = listOf("https://api.openai.com/v1", "https://api.siliconflow.cn/v1", "http://192.168.1.10:8880/v1")
        val MODEL_PRESETS = listOf("gpt-4o-mini-tts", "tts-1", "tts-1-hd", "kokoro")
    }
}

/** The calls to a custom service. These services return no word times, so the page is marked sentence by sentence. */
object CustomSpeech {
    /** OpenAI has no list of voices, so a service that does not give one gets these. */
    val STANDARD_VOICES = listOf("alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer", "verse")

    private val FATAL = setOf(401, 403, 404)
    private val TRANSIENT = setOf(408, 409, 425, 429)

    private fun open(s: CustomService, path: String, method: String): HttpURLConnection {
        val url = s.baseUrl.trim().trimEnd('/') + path
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        if (s.apiKey.isNotBlank()) c.setRequestProperty("Authorization", "Bearer ${s.apiKey.trim()}")
        return c
    }

    /** The voices a service offers (`GET {baseUrl}/audio/voices`), or the standard ones when it lists none. */
    suspend fun listVoices(s: CustomService): List<String> = withContext(Dispatchers.IO) {
        val listed = try {
            val c = open(s, "/audio/voices", "GET")
            c.connectTimeout = 5_000
            c.readTimeout = 5_000
            try {
                if (c.responseCode in 200..299) parseVoices(c.inputStream.bufferedReader().use { it.readText() }) else emptyList()
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            emptyList()
        }
        listed.ifEmpty { STANDARD_VOICES }
    }

    /** `{ "voices": [ "name", ... ] }` or a list of objects with "id" or "name". */
    private fun parseVoices(text: String): List<String> {
        val list: JSONArray = JSONObject(text).optJSONArray("voices") ?: return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until list.length()) {
            val item = list.opt(i)
            val name = when (item) {
                is String -> item
                is JSONObject -> item.optString("id").ifBlank { item.optString("name") }
                else -> ""
            }
            if (name.isNotBlank()) out += name
        }
        return out
    }

    /**
     * Says [text] with [voice] and returns the MP3. Throws [IOException] for trouble that may pass (no connection, a busy service),
     * [SpeakException] for answers that will not change (a wrong key or address, or a sentence the service refuses).
     */
    suspend fun synthesize(s: CustomService, voice: String, text: String): EdgeAudio = withContext(Dispatchers.IO) {
        coroutineScope {
            val ref = AtomicReference<HttpURLConnection?>(null)
            // cancelling the sentence closes the connection, so the request does not go on in the background
            val watcher = launch { try { awaitCancellation() } finally { ref.get()?.disconnect() } }
            try {
                val c = open(s, "/audio/speech", "POST")
                ref.set(c)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject().put("model", s.model.trim()).put("input", text).put("voice", voice).put("response_format", "mp3")
                if (s.instructions.isNotBlank()) body.put("instructions", s.instructions.trim())
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                if (code !in 200..299) {
                    val detail = try { c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty() } catch (e: Exception) { "" }
                    val message = "${s.name}: HTTP $code" + if (detail.isNotBlank()) " ${detail.take(300)}" else ""
                    when {
                        code in FATAL -> throw SpeakException(message)
                        code < 500 && code !in TRANSIENT -> throw SpeakException(message, permanent = true)
                        else -> throw IOException(message)
                    }
                }
                val bytes = c.inputStream.use { it.readBytes() }
                if (bytes.isEmpty()) throw IOException("${s.name}: the service sent no audio")
                EdgeAudio(bytes, emptyList())
            } finally {
                watcher.cancel()
                ref.get()?.disconnect()
            }
        }
    }
}
