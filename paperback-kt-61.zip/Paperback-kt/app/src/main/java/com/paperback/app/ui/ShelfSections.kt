package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ShelfBook
import com.paperback.app.data.ShelfView
import com.paperback.app.ui.theme.pbTokens

private sealed interface ShelfEntry {
    val key: String

    class Head(val title: String, override val key: String) : ShelfEntry
    class Covers(val books: List<ShelfBook>, override val key: String) : ShelfEntry
}

/**
 * A shelf in sections (Languages, Ratings, Epic books): a heading per section and the covers under it in rows of
 * three, with a small pill on the cover when the book has one ("4★"). Tap a cover for the book page.
 */
@Composable
fun SectionShelfScreen(
    view: ShelfView,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenBook: (Book) -> Unit,
) {
    val t = pbTokens()
    val entries = remember(view) {
        val out = ArrayList<ShelfEntry>()
        view.sections.forEachIndexed { si, s ->
            if (s.title != null) out.add(ShelfEntry.Head(s.title, "h$si"))
            s.books.chunked(3).forEachIndexed { ri, row -> out.add(ShelfEntry.Covers(row, "c$si-$ri")) }
        }
        out
    }
    PbListPage(view.title, headerSize, onMenu, onSearch) {
        Text(view.sub, modifier = Modifier.padding(start = 4.dp, top = 2.dp), color = t.setSub, fontSize = 14.sp)
        if (view.total == 0) {
            Spacer(Modifier.height(12.dp))
            Text(view.empty, modifier = Modifier.padding(vertical = 8.dp), color = t.setSub)
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(top = 8.dp, bottom = 112.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(entries, key = { it.key }) { e ->
                    when (e) {
                        is ShelfEntry.Head -> Text(
                            e.title.uppercase(),
                            modifier = Modifier.padding(start = 4.dp, top = 10.dp),
                            color = t.setSub,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 0.14.em,
                        )
                        is ShelfEntry.Covers -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            e.books.forEach { b -> ShelfCover(b, Modifier.weight(1f), onOpenBook) }
                            repeat(3 - e.books.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShelfCover(b: ShelfBook, modifier: Modifier, onOpen: (Book) -> Unit) {
    val t = pbTokens()
    Column(modifier.clickable { onOpen(b.book) }) {
        Box {
            BookCover(b.book, Modifier.fillMaxWidth())
            if (b.badge != null) {
                Text(
                    b.badge,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.8f))
                        .padding(horizontal = 9.dp, vertical = 3.dp),
                    color = StatsAccent.Yellow,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(b.book.title, color = t.ink, fontSize = 13.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (b.book.author.isNotBlank()) {
            Text(b.book.author, color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(b.meta, color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
