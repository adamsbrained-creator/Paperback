package com.paperback.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/**
 * Fonts the reader imported (.ttf, .otf, .woff, .woff2), kept in the app's own folder. A font's name in the reader is its file name
 * without the ending. [SYSTEM] are fonts every Android phone has, by their CSS name.
 */
object ReaderFonts {
    private val ENDINGS = setOf("ttf", "otf", "woff", "woff2")

    /** Label to CSS font name, for the fonts that come with Android. */
    val SYSTEM: List<Pair<String, String>> = listOf(
        "Condensed" to "sans-serif-condensed",
        "Light" to "sans-serif-light",
        "Medium" to "sans-serif-medium",
        "Casual" to "casual",
        "Cursive" to "cursive",
        "Serif mono" to "serif-monospace",
    )

    private fun dir(c: Context): File = File(c.filesDir, "fonts").apply { mkdirs() }

    fun list(c: Context): List<String> =
        dir(c).listFiles()?.filter { it.extension.lowercase() in ENDINGS }?.map { it.nameWithoutExtension }?.sorted().orEmpty()

    fun file(c: Context, name: String): File? =
        dir(c).listFiles()?.firstOrNull { it.extension.lowercase() in ENDINGS && it.nameWithoutExtension == name }

    /** Copies the chosen font file into the app. Returns its name, or null when it is not a font file or cannot be read. */
    fun import(c: Context, uri: Uri): String? {
        val shown = c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
            val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && cur.moveToFirst()) cur.getString(i) else null
        } ?: uri.lastPathSegment ?: return null
        val ext = shown.substringAfterLast('.', "").lowercase()
        if (ext !in ENDINGS) return null
        val name = shown.substringBeforeLast('.').replace(Regex("[\"'\\\\/]"), "").trim().ifEmpty { return null }
        return try {
            c.contentResolver.openInputStream(uri)?.use { input ->
                File(dir(c), "$name.$ext").outputStream().use { input.copyTo(it) }
            } ?: return null
            name
        } catch (_: Exception) {
            null
        }
    }

    fun delete(c: Context, name: String) {
        file(c, name)?.delete()
    }

    /** The CSS type for a data address of this font file. */
    fun mime(f: File): String = when (f.extension.lowercase()) {
        "otf" -> "font/otf"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        else -> "font/ttf"
    }
}
