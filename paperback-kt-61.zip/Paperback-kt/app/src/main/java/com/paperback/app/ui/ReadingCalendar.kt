package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

/** One book read on one day: how long and how many pages. */
class DayBook(val book: Book, val seconds: Long, val pages: Int)

/** For every day with reading, the books read that day, the one read longest first. */
fun readingByDay(sessions: List<ReadingSession>, books: List<Book>, zone: ZoneId): Map<LocalDate, List<DayBook>> {
    val byId = books.associateBy { it.id }
    return sessions
        .groupBy { Instant.ofEpochMilli(it.startMs).atZone(zone).toLocalDate() }
        .mapValues { (_, rows) ->
            rows.groupBy { it.bookId }.mapNotNull { (id, r) ->
                val b = byId[id] ?: return@mapNotNull null
                DayBook(b, r.sumOf { it.seconds.toLong() }, r.sumOf { it.pages })
            }.sortedByDescending { it.seconds }
        }
        .filterValues { it.isNotEmpty() }
}

private fun monthTitle(m: YearMonth): String =
    m.month.getDisplayName(TextStyle.FULL, Locale.getDefault()).replaceFirstChar { it.uppercase() } + " " + m.year

private fun dayTitle(d: LocalDate): String =
    d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()) + " " + d.dayOfMonth + " " +
        d.month.getDisplayName(TextStyle.SHORT, Locale.getDefault())

/**
 * A month as a calendar: each day you read shows the cover of the book you read (a second cover peeks out behind it
 * and a "+1" says there were more). [covers] = upright covers with the day number above, false = round covers with the
 * number on top. Tap a day with reading to pick it.
 */
@Composable
fun CalendarMonth(
    month: YearMonth,
    days: Map<LocalDate, List<DayBook>>,
    covers: Boolean,
    selected: LocalDate?,
    onPick: (LocalDate) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val today = LocalDate.now()
    val lead = month.atDay(1).dayOfWeek.value - 1
    val length = month.lengthOfMonth()
    val rows = (lead + length + 6) / 7
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (covers) 10.dp else 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 1..7) {
                Text(
                    DayOfWeek.of(i).getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    color = t.setSub,
                    fontSize = 12.sp,
                )
            }
        }
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (c in 0 until 7) {
                    val n = r * 7 + c - lead + 1
                    if (n < 1 || n > length) {
                        Spacer(Modifier.weight(1f))
                    } else {
                        val date = month.atDay(n)
                        val read = days[date].orEmpty()
                        if (covers) CoverDay(n, read, date == selected, date == today) { onPick(date) }
                        else RoundDay(n, read, date == selected, date == today) { onPick(date) }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.CoverDay(n: Int, read: List<DayBook>, selected: Boolean, isToday: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    val coral = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(6.dp)
    Column(
        Modifier.weight(1f).clickable(enabled = read.isNotEmpty(), onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "$n",
            color = if (selected || isToday) coral else if (read.isEmpty()) t.setSub.copy(alpha = 0.6f) else t.ink,
            fontSize = 12.sp,
            fontWeight = if (selected || isToday) FontWeight.SemiBold else FontWeight.Medium,
        )
        Spacer(Modifier.height(3.dp))
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f)) {
            if (read.isEmpty()) {
                Box(Modifier.matchParentSize().clip(shape).background(t.ink.copy(alpha = 0.05f)))
            } else {
                val more = read.size > 1
                if (more) {
                    CoverFill(read[1].book, shape, Modifier.matchParentSize().padding(start = 5.dp, top = 4.dp).alpha(0.6f))
                }
                CoverFill(
                    read[0].book, shape,
                    Modifier
                        .matchParentSize()
                        .padding(end = if (more) 5.dp else 0.dp, bottom = if (more) 4.dp else 0.dp)
                        .then(if (selected) Modifier.border(2.dp, coral, shape) else Modifier),
                )
                if (more) {
                    Box(
                        Modifier.align(Alignment.TopEnd).size(18.dp).clip(CircleShape).background(coral),
                        contentAlignment = Alignment.Center,
                    ) { Text("+${read.size - 1}", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun RowScope.RoundDay(n: Int, read: List<DayBook>, selected: Boolean, isToday: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    val coral = MaterialTheme.colorScheme.primary
    Box(
        Modifier
            .weight(1f)
            .aspectRatio(1f)
            .clip(CircleShape)
            .background(t.ink.copy(alpha = 0.07f))
            .then(if (selected) Modifier.border(2.dp, coral, CircleShape) else if (isToday) Modifier.border(1.dp, coral.copy(alpha = 0.7f), CircleShape) else Modifier)
            .clickable(enabled = read.isNotEmpty(), onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (read.isNotEmpty()) {
            CoverFill(read[0].book, CircleShape, Modifier.matchParentSize())
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.38f)))
        }
        Text(
            "$n",
            color = if (read.isEmpty()) t.setSub else Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

/** What was read on one day, one row a book. */
@Composable
fun DayBooksCard(date: LocalDate, read: List<DayBook>, onOpenBook: (Book) -> Unit, modifier: Modifier = Modifier) {
    val t = pbTokens()
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Eyebrow(dayTitle(date))
        read.forEach { d ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpenBook(d.book) },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CoverFill(d.book, RoundedCornerShape(6.dp), Modifier.width(36.dp).aspectRatio(2f / 3f))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.book.title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val bits = ArrayList<String>()
                    if (d.seconds >= 60) bits.add(Stats.duration(d.seconds))
                    if (d.pages > 0) bits.add(if (d.pages == 1) "1 page" else "${d.pages} pages")
                    Text(bits.joinToString(" · ").ifEmpty { "logged" }, color = t.setSub, fontSize = 13.sp)
                }
            }
        }
    }
}

/**
 * Your reading as a calendar, a month at a time, opened from the Reading rhythm card on Stats. Covers of what you read
 * each day, the month's figures above, and the books of a tapped day below.
 */
@Composable
fun ReadingCalendarScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenBook: (Book) -> Unit,
) {
    val t = pbTokens()
    val coral = MaterialTheme.colorScheme.primary
    val zone = remember { ZoneId.systemDefault() }
    val days = remember(sessions, books) { readingByDay(sessions, books, zone) }
    val bestStreak = remember(sessions) { Stats.longestStreak(Stats.secondsByDay(sessions, zone)) }
    val earliest = remember(days) { days.keys.minOrNull()?.let { YearMonth.from(it) } }
    var back by rememberSaveable { mutableIntStateOf(0) }
    var covers by rememberSaveable { mutableStateOf(true) }
    var picked by rememberSaveable { mutableLongStateOf(Long.MIN_VALUE) }
    val month = YearMonth.now().minusMonths(back.toLong())
    val inMonth = days.filterKeys { YearMonth.from(it) == month }
    val pages = inMonth.values.sumOf { list -> list.sumOf { it.pages } }
    val selected = if (picked == Long.MIN_VALUE) null else LocalDate.ofEpochDay(picked)

    PbListPage("Reading calendar", headerSize, onMenu, onSearch) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                val canBack = earliest != null && month.isAfter(earliest)
                Text(
                    "‹",
                    modifier = Modifier.clickable(enabled = canBack) { back += 1; picked = Long.MIN_VALUE }.padding(horizontal = 14.dp, vertical = 2.dp),
                    color = if (canBack) t.ink else t.setSub.copy(alpha = 0.4f),
                    fontSize = 30.sp,
                )
                Text(
                    monthTitle(month),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    color = t.ink,
                    fontFamily = PbSerif,
                    fontSize = 24.sp,
                )
                Text(
                    "›",
                    modifier = Modifier.clickable(enabled = back > 0) { back -= 1; picked = Long.MIN_VALUE }.padding(horizontal = 14.dp, vertical = 2.dp),
                    color = if (back > 0) t.ink else t.setSub.copy(alpha = 0.4f),
                    fontSize = 30.sp,
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Best streak", "$bestStreak", Modifier.weight(1f))
                StatTile("Days read", "${inMonth.size}", Modifier.weight(1f))
                StatTile("Pages", "$pages", Modifier.weight(1f))
            }
            PbSegmented(
                options = listOf(true to "Covers", false to "Circles"),
                selected = covers,
                onSelect = { covers = it },
                modifier = Modifier.width(220.dp),
            )
            CalendarMonth(month, days, covers, selected, onPick = { picked = if (it == selected) Long.MIN_VALUE else it.toEpochDay() })
            if (inMonth.isEmpty()) {
                Text("No reading this month.", color = t.setSub, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp))
            }
            val read = selected?.let { days[it] }.orEmpty()
            if (selected != null && read.isNotEmpty()) DayBooksCard(selected, read, onOpenBook)
        }
    }
}
