package com.paperback.app.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Plain SQLite on purpose: no annotation processor, so nothing to break the build. All calls block; use Dispatchers.IO. */
class PaperbackDb(context: Context) : SQLiteOpenHelper(context, "paperback.db", null, 9) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE books (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                language TEXT NOT NULL,
                file_path TEXT NOT NULL,
                cover_path TEXT,
                added_at INTEGER NOT NULL,
                last_opened_at INTEGER NOT NULL DEFAULT 0,
                progress REAL NOT NULL DEFAULT 0,
                position INTEGER NOT NULL DEFAULT 0,
                total_positions INTEGER NOT NULL DEFAULT 0,
                locator TEXT,
                finished INTEGER NOT NULL DEFAULT 0,
                favorite INTEGER NOT NULL DEFAULT 0,
                rating INTEGER NOT NULL DEFAULT 0,
                journal TEXT NOT NULL DEFAULT '',
                finished_at INTEGER NOT NULL DEFAULT 0,
                tags TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                publisher TEXT NOT NULL DEFAULT '',
                published TEXT NOT NULL DEFAULT '',
                meta_read INTEGER NOT NULL DEFAULT 0,
                rating10 REAL NOT NULL DEFAULT 0,
                custom_pages INTEGER NOT NULL DEFAULT 0,
                spine_color INTEGER NOT NULL DEFAULT 0,
                shelf_order INTEGER NOT NULL DEFAULT 0,
                started_at INTEGER NOT NULL DEFAULT 0,
                rated_at INTEGER NOT NULL DEFAULT 0,
                status INTEGER NOT NULL DEFAULT 0,
                status_at INTEGER NOT NULL DEFAULT 0,
                dropped_pct INTEGER NOT NULL DEFAULT 0,
                source TEXT NOT NULL DEFAULT '',
                format TEXT NOT NULL DEFAULT '',
                series TEXT NOT NULL DEFAULT '',
                series_no REAL NOT NULL DEFAULT 0,
                words INTEGER NOT NULL DEFAULT 0
            )""",
        )
        db.execSQL(
            """CREATE TABLE sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id TEXT NOT NULL,
                start_ms INTEGER NOT NULL,
                seconds INTEGER NOT NULL,
                pages INTEGER NOT NULL DEFAULT 0,
                from_pos INTEGER NOT NULL DEFAULT 0,
                to_pos INTEGER NOT NULL DEFAULT 0,
                source INTEGER NOT NULL DEFAULT 0,
                kind INTEGER NOT NULL DEFAULT 0,
                chapters INTEGER NOT NULL DEFAULT 0
            )""",
        )
        db.execSQL("CREATE INDEX idx_sessions_start ON sessions(start_ms)")
        createAnnotationTables(db)
        createCollectionTables(db)
        createHistoryTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createAnnotationTables(db) // bookmarks and highlights
        if (oldVersion < 3) {
            // step 4: journal, finish date, collections
            db.execSQL("ALTER TABLE books ADD COLUMN journal TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN finished_at INTEGER NOT NULL DEFAULT 0")
            createCollectionTables(db)
        }
        if (oldVersion < 4) {
            // tags / genres, description, publisher, date (meta_read = 0: read from the file once, after the update)
            db.execSQL("ALTER TABLE books ADD COLUMN tags TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN description TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN publisher TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN published TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN meta_read INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 5) {
            // reading entries: the first and last page of a session
            db.execSQL("ALTER TABLE sessions ADD COLUMN from_pos INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE sessions ADD COLUMN to_pos INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 6) {
            // 0 = counted by the reader, 1 = set by you (timer, hand-made or edited entry)
            db.execSQL("ALTER TABLE sessions ADD COLUMN source INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 7) {
            // book page: ratings with halves and quarters, your own page count, spine colour, place in "My order"
            db.execSQL("ALTER TABLE books ADD COLUMN rating10 REAL NOT NULL DEFAULT 0")
            db.execSQL("UPDATE books SET rating10 = rating * 2")
            db.execSQL("ALTER TABLE books ADD COLUMN custom_pages INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE books ADD COLUMN spine_color INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE books ADD COLUMN shelf_order INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 8) {
            // stats foundation: start and rating dates, paused / dropped, source, format, series, words,
            // what kind of session it was, every reading of a book, and the daily goal of each day
            db.execSQL("ALTER TABLE books ADD COLUMN started_at INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE books ADD COLUMN rated_at INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE books ADD COLUMN status INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE books ADD COLUMN status_at INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE books ADD COLUMN dropped_pct INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE books ADD COLUMN source TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN format TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN series TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE books ADD COLUMN series_no REAL NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE books ADD COLUMN words INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE sessions ADD COLUMN kind INTEGER NOT NULL DEFAULT 0")
            // sessions you made yourself are "logged" (2); the reader's own stay 0
            db.execSQL("UPDATE sessions SET kind = 2 WHERE source = 1")
            createHistoryTables(db)
            // the first reading entry of a book is the day you started it
            db.execSQL(
                "UPDATE books SET started_at = IFNULL((SELECT MIN(start_ms) FROM sessions WHERE sessions.book_id = books.id), 0)",
            )
            // a finished book is one finished reading; its dates are the ones we know
            db.execSQL(
                "INSERT INTO readings (book_id, started_at, finished_at, rating10) " +
                    "SELECT id, started_at, CASE WHEN finished_at > 0 THEN finished_at ELSE MAX(last_opened_at, added_at) END, rating10 " +
                    "FROM books WHERE finished = 1",
            )
            // a rated book gets the day it was last opened or added as its rating day, until you rate it again
            db.execSQL("UPDATE books SET rated_at = MAX(last_opened_at, added_at) WHERE rating10 > 0")
        }
        if (oldVersion < 9) {
            // chapters gone through in an entry (from imported history for now)
            db.execSQL("ALTER TABLE sessions ADD COLUMN chapters INTEGER NOT NULL DEFAULT 0")
        }
    }

    private fun createHistoryTables(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS readings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id TEXT NOT NULL,
                started_at INTEGER NOT NULL DEFAULT 0,
                finished_at INTEGER NOT NULL,
                rating10 REAL NOT NULL DEFAULT 0
            )""",
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_readings_book ON readings(book_id)")
        // the minutes-a-day goal as it was on each day, so changing the goal does not rewrite the past
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS goal_days (
                day INTEGER PRIMARY KEY,
                minutes INTEGER NOT NULL
            )""",
        )
    }

    private fun createCollectionTables(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS collections (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )""",
        )
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS collection_books (
                collection_id TEXT NOT NULL,
                book_id TEXT NOT NULL,
                PRIMARY KEY (collection_id, book_id)
            )""",
        )
    }

    private fun createAnnotationTables(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS bookmarks (
                id TEXT PRIMARY KEY,
                book_id TEXT NOT NULL,
                locator TEXT NOT NULL,
                position INTEGER NOT NULL,
                progress REAL NOT NULL,
                created_at INTEGER NOT NULL
            )""",
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_bookmarks_book ON bookmarks(book_id)")
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS highlights (
                id TEXT PRIMARY KEY,
                book_id TEXT NOT NULL,
                locator TEXT NOT NULL,
                text TEXT NOT NULL,
                note TEXT NOT NULL,
                color INTEGER NOT NULL,
                progress REAL NOT NULL,
                created_at INTEGER NOT NULL
            )""",
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_highlights_book ON highlights(book_id)")
    }

    fun allBooks(): List<Book> =
        readableDatabase.query("books", null, null, null, null, null, "added_at DESC").use { c ->
            buildList { while (c.moveToNext()) add(c.toBook()) }
        }

    fun hasBook(id: String): Boolean =
        readableDatabase.query("books", arrayOf("id"), "id = ?", arrayOf(id), null, null, null).use { it.moveToFirst() }

    /** Returns false when a book with this id already exists. */
    fun insertBook(b: Book): Boolean {
        val cv = ContentValues().apply {
            put("id", b.id)
            put("title", b.title)
            put("author", b.author)
            put("language", b.language)
            put("file_path", b.filePath)
            put("cover_path", b.coverPath)
            put("added_at", b.addedAt)
            put("total_positions", b.totalPositions)
            put("tags", b.tags.joinToString("\n"))
            put("description", b.description)
            put("publisher", b.publisher)
            put("published", b.published)
            put("meta_read", if (b.metaRead) 1 else 0)
        }
        return writableDatabase.insertWithOnConflict("books", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun updateProgress(id: String, locatorJson: String, progress: Float, position: Int, openedAt: Long) {
        val cv = ContentValues().apply {
            put("locator", locatorJson)
            put("progress", progress)
            put("position", position)
            put("last_opened_at", openedAt)
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun touchOpened(id: String, openedAt: Long) {
        val cv = ContentValues().apply { put("last_opened_at", openedAt) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setFlag(id: String, column: String, value: Boolean) {
        require(column == "finished" || column == "favorite")
        if (column == "finished") {
            setFinished(id, value)
            return
        }
        val cv = ContentValues().apply { put(column, if (value) 1 else 0) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    /** Marks a book finished (keeping the first finish date) or not finished. */
    fun setFinished(id: String, value: Boolean, record: Boolean = true) {
        if (value) {
            if (record) recordReading(id)
            writableDatabase.execSQL(
                "UPDATE books SET finished = 1, finished_at = CASE WHEN finished_at = 0 THEN ? ELSE finished_at END WHERE id = ?",
                arrayOf<Any?>(System.currentTimeMillis(), id),
            )
        } else {
            writableDatabase.execSQL("UPDATE books SET finished = 0, finished_at = 0 WHERE id = ?", arrayOf<Any?>(id))
        }
    }

    /** Adds one finished reading for a book that is being finished now (not when it already is). */
    private fun recordReading(id: String) {
        val d = writableDatabase
        val already = d.rawQuery("SELECT finished, started_at, rating10 FROM books WHERE id = ?", arrayOf(id)).use { c ->
            if (!c.moveToFirst()) return
            Triple(c.getInt(0) == 1, c.getLong(1), c.getFloat(2))
        }
        if (already.first) return
        // finishing, un-finishing and finishing again within hours is a slip, not a second reading
        val recent = d.rawQuery(
            "SELECT 1 FROM readings WHERE book_id = ? AND finished_at > ?",
            arrayOf(id, (System.currentTimeMillis() - 6L * 60L * 60L * 1000L).toString()),
        ).use { it.moveToFirst() }
        if (recent) return
        var started = already.second
        if (started <= 0L) {
            started = d.rawQuery("SELECT MIN(start_ms) FROM sessions WHERE book_id = ?", arrayOf(id)).use { c ->
                if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L
            }
        }
        d.execSQL(
            "INSERT INTO readings (book_id, started_at, finished_at, rating10) VALUES (?, ?, ?, ?)",
            arrayOf<Any?>(id, started, System.currentTimeMillis(), already.third.toDouble()),
        )
    }

    fun allReadings(): List<Reading> =
        readableDatabase.query("readings", null, null, null, null, null, "finished_at ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(Reading(c.lng("id"), c.str("book_id"), c.lng("started_at"), c.lng("finished_at"), c.getFloat(c.col("rating10"))))
                }
            }
        }

    /** Restoring a backup: a reading that is already stored (same book and finish time) is not added twice. */
    fun insertReading(bookId: String, startedAt: Long, finishedAt: Long, rating10: Double) {
        val d = writableDatabase
        val exists = d.rawQuery("SELECT 1 FROM readings WHERE book_id = ? AND finished_at = ?", arrayOf(bookId, finishedAt.toString())).use { it.moveToFirst() }
        if (exists) return
        d.execSQL(
            "INSERT INTO readings (book_id, started_at, finished_at, rating10) VALUES (?, ?, ?, ?)",
            arrayOf<Any?>(bookId, startedAt, finishedAt, rating10),
        )
    }

    /** Starting a book again: its finished flag goes, its readings stay. */
    fun startedAtFor(id: String): Long =
        readableDatabase.rawQuery("SELECT started_at FROM books WHERE id = ?", arrayOf(id)).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    fun setStartedAt(id: String, ms: Long) {
        val cv = ContentValues().apply { put("started_at", ms.coerceAtLeast(0L)) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setRatedAt(id: String, ms: Long) {
        val cv = ContentValues().apply { put("rated_at", ms.coerceAtLeast(0L)) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    /** Paused or dropped (see [BookStatus]), with the percent you had read; normal clears it. */
    fun setStatus(id: String, status: Int, atMs: Long, pct: Int) {
        val s = status.coerceIn(0, 2)
        val cv = ContentValues().apply {
            put("status", s)
            put("status_at", if (s == 0) 0L else atMs)
            put("dropped_pct", if (s == 0) 0 else pct.coerceIn(0, 100))
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    /** Where the book came from, how you read it, its series and word count. Null leaves a field as it is. */
    fun setBookFacts(id: String, source: String? = null, format: String? = null, series: String? = null, seriesNo: Float? = null, words: Int? = null) {
        val cv = ContentValues()
        source?.let { cv.put("source", it.trim()) }
        format?.let { cv.put("format", it.trim()) }
        series?.let { cv.put("series", it.trim()) }
        seriesNo?.let { cv.put("series_no", it.coerceAtLeast(0f)) }
        words?.let { cv.put("words", it.coerceAtLeast(0)) }
        if (cv.size() > 0) writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    // ---- daily goal history ---------------------------------------------------------------

    /** Saves the minutes goal in force on [epochDay] (today, when the app starts or the goal changes). */
    fun recordGoalDay(epochDay: Long, minutes: Int) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO goal_days (day, minutes) VALUES (?, ?)", arrayOf<Any?>(epochDay, minutes))
    }

    /** Days that have no saved goal yet get the goal they had last (so a gap does not hide a day). */
    fun goalDays(): Map<Long, Int> =
        readableDatabase.query("goal_days", null, null, null, null, null, "day ASC").use { c ->
            val out = LinkedHashMap<Long, Int>()
            while (c.moveToNext()) out[c.lng("day")] = c.int("minutes")
            out
        }

    /** Stores what was read from the book's file and its catalog, and marks the book as done. */
    fun setMeta(id: String, x: BookExtras) {
        val cv = ContentValues().apply {
            put("tags", x.tags.joinToString("\n"))
            put("description", x.description)
            put("publisher", x.publisher)
            put("published", x.published)
            put("meta_read", 1)
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setJournal(id: String, text: String) {
        val cv = ContentValues().apply { put("journal", text) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setRating(id: String, stars: Int) {
        val s = stars.coerceIn(0, 5)
        val cv = ContentValues().apply {
            put("rating", s)
            put("rating10", s * 2.0)
            put("rated_at", if (s > 0) System.currentTimeMillis() else 0L)
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    /** A rating on the 0..10 scale (halves and quarters of a star allowed); `rating` keeps the whole-star version. */
    fun setRating10(id: String, value: Double) {
        val v = value.coerceIn(0.0, 10.0)
        val cv = ContentValues().apply {
            put("rating", com.paperback.app.catalog.RatingMath.wholeStars(v))
            put("rating10", v)
            put("rated_at", if (v > 0.0) System.currentTimeMillis() else 0L)
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    /** Your own words for the book: title, author and the details shown on its page. */
    fun setDetails(id: String, title: String, author: String, description: String, publisher: String, published: String, tags: List<String>, language: String) {
        val cv = ContentValues().apply {
            put("title", title)
            put("author", author)
            put("description", description)
            put("publisher", publisher)
            put("published", published)
            put("tags", tags.joinToString("\n"))
            put("language", language)
            put("meta_read", 1)
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    /**
     * A book that was added without a file becomes [newId], the same book now with its file: what you recorded
     * (rating, finish date, favorite, journal, sessions, notes, bookmarks, collections) moves over and the old row goes.
     */
    fun adoptLogOnly(old: Book, newId: String) {
        val d = writableDatabase
        d.beginTransaction()
        try {
            d.execSQL(
                "UPDATE books SET favorite = ?, finished = ?, finished_at = ?, rating = ?, rating10 = ?, journal = ?, " +
                    "spine_color = ?, shelf_order = ?, added_at = MIN(added_at, ?), last_opened_at = MAX(last_opened_at, ?), " +
                    "started_at = ?, rated_at = ?, status = ?, status_at = ?, dropped_pct = ?, source = ?, format = ?, series = ?, series_no = ? WHERE id = ?",
                arrayOf<Any?>(
                    if (old.favorite) 1 else 0, if (old.finished) 1 else 0, old.finishedAt, old.rating, old.rating10.toDouble(),
                    old.journal, old.spineColor, old.shelfOrder, old.addedAt, old.lastOpenedAt,
                    old.startedAt, old.ratedAt, old.status, old.statusAt, old.droppedPct, old.source, old.format, old.series, old.seriesNo.toDouble(),
                    newId,
                ),
            )
            if (old.customPages > 0) d.execSQL("UPDATE books SET custom_pages = ? WHERE id = ?", arrayOf<Any?>(old.customPages, newId))
            if (old.finished) d.execSQL("UPDATE books SET progress = 1 WHERE id = ? AND progress < 1", arrayOf<Any?>(newId))
            for (table in listOf("sessions", "bookmarks", "highlights", "readings")) {
                d.execSQL("UPDATE $table SET book_id = ? WHERE book_id = ?", arrayOf<Any?>(newId, old.id))
            }
            d.execSQL("UPDATE OR IGNORE collection_books SET book_id = ? WHERE book_id = ?", arrayOf<Any?>(newId, old.id))
            d.execSQL("DELETE FROM collection_books WHERE book_id = ?", arrayOf<Any?>(old.id))
            d.execSQL("DELETE FROM books WHERE id = ?", arrayOf<Any?>(old.id))
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    /** The day a book was finished (ms). Only used when restoring a backup, so the real date comes back. */
    fun setFinishedAt(id: String, ms: Long) {
        val cv = ContentValues().apply { put("finished_at", ms.coerceAtLeast(0L)) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setCustomPages(id: String, pages: Int) {
        val cv = ContentValues().apply { put("custom_pages", pages.coerceAtLeast(0)) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setSpineColor(id: String, argb: Int) {
        val cv = ContentValues().apply { put("spine_color", argb) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setCoverPath(id: String, path: String?) {
        val cv = ContentValues().apply { put("cover_path", path) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setShelfOrders(order: List<String>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            order.forEachIndexed { i, id ->
                val cv = ContentValues().apply { put("shelf_order", i + 1) }
                db.update("books", cv, "id = ?", arrayOf(id))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Moves where you are in the book without opening it (entries, setting the page by hand). Keeps the resume place and the last-read time. */
    fun setPlace(id: String, progress: Float, position: Int) {
        val cv = ContentValues().apply {
            put("progress", progress.coerceIn(0f, 1f))
            put("position", position.coerceAtLeast(0))
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun deleteBook(id: String) {
        // Reading sessions stay: your history should survive removing a book.
        writableDatabase.delete("books", "id = ?", arrayOf(id))
        writableDatabase.delete("collection_books", "book_id = ?", arrayOf(id))
    }

    fun insertSession(bookId: String, startMs: Long, seconds: Int, pages: Int, fromPos: Int = 0, toPos: Int = 0, manual: Boolean = false, kind: Int = -1, chapters: Int = 0) {
        val k = if (kind >= 0) kind else if (manual) SessionKind.LOGGED else SessionKind.READ
        val cv = ContentValues().apply {
            put("book_id", bookId)
            put("start_ms", startMs)
            put("seconds", seconds)
            put("pages", pages)
            put("from_pos", fromPos)
            put("to_pos", toPos)
            put("source", if (manual) 1 else 0)
            put("kind", k)
            put("chapters", chapters.coerceAtLeast(0))
        }
        writableDatabase.insert("sessions", null, cv)
        // the earliest entry of a book is the day you started it
        if (startMs > 0L) {
            writableDatabase.execSQL(
                "UPDATE books SET started_at = ? WHERE id = ? AND (started_at = 0 OR started_at > ?)",
                arrayOf<Any?>(startMs, bookId, startMs),
            )
        }
    }

    fun updateSession(id: Long, startMs: Long, seconds: Int, pages: Int, fromPos: Int, toPos: Int) {
        val cv = ContentValues().apply {
            put("start_ms", startMs)
            put("seconds", seconds)
            put("pages", pages)
            put("from_pos", fromPos)
            put("to_pos", toPos)
            put("source", 1) // an entry you edit is yours from then on
            put("kind", SessionKind.LOGGED)
        }
        writableDatabase.update("sessions", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deleteSession(id: Long) {
        writableDatabase.delete("sessions", "id = ?", arrayOf(id.toString()))
    }

    fun allSessions(): List<ReadingSession> =
        readableDatabase.query("sessions", null, null, null, null, null, "start_ms ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        ReadingSession(
                            id = c.lng("id"),
                            bookId = c.str("book_id"),
                            startMs = c.lng("start_ms"),
                            seconds = c.int("seconds"),
                            pages = c.int("pages"),
                            fromPos = c.int("from_pos"),
                            toPos = c.int("to_pos"),
                            manual = c.int("source") == 1,
                            kind = c.int("kind"),
                            chapters = c.int("chapters"),
                        ),
                    )
                }
            }
        }

    // ---- bookmarks ------------------------------------------------------------------------

    fun bookmarksFor(bookId: String): List<Bookmark> =
        readableDatabase.query("bookmarks", null, "book_id = ?", arrayOf(bookId), null, null, "progress ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Bookmark(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            position = c.int("position"), progress = c.getFloat(c.col("progress")),
                            createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    fun insertBookmark(b: Bookmark) {
        val cv = ContentValues().apply {
            put("id", b.id)
            put("book_id", b.bookId)
            put("locator", b.locatorJson)
            put("position", b.position)
            put("progress", b.progress)
            put("created_at", b.createdAt)
        }
        writableDatabase.insertWithOnConflict("bookmarks", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteBookmark(id: String) {
        writableDatabase.delete("bookmarks", "id = ?", arrayOf(id))
    }

    // ---- highlights and notes -------------------------------------------------------------

    fun highlightsFor(bookId: String): List<Highlight> =
        readableDatabase.query("highlights", null, "book_id = ?", arrayOf(bookId), null, null, "progress ASC, created_at ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Highlight(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            text = c.str("text"), note = c.str("note"), color = c.int("color"),
                            progress = c.getFloat(c.col("progress")), createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    fun insertHighlight(h: Highlight) {
        val cv = ContentValues().apply {
            put("id", h.id)
            put("book_id", h.bookId)
            put("locator", h.locatorJson)
            put("text", h.text)
            put("note", h.note)
            put("color", h.color)
            put("progress", h.progress)
            put("created_at", h.createdAt)
        }
        writableDatabase.insertWithOnConflict("highlights", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun updateHighlight(id: String, note: String, color: Int) {
        val cv = ContentValues().apply {
            put("note", note)
            put("color", color)
        }
        writableDatabase.update("highlights", cv, "id = ?", arrayOf(id))
    }

    fun deleteHighlight(id: String) {
        writableDatabase.delete("highlights", "id = ?", arrayOf(id))
    }

    // ---- notes across all books -----------------------------------------------------------

    fun allHighlights(): List<Highlight> =
        readableDatabase.query("highlights", null, null, null, null, null, "created_at DESC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Highlight(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            text = c.str("text"), note = c.str("note"), color = c.int("color"),
                            progress = c.getFloat(c.col("progress")), createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    fun allBookmarks(): List<Bookmark> =
        readableDatabase.query("bookmarks", null, null, null, null, null, "created_at DESC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Bookmark(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            position = c.int("position"), progress = c.getFloat(c.col("progress")),
                            createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    // ---- collections ----------------------------------------------------------------------

    fun allCollections(): List<BookCollection> =
        readableDatabase.query("collections", null, null, null, null, null, "name COLLATE NOCASE ASC").use { c ->
            buildList { while (c.moveToNext()) add(BookCollection(c.str("id"), c.str("name"), c.lng("created_at"))) }
        }

    /** collection id -> ids of the books in it */
    fun collectionMembers(): Map<String, Set<String>> =
        readableDatabase.query("collection_books", null, null, null, null, null, null).use { c ->
            val out = HashMap<String, MutableSet<String>>()
            while (c.moveToNext()) out.getOrPut(c.str("collection_id")) { mutableSetOf() }.add(c.str("book_id"))
            out
        }

    fun upsertCollection(c: BookCollection) {
        val cv = ContentValues().apply {
            put("id", c.id)
            put("name", c.name)
            put("created_at", c.createdAt)
        }
        writableDatabase.insertWithOnConflict("collections", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteCollection(id: String) {
        writableDatabase.delete("collection_books", "collection_id = ?", arrayOf(id))
        writableDatabase.delete("collections", "id = ?", arrayOf(id))
    }

    fun setMember(collectionId: String, bookId: String, member: Boolean) {
        if (member) {
            val cv = ContentValues().apply {
                put("collection_id", collectionId)
                put("book_id", bookId)
            }
            writableDatabase.insertWithOnConflict("collection_books", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        } else {
            writableDatabase.delete("collection_books", "collection_id = ? AND book_id = ?", arrayOf(collectionId, bookId))
        }
    }

    private fun Cursor.col(name: String) = getColumnIndexOrThrow(name)
    private fun Cursor.str(name: String): String = getString(col(name))
    private fun Cursor.strOrNull(name: String): String? = if (isNull(col(name))) null else getString(col(name))
    private fun Cursor.int(name: String): Int = getInt(col(name))
    private fun Cursor.lng(name: String): Long = getLong(col(name))

    private fun Cursor.toBook() = Book(
        id = str("id"),
        title = str("title"),
        author = str("author"),
        language = str("language"),
        filePath = str("file_path"),
        coverPath = strOrNull("cover_path"),
        addedAt = lng("added_at"),
        lastOpenedAt = lng("last_opened_at"),
        progress = getFloat(col("progress")),
        position = int("position"),
        totalPositions = int("total_positions"),
        locatorJson = strOrNull("locator"),
        finished = int("finished") == 1,
        favorite = int("favorite") == 1,
        rating = int("rating"),
        journal = str("journal"),
        finishedAt = lng("finished_at"),
        tags = str("tags").split('\n').filter { it.isNotBlank() },
        description = str("description"),
        publisher = str("publisher"),
        published = str("published"),
        metaRead = int("meta_read") == 1,
        rating10 = getFloat(col("rating10")),
        customPages = int("custom_pages"),
        spineColor = int("spine_color"),
        shelfOrder = int("shelf_order"),
        startedAt = lng("started_at"),
        ratedAt = lng("rated_at"),
        status = int("status"),
        statusAt = lng("status_at"),
        droppedPct = int("dropped_pct"),
        source = str("source"),
        format = str("format"),
        series = str("series"),
        seriesNo = getFloat(col("series_no")),
        words = int("words"),
    )
}
