package com.paperback.app.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.FOOTER_BAR
import com.paperback.app.data.FOOTER_BATTERY
import com.paperback.app.data.FOOTER_CLOCK
import com.paperback.app.data.FOOTER_LEFT_PAGES
import com.paperback.app.data.FOOTER_TIME_LEFT
import com.paperback.app.data.Stats
import com.paperback.app.data.FOOTER_PERCENT
import com.paperback.app.data.FOOTER_TOTAL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

/**
 * The page frame, copied from Readest (TypeScript Paperback): by default the text stays 64 dp clear of the top of the screen and 44 dp
 * clear of the bottom. Both are now sliders (Top / Bottom), and the chapter name has its own Header slider. The sides follow Readest too (see ReaderSettings.toEpubPreferences).
 */
val ReaderTopFrame: Dp = 64.dp
val ReaderBottomFrame: Dp = 44.dp

/**
 * The small, quiet text around the page, as in Readest: the chapter name at the top, and a footer of up to six small items
 * (see the FOOTER_ flags in ReaderSettings): "N pages left", the percent read and the time left on the bottom left; the battery,
 * the clock and "position / total" on the bottom right; and a thin progress line along the very bottom. "Pages left" counts real
 * screens, so it drops by one for each page you turn; the counter counts fixed pieces of text, so it can move by more than one.
 * Hidden while the reader's controls are showing (they cover this strip).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderMarginInfo(
    themeIndex: Int,
    hidden: Boolean,
    chapter: String,
    pagesLeft: Int,
    position: Int,
    totalPositions: Int,
    headerSpace: Float = 40f,
    bottomSpace: Float = 44f,
    percent: Float = 0f,
    footerItems: Int = FOOTER_LEFT_PAGES or FOOTER_TOTAL,
    showHeader: Boolean = true,
    headerSize: Float = 12f,
    footerSize: Float = 12f,
    secondsLeft: Long? = null,
) {
    val c = readerColors(themeIndex)
    val context = LocalContext.current
    // The clock and the battery are read again every 20 seconds.
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            now = System.currentTimeMillis()
        }
    }
    // The chapter name sits headerSpace dp below the top edge, wherever the text starts; the counters stay on the bottom edge.
    val bottomFrame = maxOf(bottomSpace, 20f).dp
    val color = c.ink.copy(alpha = 0.55f)
    AnimatedVisibility(visible = !hidden, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, top = headerSpace.dp),
                contentAlignment = Alignment.TopStart,
            ) {
                if (showHeader && chapter.isNotBlank()) {
                    Text(chapter, color = color, fontSize = headerSize.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (footerItems and FOOTER_BAR != 0) {
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(2.dp).background(c.ink.copy(alpha = 0.12f))) {
                    Box(Modifier.fillMaxWidth(percent.coerceIn(0f, 1f)).height(2.dp).background(c.ink.copy(alpha = 0.5f)))
                }
            }
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(bottomFrame)
                    .padding(start = 18.dp, end = 18.dp, bottom = if (footerItems and FOOTER_BAR != 0) 4.dp else 0.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                val left = buildList {
                    if (footerItems and FOOTER_LEFT_PAGES != 0 && pagesLeft > 0) add("$pagesLeft ${if (pagesLeft == 1) "page" else "pages"} left")
                    if (footerItems and FOOTER_PERCENT != 0) add("%.1f%%".format(percent.coerceIn(0f, 1f) * 100f))
                    if (footerItems and FOOTER_TIME_LEFT != 0 && secondsLeft != null) add(Stats.duration(secondsLeft) + " left")
                }.joinToString("  \u00B7  ")
                val right = buildList {
                    if (footerItems and FOOTER_BATTERY != 0) batteryPercent(context, now)?.let { add("$it%") }
                    if (footerItems and FOOTER_CLOCK != 0) add(clockText(context, now))
                    if (footerItems and FOOTER_TOTAL != 0 && position > 0 && totalPositions > 0) add("$position / $totalPositions")
                }.joinToString("  \u00B7  ")
                Text(
                    left,
                    modifier = Modifier.weight(1f),
                    color = color,
                    fontSize = footerSize.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (right.isNotEmpty()) Text(right, color = color, fontSize = footerSize.sp, maxLines = 1)
            }
        }
    }
}

/** The battery level, 0 to 100, or null when the phone does not say. [tick] only makes this read again when the time changes. */
@Suppress("UNUSED_PARAMETER")
private fun batteryPercent(context: Context, tick: Long): Int? {
    val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    return if (level < 0 || scale <= 0) null else level * 100 / scale
}

/** The time of day, in the phone's 12 or 24 hour style. */
private fun clockText(context: Context, millis: Long): String {
    val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm a"
    return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
}
