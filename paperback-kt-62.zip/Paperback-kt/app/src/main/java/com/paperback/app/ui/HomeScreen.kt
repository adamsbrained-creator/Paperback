package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.draw.clip
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.Ranker
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.catalog.Load
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.RecentView
import com.paperback.app.data.Recommendation
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.data.RecapRow
import java.time.LocalDate

@Composable
fun HomeScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    recommended: List<Recommendation>,
    goalMinutes: Int,
    onOpen: (Book) -> Unit,
    onRead: (Book) -> Unit,
    onDetails: (Book) -> Unit,
    onImport: () -> Unit,
    onDiscover: () -> Unit,
    catalog: CatalogController,
    wishlist: List<CatalogBook>,
    onOpenCatalogBook: (CatalogBook) -> Unit,
    onBrowse: (kind: String, value: String) -> Unit,
    recentView: RecentView = RecentView.Spines,
    onRecentView: (RecentView) -> Unit = {},
    /** Last month's recap, while it waits to be opened. */
    recap: RecapRow? = null,
    onOpenRecap: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val today = LocalDate.now()
    val byDay = remember(sessions) { Stats.secondsByDay(sessions) }
    val pace = remember(sessions) { Stats.paceSecondsPerPosition(sessions) }
    val todaySeconds = byDay[today] ?: 0L
    val streak = Stats.currentStreak(byDay, today)

    val next = remember(books) {
        books.filter { it.isReading && it.hasFile }.maxByOrNull { it.lastOpenedAt } ?: books.firstOrNull { !it.finished && it.hasFile }
    }
    val recent = remember(books, next) {
        books.filter { it.lastOpenedAt > 0 && it.id != next?.id }.sortedByDescending { it.lastOpenedAt }.take(10)
    }

    val onlineOn by catalog.enabled.collectAsStateWithLifecycle()
    val forYou by catalog.forYou.collectAsStateWithLifecycle()
    val owned = remember(books) { ownedKeys(books) }
    LaunchedEffect(onlineOn, books) { catalog.refresh() }
    val fy = forYou
    val picks: List<Ranker.Pick> = if (fy is Load.Ready) fy.value else emptyList()

    val favorites = remember(books) { books.filter { it.favorite }.sortedByDescending { it.lastOpenedAt } }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        if (recap != null) {
            RecapBanner(recap, onOpenRecap)
            Spacer(Modifier.height(22.dp))
        }
        Eyebrow("Continue reading")
        Spacer(Modifier.height(12.dp))

        if (next == null) {
            LibraryEmpty(onImport = onImport, onDiscover = onDiscover)
        } else {
            Row(Modifier.fillMaxWidth()) {
                BookCover(next, Modifier.width(132.dp).clickable { onOpen(next) })
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        next.title,
                        modifier = Modifier.clickable { onDetails(next) },
                        fontFamily = PbSerif,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (next.author.isNotBlank()) {
                        Text(next.author, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(14.dp))
                    if (next.currentPage > 0 && next.pageCount > 0) {
                        Text("Page ${next.currentPage} of ${next.pageCount}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    ProgressTrack(next.progress)
                    Spacer(Modifier.height(8.dp))
                    val left = Stats.timeLeftSeconds(next, pace)?.let { " · ${Stats.duration(it)} left" } ?: ""
                    Text("${next.percent}%$left", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            PbButton(if (next.isReading) "Resume reading" else "Start reading", onClick = { onRead(next) })
        }

        Spacer(Modifier.height(28.dp))
        Eyebrow("Today")
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GoalRingTile(todaySeconds, goalMinutes, Modifier.weight(1.25f).fillMaxHeight())
            StatTile("Streak", if (streak == 1) "1 day" else "$streak days", Modifier.weight(1f).fillMaxHeight())
        }

        if (favorites.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            Eyebrow("Favorites")
            Spacer(Modifier.height(14.dp))
            BookShelf(favorites, leanId = null, onClick = onOpen, maxRows = 1)
        }

        if (recent.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            RecentHeader(recentView, onRecentView)
            when (recentView) {
                // The book you had open last leans on the others, the way you leave one on a real shelf.
                RecentView.Spines -> BookShelf(recent, leanId = recent.first().id, onClick = onOpen, maxRows = 2)
                RecentView.ShelfCovers -> CoverShelf(recent, onClick = onOpen, maxRows = 2)
                RecentView.CoverRow -> RecentCoverRow(recent, onOpen)
                RecentView.List -> RecentList(recent.take(5), onOpen)
            }
        }

        if (recommended.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            Eyebrow("Recommended for you")
            Spacer(Modifier.height(14.dp))
            BookShelf(recommended.map { it.book }, leanId = null, onClick = onDetails, maxRows = 1)
        }
        if (wishlist.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            HomeHeader("Want to read", onAll = { onBrowse("want", "") })
            CatalogRow(wishlist.take(12), owned, onOpen = onOpenCatalogBook)
        }

        if (onlineOn && picks.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            HomeHeader("Books you might like", onAll = { onBrowse("foryou", "") })
            CatalogRow(
                picks.take(10).map { it.book },
                owned,
                notes = picks.associate { it.book.id to it.reason },
                onOpen = onOpenCatalogBook,
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** "Recently read" with a small menu on the right to pick how the books are shown. */
@Composable
private fun RecentHeader(view: RecentView, onView: (RecentView) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) { Eyebrow("Recently read") }
        Box {
            Text(
                "${view.label} ▾",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { open = true }.padding(horizontal = 8.dp, vertical = 6.dp),
            )
            PbMenu(expanded = open, onDismiss = { open = false }) {
                RecentView.values().forEach { v ->
                    DropdownMenuItem(
                        text = { Text((if (v == view) "✓ " else "") + v.label) },
                        onClick = { open = false; onView(v) },
                    )
                }
            }
        }
    }
}

/** Covers in a row you swipe sideways, each with its title and author. */
@Composable
private fun RecentCoverRow(books: List<Book>, onOpen: (Book) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(books, key = { it.id }) { book ->
            Column(Modifier.width(112.dp).clip(RoundedCornerShape(12.dp)).clickable { onOpen(book) }) {
                BookCover(book, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(book.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (book.author.isNotBlank()) {
                    Text(book.author, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (book.isReading) {
                    Spacer(Modifier.height(6.dp))
                    ProgressTrack(book.progress, height = 4.dp)
                } else if (book.finished) {
                    Text("Finished", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

/** One line per book: small cover, title, author and where you are in it. */
@Composable
private fun RecentList(books: List<Book>, onOpen: (Book) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        books.forEach { book ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onOpen(book) },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BookCover(book, Modifier.width(56.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(book.title, fontFamily = PbSerif, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (book.author.isNotBlank()) {
                        Text(book.author, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (book.isReading) {
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { ProgressTrack(book.progress, height = 4.dp) }
                            Spacer(Modifier.width(10.dp))
                            Text("${book.percent}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else if (book.finished) {
                        Spacer(Modifier.height(4.dp))
                        Text("Finished", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

/** A Home section title with "View all" on the right. */
@Composable
private fun HomeHeader(text: String, onAll: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) { Eyebrow(text) }
        Text(
            "View all",
            color = MaterialTheme.colorScheme.primary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onAll).padding(horizontal = 8.dp, vertical = 6.dp),
        )
    }
}
