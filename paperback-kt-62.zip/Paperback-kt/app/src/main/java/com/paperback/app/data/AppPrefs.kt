package com.paperback.app.data

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.Coral
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Settings → App style → Header. The three sizes of the TypeScript app, plus one with the buttons and no wordmark. */
enum class HeaderSize(val label: String) {
    Compact("Compact"),
    Regular("Regular"),
    Large("Large"),
    Minimal("Buttons only"),
}

/** Settings → App style → Navigation. */
enum class NavStyle(val label: String) {
    Bar("Bar"),
    Clean("Clean"),
}

/** Settings → App style → Daily goal: how the goal on Stats → Activity is drawn. */
enum class GoalStyle(val label: String) {
    Ring("Ring"),
    Cover("Cover"),
    Bar("Bar"),
}

/** Settings → App style → More page: how the More page lays its pages out. */
enum class MoreStyle(val label: String) {
    Accordion("Accordion"),
    Bento("Bento"),
}

/** Home → Recently read: how the recent books are drawn. */
enum class RecentView(val label: String) {
    Spines("Spines"),
    ShelfCovers("Covers on shelf"),
    CoverRow("Cover row"),
    List("List"),
}

/** Settings → Appearance. */
enum class ThemeMode(val label: String) {
    System("Match system"),
    Light("Light"),
    Dark("Dark"),
}

/** Reading goals (port of app/stats/goals.ts). Anything that is not a sensible number falls back to the default. */
data class Goals(
    val booksPerYear: Int = 24,
    val pagesPerDay: Int = 30,
    val minutesPerDay: Int = 30,
    val streakDays: Int = 30,
) {
    fun normalized(): Goals = Goals(
        booksPerYear = sane(booksPerYear, DEFAULT.booksPerYear),
        pagesPerDay = sane(pagesPerDay, DEFAULT.pagesPerDay),
        minutesPerDay = sane(minutesPerDay, DEFAULT.minutesPerDay),
        streakDays = sane(streakDays, DEFAULT.streakDays),
    )

    companion object {
        val DEFAULT = Goals()
        private fun sane(v: Int, fallback: Int): Int = if (v in 1..99999) v else fallback
    }
}

/** The app's own choices (look and goals), kept on this device. Each one is a flow so screens update at once. */
class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("app", Context.MODE_PRIVATE)

    private val _headerSize = MutableStateFlow(
        HeaderSize.values().firstOrNull { it.name == sp.getString("headerSize", null) } ?: HeaderSize.Regular,
    )
    val headerSize: StateFlow<HeaderSize> = _headerSize.asStateFlow()

    fun setHeaderSize(value: HeaderSize) {
        _headerSize.value = value
        sp.edit().putString("headerSize", value.name).apply()
    }

    private val _navStyle = MutableStateFlow(
        NavStyle.values().firstOrNull { it.name == sp.getString("navStyle", null) } ?: NavStyle.Bar,
    )
    val navStyle: StateFlow<NavStyle> = _navStyle.asStateFlow()

    private val _moreStyle = MutableStateFlow(
        MoreStyle.values().firstOrNull { it.name == sp.getString("moreStyle", null) } ?: MoreStyle.Accordion,
    )
    val moreStyle: StateFlow<MoreStyle> = _moreStyle.asStateFlow()

    fun setMoreStyle(value: MoreStyle) {
        _moreStyle.value = value
        sp.edit().putString("moreStyle", value.name).apply()
    }

    private val _goalStyle = MutableStateFlow(
        GoalStyle.values().firstOrNull { it.name == sp.getString("goalStyle", null) } ?: GoalStyle.Ring,
    )
    val goalStyle: StateFlow<GoalStyle> = _goalStyle.asStateFlow()

    fun setGoalStyle(value: GoalStyle) {
        _goalStyle.value = value
        sp.edit().putString("goalStyle", value.name).apply()
    }

    private val _openBookPage = MutableStateFlow(sp.getBoolean("openBookPage", true))
    /** true = tapping a book opens its page (read, timer, entries); false = it opens the reader at once. */
    val openBookPage: StateFlow<Boolean> = _openBookPage.asStateFlow()

    fun setOpenBookPage(value: Boolean) {
        _openBookPage.value = value
        sp.edit().putBoolean("openBookPage", value).apply()
    }

    private val _swipeBack = MutableStateFlow(sp.getBoolean("swipeBack", true))
    /** Swipe to the right anywhere on a page that is not a main page to go back. */
    val swipeBack: StateFlow<Boolean> = _swipeBack.asStateFlow()

    fun setSwipeBack(value: Boolean) {
        _swipeBack.value = value
        sp.edit().putBoolean("swipeBack", value).apply()
    }

    private val _swipeTabs = MutableStateFlow(sp.getBoolean("swipeTabs", false))
    /** Swipe left or right on Home, Library, Stats and Settings to move to the next or previous one. */
    val swipeTabs: StateFlow<Boolean> = _swipeTabs.asStateFlow()

    fun setSwipeTabs(value: Boolean) {
        _swipeTabs.value = value
        sp.edit().putBoolean("swipeTabs", value).apply()
    }

    private val _ratingScale = MutableStateFlow(if (sp.getInt("ratingScale", 5) == 10) 10 else 5)
    /** The number next to the stars: out of 5 or out of 10. The bar always has five stars. */
    val ratingScale: StateFlow<Int> = _ratingScale.asStateFlow()

    fun setRatingScale(value: Int) {
        val v = if (value == 10) 10 else 5
        _ratingScale.value = v
        sp.edit().putInt("ratingScale", v).apply()
    }

    private val _ratingSteps = MutableStateFlow(sp.getInt("ratingSteps", 2).let { if (it == 1 || it == 4) it else 2 })
    /** How fine a rating is: 1 = whole numbers, 2 = halves, 4 = quarters. */
    val ratingSteps: StateFlow<Int> = _ratingSteps.asStateFlow()

    fun setRatingSteps(value: Int) {
        val v = if (value == 1 || value == 4) value else 2
        _ratingSteps.value = v
        sp.edit().putInt("ratingSteps", v).apply()
    }

    /** A cover link that came with an imported book (from a Bookshelf backup). Used once, in place of whatever the catalog offers. */
    fun coverHint(id: String): String? = sp.getString("coverHint:$id", null)
    fun setCoverHint(id: String, url: String) { sp.edit().putString("coverHint:$id", url).apply() }

    private val _catalogOnline = MutableStateFlow(sp.getBoolean("catalogOnline", true))
    /** Whether Search may ask the online catalog (Open Library) for trending and recommended books. */
    val catalogOnline: StateFlow<Boolean> = _catalogOnline.asStateFlow()

    fun setCatalogOnline(value: Boolean) {
        _catalogOnline.value = value
        sp.edit().putBoolean("catalogOnline", value).apply()
    }

    /** Stats -> Reading rhythm shows this month as a calendar of covers instead of the squares. */
    private val _rhythmCalendar = MutableStateFlow(sp.getBoolean("rhythmCalendar", false))
    val rhythmCalendar: StateFlow<Boolean> = _rhythmCalendar.asStateFlow()
    fun setRhythmCalendar(value: Boolean) {
        _rhythmCalendar.value = value
        sp.edit().putBoolean("rhythmCalendar", value).apply()
    }

    private val _libraryShelf = MutableStateFlow(sp.getBoolean("libraryShelf", true))
    /** true = books stand on shelves (spines); false = the grid of covers. */
    val libraryShelf: StateFlow<Boolean> = _libraryShelf.asStateFlow()

    fun setLibraryShelf(value: Boolean) {
        _libraryShelf.value = value
        sp.edit().putBoolean("libraryShelf", value).apply()
    }

    private val _recentView = MutableStateFlow(
        RecentView.values().firstOrNull { it.name == sp.getString("recentView", null) } ?: RecentView.Spines,
    )
    /** How Home's "Recently read" section looks. Spines is the original look. */
    val recentView: StateFlow<RecentView> = _recentView.asStateFlow()

    fun setRecentView(value: RecentView) {
        _recentView.value = value
        sp.edit().putString("recentView", value.name).apply()
    }

    fun setNavStyle(value: NavStyle) {
        _navStyle.value = value
        sp.edit().putString("navStyle", value.name).apply()
    }

    private val _iconStyle = MutableStateFlow(
        IconStyle.values().firstOrNull { it.name == sp.getString("iconStyle", null) } ?: IconStyle.Glassy,
    )
    /** The launcher icon. This only remembers the choice; [AppIcon.apply] switches the real icon. */
    val iconStyle: StateFlow<IconStyle> = _iconStyle.asStateFlow()

    fun setIconStyle(value: IconStyle) {
        _iconStyle.value = value
        sp.edit().putString("iconStyle", value.name).apply()
    }

    /** The accent colour as an ARGB number. Setting it also repaints the whole app (see [Accent]). */
    private val _accent = MutableStateFlow(sp.getInt("accent", Coral.toArgb()).let { 0xFF000000.toInt() or it })
    val accent: StateFlow<Int> = _accent.asStateFlow()

    init {
        Accent.color = Color(_accent.value)
    }

    fun setAccent(argb: Int) {
        val v = 0xFF000000.toInt() or argb
        _accent.value = v
        Accent.color = Color(v)
        sp.edit().putInt("accent", v).apply()
    }

    private val _themeMode = MutableStateFlow(
        ThemeMode.values().firstOrNull { it.name == sp.getString("themeMode", null) } ?: ThemeMode.System,
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    fun setThemeMode(value: ThemeMode) {
        _themeMode.value = value
        sp.edit().putString("themeMode", value.name).apply()
    }

    private val _goals = MutableStateFlow(
        Goals(
            booksPerYear = sp.getInt("goalBooks", Goals.DEFAULT.booksPerYear),
            pagesPerDay = sp.getInt("goalPages", Goals.DEFAULT.pagesPerDay),
            minutesPerDay = sp.getInt("goalMinutes", Goals.DEFAULT.minutesPerDay),
            streakDays = sp.getInt("goalStreak", Goals.DEFAULT.streakDays),
        ).normalized(),
    )
    val goals: StateFlow<Goals> = _goals.asStateFlow()

    fun setGoals(value: Goals) {
        val g = value.normalized()
        _goals.value = g
        sp.edit()
            .putInt("goalBooks", g.booksPerYear)
            .putInt("goalPages", g.pagesPerDay)
            .putInt("goalMinutes", g.minutesPerDay)
            .putInt("goalStreak", g.streakDays)
            .apply()
    }

    private val _recapGenerated = MutableStateFlow(sp.getStringSet("recapGenerated", emptySet())?.toSet() ?: emptySet())
    /** The months whose recap you opened ("2026-09"). The reminder only asks about a month that is not in here. */
    val recapGenerated: StateFlow<Set<String>> = _recapGenerated.asStateFlow()

    fun addRecapGenerated(keys: Collection<String>) {
        val next = _recapGenerated.value + keys
        if (next == _recapGenerated.value) return
        _recapGenerated.value = next
        sp.edit().putStringSet("recapGenerated", next).apply()
    }

    private val _recapRemind = MutableStateFlow(sp.getBoolean("recapRemind", true))
    /** Ask on Home when last month's recap is ready. */
    val recapRemind: StateFlow<Boolean> = _recapRemind.asStateFlow()

    fun setRecapRemind(value: Boolean) {
        _recapRemind.value = value
        sp.edit().putBoolean("recapRemind", value).apply()
    }

    private val _recapSnoozeUntil = MutableStateFlow(sp.getLong("recapSnoozeUntil", 0L))
    /** "Maybe later" on the reminder: it stays quiet until this time (ms). */
    val recapSnoozeUntil: StateFlow<Long> = _recapSnoozeUntil.asStateFlow()

    fun snoozeRecap(untilMs: Long) {
        _recapSnoozeUntil.value = untilMs
        sp.edit().putLong("recapSnoozeUntil", untilMs).apply()
    }
}
