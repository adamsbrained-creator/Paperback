package com.paperback.app.ui

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.RECAP_LENGTHS
import com.paperback.app.data.RecapDay
import com.paperback.app.data.recapPartOf
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow

/** A round step for one of three equal gaps on an axis: 1, 2, 5 or 10 times a power of ten. */
internal fun niceStep(v: Float): Float {
    if (v <= 0f) return 1f
    val exp = 10.0.pow(floor(log10(v.toDouble()))).toFloat()
    val f = v / exp
    return (if (f <= 1f) 1f else if (f <= 2f) 2f else if (f <= 5f) 5f else 10f) * exp
}

/** "45m", "1h", "1h20" for a number of minutes (axis labels). */
internal fun axisMinutes(m: Float): String {
    val n = m.toInt()
    return when {
        n <= 0 -> "0"
        n < 60 -> "${n}m"
        n % 60 == 0 -> "${n / 60}h"
        else -> "${n / 60}h${n % 60}"
    }
}

// ---- a bar for every day of the month ---------------------------------------------------------

/**
 * One bar per day with a grid, a dashed average line and day numbers. Tap a bar to select it ([onSelect] gets its
 * index, or null when the same bar is tapped again); the caller shows what the selected day says.
 */
@Composable
internal fun DailyBars(
    values: List<Float>,
    accent: Color,
    selected: Int?,
    average: Float?,
    format: (Float) -> String,
    xLabel: (Int) -> String,
    onSelect: (Int?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val track = trackColor()
    val grid = t.ink.copy(alpha = 0.10f)
    val labelColor = t.setSub.toArgb()
    val paint = remember { Paint().apply { isAntiAlias = true } }
    val peak = values.maxOrNull() ?: 0f
    val step = niceStep(peak / 3f)
    val top = step * 3f

    Canvas(
        modifier
            .fillMaxWidth()
            .height(190.dp)
            .pointerInput(values.size, selected) {
                detectTapGestures { p ->
                    val left = 38.dp.toPx()
                    val slot = (size.width - left) / max(1, values.size)
                    val i = ((p.x - left) / slot).toInt()
                    if (p.x >= left && i in values.indices) onSelect(if (i == selected) null else i) else onSelect(null)
                }
            },
    ) {
        val left = 38.dp.toPx()
        val bottom = 22.dp.toPx()
        val topPad = 8.dp.toPx()
        val chartH = size.height - bottom - topPad
        val slot = (size.width - left) / max(1, values.size)
        val barW = max(3.dp.toPx(), slot * 0.5f)
        val baseY = topPad + chartH

        paint.textSize = 10.sp.toPx()
        paint.color = labelColor
        paint.textAlign = Paint.Align.RIGHT
        for (k in 0..3) {
            val y = topPad + chartH * (1f - k / 3f)
            drawLine(grid, Offset(left, y), Offset(size.width, y), strokeWidth = 1.dp.toPx())
            drawContext.canvas.nativeCanvas.drawText(format(step * k), left - 6.dp.toPx(), y + 3.5.dp.toPx(), paint)
        }

        values.forEachIndexed { i, v ->
            val x = left + slot * i + (slot - barW) / 2f
            val h = if (top > 0f) chartH * (v / top) else 0f
            if (h > 0.5f) {
                val c = if (selected == null || selected == i) accent else accent.copy(alpha = 0.40f)
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(c, c.copy(alpha = c.alpha * 0.45f)), startY = baseY - h, endY = baseY),
                    topLeft = Offset(x, baseY - h),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f),
                )
            } else {
                drawRoundRect(track, Offset(x, baseY - 2.dp.toPx()), Size(barW, 2.dp.toPx()), CornerRadius(1.dp.toPx()))
            }
        }

        if (average != null && average > 0f && top > 0f) {
            val y = baseY - chartH * (average / top)
            drawLine(
                accent.copy(alpha = 0.7f), Offset(left, y), Offset(size.width, y),
                strokeWidth = 1.5.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8.dp.toPx(), 6.dp.toPx())),
            )
        }

        paint.textAlign = Paint.Align.CENTER
        values.indices.forEach { i ->
            val s = xLabel(i)
            if (s.isNotEmpty()) {
                paint.color = if (selected == i) accent.toArgb() else labelColor
                drawContext.canvas.nativeCanvas.drawText(s, left + slot * i + slot / 2f, size.height - 4.dp.toPx(), paint)
            }
        }
    }
}

// ---- when in the day --------------------------------------------------------------------------

/** 24 thin bars, one for each hour of the day. The bars of the favourite part of the day are bright. */
@Composable
internal fun HourBars(hours: List<Long>, favoritePart: Int?, accent: Color, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val labelColor = t.setSub.toArgb()
    val paint = remember { Paint().apply { isAntiAlias = true } }
    val peak = max(1L, hours.maxOrNull() ?: 0L)
    Canvas(modifier.fillMaxWidth().height(96.dp)) {
        val bottom = 18.dp.toPx()
        val chartH = size.height - bottom
        val slot = size.width / 24f
        val barW = max(2.dp.toPx(), slot * 0.62f)
        for (h in 0 until 24) {
            val frac = hours[h].toFloat() / peak
            val bh = max(3.dp.toPx(), chartH * frac)
            val bright = favoritePart != null && recapPartOf(h) == favoritePart
            val c = if (hours[h] <= 0L) t.ink.copy(alpha = 0.08f) else if (bright) accent else accent.copy(alpha = 0.42f)
            drawRoundRect(
                c,
                topLeft = Offset(slot * h + (slot - barW) / 2f, chartH - bh),
                size = Size(barW, bh),
                cornerRadius = CornerRadius(barW / 2f),
            )
        }
        paint.textSize = 10.sp.toPx()
        paint.color = labelColor
        paint.textAlign = Paint.Align.CENTER
        listOf(0 to "12 am", 6 to "6 am", 12 to "12 pm", 18 to "6 pm").forEach { (h, s) ->
            val x = (slot * h + slot / 2f).coerceIn(18.dp.toPx(), size.width - 18.dp.toPx())
            drawContext.canvas.nativeCanvas.drawText(s, x, size.height - 3.dp.toPx(), paint)
        }
    }
}

/** Seven bars, Monday first. The best weekday is bright; tap a bar for that weekday's best day. */
@Composable
internal fun WeekdayBars(values: List<Long>, favorite: Int?, accent: Color, onTap: (Int) -> Unit) {
    val t = pbTokens()
    val peak = max(1L, values.maxOrNull() ?: 0L)
    val names = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    Row(Modifier.fillMaxWidth().height(104.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEachIndexed { i, v ->
            val frac = v.toFloat() / peak
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .semantics(mergeDescendants = true) { contentDescription = "${names[i]}: ${com.paperback.app.data.Stats.duration(v)}" }
                    .clickable(enabled = v > 0L, onClickLabel = "Open the best ${names[i]}", role = Role.Button) { onTap(i) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier
                            .fillMaxWidth(0.62f)
                            .height(max(4f, 64f * frac).dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when {
                                    v <= 0L -> t.ink.copy(alpha = 0.08f)
                                    i == favorite -> accent
                                    else -> accent.copy(alpha = 0.42f)
                                },
                            ),
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    names[i],
                    color = if (i == favorite) t.ink else t.setSub,
                    fontSize = 12.sp,
                    fontWeight = if (i == favorite) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                )
            }
        }
    }
}

// ---- session lengths --------------------------------------------------------------------------

/** How many sessions of each length: a labelled bar per row. */
@Composable
internal fun LengthBars(counts: List<Int>, accent: Color) {
    val t = pbTokens()
    val peak = max(1, counts.maxOrNull() ?: 0)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        counts.forEachIndexed { i, n ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(RECAP_LENGTHS[i], modifier = Modifier.width(104.dp), color = t.ink, fontSize = 14.sp, maxLines = 1)
                Box(Modifier.weight(1f)) { PctBar(if (n == 0) 0.02f else n.toFloat() / peak, if (n == 0) trackColor() else accent, 10.dp) }
                Text(
                    "$n",
                    modifier = Modifier.width(34.dp),
                    color = t.ink,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.End,
                )
            }
        }
    }
}

// ---- ratings ----------------------------------------------------------------------------------

/** Books per star as lollipops: a stem and a dot, with 1 to 5 stars under them. */
@Composable
internal fun Lollipops(counts: List<Int>, accent: Color, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val peak = max(1, counts.maxOrNull() ?: 0)
    val stem = t.ink.copy(alpha = 0.10f)
    val paint = remember { Paint().apply { isAntiAlias = true } }
    val labelColor = t.setSub.toArgb()
    val countColor = t.ink.toArgb()
    Canvas(modifier.fillMaxWidth().height(150.dp)) {
        val bottom = 24.dp.toPx()
        val topPad = 22.dp.toPx()
        val chartH = size.height - bottom - topPad
        val slot = size.width / 5f
        val baseY = topPad + chartH
        drawLine(stem, Offset(0f, baseY), Offset(size.width, baseY), strokeWidth = 1.dp.toPx())
        paint.textAlign = Paint.Align.CENTER
        for (i in 0 until 5) {
            val cx = slot * i + slot / 2f
            val n = counts[i]
            if (n > 0) {
                val y = baseY - chartH * (n.toFloat() / peak)
                drawLine(accent, Offset(cx, baseY), Offset(cx, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                drawCircle(t.card, radius = 9.dp.toPx(), center = Offset(cx, y))
                drawCircle(accent, radius = 6.5.dp.toPx(), center = Offset(cx, y))
                paint.textSize = 12.sp.toPx()
                paint.color = countColor
                drawContext.canvas.nativeCanvas.drawText("$n", cx, y - 13.dp.toPx(), paint)
            }
            paint.textSize = 12.sp.toPx()
            paint.color = labelColor
            drawContext.canvas.nativeCanvas.drawText("${i + 1}\u2605", cx, size.height - 6.dp.toPx(), paint)
        }
    }
}

// ---- one dot a day ----------------------------------------------------------------------------

/** A dot for every day: green when the goal was met, amber when you read but fell short, grey otherwise. */
@Composable
internal fun GoalDots(days: List<RecapDay>, goalSeconds: Long, today: LocalDate, onTap: (LocalDate) -> Unit) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth()) {
        days.forEach { d ->
            val future = d.date.isAfter(today)
            val color = when {
                future -> t.ink.copy(alpha = 0.05f)
                d.seconds >= goalSeconds -> StatsAccent.Mint
                d.read -> StatsAccent.Yellow.copy(alpha = 0.7f)
                else -> t.ink.copy(alpha = 0.12f)
            }
            Box(
                Modifier
                    .weight(1f)
                    .height(26.dp)
                    .clickable(enabled = d.read, onClickLabel = "Open ${d.date.dayOfMonth}", role = Role.Button) { onTap(d.date) },
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(color))
            }
        }
    }
}
