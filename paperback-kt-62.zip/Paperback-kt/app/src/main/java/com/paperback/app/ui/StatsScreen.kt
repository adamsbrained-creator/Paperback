package com.paperback.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.paperback.app.data.Book
import com.paperback.app.data.Goals
import com.paperback.app.data.Highlight
import com.paperback.app.data.ReadingSession
import java.time.LocalDate

/** The pages of the Stats tab. Every page of the TypeScript Stats screen is here now. */
private enum class StatsPage(val label: String) {
    Activity("Activity"),
    Milestones("Milestones"),
    Books("Books"),
    History("History"),
    Insights("Insights"),
    Explore("Explore"),
    Recaps("Recaps"),
}

private const val NO_FOCUS = Long.MIN_VALUE

/**
 * The Stats tab: a row of pages at the top and the chosen page under it.
 * Activity and Milestones link to History for a day ("View sessions", a tier unlocked that day), which opens
 * History on that day. Milestones and Books also open books, notes, shelves and other pages, through the lambdas below.
 */
@Composable
fun StatsScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    goals: Goals,
    highlights: List<Highlight>,
    onOpenBook: (Book) -> Unit,
    onOpenGoals: () -> Unit,
    /** The notes of one book, or all notes and highlights when null. */
    onOpenNotes: (bookId: String?) -> Unit,
    onOpenFinished: () -> Unit,
    /** A shelf of the books behind a number: "langs", "rated" or "epic". */
    onOpenShelf: (kind: String) -> Unit,
    onOpenDictionary: () -> Unit,
    /** A page of the app: the Library, the books you are reading, the list of authors. */
    onOpenPage: (Dest) -> Unit,
    onOpenAuthor: (name: String) -> Unit,
    /** Pause, drop or resume a book (BookStatus). */
    onSetStatus: (bookId: String, status: Int) -> Unit = { _, _ -> },
    /** Reading rhythm as a calendar of covers (a look option) and the full-screen calendar. */
    rhythmCalendar: Boolean = false,
    goalStyle: com.paperback.app.data.GoalStyle = com.paperback.app.data.GoalStyle.Ring,
    onRhythmCalendar: (Boolean) -> Unit = {},
    onOpenCalendar: () -> Unit = {},
    /** The monthly recaps: which were opened, the reminder, and how to open one. */
    recaps: RecapHost,
    /** Another screen (a recap) asks for History on this day; [onHistoryConsumed] says it was shown. */
    historyRequest: LocalDate? = null,
    onHistoryConsumed: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    var page by rememberSaveable { mutableStateOf(StatsPage.Activity.name) }
    var focusDay by rememberSaveable { mutableLongStateOf(NO_FOCUS) }

    LaunchedEffect(historyRequest) {
        val day = historyRequest
        if (day != null) {
            focusDay = day.toEpochDay()
            page = StatsPage.History.name
            onHistoryConsumed()
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            StatsPage.values().forEach { p ->
                TogglePill(p.label, page == p.name) {
                    page = p.name
                    focusDay = NO_FOCUS
                }
            }
        }
        when (StatsPage.valueOf(page)) {
            StatsPage.Activity -> ActivityScreen(
                books = books,
                sessions = sessions,
                goals = goals,
                onOpenBook = onOpenBook,
                onOpenGoals = onOpenGoals,
                onViewDay = { day ->
                    focusDay = day.toEpochDay()
                    page = StatsPage.History.name
                },
                calendarLook = rhythmCalendar,
                goalStyle = goalStyle,
                onCalendarLook = onRhythmCalendar,
                onOpenCalendar = onOpenCalendar,
                modifier = Modifier.weight(1f),
            )
            StatsPage.Milestones -> MilestonesScreen(
                books = books,
                sessions = sessions,
                highlights = highlights,
                links = MilestoneLinks(
                    book = { id -> books.firstOrNull { it.id == id }?.let(onOpenBook) },
                    notes = onOpenNotes,
                    history = { day ->
                        focusDay = day?.toEpochDay() ?: NO_FOCUS
                        page = StatsPage.History.name
                    },
                    finished = onOpenFinished,
                    shelf = onOpenShelf,
                    dictionary = onOpenDictionary,
                ),
                modifier = Modifier.weight(1f),
            )
            StatsPage.Books -> BooksScreen(
                books = books,
                links = BooksLinks(
                    library = { onOpenPage(Dest.Library) },
                    finished = onOpenFinished,
                    reading = { onOpenPage(Dest.Reading) },
                    book = { id -> books.firstOrNull { it.id == id }?.let(onOpenBook) },
                    shelf = onOpenShelf,
                    author = onOpenAuthor,
                    authors = { onOpenPage(Dest.Authors) },
                ),
                modifier = Modifier.weight(1f),
            )
            StatsPage.History -> HistoryScreen(
                books = books,
                sessions = sessions,
                focus = if (focusDay == NO_FOCUS) null else LocalDate.ofEpochDay(focusDay),
                onOpenBook = onOpenBook,
                modifier = Modifier.weight(1f),
            )
            StatsPage.Insights -> InsightsScreen(
                books = books,
                sessions = sessions,
                goals = goals,
                links = InsightsLinks(
                    history = { day ->
                        focusDay = day.toEpochDay()
                        page = StatsPage.History.name
                    },
                    book = { id -> books.firstOrNull { it.id == id }?.let(onOpenBook) },
                    shelf = onOpenShelf,
                ),
                modifier = Modifier.weight(1f),
            )
            StatsPage.Explore -> ExploreScreen(
                books = books,
                sessions = sessions,
                goals = goals,
                highlights = highlights,
                onOpenBook = onOpenBook,
                onSetStatus = onSetStatus,
                modifier = Modifier.weight(1f),
            )
            StatsPage.Recaps -> RecapsContent(
                books = books,
                sessions = sessions,
                host = recaps,
                modifier = Modifier.weight(1f),
            )
        }
    }
}
