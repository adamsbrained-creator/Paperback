package com.paperback.app.data

data class Book(
    val id: String,              // SHA-256 of the file
    val title: String,
    val author: String,
    val language: String,
    val filePath: String,
    val coverPath: String?,
    val addedAt: Long,
    val lastOpenedAt: Long,      // 0 = never opened
    val progress: Float,         // 0..1 across the whole book
    val position: Int,           // Readium "position" (about one page), 0 = unread
    val totalPositions: Int,
    val locatorJson: String?,    // where to resume
    val finished: Boolean,
    val favorite: Boolean,
    val rating: Int,             // 0..5
    val journal: String = "",    // your own notes about the book
    val finishedAt: Long = 0L,   // 0 = unknown / not finished
) {
    val isReading: Boolean get() = !finished && (progress > 0f || position > 1)
    val percent: Int get() = (progress * 100).toInt().coerceIn(0, 100)

    /** PDFs are opened by Paperback's own page viewer; everything else goes through Readium. */
    val isPdf: Boolean get() = filePath.endsWith(".pdf", ignoreCase = true)
}

data class ReadingSession(
    val id: Long,
    val bookId: String,
    val startMs: Long,
    val seconds: Int,
    val pages: Int,
)

data class Bookmark(
    val id: String,
    val bookId: String,
    val locatorJson: String,
    val position: Int,      // Readium position (about one page)
    val progress: Float,    // 0..1 across the book
    val createdAt: Long,
)

data class Highlight(
    val id: String,
    val bookId: String,
    val locatorJson: String,
    val text: String,       // the selected passage
    val note: String,       // "" for a plain highlight
    val color: Int,         // ARGB
    val progress: Float,
    val createdAt: Long,
)

object HighlightColors {
    val YELLOW = 0xFFFFE066.toInt()
    val CORAL = 0xFFF46B4E.toInt()
    val GREEN = 0xFF7BD88F.toInt()
    val BLUE = 0xFF6CB4FF.toInt()
    val DEFAULT = YELLOW
    val all = listOf(YELLOW, CORAL, GREEN, BLUE)
}

data class BookCollection(
    val id: String,
    val name: String,
    val createdAt: Long,
)
