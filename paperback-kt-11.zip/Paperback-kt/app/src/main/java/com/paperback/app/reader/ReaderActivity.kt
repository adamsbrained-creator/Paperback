package com.paperback.app.reader

import android.os.Bundle
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Alignment
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commitNow
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.paperback.app.PaperbackApp
import com.paperback.app.R
import com.paperback.app.data.Bookmark
import com.paperback.app.data.Highlight
import com.paperback.app.data.HighlightColors
import com.paperback.app.data.ReaderLook
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PaperbackTheme
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.readium.r2.navigator.DecorableNavigator
import org.readium.r2.navigator.Decoration
import org.readium.r2.navigator.epub.EpubNavigatorFragment
import org.readium.r2.navigator.input.InputListener
import org.readium.r2.navigator.input.TapEvent
import org.readium.r2.navigator.util.DirectionalNavigationAdapter
import org.readium.r2.shared.publication.Link
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.services.search.search
import org.readium.r2.shared.publication.services.locateProgression

class ReaderActivity : FragmentActivity() {

    private val graph get() = (application as PaperbackApp).graph

    private var session: ReaderSession? = null
    private var navigator: EpubNavigatorFragment? = null
    private val tracker = ReadingTracker()

    private val chromeVisible = mutableStateOf(false)
    private val locatorState = mutableStateOf<Locator?>(null)
    private val fontSizeState = mutableDoubleStateOf(1.0)
    private val themeState = mutableIntStateOf(0)

    private val bookmarks = mutableStateOf<List<Bookmark>>(emptyList())
    private val highlights = mutableStateOf<List<Highlight>>(emptyList())
    private val panelOpen = mutableStateOf(false)
    private val editor = mutableStateOf<NoteEditorState?>(null)

    private val panelTab = mutableIntStateOf(0)
    private val toc = mutableStateOf<List<TocEntry>>(emptyList())
    private val lookOpen = mutableStateOf(false)
    private val lookState = mutableStateOf(ReaderLook())
    private val searchOpen = mutableStateOf(false)
    private val searchUi = mutableStateOf(SearchUi())
    private var searchJob: Job? = null

    /** The little menu that appears when you select text: adds "Highlight" and "Note". */
    private val selectionCallback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            menu.add(Menu.NONE, MENU_HIGHLIGHT, 0, "Highlight")
            menu.add(Menu.NONE, MENU_NOTE, 1, "Note")
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            val wantsNote = when (item.itemId) {
                MENU_HIGHLIGHT -> false
                MENU_NOTE -> true
                else -> return false
            }
            val nav = navigator
            val s = session
            if (nav == null || s == null) {
                mode.finish()
                return true
            }
            lifecycleScope.launch {
                // Read the selection first, then close the menu (closing it clears the selection).
                val selection = nav.currentSelection()
                if (selection != null) {
                    val quote = selection.locator.text.highlight.orEmpty()
                    if (wantsNote) {
                        editor.value = NoteEditorState(null, selection.locator, quote, "", HighlightColors.DEFAULT)
                    } else {
                        graph.repo.addHighlight(s.book.id, selection.locator, quote, "", HighlightColors.DEFAULT)
                        highlights.value = graph.repo.highlights(s.book.id)
                    }
                }
                mode.finish()
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val s = graph.readerSession
        if (s == null) {
            // The app was killed and Android is restoring this screen with nothing to show. The Readium
            // fragment still needs *a* factory to be restored, so give it a dummy one and leave.
            supportFragmentManager.fragmentFactory = EpubNavigatorFragment.createDummyFactory()
            super.onCreate(null)
            finish()
            return
        }
        session = s
        fontSizeState.doubleValue = graph.settings.fontSize
        themeState.intValue = graph.settings.theme
        lookState.value = graph.settings.look
        toc.value = buildToc(s)

        // IMPORTANT: the factory has to be set before super.onCreate().
        supportFragmentManager.fragmentFactory = s.navigatorFactory.createFragmentFactory(
            initialLocator = s.initialLocator,
            initialPreferences = graph.settings.toEpubPreferences(),
            configuration = EpubNavigatorFragment.Configuration(selectionActionModeCallback = selectionCallback),
        )
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_reader)

        if (savedInstanceState == null) {
            supportFragmentManager.commitNow {
                add(R.id.navigator_container, EpubNavigatorFragment::class.java, Bundle(), NAV_TAG)
            }
        }
        val nav = supportFragmentManager.findFragmentByTag(NAV_TAG) as EpubNavigatorFragment
        navigator = nav

        // Tap near the left/right edge turns the page; tap in the middle shows or hides the controls.
        nav.addInputListener(DirectionalNavigationAdapter(nav))
        nav.addInputListener(
            object : InputListener {
                override fun onTap(event: TapEvent): Boolean {
                    chromeVisible.value = !chromeVisible.value
                    return true
                }
            },
        )

        // Tap on a highlight: open it to edit the note, change the colour or delete it.
        nav.addDecorationListener(
            HIGHLIGHT_GROUP,
            object : DecorableNavigator.Listener {
                override fun onDecorationActivated(event: DecorableNavigator.OnActivatedEvent): Boolean {
                    val h = highlights.value.firstOrNull { it.id == event.decoration.id } ?: return false
                    editor.value = NoteEditorState(h.id, null, h.text, h.note, h.color)
                    return true
                }
            },
        )

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                nav.currentLocator.collect { onLocator(s, it) }
            }
        }

        // Keep the highlights drawn on the page in sync with the list.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                snapshotFlow { highlights.value }.collect { list ->
                    nav.applyDecorations(toDecorations(list), HIGHLIGHT_GROUP)
                }
            }
        }

        lifecycleScope.launch {
            bookmarks.value = graph.repo.bookmarks(s.book.id)
            highlights.value = graph.repo.highlights(s.book.id)
        }

        val pace = Stats.paceSecondsPerPosition(graph.repo.sessions.value)

        findViewById<ComposeView>(R.id.chrome).setContent {
            PaperbackTheme {
                val position = locatorState.value?.locations?.position ?: s.book.position
                Box(Modifier.fillMaxSize()) {
                    ReaderChrome(
                        title = s.book.title,
                        visible = chromeVisible.value,
                        position = position,
                        totalPositions = s.totalPositions,
                        progress = (locatorState.value?.locations?.totalProgression ?: s.book.progress.toDouble()).toFloat(),
                        secondsPerPage = pace,
                        fontSize = fontSizeState.doubleValue,
                        themeIndex = themeState.intValue,
                        bookmarked = bookmarks.value.any { it.position == position },
                        onBack = { finish() },
                        onToggleBookmark = { toggleBookmark() },
                        onOpenPanel = { openPanel(1) },
                        onOpenContents = { openPanel(0) },
                        onOpenSearch = {
                            chromeVisible.value = false
                            searchOpen.value = true
                        },
                        onOpenLook = {
                            chromeVisible.value = false
                            lookOpen.value = true
                        },
                        onSeek = { fraction ->
                            // locateProgression is a suspend function, so it needs a coroutine.
                            lifecycleScope.launch {
                                s.publication.locateProgression(fraction.toDouble())?.let { nav.go(it) }
                            }
                        },
                        onFontSize = { delta -> changeFontSize(delta) },
                        onTheme = { index -> changeTheme(index) },
                    )

                    if (panelOpen.value) {
                        ReaderPanel(
                            themeIndex = themeState.intValue,
                            initialTab = panelTab.intValue,
                            toc = toc.value,
                            currentHref = locatorState.value?.href?.toString(),
                            bookmarks = bookmarks.value,
                            highlights = highlights.value,
                            onGo = { json -> goTo(json) },
                            onDeleteBookmark = { b -> deleteBookmark(b) },
                            onDeleteHighlight = { h -> deleteHighlight(h) },
                            onClose = { panelOpen.value = false },
                        )
                    }

                    if (lookOpen.value) {
                        ReaderLookSheet(
                            themeIndex = themeState.intValue,
                            fontSize = fontSizeState.doubleValue,
                            look = lookState.value,
                            onFontSize = { value -> setFontSize(value) },
                            onTheme = { index -> changeTheme(index) },
                            onLook = { look -> changeLook(look) },
                            onClose = { lookOpen.value = false },
                            modifier = Modifier.align(Alignment.BottomStart),
                        )
                    }

                    if (searchOpen.value) {
                        ReaderSearchPanel(
                            themeIndex = themeState.intValue,
                            ui = searchUi.value,
                            onQuery = { q -> searchUi.value = searchUi.value.copy(query = q) },
                            onSubmit = { runSearch() },
                            onGo = { hit -> goToHit(hit) },
                            onClose = { closeSearch() },
                        )
                    }

                    editor.value?.let { state ->
                        NoteEditorDialog(
                            state = state,
                            themeIndex = themeState.intValue,
                            onSave = { note, color -> saveEditor(state, note, color) },
                            onDelete = state.highlightId?.let { id -> { deleteHighlightById(id) } },
                            onDismiss = { editor.value = null },
                        )
                    }
                }
            }
        }

        hideSystemBars()
        applyBrightness(lookState.value.brightness)
    }

    // ---- reading position and time --------------------------------------------------------

    private fun onLocator(s: ReaderSession, locator: Locator) {
        locatorState.value = locator
        tracker.onPosition(System.currentTimeMillis(), locator.locations.position ?: 0)
        graph.appScope.launch { graph.repo.saveProgress(s.book.id, locator) }
    }

    private fun changeFontSize(delta: Double) {
        val next = (fontSizeState.doubleValue + delta).coerceIn(0.6, 2.5)
        fontSizeState.doubleValue = next
        graph.settings.fontSize = next
        navigator?.submitPreferences(graph.settings.toEpubPreferences())
    }

    private fun setFontSize(value: Double) {
        val next = value.coerceIn(0.6, 2.5)
        fontSizeState.doubleValue = next
        graph.settings.fontSize = next
        navigator?.submitPreferences(graph.settings.toEpubPreferences())
    }

    private fun changeLook(look: ReaderLook) {
        lookState.value = look
        graph.settings.look = look
        navigator?.submitPreferences(graph.settings.toEpubPreferences())
        applyBrightness(look.brightness)
    }

    /** A value from 0.05 to 1 dims or brightens this screen only; below zero follows the phone again. */
    private fun applyBrightness(value: Float) {
        val attrs = window.attributes
        attrs.screenBrightness = if (value < 0f) android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else value.coerceIn(0.05f, 1f)
        window.attributes = attrs
    }

    private fun changeTheme(index: Int) {
        themeState.intValue = index
        graph.settings.theme = index
        navigator?.submitPreferences(graph.settings.toEpubPreferences())
    }

    // ---- bookmarks, highlights, notes -----------------------------------------------------

    private fun toggleBookmark() {
        val s = session ?: return
        val loc = locatorState.value ?: return
        val position = loc.locations.position ?: return
        lifecycleScope.launch {
            val existing = bookmarks.value.firstOrNull { it.position == position }
            if (existing != null) graph.repo.removeBookmark(existing.id) else graph.repo.addBookmark(s.book.id, loc)
            bookmarks.value = graph.repo.bookmarks(s.book.id)
        }
    }

    private fun deleteBookmark(b: Bookmark) {
        val s = session ?: return
        lifecycleScope.launch {
            graph.repo.removeBookmark(b.id)
            bookmarks.value = graph.repo.bookmarks(s.book.id)
        }
    }

    private fun saveEditor(state: NoteEditorState, note: String, color: Int) {
        val s = session ?: return
        editor.value = null
        lifecycleScope.launch {
            val id = state.highlightId
            val locator = state.locator
            if (id != null) graph.repo.updateHighlight(id, note, color)
            else if (locator != null) graph.repo.addHighlight(s.book.id, locator, state.quote, note, color)
            highlights.value = graph.repo.highlights(s.book.id)
        }
    }

    private fun deleteHighlight(h: Highlight) = deleteHighlightById(h.id)

    private fun deleteHighlightById(id: String) {
        val s = session ?: return
        editor.value = null
        lifecycleScope.launch {
            graph.repo.removeHighlight(id)
            highlights.value = graph.repo.highlights(s.book.id)
        }
    }

    private fun openPanel(tab: Int) {
        panelTab.intValue = tab
        chromeVisible.value = false
        panelOpen.value = true
    }

    /** The book's table of contents as a flat list, each line remembering how deep it is nested. */
    private fun buildToc(s: ReaderSession): List<TocEntry> {
        val out = ArrayList<TocEntry>()
        fun walk(links: List<Link>, depth: Int) {
            for (link in links) {
                val locator = s.publication.locatorFromLink(link)
                if (locator != null) {
                    out += TocEntry(
                        title = link.title?.trim().orEmpty().ifBlank { "Untitled" },
                        depth = depth,
                        locatorJson = locator.toJSON().toString(),
                        href = locator.href.toString(),
                    )
                }
                walk(link.children, depth + 1)
            }
        }
        walk(s.publication.tableOfContents, 0)
        return out
    }

    // ---- search inside the book ----------------------------------------------------------

    private fun runSearch() {
        val s = session ?: return
        val query = searchUi.value.query.trim()
        searchJob?.cancel()
        clearSearchMark()
        if (query.length < 2) {
            searchUi.value = searchUi.value.copy(hits = emptyList(), running = false, done = false, capped = false, error = null)
            return
        }
        searchUi.value = searchUi.value.copy(hits = emptyList(), running = true, done = false, capped = false, error = null)
        searchJob = lifecycleScope.launch {
            val hits = ArrayList<SearchHit>()
            var error: String? = null
            var capped = false
            val iterator = s.publication.search(query)
            if (iterator == null) {
                error = "This book can't be searched."
            } else {
                try {
                    while (true) {
                        val page = iterator.next().getOrNull() ?: break
                        for (locator in page.locators) {
                            hits += SearchHit(
                                locatorJson = locator.toJSON().toString(),
                                before = locator.text.before.orEmpty(),
                                hit = locator.text.highlight.orEmpty(),
                                after = locator.text.after.orEmpty(),
                                chapter = locator.title,
                                progress = (locator.locations.totalProgression ?: 0.0).toFloat(),
                            )
                        }
                        searchUi.value = searchUi.value.copy(hits = hits.toList())
                        if (hits.size >= MAX_SEARCH_HITS) {
                            capped = true
                            break
                        }
                    }
                } finally {
                    iterator.close()
                }
            }
            searchUi.value = searchUi.value.copy(hits = hits.toList(), running = false, done = true, capped = capped, error = error)
        }
    }

    private fun goToHit(hit: SearchHit) {
        val nav = navigator ?: return
        val locator = runCatching { Locator.fromJSON(JSONObject(hit.locatorJson)) }.getOrNull() ?: return
        searchOpen.value = false
        chromeVisible.value = false
        lifecycleScope.launch {
            nav.go(locator)
            // Mark the match on the page until the next search (or until the book is closed).
            nav.applyDecorations(
                listOf(Decoration(id = "match", locator = locator, style = Decoration.Style.Highlight(tint = SEARCH_TINT))),
                SEARCH_GROUP,
            )
        }
    }

    private fun closeSearch() {
        searchOpen.value = false
    }

    private fun clearSearchMark() {
        val nav = navigator ?: return
        lifecycleScope.launch { nav.applyDecorations(emptyList(), SEARCH_GROUP) }
    }

    private fun goTo(locatorJson: String) {
        val nav = navigator ?: return
        val locator = runCatching { Locator.fromJSON(JSONObject(locatorJson)) }.getOrNull() ?: return
        panelOpen.value = false
        chromeVisible.value = false
        lifecycleScope.launch { nav.go(locator) }
    }

    private fun toDecorations(list: List<Highlight>): List<Decoration> = list.mapNotNull { h ->
        val locator = runCatching { Locator.fromJSON(JSONObject(h.locatorJson)) }.getOrNull() ?: return@mapNotNull null
        Decoration(id = h.id, locator = locator, style = Decoration.Style.Highlight(tint = h.color))
    }

    // ---- system bars: hidden for the whole reading session, so nothing resizes when controls toggle ----

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && session != null) hideSystemBars() // e.g. after a dialog closes
    }

    // ---- lifecycle ------------------------------------------------------------------------

    override fun onResume() {
        super.onResume()
        tracker.resume(System.currentTimeMillis())
    }

    override fun onPause() {
        super.onPause()
        val s = session ?: return
        tracker.pause(System.currentTimeMillis())?.let { flush ->
            // appScope, not lifecycleScope: this has to finish even if the activity is going away.
            graph.appScope.launch { graph.repo.addSession(s.book.id, flush.startMs, flush.seconds, flush.pages) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing && session != null) graph.closeReader()
    }

    private companion object {
        const val NAV_TAG = "navigator"
        const val HIGHLIGHT_GROUP = "highlights"
        const val SEARCH_GROUP = "search"
        const val SEARCH_TINT = 0xFFFFC857.toInt()
        const val MAX_SEARCH_HITS = 200
        const val MENU_HIGHLIGHT = 1
        const val MENU_NOTE = 2
    }
}
