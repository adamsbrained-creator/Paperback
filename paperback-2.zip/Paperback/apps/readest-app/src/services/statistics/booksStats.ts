// Paperback: everything the Stats → Books page computes, as pure functions.
// No React, no DB, no Date.now(): all take `now`. Day bucketing uses the device's local time zone.

import { bookPageCounts } from './milestonesStats';
import { clampDuration, type StatEventRow } from './statsAggregate';

/** The slice of a Paperback book this page reads (PBook fits it). */
export interface BBook {
  hash: string;
  title: string;
  author: string;
  format: string;
  language: string;
  tags: string[];
  series?: string | undefined;
  deletedAt?: number | null | undefined;
  readingStatus?: string | undefined;
  readingStatusUpdatedAt?: number | undefined;
  createdAt?: number | undefined; // ms
  updatedAt?: number | undefined; // ms
  progress?: [number, number] | null | undefined;
}

/** The slice of a note row this page reads (notesViews.NoteRow fits it). */
export interface BNote {
  bookHash: string;
  bookTitle: string;
  kind: 'highlight' | 'note' | 'bookmark';
  color: string;
  at: number; // ms
}

export interface BooksInput {
  books: BBook[];
  events: StatEventRow[];
  ratings: Record<string, number>; // hash -> 1..5
  notes: BNote[] | null; // null while still being read from the books
  collections: { id: string; name: string; hashes: string[] }[];
  favorites: string[];
  wishlistCount: number;
  savedWords: number;
  now: Date;
}

const DAY = 864e5;
const startOfDay = (d: Date): Date => new Date(d.getFullYear(), d.getMonth(), d.getDate());

export const liveOnly = <T extends { deletedAt?: number | null | undefined }>(books: T[]): T[] =>
  books.filter((b) => !b.deletedAt);

// ---- status -----------------------------------------------------------------------------

export type StatusId = 'reading' | 'finished' | 'unread' | 'abandoned';
export const STATUS_LABEL: Record<StatusId, string> = {
  reading: 'Reading',
  finished: 'Finished',
  unread: 'Not started',
  abandoned: 'Dropped',
};
export const STATUS_ORDER: StatusId[] = ['reading', 'finished', 'unread', 'abandoned'];

const fraction = (b: BBook): number => {
  const p = b.progress;
  if (!p || !(p[1] > 0)) return 0;
  return Math.max(0, Math.min(1, p[0] / p[1]));
};

export function statusOfBook(b: BBook): StatusId {
  const s = b.readingStatus;
  if (s === 'finished') return 'finished';
  if (s === 'abandoned') return 'abandoned';
  if (s === 'reading' || (s !== 'unread' && fraction(b) > 0)) return 'reading';
  return 'unread';
}

export interface StatusRow {
  id: StatusId;
  label: string;
  count: number;
  hashes: string[];
}

export function statusSplit(books: BBook[]): StatusRow[] {
  const out = STATUS_ORDER.map((id) => ({ id, label: STATUS_LABEL[id], count: 0, hashes: [] as string[] }));
  for (const b of liveOnly(books)) {
    const row = out.find((r) => r.id === statusOfBook(b))!;
    row.count++;
    row.hashes.push(b.hash);
  }
  return out;
}

// ---- per-book numbers -------------------------------------------------------------------

/** Pages of each book: what the reader counted while reading, else the total in the library row. 0 = unknown. */
export function pageCountMap(books: BBook[], events: StatEventRow[]): Map<string, number> {
  const counted = bookPageCounts(events);
  const out = new Map<string, number>();
  for (const b of books) {
    const total = b.progress && b.progress[1] > 0 ? b.progress[1] : 0;
    out.set(b.hash, Math.max(counted.get(b.hash) ?? 0, total));
  }
  return out;
}

/** Distinct pages visited per book (a page read twice counts once). */
export function pagesReadByBook(events: StatEventRow[]): Map<string, number> {
  const seen = new Map<string, Set<number>>();
  for (const e of events) {
    if (clampDuration(e) <= 0) continue;
    let set = seen.get(e.md5);
    if (!set) {
      set = new Set();
      seen.set(e.md5, set);
    }
    set.add(e.page);
  }
  const out = new Map<string, number>();
  for (const [k, set] of seen) out.set(k, set.size);
  return out;
}

export function secondsByBook(events: StatEventRow[]): Map<string, number> {
  const out = new Map<string, number>();
  for (const e of events) out.set(e.md5, (out.get(e.md5) ?? 0) + clampDuration(e));
  return out;
}

const finishedAt = (b: BBook): number => b.readingStatusUpdatedAt ?? b.updatedAt ?? 0;

const median = (xs: number[]): number => {
  if (xs.length === 0) return 0;
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m]! : Math.round((s[m - 1]! + s[m]!) / 2);
};

// ---- overview ---------------------------------------------------------------------------

export interface BookRef {
  hash: string;
  title: string;
  value: number;
}

export interface Overview {
  total: number;
  finished: number;
  finishedThisYear: number;
  addedThisYear: number;
  pagesRead: number;
  pagesPerBook: number; // pages read / books that were read at all
  readBooks: number;
  longest: BookRef | null;
  shortest: BookRef | null;
  averagePages: number;
  medianPages: number;
  libraryPages: number;
  unknownPages: number;
  readingSeconds: number;
  mostRead: BookRef | null; // value = seconds
  avgRating: number | null;
  rated: number;
  favorites: number;
}

export function buildOverview(input: BooksInput): Overview {
  const live = liveOnly(input.books);
  const liveSet = new Set(live.map((b) => b.hash));
  const pages = pageCountMap(live, input.events);
  const read = pagesReadByBook(input.events);
  const secs = secondsByBook(input.events);
  const year = input.now.getFullYear();

  let pagesRead = 0;
  let readBooks = 0;
  for (const [h, n] of read) {
    if (!liveSet.has(h)) continue;
    pagesRead += n;
    readBooks++;
  }
  let readingSeconds = 0;
  let mostRead: BookRef | null = null;
  for (const b of live) {
    const s = secs.get(b.hash) ?? 0;
    readingSeconds += s;
    if (s > 0 && (!mostRead || s > mostRead.value)) mostRead = { hash: b.hash, title: b.title, value: s };
  }

  const known = live.filter((b) => (pages.get(b.hash) ?? 0) > 0);
  let longest: BookRef | null = null;
  let shortest: BookRef | null = null;
  for (const b of known) {
    const n = pages.get(b.hash)!;
    if (!longest || n > longest.value) longest = { hash: b.hash, title: b.title, value: n };
    if (!shortest || n < shortest.value) shortest = { hash: b.hash, title: b.title, value: n };
  }
  const counts = known.map((b) => pages.get(b.hash)!);
  const libraryPages = counts.reduce((a, n) => a + n, 0);

  const ratedVals = live.map((b) => input.ratings[b.hash]).filter((n): n is number => typeof n === 'number' && n >= 1);
  const finished = live.filter((b) => b.readingStatus === 'finished');

  return {
    total: live.length,
    finished: finished.length,
    finishedThisYear: finished.filter((b) => new Date(finishedAt(b)).getFullYear() === year).length,
    addedThisYear: live.filter((b) => b.createdAt && new Date(b.createdAt).getFullYear() === year).length,
    pagesRead,
    pagesPerBook: readBooks ? Math.round(pagesRead / readBooks) : 0,
    readBooks,
    longest,
    shortest,
    averagePages: counts.length ? Math.round(libraryPages / counts.length) : 0,
    medianPages: median(counts),
    libraryPages,
    unknownPages: live.length - known.length,
    readingSeconds,
    mostRead,
    avgRating: ratedVals.length ? ratedVals.reduce((a, n) => a + n, 0) / ratedVals.length : null,
    rated: ratedVals.length,
    favorites: live.filter((b) => input.favorites.includes(b.hash)).length,
  };
}

// ---- finishing --------------------------------------------------------------------------

export interface Finishing {
  /** Finished books that also have reading events (the days can only be counted for those). */
  counted: number;
  avgDays: number;
  fastest: (BookRef & { days: number }) | null;
  slowest: (BookRef & { days: number }) | null;
  avgSecondsPerBook: number;
  /** Finished ÷ (finished + reading + dropped), 0..100; null when nothing was started. */
  finishRate: number | null;
  started: number;
}

export function buildFinishing(input: BooksInput): Finishing {
  const live = liveOnly(input.books);
  const first = new Map<string, number>();
  for (const e of input.events) {
    if (clampDuration(e) <= 0) continue;
    const cur = first.get(e.md5);
    if (cur === undefined || e.startTime < cur) first.set(e.md5, e.startTime);
  }
  const secs = secondsByBook(input.events);

  const days: { b: BBook; days: number }[] = [];
  let secTotal = 0;
  let secBooks = 0;
  for (const b of live) {
    if (b.readingStatus !== 'finished') continue;
    const s = secs.get(b.hash) ?? 0;
    if (s > 0) {
      secTotal += s;
      secBooks++;
    }
    const start = first.get(b.hash);
    const end = finishedAt(b);
    if (start === undefined || !end || end < start * 1000) continue;
    const n = Math.round((startOfDay(new Date(end)).getTime() - startOfDay(new Date(start * 1000)).getTime()) / DAY) + 1;
    days.push({ b, days: n });
  }
  days.sort((a, b) => a.days - b.days);
  const ref = (d: { b: BBook; days: number } | undefined) =>
    d ? { hash: d.b.hash, title: d.b.title, value: d.days, days: d.days } : null;

  const statuses = statusSplit(input.books);
  const n = (id: StatusId) => statuses.find((s) => s.id === id)!.count;
  const started = n('finished') + n('reading') + n('abandoned');

  return {
    counted: days.length,
    avgDays: days.length ? Math.round(days.reduce((a, d) => a + d.days, 0) / days.length) : 0,
    fastest: ref(days[0]),
    slowest: days.length > 1 ? ref(days[days.length - 1]) : null,
    avgSecondsPerBook: secBooks ? Math.round(secTotal / secBooks) : 0,
    finishRate: started ? Math.round((n('finished') / started) * 100) : null,
    started,
  };
}

// ---- books finished over time -----------------------------------------------------------

export interface FinishedBar {
  label: string;
  count: number;
  hashes: string[];
}

export const MONTH_INITIALS = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];

export function finishedByMonth(books: BBook[], year: number): FinishedBar[] {
  const out: FinishedBar[] = MONTH_INITIALS.map((label) => ({ label, count: 0, hashes: [] }));
  for (const b of liveOnly(books)) {
    if (b.readingStatus !== 'finished') continue;
    const d = new Date(finishedAt(b));
    if (d.getFullYear() !== year) continue;
    const bar = out[d.getMonth()]!;
    bar.count++;
    bar.hashes.push(b.hash);
  }
  return out;
}

/** One bar per year from the first year with a finished book to this year (at most the last 8). */
export function finishedByYear(books: BBook[], now: Date): (FinishedBar & { year: number })[] {
  const by = new Map<number, string[]>();
  for (const b of liveOnly(books)) {
    if (b.readingStatus !== 'finished') continue;
    const y = new Date(finishedAt(b)).getFullYear();
    by.set(y, [...(by.get(y) ?? []), b.hash]);
  }
  const last = now.getFullYear();
  const first = Math.max(Math.min(last, ...Array.from(by.keys())), last - 7);
  const out: (FinishedBar & { year: number })[] = [];
  for (let y = first; y <= last; y++) {
    const hashes = by.get(y) ?? [];
    out.push({ year: y, label: String(y), count: hashes.length, hashes });
  }
  return out;
}

/** Years that have finished books, plus this year, newest first. */
export function finishedYearList(books: BBook[], now: Date): number[] {
  const years = new Set<number>([now.getFullYear()]);
  for (const b of liveOnly(books)) if (b.readingStatus === 'finished') years.add(new Date(finishedAt(b)).getFullYear());
  return [...years].sort((a, b) => b - a);
}

// ---- generic "label, count, share" rows -------------------------------------------------

export interface CountRow {
  name: string;
  count: number;
  /** Share of all rows' counts, 0..100 (rows add up to about 100). */
  pct: number;
  hashes: string[];
}

function rowsFrom(map: Map<string, Set<string>>, pctBase?: number): CountRow[] {
  const raw = [...map.entries()].map(([name, set]) => ({ name, count: set.size, hashes: [...set] }));
  const base = pctBase ?? raw.reduce((a, r) => a + r.count, 0);
  return raw
    .map((r) => ({ ...r, pct: base ? Math.round((r.count / base) * 100) : 0 }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

const add = (map: Map<string, Set<string>>, key: string, hash: string) => {
  let set = map.get(key);
  if (!set) {
    set = new Set();
    map.set(key, set);
  }
  set.add(hash);
};

// ---- genres (from tags) -----------------------------------------------------------------

/** Tags that mean the same genre. Used by "Grouped"; "As tagged" shows the tags as they are. */
const GROUPS: Record<string, string[]> = {
  'Science fiction': ['sci-fi', 'scifi', 'sci fi', 'sf', 'science-fiction', 'science fiction', 'space opera', 'cyberpunk'],
  'Young adult': ['ya', 'young adult', 'young-adult', 'teen', 'teen fiction'],
  Fantasy: ['fantasy', 'epic fantasy', 'high fantasy', 'urban fantasy', 'dark fantasy', 'fantasía', 'fantasia', 'magic'],
  Fiction: ['fiction', 'literary fiction', 'general fiction', 'novel', 'novels', 'contemporary', 'contemporary fiction'],
  Classics: ['classic', 'classics', 'classic literature', 'classical literature'],
  'Non-fiction': ['non-fiction', 'nonfiction', 'non fiction'],
  'Biography & memoir': ['biography', 'biographies', 'memoir', 'memoirs', 'autobiography'],
  'Mystery & thriller': ['mystery', 'thriller', 'thrillers', 'crime', 'detective', 'suspense', 'crime fiction'],
  'Historical fiction': ['historical fiction', 'historical'],
  History: ['history', 'world history'],
  Romance: ['romance', 'love stories', 'romantic'],
  Horror: ['horror', 'gothic'],
  Dystopian: ['dystopia', 'dystopian'],
  'Self-help': ['self-help', 'self help', 'personal development', 'productivity'],
  Poetry: ['poetry', 'poems', 'poem'],
  Philosophy: ['philosophy'],
  Science: ['science', 'popular science', 'pop science'],
  "Children's": ['children', 'childrens', "children's", 'kids', 'middle grade'],
  'Comics & manga': ['comics', 'comic', 'graphic novel', 'graphic novels', 'manga'],
};
const GROUP_OF = new Map<string, string>();
for (const [group, tags] of Object.entries(GROUPS)) for (const t of tags) GROUP_OF.set(t, group);

const tidy = (tag: string): string => {
  const t = tag.trim().replace(/\s+/g, ' ');
  return t.charAt(0).toUpperCase() + t.slice(1);
};

export type GenreMode = 'grouped' | 'tagged';

export function genreRows(books: BBook[], mode: GenreMode): CountRow[] {
  const map = new Map<string, Set<string>>();
  for (const b of liveOnly(books)) {
    for (const raw of b.tags) {
      const tag = raw.trim();
      if (!tag) continue;
      const name = mode === 'grouped' ? (GROUP_OF.get(tag.toLowerCase()) ?? tidy(tag)) : tag;
      add(map, name, b.hash);
    }
  }
  return rowsFrom(map);
}

export const untaggedCount = (books: BBook[]): number =>
  liveOnly(books).filter((b) => !b.tags.some((t) => t.trim())).length;

// ---- authors, series, formats, languages ------------------------------------------------

export function authorRows(books: BBook[]): CountRow[] {
  const map = new Map<string, Set<string>>();
  const live = liveOnly(books);
  for (const b of live) add(map, b.author.trim() || 'Unknown author', b.hash);
  return rowsFrom(map, live.length);
}

export interface SeriesRow {
  name: string;
  count: number;
  finished: number;
  hashes: string[];
}

export function seriesRows(books: BBook[]): SeriesRow[] {
  const map = new Map<string, BBook[]>();
  for (const b of liveOnly(books)) {
    const name = (b.series ?? '').trim();
    if (name) map.set(name, [...(map.get(name) ?? []), b]);
  }
  return [...map.entries()]
    .map(([name, list]) => ({
      name,
      count: list.length,
      finished: list.filter((b) => b.readingStatus === 'finished').length,
      hashes: list.map((b) => b.hash),
    }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

export function formatRows(books: BBook[]): CountRow[] {
  const map = new Map<string, Set<string>>();
  const live = liveOnly(books);
  for (const b of live) add(map, b.format.trim().toUpperCase() || 'Unknown', b.hash);
  return rowsFrom(map, live.length);
}

const THREE_TO_TWO: Record<string, string> = {
  eng: 'en', spa: 'es', rus: 'ru', fra: 'fr', fre: 'fr', deu: 'de', ger: 'de', ita: 'it', por: 'pt',
  zho: 'zh', chi: 'zh', jpn: 'ja', kor: 'ko', ara: 'ar', nld: 'nl', dut: 'nl', pol: 'pl', ukr: 'uk', tur: 'tr',
};

/** "en-US" and "eng" both become "en"; "" stays "". */
export function languageCode(raw: string): string {
  const base = raw.trim().toLowerCase().split(/[-_]/)[0] ?? '';
  return THREE_TO_TWO[base] ?? base;
}

export function languageName(code: string): string {
  if (!code) return 'Unknown';
  try {
    const name = new Intl.DisplayNames(['en'], { type: 'language' }).of(code);
    if (name && name.toLowerCase() !== code.toLowerCase()) return name;
  } catch {
    /* fall through */
  }
  return code.toUpperCase();
}

export function languageRows(books: BBook[]): CountRow[] {
  const map = new Map<string, Set<string>>();
  const live = liveOnly(books);
  for (const b of live) add(map, languageName(languageCode(b.language)), b.hash);
  const rows = rowsFrom(map, live.length);
  // "Unknown" last, whatever its size, so the real languages read first.
  return [...rows.filter((r) => r.name !== 'Unknown'), ...rows.filter((r) => r.name === 'Unknown')];
}

// ---- length and rating distributions ----------------------------------------------------

export interface Bucket {
  label: string;
  count: number;
  hashes: string[];
}

export const PAGE_BUCKETS: { label: string; min: number; max: number }[] = [
  { label: '<100', min: 1, max: 99 },
  { label: '100–299', min: 100, max: 299 },
  { label: '300–499', min: 300, max: 499 },
  { label: '500–699', min: 500, max: 699 },
  { label: '700–999', min: 700, max: 999 },
  { label: '1000+', min: 1000, max: Infinity },
];

export function pageBuckets(books: BBook[], events: StatEventRow[]): { buckets: Bucket[]; unknown: string[] } {
  const live = liveOnly(books);
  const pages = pageCountMap(live, events);
  const buckets: Bucket[] = PAGE_BUCKETS.map((b) => ({ label: b.label, count: 0, hashes: [] }));
  const unknown: string[] = [];
  for (const b of live) {
    const n = pages.get(b.hash) ?? 0;
    const i = PAGE_BUCKETS.findIndex((x) => n >= x.min && n <= x.max);
    if (i < 0) {
      unknown.push(b.hash);
      continue;
    }
    buckets[i]!.count++;
    buckets[i]!.hashes.push(b.hash);
  }
  return { buckets, unknown };
}

export function ratingBuckets(books: BBook[], ratings: Record<string, number>): { buckets: Bucket[]; unrated: string[] } {
  const live = liveOnly(books);
  const buckets: Bucket[] = [1, 2, 3, 4, 5].map((n) => ({ label: `${n}`, count: 0, hashes: [] }));
  const unrated: string[] = [];
  for (const b of live) {
    const n = ratings[b.hash];
    if (typeof n === 'number' && n >= 1 && n <= 5) {
      const bucket = buckets[Math.round(n) - 1]!;
      bucket.count++;
      bucket.hashes.push(b.hash);
    } else unrated.push(b.hash);
  }
  return { buckets, unrated };
}

/** Average rating per genre (grouped), best first; only genres with at least `min` rated books. */
export function ratingByGenre(
  books: BBook[],
  ratings: Record<string, number>,
  min = 2,
): { name: string; avg: number; rated: number }[] {
  const byHash = new Map(liveOnly(books).map((b) => [b.hash, b]));
  const out: { name: string; avg: number; rated: number }[] = [];
  for (const g of genreRows(books, 'grouped')) {
    const vals = g.hashes
      .filter((h) => byHash.has(h))
      .map((h) => ratings[h])
      .filter((n): n is number => typeof n === 'number' && n >= 1);
    if (vals.length >= min) out.push({ name: g.name, avg: vals.reduce((a, n) => a + n, 0) / vals.length, rated: vals.length });
  }
  return out.sort((a, b) => b.avg - a.avg || b.rated - a.rated || a.name.localeCompare(b.name));
}

// ---- collections ------------------------------------------------------------------------

export function collectionRows(books: BBook[], collections: BooksInput['collections']): CountRow[] {
  const live = new Set(liveOnly(books).map((b) => b.hash));
  const total = collections.reduce((a, c) => a + c.hashes.filter((h) => live.has(h)).length, 0);
  return collections
    .map((c) => {
      const hashes = c.hashes.filter((h) => live.has(h));
      return { name: c.name, count: hashes.length, pct: total ? Math.round((hashes.length / total) * 100) : 0, hashes };
    })
    .filter((r) => r.count > 0)
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

// ---- highlights and notes ---------------------------------------------------------------

export interface NotesSummary {
  highlights: number;
  notes: number;
  bookmarks: number;
  booksWithNotes: number;
  perBook: number; // highlights + notes per book that has any (one decimal)
  mostHighlighted: { hash: string; title: string; count: number } | null;
  thisMonth: number;
  colors: { color: string; count: number }[];
}

export function notesSummary(notes: BNote[], now: Date): NotesSummary {
  const per = new Map<string, { title: string; count: number }>();
  const colors = new Map<string, number>();
  let highlights = 0;
  let notesN = 0;
  let bookmarks = 0;
  let thisMonth = 0;
  for (const n of notes) {
    if (n.kind === 'bookmark') {
      bookmarks++;
      continue;
    }
    if (n.kind === 'highlight') highlights++;
    else notesN++;
    const cur = per.get(n.bookHash) ?? { title: n.bookTitle, count: 0 };
    cur.count++;
    per.set(n.bookHash, cur);
    colors.set(n.color, (colors.get(n.color) ?? 0) + 1);
    const d = new Date(n.at);
    if (d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth()) thisMonth++;
  }
  let top: NotesSummary['mostHighlighted'] = null;
  for (const [hash, v] of per) if (!top || v.count > top.count) top = { hash, title: v.title, count: v.count };
  const marked = highlights + notesN;
  return {
    highlights,
    notes: notesN,
    bookmarks,
    booksWithNotes: per.size,
    perBook: per.size ? Math.round((marked / per.size) * 10) / 10 : 0,
    mostHighlighted: top,
    thisMonth,
    colors: [...colors.entries()].map(([color, count]) => ({ color, count })).sort((a, b) => b.count - a.count),
  };
}

/** The first `n` rows, with all the rest added up as one "Other" row (nothing is added when there are `n` or fewer). */
export function topWithOther(rows: CountRow[], n: number): CountRow[] {
  if (rows.length <= n) return rows;
  const rest = rows.slice(n);
  const hashes = rest.flatMap((r) => r.hashes);
  return [
    ...rows.slice(0, n),
    { name: 'Other', count: rest.reduce((a, r) => a + r.count, 0), pct: rest.reduce((a, r) => a + r.pct, 0), hashes },
  ];
}

// ---- text helpers -----------------------------------------------------------------------

/** 5400 → "1h 30m", 2700 → "45m", 90000 → "25h". */
export function durationText(seconds: number): string {
  const min = Math.round(seconds / 60);
  if (min < 60) return `${min}m`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return h >= 100 || m === 0 ? `${h}h` : `${h}h ${String(m).padStart(2, '0')}m`;
}

export const dayText = (n: number): string => `${n} ${n === 1 ? 'day' : 'days'}`;

export const oneDecimal = (n: number): string => (Math.round(n * 10) / 10).toFixed(1);
