'use client';

import { useMemo } from 'react';
import { usePaperbackOpenBook } from '@/components/paperback/useOpenBook';
import type { PBook } from '@/services/paperback/library';
import { pageCountMap, statusOfBook, STATUS_LABEL } from '@/services/statistics/booksStats';
import { commas } from '@/services/statistics/milestonesStats';
import type { StatEventRow } from '@/services/statistics/statsAggregate';
import type { BooksListSpec } from './BooksView';
import { SIcon } from './StatsIcons';
import { Thumb } from './ui';

/** The books behind a bar, row or dot of Stats → Books. Tap a book to open it. */
export default function BooksListScreen({
  spec,
  booksByHash,
  events,
  ratings,
  onBack,
}: {
  spec: BooksListSpec;
  booksByHash: Map<string, PBook>;
  events: StatEventRow[];
  ratings: Record<string, number>;
  onBack: () => void;
}) {
  const openBook = usePaperbackOpenBook();
  const books = useMemo(
    () =>
      spec.hashes
        .map((h) => booksByHash.get(h))
        .filter((b): b is PBook => !!b)
        .sort((a, b) => a.title.localeCompare(b.title)),
    [spec, booksByHash],
  );
  const pages = useMemo(() => pageCountMap(books, events), [books, events]);

  return (
    <div className='pbs pbs-col'>
      <div className='pbs-stop'>
        <button type='button' className='pbs-round' aria-label='Back to Books' onClick={onBack}>
          <SIcon name='back' />
        </button>
        <h2 style={{ margin: 0, fontSize: 30, fontWeight: 500, letterSpacing: '-.02em' }}>{spec.title}</h2>
      </div>
      {spec.subtitle && <div className='pbb-sub'>{spec.subtitle}</div>}
      <section className='pbs-card' aria-label={spec.title}>
        {books.length === 0 ? (
          <p className='pbb-empty' style={{ margin: 0 }}>
            No books here.
          </p>
        ) : (
          <div className='pbb-list'>
            {books.map((b) => {
              const n = pages.get(b.hash) ?? 0;
              const stars = ratings[b.hash];
              return (
                <button key={b.hash} type='button' className='pbb-item' onClick={() => void openBook(b)}>
                  <Thumb md5={b.hash} book={b} />
                  <div>
                    <h4>{b.title}</h4>
                    <p>
                      {b.author || 'Unknown author'}
                      {n > 0 ? ` · ${commas(n)} pages` : ''}
                    </p>
                  </div>
                  <div className='pbb-st'>
                    {stars ? <b>{stars} ★</b> : STATUS_LABEL[statusOfBook(b)]}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
