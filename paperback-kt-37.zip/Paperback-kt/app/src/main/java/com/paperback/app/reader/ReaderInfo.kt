package com.paperback.app.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.FOOTER_LEFT_PAGES
import com.paperback.app.data.FOOTER_PERCENT
import com.paperback.app.data.FOOTER_TOTAL

/**
 * The page frame, copied from Readest (TypeScript Paperback): by default the text stays 64 dp clear of the top of the screen and 44 dp
 * clear of the bottom. Both are now sliders (Top / Bottom), and the chapter name has its own Header slider. The sides follow Readest too (see ReaderSettings.toEpubPreferences).
 */
val ReaderTopFrame: Dp = 64.dp
val ReaderBottomFrame: Dp = 44.dp

/**
 * The small, quiet text around the page, as in Readest: the chapter name at the top; "N pages left in chapter"
 * at the bottom left and "position / total" at the bottom right. "Pages left" counts real screens, so it drops
 * by one for each page you turn; the counter counts fixed pieces of text, so it can move by more than one.
 * Hidden while the reader's controls are showing (they cover this strip).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderMarginInfo(
    themeIndex: Int,
    hidden: Boolean,
    chapter: String,
    pagesLeft: Int,
    position: Int,
    totalPositions: Int,
    headerSpace: Float = 40f,
    bottomSpace: Float = 44f,
    percent: Float = 0f,
    footerItems: Int = FOOTER_LEFT_PAGES or FOOTER_TOTAL,
) {
    val c = readerColors(themeIndex)
    // The chapter name sits headerSpace dp below the top edge, wherever the text starts; the counters stay on the bottom edge.
    val bottomFrame = maxOf(bottomSpace, 20f).dp
    val color = c.ink.copy(alpha = 0.55f)
    AnimatedVisibility(visible = !hidden, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, top = headerSpace.dp),
                contentAlignment = Alignment.TopStart,
            ) {
                if (chapter.isNotBlank()) {
                    Text(chapter, color = color, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(bottomFrame)
                    .padding(start = 18.dp, end = 18.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                val left = buildList {
                    if (footerItems and FOOTER_LEFT_PAGES != 0 && pagesLeft > 0) add("$pagesLeft ${if (pagesLeft == 1) "page" else "pages"} left")
                    if (footerItems and FOOTER_PERCENT != 0) add("%.1f%%".format(percent.coerceIn(0f, 1f) * 100f))
                }.joinToString("  ·  ")
                Text(
                    left,
                    modifier = Modifier.weight(1f),
                    color = color,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (footerItems and FOOTER_TOTAL != 0 && position > 0 && totalPositions > 0) {
                    Text("$position / $totalPositions", color = color, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}
