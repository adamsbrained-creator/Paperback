package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Paperback's icon set, copied from components/paperback/icons.tsx: a 24 px grid, 1.9 px stroke, round caps
 * and joins. The path strings are the same ones the TypeScript app draws, so the icons are identical.
 * [solid] is the shape that fills in for the active state.
 */
enum class PbIconName(val d: String, val solid: String? = null) {
    Home("M4 11l8-7 8 7 M6 10v10h12V10", "M4 11l8-7 8 7 M6 10v10h12V10"),
    Discover("M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 1 0 0-17z M15.5 8.5l-2 5-5 2 2-5z"),
    Collections("M4 8l8-4 8 4-8 4z M4 12l8 4 8-4 M4 16l8 4 8-4", "M4 8l8-4 8 4-8 4z"),
    Bookmark("M7 4h10v16l-5-4-5 4z", "M7 4h10v16l-5-4-5 4z"),
    Stats("M5 20v-8 M12 20V5 M19 20v-5"),
    Settings("M4 7h9 M17 7h3 M15 5a2 2 0 1 0 0 4 2 2 0 1 0 0-4z M4 17h3 M11 17h9 M9 15a2 2 0 1 0 0 4 2 2 0 1 0 0-4z"),
    Theme(
        "M12 3 a9 9 0 1 0 0 18 c1.4 0 2 -1 1.5 -2.2 c-0.5 -1.2 0.2 -2.3 1.5 -2.3 H17 a4 4 0 0 0 4 -4 c0 -5 -4 -9.5 -9 -9.5 z M7.5 11 h0.01 M10 7 h0.01 M15 7.5 h0.01",
    ),
    Search("M11 4.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 1 0 0-13z M16 16l4.5 4.5"),
    AppStyle("M4 7 a3 3 0 0 1 3 -3 h10 a3 3 0 0 1 3 3 v10 a3 3 0 0 1 -3 3 H7 a3 3 0 0 1 -3 -3 z M4 10 h16 M8 7 h5"),
    Goals("M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 1 0 0-17z M12 8a4 4 0 1 0 0 8 4 4 0 1 0 0-8z M12 12 h0.01"),
    Backup("M7 18 a4 4 0 0 1 0 -8 a5 5 0 0 1 9.6 -1 A4.5 4.5 0 0 1 17 18 z M12 16 v-5 M9.5 13.5 L12 11 l2.5 2.5"),
    About("M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 1 0 0-17z M12 11v5 M12 8 h0.01"),
    Menu("M4 7h16 M4 12h10 M4 17h14"),
    MenuLines("M5 7h14 M5 12h14 M5 17h14"),
    Close("M6 6l12 12 M18 6L6 18"),
    Dots("M5 12 h0.01 M12 12 h0.01 M19 12 h0.01"),
    Library("M5 4v16 M10 4v16 M14 5.5l4.5 14"),
    Reader("M5 4 h11 a3 3 0 0 1 3 3 v13 H8 a3 3 0 0 1 -3 -3 z M5 17 a3 3 0 0 1 3 -3 h11"),
    ImportFile("M12 4v11 M7.5 10.5L12 15l4.5-4.5 M5 19h14"),
    Plus("M12 5v14 M5 12h14"),
    CaretRight("M9 5l7 7-7 7"),
    CaretLeft("M15 5l-7 7 7 7"),
    Star("M12 3.6l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.9l6-.8z", "M12 3.6l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.9l6-.8z"),
    Note("M6 3.5h9l3.5 3.5v13.5H6z M14.5 3.5V7.5H18.5 M9 12h6 M9 16h6"),
    Edit("M4 20l1-4.2L16.3 4.5a2.1 2.1 0 0 1 3 3L8 18.8z M14.5 6.3l3 3"),
}

/** One icon. [size] is the drawn size; the icon scales from its 24 px grid. */
@Composable
fun PbIcon(
    name: PbIconName,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    tint: Color = LocalContentColor.current,
    filled: Boolean = false,
    strokeWidth: Float? = null,
    contentDescription: String? = null,
) {
    val line = remember(name) { PathParser().parsePathString(name.d).toPath() }
    val solid = remember(name) { name.solid?.let { PathParser().parsePathString(it).toPath() } }
    val sw = strokeWidth ?: if (filled && name.solid == null) 2.6f else 1.9f
    val described = if (contentDescription != null) {
        modifier.semantics { this.contentDescription = contentDescription }
    } else {
        modifier
    }
    Canvas(described.size(size)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            if (filled && solid != null) drawPath(solid, tint, style = Fill)
            drawPath(line, tint, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}
