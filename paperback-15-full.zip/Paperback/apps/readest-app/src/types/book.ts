import { BookMetadata } from '@/libs/document';
import { TTSHighlightOptions } from '@/services/tts/types';
import { TTSHighlightGranularity } from '@/services/tts/types';
import { TTSMediaMetadataMode } from '@/services/tts/types';
import { TTSPlayerStyle } from '@/services/tts/types';
import type { AnnotationLinkType } from '@/utils/deeplink';
import { AnnotationToolType } from './annotator';

export type BookFormat =
  | 'EPUB'
  | 'PDF'
  | 'MOBI'
  | 'AZW'
  | 'AZW3'
  | 'CBZ'
  | 'FB2'
  | 'FBZ'
  | 'TXT'
  | 'MD'
  | 'HTML';
export type BookNoteType = 'bookmark' | 'annotation' | 'excerpt' | 'notebook' | 'ink';
export type ReadingStatus = 'unread' | 'reading' | 'finished' | 'abandoned';
export type HighlightStyle = 'highlight' | 'underline' | 'squiggly';
// Predefined highlight colors, can be extended with custom hex colors
export type HighlightColor = 'red' | 'yellow' | 'green' | 'blue' | 'violet' | string;
export const DEFAULT_HIGHLIGHT_COLORS = ['red', 'yellow', 'green', 'blue', 'violet'] as const;
export type DefaultHighlightColor = (typeof DEFAULT_HIGHLIGHT_COLORS)[number];
// A user-added highlight color with optional label
export interface UserHighlightColor {
  hex: string;
  label?: string;
}
export type ReadingRulerColor = 'transparent' | 'yellow' | 'green' | 'blue' | 'rose';

export interface ParagraphModeConfig {
  enabled: boolean;
}

export const FIXED_LAYOUT_FORMATS: Set<BookFormat> = new Set(['PDF', 'CBZ']);

/**
 * Lookup tables built from a Book[] for O(1) hash and metaHash queries during
 * batch import. Mutated in place by importBook so subsequent files in the
 * same batch see books added by earlier files. Defined here (rather than in
 * services/bookService) so the AppService interface in types/system can
 * reference it without an inline `import(...)` type.
 */
export interface BookLookupIndex {
  byHash: Map<string, Book>;
  byMetaKey: Map<string, Book[]>; // key = `${metaHash}:${format}`
  // Fallback for books whose metaHash moves with every export of the same file
  // (calibre re-mints dc:identifier, issue #5959). key =
  // `${getStableMetadataHash(metadata)}:${format}`, and only books that carry a
  // volatile identifier appear here.
  byStableKey: Map<string, Book[]>;
  // Maps normalized absolute source path -> Book for in-place imports.
  // Lets the importer recognize "I already have this exact file" without
  // having to open, parse, and hash it again. Only books with a non-empty
  // `filePath` and `!deletedAt` are indexed. The key is produced by
  // `normalizeFilePathForIndex` so callers must use the same helper to
  // probe; importBook handles that internally.
  byFilePath: Map<string, Book>;
}

/**
 * User-facing options for AppService.importBook. The bookService implementation
 * extends this with required callbacks (saveBookConfig / generateCoverImageUrl)
 * that are bound by the AppService instance.
 */
export interface ImportBookOptions {
  /** Whether to copy the file into the Books directory. Defaults to true. */
  saveBook?: boolean;
  /** Whether to extract and save a cover image. Defaults to true. */
  saveCover?: boolean;
  /** Whether to overwrite an existing file at the same path. Defaults to false. */
  overwrite?: boolean;
  /** Whether the import is transient (not stored long-term). Defaults to false. */
  transient?: boolean;
  /**
   * If true, do NOT copy the source file into Books/<hash>/. Instead, persist
   * an absolute filePath on the Book and let isBookAvailable / loadBookContent
   * fall back to it. The caller is responsible for verifying the source is
   * already inside the user's chosen library root (customRootDir) so that the
   * file remains stable across launches. Sidecar files (cover.png, config.json,
   * nav.json) are still written to Books/<hash>/ as usual. Defaults to false.
   */
  inPlace?: boolean;
  /** Pre-built lookup index for O(1) dedup during batch imports. */
  lookupIndex?: BookLookupIndex;
}

export interface Book {
  // if Book is a remote book we just lazy load the book content via url
  url?: string;
  // if Book is a transient local book we can load the book content via filePath
  filePath?: string;
  // Other on-disk paths that resolved to this same book — a watched folder
  // holding the same file twice under different names, or a copy left behind
  // after a rename. Only `filePath` is ever read from; these are remembered so
  // the auto-import scan doesn't treat a known duplicate as a new file on every
  // pass. Device-local like `filePath`: never published to peers.
  altFilePaths?: string[];
  // Partial md5 hash of the book file, used as the unique identifier
  hash: string;
  // Metadata md5 hash, used to aggregate different versions of the same book
  metaHash?: string;
  format: BookFormat;
  title: string; // editable title from metadata
  sourceTitle?: string; // parsed when the book is imported and used to locate the file
  author: string;
  group?: string; // deprecated in favor of groupId and groupName
  groupId?: string;
  groupName?: string;
  // Field-level LWW timestamp for group membership (groupId + groupName), so an
  // unrelated row bump cannot clobber a grouping edit. The row's updatedAt is
  // stamped by things that have nothing to do with groups -- most notably
  // `cloudService.uploadBook`, which bumps it on every UPLOAD -- so whole-row
  // LWW let a peer holding a never-grouped copy win and erase the group for the
  // whole fleet (#5911). Mirrors readingStatusUpdatedAt / coverUpdatedAt /
  // metadataUpdatedAt.
  groupUpdatedAt?: number | null;
  tags?: string[];
  coverImageUrl?: string | null;
  // Partial MD5 of the local cover.png. Content-addressed cover-change signal:
  // a peer re-downloads the cover iff its synced value differs from the local
  // one (issue #4544). Invariant: coverHash === partialMD5(cover.png).
  coverHash?: string | null;

  createdAt: number;
  updatedAt: number;
  deletedAt?: number | null;
  /**
   * Positive authorization to delete this book's directory from third-party
   * file-sync providers. Must equal the current `deletedAt` tombstone; a plain
   * tombstone hides the library row but preserves provider bytes (#5695).
   */
  fileSyncDeletionRequestedAt?: number | null;

  uploadedAt?: number | null;
  downloadedAt?: number | null;
  coverDownloadedAt?: number | null;
  // Field-level LWW timestamp for the cover, so a page-turn that wins whole-row
  // LWW on updatedAt cannot clobber a cover edit (mirrors readingStatusUpdatedAt).
  coverUpdatedAt?: number | null;
  syncedAt?: number | null;

  lastUpdated?: number; // deprecated in favor of updatedAt
  progress?: [number, number] | null; // Add progress field: [current, total], 1-based page number
  readingStatus?: ReadingStatus;
  readingStatusUpdatedAt?: number; // ms; bumped only when readingStatus changes
  primaryLanguage?: string;
  // The book carries its own recorded narration (EPUB 3 Media Overlays), so the
  // library can badge it without opening the file. Derived from the file on
  // every import, like `format` — not user data, so it needs no LWW timestamp.
  hasNarration?: boolean;
  // The page total the reader will lay out, counted from the file at import so
  // an unopened book can show and sort by it (#6662). Like `hasNarration`, it is
  // re-derived on every import; once opened, `progress[1]` holds the same total.
  pageCount?: number;

  metadata?: BookMetadata;
  // Field-level LWW timestamp for the metadata group (title, author, tags,
  // metadata), so a page-turn that wins whole-row LWW on updatedAt cannot
  // clobber a metadata edit (mirrors readingStatusUpdatedAt / coverUpdatedAt).
  metadataUpdatedAt?: number | null;
}

export interface BookGroupType {
  id: string;
  name: string;
}

export interface PageInfo {
  current: number;
  next?: number;
  total: number;
}

// Remaining time of the book in minutes
export interface TimeInfo {
  section: number;
  total: number;
}

export interface BookNote {
  bookHash?: string;
  metaHash?: string;
  id: string;
  type: BookNoteType;
  cfi: string; // Canonicalized CFI for the note location
  xpointer0?: string; // Start XPointer for the note location
  xpointer1?: string; // End XPointer for the note location
  page?: number;
  text?: string;
  style?: HighlightStyle;
  color?: HighlightColor;
  note: string;
  /**
   * If true, this annotation should be applied to every occurrence of `text`
   * within the same section (chapter/spine item), in addition to the original
   * range identified by `cfi`. Defaults to false / undefined (single-range).
   * Only meaningful for annotations that have a `text` value; ignored for
   * bookmarks and excerpts, and for fixed-layout formats (e.g. PDF).
   */
  global?: boolean;

  createdAt: number;
  updatedAt: number;
  deletedAt?: number | null;
}

export interface BooknoteGroup {
  id: number;
  href: string;
  label: string;
  booknotes: BookNote[];
}

export type WritingMode = 'auto' | 'horizontal-tb' | 'horizontal-rl' | 'vertical-rl';

export interface BookLayout {
  marginTopPx: number;
  marginBottomPx: number;
  marginLeftPx: number;
  marginRightPx: number;
  marginPx?: number; // deprecated
  compactMarginTopPx: number;
  compactMarginBottomPx: number;
  compactMarginLeftPx: number;
  compactMarginRightPx: number;
  compactMarginPx?: number; // deprecated
  gapPercent: number;
  /* Centre gap of a two-column spread in px; 0 derives it from the margins
     and gapPercent as before. */
  columnGapPx: number;
  scrolled: boolean;
  scrolledDirection: 'vertical' | 'horizontal';
  webtoonMode: boolean;
  /* Fixed-layout only: freeze the horizontal pan offset of a zoomed page so it
     can't drift sideways out of alignment while scrolling (#5976). */
  lockHorizontalPan: boolean;
  noContinuousScroll: boolean;
  disableClick: boolean;
  disableSwipe: boolean;
  disablePullDownToBookmark: boolean;
  fullscreenClickArea: boolean;
  swapClickArea: boolean;
  disableDoubleClick: boolean;
  volumeKeysToFlip: boolean;
  maxColumnCount: number;
  maxInlineSize: number;
  maxBlockSize: number;
  writingMode: WritingMode;
  vertical: boolean;
  rtl: boolean;
  scrollingOverlap: number;
  allowScript: boolean;
  hideScrollbar: boolean;
  /* Auto Scroll (#4998) speed as a percentage; 100 = AUTO_SCROLL_BASE_PX_PER_SEC. */
  autoScrollSpeed: number;
  /* True when a session was still running as the book was closed, so reopening
     the book resumes it (#5631). Per book: written with the global write
     skipped, and cleared by any explicit stop. */
  autoScrollRunning: boolean;
}

export interface BookStyle {
  zoomLevel: number;
  paragraphMargin: number;
  lineHeight: number;
  wordSpacing: number;
  letterSpacing: number;
  textIndent: number;
  fullJustification: boolean;
  hyphenation: boolean;
  theme: string;
  backgroundTextureId: string;
  backgroundOpacity: number;
  backgroundSize: string;
  highlightOpacity: number;
  codeHighlighting: boolean;
  codeLanguage: string;
  dialogueHighlight: boolean;
  dialogueHighlightCustomColor: boolean;
  dialogueHighlightColor: string;
  dialogueHighlightCustomTextColor: boolean;
  dialogueHighlightTextColor: string;
  dialogueHighlightItalic: boolean;
  userStylesheet: string;
  userUIStylesheet: string;

  overrideFont: boolean;
  overrideLayout: boolean;
  overrideColor: boolean;
  useBookLayout: boolean;

  // fixed-layout specific
  zoomMode: 'fit-page' | 'fit-width' | 'original-size' | 'custom';
  spreadMode: 'auto' | 'none';
  keepCoverSpread: boolean;
  invertImgColorInDark: boolean;
  applyThemeToPDF: boolean;
  contrast: number;
}

export interface BookFont {
  serifFont: string;
  sansSerifFont: string;
  monospaceFont: string;
  defaultFont: string;
  defaultCJKFont: string;
  defaultFontSize: number;
  minimumFontSize: number;
  fontWeight: number;
}

// 'push' slides the whole strip; 'slide' and 'curl' layer the outgoing page
// over the still incoming page (Apple Books style, needs View Transitions).
export type PageTurnStyle = 'push' | 'slide' | 'curl';
export interface ViewConfig {
  sideBarTab: string;
  uiLanguage: string;
  sortedTOC: boolean;
  showTOCThumbnails: boolean;

  doubleBorder: boolean;
  borderColor: string;

  showHeader: boolean;
  showFooter: boolean;
  showRemainingTime: boolean;
  showRemainingPages: boolean;
  showProgressInfo: boolean;
  showStickyProgressBar: boolean;
  showCurrentTime: boolean;
  use24HourClock: boolean;
  showCurrentBatteryStatus: boolean;
  showBatteryPercentage: boolean;
  showPaginationButtons: boolean;
  progressStyle: 'percentage' | 'fraction' | 'reference';
  referencePageCount: number;

  // Styling for the header (section title) and footer (progress readout,
  // remaining time/pages, clock, battery). See utils/headerFooterStyle.ts
  // for how these resolve; e-ink ignores both colors.
  /** Font size in px for the header/footer info text. */
  headerFooterFontSize: number;
  /** `''` follows the theme's base-content; otherwise a `#rrggbb`. */
  headerFooterTextColor: string;
  /**
   * `'auto'` keeps the built-in backdrop (the scrolled-mode footer pill and
   * nothing behind the header), `'none'` removes it everywhere, and a
   * `#rrggbb` paints a matching chip behind both header and footer in every
   * flow mode.
   */
  headerFooterBackground: string;
  /** 0-1 alpha applied to a `#rrggbb` headerFooterBackground. */
  headerFooterBgOpacity: number;

  animated: boolean;
  pageTurnStyle: PageTurnStyle;
  isEink: boolean;
  isColorEink: boolean;
  /**
   * Number of page turns between automatic deep full refreshes in e-ink mode.
   * 0 disables it. Manual refresh bindings are unusable on readers with no
   * spare buttons, so this clears accumulated ghosting on its own.
   */
  einkAutoRefreshInterval: number;

  paragraphMode: ParagraphModeConfig;

  readingRulerEnabled: boolean;
  readingRulerLines: number;
  readingRulerPosition: number;
  readingRulerOpacity: number;
  readingRulerColor: ReadingRulerColor;
}

export interface TTSConfig {
  ttsRate: number;
  ttsSentenceGap: number;
  ttsParagraphGap: number;
  ttsVoice: string;
  // Prefer the book's own recorded narration (EPUB 3 Media Overlays) over
  // synthesized speech. Defaults on, so a read-along book is read by its
  // narrator; picking a synthetic voice while that book is open clears it.
  // Distinct from ttsVoice because ttsVoice inherits the global default and so
  // cannot tell "never chose" from "chose a synthetic voice for this book".
  ttsUseNarration: boolean;
  ttsLocation: string;
  ttsHighlightOptions: TTSHighlightOptions;
  ttsHighlightGranularity: TTSHighlightGranularity;
  ttsMediaMetadata: TTSMediaMetadataMode;
  ttsPlayerStyle: TTSPlayerStyle;
  ttsSkipInlineAnnotations: boolean;
  // Sentence-by-sentence Read Aloud: pause after every sentence (#5233).
  ttsPauseAfterSentence: boolean;
}

// Markdown and plain text render the note template; JSON emits the
// machine-readable file that Readest itself can import back (#5400).
export type NoteExportFormat = 'markdown' | 'text' | 'json';

export interface NoteExportConfig {
  includeTitle: boolean;
  includeAuthor: boolean;
  includeDate: boolean;
  // Include a public cover image link; requires publishing the cover to the
  // public bucket (sign-in) unless the book already has a public cover URL.
  includeCoverImage: boolean;
  includeChapterTitles: boolean;
  includeQuotes: boolean;
  // The sentence around each highlight, read from the book at export time.
  includeContext: boolean;
  includeNotes: boolean;
  includePageNumber: boolean;
  includeTimestamp: boolean;
  includeChapterSeparator: boolean;
  linkType: AnnotationLinkType;
  noteSeparator: string;
  useCustomTemplate: boolean;
  customTemplate: string;
  // Superseded by `exportFormat`; kept so configs written before the JSON
  // option existed still pick the right format on load.
  exportAsPlainText: boolean;
  exportFormat: NoteExportFormat;
  // Highlight colors/styles to omit from the export. Empty arrays export
  // everything; storing exclusions keeps colors/styles added later included
  // by default (#4801).
  excludedColors: HighlightColor[];
  excludedStyles: HighlightStyle[];
}

export interface AnnotatorConfig {
  enableAnnotationQuickActions: boolean;
  annotationQuickAction: AnnotationToolType | null;
  // Hand the word back selected, with the toolbar, when an instant dictionary
  // lookup closes (#6213). Off: closing it returns straight to reading (#6454).
  keepSelectionAfterLookup: boolean;
  annotationToolbarItems: AnnotationToolType[];
  copyToNotebook: boolean;
  noteExportConfig: NoteExportConfig;
}

export interface ScreenConfig {
  screenOrientation: 'auto' | 'portrait' | 'landscape';
}

export type ProofreadScope = 'selection' | 'book' | 'library';

export interface ProofreadRule {
  id: string;
  scope: ProofreadScope;
  pattern: string;
  replacement: string;
  cfi?: string;
  sectionHref?: string;
  enabled: boolean;
  isRegex: boolean;
  order: number; // Lower numbers apply first
  wholeWord?: boolean; // Match whole words only (uses \b word boundaries)
  caseSensitive?: boolean; // Case-sensitive matching (default true)
  onlyForTTS?: boolean; // Only replace text for TTS, not in the book display (only for book/library scope)
  // CRDT sync fields (book/selection scope rides the book-config sync). `updatedAt`
  // is the last-write-wins key for the per-id merge; `deletedAt` is a tombstone so a
  // deletion survives the merge instead of being resurrected by the peer's copy.
  // Library-scope rules sync via the settings replica (whole-field LWW) and don't
  // need a tombstone, so these stay optional for back-compat with older configs.
  updatedAt?: number;
  deletedAt?: number | null;
}

export interface ProofreadRulesConfig {
  proofreadRules?: ProofreadRule[];
}

export interface ViewSettingsConfig {
  isGlobal: boolean;
}

export interface ViewSettings
  extends BookLayout,
    BookStyle,
    BookFont,
    ViewConfig,
    TTSConfig,
    ScreenConfig,
    ProofreadRulesConfig,
    AnnotatorConfig,
    ViewSettingsConfig {}

export interface BookProgress {
  location: string;
  sectionHref: string;
  sectionLabel: string;
  section: PageInfo;
  pageinfo: PageInfo;
  pageItem?: { label?: string; href?: string } | null;
  timeinfo: TimeInfo;
  // Overall reading position in foliate's size-domain (0..1), matching the
  // domain used by the sticky progress bar's chapter ticks.
  fraction: number;
  index: number;
  range: Range;
  page: number;
}

export type SearchMode = 'contains' | 'whole-words' | 'regex' | 'nearby-words';

export interface BookSearchConfig {
  scope: 'book' | 'section';
  mode: SearchMode;
  matchCase: boolean;
  matchDiacritics: boolean;
  // nearby-words: maximum number of words separating the matched words
  nearbyWords?: number;
  /** @deprecated since schema v3 — mirrors `mode === 'whole-words'`; kept for sync wire back-compat. */
  matchWholeWords?: boolean;
  index?: number;
  query?: string;
  acceptNode?: (node: Node) => number;

  // pre-cached search results
  results?: BookSearchResult[] | BookSearchMatch[] | null;
}

export type LibrarySearchConfig = Omit<BookSearchConfig, 'mode'> & {
  mode: SearchMode | 'fuzzy';
};

export interface SearchExcerpt {
  pre: string;
  match: string;
  post: string;
  // nearby-words: the cluster window split into matched (emphasized) words and gaps
  segments?: { text: string; emphasized: boolean }[];
}

export interface BookSearchMatch {
  cfi: string;
  // nearby-words: per-word CFIs to highlight (>= 2); absent for single-span matches
  cfis?: string[];
  excerpt: SearchExcerpt;
}

// Text-offset locator into a section's extracted text. Library search results
// carry locators instead of CFIs; the CFI is resolved lazily on click so
// searching never needs live DOM Ranges (see librarySearchService).
export interface SearchResultLocator {
  section: number;
  start: number;
  end: number;
  // fuzzy/nearby: matched sub-spans within [start, end)
  runs?: { start: number; end: number }[];
}

export interface LibrarySearchMatch {
  locator: SearchResultLocator;
  excerpt: SearchExcerpt;
}

export interface LibrarySearchSectionResult {
  index: number;
  label: string;
  subitems: LibrarySearchMatch[];
}

export interface BookSearchResult {
  index?: number;
  label: string;
  subitems: BookSearchMatch[];
  progress?: number;
}

export const BOOK_CONFIG_SCHEMA_VERSION = 3;

export interface BookConfig {
  schemaVersion?: number;
  bookHash?: string;
  metaHash?: string;
  progress?: [number, number]; // [current pagenum, total pagenum], 1-based page number
  location?: string; // CFI of the current location
  xpointer?: string; // XPointer of the current location (for Koreader interoperability)
  booknotes?: BookNote[];
  rsvpPosition?: { cfi: string; wordText: string };
  searchConfig?: Partial<BookSearchConfig>;
  viewSettings?: Partial<ViewSettings>;
  /**
   * A device-local recording paired with this ebook. The audio files live
   * under Books/<hash>/audiobook/. It stays on this device.
   */
  audiobook?: PairedAudiobook;
  /**
   * The pages of a comic laid out as spreads of their own (wide images), by
   * page path: a device-local cache of measuring them, so a later open skips
   * it and a streamed comic keeps what earlier reading found. Neither sync
   * carries it; both copy an explicit list of fields.
   */
  widePages?: string[];
  /**
   * Where a zoomed fixed-layout page was panned under the horizontal pan lock,
   * as a fraction of its horizontal overflow, restored on reopen. Device-local
   * like widePages: it depends on this screen's zoom and size.
   */
  panX?: number;

  lastSyncedAtConfig?: number;
  lastSyncedAtNotes?: number;
  lastPushedAtConfig?: number;
  lastPushedAtNotes?: number;
  foliateImportedAt?: number;

  updatedAt: number;
}

export interface AudiobookFile {
  id: string;
  name: string;
  path: string;
  duration: number;
}

export interface AudiobookChapter {
  id: string;
  fileId: string;
  label: string;
  start: number;
  end: number;
}

export interface AudiobookChapterMapping {
  ebookChapterId: string;
  audioChapterId: string;
}

export interface PairedAudiobook {
  version: 1;
  title?: string;
  narrator?: string;
  files: AudiobookFile[];
  chapters: AudiobookChapter[];
  mappings: AudiobookChapterMapping[];
  createdAt: number;
}

export interface BooksGroup {
  id: string;
  name: string;
  displayName: string;
  /**
   * True when `displayName` is an i18n key rather than user-authored text, so
   * the rendering component must run it through `_()`. Set for groupings whose
   * values are enums we own (reading status); never set for series, author,
   * tag or subject names, which must render verbatim even when one of them
   * happens to collide with a UI string.
   */
  localized?: boolean;
  books: Book[];

  updatedAt: number;
}
export interface BookContent {
  book: Book;
  file: File;
}
