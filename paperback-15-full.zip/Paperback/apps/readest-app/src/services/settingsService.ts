import { FileSystem } from '@/types/system';
import { LibrarySecondarySortByType, ReadSettings, SystemSettings } from '@/types/settings';
import { DEFAULT_HIGHLIGHT_COLORS, UserHighlightColor, ViewSettings } from '@/types/book';
import { v4 as uuidv4 } from 'uuid';
import {
  DEFAULT_BOOK_LAYOUT,
  DEFAULT_BOOK_STYLE,
  DEFAULT_BOOK_FONT,
  DEFAULT_VIEW_CONFIG,
  DEFAULT_READSETTINGS,
  SYSTEM_SETTINGS_VERSION,
  DEFAULT_TTS_CONFIG,
  DEFAULT_MOBILE_VIEW_SETTINGS,
  DEFAULT_SYSTEM_SETTINGS,
  DEFAULT_CJK_VIEW_SETTINGS,
  DEFAULT_MOBILE_READSETTINGS,
  DEFAULT_SCREEN_CONFIG,
  SETTINGS_FILENAME,
  DEFAULT_MOBILE_SYSTEM_SETTINGS,
  DEFAULT_ANNOTATOR_CONFIG,
  DEFAULT_EINK_VIEW_SETTINGS,
  DEFAULT_VIEW_SETTINGS_CONFIG,
} from './constants';
import { isCJKEnv } from '@/utils/misc';
import { safeLoadJSON, safeSaveJSON } from './persistence';

export interface Context {
  fs: FileSystem;
  isMobile: boolean;
  isEink: boolean;
  isAppDataSandbox: boolean;
}

export function getDefaultViewSettings(ctx: Context): ViewSettings {
  return {
    ...DEFAULT_BOOK_LAYOUT,
    ...DEFAULT_BOOK_STYLE,
    ...DEFAULT_BOOK_FONT,
    ...DEFAULT_VIEW_CONFIG,
    ...DEFAULT_TTS_CONFIG,
    ...DEFAULT_SCREEN_CONFIG,
    ...DEFAULT_ANNOTATOR_CONFIG,
    ...DEFAULT_VIEW_SETTINGS_CONFIG,
    ...(ctx.isMobile ? DEFAULT_MOBILE_VIEW_SETTINGS : {}),
    ...(ctx.isEink ? DEFAULT_EINK_VIEW_SETTINGS : {}),
    ...(isCJKEnv() ? DEFAULT_CJK_VIEW_SETTINGS : {}),
  };
}

/**
 * Normalize highlight color prefs into the current shape:
 * - `userHighlightColors` becomes `UserHighlightColor[]`. Legacy `string[]` entries
 *   are lifted into `{ hex }`. A legacy `highlightColorLabels` map (shipped only in
 *   draft builds of this feature) is folded in: hex entries attach to matching user
 *   colors, named entries move into `defaultHighlightLabels`.
 */
export function migrateHighlightColorPrefs(read: ReadSettings): void {
  const rawUser = (read.userHighlightColors ?? []) as unknown[];
  const userColors: UserHighlightColor[] = rawUser
    .map((entry) => {
      if (typeof entry === 'string') {
        return { hex: entry.trim().toLowerCase() };
      }
      if (entry && typeof entry === 'object' && 'hex' in entry) {
        const { hex, label } = entry as UserHighlightColor;
        return {
          hex: typeof hex === 'string' ? hex.trim().toLowerCase() : '',
          ...(label?.trim() ? { label: label.trim() } : {}),
        };
      }
      return { hex: '' };
    })
    .filter((entry) => entry.hex.startsWith('#'));

  read.defaultHighlightLabels = { ...(read.defaultHighlightLabels ?? {}) };

  const legacyLabels = (read as unknown as { highlightColorLabels?: unknown }).highlightColorLabels;
  if (legacyLabels && typeof legacyLabels === 'object') {
    const labels = legacyLabels as Record<string, unknown>;
    for (const name of DEFAULT_HIGHLIGHT_COLORS) {
      const value = labels[name];
      if (typeof value === 'string' && value.trim() && !read.defaultHighlightLabels[name]) {
        read.defaultHighlightLabels[name] = value.trim();
      }
    }
    for (const entry of userColors) {
      if (entry.label) continue;
      const value = labels[entry.hex];
      if (typeof value === 'string' && value.trim()) {
        entry.label = value.trim();
      }
    }
    delete (read as unknown as { highlightColorLabels?: unknown }).highlightColorLabels;
  }

  read.userHighlightColors = userColors;
}

/**
 * `librarySortBy2` was renamed to `libraryThenSortBy` (#5119). Carry a stored
 * pre-rename pick over so users keep their "Then by" sort, then drop the legacy
 * key so a later explicit `'none'` isn't resurrected on the next load.
 */
export function migrateLibraryThenSort(settings: SystemSettings): void {
  const legacy = settings as unknown as { librarySortBy2?: LibrarySecondarySortByType };
  if (!legacy.librarySortBy2) return;
  if (settings.libraryThenSortBy === 'none') {
    settings.libraryThenSortBy = legacy.librarySortBy2;
  }
  delete legacy.librarySortBy2;
}

export async function loadSettings(ctx: Context): Promise<SystemSettings> {
  const defaultSettings: SystemSettings = {
    ...DEFAULT_SYSTEM_SETTINGS,
    ...(ctx.isMobile ? DEFAULT_MOBILE_SYSTEM_SETTINGS : {}),
    version: SYSTEM_SETTINGS_VERSION,
    localBooksDir: await ctx.fs.getPrefix('Books'),
    koreaderSyncDeviceId: uuidv4(),
    globalReadSettings: {
      ...DEFAULT_READSETTINGS,
      ...(ctx.isMobile ? DEFAULT_MOBILE_READSETTINGS : {}),
    },
    globalViewSettings: getDefaultViewSettings(ctx),
  } as SystemSettings;

  let settings = await safeLoadJSON<SystemSettings>(
    ctx.fs,
    SETTINGS_FILENAME,
    'Settings',
    defaultSettings,
  );

  const version = settings.version ?? 0;
  if (ctx.isAppDataSandbox || version < SYSTEM_SETTINGS_VERSION) {
    settings.version = SYSTEM_SETTINGS_VERSION;
  }
  settings = {
    ...DEFAULT_SYSTEM_SETTINGS,
    ...(ctx.isMobile ? DEFAULT_MOBILE_SYSTEM_SETTINGS : {}),
    ...settings,
  };
  settings.globalReadSettings = {
    ...DEFAULT_READSETTINGS,
    ...(ctx.isMobile ? DEFAULT_MOBILE_READSETTINGS : {}),
    ...settings.globalReadSettings,
  };
  migrateHighlightColorPrefs(settings.globalReadSettings);
  settings.globalViewSettings = {
    ...getDefaultViewSettings(ctx),
    ...settings.globalViewSettings,
  };

  settings.localBooksDir = await ctx.fs.getPrefix('Books');

  // Coerce stale `'wikipedia'` quick-action to `'dictionary'`. The Wikipedia
  // annotation tool was removed; Wikipedia is now reachable as a tab inside
  // the unified dictionary popup. Without this guard, users who had set the
  // quick action to wikipedia would get a no-op.
  if ((settings.globalViewSettings.annotationQuickAction as string) === 'wikipedia') {
    settings.globalViewSettings.annotationQuickAction = 'dictionary';
  }

  migrateLibraryThenSort(settings);
  if (!settings.replicaDeviceId) {
    settings.replicaDeviceId = uuidv4();
    await saveSettings(ctx.fs, settings);
  }

  return settings;
}

let settingsWrites: Promise<void> = Promise.resolve();
/**
 * The newest queued settings, or null once it is safely on disk. Saves run on
 * hot paths (every view-setting slider step), so a burst would otherwise do one
 * write per step. Only the newest object needs writing; the earlier callers still await a
 * link that resolves after a write carrying their data or newer, and reject with
 * it when it fails — the stamp is only dropped once the write succeeds, so the
 * next link retries instead of reporting a silent success.
 */
let pendingSettings: SystemSettings | null = null;
export async function saveSettings(fs: FileSystem, settings: SystemSettings): Promise<void> {
  pendingSettings = settings;
  const write = async () => {
    const next = pendingSettings;
    if (!next) return;
    await safeSaveJSON(fs, SETTINGS_FILENAME, 'Settings', next);
    if (pendingSettings === next) pendingSettings = null;
  };
  settingsWrites = settingsWrites.catch(() => {}).then(write);
  await settingsWrites;
}
