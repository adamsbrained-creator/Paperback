// Paperback: pure aggregation over KOReader-style page-read events.
// No React, no DB, no Date.now() — everything takes `now` so it is testable.
// All day/hour bucketing uses the device's LOCAL time zone.

export interface StatEventRow {
  md5: string;
  title: string;
  authors: string;
  page: number;
  startTime: number; // Unix seconds
  duration: number; // seconds
  totalPages: number;
}

export interface Summary {
  seconds: number;
  pages: number;
  books: number;
  sessions: number;
  avgSessionSeconds: number;
  pagesPerHour: number;
}

export interface HeatCell {
  key: string; // yyyy-mm-dd
  seconds: number;
  level: 0 | 1 | 2 | 3 | 4;
  inFuture: boolean;
}

export interface TopBook {
  md5: string;
  title: string;
  authors: string;
  seconds: number;
  share: number; // 0..1 of range time
}

export interface Session {
  md5: string;
  title: string;
  start: number; // Unix seconds
  end: number;
  seconds: number;
  pageFrom: number;
  pageTo: number;
  /** Distinct pages visited in this session (a page re-read within it counts once). */
  pages: number;
}

/** A page visit longer than this is a forgotten screen, not reading. */
const MAX_EVENT_SECONDS = 120;
/** Two events of the same book closer than this belong to one session. */
const SESSION_GAP_SECONDS = 10 * 60;
/** A day counts toward the streak after this much reading. */
export const STREAK_MIN_SECONDS = 60;

const pad = (n: number) => String(n).padStart(2, '0');

export const dayKeyOf = (d: Date): string =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

const dayKeyOfSec = (sec: number): string => dayKeyOf(new Date(sec * 1000));

const startOfDay = (d: Date): Date => new Date(d.getFullYear(), d.getMonth(), d.getDate());

const addDays = (d: Date, n: number): Date =>
  new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);

/** Monday = 0 … Sunday = 6. */
const mondayIndex = (d: Date): number => (d.getDay() + 6) % 7;

export const clampDuration = (e: StatEventRow): number =>
  Math.max(0, Math.min(e.duration, MAX_EVENT_SECONDS));

export function buildSessions(events: StatEventRow[]): Session[] {
  const sorted = [...events].sort((a, b) => a.startTime - b.startTime);
  const sessions: Session[] = [];
  let cur: Session | null = null;
  let curPages = new Set<number>();
  for (const e of sorted) {
    const dur = clampDuration(e);
    if (dur <= 0) continue;
    const end = e.startTime + dur;
    if (cur && cur.md5 === e.md5 && e.startTime - cur.end <= SESSION_GAP_SECONDS) {
      cur.seconds += dur;
      cur.end = Math.max(cur.end, end);
      cur.pageFrom = Math.min(cur.pageFrom, e.page);
      cur.pageTo = Math.max(cur.pageTo, e.page);
      curPages.add(e.page);
      cur.pages = curPages.size;
    } else {
      curPages = new Set([e.page]);
      cur = {
        md5: e.md5,
        title: e.title,
        start: e.startTime,
        end,
        seconds: dur,
        pageFrom: e.page,
        pageTo: e.page,
        pages: 1,
      };
      sessions.push(cur);
    }
  }
  return sessions;
}

export function computeSummary(events: StatEventRow[]): Summary {
  let seconds = 0;
  const pages = new Set<string>();
  const books = new Set<string>();
  for (const e of events) {
    const dur = clampDuration(e);
    if (dur <= 0) continue;
    seconds += dur;
    pages.add(`${e.md5}:${e.page}`);
    books.add(e.md5);
  }
  const sessions = buildSessions(events).length;
  return {
    seconds,
    pages: pages.size,
    books: books.size,
    sessions,
    avgSessionSeconds: sessions ? Math.round(seconds / sessions) : 0,
    pagesPerHour: seconds > 0 ? Math.round((pages.size / seconds) * 3600) : 0,
  };
}

/** Seconds read per local day, all time. */
export function secondsByDay(events: StatEventRow[]): Map<string, number> {
  const map = new Map<string, number>();
  for (const e of events) {
    const dur = clampDuration(e);
    if (dur <= 0) continue;
    const k = dayKeyOfSec(e.startTime);
    map.set(k, (map.get(k) ?? 0) + dur);
  }
  return map;
}

export function computeStreaks(
  byDay: Map<string, number>,
  now: Date,
): { current: number; longest: number } {
  const qualifies = (d: Date) => (byDay.get(dayKeyOf(d)) ?? 0) >= STREAK_MIN_SECONDS;
  const today = startOfDay(now);

  // Current: today may still be in progress, so an empty today does not break it.
  let cursor = qualifies(today) ? today : addDays(today, -1);
  let current = 0;
  while (qualifies(cursor)) {
    current++;
    cursor = addDays(cursor, -1);
  }

  const days = [...byDay.entries()]
    .filter(([, s]) => s >= STREAK_MIN_SECONDS)
    .map(([k]) => {
      const [y, m, d] = k.split('-').map(Number);
      return new Date(y!, m! - 1, d!);
    })
    .sort((a, b) => a.getTime() - b.getTime());
  let longest = 0;
  let run = 0;
  let prev: Date | null = null;
  for (const d of days) {
    run = prev && dayKeyOf(addDays(prev, 1)) === dayKeyOf(d) ? run + 1 : 1;
    longest = Math.max(longest, run);
    prev = d;
  }
  return { current, longest: Math.max(longest, current) };
}

const levelOf = (seconds: number): HeatCell['level'] => {
  const min = seconds / 60;
  if (min < 1) return 0;
  if (min < 15) return 1;
  if (min < 30) return 2;
  if (min < 60) return 3;
  return 4;
};

/** `weeks` columns × 7 rows (Mon→Sun), the last column is the current week. */
export function buildHeatmap(byDay: Map<string, number>, now: Date, weeks = 18): HeatCell[][] {
  const today = startOfDay(now);
  const lastMonday = addDays(today, -mondayIndex(today));
  const firstMonday = addDays(lastMonday, -7 * (weeks - 1));
  const columns: HeatCell[][] = [];
  for (let w = 0; w < weeks; w++) {
    const col: HeatCell[] = [];
    for (let d = 0; d < 7; d++) {
      const date = addDays(firstMonday, w * 7 + d);
      const key = dayKeyOf(date);
      const seconds = byDay.get(key) ?? 0;
      const inFuture = date.getTime() > today.getTime();
      col.push({ key, seconds, level: inFuture ? 0 : levelOf(seconds), inFuture });
    }
    columns.push(col);
  }
  return columns;
}

export function topBooks(events: StatEventRow[], limit = 5): TopBook[] {
  const map = new Map<string, TopBook>();
  let total = 0;
  for (const e of events) {
    const dur = clampDuration(e);
    if (dur <= 0) continue;
    total += dur;
    const cur = map.get(e.md5);
    if (cur) cur.seconds += dur;
    else map.set(e.md5, { md5: e.md5, title: e.title, authors: e.authors, seconds: dur, share: 0 });
  }
  return [...map.values()]
    .sort((a, b) => b.seconds - a.seconds)
    .slice(0, limit)
    .map((b) => ({ ...b, share: total ? b.seconds / total : 0 }));
}

export const formatClock = (sec: number): string => {
  const d = new Date(sec * 1000);
  return `${d.getHours()}:${pad(d.getMinutes())}`;
};

/** 112h · 1h 05m · 42m · 0m */
export const formatDuration = (seconds: number): string => {
  const mins = Math.round(seconds / 60);
  if (mins >= 6000) return `${Math.round(mins / 60)}h`;
  if (mins >= 60) {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return m === 0 ? `${h}h` : `${h}h ${pad(m)}m`;
  }
  return `${mins}m`;
};

export const formatCount = (n: number): string => n.toLocaleString('en-US');

export interface PaceInfo {
  expected: number;
  delta: number; // finished - expected (rounded down); >=0 on pace
  label: string;
}

/** Books-goal pace: finished vs. what a straight line through the year predicts. */
export function booksPace(finished: number, goal: number, now: Date): PaceInfo {
  const start = new Date(now.getFullYear(), 0, 1).getTime();
  const end = new Date(now.getFullYear() + 1, 0, 1).getTime();
  const elapsed = (now.getTime() - start) / (end - start);
  const expected = Math.floor(goal * elapsed);
  const delta = finished - expected;
  const left = Math.max(goal - finished, 0);
  const status = delta >= 0 ? 'on pace' : `${-delta} behind`;
  return { expected, delta, label: `${left} to go · ${status}` };
}

// ---- rolling windows for the Stats screen ------------------------------------------------
// Week = the last 7 days, month = the last 30 days, year = the last 12 months, each ending today,
// compared with the window of the same length right before it.

