/**
 * Dictionary provider registry.
 *
 * Returns the ordered list of {@link DictionaryProvider} instances visible
 * in the lookup popup, given the user's current `dictionarySettings` (order,
 * enable flags), the imported-dictionary metadata, and the filesystem
 * accessor used by import-backed providers (StarDict / MDict) to lazily open
 * their bundle files.
 *
 * Provider instances are cached at module scope (keyed by id) so subsequent
 * lookups within the same session reuse parsed indexes / object URLs. This
 * cache is **not** in zustand: provider instances and their object URLs are
 * runtime-only and non-serializable; storing them alongside metadata would
 * pollute the synced settings shape.
 */
import type { DictionaryProvider, DictionarySettings, ImportedDictionary } from './types';
import { BUILTIN_PROVIDER_IDS } from './types';
import { isSystemDictionarySupported } from './systemDictionary';
import { wiktionaryProvider } from './providers/wiktionaryProvider';
import { wikipediaProvider } from './providers/wikipediaProvider';

const instanceCache = new Map<string, DictionaryProvider>();

interface RegistryArgs {
  settings: DictionarySettings;
  dictionaries: ImportedDictionary[];
  /** Kept for callers that still pass it; imported dictionaries are no longer supported. */
  fs?: unknown;
}

const builtinFor = (id: string): DictionaryProvider | undefined => {
  if (id === BUILTIN_PROVIDER_IDS.wiktionary) return wiktionaryProvider;
  if (id === BUILTIN_PROVIDER_IDS.wikipedia) return wikipediaProvider;
  // System dictionary is a sentinel — it has no in-popup UI. The
  // annotator handles it before reaching the popup; the registry
  // filters it out of `getEnabledProviders` so no empty tab appears.
  return undefined;
};

const getOrCreate = (id: string): DictionaryProvider | undefined => {
  const cached = instanceCache.get(id);
  if (cached) return cached;
  const builtin = builtinFor(id);
  if (builtin) instanceCache.set(id, builtin);
  return builtin;
};

/**
 * Returns the ordered list of enabled providers ready for the popup.
 * - Filters out disabled ids.
 * - Filters out imported entries that are soft-deleted, unavailable on this
 *   device, or flagged unsupported.
 * - Filters out the system-dictionary sentinel (no in-popup UI; handled
 *   directly by the annotator before the popup opens).
 * - Preserves the order in `settings.providerOrder`.
 */
export const getEnabledProviders = ({ settings }: RegistryArgs): DictionaryProvider[] => {
  const out: DictionaryProvider[] = [];
  for (const id of settings.providerOrder) {
    if (settings.providerEnabled[id] === false) continue;
    if (id === BUILTIN_PROVIDER_IDS.systemDictionary) continue;
    if (!id.startsWith('builtin:')) continue;
    const provider = getOrCreate(id);
    if (provider) out.push(provider);
  }
  return out;
};

/**
 * True when the user has enabled the system-dictionary entry in
 * settings. The annotator checks this before opening the in-app popup
 * — when set, the selection is handed to the OS instead. Independent
 * of `getEnabledProviders` (which filters the sentinel out so no empty
 * tab appears) so callers don't need to look at order/list shape to
 * make the dispatch decision.
 *
 * Gated by platform support: `providerEnabled` is whole-field synced
 * across devices, so a flag set on (say) macOS would otherwise reach a
 * Windows device that has no handoff implementation, leaving the
 * annotator with no way to look up a word. Short-circuiting here keeps
 * the setting durable on the device where it makes sense while making
 * it a no-op everywhere else.
 */
export const isSystemDictionaryEnabled = (settings: DictionarySettings): boolean => {
  if (!isSystemDictionarySupported()) return false;
  return settings.providerEnabled[BUILTIN_PROVIDER_IDS.systemDictionary] === true;
};

