import { useMemo } from 'react';
import { useSettingsStore } from '@/store/settingsStore';
import type { LibraryCoverFitType } from '@/types/settings';

export interface BookshelfCoverSettings {
  hideCovers: boolean;
  coverFit: LibraryCoverFitType;
  skeuomorphicCovers: boolean;
}

/**
 * Cover appearance for surfaces that are not inside a shelf. The reader is
 * memoized, so the result keeps the same object until a setting changes.
 */
export const useDefaultBookshelfCovers = (): BookshelfCoverSettings => {
  const hideCovers = useSettingsStore((state) => state.settings.libraryHideCovers ?? false);
  const coverFit = useSettingsStore((state) => state.settings.libraryCoverFit ?? 'crop');
  const skeuomorphicCovers = useSettingsStore(
    (state) => state.settings.librarySkeuomorphicCovers ?? false,
  );
  return useMemo(
    () => ({ hideCovers, coverFit, skeuomorphicCovers }),
    [hideCovers, coverFit, skeuomorphicCovers],
  );
};
