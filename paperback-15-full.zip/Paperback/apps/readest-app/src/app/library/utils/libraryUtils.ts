import { Book } from '@/types/book';
import {
  getContributorNames,
} from '@/utils/book';
import { stubTranslation as _ } from '@/utils/misc';
import { SIZE_PER_LOC, SIZE_PER_TIME_UNIT } from '@/services/constants';

// Calibre custom column names and values, flattened for searching (#4811).
const normalizeValues = (values: string[]): string[] => [
  ...new Set(values.map((value) => value.trim()).filter(Boolean)),
];

export const getBookSubjects = (book: Book): string[] => {
  return getContributorNames(book.metadata?.subject);
};

export const getBookTags = (book: Book): string[] => normalizeValues(book.tags ?? []);

// Applied to the selected books only, never to the rest of the library.
// Returns a new array where only the books whose tags actually change are new
// objects. Tags merge with the metadata group on its own clock, so a changed
// book stamps metadataUpdatedAt like a metadata edit does, leaving updatedAt
// (the Date Read sort key) alone (#6414).
export const getTimeRemainingMinutes = (
  book: Book,
  medianPageDurationSecs?: number,
): number | undefined => {
  const pagesLeft = book.progress ? book.progress[1] - book.progress[0] : undefined;
  if (!pagesLeft) return undefined;
  return convertPagesToTimeRemainingMinutes(pagesLeft, medianPageDurationSecs);
};

export const convertPagesToTimeRemainingMinutes = (
  pagesLeft: number,
  medianPageDurationSecs?: number,
): number => {
  // Prefer the reader's own pace; fall back to the coarse global estimate.
  const minutesPerPage = medianPageDurationSecs
    ? medianPageDurationSecs / 60
    : SIZE_PER_LOC / SIZE_PER_TIME_UNIT;
  return Math.max(1, Math.round(pagesLeft * minutesPerPage));
};

/**
 * Minutes a book still needs, or `undefined` when its tile shows no time at all.
 * Finished, on-hold and unread books render a status badge instead of a time (see
 * `ReadingProgress`), even when they still have pages left — so they have no time
 * to sort by. Sorting and the label must agree on this, hence the shared helper.
 */
export const getDisplayedTimeRemaining = (
  book: Book,
  medianPageDurationSecs?: number,
): number | undefined => {
  const { readingStatus } = book;
  if (readingStatus === 'finished' || readingStatus === 'abandoned' || readingStatus === 'unread') {
    return undefined;
  }
  return getTimeRemainingMinutes(book, medianPageDurationSecs);
};

// A tenth of an hour is still meaningful below 10h (1.6h); above it, a tenth
// stops mattering once there are dozens of hours left.
// localeCompare with an options object builds a new collator on every call, which
// is ~20x slower in V8, so title sorts reuse one numeric collator per locale.
/**
 * Parse a combined author string into individual author names.
 * Handles common separators like ", ", " & ", " and ".
 */
export const parseAuthors = (authorString: string): string[] => {
  if (!authorString || !authorString.trim()) {
    return [];
  }

  // Split by common separators: comma, ampersand, "and"
  // Use regex to handle variations with different spacing
  const authors = authorString
    .split(/\s*(?:,|&|\band\b)\s*/i)
    .map((author) => author.trim())
    .filter((author) => author.length > 0);

  return authors;
};

