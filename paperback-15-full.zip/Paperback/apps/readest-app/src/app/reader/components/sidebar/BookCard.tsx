import clsx from 'clsx';
import { useRef } from 'react';
import { Book } from '@/types/book';
import { useThemeStore } from '@/store/themeStore';
import { useTranslation } from '@/hooks/useTranslation';
import { formatAuthors, formatTitle } from '@/utils/book';
import BookCover from '@/components/BookCover';
import BookCoverViewer, { useBookCoverViewer } from '@/components/BookCoverViewer';
import { useDefaultBookshelfCovers } from '@/hooks/useDefaultBookshelfCovers';

const BookCard = ({ book }: { book: Book }) => {
  const { title, author } = book;
  const _ = useTranslation();
  const { skeuomorphicCovers } = useDefaultBookshelfCovers();
  const { isDarkMode } = useThemeStore();
  const bookCoverRef = useRef<HTMLButtonElement | null>(null);
  const { coverSrc, openCoverViewer, closeCoverViewer } = useBookCoverViewer(book);

  return (
    <div className='flex h-20 w-full items-center'>
      <button
        ref={bookCoverRef}
        type='button'
        aria-label={_('View Book Cover')}
        className={clsx(
          'me-4 aspect-[28/41] max-h-16 w-[15%] max-w-12 overflow-hidden rounded-xs shadow-md',
          isDarkMode ? 'mix-blend-screen' : 'mix-blend-multiply',
        )}
        onClick={openCoverViewer}
      >
        <BookCover
          book={book}
          mode='list'
          coverFit='crop'
          showSpine={skeuomorphicCovers}
          imageClassName='rounded-xs'
          onImageError={() => (bookCoverRef.current!.style.display = 'none')}
        />
      </button>
      {coverSrc && <BookCoverViewer src={coverSrc} onClose={closeCoverViewer} />}
      <div className='min-w-0 flex-1'>
        <h4 className='line-clamp-2 w-[90%] text-sm font-semibold'>
          {formatTitle(title).replace(/\u00A0/g, ' ')}
        </h4>
        <p className='truncate text-xs opacity-75'>{formatAuthors(author)}</p>
      </div>
    </div>
  );
};

export default BookCard;
