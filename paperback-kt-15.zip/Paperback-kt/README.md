# Paperback 2 (Kotlin)

Paperback rebuilt natively: Kotlin, Jetpack Compose, and the Readium toolkit for EPUB (instead of Readest).
Android only. Package id `com.paperback.app`, so it installs next to the old TypeScript Paperback.

## What works in this first step
- Import EPUBs (copied into the app, deduplicated by file hash, cover and page count read from the book)
- Home (continue reading, today, streak, recently read), Library (search, filters, favorite / finished / remove), Stats (today, week, streaks, last 7 days, most read)
- Reader: page turns by tapping the screen edges, tap the middle for controls (slider, font size, light / sepia / dark), position saved on every page turn
- Reading time and pages counted per session (idle time is capped, like Readest)

### Added in round 2
- Bookmarks: bookmark button at the top of the reader, list in the notes panel
- Highlights and notes: select text, choose Highlight or Note; tap a highlight to edit it (note, colour, delete)
- Panel (button next to the bookmark) lists all bookmarks and notes of the book; tap one to jump there
- Reader controls now follow the page theme (light / sepia / dark)
- Fixed: the reader header jumped and lagged when the controls toggled. The phone's status and navigation bars now stay hidden
  for the whole reading session (swipe from the edge to peek), so nothing resizes when you tap the page

### Added in round 3: Settings (copied from the TypeScript app)
- **Settings page** exactly as in `app/(paperback)/settings/page.tsx`: daily-goal card (ring, minutes today, Edit), then READING (Reading goals, Reading stats, Reader defaults), LOOK (Appearance, App style), LIBRARY (Library & import, Backup & restore) and About, with the round menu button at the bottom right
- **Page header** in the three sizes (Compact / Regular / Large) on every screen, with the menu and search buttons; Library shows its book-count chip
- **Menu**: the pop-up card above the round button (Home, Library, Discover, Collections, Bookmarks, Stats, Settings, More) and the "All pages" sheet. Pages that are not built yet say "Soon"
- **App style** (header size with a live sample of each), **About** (logo tile, Credits, Open-source licenses), **Appearance** (Light / Dark / Match system), **Reading goals** (books this year, pages, minutes, streak, editable)
- **Reader defaults** (font size and page colors) and **Library & import**, both real, not placeholders
- **Backup & restore**: one JSON file with progress, favorites, ratings, bookmarks, highlights, reading history, goals and settings. Restore matches books by hash and never moves reading progress backwards
- The icons are the TypeScript app's own SVG paths (`PbIcons.kt`), so they are identical
- Navigation is now a small back stack in `PaperbackRoot.kt` (Back returns; tabs replace each other)

Not copied yet: Appearance's **Home layout** (Pile) and **Navigation** style (dock, header switch, off), because the Kotlin Home and tab bar have only one layout.
Outfit is not bundled yet (the font could not be downloaded); text uses the system sans. To add it, put Outfit-Regular/Medium/SemiBold.ttf in `app/src/main/res/font/` and point `PbSans` in `ui/theme/Theme.kt` at them.

### Added in step 4 (built on step 3)
- **Book page**: Library long-press -> Details, or tap the title on Home. Rating (stars), Favorite / Finished, progress, time read, page, sessions, collections, link to the book's notes, journal, remove
- **Collections** (menu -> Collections): create, rename, delete, add and remove books; a book's page can also toggle its collections
- **Notes & highlights** and **Bookmarks** (menu / All pages): every highlight, note and bookmark across all books, search, tap to open the book at that spot, remove, share notes as Markdown. Bookmarks opens on the second tab
- **Shelf pages** (All pages): Currently reading, Recently read, Finished, Favorites. Tap a cover for the book page
- **Finish date**: finishing a book now saves the date, so "books this year" in Reading goals is exact (older finished books still use the date they were last opened)
- **Backup** now also keeps journals, finish dates and collections (older backups still restore)
- Database upgrades in place (version 3): journal, finish date, collections. Existing libraries and history are kept

### Added in step 5
- **Global search** (the search button in every page header, or menu -> All pages -> Search): books by title, author or journal, your notes and highlights, collections, and the app's own pages (type "backup", "goals", "theme"...). Ignores capitals and accents; every word you type must match; matches are shown in coral
- Tap a book for its page, a note to open the book at that passage, a collection or page to go there. Back returns to the same search
- Recent searches are remembered (Clear removes them)

### Step 6: polish (no new features)
- One set of building blocks (`ui/PbKit.kt`): dialog, filled text field, rounded cards, segmented switch, round select mark, action pills. Every page and dialog from steps 4 and 5 now uses them instead of Material's stock look
- Dialogs (Add books, new / rename collection, delete, remove book, reader note editor) are rounded cards with a serif title and pill buttons. Add books has a search box, covers, and round ticks
- Text fields are filled with the card colour, no outline. Library search and filters use them too (filters are the coral pills, not Material chips)
- Book page: sections use the Settings label style, Notes & bookmarks is a Settings-style row, About is a card, Remove is a red pill button
- Collections list is one card with covers and carets; Notes are cards (serif quote, colour dot); Search results are cards
- Shelf pages and collection grids show author and reading progress like the Library
- Library's long-press menu, the snackbar and the reader's buttons use the app's colours and icons

### Step 7: Discover (free books from the internet)
- **Discover** (menu -> Discover, All pages -> Get books, or "Discover free books" on an empty Home / Library / Import page). Lists the catalogs: **Project Gutenberg** and **Standard Ebooks** are always there; **Add a catalog** takes any OPDS address (Calibre, Kavita, COPS, a library server...). Your own catalogs can be edited or removed from the dots menu; they are stored on this device only
- Private catalogs: add a username and password (Basic and Digest login are both handled; Calibre's content server uses Digest). The password is only ever sent to that catalog's own address
- Browsing like the old app: the toolbar has Back, Home (the catalog's first page), a search box (when the catalog has search), a Filters menu (when the page has filters) and Close. Pages show navigation cards, shelves that scroll sideways ("See all"), book grids and First / Previous / Next / Last. Back goes back one page at a time and the scroll position of each page is remembered
- **Book page**: cover, title, authors, **Download EPUB** (a small arrow next to it lists the other EPUB versions when a book has several, e.g. Standard Ebooks' advanced EPUB), description, details and subjects. A book you already have shows **Open & Read** (and Download again); it is recognised by where it came from, or by its title if you added it by hand
- Downloads go straight into the Library (same duplicate check and cover reading as Import) with a progress bar. Only **EPUB** is downloaded; if a book is offered only as PDF / MOBI the page says so
- Covers are fetched with the catalog's login and kept in the app's cache, so a page you have seen opens instantly
- The app now asks for the **Internet** permission, and allows plain `http://` so catalogs on your home network (Calibre at `192.168...`) work
- Not done: OPDS pagination "infinite scroll", catalogs that need a web sign-in page (OAuth), buying or borrowing books

### Step 8: reading essentials + polish
- **Contents**: the book's table of contents, nested chapters indented, the chapter you are in marked in coral. Reader controls -> **Contents** (also the first tab of the top-right panel). Tap a chapter to go there
- **Search in the book**: reader controls -> **Search**. Type, press search on the keyboard, tap a match to jump to it (the match is marked on the page). Up to 200 matches
- **Text settings** (reader controls -> **Text**): a sheet that sits over the page so you see changes live. Font size, page colors, **margins**, **layout** (the book's own, or Custom: **font** serif / sans / mono, **line spacing**, **left or justified**) and **brightness** (own slider for the reader, or "Auto" to follow the phone)
- Margins and layout are also in **Settings -> Reader defaults**, with a live sample
- Sliders are now Paperback's own (slim track, round coral handle) in the reader and in Reader defaults
- Fixed icons: Appearance, App style, Backup and Reader were drawn wrong (compact SVG arc flags); the paths now use spaced flags
- Library: round coral "+" import button; dark theme no longer has a purple tint on Material's selected colours

### Step 9: PDF
- **Import PDFs** the same way as EPUBs (Import, Library "+", Settings -> Library & import). A PDF is recognised by its content, so a file with a wrong name still works. The cover is the first page, the title is the file name (no author: a PDF's own details can't be read here)
- **PDF reader** (its own screen, drawn with Android's built-in PdfRenderer, no extra library): one page at a time, fitted to the screen. Swipe or tap the left / right edge to turn the page, tap the middle for the controls. **Pinch** or **double-tap** to zoom (up to 5x, sharper copy of the page once you stop), drag to move the zoomed page
- Controls: back, bookmark, bookmarks list, page slider ("Go to page" while dragging), time left, and **View**: page colors (Light, Sepia, Dark), **Right to left** page turning for manga, brightness
- Same as for EPUB: position saved on every page turn (and it resumes there), reading time and pages counted, bookmarks, finished at the last page, progress in Home / Library / Stats, included in Backup
- Comics: a comic saved as a PDF works the same way (use "Right to left" for manga). CBZ / CBR files are not supported yet
- Not possible with this approach: selecting text, highlights and notes, searching inside the PDF, and a table of contents. Scanned and text PDFs both display, but the text can't be reflowed (zoom in instead)

### Step 10: PDF fixes
- Fixed: zooming a PDF page (pinch or double-tap) made the page disappear. Two causes: lifting the fingers while zoomed produced an invalid position, and the sharper zoomed copy could be bigger than the phone's graphics limit (4096 px) and then was not drawn
- Fixed: Dark (and Sepia) turned pictures into negatives. The viewer now checks each page: a page that is mostly white with almost no color is "text" and gets the Dark / Sepia colors; a page with pictures or color is shown as it is in every theme (on the Dark or Sepia background). A page that mixes a large color picture with text is treated as a picture page

### Step 11: PDF picture pages without the white sheet
- On a picture page (a page that is not mostly text) the viewer now finds the white margins around the picture and shows just the picture, so in Dark and Sepia there is no white sheet floating on the dark / sepia background. The picture is also a little bigger. This applies in every theme
- Text pages are shown whole. Nothing is cut when the page is nearly empty (a few stray marks) or already has no real margin
- Colors of pictures are never changed by the theme (this was already so in kt-10)

### Step 12: Genres, authors and recommendations (and Discover fixes)
- **Paperback now reads each book's genres / tags, description, publisher and date** (from the EPUB itself, and for Discover downloads also from the catalog). Books you already had are read once, in the background, after the update. PDFs have none of these. Messy subject lines are cleaned: "England -- Fiction" becomes the tags *England* and *Fiction*; codes like "LoCC: ..." and words like "Text" are dropped
- **Genres page** and **Authors page** (menu -> More, or search): every genre / author with its number of books, a filter field once there are many, tap one to see its books
- **Book page**: genre chips (tap one to see that genre), description with Read more, Publisher and Published in About, tap the author to see their books, and a **Similar in your library** row
- **Library**: a Sort menu (Recently added, Recently read, Title, Author, Rating, Progress) and a Genre filter; the Library search also finds genres
- **Home**: **Recommended for you**, with "Like <book>". Books you have not started, ranked by how much they resemble the books you rated 4-5, favorited, or finished (rated 1-2 count for nothing). It appears once you have rated, favorited or finished a book that has genres
- **Search** finds books by genre too, and lists matching Authors and Genres
- **Discover**: the book page shows a cleaned Genres list and a short description (Project Gutenberg's long catalogue record is cut to its Summary)
- Discover fixes: Project Gutenberg lists show covers and authors and open the book directly (no duplicate page); "No records found" is no longer tappable; a page that fails with "403 / busy" is retried once; pages you opened in the last 10 minutes load instantly from a cache
- Database version 4 (new columns; nothing is lost)

### Step 13: Chapter name and "pages left" around the page (EPUB reader)
- The reader now shows, always and quietly, like Readest: the **chapter name** above the page (top left), **"N pages left in chapter"** below it (bottom left) and **"position / total"** (bottom right, for example "2 / 196"). They hide while the controls are showing
- The two numbers count different things on purpose, as in Readest: "pages left" counts real screens (it drops by exactly 1 per page turn; the page you are on counts, so the last page says "1 page left"), while "2 / 196" counts Readium's fixed pieces of text, so one page turn can move it by 2 or more
- "Pages left" is measured on the page on screen (how many screens wide the chapter's file is), and re-measured after text size, margin, font or theme changes. For a chapter that continues into the next files it adds those files' length, estimated from the position counts. If a book's contents put several chapters in one file, the chapter ends where the next file starts
- The page area now has a 32 dp strip above and below it (plus the phone's status / navigation bar space) to hold this text; the strip takes the page colour of the theme
- The controls card still shows "Page X of Y . % . time left" as before

### Step 14: The "25 / 136" counter now counts like Readest
- Fixed: the counter stood still for 2-3 page turns (it showed the same number on several pages). Readium's "positions" are cut by the *packed* size of the book (about 1 per 3000 characters of text), so a page held less than one. The counter now uses Readest's way: the book is cut into pieces of 1500 bytes of its *unpacked* text (sizes read from the EPUB file itself), and the counter is the piece your page starts in. A page usually holds one or more pieces, so the number moves on every turn and sometimes jumps by 2
- The total ("/ 136") is that piece count, so it is larger than before and stays the same whatever the text size
- "Page X of Y" in the controls card shows the same two numbers (the "time left" there still uses the old position count)
- If a book's sizes can't be read, the counter falls back to Readium's positions as before

### Step 15: Reflow a PDF as an EPUB
- Open a PDF's book page and tap **Reflow as EPUB**. It reads the PDF's text and builds a new book called "Title (EPUB)" in your Library. The PDF is not touched, and its progress, bookmarks and stats stay with it. The copy is a normal EPUB, so Contents, search, notes, text size, fonts, margins, line spacing and the Light / Sepia / Dark pages all work
- A progress bar shows "Reading page N of M" with a Cancel button. One conversion runs at a time, and it keeps going if you leave the page. Converting the same PDF twice finds the first copy instead of adding another
- What it does: joins lines into paragraphs (first-line indents, extra space above, a short last line), joins words split by a hyphen at the end of a line, finds chapter and section headings (bigger or bold, standing alone) and builds the Contents from them, removes running headers, footers and page numbers, keeps italics and bold, raised footnote marks, bullet lists and scene breaks, puts footnotes after the paragraph they belong to, merges a big drop-cap letter back into its word, and keeps pictures where they were. The cover is the PDF's cover
- Limits: a **scanned PDF has no text** and is refused with a message (reading scans needs text recognition, which is not built). **Two-column pages, tables and maths** come out in a jumbled or flat order. Footnotes are placed after the paragraph, not at the page bottom. Comics and picture books have nothing to reflow
- The converter itself (`app/src/main/java/com/paperback/app/reflow`) is plain Java so it can be tested without a phone. It was checked on generated novels, a one-sentence-per-paragraph PDF, drop caps, bullets, footnotes, a double-spaced typescript, a scan, and a real LaTeX-typeset book. Reading the PDF itself uses the PDFBox for Android library (`com.tom-roush:pdfbox-android`, about 5 MB more in the app)

## Not done yet (in the old app, planned in this order)
CBZ / CBR comics, PDF text and notes, wishlist, journal page, dictionary and saved words, read aloud, milestones, Outfit and Newsreader fonts.

## Layout
- `app/src/main/java/com/paperback/app/data` database, import, stats maths (`Stats.kt` is the port of statsAggregate.ts)
- `.../reader` ReaderActivity (hosts Readium's fragment), the controls overlay, reading-time tracker
- `.../data/opds` the OPDS reader for Discover (XML / JSON parsing, web client with login), `DiscoverController.kt` and `OpdsStore.kt` (catalog list)
- `.../ui` Home, Library, Stats, book page, collections, notes, shelf pages, Discover, settings pages, menu, and the theme (same coral / black / white as before)

## Building
Upload the zip next to `.github/workflows/apk-kotlin-from-one-zip.yml` and run the workflow. Versions are in `gradle/libs.versions.toml`.
If Gradle can't find a version, change it there.
