package com.paperback.app.reflow;

/** The PDF can't be turned into a book. The message is written for the reader of the app. */
public final class ReflowException extends Exception {
    private static final long serialVersionUID = 1L;

    public ReflowException(String message) {
        super(message);
    }
}
