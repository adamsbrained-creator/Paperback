package com.paperback.app.reflow;

import android.content.Context;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.io.MemoryUsageSetting;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.CancellationException;

/** The whole job: a PDF file in, an EPUB file out. Runs on the calling thread, so call it from a background one. */
public final class PdfReflower {

    public interface Progress {
        /** Called as pages are read. Return false to cancel. */
        boolean update(int page, int total);
    }

    private PdfReflower() {
    }

    /**
     * @param workDir an empty-or-new folder for the pictures taken out of the PDF; deleted when done
     * @param meta    title, author and the rest for the new book; [Meta.author] is filled from the PDF when blank
     * @throws ReflowException    the PDF can't be reflowed (no text, locked); the message is fit to show
     * @throws CancellationException if [progress] returned false
     */
    public static void convert(Context context, File pdf, File out, File workDir, EpubWriter.Meta meta, Progress progress)
            throws IOException, ReflowException {
        PDFBoxResourceLoader.init(context.getApplicationContext());
        File images = new File(workDir, "images");
        if (!images.exists() && !images.mkdirs()) throw new IOException("Can't create " + images);
        PDDocument doc = null;
        try {
            try {
                doc = PDDocument.load(pdf, MemoryUsageSetting.setupTempFileOnly());
            } catch (IOException e) {
                if (e.getClass().getSimpleName().contains("InvalidPassword")) {
                    throw new ReflowException("This PDF is password-protected, so it can't be reflowed.");
                }
                throw new ReflowException("Couldn't read this PDF.");
            }
            int total = doc.getNumberOfPages();
            if (total == 0) throw new ReflowException("This PDF has no pages.");

            if (meta.author == null || meta.author.trim().length() == 0) {
                PDDocumentInformation info = doc.getDocumentInformation();
                if (info != null && info.getAuthor() != null) meta.author = info.getAuthor().trim();
            }

            PdfBoxExtractor extractor = new PdfBoxExtractor(images);
            Reflow reflow = new Reflow();
            for (int i = 0; i < total; i++) {
                if (progress != null && !progress.update(i, total)) throw new CancellationException("cancelled");
                PageData pd;
                try {
                    pd = extractor.extract(doc, i);
                } catch (IOException e) {
                    pd = new PageData(i, 595f, 842f);   // an unreadable page is left blank
                } catch (RuntimeException e) {
                    pd = new PageData(i, 595f, 842f);
                }
                reflow.addPage(pd);
            }
            if (progress != null && !progress.update(total, total)) throw new CancellationException("cancelled");

            Reflow.Result result = reflow.build();
            EpubWriter.write(result, meta, out);
        } finally {
            if (doc != null) {
                try {
                    doc.close();
                } catch (IOException ignored) {
                }
            }
            deleteTree(workDir);
        }
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }
}
