package com.paperback.app.reflow;

import android.graphics.Bitmap;

import com.tom_roush.pdfbox.contentstream.operator.Operator;
import com.tom_roush.pdfbox.cos.COSBase;
import com.tom_roush.pdfbox.cos.COSName;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDPage;
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle;
import com.tom_roush.pdfbox.pdmodel.font.PDFont;
import com.tom_roush.pdfbox.pdmodel.font.PDFontDescriptor;
import com.tom_roush.pdfbox.pdmodel.graphics.PDXObject;
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.text.TextPosition;
import com.tom_roush.pdfbox.util.Matrix;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Reads one PDF page at a time with PDFBox and hands the characters and pictures to {@link Reflow}.
 *
 * It rides on PDFTextStripper, which already knows how to decode every font; this class only records where each
 * character sits (and which pictures are drawn, and where) instead of letting the stripper build text.
 */
final class PdfBoxExtractor extends PDFTextStripper {

    private static final int MAX_IMAGE_SIDE = 1600;
    private static final int MAX_IMAGES = 600;

    private static final class Pending {
        final PDImageXObject image;
        final float x, y, w, h;

        Pending(PDImageXObject image, float x, float y, float w, float h) {
            this.image = image;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }

    private static final class Saved {
        final File file;
        final String key;
        final int pxW, pxH;

        Saved(File file, String key, int pxW, int pxH) {
            this.file = file;
            this.key = key;
            this.pxW = pxW;
            this.pxH = pxH;
        }
    }

    private static final Writer DISCARD = new Writer() {
        @Override
        public void write(char[] buf, int off, int len) {
        }

        @Override
        public void flush() {
        }

        @Override
        public void close() {
        }
    };

    private final File imageDir;
    private final Map<PDFont, boolean[]> fontStyles = new IdentityHashMap<PDFont, boolean[]>();
    private final Map<PDImageXObject, Saved> savedImages = new IdentityHashMap<PDImageXObject, Saved>();
    private int imageCounter = 0;

    private PageData page;
    private PDRectangle box;
    private final List<Pending> pending = new ArrayList<Pending>();

    PdfBoxExtractor(File imageDir) throws IOException {
        super();
        this.imageDir = imageDir;
    }

    /** Reads page [index] (0-based). */
    PageData extract(PDDocument doc, int index) throws IOException {
        PDPage pdPage = doc.getPage(index);
        box = pdPage.getCropBox();
        int rotation = pdPage.getRotation();
        float w = box.getWidth();
        float h = box.getHeight();
        if (rotation == 90 || rotation == 270) {
            float t = w;
            w = h;
            h = t;
        }
        page = new PageData(index, w, h);
        pending.clear();
        setStartPage(index + 1);
        setEndPage(index + 1);
        writeText(doc, DISCARD);

        float pageArea = Math.max(1f, w * h);
        boolean hasText = page.glyphs.size() >= 40;
        for (Pending p : pending) {
            if (savedImages.size() >= MAX_IMAGES) break;
            if (p.w < 28f || p.h < 28f) continue;
            // a page-sized picture under a page of text is a scan's background; don't even decode it
            if (hasText && p.w * p.h >= 0.8f * pageArea) continue;
            Saved s = save(p.image);
            if (s == null) continue;
            page.images.add(new PlacedImage(s.file, s.key, p.x, p.y, p.w, p.h, s.pxW, s.pxH));
        }
        pending.clear();
        PageData done = page;
        page = null;
        return done;
    }

    // ---- characters

    @Override
    protected void processTextPosition(TextPosition text) {
        if (page != null) {
            try {
                String u = text.getUnicode();
                if (u != null && u.length() > 0 && Math.abs(text.getDir()) < 0.5f) {
                    float size = text.getFontSizeInPt();
                    boolean[] style = styleOf(text.getFont());
                    page.glyphs.add(new Glyph(u, text.getXDirAdj(), text.getYDirAdj(), text.getWidthDirAdj(), size, style[0], style[1]));
                }
            } catch (RuntimeException ignored) {
                // one odd character is not worth losing the page
            }
        }
        super.processTextPosition(text);
    }

    private boolean[] styleOf(PDFont font) {
        boolean[] s = fontStyles.get(font);
        if (s != null) return s;
        boolean bold = false;
        boolean italic = false;
        if (font != null) {
            String name = font.getName();
            if (name != null) {
                String n = name.toLowerCase(Locale.ROOT);
                bold = n.contains("bold") || n.contains("black") || n.contains("heavy") || n.contains("semibold");
                italic = n.contains("italic") || n.contains("oblique");
            }
            PDFontDescriptor d = font.getFontDescriptor();
            if (d != null) {
                if (d.isItalic()) italic = true;
                if (d.isForceBold() || d.getFontWeight() >= 700f) bold = true;
            }
        }
        s = new boolean[] {bold, italic};
        fontStyles.put(font, s);
        return s;
    }

    // ---- pictures

    @Override
    protected void processOperator(Operator operator, List<COSBase> operands) throws IOException {
        if (page != null && "Do".equals(operator.getName()) && operands != null && !operands.isEmpty()
                && operands.get(0) instanceof COSName) {
            try {
                PDXObject xo = getResources().getXObject((COSName) operands.get(0));
                if (xo instanceof PDImageXObject) note((PDImageXObject) xo);
            } catch (RuntimeException ignored) {
                // a picture we can't place is skipped
            }
        }
        super.processOperator(operator, operands);
    }

    private void note(PDImageXObject image) {
        if (image.isStencil()) return;
        Matrix m = getGraphicsState().getCurrentTransformationMatrix();
        float w = m.getScalingFactorX();
        float h = m.getScalingFactorY();
        float x = m.getTranslateX() - box.getLowerLeftX();
        float bottom = m.getTranslateY() - box.getLowerLeftY();
        float top = box.getHeight() - (bottom + h);
        pending.add(new Pending(image, x, top, w, h));
    }

    private Saved save(PDImageXObject image) {
        Saved known = savedImages.get(image);
        if (known != null) return known;
        Bitmap bmp = null;
        Bitmap scaled = null;
        try {
            bmp = image.getImage();
            if (bmp == null) return null;
            int pw = bmp.getWidth();
            int ph = bmp.getHeight();
            int side = Math.max(pw, ph);
            Bitmap out = bmp;
            if (side > MAX_IMAGE_SIDE) {
                float k = MAX_IMAGE_SIDE / (float) side;
                scaled = Bitmap.createScaledBitmap(bmp, Math.max(1, Math.round(pw * k)), Math.max(1, Math.round(ph * k)), true);
                out = scaled;
            }
            boolean png = image.getSoftMask() != null;
            File f = new File(imageDir, "img" + (++imageCounter) + (png ? ".png" : ".jpg"));
            OutputStream os = new FileOutputStream(f);
            try {
                out.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 85, os);
            } finally {
                os.close();
            }
            Saved s = new Saved(f, "i" + imageCounter, image.getWidth(), image.getHeight());
            savedImages.put(image, s);
            return s;
        } catch (IOException e) {
            return null;
        } catch (RuntimeException e) {
            return null;
        } catch (OutOfMemoryError e) {
            return null;
        } finally {
            if (scaled != null) scaled.recycle();
            if (bmp != null) bmp.recycle();
        }
    }
}
