package com.paperback.app.reader

import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.ReaderFonts
import com.paperback.app.data.ReaderLook
import com.paperback.app.ui.PbIcon
import com.paperback.app.ui.PbIconName
import com.paperback.app.ui.theme.PbSerif
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// =================================================================================================
// Reader controls, style 4 ("Panel"): the Reader Settings tiles and the Advanced Settings page.
// =================================================================================================

private val FONT_MIN = 0.6f
private val FONT_MAX = 2.5f

/** A small round button with an icon and a caption under it. [active] tints it with the accent colour. */
@Composable
private fun CircleTool(
    c: ReaderColors,
    icon: PbIconName,
    caption: String,
    active: Boolean = false,
    onClick: () -> Unit,
) {
    val accent = MaterialTheme.colorScheme.primary
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(if (active) accent.copy(alpha = 0.18f) else c.chip)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) { PbIcon(icon, size = 20.dp, tint = if (active) accent else c.ink, contentDescription = caption) }
        Spacer(Modifier.height(4.dp))
        Text(caption, color = c.ink.copy(alpha = 0.6f), fontSize = 10.sp, maxLines = 1)
    }
}

/**
 * A tall rounded slider that fills from the bottom: drag up or down, or tap. [fraction] is 0..1.
 * The caption under it is its own button ([onCaption]) so a slider can offer a reset.
 */
@Composable
private fun TallSlider(
    c: ReaderColors,
    fraction: Float,
    icon: PbIconName,
    caption: String,
    modifier: Modifier = Modifier,
    onCaption: (() -> Unit)? = null,
    onFraction: (Float) -> Unit,
) {
    var heightPx by remember { mutableFloatStateOf(1f) }
    val change by rememberUpdatedState(onFraction)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(96.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(c.chip)
                .onSizeChanged { heightPx = it.height.toFloat() }
                .pointerInput(Unit) {
                    fun toFraction(y: Float): Float = 1f - (y / heightPx).coerceIn(0f, 1f)
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        change(toFraction(down.position.y))
                        drag(down.id) {
                            it.consume()
                            change(toFraction(it.position.y))
                        }
                    }
                },
        ) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(fraction.coerceIn(0.04f, 1f))
                    .background(c.ink.copy(alpha = 0.16f)),
            )
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)) {
                PbIcon(icon, size = 20.dp, tint = c.ink)
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            caption,
            color = c.ink.copy(alpha = 0.6f),
            fontSize = 10.sp,
            maxLines = 1,
            modifier = if (onCaption != null) Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onCaption).padding(horizontal = 4.dp) else Modifier,
        )
    }
}

/**
 * The tiles of the "Reader Settings" panel: page colours with a pencil, Voice, a big Text tile that opens Advanced settings,
 * Search, Transitions, Chapters, Lock, and the Text size and Brightness sliders.
 */
@Composable
internal fun ReaderPanelBody(
    c: ReaderColors,
    themeChoice: Int,
    fontSize: Double,
    brightness: Float,
    look: ReaderLook,
    onTheme: (Int) -> Unit,
    onSetFontSize: (Double) -> Unit,
    onBrightness: (Float) -> Unit,
    onLook: (ReaderLook) -> Unit,
    onListen: () -> Unit,
    onSearch: () -> Unit,
    onContents: () -> Unit,
    onAdvanced: () -> Unit,
) {
    val edge = c.ink.copy(alpha = 0.25f)
    val portrait = LocalConfiguration.current.orientation != android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val locked = look.orientation != 0
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // row 1: colours and Voice
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(c.chip)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    ThemeDot(Color.Unspecified, themeChoice < 0, 30.dp, "Auto, matches your phone", edge, split = true) { onTheme(ReaderThemes.AUTO) }
                    ReaderThemes.menuOrder.forEach { i ->
                        ThemeDot(ReaderThemes.colors(i).page, themeChoice == i, 30.dp, ReaderThemes.name(i), edge) { onTheme(i) }
                    }
                    Box(Modifier.size(30.dp).clip(CircleShape).clickable(onClick = onAdvanced), contentAlignment = Alignment.Center) {
                        PbIcon(PbIconName.Edit, size = 18.dp, tint = c.ink, contentDescription = "Text and background")
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("Theme", color = c.ink.copy(alpha = 0.6f), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
            Spacer(Modifier.width(12.dp))
            CircleTool(c, PbIconName.Wave, "Voice", onClick = onListen)
        }
        // rows 2 and 3: the Text tile and its two buttons on the left, Search, Transitions and the two sliders on the right
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Column {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .height(96.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(c.chip)
                            .clickable(onClick = onAdvanced)
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("Aa", color = c.ink, fontFamily = PbSerif, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                        Column {
                            Text("Text", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("Customize", color = c.ink.copy(alpha = 0.6f), fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("Advanced", color = c.ink.copy(alpha = 0.6f), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    CircleTool(c, PbIconName.Chapters, "Chapters", onClick = onContents)
                    CircleTool(c, PbIconName.Lock, "Lock", active = locked) {
                        onLook(look.copy(orientation = if (locked) 0 else if (portrait) 1 else 2))
                    }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    CircleTool(c, PbIconName.Search, "Search", onClick = onSearch)
                    CircleTool(c, PbIconName.Transitions, "Transitions", active = look.pageAnimation) {
                        onLook(look.copy(pageAnimation = !look.pageAnimation))
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TallSlider(
                        c = c,
                        fraction = ((fontSize.toFloat() - FONT_MIN) / (FONT_MAX - FONT_MIN)),
                        icon = PbIconName.TextSize,
                        caption = "Text Size",
                        modifier = Modifier.weight(1f),
                    ) { f ->
                        val next = (((FONT_MIN + f * (FONT_MAX - FONT_MIN)) * 10f).roundToInt() / 10f).toDouble()
                        if (next != (fontSize * 10).roundToInt() / 10.0) onSetFontSize(next)
                    }
                    TallSlider(
                        c = c,
                        fraction = if (brightness < 0f) 0.5f else ((brightness - 0.05f) / 0.95f),
                        icon = PbIconName.Sun,
                        caption = if (brightness < 0f) "Auto" else "Brightness",
                        modifier = Modifier.weight(1f),
                        onCaption = { onBrightness(-1f) },
                    ) { f -> onBrightness((0.05f + f * 0.95f).coerceIn(0.05f, 1f)) }
                }
            }
        }
    }
}

// =================================================================================================
// Advanced settings
// =================================================================================================

/** A font as the Advanced page lists it: the label under the "Aa", and what it sets in [ReaderLook]. */
private class FontChoice(val label: String, val family: Int, val name: String)

private fun fontChoices(imported: List<String>): List<FontChoice> =
    listOf(FontChoice("Serif", 0, ""), FontChoice("Sans", 1, ""), FontChoice("Mono", 2, "")) +
        ReaderFonts.SYSTEM.map { (label, css) -> FontChoice(label, 0, css) } +
        imported.map { FontChoice(it, 0, it) }

private fun FontChoice.selected(look: ReaderLook): Boolean =
    if (name.isEmpty()) look.fontName.isEmpty() && look.fontFamily == family else look.fontName == name

/** The Compose font for the sample text: an imported file, an Android system font, or one of the three families. */
@Composable
private fun rememberSampleFont(look: ReaderLook): FontFamily {
    val context = LocalContext.current
    return remember(look.fontName, look.fontFamily) {
        runCatching {
            when {
                look.fontName.isNotEmpty() -> {
                    val file = ReaderFonts.file(context, look.fontName)
                    FontFamily(if (file != null) Typeface.createFromFile(file) else Typeface.create(look.fontName, Typeface.NORMAL))
                }
                look.fontFamily == 1 -> FontFamily.SansSerif
                look.fontFamily == 2 -> FontFamily.Monospace
                else -> FontFamily.Serif
            }
        }.getOrDefault(FontFamily.Serif)
    }
}

private const val SAMPLE =
    "So we beat on, boats against the current, borne back ceaselessly into the past. Gatsby believed in the green light\u2026"

@Composable
private fun Group(c: ReaderColors, title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(title, color = c.ink.copy(alpha = 0.55f), fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        content()
    }
}

/** A round "\u2212" or "+" button. */
@Composable
private fun StepButton(c: ReaderColors, plus: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(CircleShape).background(c.page).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(if (plus) "+" else "\u2212", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun StepRow(c: ReaderColors, icon: PbIconName, label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        PbIcon(icon, size = 18.dp, tint = c.ink.copy(alpha = 0.7f))
        Spacer(Modifier.width(12.dp))
        Text(label, modifier = Modifier.weight(1f), color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        StepButton(c, false, onMinus)
        Text(value, modifier = Modifier.width(44.dp), color = c.ink, fontSize = 14.sp, textAlign = TextAlign.Center)
        StepButton(c, true, onPlus)
    }
}

/**
 * The Advanced settings page of the Panel style: a live preview, page colours, a font grid, size, weight, ligatures and alignment.
 * Anything changed here switches the book to the custom layout (otherwise the book's own styles would win). The last card opens
 * every other reader setting, so nothing is out of reach from this page.
 */
@Composable
fun ReaderAdvancedSheet(
    themeIndex: Int,
    themeChoice: Int,
    fontSize: Double,
    look: ReaderLook,
    onFontSize: (Double) -> Unit,
    onTheme: (Int) -> Unit,
    onLook: (ReaderLook) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = readerColors(themeIndex)
    BackHandler(onBack = onClose)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var imported by remember { mutableStateOf(ReaderFonts.list(context)) }
    var importMessage by remember { mutableStateOf<String?>(null) }
    var colorsOpen by rememberSaveable { mutableStateOf(false) }
    var moreOpen by rememberSaveable { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val name = withContext(Dispatchers.IO) { ReaderFonts.import(context, uri) }
            if (name == null) {
                importMessage = "That is not a font file (.ttf, .otf, .woff or .woff2)."
            } else {
                importMessage = null
                imported = ReaderFonts.list(context)
                onLook(look.copy(custom = true, fontName = name))
            }
        }
    }
    // Edits here turn the custom layout on.
    fun edit(change: (ReaderLook) -> ReaderLook) = onLook(change(look).copy(custom = true))

    val accent = MaterialTheme.colorScheme.primary
    val sample = rememberSampleFont(look)
    val shownSize = (fontSize * 16).roundToInt()
    val shownWeight = (look.fontWeight * 400).roundToInt()

    Box(
        modifier
            .fillMaxSize()
            .background(c.page)
            // swallow touches so nothing reaches the book underneath
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {},
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(top = 14.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text(
                "Advanced Settings",
                modifier = Modifier.fillMaxWidth(),
                color = c.ink.copy(alpha = 0.55f),
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )

            // Preview and the page colours
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(c.chip)) {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Text("Preview", color = c.ink.copy(alpha = 0.55f), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        SAMPLE,
                        color = c.ink,
                        style = TextStyle(
                            fontFamily = sample,
                            fontSize = (16f * fontSize.toFloat()).sp,
                            lineHeight = (16f * fontSize.toFloat() * (if (look.custom) look.lineSpacing else 1.5f)).sp,
                            fontWeight = FontWeight((400 * (if (look.custom) look.fontWeight else 1f)).roundToInt().coerceIn(100, 900)),
                            textAlign = if (look.custom && look.justify) TextAlign.Justify else TextAlign.Start,
                        ),
                    )
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(c.ink.copy(alpha = 0.08f)))
                Row(
                    Modifier.fillMaxWidth().clickable { colorsOpen = !colorsOpen }.padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(22.dp)) {
                        Box(Modifier.size(14.dp).clip(CircleShape).background(accent))
                        Box(Modifier.align(Alignment.BottomEnd).size(14.dp).clip(CircleShape).background(Color(0xFF5B8DEF).copy(alpha = 0.85f)))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Text & Background", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text("Create your perfect reading palette.", color = c.ink.copy(alpha = 0.55f), fontSize = 12.sp)
                    }
                    PbIcon(if (colorsOpen) PbIconName.CaretDown else PbIconName.CaretRight, size = 16.dp, tint = c.ink.copy(alpha = 0.5f), strokeWidth = 2.4f)
                }
                if (colorsOpen) {
                    ThemePickerRow(c, themeChoice, Modifier.padding(start = 18.dp, end = 18.dp, bottom = 16.dp), onPick = onTheme)
                }
            }

            // Layout: the book's own styles or the custom ones
            Group(c, "Layout") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(c, "Book's own", selected = !look.custom) { onLook(look.copy(custom = false)) }
                    Pill(c, "Custom", selected = look.custom) { onLook(look.copy(custom = true)) }
                    Pill(c, "Readest") { onLook(ReaderLook.readest(look.brightness)) }
                }
            }

            // Font grid, four to a page
            Group(c, "Select Font") {
                val fonts = fontChoices(imported)
                val pages = fonts.chunked(4)
                val pagerState = rememberPagerState(pageCount = { pages.size })
                HorizontalPager(state = pagerState, pageSpacing = 10.dp) { page ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pages[page].forEach { f ->
                            val on = look.custom && f.selected(look)
                            val family = remember(f.name, f.family) {
                                runCatching {
                                    when {
                                        f.name.isNotEmpty() -> {
                                            val file = ReaderFonts.file(context, f.name)
                                            FontFamily(if (file != null) Typeface.createFromFile(file) else Typeface.create(f.name, Typeface.NORMAL))
                                        }
                                        f.family == 1 -> FontFamily.SansSerif
                                        f.family == 2 -> FontFamily.Monospace
                                        else -> FontFamily.Serif
                                    }
                                }.getOrDefault(FontFamily.Default)
                            }
                            Column(
                                Modifier
                                    .weight(1f)
                                    .height(76.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(c.chip)
                                    .border(if (on) 1.5.dp else 0.dp, if (on) accent else Color.Transparent, RoundedCornerShape(20.dp))
                                    .clickable { onLook(look.copy(custom = true, fontFamily = f.family, fontName = f.name)) },
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                            ) {
                                Text("Aa", color = c.ink, fontFamily = family, fontSize = 22.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(f.label, color = c.ink.copy(alpha = 0.55f), fontSize = 11.sp, maxLines = 1, fontFamily = family)
                            }
                        }
                        // keep the tiles the same width on a page that is not full
                        repeat(4 - pages[page].size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    repeat(pages.size) { i ->
                        Box(
                            Modifier
                                .padding(horizontal = 3.dp)
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (pagerState.currentPage == i) c.ink else c.ink.copy(alpha = 0.2f)),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(c, "+ Import font") { picker.launch(arrayOf("*/*")) }
                    if (look.fontName in imported) {
                        Pill(c, "Remove ${look.fontName}") {
                            ReaderFonts.delete(context, look.fontName)
                            imported = ReaderFonts.list(context)
                            onLook(look.copy(fontName = ""))
                        }
                    }
                }
                importMessage?.let { Text(it, color = c.ink.copy(alpha = 0.6f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, start = 4.dp)) }
            }

            // Typography
            Group(c, "Typography") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(c.chip).padding(vertical = 4.dp)) {
                    StepRow(
                        c, PbIconName.TextSize, "Font Size", "$shownSize",
                        onMinus = { onFontSize(((fontSize * 16 - 1).coerceAtLeast(FONT_MIN * 16.0)) / 16.0) },
                        onPlus = { onFontSize(((fontSize * 16 + 1).coerceAtMost(FONT_MAX * 16.0)) / 16.0) },
                    )
                    Box(Modifier.fillMaxWidth().padding(start = 14.dp).height(1.dp).background(c.ink.copy(alpha = 0.08f)))
                    StepRow(
                        c, PbIconName.Edit, "Font Weight", "$shownWeight",
                        onMinus = { edit { it.copy(fontWeight = (it.fontWeight - 0.25f).coerceAtLeast(0.5f)) } },
                        onPlus = { edit { it.copy(fontWeight = (it.fontWeight + 0.25f).coerceAtMost(2.0f)) } },
                    )
                    Box(Modifier.fillMaxWidth().padding(start = 14.dp).height(1.dp).background(c.ink.copy(alpha = 0.08f)))
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("fi", color = c.ink.copy(alpha = 0.7f), fontFamily = PbSerif, fontSize = 17.sp, modifier = Modifier.width(18.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Ligatures", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("Smooth, connected characters (if supported by the font)", color = c.ink.copy(alpha = 0.55f), fontSize = 12.sp)
                        }
                        Switch(
                            checked = look.ligatures,
                            onCheckedChange = { on -> edit { it.copy(ligatures = on) } },
                            colors = SwitchDefaults.colors(checkedTrackColor = accent, checkedThumbColor = Color.White),
                        )
                    }
                }
            }

            // Text alignment
            Group(c, "Text Alignment") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(false to "Default", true to "Justify").forEach { (justify, title) ->
                        val on = look.custom && look.justify == justify
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(c.chip)
                                .border(if (on) 1.5.dp else 0.dp, if (on) accent else Color.Transparent, RoundedCornerShape(20.dp))
                                .clickable { edit { it.copy(justify = justify) } }
                                .padding(14.dp),
                        ) {
                            Text(title, color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (justify) "Text spreads evenly across the width." else "Text lines up on the left edge.",
                                color = c.ink.copy(alpha = 0.55f),
                                fontSize = 12.sp,
                            )
                        }
                    }
                }
            }

            // Everything else (spacing, margins, header and footer, behaviour, selection, display)
            Group(c, "More") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(c.chip)) {
                    Row(
                        Modifier.fillMaxWidth().clickable { moreOpen = !moreOpen }.padding(horizontal = 18.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("All reader settings", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("Spacing, margins, header and footer, behavior", color = c.ink.copy(alpha = 0.55f), fontSize = 12.sp)
                        }
                        PbIcon(if (moreOpen) PbIconName.CaretDown else PbIconName.CaretRight, size = 16.dp, tint = c.ink.copy(alpha = 0.5f), strokeWidth = 2.4f)
                    }
                    if (moreOpen) {
                        ReaderLookControls(
                            look = look,
                            onChange = onLook,
                            c = c,
                            showBrightness = true,
                            modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                            initiallyOpen = "",
                        )
                    }
                }
            }
        }

        // floating Back pill
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                .padding(bottom = 20.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(c.card)
                .border(1.dp, c.ink.copy(alpha = 0.12f), RoundedCornerShape(24.dp))
                .clickable(onClick = onClose)
                .padding(horizontal = 18.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PbIcon(PbIconName.CaretLeft, size = 16.dp, tint = c.ink, strokeWidth = 2.4f)
            Spacer(Modifier.width(6.dp))
            Text("Back", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}
