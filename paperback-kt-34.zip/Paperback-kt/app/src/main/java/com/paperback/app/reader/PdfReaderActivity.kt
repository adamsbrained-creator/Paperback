package com.paperback.app.reader

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.paperback.app.PaperbackApp
import com.paperback.app.data.Bookmark
import com.paperback.app.data.PdfDoc
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PaperbackTheme
import kotlinx.coroutines.launch
import java.io.File

/** Reads a PDF: Paperback draws the pages itself (see [PdfDoc]) and keeps the same progress, time and bookmarks as for EPUB. */
class PdfReaderActivity : ComponentActivity() {

    private val graph get() = (application as PaperbackApp).graph

    private var session: PdfSession? = null
    private var doc: PdfDoc? = null
    private val tracker = ReadingTracker()

    private val chromeVisible = mutableStateOf(false)
    private val themeState = mutableIntStateOf(0)
    private val rtlState = mutableStateOf(false)
    private val brightnessState = mutableFloatStateOf(-1f)
    private val bookmarks = mutableStateOf<List<Bookmark>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val s = graph.pdfSession
        val d = s?.let { PdfDoc.open(File(it.book.filePath)) }
        if (s == null || d == null) {
            // Nothing prepared (the app was restarted) or the file can't be read.
            if (s != null) Toast.makeText(this, "Couldn't open ${s.book.title}. It may be damaged or password-protected.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        session = s
        doc = d
        themeState.intValue = graph.settings.theme
        rtlState.value = graph.settings.pdfRtl
        brightnessState.floatValue = graph.settings.look.brightness
        enableEdgeToEdge()

        lifecycleScope.launch { bookmarks.value = graph.repo.bookmarks(s.book.id) }
        val pace = Stats.paceSecondsPerPosition(graph.repo.sessions.value)

        setContent {
            PaperbackTheme {
                PdfReaderRoot(
                    doc = d,
                    title = s.book.title,
                    startPage = s.startPage,
                    themeIndex = themeState.intValue,
                    rtl = rtlState.value,
                    brightness = brightnessState.floatValue,
                    chromeVisible = chromeVisible.value,
                    bookmarks = bookmarks.value,
                    secondsPerPage = pace,
                    onPage = { page -> onPage(s, d, page) },
                    onToggleChrome = { chromeVisible.value = !chromeVisible.value },
                    onHideChrome = { chromeVisible.value = false },
                    onBack = { finish() },
                    onToggleBookmark = { page -> toggleBookmark(s, d, page) },
                    onDeleteBookmark = { b -> deleteBookmark(s, b) },
                    onTheme = { index ->
                        themeState.intValue = index
                        graph.settings.theme = index
                    },
                    onRtl = { value ->
                        rtlState.value = value
                        graph.settings.pdfRtl = value
                    },
                    onBrightness = { value ->
                        brightnessState.floatValue = value
                        graph.settings.look = graph.settings.look.copy(brightness = value)
                        applyBrightness(value)
                    },
                )
            }
        }
        hideSystemBars()
        applyBrightness(brightnessState.floatValue)
    }

    private fun onPage(s: PdfSession, d: PdfDoc, page: Int) {
        tracker.onPosition(System.currentTimeMillis(), page)
        graph.appScope.launch { graph.repo.savePdfProgress(s.book.id, page, d.pageCount) }
    }

    private fun toggleBookmark(s: PdfSession, d: PdfDoc, page: Int) {
        lifecycleScope.launch {
            val existing = bookmarks.value.firstOrNull { it.position == page }
            if (existing != null) graph.repo.removeBookmark(existing.id) else graph.repo.addPdfBookmark(s.book.id, page, d.pageCount)
            bookmarks.value = graph.repo.bookmarks(s.book.id)
        }
    }

    private fun deleteBookmark(s: PdfSession, b: Bookmark) {
        lifecycleScope.launch {
            graph.repo.removeBookmark(b.id)
            bookmarks.value = graph.repo.bookmarks(s.book.id)
        }
    }

    /** A value from 0.05 to 1 dims or brightens this screen only; below zero follows the phone again. */
    private fun applyBrightness(value: Float) {
        val attrs = window.attributes
        attrs.screenBrightness = if (value < 0f) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else value.coerceIn(0.05f, 1f)
        window.attributes = attrs
    }

    // The phone's bars stay hidden for the whole session (swipe from the edge to peek), like the EPUB reader.
    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && session != null) hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        tracker.resume(System.currentTimeMillis())
    }

    override fun onPause() {
        super.onPause()
        val s = session ?: return
        tracker.pause(System.currentTimeMillis())?.let { flush ->
            graph.appScope.launch { graph.repo.addSession(s.book.id, flush.startMs, flush.seconds, flush.pages, flush.fromPos, flush.toPos) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        doc?.close()
        doc = null
        if (isFinishing && session != null) graph.closePdf()
    }
}
