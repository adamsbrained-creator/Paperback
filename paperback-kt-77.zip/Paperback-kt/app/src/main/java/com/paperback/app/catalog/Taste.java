package com.paperback.app.catalog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * What your library says about your taste, worked out on the phone: how much you like each subject and each
 * author, from what you finished, rated, favorited and started. Nothing here leaves the device; only a few
 * subject and author names are later used as search words.
 */
public final class Taste {
    /** One subject or author with how much you like it, and the book that shows it best. */
    public static final class Signal {
        public final String name;
        public final double weight;
        /** Title of the book of yours that counts most for it. */
        public final String because;
        /** The strongest single book weight behind it. */
        public final double bestBook;
        /** How many of your books show it. */
        public final int count;

        Signal(String name, double weight, String because, double bestBook, int count) {
            this.name = name;
            this.weight = weight;
            this.because = because;
            this.bestBook = bestBook;
            this.count = count;
        }

        /** Weight with a bonus for being a pattern across several books, used to choose what to search for. */
        double strength() {
            return weight * (1.0 + 0.4 * (count - 1));
        }
    }

    private final Map<String, Signal> subjects;
    private final Map<String, Signal> authors;
    private final List<Signal> topSubjects;
    private final List<Signal> topAuthors;
    private final Map<String, Boolean> owned;
    private final int dismissedCount;
    // the era and the length of the books you like (-1 / 0 = too few books to say)
    private double eraMean = -1.0;
    private double eraSd = 0.0;
    private double lenMean = -1.0;
    private double lenSd = 0.0;

    private Taste(Map<String, Signal> subjects, Map<String, Signal> authors, Map<String, Boolean> owned, int dismissedCount) {
        this.subjects = subjects;
        this.authors = authors;
        this.owned = owned;
        this.dismissedCount = dismissedCount;
        this.topSubjects = sorted(subjects, 2.0);
        this.topAuthors = sorted(authors, 2.0);
    }

    private static List<Signal> sorted(Map<String, Signal> m, double min) {
        List<Signal> out = new ArrayList<Signal>();
        for (Signal s : m.values()) if (s.weight >= min) out.add(s);
        Collections.sort(out, new Comparator<Signal>() {
            @Override public int compare(Signal a, Signal b) {
                int c = Double.compare(b.strength(), a.strength());
                return c != 0 ? c : a.name.compareToIgnoreCase(b.name);
            }
        });
        return out;
    }

    /** What a rating is worth as a signal, from -2.5 (1 star) to 3 (5 stars), between the whole stars in a line. */
    public static double ratingValue(double r) {
        double x = Math.max(1.0, Math.min(5.0, r));
        if (x < 2.0) return -2.5 + (x - 1.0) * 1.0;
        if (x < 3.0) return -1.5 + (x - 2.0) * 1.9;
        if (x < 4.0) return 0.4 + (x - 3.0) * 1.6;
        return 2.0 + (x - 4.0) * 1.0;
    }

    /**
     * How far your own ratings sit from the usual (a mean of 3.8): someone who gives nearly everything 5 stars
     * means less by a 4 than someone who is stingy. Added to a rating before it is read. Zero until there are
     * enough ratings to know, and never more than a star.
     */
    public static double ratingShift(double mean, int count) {
        if (count < 5) return 0.0;
        double shift = (3.8 - mean) * Math.min(1.0, count / 10.0);
        return Math.max(-1.0, Math.min(1.0, shift));
    }

    private static double ratingShift(List<TasteBook> books) {
        double sum = 0.0;
        int n = 0;
        for (TasteBook b : books) {
            if (b.rating > 0 && !b.dismissed) {
                sum += b.rating;
                n++;
            }
        }
        return n == 0 ? 0.0 : ratingShift(sum / n, n);
    }

    /**
     * How much one book says you like what it is about. Negative when you rated it low, dropped it or said you
     * are not interested; older books count a little less than what you read lately. [shift] moves your ratings
     * to where most people's sit, and a book you never rated is judged by how fast you read it.
     */
    static double bookWeight(TasteBook b, double shift) {
        if (b.dismissed) return -0.9; // two "not interested" on one author are enough to hide the author
        double w = 0.3; // you added it: a little interest
        if (b.wanted) w += 1.2; // you saved it to read
        if (b.rating > 0) w += ratingValue(b.rating + shift);
        if (b.favorite) w += 2.0;
        if (b.finished) {
            w += b.rating == 0 ? 1.5 : 0.5;
            // no rating: a book you tore through says more than one you dragged through
            if (b.rating == 0 && b.pace >= 1.5) w += 0.8;
            else if (b.rating == 0 && b.pace > 0 && b.pace <= 0.5) w -= 0.4;
        } else if (b.dropped) w -= 2.2 - 1.2 * Math.min(1.0, b.progress * 2.0); // the earlier you left, the worse
        else if (b.progress > 0.1) w += 0.8 * Math.min(1.0, b.progress);
        if (w > 0 && !b.favorite && b.ageDays > 0) w *= 0.55 + 0.45 * Math.exp(-b.ageDays / 540.0);
        return w;
    }

    /** How well a first-publication year fits the era of the books you like, 0 to 1; -1 when it cannot be said. */
    public double eraFit(int year) {
        if (eraMean < 0 || year <= 0) return -1.0;
        double z = (year - eraMean) / eraSd;
        return Math.exp(-0.5 * z * z);
    }

    /** How well a page count fits the length of the books you like, 0 to 1; -1 when it cannot be said. */
    public double lengthFit(int pages) {
        if (lenMean < 0 || pages < 40) return -1.0;
        double z = (Math.log(pages) - lenMean) / lenSd;
        return Math.exp(-0.5 * z * z);
    }

    public static Taste of(List<TasteBook> books) {
        Map<String, double[]> sSum = new LinkedHashMap<String, double[]>(); // [weight, bestBook, count]
        Map<String, String> sName = new HashMap<String, String>();
        Map<String, String> sBecause = new HashMap<String, String>();
        Map<String, double[]> aSum = new LinkedHashMap<String, double[]>();
        Map<String, String> aName = new HashMap<String, String>();
        Map<String, String> aBecause = new HashMap<String, String>();
        Map<String, Boolean> owned = new HashMap<String, Boolean>();
        int dismissedCount = 0;
        double shift = ratingShift(books);
        // weighted sums for the era and the length of what you like: [weight, weight*x, weight*x*x, count]
        double[] era = new double[4];
        double[] len = new double[4];

        for (TasteBook b : books) {
            owned.put(TitleKey.of(b.title), Boolean.TRUE);
            if (b.dismissed) dismissedCount++;
            double w = bookWeight(b, shift);
            if (w >= 1.0 && !b.dismissed) {
                if (b.year > 0) accumulate(era, w, b.year);
                if (b.pages >= 40) accumulate(len, w, Math.log(b.pages));
            }
            List<String> tags = Subjects.clean(b.tags, 16);
            double share = w / Math.max(1.0, Math.sqrt(tags.size())); // a book with many tags does not outweigh one with few
            for (String t : tags) {
                String k = Subjects.key(t);
                double f = Subjects.isGeneric(t) ? 0.35 : 1.0;
                add(sSum, sName, sBecause, k, t, share * f, w, b.title);
            }
            String a = firstAuthor(b.author);
            if (!a.isEmpty()) add(aSum, aName, aBecause, a.toLowerCase(Locale.ROOT), a, w, w, b.title);
        }
        Taste t = new Taste(build(sSum, sName, sBecause), build(aSum, aName, aBecause), owned, dismissedCount);
        if (era[3] >= 4) {
            double mean = era[1] / era[0];
            double sd = Math.sqrt(Math.max(0.0, era[2] / era[0] - mean * mean));
            t.eraMean = mean;
            t.eraSd = Math.max(20.0, sd * 1.2); // never narrower than a generation
        }
        if (len[3] >= 4) {
            double mean = len[1] / len[0];
            double sd = Math.sqrt(Math.max(0.0, len[2] / len[0] - mean * mean));
            t.lenMean = mean;
            t.lenSd = Math.max(0.35, sd * 1.2);
        }
        return t;
    }

    private static void accumulate(double[] sums, double w, double x) {
        sums[0] += w;
        sums[1] += w * x;
        sums[2] += w * x * x;
        sums[3] += 1;
    }

    private static void add(Map<String, double[]> sum, Map<String, String> names, Map<String, String> because,
                            String key, String name, double add, double bookW, String title) {
        double[] cur = sum.get(key);
        if (cur == null) {
            sum.put(key, new double[] {add, bookW, 1});
            names.put(key, name);
            because.put(key, title);
        } else {
            cur[0] += add;
            cur[2] += 1;
            if (bookW > cur[1]) {
                cur[1] = bookW;
                because.put(key, title);
            }
        }
    }

    private static Map<String, Signal> build(Map<String, double[]> sum, Map<String, String> names, Map<String, String> because) {
        Map<String, Signal> out = new LinkedHashMap<String, Signal>();
        for (Map.Entry<String, double[]> e : sum.entrySet()) {
            out.put(e.getKey(), new Signal(names.get(e.getKey()), e.getValue()[0], because.get(e.getKey()), e.getValue()[1], (int) e.getValue()[2]));
        }
        return out;
    }

    /** "Tolkien, J. R. R." / "A and B" -> the first author as written. */
    static String firstAuthor(String author) {
        if (author == null) return "";
        String a = author.trim();
        int i = a.indexOf(';');
        if (i > 0) a = a.substring(0, i);
        i = a.indexOf(" & ");
        if (i > 0) a = a.substring(0, i);
        i = a.indexOf(" and ");
        if (i > 0) a = a.substring(0, i);
        return a.trim();
    }

    // ---- reading the result ---------------------------------------------------------------------

    /** True when there is nothing to base a recommendation on. */
    public boolean isEmpty() {
        return subjects.isEmpty() && authors.isEmpty();
    }

    public double subjectWeight(String subject) {
        Signal s = subjects.get(Subjects.key(subject));
        return s == null ? 0.0 : s.weight;
    }

    public Signal subject(String subject) {
        return subjects.get(Subjects.key(subject));
    }

    public Signal author(String author) {
        return authors.get(firstAuthor(author).toLowerCase(Locale.ROOT));
    }

    public boolean owns(String title) {
        return owned.containsKey(TitleKey.of(title));
    }

    /** Subjects you like most, best first (specific ones before broad ones like "Fiction"). */
    public List<Signal> likedSubjects(int n) {
        List<Signal> specific = new ArrayList<Signal>();
        List<Signal> broad = new ArrayList<Signal>();
        for (Signal s : topSubjects) (Subjects.isGeneric(s.name) ? broad : specific).add(s);
        specific.addAll(broad);
        return specific.subList(0, Math.min(n, specific.size()));
    }

    public List<Signal> likedAuthors(int n) {
        return topAuthors.subList(0, Math.min(n, topAuthors.size()));
    }

    /** Authors you rated low or abandoned, so their books are not suggested. */
    public boolean dislikesAuthor(String author) {
        Signal s = author(author);
        return s != null && s.weight < -1.0;
    }

    /**
     * What the recommendation was based on, as one line: it changes only when your taste does, so the
     * suggestions are not fetched again every time you open the page.
     */
    public String signature() {
        StringBuilder sb = new StringBuilder();
        for (Signal s : likedSubjects(6)) sb.append(Subjects.key(s.name)).append('|');
        sb.append('#');
        for (Signal s : likedAuthors(3)) sb.append(s.name.toLowerCase(Locale.ROOT)).append('|');
        sb.append('!').append(dismissedCount);
        return sb.toString();
    }
}
