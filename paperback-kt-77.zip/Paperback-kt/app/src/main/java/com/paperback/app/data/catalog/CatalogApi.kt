package com.paperback.app.data.catalog

import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.Describe
import com.paperback.app.catalog.Subjects
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.opds.MiniJson
import com.paperback.app.data.opds.OpdsHttp
import com.paperback.app.data.opds.OpdsText
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.security.MessageDigest

/** What the book's own page shows beyond the list entry. Anything can be missing. */
class CatalogDetails(
    val description: String,
    val subjects: List<String>,
    val rating: Double,
    val ratingCount: Int,
    val wantToRead: Int,
    val alreadyRead: Int,
    val pages: Int,
    /** "Open Library" or "Google Books": where the description / rating came from, for the credit line. */
    val credit: String,
)

/**
 * The online catalog: Open Library (free, no account), with Google Books as a backup for descriptions and
 * ratings that Open Library doesn't have. Only book facts are read; no books are downloaded. Every answer is
 * kept on the phone for a while (so the page opens at once, and still works offline), and an old answer is
 * used if the network is down.
 */
class CatalogApi(private val http: OpdsHttp, cacheDir: File) {
    private val dir = File(cacheDir, "catalog").apply { mkdirs() }

    init {
        // forget answers older than two weeks
        val cutoff = System.currentTimeMillis() - 14 * DAY
        dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }

    // ---- lists ----------------------------------------------------------------------------------

    fun trending(): List<CatalogBook> =
        works(get("$OL/trending/weekly.json?limit=24", 6 * HOUR), "works")

    /** Popular books of a subject, from Open Library's subject pages ("science_fiction", "love"...). */
    fun subject(slug: String, limit: Int = 30): List<CatalogBook> =
        works(get("$OL/subjects/${enc(slug)}.json?limit=$limit", 24 * HOUR), "works")

    fun search(query: String, limit: Int = 24): List<CatalogBook> =
        works(get("$OL/search.json?q=${enc(query)}&limit=$limit&fields=$FIELDS", 12 * HOUR), "docs")

    fun bySubject(subject: String, limit: Int = 20): List<CatalogBook> =
        search("subject:\"${subject.replace('"', ' ')}\"", limit)

    fun byAuthor(author: String, limit: Int = 20): List<CatalogBook> =
        search("author:\"${author.replace('"', ' ')}\"", limit)

    // ---- one book -------------------------------------------------------------------------------

    /** Only the description of a book (one request, kept for a week), to compare what books are about. */
    fun blurb(book: CatalogBook): String {
        val w = get("$OL/works/${book.id}.json", 7 * DAY) as? Map<*, *> ?: return ""
        val d = w["description"]
        return Describe.clean(
            when (d) {
                is String -> d
                is Map<*, *> -> d["value"] as? String ?: ""
                else -> ""
            },
        )
    }

    fun details(book: CatalogBook): CatalogDetails {
        var description = ""
        var subjects: List<String> = emptyList()
        var pages = 0
        runCatching {
            val w = get("$OL/works/${book.id}.json", 7 * DAY) as? Map<*, *>
            if (w != null) {
                val d = w["description"]
                description = Describe.clean(
                    when (d) {
                        is String -> d
                        is Map<*, *> -> d["value"] as? String ?: ""
                        else -> ""
                    },
                )
                subjects = strings(w["subjects"])
            }
        }
        var rating = book.rating
        var ratingCount = book.ratingCount
        if (rating <= 0.0) {
            runCatching {
                val r = get("$OL/works/${book.id}/ratings.json", 24 * HOUR) as? Map<*, *>
                val sum = r?.get("summary") as? Map<*, *>
                rating = num(sum?.get("average"))
                ratingCount = num(sum?.get("count")).toInt()
            }
        }
        var want = 0
        var read = 0
        runCatching {
            val b = get("$OL/works/${book.id}/bookshelves.json", 24 * HOUR) as? Map<*, *>
            val c = b?.get("counts") as? Map<*, *>
            want = num(c?.get("want_to_read")).toInt()
            read = num(c?.get("already_read")).toInt()
        }
        var credit = "Open Library"
        if (description.isBlank() || rating <= 0.0) {
            runCatching {
                val g = googleBooks(book)
                if (g != null) {
                    if (description.isBlank() && g.description.isNotBlank()) {
                        description = g.description
                        credit = "Google Books"
                    }
                    if (rating <= 0.0 && g.rating > 0.0) {
                        rating = g.rating
                        ratingCount = g.ratingCount
                    }
                    pages = g.pages
                }
            }
        }
        return CatalogDetails(description, subjects, rating, ratingCount, want, read, pages, credit)
    }

    private class Google(val description: String, val rating: Double, val ratingCount: Int, val pages: Int)

    private fun googleBooks(book: CatalogBook): Google? {
        val q = buildString {
            append("intitle:\"").append(book.title.replace('"', ' ')).append('"')
            if (book.firstAuthor().isNotBlank()) append("+inauthor:\"").append(book.firstAuthor().replace('"', ' ')).append('"')
        }
        val url = "https://www.googleapis.com/books/v1/volumes?q=${enc(q).replace("%2B", "+")}&maxResults=5&printType=books" +
            "&fields=items(volumeInfo(title,description,averageRating,ratingsCount,pageCount))"
        val root = get(url, 7 * DAY) as? Map<*, *> ?: return null
        val items = root["items"] as? List<*> ?: return null
        for (item in items) {
            val v = (item as? Map<*, *>)?.get("volumeInfo") as? Map<*, *> ?: continue
            if (!TitleKey.same(v["title"] as? String ?: "", book.title)) continue
            return Google(
                description = Describe.clean(OpdsText.plain(v["description"] as? String)),
                rating = num(v["averageRating"]),
                ratingCount = num(v["ratingsCount"]).toInt(),
                pages = num(v["pageCount"]).toInt(),
            )
        }
        return null
    }

    // ---- reading answers ------------------------------------------------------------------------

    private fun works(root: Any?, key: String): List<CatalogBook> {
        val list = (root as? Map<*, *>)?.get(key) as? List<*> ?: return emptyList()
        return list.mapNotNull { (it as? Map<*, *>)?.let(::parseWork) }
    }

    private fun parseWork(m: Map<*, *>): CatalogBook? {
        val id = (m["key"] as? String)?.substringAfterLast('/') ?: return null
        if (!id.startsWith("OL") || !id.endsWith("W")) return null
        val title = (m["title"] as? String)?.trim().orEmpty()
        if (title.isEmpty()) return null
        val authors = strings(m["author_name"]).ifEmpty {
            (m["authors"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.get("name") as? String }.orEmpty()
        }
        val cover = num(m["cover_i"]).toInt().takeIf { it > 0 } ?: num(m["cover_id"]).toInt()
        return CatalogBook(
            id,
            title,
            authors.take(3).joinToString(", "),
            num(m["first_publish_year"]).toInt(),
            cover,
            num(m["ratings_average"]),
            num(m["ratings_count"]).toInt(),
            num(m["edition_count"]).toInt(),
            (num(m["already_read_count"]) + num(m["want_to_read_count"])).toInt(),
            Subjects.clean(strings(m["subject"]).ifEmpty { strings(m["subjects"]) }, 24),
        )
    }

    private fun strings(v: Any?): List<String> = (v as? List<*>)?.mapNotNull { it as? String }.orEmpty()

    private fun num(v: Any?): Double = (v as? Number)?.toDouble() ?: 0.0

    // ---- the web, with a memory ------------------------------------------------------------------

    /** The parsed JSON of [url]. A saved answer younger than [ttl] is used without asking; an older one only when the network fails. */
    private fun get(url: String, ttl: Long): Any? {
        val file = File(dir, sha1(url))
        val now = System.currentTimeMillis()
        if (file.exists() && now - file.lastModified() < ttl) {
            val cached = runCatching { MiniJson.parse(file.readText()) }.getOrNull()
            if (cached != null) return cached
        }
        try {
            val text = http.getJson(url).text
            val parsed = MiniJson.parse(text) ?: throw IOException("The catalog sent something unreadable.")
            runCatching { file.writeText(text) }
            return parsed
        } catch (e: IOException) {
            if (file.exists()) {
                val old = runCatching { MiniJson.parse(file.readText()) }.getOrNull()
                if (old != null) return old
            }
            throw e
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    companion object {
        private const val OL = "https://openlibrary.org"
        private const val HOUR = 3_600_000L
        private const val DAY = 24 * HOUR
        private const val FIELDS =
            "key,title,author_name,first_publish_year,cover_i,ratings_average,ratings_count,edition_count,subject,want_to_read_count,already_read_count"

        /** Open Library cover pictures: [size] is "S", "M" or "L". Returns null for books with no cover. */
        fun coverUrl(book: CatalogBook, size: String = "M"): String? =
            if (book.coverId > 0) "https://covers.openlibrary.org/b/id/${book.coverId}-$size.jpg?default=false" else null

        fun pageUrl(book: CatalogBook): String = "$OL/works/${book.id}"
    }
}
