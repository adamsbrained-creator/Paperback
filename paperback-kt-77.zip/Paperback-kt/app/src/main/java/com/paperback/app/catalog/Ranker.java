package com.paperback.app.catalog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Puts catalog books in the order you are likely to want them, and says why. */
public final class Ranker {
    private Ranker() {}

    public static final int KIND_GENERAL = 0;
    /** Suggested because of one book of yours that you liked ([Pick.anchor] is its title). */
    public static final int KIND_BOOK = 1;
    /** Suggested because you like the author ([Pick.anchor] is the name). */
    public static final int KIND_AUTHOR = 2;
    /** Suggested because you read a lot of a subject ([Pick.anchor] is the subject). */
    public static final int KIND_SUBJECT = 3;
    /** The next books of a series you are in ([Pick.anchor] is the series). */
    public static final int KIND_SERIES = 4;

    public static final class Pick {
        public final CatalogBook book;
        public final String reason;
        public final double score;
        public final int kind;
        public final String anchor;

        public Pick(CatalogBook book, String reason, double score, int kind, String anchor) {
            this.book = book;
            this.reason = reason;
            this.score = score;
            this.kind = kind;
            this.anchor = anchor == null ? "" : anchor;
        }
    }

    /** Picks with the same reason, shown as a row of their own ("Because you liked ..."). */
    public static final class Group {
        public final String title;
        public final List<Pick> picks;
        final double strength;

        Group(String title, List<Pick> picks, double strength) {
            this.title = title;
            this.picks = picks;
            this.strength = strength;
        }
    }

    /**
     * The picks that share a reason, as rows: the strongest first, series before the rest. A reason needs
     * [minSize] books to make a row (a series needs one), and at most [maxRows] rows are returned.
     */
    public static List<Group> group(List<Pick> picks, int minSize, int maxRows) {
        Map<String, List<Pick>> by = new LinkedHashMap<String, List<Pick>>();
        for (Pick p : picks) {
            if (p.kind == KIND_GENERAL || p.anchor.isEmpty()) continue;
            String key = p.kind + "|" + p.anchor.toLowerCase(Locale.ROOT);
            List<Pick> l = by.get(key);
            if (l == null) {
                l = new ArrayList<Pick>();
                by.put(key, l);
            }
            l.add(p);
        }
        List<Group> out = new ArrayList<Group>();
        for (List<Pick> l : by.values()) {
            Pick first = l.get(0);
            int need = first.kind == KIND_SERIES ? 1 : minSize;
            if (l.size() < need) continue;
            double strength = first.kind == KIND_SERIES ? 1000.0 : 0.0;
            for (int i = 0; i < l.size() && i < 3; i++) strength += l.get(i).score;
            out.add(new Group(titleOf(first), l, strength));
        }
        Collections.sort(out, new Comparator<Group>() {
            @Override public int compare(Group a, Group b) {
                return Double.compare(b.strength, a.strength);
            }
        });
        return out.size() > maxRows ? new ArrayList<Group>(out.subList(0, maxRows)) : out;
    }

    private static String titleOf(Pick p) {
        switch (p.kind) {
            case KIND_BOOK: return "Because you liked " + p.anchor;
            case KIND_AUTHOR: return "More by " + p.anchor;
            case KIND_SUBJECT: return "Since you read a lot of " + p.anchor;
            case KIND_SERIES: return "More in the " + p.anchor + " series";
            default: return "For you";
        }
    }

    public static List<Pick> rank(List<CatalogBook> candidates, Taste taste, int limit) {
        return rank(candidates, taste, limit, null);
    }

    /**
     * [kindWeights] is how much each kind of reason ([KIND_GENERAL] to [KIND_SERIES]) has pleased you so far,
     * around 1.0; a suggestion's score is scaled by its kind's weight. Null leaves the scores as they are.
     */
    public static List<Pick> rank(List<CatalogBook> candidates, Taste taste, int limit, double[] kindWeights) {
        List<Pick> scored = new ArrayList<Pick>();
        Set<String> seenTitles = new HashSet<String>();
        for (CatalogBook c : candidates) {
            if (c.title == null || c.title.trim().isEmpty()) continue;
            if (taste.owns(c.title)) continue;
            if (taste.dislikesAuthor(c.firstAuthor())) continue;
            if (!seenTitles.add(TitleKey.of(c.title))) continue;
            Pick p = score(c, taste);
            if (p != null && kindWeights != null && p.score > 0 && p.kind >= 0 && p.kind < kindWeights.length) {
                p = new Pick(p.book, p.reason, p.score * kindWeights[p.kind], p.kind, p.anchor);
            }
            if (p != null) scored.add(p);
        }
        Collections.sort(scored, new Comparator<Pick>() {
            @Override public int compare(Pick a, Pick b) {
                return Double.compare(b.score, a.score);
            }
        });
        // at most two books by the same author, so one favourite does not fill the row
        Map<String, Integer> perAuthor = new HashMap<String, Integer>();
        // and at most six for one reason, so one favourite book or subject does not fill the whole list
        Map<String, Integer> perReason = new HashMap<String, Integer>();
        List<Pick> out = new ArrayList<Pick>();
        for (Pick p : scored) {
            String a = p.book.firstAuthor().toLowerCase(Locale.ROOT);
            int n = perAuthor.containsKey(a) ? perAuthor.get(a) : 0;
            if (!a.isEmpty() && n >= 2) continue;
            String r = p.kind + "|" + p.anchor.toLowerCase(Locale.ROOT);
            int rn = perReason.containsKey(r) ? perReason.get(r) : 0;
            if (p.kind != KIND_GENERAL && rn >= 6) continue;
            perAuthor.put(a, n + 1);
            perReason.put(r, rn + 1);
            out.add(p);
            if (out.size() >= limit) break;
        }
        return out;
    }

    static Pick score(CatalogBook c, Taste taste) {
        double subj = 0.0;
        Taste.Signal bestSubject = null;
        double bestSubjectContribution = 0.0;
        List<Double> positives = new ArrayList<Double>();
        for (String s : Subjects.clean(c.subjects, 30)) {
            Taste.Signal sig = taste.subject(s);
            if (sig == null) continue;
            double w = sig.weight;
            if (w > 0) {
                positives.add(w);
                if (w > bestSubjectContribution && !Subjects.isGeneric(s)) {
                    bestSubjectContribution = w;
                    bestSubject = sig;
                }
            } else {
                subj += w; // subjects of books you did not like count against it
            }
        }
        Collections.sort(positives, Collections.reverseOrder());
        for (int i = 0; i < positives.size() && i < 4; i++) subj += positives.get(i) / (1.0 + 0.5 * i);

        double auth = 0.0;
        Taste.Signal authorSig = taste.author(c.firstAuthor());
        if (authorSig != null && authorSig.weight > 0) auth = 1.2 * Math.min(authorSig.weight, 6.0);

        if (subj <= 0.0 && auth <= 0.0) return null; // nothing ties it to what you read

        double pop = 0.25 * Math.log10(1 + c.ratingCount) + 0.2 * Math.log10(1 + c.editions) + 0.15 * Math.log10(1 + c.readers);
        double quality = c.ratingCount >= 5 ? (c.rating - 3.6) * 0.8 : 0.0;
        double cover = c.coverId > 0 ? 0.3 : -0.6;
        double total = subj + auth + pop + quality + cover;
        // a book from the era of the books you like gets a little more, one from far away a little less
        double era = taste.eraFit(c.year);
        if (era >= 0) total += 0.8 * (era - 0.5);

        String reason;
        int kind;
        String anchor;
        if (authorSig != null && auth >= bestSubjectContribution * 1.5 && auth > 0) {
            reason = "More by " + c.firstAuthor();
            kind = KIND_AUTHOR;
            anchor = c.firstAuthor();
        } else if (bestSubject != null) {
            if (bestSubject.bestBook >= 2.0 && !bestSubject.because.isEmpty()) {
                reason = "Because you liked " + bestSubject.because;
                kind = KIND_BOOK;
                anchor = bestSubject.because;
            } else {
                reason = "You read a lot of " + bestSubject.name;
                kind = KIND_SUBJECT;
                anchor = bestSubject.name;
            }
        } else if (authorSig != null) {
            reason = "More by " + c.firstAuthor();
            kind = KIND_AUTHOR;
            anchor = c.firstAuthor();
        } else {
            reason = "Popular with readers like you";
            kind = KIND_GENERAL;
            anchor = "";
        }
        return new Pick(c, reason, total, kind, anchor);
    }
}
