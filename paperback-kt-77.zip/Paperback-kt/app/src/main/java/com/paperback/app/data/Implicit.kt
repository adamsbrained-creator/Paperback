package com.paperback.app.data

/*
 * Signs of how much you liked a book that you never said yourself, worked out from what Paperback already
 * keeps: how fast you read it, and where and when it was published. Plain Kotlin, so it can be tested on its own.
 */
object Implicit {
    private const val DAY = 86_400_000L

    /**
     * How fast you read each finished book compared with your usual pace, by book id (1 = as usual, 2 = twice as
     * fast). Needs the day you started and finished it and its length; empty until there are four such books.
     */
    fun paceRatios(books: List<Book>): Map<String, Double> {
        val rates = HashMap<String, Double>()
        for (b in books) {
            if (!b.finished || b.startedAt <= 0L || b.finishedAt <= b.startedAt) continue
            val pages = b.pageCount
            if (pages < 40) continue
            val days = ((b.finishedAt - b.startedAt) / DAY + 1).toDouble()
            rates[b.id] = pages / days
        }
        if (rates.size < 4) return emptyMap()
        val sorted = rates.values.sorted()
        val median = sorted[sorted.size / 2]
        if (median <= 0.0) return emptyMap()
        return rates.mapValues { it.value / median }
    }

    private val yearPattern = Regex("""\b(1[0-9]{3}|20[0-9]{2})\b""")

    /** The year in a publication date like "1998-06-01" or "June 1998", 0 when there is none. */
    fun yearOf(published: String?): Int {
        if (published.isNullOrBlank()) return 0
        val y = yearPattern.find(published)?.value?.toIntOrNull() ?: return 0
        return if (y in 1000..2100) y else 0
    }
}
