package com.paperback.app.data

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.ceil
import kotlin.math.max

/*
 * Everything the Stats -> Milestones page shows, as plain functions (no Android, no UI, no clock: `nowMs` is passed
 * in). A port of the TypeScript app's milestonesStats.ts.
 *
 * Fifteen lifetime counters with five tiers each (round 4 added words read, listening hours, reviews written, reading
 * days and authors read), a "next up" pick, and a timeline of when things happened.
 * Every tier and every timeline entry carries a [MilestoneTarget], so the page can open what is behind it
 * (the book finished, the notes of a book, the day in History).
 *
 * Differences from the TypeScript app, because this app stores different things:
 *  - pages are the pages turned in the reading sessions (not distinct pages), like the Activity page;
 *  - notes and quotes come from the highlights table (a highlight with text of your own is a note);
 *  - there is no dictionary yet, so saved words are passed in as an (empty) list;
 *  - ratings are saved without a date, so Books Rated has no unlock dates.
 */

enum class MilestoneId {
    Books, Pages, Sessions, Hours, Words, Rated, Quotes, Streak, Epic, Notes, WordsRead, ListenHours, Reviews, Days, Authors,
    PerfectWeeks, Comebacks, Marathons, EarlyBird, NightOwl, Genres, Languages,
}

/** Icons of the milestones, plus the three that only timeline entries use (Trophy, Done, Plus). */
enum class MilestoneIcon { Book, Page, Clock, Timer, Mark, Star, Quote, Flame, Stack, Note, Trophy, Done, Plus, Headphones, Calendar, Person, Words }

enum class TimelineKind { Book, Read, Note }

/** What a tap on a tier or a timeline entry opens. */
sealed interface MilestoneTarget {
    /** A book's page. */
    data class OpenBook(val bookId: String) : MilestoneTarget

    /** The notes and highlights of one book. */
    data class OpenNotes(val bookId: String) : MilestoneTarget

    /** Stats -> History, on the month of [date] with that day's sessions in view. */
    data class OpenHistory(val date: LocalDate) : MilestoneTarget

    /** The dictionary (the page where saved words live). */
    data object OpenDictionary : MilestoneTarget
}

/** A word saved in the dictionary. The dictionary is not built yet, so the list is empty for now. */
class SavedWord(val word: String, val addedAt: Long)

class MilestoneInput(
    /** The sessions the stats use (see Repository.sessions). */
    val sessions: List<ReadingSession>,
    val books: List<Book>,
    val highlights: List<Highlight>,
    val savedWords: List<SavedWord> = emptyList(),
    val zone: ZoneId,
    val nowMs: Long,
)

class Milestone(
    val id: MilestoneId,
    val name: String,
    /** Shorter name for the small cards. */
    val short: String?,
    val icon: MilestoneIcon,
    val kind: TimelineKind,
    val value: Int,
    val tiers: List<Int>,
    val unit: String,
    /** For each tier: when it was unlocked (ms), or null when it is not unlocked or the date is unknown. */
    val dates: List<Long?>,
    /** For each tier: what opens when you tap it (only unlocked tiers that have something behind them). */
    val targets: List<MilestoneTarget?>,
    /** How many tiers are unlocked. */
    val unlocked: Int,
    /** The next tier's target, or null when every tier is unlocked. */
    val next: Int?,
    /** 0..100: progress from the last unlocked tier to the next one. */
    val pct: Float,
    /** Units gained in the last 90 days (for the "about N days" estimate), or null when it cannot be known. */
    val recent: Double?,
) {
    val label: String get() = short ?: name
}

class TextPart(val text: String, val bold: Boolean = false)

class TimelineEvent(
    val key: String,
    val kind: TimelineKind,
    val icon: MilestoneIcon,
    val title: String,
    val at: Long,
    val sub: List<TextPart>,
    val target: MilestoneTarget?,
)

class NextUp(
    val milestone: Milestone,
    /** 1-based number of the tier being worked on. */
    val tier: Int,
    val need: Int,
    val target: Int,
    /** Rough days until it is reached at the last 90 days' pace; null when there is no recent pace. */
    val days: Int?,
)

private const val DAY_MS = 86_400_000L
const val MILESTONE_RECENT_DAYS = 90

/** An epic book has at least this many pages. */
const val EPIC_PAGES = 500
val ADDED_TIERS = listOf(10, 25, 50, 100, 250)

/** A day counts toward a streak after this many seconds of reading (same as Stats). */
private const val STREAK_MIN_SECONDS = 60L

private val TIERS: Map<MilestoneId, List<Int>> = mapOf(
    MilestoneId.Books to listOf(10, 25, 50, 100, 250),
    MilestoneId.Pages to listOf(1000, 5000, 10000, 25000, 50000),
    MilestoneId.Sessions to listOf(25, 100, 500, 1000, 2500),
    MilestoneId.Hours to listOf(50, 100, 250, 500, 1000),
    MilestoneId.Words to listOf(10, 50, 100, 250, 500),
    MilestoneId.Rated to listOf(5, 10, 25, 50, 100),
    MilestoneId.Quotes to listOf(10, 50, 100, 250, 500),
    MilestoneId.Streak to listOf(7, 14, 30, 60, 100),
    MilestoneId.Epic to listOf(3, 5, 10, 25, 50),
    MilestoneId.Notes to listOf(1, 5, 10, 25, 50),
    MilestoneId.WordsRead to listOf(100_000, 500_000, 1_000_000, 2_500_000, 5_000_000),
    MilestoneId.ListenHours to listOf(5, 10, 25, 50, 100),
    MilestoneId.Reviews to listOf(1, 5, 10, 25, 50),
    MilestoneId.Days to listOf(30, 100, 200, 365, 500),
    MilestoneId.Authors to listOf(5, 10, 25, 50, 100),
    MilestoneId.PerfectWeeks to listOf(1, 4, 12, 26, 52),
    MilestoneId.Comebacks to listOf(1, 3, 5, 10, 25),
    MilestoneId.Marathons to listOf(1, 5, 10, 25, 50),
    MilestoneId.EarlyBird to listOf(5, 25, 50, 100, 200),
    MilestoneId.NightOwl to listOf(5, 25, 50, 100, 200),
    MilestoneId.Genres to listOf(3, 5, 8, 12, 15),
    MilestoneId.Languages to listOf(2, 3, 5, 8, 12),
)

// ---- small helpers --------------------------------------------------------------------------

fun commas(n: Int): String = "%,d".format(n)

/** 1,234 -> "1.2K", 6277 -> "6.3K", 25000 -> "25K", 950 -> "950". */
fun shortNum(n: Int): String {
    if (n < 1000) return n.toString()
    if (n >= 1_000_000) {
        val m = n / 1_000_000.0
        return if (m % 1.0 == 0.0 || m >= 10) "${Math.round(m)}M" else "%.1fM".format(m)
    }
    val x = n / 1000.0
    val whole = x % 1.0 == 0.0
    return if (x >= 10 || whole) "${Math.round(x)}K" else "%.1fK".format(x)
}

private fun ordinal(n: Int): String {
    val v = n % 100
    val suffix = if (v in 11..13) "th" else when (n % 10) {
        1 -> "st"
        2 -> "nd"
        3 -> "rd"
        else -> "th"
    }
    return "${commas(n)}$suffix"
}

private fun known(t: Long): Long? = if (t > 0) t else null

/** The day a finished book counts for: its saved finish date, else when it was last opened (or added). */
fun finishedAtMs(b: Book): Long = if (b.finishedAt > 0) b.finishedAt else max(b.lastOpenedAt, b.addedAt)

/** True for a finished book of at least [EPIC_PAGES] pages (in the page count that applies). */
fun isEpic(b: Book): Boolean = b.finished && b.pageCount >= EPIC_PAGES

/** True once you gave the book a rating. */
fun isRated(b: Book): Boolean = b.rating > 0 || b.rating10 > 0f

private fun dayStartMs(d: LocalDate, zone: ZoneId): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()

/** Dates of the tiers a sorted list of times has reached: tier t is the time of the t-th item. */
private fun datesFromTimes(times: List<Long>, tiers: List<Int>): List<Long?> =
    tiers.map { t -> if (times.size >= t) known(times[t - 1]) else null }

private fun historyTargets(dates: List<Long?>, zone: ZoneId): List<MilestoneTarget?> =
    dates.map { at -> at?.let { MilestoneTarget.OpenHistory(dateOf(it, zone)) } }

private fun build(
    id: MilestoneId,
    name: String,
    short: String?,
    icon: MilestoneIcon,
    kind: TimelineKind,
    unit: String,
    value: Int,
    dates: List<Long?>,
    targets: List<MilestoneTarget?>,
    recent: Double?,
): Milestone {
    val tiers = TIERS.getValue(id)
    val unlocked = tiers.count { value >= it }
    val next = tiers.getOrNull(unlocked)
    val prev = if (unlocked > 0) tiers[unlocked - 1] else 0
    val pct = if (next != null) (((value - prev).toFloat() / (next - prev)) * 100f).coerceIn(0f, 100f) else 100f
    return Milestone(
        id = id, name = name, short = short, icon = icon, kind = kind, value = value, tiers = tiers, unit = unit,
        dates = tiers.indices.map { i -> if (i < unlocked) dates.getOrNull(i) else null },
        targets = tiers.indices.map { i -> if (i < unlocked) targets.getOrNull(i) else null },
        unlocked = unlocked, next = next, pct = pct, recent = recent,
    )
}

/** The day each streak length was first reached (a key of 7 holds the day a 7-day streak first happened). */
private fun streakReach(byDay: Map<LocalDate, Long>, lengths: List<Int>, zone: ZoneId): Map<Int, Long> {
    val days = byDay.filterValues { it >= STREAK_MIN_SECONDS }.keys.sorted()
    val reach = HashMap<Int, Long>()
    var run = 0
    var prev: LocalDate? = null
    for (d in days) {
        run = if (prev != null && prev.plusDays(1) == d) run + 1 else 1
        for (t in lengths) {
            if (run >= t && !reach.containsKey(t)) reach[t] = dayStartMs(d, zone)
        }
        prev = d
    }
    return reach
}

/** Each author once, with the finished book that first made them one of your authors and when, oldest first. */
private fun authorFirsts(books: List<Book>): List<Pair<Book, Long>> {
    val seen = HashSet<String>()
    val out = ArrayList<Pair<Book, Long>>()
    for (b in books.filter { it.finished }.map { it to finishedAtMs(it) }.sortedBy { it.second }) {
        val key = b.first.author.trim().lowercase()
        if (key.isEmpty() || !seen.add(key)) continue
        out.add(b)
    }
    return out
}

// ---- the milestones -------------------------------------------------------------------------

fun buildMilestones(input: MilestoneInput): List<Milestone> {
    val zone = input.zone
    val cutoff = input.nowMs - MILESTONE_RECENT_DAYS * DAY_MS
    fun since(times: List<Long>): Int = times.count { it >= cutoff }

    val books = input.books
    val byId = books.associateBy { it.id }
    val finished = books.filter { it.finished }.map { it to finishedAtMs(it) }.sortedBy { it.second }
    val finishTimes = finished.map { it.second }
    val finishTargets: List<MilestoneTarget?> = finished.map { MilestoneTarget.OpenBook(it.first.id) }

    // pages, hours, sessions, streak: from the reading sessions
    val rows = input.sessions.sortedBy { it.startMs }
    val merged = buildSessions(rows)

    val perDay: List<Pair<LocalDate, Int>> = merged
        .groupBy { dateOf(it.startMs, zone) }
        .map { (d, list) -> d to list.sumOf { it.pages } }
        .sortedBy { it.first }
    val totalPages = perDay.sumOf { it.second }
    val pageDates: List<Long?> = TIERS.getValue(MilestoneId.Pages).map { t ->
        var sum = 0
        var at: Long? = null
        for ((d, p) in perDay) {
            sum += p
            if (sum >= t) {
                at = known(dayStartMs(d, zone))
                break
            }
        }
        at
    }
    val recentPages = perDay.filter { dayStartMs(it.first, zone) >= cutoff }.sumOf { it.second }

    var totalSec = 0L
    val hourTiers = TIERS.getValue(MilestoneId.Hours)
    val hourDates = arrayOfNulls<Long>(hourTiers.size)
    for (r in rows) {
        totalSec += r.seconds
        for (i in hourTiers.indices) {
            if (hourDates[i] == null && totalSec >= hourTiers[i] * 3600L) hourDates[i] = known(r.startMs)
        }
    }
    val recentSec = rows.filter { it.startMs >= cutoff }.sumOf { it.seconds.toLong() }

    val sessionTimes = merged.map { it.startMs }
    val sessionDates = datesFromTimes(sessionTimes, TIERS.getValue(MilestoneId.Sessions))

    val byDay = Stats.secondsByDay(rows, zone)
    val longest = Stats.longestStreak(byDay)
    val reach = streakReach(byDay, TIERS.getValue(MilestoneId.Streak), zone)
    val streakDates: List<Long?> = TIERS.getValue(MilestoneId.Streak).map { reach[it] }

    // epic books: finished books of at least EPIC_PAGES pages
    val epic = finished.filter { isEpic(it.first) }
    val epicTimes = epic.map { it.second }
    val epicTargets: List<MilestoneTarget?> = epic.map { MilestoneTarget.OpenBook(it.first.id) }

    // words, ratings, quotes, notes
    val wordTimes = input.savedWords.map { it.addedAt }.sorted()
    val rated = books.count { isRated(it) }
    val quotes = input.highlights.sortedBy { it.createdAt }
    val quoteTimes = quotes.map { it.createdAt }
    val written = quotes.filter { it.note.isNotBlank() }
    val noteTimes = written.map { it.createdAt }

    // words read (pages turned times the words on a page), listening hours, reading days, reviews, authors
    val readRows = rows.filter { it.kind != SessionKind.LISTEN }
    val wordTiers = TIERS.getValue(MilestoneId.WordsRead)
    val wordDates = arrayOfNulls<Long>(wordTiers.size)
    var totalWords = 0.0
    var recentWords = 0.0
    for (r in readRows) {
        val w = wordsPerPage(byId[r.bookId]) * r.pages
        totalWords += w
        if (r.startMs >= cutoff) recentWords += w
        for (i in wordTiers.indices) {
            if (wordDates[i] == null && totalWords >= wordTiers[i]) wordDates[i] = known(r.startMs)
        }
    }
    val listenRows = rows.filter { it.kind == SessionKind.LISTEN }
    val listenTiers = TIERS.getValue(MilestoneId.ListenHours)
    val listenDates = arrayOfNulls<Long>(listenTiers.size)
    var listenSec = 0L
    for (r in listenRows) {
        listenSec += r.seconds
        for (i in listenTiers.indices) {
            if (listenDates[i] == null && listenSec >= listenTiers[i] * 3600L) listenDates[i] = known(r.startMs)
        }
    }
    val recentListen = listenRows.filter { it.startMs >= cutoff }.sumOf { it.seconds.toLong() }
    val readingDays = byDay.filterValues { it >= STREAK_MIN_SECONDS }.keys.sorted()
    val dayTimes = readingDays.map { dayStartMs(it, zone) }
    val reviews = books.count { it.journal.isNotBlank() }
    val authors = authorFirsts(books)
    val authorTimes = authors.map { it.second }
    val authorTargets: List<MilestoneTarget?> = authors.map { MilestoneTarget.OpenBook(it.first.id) }

    fun notesTarget(h: Highlight?): MilestoneTarget? = h?.takeIf { byId.containsKey(it.bookId) }?.let { MilestoneTarget.OpenNotes(it.bookId) }
    val tiersOf = { id: MilestoneId -> TIERS.getValue(id) }

    // books rated, dated by when the rating was set (an upgrade fills this in from the last time you opened the book)
    val ratedBooks = books.filter { isRated(it) }.sortedBy { it.ratedAt }
    val ratedTimes = ratedBooks.map { it.ratedAt }

    // perfect weeks: Monday to Sunday with a reading day on every day, dated by the Sunday
    val readingDaySet = readingDays.toSet()
    val perfectTimes = readingDays
        .map { it.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY)) }
        .distinct().sorted()
        .filter { w -> (0L..6L).all { w.plusDays(it) in readingDaySet } }
        .map { dayStartMs(it.plusDays(6), zone) }

    // comebacks: the day you read again after a week or more with no reading
    val comebackTimes = ArrayList<Long>()
    for (i in 1 until readingDays.size) {
        if (java.time.temporal.ChronoUnit.DAYS.between(readingDays[i - 1], readingDays[i]) >= 8L) comebackTimes.add(dayStartMs(readingDays[i], zone))
    }

    // marathons: one sitting of two hours or more (listening is left out)
    val marathonTimes = buildSessions(readRows).filter { it.seconds >= 7200L }.map { it.startMs }.sorted()

    // early birds and night owls: days with a sitting that started between 4 and 7 in the morning, or from 11 at night to 4
    fun firstPerDay(inRange: (Int) -> Boolean): List<Long> = readRows
        .filter { it.seconds >= STREAK_MIN_SECONDS && inRange(java.time.Instant.ofEpochMilli(it.startMs).atZone(zone).hour) }
        .groupBy { dateOf(it.startMs, zone) }
        .map { (_, list) -> list.minOf { it.startMs } }
        .sorted()
    val earlyTimes = firstPerDay { it in 4..6 }
    val owlTimes = firstPerDay { it >= 23 || it <= 3 }

    // genres and languages: the finished book that first brought each one in
    val genreTimes = ArrayList<Long>()
    val genreTargets = ArrayList<MilestoneTarget?>()
    val languageTimes = ArrayList<Long>()
    val languageTargets = ArrayList<MilestoneTarget?>()
    val seenGenres = HashSet<String>()
    val seenLanguages = HashSet<String>()
    for ((b, at) in finished) {
        for (g in broadGenresOf(b)) if (seenGenres.add(g)) { genreTimes.add(at); genreTargets.add(MilestoneTarget.OpenBook(b.id)) }
        for (l in languageOf(b)) if (seenLanguages.add(l)) { languageTimes.add(at); languageTargets.add(MilestoneTarget.OpenBook(b.id)) }
    }

    return listOf(
        build(
            MilestoneId.Books, "Books Read", null, MilestoneIcon.Book, TimelineKind.Book, "books",
            value = finished.size,
            dates = datesFromTimes(finishTimes, tiersOf(MilestoneId.Books)),
            targets = tiersOf(MilestoneId.Books).map { t -> finishTargets.getOrNull(t - 1) },
            recent = since(finishTimes).toDouble(),
        ),
        build(
            MilestoneId.Pages, "Pages Read", null, MilestoneIcon.Page, TimelineKind.Read, "pages",
            value = totalPages, dates = pageDates, targets = historyTargets(pageDates, zone),
            recent = recentPages.toDouble(),
        ),
        build(
            MilestoneId.Sessions, "Reading Sessions", null, MilestoneIcon.Clock, TimelineKind.Read, "sessions",
            value = sessionTimes.size,
            dates = sessionDates, targets = historyTargets(sessionDates, zone),
            recent = since(sessionTimes).toDouble(),
        ),
        build(
            MilestoneId.Hours, "Reading Hours", null, MilestoneIcon.Timer, TimelineKind.Read, "hours",
            value = (totalSec / 3600L).toInt(),
            dates = hourDates.toList(), targets = historyTargets(hourDates.toList(), zone),
            recent = recentSec / 3600.0,
        ),
        build(
            MilestoneId.Words, "Words Saved", null, MilestoneIcon.Mark, TimelineKind.Note, "words",
            value = wordTimes.size,
            dates = datesFromTimes(wordTimes, tiersOf(MilestoneId.Words)),
            targets = tiersOf(MilestoneId.Words).map { MilestoneTarget.OpenDictionary },
            recent = since(wordTimes).toDouble(),
        ),
        build(
            MilestoneId.Rated, "Books Rated", null, MilestoneIcon.Star, TimelineKind.Note, "books",
            value = rated,
            dates = datesFromTimes(ratedTimes, tiersOf(MilestoneId.Rated)),
            targets = tiersOf(MilestoneId.Rated).map { t -> ratedBooks.getOrNull(t - 1)?.let { MilestoneTarget.OpenBook(it.id) } },
            recent = since(ratedTimes.filter { it > 0 }).toDouble(),
        ),
        build(
            MilestoneId.Quotes, "Quotes Saved", null, MilestoneIcon.Quote, TimelineKind.Note, "quotes",
            value = quotes.size,
            dates = datesFromTimes(quoteTimes, tiersOf(MilestoneId.Quotes)),
            targets = tiersOf(MilestoneId.Quotes).map { t -> notesTarget(quotes.getOrNull(t - 1)) },
            recent = since(quoteTimes).toDouble(),
        ),
        build(
            MilestoneId.Streak, "Longest Streak", null, MilestoneIcon.Flame, TimelineKind.Read, "days",
            value = longest, dates = streakDates, targets = historyTargets(streakDates, zone),
            recent = null,
        ),
        build(
            MilestoneId.Epic, "Epic Books ($EPIC_PAGES+ pages)", "Epic Books", MilestoneIcon.Stack, TimelineKind.Book, "books",
            value = epic.size,
            dates = datesFromTimes(epicTimes, tiersOf(MilestoneId.Epic)),
            targets = tiersOf(MilestoneId.Epic).map { t -> epicTargets.getOrNull(t - 1) },
            recent = since(epicTimes).toDouble(),
        ),
        build(
            MilestoneId.Notes, "Notes Written", null, MilestoneIcon.Note, TimelineKind.Note, "notes",
            value = noteTimes.size,
            dates = datesFromTimes(noteTimes, tiersOf(MilestoneId.Notes)),
            targets = tiersOf(MilestoneId.Notes).map { t -> notesTarget(written.getOrNull(t - 1)) },
            recent = since(noteTimes).toDouble(),
        ),
        build(
            MilestoneId.WordsRead, "Words Read", null, MilestoneIcon.Words, TimelineKind.Read, "words",
            value = totalWords.coerceAtMost(Int.MAX_VALUE.toDouble()).toLong().toInt(),
            dates = wordDates.toList(), targets = historyTargets(wordDates.toList(), zone),
            recent = recentWords,
        ),
        build(
            MilestoneId.ListenHours, "Listening Hours", "Listening", MilestoneIcon.Headphones, TimelineKind.Read, "hours",
            value = (listenSec / 3600L).toInt(),
            dates = listenDates.toList(), targets = historyTargets(listenDates.toList(), zone),
            recent = recentListen / 3600.0,
        ),
        build(
            MilestoneId.Reviews, "Reviews Written", null, MilestoneIcon.Note, TimelineKind.Note, "reviews",
            value = reviews,
            dates = tiersOf(MilestoneId.Reviews).map { null }, // a review is saved without a date
            targets = emptyList(),
            recent = null,
        ),
        build(
            MilestoneId.Days, "Reading Days", null, MilestoneIcon.Calendar, TimelineKind.Read, "days",
            value = dayTimes.size,
            dates = datesFromTimes(dayTimes, tiersOf(MilestoneId.Days)),
            targets = historyTargets(datesFromTimes(dayTimes, tiersOf(MilestoneId.Days)), zone),
            recent = since(dayTimes).toDouble(),
        ),
        build(
            MilestoneId.Authors, "Authors Read", null, MilestoneIcon.Person, TimelineKind.Book, "authors",
            value = authors.size,
            dates = datesFromTimes(authorTimes, tiersOf(MilestoneId.Authors)),
            targets = tiersOf(MilestoneId.Authors).map { t -> authorTargets.getOrNull(t - 1) },
            recent = since(authorTimes).toDouble(),
        ),
        build(
            MilestoneId.PerfectWeeks, "Perfect Weeks", null, MilestoneIcon.Calendar, TimelineKind.Read, "weeks",
            value = perfectTimes.size,
            dates = datesFromTimes(perfectTimes, tiersOf(MilestoneId.PerfectWeeks)),
            targets = historyTargets(datesFromTimes(perfectTimes, tiersOf(MilestoneId.PerfectWeeks)), zone),
            recent = since(perfectTimes).toDouble(),
        ),
        build(
            MilestoneId.Comebacks, "Comebacks", null, MilestoneIcon.Flame, TimelineKind.Read, "comebacks",
            value = comebackTimes.size,
            dates = datesFromTimes(comebackTimes, tiersOf(MilestoneId.Comebacks)),
            targets = historyTargets(datesFromTimes(comebackTimes, tiersOf(MilestoneId.Comebacks)), zone),
            recent = since(comebackTimes).toDouble(),
        ),
        build(
            MilestoneId.Marathons, "Marathon Sessions", "Marathons", MilestoneIcon.Timer, TimelineKind.Read, "sessions",
            value = marathonTimes.size,
            dates = datesFromTimes(marathonTimes, tiersOf(MilestoneId.Marathons)),
            targets = historyTargets(datesFromTimes(marathonTimes, tiersOf(MilestoneId.Marathons)), zone),
            recent = since(marathonTimes).toDouble(),
        ),
        build(
            MilestoneId.EarlyBird, "Early Bird", null, MilestoneIcon.Clock, TimelineKind.Read, "days",
            value = earlyTimes.size,
            dates = datesFromTimes(earlyTimes, tiersOf(MilestoneId.EarlyBird)),
            targets = historyTargets(datesFromTimes(earlyTimes, tiersOf(MilestoneId.EarlyBird)), zone),
            recent = since(earlyTimes).toDouble(),
        ),
        build(
            MilestoneId.NightOwl, "Night Owl", null, MilestoneIcon.Star, TimelineKind.Read, "days",
            value = owlTimes.size,
            dates = datesFromTimes(owlTimes, tiersOf(MilestoneId.NightOwl)),
            targets = historyTargets(datesFromTimes(owlTimes, tiersOf(MilestoneId.NightOwl)), zone),
            recent = since(owlTimes).toDouble(),
        ),
        build(
            MilestoneId.Genres, "Genres Explored", "Genres", MilestoneIcon.Stack, TimelineKind.Book, "genres",
            value = seenGenres.size,
            dates = datesFromTimes(genreTimes, tiersOf(MilestoneId.Genres)),
            targets = tiersOf(MilestoneId.Genres).map { t -> genreTargets.getOrNull(t - 1) },
            recent = since(genreTimes).toDouble(),
        ),
        build(
            MilestoneId.Languages, "Languages Read", "Languages", MilestoneIcon.Words, TimelineKind.Book, "languages",
            value = seenLanguages.size,
            dates = datesFromTimes(languageTimes, tiersOf(MilestoneId.Languages)),
            targets = tiersOf(MilestoneId.Languages).map { t -> languageTargets.getOrNull(t - 1) },
            recent = since(languageTimes).toDouble(),
        ),
    )
}

/** Tiers unlocked over all tiers: (done, total). */
fun tiersUnlocked(list: List<Milestone>): Pair<Int, Int> =
    list.sumOf { it.unlocked } to list.sumOf { it.tiers.size }

// ---- next up --------------------------------------------------------------------------------

/** The milestone closest to its next tier (the biggest share of the way there). */
fun pickNextUp(list: List<Milestone>): NextUp? {
    var best: Milestone? = null
    for (m in list) {
        if (m.next == null) continue
        val b = best
        if (b == null || m.pct > b.pct) best = m
    }
    val b = best ?: return null
    val target = b.next ?: return null
    val need = target - b.value
    val recent = b.recent
    val perDay = if (recent != null && recent > 0) recent / MILESTONE_RECENT_DAYS else 0.0
    return NextUp(
        milestone = b,
        tier = b.unlocked + 1,
        need = need,
        target = target,
        days = if (perDay > 0) max(1, ceil(need / perDay).toInt()) else null,
    )
}

/** "about 24 days" / "about 6 weeks" / "about 5 months". */
fun etaText(days: Int): String = when {
    days < 21 -> "about $days ${if (days == 1) "day" else "days"}"
    days < 70 -> "about ${Math.round(days / 7.0)} weeks"
    else -> {
        val months = Math.round(days / 30.0).toInt()
        if (months >= 24) "over 2 years" else "about $months months"
    }
}

/** What the next-up card says after "until": "25 Books Read", "a 30-day streak". */
fun goalText(m: Milestone, n: Int): String = when (m.id) {
    MilestoneId.Books -> "${commas(n)} Books Read"
    MilestoneId.Streak -> "a $n-day streak"
    MilestoneId.Notes -> if (n == 1) "your first note" else "${commas(n)} Notes Written"
    MilestoneId.Reviews -> if (n == 1) "your first review" else "${commas(n)} Reviews Written"
    else -> tierTitle(m, n)
}

// ---- timeline -------------------------------------------------------------------------------

fun tierTitle(m: Milestone, n: Int): String = when (m.id) {
    MilestoneId.Books -> "${commas(n)} Books Finished"
    MilestoneId.Pages -> "${commas(n)} Pages Read"
    MilestoneId.Sessions -> "${commas(n)} Reading Sessions"
    MilestoneId.Hours -> "${commas(n)} Reading Hours"
    MilestoneId.Words -> "${commas(n)} Words Saved"
    MilestoneId.Rated -> "${commas(n)} Books Rated"
    MilestoneId.Quotes -> "${commas(n)} Quotes Saved"
    MilestoneId.Streak -> "$n-Day Reading Streak"
    MilestoneId.Epic -> "${commas(n)} Epic Books"
    MilestoneId.Notes -> if (n == 1) "First Reading Note" else "${commas(n)} Notes Written"
    MilestoneId.WordsRead -> "${shortNum(n)} Words Read"
    MilestoneId.ListenHours -> "${commas(n)} Listening Hours"
    MilestoneId.PerfectWeeks -> if (n == 1) "First Perfect Week" else "${commas(n)} Perfect Weeks"
    MilestoneId.Comebacks -> if (n == 1) "First Comeback" else "${commas(n)} Comebacks"
    MilestoneId.Marathons -> if (n == 1) "First Marathon Session" else "${commas(n)} Marathon Sessions"
    MilestoneId.EarlyBird -> "${commas(n)} Early Mornings"
    MilestoneId.NightOwl -> "${commas(n)} Late Nights"
    MilestoneId.Genres -> "${commas(n)} Genres Explored"
    MilestoneId.Languages -> "${commas(n)} Languages Read"
    MilestoneId.Reviews -> if (n == 1) "First Review Written" else "${commas(n)} Reviews Written"
    MilestoneId.Days -> "${commas(n)} Reading Days"
    MilestoneId.Authors -> "${commas(n)} Authors Read"
}

/** "2 days and 2 hours of reading" (from 24 hours), else "12 hours of reading". */
fun hoursText(hours: Int): String {
    if (hours < 24) return "$hours ${if (hours == 1) "hour" else "hours"} of reading"
    val d = hours / 24
    val h = hours % 24
    val days = "$d ${if (d == 1) "day" else "days"}"
    return if (h > 0) "$days and $h ${if (h == 1) "hour" else "hours"} of reading" else "$days of reading"
}

private fun q(title: String) = "\u201C$title\u201D"

fun buildTimeline(input: MilestoneInput, list: List<Milestone>): List<TimelineEvent> {
    val books = input.books
    val byId = books.associateBy { it.id }
    val finished = books.filter { it.finished }.map { it to finishedAtMs(it) }.sortedBy { it.second }
    val quotes = input.highlights.sortedBy { it.createdAt }
    val written = quotes.filter { it.note.isNotBlank() }
    val words = input.savedWords.sortedBy { it.addedAt }
    val added = books.map { it to it.addedAt }.sortedBy { it.second }
    val authors = authorFirsts(books)

    fun titleOf(bookId: String?): String = byId[bookId]?.title ?: "a removed book"
    fun bookTarget(b: Book): MilestoneTarget = MilestoneTarget.OpenBook(b.id)

    val out = ArrayList<TimelineEvent>()
    fun push(
        key: String, kind: TimelineKind, icon: MilestoneIcon, title: String, at: Long,
        sub: List<TextPart>, target: MilestoneTarget?,
    ) {
        if (at > 0) out.add(TimelineEvent(key, kind, icon, title, at, sub, target))
    }

    // tier unlocks
    for (m in list) {
        m.dates.forEachIndexed { i, at ->
            if (at == null) return@forEachIndexed
            val n = m.tiers[i]
            var icon = m.icon
            val sub: List<TextPart> = when (m.id) {
                MilestoneId.Books -> {
                    icon = MilestoneIcon.Done
                    listOf(TextPart("Finished "), TextPart(q(finished.getOrNull(n - 1)?.first?.title ?: ""), true))
                }
                MilestoneId.Pages -> listOf(TextPart("Across all your books"))
                MilestoneId.Sessions -> listOf(TextPart("Your "), TextPart(ordinal(n), true), TextPart(" time sitting down with a book"))
                MilestoneId.Hours -> listOf(TextPart(hoursText(n)))
                MilestoneId.Words -> listOf(TextPart("Latest: "), TextPart(words.getOrNull(n - 1)?.word ?: "", true))
                MilestoneId.Quotes -> listOf(TextPart("Latest from "), TextPart(titleOf(quotes.getOrNull(n - 1)?.bookId), true))
                MilestoneId.Streak -> listOf(TextPart("$n days without a missed day"))
                MilestoneId.Epic -> listOf(TextPart("$n books of $EPIC_PAGES+ pages"))
                MilestoneId.Notes ->
                    if (n == 1) listOf(TextPart(titleOf(written.getOrNull(0)?.bookId), true))
                    else listOf(TextPart("Latest on "), TextPart(titleOf(written.getOrNull(n - 1)?.bookId), true))
                MilestoneId.Rated -> emptyList()
                MilestoneId.WordsRead -> listOf(TextPart("Across everything you read"))
                MilestoneId.ListenHours -> listOf(TextPart("$n hours of listening"))
                MilestoneId.Reviews -> emptyList()
                MilestoneId.Days -> listOf(TextPart("Your "), TextPart(ordinal(n), true), TextPart(" day of reading"))
                MilestoneId.Authors -> listOf(TextPart("Latest: "), TextPart(authors.getOrNull(n - 1)?.first?.author ?: "", true))
                MilestoneId.PerfectWeeks -> listOf(TextPart("A reading day on every day of the week"))
                MilestoneId.Comebacks -> listOf(TextPart("Back after a week away"))
                MilestoneId.Marathons -> listOf(TextPart("Two hours or more in one sitting"))
                MilestoneId.EarlyBird -> listOf(TextPart("Mornings you read before 7"))
                MilestoneId.NightOwl -> listOf(TextPart("Nights you read after 11"))
                MilestoneId.Genres -> listOf(TextPart("Kinds of books you have finished"))
                MilestoneId.Languages -> listOf(TextPart("Languages you have finished a book in"))
            }
            push("${m.id.name}:$n", m.kind, icon, tierTitle(m, n), at, sub, m.targets.getOrNull(i))
        }
    }

    // books added
    for (n in ADDED_TIERS) {
        val a = added.getOrNull(n - 1) ?: continue
        push(
            "added:$n", TimelineKind.Book, MilestoneIcon.Trophy, "${commas(n)} Books Added", a.second,
            listOf(TextPart("Milestone reached with "), TextPart(q(a.first.title), true)), bookTarget(a.first),
        )
    }

    // firsts
    added.firstOrNull()?.let { (b, at) ->
        push("first-added", TimelineKind.Book, MilestoneIcon.Plus, "First Book Added", at, listOf(TextPart(b.title, true)), bookTarget(b))
    }
    finished.firstOrNull()?.let { (b, at) ->
        push("first-finished", TimelineKind.Book, MilestoneIcon.Done, "First Book Finished", at, listOf(TextPart(b.title, true)), bookTarget(b))
    }
    quotes.firstOrNull()?.let { h ->
        val book = byId[h.bookId]
        push(
            "first-quote", TimelineKind.Note, MilestoneIcon.Quote, "First Saved Quote", h.createdAt,
            listOf(TextPart(titleOf(h.bookId), true)), if (book != null) MilestoneTarget.OpenNotes(book.id) else null,
        )
    }

    // the longest finished book (pages as the book counts them)
    val longest = finished.filter { it.first.pageCount > 0 }.maxByOrNull { it.first.pageCount }
    if (longest != null) {
        push(
            "longest-book", TimelineKind.Book, MilestoneIcon.Stack, "Longest Book Read", longest.second,
            listOf(TextPart(longest.first.title, true), TextPart(" (${commas(longest.first.pageCount)} pages)")),
            bookTarget(longest.first),
        )
    }

    return out.sortedWith(compareByDescending<TimelineEvent> { it.at }.thenBy { it.key })
}

// ---- dates ----------------------------------------------------------------------------------

/** "October" for this year, "May 2025" for earlier years. */
fun monthHeading(at: Long, nowMs: Long, zone: ZoneId): String {
    val d = dateOf(at, zone)
    val name = StatNames.MONTHS[d.monthValue - 1]
    return if (d.year == dateOf(nowMs, zone).year) name else "$name ${d.year}"
}

/** "8 Oct", or "8 Oct 2025" for earlier years. */
fun shortDateLabel(at: Long, nowMs: Long, zone: ZoneId): String {
    val d = dateOf(at, zone)
    val base = "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"
    return if (d.year == dateOf(nowMs, zone).year) base else "$base ${d.year}"
}
