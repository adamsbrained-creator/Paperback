package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.Consistency
import com.paperback.app.data.FinishBy
import com.paperback.app.data.Forecast
import com.paperback.app.data.ForecastBook
import com.paperback.app.data.GoalNeed
import com.paperback.app.data.WORDS_PER_PAGE
import com.paperback.app.data.WordStats
import com.paperback.app.data.WpmMonth
import com.paperback.app.data.buildForecast
import com.paperback.app.data.daysAtMinutes
import com.paperback.app.data.finishDateText
import com.paperback.app.data.goalNeed
import com.paperback.app.data.minutesPerDayToFinish
import com.paperback.app.data.minutesText
import com.paperback.app.data.wordStats
import com.paperback.app.data.wordsText
import com.paperback.app.data.Goals
import com.paperback.app.data.MonthCompare
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Records
import com.paperback.app.data.Speed
import com.paperback.app.data.StatNames
import com.paperback.app.data.Stats
import com.paperback.app.data.YearPace
import com.paperback.app.data.commas
import com.paperback.app.data.consistency
import com.paperback.app.data.inDaysText
import com.paperback.app.data.monthCompare
import com.paperback.app.data.readingRecords
import com.paperback.app.data.readingSpeed
import com.paperback.app.data.yearPace
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** Where a tap on the Insights page goes. The Stats screen builds this from the app's navigation. */
class InsightsLinks(
    /** Stats -> History, on that day. */
    val history: (day: LocalDate) -> Unit,
    val book: (bookId: String) -> Unit,
    /** A shelf of books: "done-2026" is the books finished in 2026. */
    val shelf: (kind: String) -> Unit,
)

private val FORECAST_ACCENTS = listOf(DashAccent.Blue, DashAccent.Cyan, DashAccent.Pink, DashAccent.Violet)

private fun dayText(d: LocalDate) = "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"

private fun minText(seconds: Long) = Stats.duration(seconds)

/**
 * Stats -> Insights: how this month compares, consistency, reading speed, records, finish estimates and the pace of
 * the year. Every card opens something: History on a day, a book, or the books finished this year.
 */
@Composable
fun InsightsScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    goals: Goals,
    links: InsightsLinks,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val zone = remember { ZoneId.systemDefault() }
    val nowMs = remember { System.currentTimeMillis() }
    val today = remember { LocalDate.now(zone) }

    if (sessions.isEmpty()) {
        Box(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("No insights yet", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Read for a few days and what stands out will show up here.",
                    color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center,
                )
            }
        }
        return
    }

    val month = remember(sessions) { monthCompare(sessions, today, zone) }
    val cons = remember(sessions) { consistency(sessions, today, zone) }
    val speed = remember(sessions) { readingSpeed(sessions, today, zone) }
    val rec = remember(sessions) { readingRecords(sessions, zone) }
    val forecast = remember(books, sessions) { buildForecast(books, sessions, today, zone) }
    val words = remember(books, sessions) { wordStats(sessions, books, today, zone) }
    val finished = remember(books) { Stats.booksFinishedInYear(books, today.year, zone) }
    val year = remember(finished, goals.booksPerYear) { yearPace(finished, goals.booksPerYear, nowMs, zone) }
    val need = remember(finished, goals.booksPerYear) { goalNeed(finished, goals.booksPerYear, today) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "month") { MonthCard(month) { links.history(today) } }
        item(key = "consistency") { ConsistencyRow(cons) { links.history(today) } }
        item(key = "speed") { SpeedCard(speed, links) }
        item(key = "wpm") { WpmCard(words, links) }
        item(key = "words") { WordsCard(words, links) }
        item(key = "records-label") {
            CardLabel("Your records", Modifier.padding(start = 4.dp, top = 12.dp))
        }
        item(key = "records") { RecordsTiles(rec, links) }
        if (forecast.books.isNotEmpty()) {
            item(key = "forecast") { ForecastCard(forecast, today, links) }
        }
        item(key = "year") {
            YearCard(year, need, onOpen = if (year.finished > 0) ({ links.shelf("done-${year.year}") }) else null)
        }
    }
}

// ---- shared bits ----------------------------------------------------------------------------

/** A dashboard card (graphite, soft glow). With [onTap] it is clickable (and announced as a button). */
@Composable
private fun InsightCard(description: String, onTap: (() -> Unit)?, content: @Composable () -> Unit) {
    DashCard(Modifier.fillMaxWidth(), onClick = onTap, description = description) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) { content() }
    }
}

/** The title of a card with a small note at the right: "Reading speed" ... "pages per hour". */
@Composable
private fun CardHead(title: String, note: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
        Text(title, modifier = Modifier.weight(1f), color = t.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(10.dp))
        Text(note, color = t.setSub, fontSize = 14.sp)
    }
}

/** A big number with its unit after it, on one baseline. */
@Composable
private fun NumberUnit(number: String, unit: String?, color: Color, size: Int = 44) {
    val t = pbTokens()
    Row {
        Text(
            number,
            modifier = Modifier.alignByBaseline(),
            color = color,
            fontSize = size.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.02).em,
            maxLines = 1,
        )
        if (unit != null) {
            Text(unit, modifier = Modifier.alignByBaseline().padding(start = 6.dp), color = t.setSub, fontSize = 16.sp, maxLines = 1)
        }
    }
}

// ---- this month against last ----------------------------------------------------------------

@Composable
private fun MonthCard(m: MonthCompare, onOpen: () -> Unit) {
    val t = pbTokens()
    val pct = m.pct
    val up = pct != null && pct >= 0
    val em = if (up) inkOf(DashAccent.Cyan) else inkOf(DashAccent.Pink)
    val sentence: AnnotatedString = buildAnnotatedString {
        when {
            pct == null -> {
                append("You've read ")
                withStyle(SpanStyle(color = em)) { append(minText(m.cur)) }
                append(" this month.")
            }
            pct == 0 -> append("You're reading about the same as last month.")
            else -> {
                append("You're reading ")
                withStyle(SpanStyle(color = em)) { append("${abs(pct)}% ${if (up) "more" else "less"}") }
                append(" than ${m.prevName}.")
            }
        }
    }
    val maxSeconds = max(1L, max(m.cur, m.prev))
    InsightCard("${m.monthName} so far: ${minText(m.cur)}. Open History.", onOpen) {
        CardLabel("${m.monthName} so far")
        Spacer(Modifier.height(12.dp))
        Text(sentence, color = t.ink, fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(16.dp))
        CompareRow(m.monthName.take(3), m.cur, maxSeconds, DashAccent.Blue, 1f)
        Spacer(Modifier.height(10.dp))
        CompareRow(m.prevName.take(3), m.prev, maxSeconds, DashAccent.Violet, 0.55f)
        Text(
            "${m.monthName} is compared with the same days of ${m.prevName}.",
            modifier = Modifier.padding(top = 12.dp),
            color = t.setSub,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun CompareRow(label: String, seconds: Long, maxSeconds: Long, color: Color, alpha: Float) {
    val t = pbTokens()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.width(48.dp), color = t.ink, fontSize = 15.sp)
        Box(Modifier.weight(1f)) {
            PctBar(max(0.02f, seconds.toFloat() / maxSeconds), color.copy(alpha = alpha), 10.dp)
        }
        Text(minText(seconds), modifier = Modifier.width(64.dp), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
    }
}

// ---- consistency ----------------------------------------------------------------------------

@Composable
private fun ConsistencyRow(c: Consistency, onOpen: () -> Unit) {
    val t = pbTokens()
    val pct = (c.pct * 100).roundToInt()
    val frac = if (c.longestStreak <= 0) 0f else (c.streak.toFloat() / c.longestStreak).coerceIn(0.03f, 1f)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        DashCard(
            Modifier.weight(1f).height(188.dp),
            onClick = onOpen,
            description = "Consistency: ${c.activeDays} of ${c.of} days. Open History.",
        ) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                DashLabel(PbIconName.Check, "Consistency")
                Box(Modifier.fillMaxWidth().weight(1f).padding(top = 6.dp)) {
                    GoalGauge(c.pct.coerceIn(0f, 1f), Modifier.fillMaxSize())
                    Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$pct%", color = t.ink, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em)
                        Text("${c.activeDays} of ${c.of} days", color = t.setSub, fontSize = 12.sp)
                    }
                }
            }
        }
        DashCard(
            Modifier.weight(1f).height(188.dp),
            description = "Streak: ${c.streak} days. Best streak: ${c.longestStreak} days.",
        ) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Column {
                    DashLabel(PbIconName.Flame, "Streak")
                    Spacer(Modifier.height(10.dp))
                    Row {
                        Text("${c.streak}", modifier = Modifier.alignByBaseline(), color = t.ink, fontSize = 36.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em, maxLines = 1)
                        Text("days", modifier = Modifier.alignByBaseline().padding(start = 6.dp), color = t.setSub, fontSize = 15.sp, maxLines = 1)
                    }
                }
                Column {
                    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(t.ink.copy(alpha = 0.12f))) {
                        Box(
                            Modifier
                                .fillMaxWidth(frac)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(3.dp))
                                .background(Brush.horizontalGradient(listOf(DashAccent.Blue, DashAccent.Pink))),
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Best streak ${c.longestStreak} days", color = t.setSub, fontSize = 13.sp)
                }
            }
        }
    }
}

/** A ring filled [value] (0..1) of the way round from the top, with [content] in the middle. */
@Composable
private fun RingArc(value: Float, color: Color, size: Dp, stroke: Dp, content: @Composable () -> Unit) {
    val track = trackColor()
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = stroke.toPx()
            val d = this.size.minDimension - sw
            val tl = Offset(sw / 2f, sw / 2f)
            drawArc(track, 0f, 360f, false, topLeft = tl, size = Size(d, d), style = Stroke(sw))
            val v = value.coerceIn(0f, 1f)
            if (v > 0f) {
                drawArc(color, -90f, 360f * v, false, topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
            }
        }
        content()
    }
}

// ---- reading speed --------------------------------------------------------------------------

private const val BAR_AREA = 62

@Composable
private fun SpeedCard(speed: Speed, links: InsightsLinks) {
    val t = pbTokens()
    val yellow = DashAccent.Violet
    val best = speed.best
    val maxPace = max(1, speed.months.maxOf { it.pace })
    InsightCard("Reading speed: ${if (speed.current > 0) "${speed.current} pages per hour" else "not enough reading yet"}.", null) {
        CardHead("Reading speed", "pages per hour")
        Spacer(Modifier.height(14.dp))
        NumberUnit(if (speed.current > 0) "${speed.current}" else "\u2013", if (speed.current > 0) "p/h" else null, inkOf(yellow))
        Text(
            if (best != null) "Fastest month: ${best.label} \u00B7 ${best.pace} p/h" else "Read a little longer to see how your speed changes.",
            modifier = Modifier.padding(top = 6.dp),
            color = t.setSub,
            fontSize = 14.sp,
        )
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().height((BAR_AREA + 48).dp)) {
            speed.months.forEach { s ->
                val top = best != null && best.label == s.label && s.pace == best.pace
                val h = if (s.pace > 0) max(10, ((s.pace.toFloat() / maxPace) * BAR_AREA).roundToInt()) else 6
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(horizontal = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .semantics(mergeDescendants = true) {
                            contentDescription = "${s.label}: ${if (s.pace > 0) "${s.pace} pages per hour" else "not enough reading"}. Open that month in History."
                        }
                        .clickable(onClickLabel = "Open that month", role = Role.Button) { links.history(s.firstDay) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    if (s.pace > 0) {
                        Text("${s.pace}", color = if (top) inkOf(yellow) else t.setSub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(3.dp))
                    }
                    Box(
                        Modifier
                            .width(10.dp)
                            .height(h.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(
                                when {
                                    s.pace <= 0 -> SolidColor(yellow.copy(alpha = 0.25f))
                                    top -> Brush.verticalGradient(listOf(DashAccent.Pink, yellow))
                                    else -> Brush.verticalGradient(listOf(yellow.copy(alpha = 0.75f), yellow.copy(alpha = 0.35f)))
                                },
                            ),
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(s.label, color = t.setSub, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}

// ---- records --------------------------------------------------------------------------------

@Composable
private fun RecordsTiles(rec: Records, links: InsightsLinks) {
    val bestDay = rec.bestDay
    val longest = rec.longestSession
    val bestWeek = rec.bestWeek
    val most = rec.mostPages
    val zone = remember { ZoneId.systemDefault() }
    val longestDay = longest?.let { java.time.Instant.ofEpochMilli(it.startMs).atZone(zone).toLocalDate() }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RecordTile(
                "Best day", if (bestDay != null) minText(bestDay.seconds) else "\u2013", bestDay?.let { dayText(it.date) },
                DashAccent.Pink,
                if (bestDay != null) "Best day, ${dayText(bestDay.date)}. Open that day." else "Best day: none yet.",
                if (bestDay != null) ({ links.history(bestDay.date) }) else null,
                Modifier.weight(1f),
            )
            RecordTile(
                "Longest session", if (longest != null) minText(longest.seconds) else "\u2013", longestDay?.let { dayText(it) },
                DashAccent.Blue,
                if (longestDay != null) "Longest session, ${dayText(longestDay)}. Open that day." else "Longest session: none yet.",
                if (longest != null && longestDay != null) ({ links.history(longestDay) }) else null,
                Modifier.weight(1f),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RecordTile(
                "Best week", if (bestWeek != null) minText(bestWeek.seconds) else "\u2013", bestWeek?.let { "from ${dayText(it.start)}" },
                DashAccent.Violet,
                if (bestWeek != null) "Best week, from ${dayText(bestWeek.start)}. Open that week." else "Best week: none yet.",
                if (bestWeek != null) ({ links.history(bestWeek.start) }) else null,
                Modifier.weight(1f),
            )
            RecordTile(
                "Most pages a day", if (most != null) commas(most.pages) else "\u2013",
                most?.let { "${StatNames.WEEKDAYS_SHORT[StatNames.weekdayIndex(it.date)]} ${dayText(it.date)}" },
                DashAccent.Cyan,
                if (most != null) "Most pages in a day, ${dayText(most.date)}. Open that day." else "Most pages in a day: none yet.",
                if (most != null) ({ links.history(most.date) }) else null,
                Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun RecordTile(
    label: String,
    value: String,
    sub: String?,
    color: Color,
    description: String,
    onTap: (() -> Unit)?,
    modifier: Modifier,
) {
    val t = pbTokens()
    DashCard(modifier.height(112.dp), onClick = onTap, description = description) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(color))
                Spacer(Modifier.width(8.dp))
                Text(label, color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Column {
                Text(value, color = t.ink, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.02).em, maxLines = 1)
                if (sub != null) Text(sub, color = t.setSub, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

// ---- when you will finish -------------------------------------------------------------------

// ---- words per minute -----------------------------------------------------------------------

@Composable
private fun WpmCard(w: WordStats, links: InsightsLinks) {
    val t = pbTokens()
    val blue = DashAccent.Blue
    val best = w.bestMonth
    val maxWpm = max(1, w.months.maxOf { it.wpm })
    InsightCard("Words per minute: ${if (w.wpm > 0) "${w.wpm}" else "not enough reading yet"}.", null) {
        CardHead("Words per minute", "last 60 days")
        Spacer(Modifier.height(14.dp))
        NumberUnit(if (w.wpm > 0) "${w.wpm}" else "–", if (w.wpm > 0) "wpm" else null, inkOf(blue))
        Text(
            if (best != null) "Fastest month: ${best.label} · ${best.wpm} wpm" else "Read a little longer to see how your speed changes.",
            modifier = Modifier.padding(top = 6.dp),
            color = t.setSub,
            fontSize = 14.sp,
        )
        if (w.wpm > 0 && w.wpmEstimated) {
            Text(
                "Estimated at $WORDS_PER_PAGE words a page. Add a word count in Edit book for an exact speed.",
                modifier = Modifier.padding(top = 4.dp),
                color = t.setSub,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().height((BAR_AREA + 48).dp)) {
            w.months.forEach { m -> WpmBar(m, best, maxWpm, links) }
        }
        val fast = w.fastest
        val slow = w.slowest
        if (fast != null) {
            Spacer(Modifier.height(10.dp))
            BookWpmRow("Fastest book", fast.book, fast.wpm, links)
        }
        if (slow != null && fast != null && slow.book.id != fast.book.id) {
            BookWpmRow("Slowest book", slow.book, slow.wpm, links)
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.WpmBar(m: WpmMonth, best: WpmMonth?, maxWpm: Int, links: InsightsLinks) {
    val t = pbTokens()
    val blue = DashAccent.Blue
    val top = best != null && best.label == m.label && m.wpm == best.wpm
    val h = if (m.wpm > 0) max(10, ((m.wpm.toFloat() / maxWpm) * BAR_AREA).roundToInt()) else 6
    Column(
        Modifier
            .weight(1f)
            .fillMaxHeight()
            .padding(horizontal = 3.dp)
            .clip(RoundedCornerShape(10.dp))
            .semantics(mergeDescendants = true) {
                contentDescription = "${m.label}: ${if (m.wpm > 0) "${m.wpm} words per minute" else "not enough reading"}. Open that month in History."
            }
            .clickable(onClickLabel = "Open that month", role = Role.Button) { links.history(m.firstDay) },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom,
    ) {
        if (m.wpm > 0) {
            Text("${m.wpm}", color = if (top) inkOf(blue) else t.setSub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
        }
        Box(
            Modifier
                .width(10.dp)
                .height(h.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(
                    when {
                        m.wpm <= 0 -> SolidColor(blue.copy(alpha = 0.25f))
                        top -> Brush.verticalGradient(listOf(DashAccent.Cyan, blue))
                        else -> Brush.verticalGradient(listOf(blue.copy(alpha = 0.75f), blue.copy(alpha = 0.35f)))
                    },
                ),
        )
        Spacer(Modifier.height(8.dp))
        Text(m.label, color = t.setSub, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun BookWpmRow(label: String, book: Book, wpm: Int, links: InsightsLinks) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .semantics(mergeDescendants = true) { contentDescription = "$label: ${book.title}, $wpm words per minute. Open book details." }
            .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(book.id) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BookCover(book, Modifier.width(34.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = t.setSub, fontSize = 12.sp)
            Text(book.title, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("$wpm wpm", color = inkOf(DashAccent.Blue), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ---- words read -----------------------------------------------------------------------------

@Composable
private fun WordsCard(w: WordStats, links: InsightsLinks) {
    val t = pbTokens()
    val mint = DashAccent.Cyan
    val counted = w.countedBooks
    val all = w.countedBooks + w.uncountedBooks
    InsightCard("Words read: ${commas(w.total.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())}.", null) {
        CardHead("Words read", "pages turned")
        Spacer(Modifier.height(14.dp))
        NumberUnit(if (w.total > 0) wordsText(w.total) else "–", if (w.total > 0) "words" else null, inkOf(mint))
        Text(
            when {
                w.total <= 0 -> "Words are counted from the pages you turn."
                w.novels >= 1.0 -> "About ${if (w.novels >= 10) "${Math.round(w.novels)}" else "%.1f".format(w.novels)} average novels (90,000 words each)."
                else -> "Less than one average novel so far."
            },
            modifier = Modifier.padding(top = 6.dp),
            color = t.setSub,
            fontSize = 14.sp,
            lineHeight = 20.sp,
        )
        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            TileRow(
                { m ->
                    StatTile("This month", DashAccent.Blue, m, null, "Words read this month: ${wordsText(w.thisMonth)}.") {
                        BigNumber(if (w.thisMonth > 0) wordsText(w.thisMonth) else "–")
                    }
                },
                { m ->
                    StatTile("This year", DashAccent.Pink, m, null, "Words read this year: ${wordsText(w.thisYear)}.") {
                        BigNumber(if (w.thisYear > 0) wordsText(w.thisYear) else "–")
                    }
                },
            )
            TileRow(
                { m ->
                    StatTile("A reading day", DashAccent.Violet, m, null, "Words on an average reading day: ${w.perReadingDay}.") {
                        BigNumber(if (w.perReadingDay > 0) wordsText(w.perReadingDay.toLong()) else "–")
                        TileSub("last 30 days")
                    }
                },
                { m ->
                    StatTile("Listened", DashAccent.Cyan, m, null, "Words listened to: ${wordsText(w.listened)}.") {
                        BigNumber(if (w.listened > 0) wordsText(w.listened) else "–")
                        TileSub("read aloud")
                    }
                },
            )
        }
        if (w.topBooks.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            CardLabel("Most words")
            Spacer(Modifier.height(6.dp))
            w.topBooks.forEach { b ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .semantics(mergeDescendants = true) { contentDescription = "${b.book.title}, ${wordsText(b.words)} words. Open book details." }
                        .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(b.book.id) }
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BookCover(b.book, Modifier.width(34.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(b.book.title, modifier = Modifier.weight(1f), color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(wordsText(b.words), color = t.setSub, fontSize = 14.sp)
                }
            }
        }
        if (all > 0) {
            Text(
                if (counted == all) "Every book here has an exact word count."
                else "$counted of $all books have an exact word count; the rest are counted at $WORDS_PER_PAGE words a page. Add counts in Edit book.",
                modifier = Modifier.padding(top = 10.dp),
                color = t.setSub,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
        }
    }
}

// ---- when you will finish -------------------------------------------------------------------

private enum class ForecastMode(val label: String) {
    Pace("Your pace"),
    Minutes("Minutes a day"),
    By("Finish by"),
}

@Composable
private fun ForecastCard(f: Forecast, today: LocalDate, links: InsightsLinks) {
    val t = pbTokens()
    var mode by rememberSaveable { mutableStateOf(ForecastMode.Pace.name) }
    var minutes by rememberSaveable { mutableIntStateOf(30) }
    var finishBy by rememberSaveable { mutableStateOf(FinishBy.Month.name) }
    val by = FinishBy.valueOf(finishBy)
    val m = ForecastMode.valueOf(mode)
    val rows = f.books

    InsightCard("When you'll finish: ${rows.size} ${if (rows.size == 1) "book" else "books"}.", null) {
        CardHead("When you'll finish", when (m) {
            ForecastMode.Pace -> "at your pace"
            ForecastMode.Minutes -> "reading every day"
            ForecastMode.By -> "reading every day"
        })
        Spacer(Modifier.height(12.dp))
        PbSegmented(ForecastMode.values().map { it.name to it.label }, mode, { mode = it })
        Spacer(Modifier.height(12.dp))

        if (m == ForecastMode.Minutes) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Text("A day", color = t.setSub, fontSize = 14.sp)
                Text(minutesText(minutes), color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            }
            PbSlider(
                value = minutes.toFloat(),
                onValueChange = { minutes = ((it / 5f).roundToInt() * 5).coerceIn(5, 180) },
                valueRange = 5f..180f,
                trackColor = t.ink.copy(alpha = 0.15f),
            )
            Spacer(Modifier.height(6.dp))
        }
        if (m == ForecastMode.By) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FinishBy.values().forEach { b -> TogglePill(b.label, b == by) { finishBy = b.name } }
            }
            Spacer(Modifier.height(10.dp))
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            rows.forEachIndexed { i, r ->
                val ac = FORECAST_ACCENTS[i % FORECAST_ACCENTS.size]
                var main: String? = null
                var sub: String? = null
                var tone = ac
                when (m) {
                    ForecastMode.Pace -> {
                        val likely = r.likelyDays
                        val fast = r.fastDays
                        val slow = r.slowDays
                        if (likely != null) {
                            main = finishDateText(today, likely)
                            sub = if (fast != null && slow != null && fast != slow) "${finishDateText(today, fast)} – ${finishDateText(today, slow)}" else inDaysText(likely)
                        }
                    }
                    ForecastMode.Minutes -> {
                        val days = daysAtMinutes(r.secondsLeft, minutes)
                        main = finishDateText(today, days)
                        sub = inDaysText(days)
                    }
                    ForecastMode.By -> {
                        val days = by.days(today)
                        val need = minutesPerDayToFinish(r.secondsLeft, days)
                        main = "${minutesText(need)} a day"
                        sub = "by ${finishDateText(today, days)}"
                        if (need > 180) tone = DashAccent.Pink
                    }
                }
                val mainText: String? = main
                val subText: String? = sub
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .semantics(mergeDescendants = true) { contentDescription = "${r.book.title}. ${mainText ?: ""} ${subText ?: ""}. Open book details." }
                        .clickable(onClickLabel = "Open book", role = Role.Button) { links.book(r.book.id) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BookCover(r.book, Modifier.width(42.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.book.title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${commas(r.pagesLeft)} ${if (r.pagesLeft == 1) "page" else "pages"} left · ${minText(r.secondsLeft)} of reading",
                            color = t.setSub,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                        )
                    }
                    if (mainText != null) {
                        Spacer(Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                mainText,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(tone.copy(alpha = 0.14f))
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                color = inkOf(tone),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                            )
                            if (subText != null) {
                                Text(subText, modifier = Modifier.padding(top = 2.dp, end = 4.dp), color = t.setSub, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        Text(
            when (m) {
                ForecastMode.Pace ->
                    if (f.pattern == null) "Read on a few more days and a range shows up here."
                    else "The first date is a quick stretch, the last a slow one: the best and the slowest quarter of the days you read in the last 60 days, and how often you read."
                ForecastMode.Minutes -> "Move the slider: every book shows when you would finish at that many minutes every day."
                ForecastMode.By -> "The minutes you would need every day, from today, to finish by then. Pink is more than three hours a day."
            },
            modifier = Modifier.padding(top = 10.dp),
            color = t.setSub,
            fontSize = 12.sp,
            lineHeight = 17.sp,
        )
    }
}

// ---- the year -------------------------------------------------------------------------------

@Composable
private fun YearCard(y: YearPace, need: GoalNeed, onOpen: (() -> Unit)?) {
    val t = pbTokens()
    val mint = DashAccent.Cyan
    val mark = minOf(100f, (y.expected.toFloat() / max(1, y.goal)) * 100f)
    InsightCard("Books in ${y.year}: ${y.finished} of ${y.goal}.${if (onOpen != null) " Show the books." else ""}", onOpen) {
        CardHead("Books in ${y.year}", "goal ${y.goal}")
        Spacer(Modifier.height(14.dp))
        NumberUnit("${y.finished}", "of ${y.goal}", inkOf(mint))
        Spacer(Modifier.height(10.dp))
        YearBar(minOf(1f, y.finished.toFloat() / max(1, y.goal)), mark / 100f, mint)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                if (y.finished >= y.expected) "On pace or ahead" else "${y.expected - y.finished} behind the line",
                color = t.setSub, fontSize = 14.sp,
            )
            Text(
                if (y.projected > 0) "${y.projected} by December at this rate" else "",
                color = t.setSub, fontSize = 14.sp,
            )
        }
        // what the rest of the year asks for
        if (need.booksLeft > 0 && need.everyDays != null && need.perMonth != null) {
            Text(
                "To reach ${y.goal} you need ${if (need.booksLeft == 1) "1 more book" else "${need.booksLeft} more books"}: " +
                    "one every ${need.everyDays} ${if (need.everyDays == 1) "day" else "days"}, about ${"%.1f".format(need.perMonth)} a month.",
                modifier = Modifier.padding(top = 8.dp), color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp,
            )
        }
    }
}

/** The books-so-far bar with a dotted mark where a straight line through the year would be today. */
@Composable
internal fun YearBar(fraction: Float, mark: Float, color: Color) {
    val track = trackColor()
    val dots = pbTokens().setSub
    Canvas(Modifier.fillMaxWidth().height(26.dp)) {
        val h = 10.dp.toPx()
        val top = (size.height - h) / 2f
        val r = CornerRadius(h / 2f)
        drawRoundRect(track, topLeft = Offset(0f, top), size = Size(size.width, h), cornerRadius = r)
        val w = max(h, size.width * fraction.coerceIn(0f, 1f)).coerceAtMost(size.width)
        drawRoundRect(color, topLeft = Offset(0f, top), size = Size(w, h), cornerRadius = r)
        val x = (size.width * mark.coerceIn(0f, 1f)).coerceIn(2.dp.toPx(), size.width - 2.dp.toPx())
        for (k in -1..1) drawCircle(dots, radius = 1.6.dp.toPx(), center = Offset(x, size.height / 2f + k * 7.dp.toPx()))
    }
}
