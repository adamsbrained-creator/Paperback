package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.Similar
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

/**
 * "Pick my next read": one tap on the button shows the book of your library that [Similar.pickNext] ranks
 * first, with the reason; "Another" moves on to the next best, and "Close" folds it away again.
 */
@Composable
fun NextReadPicker(picks: List<Similar.NextPick>, onRead: (Book) -> Unit, onDetails: (Book) -> Unit) {
    if (picks.isEmpty()) return
    var index by remember(picks.size, picks.first().book.id) { mutableIntStateOf(-1) }
    if (index < 0) {
        PbButton("Pick my next read", onClick = { index = 0 }, ghost = true)
        return
    }
    val t = pbTokens()
    val pick = picks[index % picks.size]
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Eyebrow("Try this next", Modifier.weight(1f))
            if (picks.size > 1) PickAction("Another") { index = (index + 1) % picks.size }
            PickAction("Close") { index = -1 }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth()) {
            BookCover(pick.book, Modifier.width(84.dp).clickable { onDetails(pick.book) })
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    pick.book.title,
                    modifier = Modifier.clickable { onDetails(pick.book) },
                    color = t.ink,
                    fontFamily = PbSerif,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                if (pick.book.author.isNotBlank()) {
                    Text(pick.book.author, color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.height(6.dp))
                Text(pick.why, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, fontStyle = FontStyle.Italic, lineHeight = 18.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        PbButton("Start reading", onClick = { onRead(pick.book) })
    }
}

@Composable
private fun PickAction(text: String, onClick: () -> Unit) {
    Text(
        text,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp),
        color = MaterialTheme.colorScheme.primary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
    )
}
