package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.theme.pbTokens

private val RingCoral = Color(0xFFF2674A)

/**
 * The frame every screen opened from the menu shares (Shell + PageHeader in the TypeScript app): the header in
 * the chosen size, then the content, with room at the bottom for the round menu button. Content is at most
 * 560 dp wide and 20 dp from the edges, like `.pb-set-wrap`.
 */
@Composable
fun PbPage(
    label: String,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier,
    headerGap: Dp = 0.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, bottom = 112.dp),
        ) {
            PageHeader(label = label, size = headerSize, onMenu = onMenu, onSearch = onSearch)
            if (headerGap > 0.dp) Spacer(Modifier.height(headerGap))
            content()
        }
    }
}

class SetRowDef(val icon: PbIconName, val title: String, val value: String? = null, val onClick: () -> Unit)

/** A group of settings rows in one rounded card, with an optional small caps label above it. */
@Composable
fun SetGroup(label: String?, rows: List<SetRowDef>) {
    val t = pbTokens()
    if (label != null) {
        Text(
            label,
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 24.dp),
            color = t.setSub,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.14.em,
        )
    }
    Column(
        Modifier
            .padding(top = if (label != null) 10.dp else 24.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(t.card),
    ) {
        rows.forEachIndexed { i, r ->
            if (i > 0) {
                Box(Modifier.padding(start = 70.dp, end = 16.dp).fillMaxWidth().height(1.dp).background(t.rule))
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clickable(onClick = r.onClick)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(
                    Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(t.bg),
                    contentAlignment = Alignment.Center,
                ) { PbIcon(r.icon, size = 22.dp, tint = t.ink) }
                Text(
                    r.title,
                    modifier = Modifier.weight(1f),
                    color = t.ink,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (r.value != null) {
                    Text(r.value, color = t.setSub, fontSize = 14.sp, maxLines = 1)
                }
                PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub, strokeWidth = 2f)
            }
        }
    }
}

/** Daily goal: ring, "12 of 30 min today" and Edit (the dark card at the top of Settings). */
@Composable
fun GoalCard(secondsToday: Long, goalMinutes: Int, onEdit: () -> Unit) {
    val t = pbTokens()
    val minutes = (secondsToday / 60L).toInt()
    val fraction = (secondsToday / 60f / goalMinutes).coerceIn(0f, 1f)
    val pct = Math.round(fraction * 100f)
    Row(
        Modifier
            .padding(top = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(t.goalCard)
            .padding(start = 18.dp, top = 16.dp, end = 16.dp, bottom = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(56.dp)) {
                val k = this.size.width / 56f
                drawCircle(Color(0xFF3A3A3A), radius = 23f * k, center = Offset(28f * k, 28f * k), style = Stroke(width = 7f * k))
                if (pct > 0) {
                    drawArc(
                        color = RingCoral,
                        startAngle = -90f,
                        sweepAngle = 360f * fraction,
                        useCenter = false,
                        topLeft = Offset(5f * k, 5f * k),
                        size = Size(46f * k, 46f * k),
                        style = Stroke(width = 7f * k, cap = StrokeCap.Round),
                    )
                } else {
                    drawCircle(RingCoral, radius = 4.5f * k, center = Offset(28f * k, 5f * k))
                }
            }
            Text("$pct%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f)) {
            Text("Daily goal", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text("$minutes of $goalMinutes min today", color = Color(0xFFC4C4C4), fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Box(
            Modifier
                .height(40.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .clickable(onClick = onEdit)
                .padding(horizontal = 18.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("Edit", color = Color(0xFF161616), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Settings (app/(paperback)/settings/page.tsx): daily goal card, then Reading, Look and Library rows, then About. */
@Composable
fun SettingsScreen(
    headerSize: HeaderSize,
    secondsToday: Long,
    goalMinutes: Int,
    readerValue: String,
    appearanceValue: String,
    navLabel: String,
    version: String,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpen: (Dest) -> Unit,
) {
    val reading = listOf(
        SetRowDef(PbIconName.Goals, "Reading goals", "$goalMinutes min a day") { onOpen(Dest.Goals) },
        SetRowDef(PbIconName.Stats, "Reading stats") { onOpen(Dest.Stats) },
        SetRowDef(PbIconName.Reader, "Reader defaults", readerValue) { onOpen(Dest.ReaderDefaults) },
    )
    val look = listOf(
        SetRowDef(PbIconName.Theme, "Appearance", appearanceValue) { onOpen(Dest.Appearance) },
        SetRowDef(PbIconName.AppStyle, "App style", "Header: ${headerSize.label} · $navLabel") { onOpen(Dest.AppStyle) },
    )
    val library = listOf(
        SetRowDef(PbIconName.Library, "Library & import", "Import") { onOpen(Dest.Import) },
        SetRowDef(PbIconName.Backup, "Backup & restore") { onOpen(Dest.Backup) },
    )
    val about = listOf(SetRowDef(PbIconName.About, "About Paperback", version) { onOpen(Dest.About) })

    PbPage(label = "Settings", headerSize = headerSize, onMenu = onMenu, onSearch = onSearch) {
        GoalCard(secondsToday, goalMinutes) { onOpen(Dest.Goals) }
        SetGroup("READING", reading)
        SetGroup("LOOK", look)
        SetGroup("LIBRARY", library)
        SetGroup(null, about)
    }
}
