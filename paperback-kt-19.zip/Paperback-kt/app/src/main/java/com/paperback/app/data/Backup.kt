package com.paperback.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** What a backup file holds, as shown on the Backup & restore screen. */
data class BackupCounts(val books: Int, val bookmarks: Int, val highlights: Int, val sessions: Int, val collections: Int = 0) {
    fun describe(): String {
        fun n(count: Int, one: String, many: String) = "$count ${if (count == 1) one else many}"
        return listOf(
            n(books, "book", "books"),
            n(bookmarks, "bookmark", "bookmarks"),
            n(highlights, "highlight", "highlights"),
            n(sessions, "reading session", "reading sessions"),
            n(collections, "collection", "collections"),
        ).joinToString(", ")
    }
}

/** A backup file that was read and checked, waiting for the person to confirm the restore. */
data class PendingBackup(val json: String, val exportedAt: String, val counts: BackupCounts)

/**
 * Backup of everything Paperback adds to your books: progress, favorites, ratings, bookmarks, highlights,
 * notes, reading history, goals and look. The book files themselves are not inside; books are matched by
 * their hash, so a restore fills in the ones that are in your library.
 */
object Backup {
    private const val APP = "paperback"
    private const val VERSION = 1

    fun filename(today: LocalDate = LocalDate.now()): String =
        "paperback-backup-" + today.format(DateTimeFormatter.ISO_LOCAL_DATE) + ".json"

    fun currentCounts(db: PaperbackDb): BackupCounts {
        val books = db.allBooks()
        return BackupCounts(
            books = books.size,
            bookmarks = books.sumOf { db.bookmarksFor(it.id).size },
            highlights = books.sumOf { db.highlightsFor(it.id).size },
            sessions = db.allSessions().size,
            collections = db.allCollections().size,
        )
    }

    fun build(db: PaperbackDb, prefs: AppPrefs, reader: ReaderSettings): String {
        val root = JSONObject()
        root.put("app", APP)
        root.put("platform", "kotlin")
        root.put("version", VERSION)
        root.put("exportedAt", Instant.now().toString())

        val g = prefs.goals.value
        root.put(
            "goals",
            JSONObject()
                .put("booksPerYear", g.booksPerYear)
                .put("pagesPerDay", g.pagesPerDay)
                .put("minutesPerDay", g.minutesPerDay)
                .put("streakDays", g.streakDays),
        )
        root.put(
            "settings",
            JSONObject()
                .put("headerSize", prefs.headerSize.value.name)
                .put("navStyle", prefs.navStyle.value.name)
                .put("themeMode", prefs.themeMode.value.name)
                .put("readerFontSize", reader.fontSize)
                .put("readerTheme", reader.theme),
        )

        val books = db.allBooks()
        val booksJson = JSONArray()
        val bookmarksJson = JSONArray()
        val highlightsJson = JSONArray()
        for (b in books) {
            booksJson.put(
                JSONObject()
                    .put("id", b.id)
                    .put("title", b.title)
                    .put("author", b.author)
                    .put("favorite", b.favorite)
                    .put("finished", b.finished)
                    .put("rating", b.rating)
                    .put("progress", b.progress.toDouble())
                    .put("position", b.position)
                    .put("lastOpenedAt", b.lastOpenedAt)
                    .put("finishedAt", b.finishedAt)
                    .put("journal", b.journal)
                    .put("locator", b.locatorJson ?: JSONObject.NULL),
            )
            for (m in db.bookmarksFor(b.id)) {
                bookmarksJson.put(
                    JSONObject()
                        .put("id", m.id)
                        .put("bookId", m.bookId)
                        .put("locator", m.locatorJson)
                        .put("position", m.position)
                        .put("progress", m.progress.toDouble())
                        .put("createdAt", m.createdAt),
                )
            }
            for (h in db.highlightsFor(b.id)) {
                highlightsJson.put(
                    JSONObject()
                        .put("id", h.id)
                        .put("bookId", h.bookId)
                        .put("locator", h.locatorJson)
                        .put("text", h.text)
                        .put("note", h.note)
                        .put("color", h.color)
                        .put("progress", h.progress.toDouble())
                        .put("createdAt", h.createdAt),
                )
            }
        }
        root.put("books", booksJson)
        root.put("bookmarks", bookmarksJson)
        root.put("highlights", highlightsJson)

        val sessionsJson = JSONArray()
        for (s in db.allSessions()) {
            sessionsJson.put(
                JSONObject()
                    .put("bookId", s.bookId)
                    .put("startMs", s.startMs)
                    .put("seconds", s.seconds)
                    .put("pages", s.pages),
            )
        }
        root.put("sessions", sessionsJson)

        val members = db.collectionMembers()
        val collectionsJson = JSONArray()
        for (c in db.allCollections()) {
            collectionsJson.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name)
                    .put("createdAt", c.createdAt)
                    .put("books", JSONArray((members[c.id] ?: emptySet()).toList())),
            )
        }
        root.put("collections", collectionsJson)

        return root.toString(2)
    }

    /** Checks that [text] is a Paperback backup. Returns the pending restore, or an error message. */
    fun parse(text: String): Result<PendingBackup> = runCatching {
        val root = JSONObject(text)
        require(root.optString("app") == APP) { "That is not a Paperback backup file." }
        PendingBackup(
            json = text,
            exportedAt = root.optString("exportedAt", ""),
            counts = BackupCounts(
                books = root.optJSONArray("books")?.length() ?: 0,
                bookmarks = root.optJSONArray("bookmarks")?.length() ?: 0,
                highlights = root.optJSONArray("highlights")?.length() ?: 0,
                sessions = root.optJSONArray("sessions")?.length() ?: 0,
                collections = root.optJSONArray("collections")?.length() ?: 0,
            ),
        )
    }.recoverCatching { e ->
        throw IllegalArgumentException(
            if (e is IllegalArgumentException) e.message else "That file could not be read as a Paperback backup.",
        )
    }

    /** Applies a backup to the books that are in the library. Returns how many books were matched. */
    fun restore(pending: PendingBackup, db: PaperbackDb, prefs: AppPrefs, reader: ReaderSettings): Int {
        val root = JSONObject(pending.json)

        root.optJSONObject("goals")?.let { g ->
            val d = Goals.DEFAULT
            prefs.setGoals(
                Goals(
                    booksPerYear = g.optInt("booksPerYear", d.booksPerYear),
                    pagesPerDay = g.optInt("pagesPerDay", d.pagesPerDay),
                    minutesPerDay = g.optInt("minutesPerDay", d.minutesPerDay),
                    streakDays = g.optInt("streakDays", d.streakDays),
                ),
            )
        }
        root.optJSONObject("settings")?.let { s ->
            HeaderSize.values().firstOrNull { it.name == s.optString("headerSize") }?.let { prefs.setHeaderSize(it) }
            NavStyle.values().firstOrNull { it.name == s.optString("navStyle") }?.let { prefs.setNavStyle(it) }
            ThemeMode.values().firstOrNull { it.name == s.optString("themeMode") }?.let { prefs.setThemeMode(it) }
            if (s.has("readerFontSize")) reader.fontSize = s.optDouble("readerFontSize", reader.fontSize).coerceIn(0.6, 2.5)
            if (s.has("readerTheme")) reader.theme = s.optInt("readerTheme", reader.theme).coerceIn(0, 2)
        }

        val inLibrary = db.allBooks().associateBy { it.id }
        var matched = 0

        root.optJSONArray("books")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                val existing = inLibrary[id] ?: continue
                matched++
                db.setFlag(id, "favorite", o.optBoolean("favorite", existing.favorite))
                db.setFinished(id, o.optBoolean("finished", existing.finished))
                db.setRating(id, o.optInt("rating", existing.rating))
                if (o.has("journal")) db.setJournal(id, o.optString("journal", existing.journal))
                val locator = if (o.isNull("locator")) null else o.optString("locator").takeIf { it.isNotEmpty() }
                // Only move reading progress forward: a restore must never undo reading done since the backup.
                val progress = o.optDouble("progress", 0.0).toFloat()
                if (locator != null && progress > existing.progress) {
                    db.updateProgress(
                        id = id,
                        locatorJson = locator,
                        progress = progress,
                        position = o.optInt("position", existing.position),
                        openedAt = maxOf(existing.lastOpenedAt, o.optLong("lastOpenedAt", 0L)),
                    )
                }
            }
        }

        root.optJSONArray("bookmarks")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val bookId = o.optString("bookId")
                if (bookId !in inLibrary) continue
                db.insertBookmark(
                    Bookmark(
                        id = o.optString("id"),
                        bookId = bookId,
                        locatorJson = o.optString("locator"),
                        position = o.optInt("position", 0),
                        progress = o.optDouble("progress", 0.0).toFloat(),
                        createdAt = o.optLong("createdAt", 0L),
                    ),
                )
            }
        }

        root.optJSONArray("highlights")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val bookId = o.optString("bookId")
                if (bookId !in inLibrary) continue
                db.insertHighlight(
                    Highlight(
                        id = o.optString("id"),
                        bookId = bookId,
                        locatorJson = o.optString("locator"),
                        text = o.optString("text"),
                        note = o.optString("note"),
                        color = o.optInt("color", HighlightColors.DEFAULT),
                        progress = o.optDouble("progress", 0.0).toFloat(),
                        createdAt = o.optLong("createdAt", 0L),
                    ),
                )
            }
        }

        // Collections: created again if missing, with the books of the backup that are in the library.
        root.optJSONArray("collections")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id.isEmpty()) continue
                db.upsertCollection(BookCollection(id, o.optString("name"), o.optLong("createdAt", 0L)))
                o.optJSONArray("books")?.let { ids ->
                    for (j in 0 until ids.length()) {
                        val bookId = ids.optString(j)
                        if (bookId in inLibrary) db.setMember(id, bookId, true)
                    }
                }
            }
        }

        // Reading history is kept even for books that are no longer in the library, like the database does.
        // A session that is already stored (same book and start time) is not added twice.
        val have = db.allSessions().map { it.bookId to it.startMs }.toHashSet()
        root.optJSONArray("sessions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val bookId = o.optString("bookId")
                val startMs = o.optLong("startMs", 0L)
                if (bookId.isEmpty() || startMs <= 0L || (bookId to startMs) in have) continue
                db.insertSession(bookId, startMs, o.optInt("seconds", 0), o.optInt("pages", 0))
                have.add(bookId to startMs)
            }
        }

        return matched
    }

    /** "Made 22 Oct 2026" for the confirm card. */
    fun madeOn(exportedAt: String): String? = runCatching {
        val d = Instant.parse(exportedAt).atZone(ZoneId.systemDefault()).toLocalDate()
        d.format(DateTimeFormatter.ofPattern("d MMM yyyy"))
    }.getOrNull()
}
