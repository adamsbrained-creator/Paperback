package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Recommendation
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import java.time.LocalDate

@Composable
fun HomeScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    recommended: List<Recommendation>,
    goalMinutes: Int,
    onOpen: (Book) -> Unit,
    onDetails: (Book) -> Unit,
    onImport: () -> Unit,
    onDiscover: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val today = LocalDate.now()
    val byDay = remember(sessions) { Stats.secondsByDay(sessions) }
    val pace = remember(sessions) { Stats.paceSecondsPerPosition(sessions) }
    val todaySeconds = byDay[today] ?: 0L
    val streak = Stats.currentStreak(byDay, today)

    val next = remember(books) {
        books.filter { it.isReading }.maxByOrNull { it.lastOpenedAt } ?: books.firstOrNull { !it.finished }
    }
    val recent = remember(books, next) {
        books.filter { it.lastOpenedAt > 0 && it.id != next?.id }.sortedByDescending { it.lastOpenedAt }.take(10)
    }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Eyebrow("Continue reading")
        Spacer(Modifier.height(12.dp))

        if (next == null) {
            LibraryEmpty(onImport = onImport, onDiscover = onDiscover)
        } else {
            Row(Modifier.fillMaxWidth()) {
                BookCover(next, Modifier.width(132.dp).clickable { onOpen(next) })
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        next.title,
                        modifier = Modifier.clickable { onDetails(next) },
                        fontFamily = PbSerif,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (next.author.isNotBlank()) {
                        Text(next.author, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(14.dp))
                    if (next.position > 0 && next.totalPositions > 0) {
                        Text("Page ${next.position} of ${next.totalPositions}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    ProgressTrack(next.progress)
                    Spacer(Modifier.height(8.dp))
                    val left = Stats.timeLeftSeconds(next, pace)?.let { " · ${Stats.duration(it)} left" } ?: ""
                    Text("${next.percent}%$left", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            PbButton(if (next.isReading) "Resume reading" else "Start reading", onClick = { onOpen(next) })
        }

        Spacer(Modifier.height(28.dp))
        Eyebrow("Today")
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GoalRingTile(todaySeconds, goalMinutes, Modifier.weight(1.25f).fillMaxHeight())
            StatTile("Streak", if (streak == 1) "1 day" else "$streak days", Modifier.weight(1f).fillMaxHeight())
        }

        if (recent.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            Eyebrow("Recently read")
            Spacer(Modifier.height(12.dp))
            LazyRow(
                modifier = Modifier.fullBleed(20.dp),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Top,
            ) {
                items(recent, key = { it.id }) { b ->
                    BookCover(b, Modifier.width(96.dp).clickable { onOpen(b) })
                }
            }
        }

        if (recommended.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            Eyebrow("Recommended for you")
            Spacer(Modifier.height(12.dp))
            LazyRow(
                modifier = Modifier.fullBleed(20.dp),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Top,
            ) {
                items(recommended, key = { it.book.id }) { r ->
                    Column(Modifier.width(104.dp).clickable { onDetails(r.book) }) {
                        BookCover(r.book)
                        Spacer(Modifier.height(6.dp))
                        Text(r.book.title, fontSize = 12.sp, lineHeight = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            "Like ${r.because.title}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
