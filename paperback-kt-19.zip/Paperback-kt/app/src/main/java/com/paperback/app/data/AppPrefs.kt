package com.paperback.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Settings → App style → Header. The three sizes of the TypeScript app, plus one with the buttons and no wordmark. */
enum class HeaderSize(val label: String) {
    Compact("Compact"),
    Regular("Regular"),
    Large("Large"),
    Minimal("Buttons only"),
}

/** Settings → App style → Navigation. */
enum class NavStyle(val label: String) {
    Bar("Bar"),
    Clean("Clean"),
}

/** Settings → Appearance. */
enum class ThemeMode(val label: String) {
    System("Match system"),
    Light("Light"),
    Dark("Dark"),
}

/** Reading goals (port of app/stats/goals.ts). Anything that is not a sensible number falls back to the default. */
data class Goals(
    val booksPerYear: Int = 24,
    val pagesPerDay: Int = 30,
    val minutesPerDay: Int = 30,
    val streakDays: Int = 30,
) {
    fun normalized(): Goals = Goals(
        booksPerYear = sane(booksPerYear, DEFAULT.booksPerYear),
        pagesPerDay = sane(pagesPerDay, DEFAULT.pagesPerDay),
        minutesPerDay = sane(minutesPerDay, DEFAULT.minutesPerDay),
        streakDays = sane(streakDays, DEFAULT.streakDays),
    )

    companion object {
        val DEFAULT = Goals()
        private fun sane(v: Int, fallback: Int): Int = if (v in 1..99999) v else fallback
    }
}

/** The app's own choices (look and goals), kept on this device. Each one is a flow so screens update at once. */
class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("app", Context.MODE_PRIVATE)

    private val _headerSize = MutableStateFlow(
        HeaderSize.values().firstOrNull { it.name == sp.getString("headerSize", null) } ?: HeaderSize.Regular,
    )
    val headerSize: StateFlow<HeaderSize> = _headerSize.asStateFlow()

    fun setHeaderSize(value: HeaderSize) {
        _headerSize.value = value
        sp.edit().putString("headerSize", value.name).apply()
    }

    private val _navStyle = MutableStateFlow(
        NavStyle.values().firstOrNull { it.name == sp.getString("navStyle", null) } ?: NavStyle.Bar,
    )
    val navStyle: StateFlow<NavStyle> = _navStyle.asStateFlow()

    fun setNavStyle(value: NavStyle) {
        _navStyle.value = value
        sp.edit().putString("navStyle", value.name).apply()
    }

    private val _themeMode = MutableStateFlow(
        ThemeMode.values().firstOrNull { it.name == sp.getString("themeMode", null) } ?: ThemeMode.System,
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    fun setThemeMode(value: ThemeMode) {
        _themeMode.value = value
        sp.edit().putString("themeMode", value.name).apply()
    }

    private val _goals = MutableStateFlow(
        Goals(
            booksPerYear = sp.getInt("goalBooks", Goals.DEFAULT.booksPerYear),
            pagesPerDay = sp.getInt("goalPages", Goals.DEFAULT.pagesPerDay),
            minutesPerDay = sp.getInt("goalMinutes", Goals.DEFAULT.minutesPerDay),
            streakDays = sp.getInt("goalStreak", Goals.DEFAULT.streakDays),
        ).normalized(),
    )
    val goals: StateFlow<Goals> = _goals.asStateFlow()

    fun setGoals(value: Goals) {
        val g = value.normalized()
        _goals.value = g
        sp.edit()
            .putInt("goalBooks", g.booksPerYear)
            .putInt("goalPages", g.pagesPerDay)
            .putInt("goalMinutes", g.minutesPerDay)
            .putInt("goalStreak", g.streakDays)
            .apply()
    }
}
