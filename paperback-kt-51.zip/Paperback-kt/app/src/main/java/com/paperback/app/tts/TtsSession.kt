package com.paperback.app.tts

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.paperback.app.PaperbackApp
import com.paperback.app.reader.ReaderSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.readium.r2.shared.publication.Link
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.services.positions
import java.io.File
import java.net.URLDecoder
import java.nio.charset.Charset
import java.util.zip.ZipFile
import kotlin.coroutines.cancellation.CancellationException

/** The reader screen implements this so the read-aloud session can mark the spoken text and follow it with the page. */
interface TtsHost {
    /** True while the reader is on screen (then it counts the reading time itself). */
    val resumed: Boolean
    fun showHighlight(sentence: Locator?, word: Locator?)
    fun goTo(locator: Locator)
}

/**
 * Everything the session needs to know about the book, copied out of the Readium publication so that it keeps working
 * (lock screen, notification) after the reader screen has closed the publication.
 */
class TtsBook(
    val bookId: String,
    val title: String,
    val author: String,
    val filePath: String,
    val coverPath: String?,
    val language: String,
    /** One locator per file of the reading order (href, media type). */
    val resources: List<Locator>,
    /** The contents entry that each file falls under ("" when the book has none). */
    val chapterTitles: List<String>,
    /** Readium's reading positions, grouped by file, in order. */
    val positionsByResource: List<List<Locator>>,
) {
    val hrefs: List<String> = resources.map { it.href.toString().substringBefore('#') }
}

enum class LoopState { Off, A, B }

/** How far a chapter's offline audio has got. */
class DownloadState(val done: Int, val total: Int, val running: Boolean) {
    val complete: Boolean get() = total > 0 && done >= total
}

class VoiceGroup(val id: String, val name: String, val voices: List<TtsVoice>)

/** The sleep timer's "stop when the chapter ends" value, same as TTS_STOP_AT_CHAPTER_END in the TypeScript app. */
const val SLEEP_END_OF_CHAPTER = -1

/**
 * Reading a book aloud. One session exists at a time ([TtsHub.session]); it lives in the app, not in the reader screen, so the
 * voice keeps going with the screen off, and the reader can come and go ([attach] / [detach]).
 *
 * The TypeScript app's TTSController did this with foliate marks and a Web Audio pipeline. Here the book's text is cut into
 * sentences ([TtsHtml]), each sentence is said by a [Speaker] (Edge voices over the internet, or the phone's own voice), and the
 * sentence being said is drawn on the page with a Readium decoration.
 */
class TtsSession(private val app: Application, val book: TtsBook, val prefs: TtsPrefs) {
    private val graph get() = (app as PaperbackApp).graph
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val cache = TtsAudioCache(app)
    private var host: TtsHost? = null

    // ---- what the screens show ----------------------------------------------------------------------

    var active by mutableStateOf(false)
        private set
    var playing by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var sheetOpen by mutableStateOf(false)
    var chapterIndex by mutableIntStateOf(0)
        private set
    var sentenceIndex by mutableIntStateOf(0)
        private set

    /** The sentences of the chapter being read, as shown in the sentence view. */
    var lines by mutableStateOf<List<String>>(emptyList())
        private set
    var chapterTitle by mutableStateOf("")
        private set
    var voice by mutableStateOf<TtsVoice?>(null)
        private set
    var sleepOption by mutableIntStateOf(0)
        private set
    var sleepFiresAt by mutableLongStateOf(0L)
        private set
    var loopState by mutableStateOf(LoopState.Off)
        private set
    var loopA by mutableIntStateOf(-1)
        private set
    var loopB by mutableIntStateOf(-1)
        private set

    /** False after you turn pages yourself: the page stays where it is until "Back to Read Aloud". */
    var following by mutableStateOf(true)
        private set
    var notice by mutableStateOf<String?>(null)
        private set
    var systemVoices by mutableStateOf<List<TtsVoice>>(emptyList())
        private set
    val downloads = mutableStateMapOf<Int, DownloadState>()
    var downloadRows by mutableStateOf<List<Pair<Int, String>>>(emptyList())
        private set

    val rate: Float get() = prefs.rate

    /** The language the book is in (two letters, or with region), from the book or, failing that, from its alphabet. */
    var lang: String = TtsPrefs.lang2(book.language)
        private set

    private var cumulative: IntArray = IntArray(1)
    private var paragraphOf: IntArray = IntArray(0)

    // ---- engines ------------------------------------------------------------------------------------

    private val edgeLazy = lazy { EdgeSpeaker(cache, { prefs.cacheEnabled }, { prefs.cacheBudgetMb }) }
    private val systemLazy = lazy { SystemSpeaker(app) }
    private val edge: EdgeSpeaker by edgeLazy
    private val system: SystemSpeaker by systemLazy
    private val speaker: Speaker get() = if (voice?.id?.startsWith(SYSTEM_PREFIX) == true) system else edge

    private var loopJob: Job? = null
    private var sleepJob: Job? = null
    private var downloadJob: Job? = null
    private var noticeJob: Job? = null
    private val chapterCache = object : LinkedHashMap<Int, TtsChapter>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, TtsChapter>?) = size > 6
    }
    private var currentChapter: TtsChapter? = null
    private var wordCursor = 0
    private var lastSaved = 0L
    private var failures = 0

    // ---- reading time while the reader is not on screen ----------------------------------------------

    private var tickAt = 0L
    private var backgroundMs = 0L
    private var backgroundStart = 0L
    private var firstPosition = -1
    private var lastPosition = -1

    // ---- audio focus ---------------------------------------------------------------------------------

    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusRequest: AudioFocusRequest? = null
    private var resumeOnFocus = false
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> { resumeOnFocus = false; pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { resumeOnFocus = playing; pause() }
            AudioManager.AUDIOFOCUS_GAIN -> if (resumeOnFocus) { resumeOnFocus = false; play() }
        }
    }

    init {
        voice = defaultVoice()
    }

    // ---- connecting the reader screen -----------------------------------------------------------------

    fun attach(h: TtsHost) {
        host = h
        flushBackground()
        if (active) {
            val s = currentSentence()
            if (s != null) publishHighlight(s, null, follow = following)
        }
    }

    fun detach(h: TtsHost) {
        if (host === h) host = null
    }

    /** The reader noticed the person moved the page themselves. */
    fun userMovedPage() {
        if (active && following) following = false
    }

    fun followAgain() {
        following = true
        currentSentence()?.let { publishHighlight(it, null, follow = true) }
    }

    // ---- starting and stopping -------------------------------------------------------------------------

    /** Begins reading aloud from the page the reader shows ([from]). */
    fun start(from: Locator?) {
        if (active) {
            sheetOpen = true
            return
        }
        active = true
        playing = true
        following = true
        TtsService.start(app)
        requestFocus()
        scope.launch {
            val href = from?.href?.toString()?.substringBefore('#')
            var ch = href?.let { book.hrefs.indexOf(it) } ?: -1
            if (ch < 0) ch = 0
            val progression = from?.locations?.progression ?: 0.0
            detectLanguage(ch)
            val chapter = loadChapter(ch)
            var idx = chapter?.sentences?.indexOfFirst { it.progression >= progression - 0.0004 } ?: 0
            if (idx < 0) idx = chapter?.sentences?.size ?: 0
            chapterIndex = ch
            sentenceIndex = idx
            tickAt = System.currentTimeMillis()
            startLoop()
        }
    }

    fun play() {
        if (!active) return
        if (!playing) {
            playing = true
            requestFocus()
            tickAt = System.currentTimeMillis()
            speaker.resume()
            changed()
        }
    }

    fun pause() {
        if (!active || !playing) return
        tick()
        playing = false
        speaker.pause()
        flushBackground()
        changed()
    }

    fun togglePlay() = if (playing) pause() else play()

    /** Ends the session: the mini player, the notification and the voice all go away. */
    fun stop() {
        if (!active && loopJob == null) return
        tick()
        flushBackground()
        loopJob?.cancel()
        sleepJob?.cancel()
        downloadJob?.cancel()
        active = false
        playing = false
        buffering = false
        sheetOpen = false
        if (edgeLazy.isInitialized()) runCatching { edge.release() }
        if (systemLazy.isInitialized()) runCatching { system.release() }
        abandonFocus()
        host?.showHighlight(null, null)
        TtsService.stop(app)
        if (TtsHub.session === this) TtsHub.session = null
    }

    // ---- moving around ----------------------------------------------------------------------------------

    fun stepSentence(delta: Int) {
        val ch = currentChapter ?: return
        var c = chapterIndex
        var i = sentenceIndex + delta
        scope.launch {
            if (i < 0) {
                var prev = c - 1
                while (prev >= 0 && (loadChapter(prev)?.sentences?.isEmpty() != false)) prev--
                if (prev < 0) i = 0 else { c = prev; i = loadChapter(prev)!!.sentences.size - 1 }
            } else if (i >= ch.sentences.size) {
                var next = c + 1
                while (next < book.resources.size && (loadChapter(next)?.sentences?.isEmpty() != false)) next++
                if (next >= book.resources.size) return@launch
                c = next
                i = 0
            }
            jumpTo(c, i)
        }
    }

    /** Previous or next paragraph: the first sentence of it. */
    fun stepParagraph(delta: Int) {
        val ch = currentChapter ?: return
        val s = ch.sentences.getOrNull(sentenceIndex) ?: return
        if (delta > 0) {
            val next = ch.sentences.indexOfFirst { it.paragraph > s.paragraph }
            if (next >= 0) jumpTo(chapterIndex, next) else stepSentence(1)
        } else {
            val startOfThis = ch.sentences.indexOfFirst { it.paragraph == s.paragraph }
            if (startOfThis < sentenceIndex) {
                jumpTo(chapterIndex, startOfThis)
            } else if (startOfThis > 0) {
                val prevPara = ch.sentences[startOfThis - 1].paragraph
                jumpTo(chapterIndex, ch.sentences.indexOfFirst { it.paragraph == prevPara })
            } else {
                stepSentence(-1)
            }
        }
    }

    fun playFrom(index: Int) {
        val ch = currentChapter ?: return
        if (index in ch.sentences.indices) {
            if (!playing) play()
            jumpTo(chapterIndex, index)
        }
    }

    /** The scrubber: [fraction] of the chapter, by text length. */
    fun seekFraction(fraction: Float) {
        val ch = currentChapter ?: return
        if (ch.sentences.isEmpty()) return
        val target = (cumulative.last() * fraction.coerceIn(0f, 1f)).toInt()
        var idx = cumulative.indexOfLast { it <= target }.coerceIn(0, ch.sentences.size - 1)
        if (idx < 0) idx = 0
        jumpTo(chapterIndex, idx)
    }

    private fun jumpTo(chapter: Int, sentence: Int) {
        loopJob?.cancel()
        if (chapter != chapterIndex) clearLoop()
        chapterIndex = chapter
        sentenceIndex = sentence
        if (active) startLoop()
    }

    // ---- speed, voice, timer, repeat ----------------------------------------------------------------------

    fun setRate(r: Float) {
        prefs.setRate(r)
        speaker.setRate(prefs.rate)
        changed()
    }

    @JvmName("applyVoice")

    fun setVoice(v: TtsVoice) {
        prefs.setVoiceFor(lang, v.id)
        val old = speaker
        voice = v
        failures = 0
        if (active) jumpTo(chapterIndex, sentenceIndex) // stops what the old voice was saying
        if (old !== speaker) old.resume() // clear its "paused" state, so it is fresh when it is chosen again
        if (!playing) speaker.pause()
        refreshDownloads()
    }

    fun setSleep(option: Int) {
        sleepJob?.cancel()
        sleepOption = option
        sleepFiresAt = 0L
        if (option > 0) {
            sleepFiresAt = System.currentTimeMillis() + option * 1000L
            sleepJob = scope.launch {
                delay(option * 1000L)
                sleepOption = 0
                sleepFiresAt = 0L
                pause()
                say("Sleep timer: paused.")
            }
        }
    }

    fun toggleLoop() {
        when (loopState) {
            LoopState.Off -> { loopA = sentenceIndex; loopB = -1; loopState = LoopState.A }
            LoopState.A -> {
                loopB = sentenceIndex
                if (loopB < loopA) { val t = loopA; loopA = loopB; loopB = t }
                loopState = LoopState.B
            }
            LoopState.B -> clearLoop()
        }
    }

    private fun clearLoop() {
        loopState = LoopState.Off
        loopA = -1
        loopB = -1
    }

    /** The sentences between A and B, for marking them in the sentence view. */
    fun loopRange(): IntRange? = if (loopState == LoopState.B && loopA >= 0 && loopB >= loopA) loopA..loopB else null

    // ---- time -------------------------------------------------------------------------------------------

    private fun charsPerSecond(): Double = when (lang) {
        "zh" -> 4.5
        "ja" -> 6.5
        "ko" -> 5.5
        "ru", "uk", "bg", "pl", "cs", "sk" -> 14.0
        "de", "fi", "hu" -> 13.0
        else -> 15.0
    }

    /** Seconds spoken so far in this chapter and the chapter's total, at the current speed (an estimate from the text length). */
    fun timeInfo(): Pair<Int, Int> {
        val cps = charsPerSecond() * rate.coerceAtLeast(0.1f)
        val total = (cumulative.last() / cps).toInt()
        val at = (cumulative.getOrElse(sentenceIndex.coerceAtLeast(0)) { cumulative.last() } / cps).toInt()
        return at to total
    }

    // ---- the reading loop -----------------------------------------------------------------------------------

    private fun startLoop() {
        loopJob?.cancel()
        loopJob = scope.launch { runLoop() }
    }

    private suspend fun runLoop() {
        while (currentCoroutineContext().isActive) {
            val ch = loadChapter(chapterIndex)
            if (ch == null) {
                finished()
                return
            }
            showChapter(ch)
            if (sentenceIndex !in ch.sentences.indices) {
                // the end of this file (or an empty one): on to the next
                if (chapterIndex + 1 >= book.resources.size) {
                    finished()
                    return
                }
                chapterIndex++
                sentenceIndex = 0
                clearLoop()
                if (sleepOption == SLEEP_END_OF_CHAPTER) {
                    sleepOption = 0
                    pause()
                    say("Sleep timer: paused at the end of the chapter.")
                }
                continue
            }
            val s = ch.sentences[sentenceIndex]
            val v = voice ?: return
            tick()
            publishSentence(ch, s)
            val req = SpeakRequest(s.text, v.lang, v)
            if (v.id.startsWith(SYSTEM_PREFIX).not()) {
                edge.prefetch((1..3).mapNotNull { n -> ch.sentences.getOrNull(sentenceIndex + n) }.map { SpeakRequest(it.text, v.lang, v) } + req)
            }
            buffering = true
            try {
                speaker.speak(req, prefs.rate, onStart = { buffering = false }, onWord = { span -> onWord(s, req, span) })
                failures = 0
            } catch (e: CancellationException) {
                throw e
            } catch (e: SpeakException) {
                buffering = false
                if (!e.permanent) {
                    failures++
                    if (!recover(e)) return
                    continue
                }
            }
            buffering = false
            val last = sentenceIndex
            advance(ch)
            if (prefs.pauseAfterSentence && playing) pause()
            val paragraphEnds = ch.sentences.getOrNull(last + 1)?.paragraph != s.paragraph
            val gap = ((if (paragraphEnds) 300f else 150f) / rate.coerceAtLeast(0.5f)).toLong()
            if (v.id.startsWith(SYSTEM_PREFIX)) delay(gap / 2) else delay(gap)
        }
    }

    private fun advance(ch: TtsChapter) {
        if (loopState == LoopState.B && sentenceIndex == loopB) sentenceIndex = loopA else sentenceIndex++
    }

    /** A sentence could not be said: after a couple of failures an Edge voice gives way to the phone's own voice. False ends the loop. */
    private suspend fun recover(e: SpeakException): Boolean {
        val v = voice ?: return false
        val isEdge = !v.id.startsWith(SYSTEM_PREFIX)
        if (isEdge && failures >= 2) {
            system.ensure()
            if (systemVoices.isEmpty()) systemVoices = system.voices(lang)
            val fallback = systemVoices.firstOrNull() ?: TtsVoice(SYSTEM_PREFIX + "default", "Phone voice", lang, null, true)
            voice = fallback
            failures = 0
            edge.prefetch(emptyList())
            if (!playing) system.pause()
            say("Edge voices need internet. Using the phone's voice for now.")
            return true
        }
        if (failures >= 4) {
            say(e.message ?: "The voice stopped.")
            failures = 0
            pause()
            return true
        }
        delay(600)
        return true
    }

    private fun finished() {
        say("Reached the end of the book.")
        stop()
    }

    private fun onWord(s: TtsSentence, req: SpeakRequest, span: WordSpan) {
        if (prefs.granularity != "word") return
        val end = span.end.coerceAtMost(req.text.length)
        if (span.start < 0 || span.start >= end) return
        val word = req.text.substring(span.start, end)
        val at = TtsAlign.findInQuote(s.quote, word, wordCursor)
        if (at < 0) return
        wordCursor = at + word.trim().length
        val ch = currentChapter ?: return
        val sentenceLoc = sentenceLocator(ch.index, s, s.quote, s.before, s.after)
        val wordLoc = sentenceLocator(
            ch.index, s, word.trim(),
            (s.before + s.quote.substring(0, at)).takeLast(40),
            (s.quote.substring(at + word.trim().length) + s.after).take(40),
        )
        host?.showHighlight(sentenceLoc, wordLoc)
    }

    private fun currentSentence(): TtsSentence? = currentChapter?.sentences?.getOrNull(sentenceIndex)

    private var shownKey = -1L

    private fun publishSentence(ch: TtsChapter, s: TtsSentence) {
        wordCursor = 0
        publishHighlight(s, null, follow = following)
        savePosition(ch, s)
        // the lock screen / notification text follows the "update frequency" setting
        val part = when (prefs.mediaMetadata) {
            "sentence" -> sentenceIndex.toLong()
            "paragraph" -> s.paragraph.toLong()
            else -> 0L
        }
        val key = ch.index * 1_000_000L + part
        if (key != shownKey) {
            shownKey = key
            changed()
        }
    }

    private fun publishHighlight(s: TtsSentence, word: Locator?, follow: Boolean) {
        val ch = currentChapter ?: return
        val loc = sentenceLocator(ch.index, s, s.quote, s.before, s.after)
        host?.showHighlight(loc, word)
        if (follow) host?.goTo(loc)
    }

    private fun sentenceLocator(resource: Int, s: TtsSentence, quote: String, before: String, after: String): Locator {
        val base = book.resources[resource]
        return base.copy(
            locations = base.locations.copy(progression = s.progression),
            text = Locator.Text(before = before, highlight = quote, after = after),
        )
    }

    /** The reading position (Readium's own, so the book's progress and page counter follow along). */
    private fun positionLocator(resource: Int, progression: Double): Locator? {
        val list = book.positionsByResource.getOrNull(resource)?.takeIf { it.isNotEmpty() } ?: return null
        return list[(progression * list.size).toInt().coerceIn(0, list.size - 1)]
    }

    private fun savePosition(ch: TtsChapter, s: TtsSentence) {
        val loc = positionLocator(ch.index, s.progression) ?: return
        val pos = loc.locations.position ?: 0
        if (firstPosition < 0) firstPosition = pos
        lastPosition = pos
        val now = System.currentTimeMillis()
        // The reader saves its own place while you are looking at it; here we only keep the book's place when you are not.
        if (now - lastSaved < 3000L) return
        if (host?.resumed == true) return
        lastSaved = now
        graph.appScope.launch { graph.repo.saveProgress(book.bookId, loc) }
    }

    private fun showChapter(ch: TtsChapter) {
        if (currentChapter === ch) return
        currentChapter = ch
        lines = ch.sentences.map { it.quote.replace(Regex("\\s+"), " ") }
        chapterTitle = book.chapterTitles.getOrNull(ch.index).orEmpty().ifBlank { "Section ${ch.index + 1}" }
        val cum = IntArray(ch.sentences.size + 1)
        for (i in ch.sentences.indices) cum[i + 1] = cum[i] + ch.sentences[i].text.length
        cumulative = cum
    }

    // ---- reading time in the background -------------------------------------------------------------------

    /** Adds the time since the last tick to the background total, when the reader is not on screen. */
    private fun tick() {
        val now = System.currentTimeMillis()
        if (playing && tickAt > 0L && host?.resumed != true) {
            if (backgroundMs == 0L) backgroundStart = tickAt
            backgroundMs += (now - tickAt).coerceIn(0L, 120_000L)
        }
        tickAt = now
    }

    /** Saves listening done while the reader was closed or off screen as a reading session (the reader counts its own). */
    private fun flushBackground() {
        val seconds = (backgroundMs / 1000L).toInt()
        if (seconds >= 5) {
            val from = firstPosition.coerceAtLeast(0)
            val to = lastPosition.coerceAtLeast(from)
            val start = backgroundStart
            graph.appScope.launch { graph.repo.addSession(book.bookId, start, seconds, (to - from).coerceIn(0, 400), from, to) }
        }
        backgroundMs = 0L
        backgroundStart = 0L
        firstPosition = -1
        lastPosition = -1
    }

    // ---- loading text -----------------------------------------------------------------------------------------

    /** Reads and cuts one file of the book. Null when [index] is past the last file. */
    suspend fun loadChapter(index: Int): TtsChapter? {
        if (index < 0 || index >= book.resources.size) return null
        chapterCache[index]?.let { return it }
        val parsed = withContext(Dispatchers.Default) {
            val html = readEntry(book.hrefs[index])
            TtsHtml.chapter(index, book.hrefs[index], html ?: "")
        }
        chapterCache[index] = parsed
        return parsed
    }

    private fun readEntry(href: String): String? = runCatching {
        ZipFile(File(book.filePath)).use { zip ->
            val wanted = decode(href).trimStart('/')
            val names = zip.entries().asSequence().map { it.name }.toList()
            val name = names.firstOrNull { it == wanted }
                ?: names.firstOrNull { it.endsWith("/$wanted") }
                ?: names.firstOrNull { wanted.endsWith("/$it") }
                ?: return@use null
            val bytes = zip.getInputStream(zip.getEntry(name)).use { it.readBytes() }
            val head = String(bytes, 0, minOf(bytes.size, 200), Charsets.ISO_8859_1)
            val declared = Regex("encoding=[\"']([A-Za-z0-9_\\-]+)[\"']").find(head)?.groupValues?.get(1)
            val cs = runCatching { Charset.forName(declared ?: "UTF-8") }.getOrDefault(Charsets.UTF_8)
            String(bytes, cs)
        }
    }.getOrNull()

    private fun decode(s: String): String = runCatching { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") }.getOrDefault(s)

    private suspend fun detectLanguage(startChapter: Int) {
        if (book.language.isNotBlank() && TtsPrefs.lang2(book.language).length >= 2) {
            lang = TtsPrefs.lang2(book.language)
        }
        // A book that says it is English but is written in another alphabet (common with converted files): trust the letters.
        val sample = loadChapter(startChapter)?.sentences?.take(40)?.joinToString(" ") { it.text }.orEmpty()
        TtsHtml.languageOfScript(sample)?.let { lang = it }
        voice = defaultVoice()
    }

    // ---- voices -------------------------------------------------------------------------------------------------

    private fun regionOrder(v: TtsVoice): Int = when (v.lang.substringAfter('-', "")) {
        "CN" -> 0; "TW" -> 1; "HK" -> 2; "US" -> 3; "GB" -> 4; else -> 5
    }

    fun edgeVoicesFor(): List<TtsVoice> {
        val bookRegion = book.language.substringAfter('-', "").uppercase()
        return EdgeSpeech.voices
            .filter { TtsPrefs.lang2(it.lang) == lang || it.variant == "multilingual" }
            .sortedWith(
                compareBy<TtsVoice>(
                    { TtsPrefs.lang2(it.lang) != lang },
                    { bookRegion.isNotEmpty() && it.lang.substringAfter('-', "") != bookRegion },
                    { regionOrder(it) },
                    { it.name },
                ),
            )
    }

    fun systemVoicesFor(): List<TtsVoice> = systemVoices

    private fun defaultVoice(): TtsVoice? {
        prefs.voiceFor(lang)?.let { id ->
            if (id.startsWith(SYSTEM_PREFIX)) return TtsVoice(id, "Phone voice", lang, null, true)
            EdgeSpeech.voices.firstOrNull { it.id == id }?.let { return it }
        }
        val edgeOwn = edgeVoicesFor().firstOrNull { TtsPrefs.lang2(it.lang) == lang && it.id != "en-US-AnaNeural" }
        return edgeOwn ?: edgeVoicesFor().firstOrNull() ?: TtsVoice(SYSTEM_PREFIX + "default", "Phone voice", lang, null, true)
    }

    /** The voice picker's groups: Edge's voices for the book's language, and the phone's own. */
    fun voiceGroups(): List<VoiceGroup> {
        val out = ArrayList<VoiceGroup>()
        val own = edgeVoicesFor()
        if (own.isNotEmpty()) out += VoiceGroup("edge", "Edge voices · online", own)
        if (systemVoices.isNotEmpty()) out += VoiceGroup("system", "On this phone", systemVoices)
        return out
    }

    /** Loads the phone's voices for the picker (starts the phone's speech engine the first time). */
    fun loadSystemVoices() {
        if (systemVoices.isNotEmpty()) return
        scope.launch {
            if (system.ensure()) systemVoices = system.voices(lang)
        }
    }

    // ---- offline audio ---------------------------------------------------------------------------------------------

    /** Works out, for every file of the book, how many of its sentences are already stored for the current voice. */
    fun refreshDownloads() {
        val v = voice ?: return
        if (v.id.startsWith(SYSTEM_PREFIX)) {
            downloads.clear()
            downloadRows = emptyList()
            return
        }
        scope.launch {
            val rows = ArrayList<Pair<Int, String>>()
            for (i in book.resources.indices) {
                val ch = loadChapter(i) ?: continue
                if (ch.sentences.isEmpty()) continue
                rows += i to book.chapterTitles.getOrNull(i).orEmpty().ifBlank { "Section ${i + 1}" }
                if (downloads[i]?.running != true) {
                    val keys = ch.sentences.map { cache.key(v.id, it.text) }
                    val done = withContext(Dispatchers.IO) { keys.count { cache.has(it) } }
                    val marked = withContext(Dispatchers.IO) { cache.downloadedKeys(book.bookId, v.id, i) != null }
                    downloads[i] = DownloadState(if (marked) done else 0, keys.size, false)
                }
            }
            downloadRows = rows
        }
    }

    fun downloadChapter(index: Int) {
        val v = voice ?: return
        if (v.id.startsWith(SYSTEM_PREFIX) || downloads[index]?.running == true) return
        val previous = downloadJob
        downloadJob = scope.launch {
            previous?.join()
            val ch = loadChapter(index) ?: return@launch
            val reqs = ch.sentences.map { SpeakRequest(it.text, v.lang, v) }
            val keys = reqs.map { cache.key(it) }
            withContext(Dispatchers.IO) { cache.markDownloading(book.bookId, v.id, index, keys) }
            var done = keys.count { cache.has(it) }
            downloads[index] = DownloadState(done, reqs.size, true)
            try {
                coroutineScope {
                    val q = reqs.iterator()
                    repeat(3) {
                        launch {
                            while (true) {
                                val r = synchronized(q) { if (q.hasNext()) q.next() else null } ?: break
                                try {
                                    edge.download(r)
                                } catch (e: SpeakException) {
                                    if (!e.permanent) throw e
                                }
                                done++
                                downloads[index] = DownloadState(minOf(done, reqs.size), reqs.size, true)
                            }
                        }
                    }
                }
                downloads[index] = DownloadState(reqs.size, reqs.size, false)
            } catch (e: CancellationException) {
                downloads[index] = DownloadState(keys.count { cache.has(it) }, reqs.size, false)
                throw e
            } catch (e: Exception) {
                downloads[index] = DownloadState(keys.count { cache.has(it) }, reqs.size, false)
                say("Download stopped: ${e.message ?: "no connection"}")
            }
        }
    }

    fun downloadAll() {
        for ((i, _) in downloadRows) if (downloads[i]?.complete != true) downloadChapter(i)
    }

    fun deleteDownload(index: Int) {
        val v = voice ?: return
        scope.launch {
            withContext(Dispatchers.IO) { cache.deleteDownload(book.bookId, v.id, index) }
            val total = downloads[index]?.total ?: 0
            downloads[index] = DownloadState(0, total, false)
        }
    }

    fun cancelDownloads() {
        downloadJob?.cancel()
        downloadJob = null
    }

    // ---- small things -------------------------------------------------------------------------------------------------

    fun say(text: String) {
        notice = text
        noticeJob?.cancel()
        noticeJob = scope.launch {
            delay(5000)
            notice = null
        }
    }

    /** Tells the notification to redraw (play / pause, new text). */
    private fun changed() = TtsService.refresh()

    private fun requestFocus() {
        val req = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener(focusListener)
            .build()
            .also { focusRequest = it }
        audioManager.requestAudioFocus(req)
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    /** What the notification shows: the book, the chapter, and (per the "update frequency" setting) the sentence. */
    fun notificationTitle(): String = book.title

    fun notificationText(): String {
        val s = currentSentence()
        return when (prefs.mediaMetadata) {
            "chapter" -> chapterTitle
            else -> if (s != null) s.text.take(90) else chapterTitle
        }
    }

    fun coverBitmap(): Bitmap? {
        val path = book.coverPath ?: return null
        return runCatching {
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeFile(path, opts)
        }.getOrNull()
    }

    companion object {
        /** Reads the publication into a [TtsBook]. Do this once, on starting. */
        suspend fun buildBook(s: ReaderSession): TtsBook {
            val pub = s.publication
            val resources = pub.readingOrder.mapNotNull { pub.locatorFromLink(it) }
            val hrefs = resources.map { it.href.toString().substringBefore('#') }
            val titleAt = arrayOfNulls<String>(resources.size)
            fun walk(links: List<Link>) {
                for (link in links) {
                    val loc = pub.locatorFromLink(link)
                    val i = loc?.let { hrefs.indexOf(it.href.toString().substringBefore('#')) } ?: -1
                    if (i >= 0 && titleAt[i].isNullOrBlank()) titleAt[i] = link.title?.trim()
                    walk(link.children)
                }
            }
            walk(pub.tableOfContents)
            // a file without its own contents entry belongs to the one before it
            val titles = ArrayList<String>()
            var last = ""
            for (i in resources.indices) {
                titleAt[i]?.takeIf { it.isNotBlank() }?.let { last = it }
                titles += last
            }
            val grouped = ArrayList<MutableList<Locator>>().also { g -> repeat(resources.size) { g += ArrayList<Locator>() } }
            for (p in pub.positions()) {
                val i = hrefs.indexOf(p.href.toString().substringBefore('#'))
                if (i >= 0) grouped[i] += p
            }
            return TtsBook(
                bookId = s.book.id,
                title = s.book.title,
                author = s.book.author,
                filePath = s.book.filePath,
                coverPath = s.book.coverPath,
                language = s.book.language,
                resources = resources,
                chapterTitles = titles,
                positionsByResource = grouped,
            )
        }
    }
}

/** The one read-aloud session of the app, and the settings it uses. */
object TtsHub {
    var session by mutableStateOf<TtsSession?>(null)

    private var prefsInstance: TtsPrefs? = null

    fun prefs(context: Context): TtsPrefs =
        prefsInstance ?: TtsPrefs(context.applicationContext).also { prefsInstance = it }

    /** Starts a session for the book the reader has open, or returns the one already running for it. */
    suspend fun open(app: Application, s: ReaderSession): TtsSession {
        session?.let { if (it.book.bookId == s.book.id) return it }
        session?.stop()
        val book = TtsSession.buildBook(s)
        val created = TtsSession(app, book, prefs(app))
        session = created
        return created
    }
}
