# Paperback 2 (Kotlin)

Paperback rebuilt natively: Kotlin, Jetpack Compose, and the Readium toolkit for EPUB (instead of Readest).
Android only. Package id `com.paperback.app`, so it installs next to the old TypeScript Paperback.

## What works in this first step
- Import EPUBs (copied into the app, deduplicated by file hash, cover and page count read from the book)
- Home (continue reading, today, streak, recently read), Library (search, filters, favorite / finished / remove), Stats (today, week, streaks, last 7 days, most read)
- Reader: page turns by tapping the screen edges, tap the middle for controls (slider, font size, light / sepia / dark), position saved on every page turn
- Reading time and pages counted per session (idle time is capped, like Readest)

### Added in round 2
- Bookmarks: bookmark button at the top of the reader, list in the notes panel
- Highlights and notes: select text, choose Highlight or Note; tap a highlight to edit it (note, colour, delete)
- Panel (button next to the bookmark) lists all bookmarks and notes of the book; tap one to jump there
- Reader controls now follow the page theme (light / sepia / dark)
- Fixed: the reader header jumped and lagged when the controls toggled. The phone's status and navigation bars now stay hidden
  for the whole reading session (swipe from the edge to peek), so nothing resizes when you tap the page

### Added in round 3: Settings (copied from the TypeScript app)
- **Settings page** exactly as in `app/(paperback)/settings/page.tsx`: daily-goal card (ring, minutes today, Edit), then READING (Reading goals, Reading stats, Reader defaults), LOOK (Appearance, App style), LIBRARY (Library & import, Backup & restore) and About, with the round menu button at the bottom right
- **Page header** in the three sizes (Compact / Regular / Large) on every screen, with the menu and search buttons; Library shows its book-count chip
- **Menu**: the pop-up card above the round button (Home, Library, Discover, Collections, Bookmarks, Stats, Settings, More) and the "All pages" sheet. Pages that are not built yet say "Soon"
- **App style** (header size with a live sample of each), **About** (logo tile, Credits, Open-source licenses), **Appearance** (Light / Dark / Match system), **Reading goals** (books this year, pages, minutes, streak, editable)
- **Reader defaults** (font size and page colors) and **Library & import**, both real, not placeholders
- **Backup & restore**: one JSON file with progress, favorites, ratings, bookmarks, highlights, reading history, goals and settings. Restore matches books by hash and never moves reading progress backwards
- The icons are the TypeScript app's own SVG paths (`PbIcons.kt`), so they are identical
- Navigation is now a small back stack in `PaperbackRoot.kt` (Back returns; tabs replace each other)

Not copied yet: Appearance's **Home layout** (Pile) and **Navigation** style (dock, header switch, off), because the Kotlin Home and tab bar have only one layout.
Outfit is not bundled yet (the font could not be downloaded); text uses the system sans. To add it, put Outfit-Regular/Medium/SemiBold.ttf in `app/src/main/res/font/` and point `PbSans` in `ui/theme/Theme.kt` at them.

### Added in step 4 (built on step 3)
- **Book page**: Library long-press -> Details, or tap the title on Home. Rating (stars), Favorite / Finished, progress, time read, page, sessions, collections, link to the book's notes, journal, remove
- **Collections** (menu -> Collections): create, rename, delete, add and remove books; a book's page can also toggle its collections
- **Notes & highlights** and **Bookmarks** (menu / All pages): every highlight, note and bookmark across all books, search, tap to open the book at that spot, remove, share notes as Markdown. Bookmarks opens on the second tab
- **Shelf pages** (All pages): Currently reading, Recently read, Finished, Favorites. Tap a cover for the book page
- **Finish date**: finishing a book now saves the date, so "books this year" in Reading goals is exact (older finished books still use the date they were last opened)
- **Backup** now also keeps journals, finish dates and collections (older backups still restore)
- Database upgrades in place (version 3): journal, finish date, collections. Existing libraries and history are kept

### Added in step 5
- **Global search** (the search button in every page header, or menu -> All pages -> Search): books by title, author or journal, your notes and highlights, collections, and the app's own pages (type "backup", "goals", "theme"...). Ignores capitals and accents; every word you type must match; matches are shown in coral
- Tap a book for its page, a note to open the book at that passage, a collection or page to go there. Back returns to the same search
- Recent searches are remembered (Clear removes them)

### Step 6: polish (no new features)
- One set of building blocks (`ui/PbKit.kt`): dialog, filled text field, rounded cards, segmented switch, round select mark, action pills. Every page and dialog from steps 4 and 5 now uses them instead of Material's stock look
- Dialogs (Add books, new / rename collection, delete, remove book, reader note editor) are rounded cards with a serif title and pill buttons. Add books has a search box, covers, and round ticks
- Text fields are filled with the card colour, no outline. Library search and filters use them too (filters are the coral pills, not Material chips)
- Book page: sections use the Settings label style, Notes & bookmarks is a Settings-style row, About is a card, Remove is a red pill button
- Collections list is one card with covers and carets; Notes are cards (serif quote, colour dot); Search results are cards
- Shelf pages and collection grids show author and reading progress like the Library
- Library's long-press menu, the snackbar and the reader's buttons use the app's colours and icons

### Step 7: Discover (free books from the internet)
- **Discover** (menu -> Discover, All pages -> Get books, or "Discover free books" on an empty Home / Library / Import page). Lists the catalogs: **Project Gutenberg** and **Standard Ebooks** are always there; **Add a catalog** takes any OPDS address (Calibre, Kavita, COPS, a library server...). Your own catalogs can be edited or removed from the dots menu; they are stored on this device only
- Private catalogs: add a username and password (Basic and Digest login are both handled; Calibre's content server uses Digest). The password is only ever sent to that catalog's own address
- Browsing like the old app: the toolbar has Back, Home (the catalog's first page), a search box (when the catalog has search), a Filters menu (when the page has filters) and Close. Pages show navigation cards, shelves that scroll sideways ("See all"), book grids and First / Previous / Next / Last. Back goes back one page at a time and the scroll position of each page is remembered
- **Book page**: cover, title, authors, **Download EPUB** (a small arrow next to it lists the other EPUB versions when a book has several, e.g. Standard Ebooks' advanced EPUB), description, details and subjects. A book you already have shows **Open & Read** (and Download again); it is recognised by where it came from, or by its title if you added it by hand
- Downloads go straight into the Library (same duplicate check and cover reading as Import) with a progress bar. Only **EPUB** is downloaded; if a book is offered only as PDF / MOBI the page says so
- Covers are fetched with the catalog's login and kept in the app's cache, so a page you have seen opens instantly
- The app now asks for the **Internet** permission, and allows plain `http://` so catalogs on your home network (Calibre at `192.168...`) work
- Not done: OPDS pagination "infinite scroll", catalogs that need a web sign-in page (OAuth), buying or borrowing books

### Step 8: reading essentials + polish
- **Contents**: the book's table of contents, nested chapters indented, the chapter you are in marked in coral. Reader controls -> **Contents** (also the first tab of the top-right panel). Tap a chapter to go there
- **Search in the book**: reader controls -> **Search**. Type, press search on the keyboard, tap a match to jump to it (the match is marked on the page). Up to 200 matches
- **Text settings** (reader controls -> **Text**): a sheet that sits over the page so you see changes live. Font size, page colors, **margins**, **layout** (the book's own, or Custom: **font** serif / sans / mono, **line spacing**, **left or justified**) and **brightness** (own slider for the reader, or "Auto" to follow the phone)
- Margins and layout are also in **Settings -> Reader defaults**, with a live sample
- Sliders are now Paperback's own (slim track, round coral handle) in the reader and in Reader defaults
- Fixed icons: Appearance, App style, Backup and Reader were drawn wrong (compact SVG arc flags); the paths now use spaced flags
- Library: round coral "+" import button; dark theme no longer has a purple tint on Material's selected colours

### Step 9: PDF
- **Import PDFs** the same way as EPUBs (Import, Library "+", Settings -> Library & import). A PDF is recognised by its content, so a file with a wrong name still works. The cover is the first page, the title is the file name (no author: a PDF's own details can't be read here)
- **PDF reader** (its own screen, drawn with Android's built-in PdfRenderer, no extra library): one page at a time, fitted to the screen. Swipe or tap the left / right edge to turn the page, tap the middle for the controls. **Pinch** or **double-tap** to zoom (up to 5x, sharper copy of the page once you stop), drag to move the zoomed page
- Controls: back, bookmark, bookmarks list, page slider ("Go to page" while dragging), time left, and **View**: page colors (Light, Sepia, Dark), **Right to left** page turning for manga, brightness
- Same as for EPUB: position saved on every page turn (and it resumes there), reading time and pages counted, bookmarks, finished at the last page, progress in Home / Library / Stats, included in Backup
- Comics: a comic saved as a PDF works the same way (use "Right to left" for manga). CBZ / CBR files are not supported yet
- Not possible with this approach: selecting text, highlights and notes, searching inside the PDF, and a table of contents. Scanned and text PDFs both display, but the text can't be reflowed (zoom in instead)

### Step 10: PDF fixes
- Fixed: zooming a PDF page (pinch or double-tap) made the page disappear. Two causes: lifting the fingers while zoomed produced an invalid position, and the sharper zoomed copy could be bigger than the phone's graphics limit (4096 px) and then was not drawn
- Fixed: Dark (and Sepia) turned pictures into negatives. The viewer now checks each page: a page that is mostly white with almost no color is "text" and gets the Dark / Sepia colors; a page with pictures or color is shown as it is in every theme (on the Dark or Sepia background). A page that mixes a large color picture with text is treated as a picture page

### Step 11: PDF picture pages without the white sheet
- On a picture page (a page that is not mostly text) the viewer now finds the white margins around the picture and shows just the picture, so in Dark and Sepia there is no white sheet floating on the dark / sepia background. The picture is also a little bigger. This applies in every theme
- Text pages are shown whole. Nothing is cut when the page is nearly empty (a few stray marks) or already has no real margin
- Colors of pictures are never changed by the theme (this was already so in kt-10)

### Step 12: Genres, authors and recommendations (and Discover fixes)
- **Paperback now reads each book's genres / tags, description, publisher and date** (from the EPUB itself, and for Discover downloads also from the catalog). Books you already had are read once, in the background, after the update. PDFs have none of these. Messy subject lines are cleaned: "England -- Fiction" becomes the tags *England* and *Fiction*; codes like "LoCC: ..." and words like "Text" are dropped
- **Genres page** and **Authors page** (menu -> More, or search): every genre / author with its number of books, a filter field once there are many, tap one to see its books
- **Book page**: genre chips (tap one to see that genre), description with Read more, Publisher and Published in About, tap the author to see their books, and a **Similar in your library** row
- **Library**: a Sort menu (Recently added, Recently read, Title, Author, Rating, Progress) and a Genre filter; the Library search also finds genres
- **Home**: **Recommended for you**, with "Like <book>". Books you have not started, ranked by how much they resemble the books you rated 4-5, favorited, or finished (rated 1-2 count for nothing). It appears once you have rated, favorited or finished a book that has genres
- **Search** finds books by genre too, and lists matching Authors and Genres
- **Discover**: the book page shows a cleaned Genres list and a short description (Project Gutenberg's long catalogue record is cut to its Summary)
- Discover fixes: Project Gutenberg lists show covers and authors and open the book directly (no duplicate page); "No records found" is no longer tappable; a page that fails with "403 / busy" is retried once; pages you opened in the last 10 minutes load instantly from a cache
- Database version 4 (new columns; nothing is lost)

### Step 13: Chapter name and "pages left" around the page (EPUB reader)
- The reader now shows, always and quietly, like Readest: the **chapter name** above the page (top left), **"N pages left in chapter"** below it (bottom left) and **"position / total"** (bottom right, for example "2 / 196"). They hide while the controls are showing
- The two numbers count different things on purpose, as in Readest: "pages left" counts real screens (it drops by exactly 1 per page turn; the page you are on counts, so the last page says "1 page left"), while "2 / 196" counts Readium's fixed pieces of text, so one page turn can move it by 2 or more
- "Pages left" is measured on the page on screen (how many screens wide the chapter's file is), and re-measured after text size, margin, font or theme changes. For a chapter that continues into the next files it adds those files' length, estimated from the position counts. If a book's contents put several chapters in one file, the chapter ends where the next file starts
- The page area now has a 32 dp strip above and below it (plus the phone's status / navigation bar space) to hold this text; the strip takes the page colour of the theme
- The controls card still shows "Page X of Y . % . time left" as before

### Step 14: The "25 / 136" counter now counts like Readest
- Fixed: the counter stood still for 2-3 page turns (it showed the same number on several pages). Readium's "positions" are cut by the *packed* size of the book (about 1 per 3000 characters of text), so a page held less than one. The counter now uses Readest's way: the book is cut into pieces of 1500 bytes of its *unpacked* text (sizes read from the EPUB file itself), and the counter is the piece your page starts in. A page usually holds one or more pieces, so the number moves on every turn and sometimes jumps by 2
- The total ("/ 136") is that piece count, so it is larger than before and stays the same whatever the text size
- "Page X of Y" in the controls card shows the same two numbers (the "time left" there still uses the old position count)
- If a book's sizes can't be read, the counter falls back to Readium's positions as before

### Step 15: Reflow a PDF as an EPUB
- Open a PDF's book page and tap **Reflow as EPUB**. It reads the PDF's text and builds a new book called "Title (EPUB)" in your Library. The PDF is not touched, and its progress, bookmarks and stats stay with it. The copy is a normal EPUB, so Contents, search, notes, text size, fonts, margins, line spacing and the Light / Sepia / Dark pages all work
- A progress bar shows "Reading page N of M" with a Cancel button. One conversion runs at a time, and it keeps going if you leave the page. Converting the same PDF twice finds the first copy instead of adding another
- What it does: joins lines into paragraphs (first-line indents, extra space above, a short last line), joins words split by a hyphen at the end of a line, finds chapter and section headings (bigger or bold, standing alone) and builds the Contents from them, removes running headers, footers and page numbers, keeps italics and bold, raised footnote marks, bullet lists and scene breaks, puts footnotes after the paragraph they belong to, merges a big drop-cap letter back into its word, and keeps pictures where they were. The cover is the PDF's cover
- Limits: a **scanned PDF has no text**; from step 17 it is read with text recognition instead. **Two-column pages, tables and maths** come out in a jumbled or flat order. Footnotes are placed after the paragraph, not at the page bottom. Comics and picture books have nothing to reflow
- The converter itself (`app/src/main/java/com/paperback/app/reflow`) is plain Java so it can be tested without a phone. It was checked on generated novels, a one-sentence-per-paragraph PDF, drop caps, bullets, footnotes, a double-spaced typescript, a scan, and a real LaTeX-typeset book. Reading the PDF itself uses the PDFBox for Android library (`com.tom-roush:pdfbox-android`, about 5 MB more in the app)

### Step 16: Polish and bug fixes (no new features)
Bugs fixed
- **PDF viewer could crash when you left it while a page was still drawing.** The file was closed under the drawing page. It now waits for the page to finish, and a page asked for after that gets a blank answer instead of an error
- **A PDF page that can't be drawn** (a damaged page, or not enough memory for a big zoomed bitmap) now shows "Couldn't draw page N" instead of crashing or staying blank
- A tiny crash-in-waiting in the PDF page crop (an empty drawing range) is closed
- **Deleting a highlight on the Notes page now asks first**, because its note goes with it
- "Remove" buttons (Notes, bookmarks list, reader panel, PDF bookmarks) have a proper 44 dp tap target; the small pills (filters, Rename / Delete, Share) are 44 dp tall instead of 40

Look
- **Home**: "Resume reading" is the same black pill as every other main button (it was coral and Material's own). "Read today" is now the **daily goal ring** ("8 of 30 min") like the Settings card
- **Home**: the Recently read and Recommended rows now run to the screen edges and their shadows are no longer cut off at the bottom
- Home, Library and Stats use the same 560 dp page width as every other page (matters on tablets, folded phones and landscape)

### Step 17: Reflow scanned PDFs (text recognition)
- **"Reflow as EPUB" now works on scans.** When the PDF has no text of its own (found by looking at a dozen pages, so it takes a second), every page is drawn as a picture and read with Google's on-device text recognition (ML Kit, the bundled Latin model, nothing leaves the phone). The result goes through the same paragraph, heading, footnote and running-header logic as a PDF with text
- **Two-page spreads are split.** A scan where each PDF page shows two book pages side by side is cut at the fold and the left page is read before the right
- **Crooked scans are straightened** before the sizes are measured, so a slightly tilted page doesn't turn body lines into headings. Page numbers printed in the margin beside the text (older-edition numbers) are dropped
- While it reads, the card says "Recognising text on page N of M" and the screen stays on. Expect a few minutes for a few hundred pages, and keep Paperback open
- Limits: **italics and bold are not seen** (so italic subheadings read as normal paragraphs), small recognition mistakes happen (a letter swapped, a Greek word turned to nonsense), the language is Latin script only (English, French, German, Spanish and so on, not Greek, Cyrillic, Arabic or Chinese), footnotes on a scan are only recognised when their print is clearly smaller, and two-column or table pages stay jumbled
- The app is about 4 MB bigger per processor type for the recognition model
- New plain-Java pieces in `reflow`: `Spread` (finds the fold), `OcrPages` (words and boxes to the page model: straightening, line sizes, margin numbers), `NoTextException`; `data/ReflowOcr.kt` draws the pages and calls ML Kit. The Java part was tested on 126 half-pages of a real scanned book using Tesseract as the recogniser in the sandbox; the ML Kit call itself could not be run there

### Step 18: Smaller app
- The app was 41 MB, mostly because the text recognition model is packed once for every processor type. Now **only arm64-v8a** is packed (every phone from the last ten years). An emulator or an old 32-bit phone needs `paperback.abis=arm64-v8a,armeabi-v7a,x86_64` in `gradle.properties`
- **R8 and resource shrinking are on** for the release build: unused code and resources are removed and the rest is renamed, which also helps start-up. The rules are in `app/proguard-rules.pro`. If a build ever crashes at launch or when opening a book, put `paperback.minify=false` in `gradle.properties` to turn it off again

### Step 19: Navigation choice
- **Settings → App style → Navigation**: **Bar** (as before) or **Clean**. Clean has no bar at the bottom, so the screen is just the page; Home, Library, Stats, Settings and everything else open from the menu button in the top corner. The choice is kept on the phone and is part of the backup
- **Header** on the same page: the "Header size" card is gone; tap any of the four samples to choose it. The fourth, **Buttons only**, has the menu and search buttons and no "paperback" wordmark
- **Accent colour** (Settings → Appearance): eight ready-made colours (Coral, Teal, Amber, Violet, Green, Pink, Blue, Lime) as round swatches, and a rainbow swatch that opens two sliders (hue, then shade) for your own. It recolours buttons, progress, the bar, highlights and links across the app at once, and is saved and included in backups. The app icon and logo stay coral
- **The bar now has Settings** as a fourth item (gear icon). Settings is now a main screen like Home, Library and Stats, so the bar stays visible on it and Back from it leaves the app, as from the other three

### Step 20: Bookshelves
- **Library** shows your books as spines standing on wooden shelves: the title runs down the spine, the author is small at the foot, thicker books are wider, and a thin accent line at the bottom of a spine shows how far you are. Tap to open, long-press for Details / Favorites / Finished / Remove, as with the covers. Favorites get their own shelf on top when you aren't searching or filtering
- **View: Shelves / Covers** (next to Sort and Genre) switches between the shelves and the old grid of covers; the choice is kept and is part of the backup
- **Home**: Continue reading and Today are unchanged. Favorites, Recently read and Recommended for you are now shelves (the book you read last leans on the others). Recommended books open their details page
- Spine colours and heights come from the book itself, so a book always looks the same. The wood is warm in light mode and darker in dark mode
- Header, navigation, Settings and everything else are as in kt-19

### Step 21: The reader counter jumps more often
- The "25 / 136" counter used to move by exactly 1 on most page turns and jump only about once in 10 pages, because a page of English text is only a little more than one 1500-byte piece. The pieces are now **750 bytes** (half of Readest's), so a page holds about two and the counter moves by 2 on most turns, sometimes 1 or 3. The total is about twice as large as before and still does not change with text size
- Want it jumping even more, or less? It is one number: `SIZE_PER_LOCATION` in `data/ReaderPlace.kt` (smaller = bigger jumps)

### Step 26: The reader counter counts exactly like Readest
- The "25 / 136" counter is cut into **1500-byte** pieces of the book text, the same size Readest uses, so a book shows about the same total as in Readest (about half of kt-25's). Because a page holds a little more than one piece, the number moves by 1 on most page turns and by 2 now and then, as it does in Readest
- It is still one number: `SIZE_PER_LOCATION` in `data/ReaderPlace.kt` (750 was the kt-21 setting)

### Step 27: Build fixes
- The build failed with five compile errors: the hue/lightness colors of the accent picker (`Color.hsl` is not in this version of Compose, so `AccentPicker.kt` has its own `hslColor`), the gauge's side gap in `ActivityCharts.kt`, a missing argument on the "Peak hour" stat (`SideStat` sub is optional now), the Library "View" pill (`MenuPill` active is optional now), and a stray comma in `EntryScreen.kt`'s `when`

### Step 22: Stats -> Activity
The Stats tab is now the Activity page from the TypeScript app, in the Kotlin look. It replaces the old Stats tiles; everything those showed is in here.
- **Daily goal**: half-circle gauge with the minutes read today, "N min to go" / "Goal reached", streak, goal met (of the last 7 days), this week's total, and a tick for each of the last 7 days. Tap it to open Reading goals
- **Next best action**: one suggestion for today (keep your streak, N minutes to go, start a streak...)
- **Reading chart**: Week / Month / Year / All time, Time or Pages, a big total with the change against the previous period, a bar chart you can tap or drag (the picked bar is read out above it), a dashed goal line for time in week and month, and arrows to go back and forward. Tap the label between the arrows to jump to any week, month or year
- **Details**: reading pace (pages per hour, with a trend line and the change), sessions (with the change), books finished in the period
- **Session length**: average session, longest session (and when), best day, average a day, each against your daily goal
- **Reading rhythm**: an 18-week calendar, darker = more reading. Tap a day for its time
- **When you read** (last 90 days): by session or by pages. A 24-hour clock (tap an hour), your most active time of day, best weekday, peak hour, counts for morning / afternoon / evening / night, and a bar for each weekday
- **Most read**: your top books for the chosen period with their share of the time. Tap one for its page
- **All time**: reading time, pages, sessions, books read, books finished, days read, current and longest streak, longest session, best day, average on days read, reading since
- Sessions are logged rows of the same book less than 10 minutes apart, merged. Days and hours use the phone's time zone
- Not in this step (they are separate pages in the original): Books, History, Insights, Milestones

### Step 23: Online catalog and a smarter Search
Search is now also a way to find books to read next. The books come from **Open Library** (free, no account, no key); when it has no description or rating, **Google Books** fills in. Nothing can be downloaded from these pages: they only tell you about books, and you add the files yourself.
- **Search page, before you type**: Recent searches, then **For you** (recommendations), **Trending this week**, and **Explore by category** (20 genres). "View all" opens a grid
- **For you** is worked out on the phone from your library: what you finished, rated (5 and 4 stars count most, 1 and 2 count against), favorited and started, by genre and by author. Books you own are left out, authors you rated low are not suggested, and no author fills more than two spots. Each book says why ("Because you liked Dune", "More by Frank Herbert", "You read a lot of Fantasy"). Only a few genre and author names are sent, as search words. It is refreshed when your taste changes, or after six hours
- The keyboard no longer opens by itself on an empty Search page (it would cover these sections); tap the field to type. With the catalog off it opens as before
- **Typing a search** shows your own results first (books, notes, collections, pages as before) and then **Online catalog** results with cover, year and rating. The catalog is asked once you pause typing
- **Catalog book page**: cover, title, author (tap for more by them), star rating and number of ratings, year, how many have read it / want to read it, description (Read more), genres (tap to browse), **More by the author**, **More in this genre**. If you own it, it says so and opens your copy; if not, it says where to get it and links to the Open Library page
- **Privacy**: the whole thing can be turned off (the card shown when it is off, or the link at the bottom of the page). Answers are kept on the phone (trending 6 h, categories 24 h, searches 12 h, book pages 7 days) so pages open fast and still work offline. About describes this. Turning it off is part of the backup
- `catalog/` (Java, tested on a computer with sample data): `Taste`, `Ranker`, `Subjects`, `TitleKey`, `Describe`. `data/catalog/`: `CatalogApi` (requests and parsing), `CatalogController`, `Categories`. `ui/`: `ExploreSection`, `CatalogBookScreen`, `CatalogBrowseScreen`, `CatalogUi`
- Not in this step: a "Want to read" list (saving catalog books to come back to) and showing recommendations on Home

### Step 24: Want to read, and recommendations on Home
- **Want to read** (the old "Wishlist"): open any book in the online catalog and tap **Want to read** to save it. The list is under Menu, More, Shelves, as a row at the top of the Search page, and on Home. Long-press a book on the list to take it off. A book leaves the list by itself when you add a copy to your library (matched by title). The list stays on the phone and is part of the backup (it is kept even if the online catalog is off)
- **Home** has two new rows at the bottom: **Want to read** and **Books you might like** (the same recommendations as "For you" on Search, with the reason under each cover; shown only while the online catalog is on). "View all" opens the full list
- Everything else is as in kt-23

### Step 25: Book page first, reading timer and entries
- **Tapping a book opens its page** (Library, Home). From there: Start / Resume reading. If you prefer the old way, **Settings → App style → Tapping a book → The reader**. The choice is part of the backup. Long-press in Library and tapping a book on shelf pages still open the page too
- **Entries** on the book page (Reading time): every time you read is one card with the date and time, the pages (for example "Pages 76–102" and "+ 27"), the time and your pace in min/page. Reading in the reader is added automatically as before, and now remembers the first and last page. Tap an entry to change it; **Add entry** makes one by hand (date, time, from page, to page, minutes, with 15 m / 30 m / 45 m / 1 h buttons). Pages are the numbers shown in the reader (25 / 136). Everything feeds Activity and the goals like any other reading. Backups include the page numbers
- **Timer**: counts up for one book at a time, with an optional target (15 / 30 / 60 minutes or your own; tap the chosen time again for no limit). It keeps counting with the screen off and after a restart (it works from clock times). A buzz marks the target, but only while the timer page is open. **Finish & save** opens the entry with the time filled in so you can add the pages. **Reset** starts over. The reader already counts your reading in Paperback, so the timer is for paper books or other apps
- Database version 5 (two new columns on sessions); older installs update by themselves and keep their history
- Not done: showing the running timer outside the book page, and a notification when the target is reached with the app closed

## Not done yet (in the old app, planned in this order)
CBZ / CBR comics, PDF text and notes, journal page, dictionary and saved words, read aloud, milestones, Outfit and Newsreader fonts.

## Layout
- `app/src/main/java/com/paperback/app/data` database, import, stats maths (`Stats.kt` is the port of statsAggregate.ts)
- `.../reader` ReaderActivity (hosts Readium's fragment), the controls overlay, reading-time tracker
- `.../data/opds` the OPDS reader for Discover (XML / JSON parsing, web client with login), `DiscoverController.kt` and `OpdsStore.kt` (catalog list)
- `.../ui` Home, Library, Stats, book page, collections, notes, shelf pages, Discover, settings pages, menu, and the theme (same coral / black / white as before)

## Building
Upload the zip next to `.github/workflows/apk-kotlin-from-one-zip.yml` and run the workflow. Versions are in `gradle/libs.versions.toml`.
If Gradle can't find a version, change it there.
