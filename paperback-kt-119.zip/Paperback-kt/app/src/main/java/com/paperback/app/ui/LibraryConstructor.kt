package com.paperback.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.paperback.app.data.LibraryBlock
import com.paperback.app.data.LibraryCatalog
import com.paperback.app.data.LibraryLayout
import com.paperback.app.data.LibraryPresets
import com.paperback.app.data.LibrarySpacing
import com.paperback.app.data.LibraryView
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlinx.coroutines.isActive

/*
 * Customize Library. A full-screen editor over the app, the same idea as Customize Home: a picture of the page, the list
 * of its blocks (drag to move, eye to hide), and a panel for the block you tap. Nothing is saved until Done, and Undo
 * and Redo walk through every change made since the editor opened.
 */

/** The state of one visit to Customize Library. The app keeps it in the view model so turning the phone doesn't lose the work. */
class LibrarySession(private val initial: LibraryLayout?, private val initialView: LibraryView) {
    enum class Tab { Blocks, Style }

    var tab by mutableStateOf(Tab.Blocks)
    var layout by mutableStateOf(initial ?: LibraryLayout.ORIGINAL)
        private set
    var view by mutableStateOf(initialView)
        private set
    var selected by mutableStateOf<LibraryBlock?>(null)

    private class Snap(val layout: LibraryLayout, val view: LibraryView)

    private var undoStack by mutableStateOf(emptyList<Snap>())
    private var redoStack by mutableStateOf(emptyList<Snap>())
    private var gesture = false

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** Whether leaving now would throw something away. */
    val changed: Boolean get() = layout != (initial ?: LibraryLayout.ORIGINAL) || view != initialView

    private fun push() {
        undoStack = (undoStack + Snap(layout, view)).takeLast(60)
        redoStack = emptyList()
    }

    /** One undoable change. */
    fun edit(change: (LibraryLayout) -> LibraryLayout) {
        endLive()
        val next = change(layout).normalized()
        if (next != layout) {
            push()
            layout = next
        }
    }

    /** A change that comes in many small steps (a drag): the first step is remembered, the rest are not, until [endLive]. */
    fun live(change: (LibraryLayout) -> LibraryLayout) {
        val next = change(layout).normalized()
        if (next == layout) return
        if (!gesture) {
            push()
            gesture = true
        }
        layout = next
    }

    fun endLive() {
        gesture = false
    }

    fun chooseView(value: LibraryView) {
        endLive()
        if (value != view) {
            push()
            view = value
        }
    }

    fun undo() {
        endLive()
        val last = undoStack.lastOrNull() ?: return
        redoStack = redoStack + Snap(layout, view)
        undoStack = undoStack.dropLast(1)
        layout = last.layout
        view = last.view
    }

    fun redo() {
        endLive()
        val next = redoStack.lastOrNull() ?: return
        undoStack = undoStack + Snap(layout, view)
        redoStack = redoStack.dropLast(1)
        layout = next.layout
        view = next.view
    }

    /** Shows a hidden block or hides a shown one. A chip row with all its switches off comes back with them on. */
    fun toggleHidden(block: LibraryBlock) = edit { l ->
        if (l.isVisible(block)) {
            l.hiding(block, true)
        } else {
            var next = l.hiding(block, false)
            if (!next.isVisible(block)) LibraryCatalog.optionsOf(block).forEach { next = next.withOption(it.key, true) }
            next
        }
    }

    /** One step of a drag in the list of blocks. */
    fun moveLive(from: Int, to: Int) = live { it.moving(from, to) }
}

private val LibSheetTop = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)

@Composable
fun LibraryConstructor(
    session: LibrarySession,
    onDone: (LibraryLayout, LibraryView) -> Unit,
    onUseOriginal: () -> Unit,
    onClose: () -> Unit,
) {
    val t = pbTokens()
    var askDiscard by remember { mutableStateOf(false) }
    var askOriginal by remember { mutableStateOf(false) }
    val close: () -> Unit = { if (session.changed) askDiscard = true else onClose() }

    BackHandler {
        if (session.selected != null) {
            session.selected = null
        } else {
            close()
        }
    }

    // the editor rises a little as it opens
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val appear by animateFloatAsState(if (shown) 1f else 0f, tween(PB_MS_ENTER, easing = PbEaseOut), label = "libraryEditorIn")

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = appear
                translationY = (1f - appear) * 24.dp.toPx()
            }
            .background(t.bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            // nothing under the editor may be touched
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                LibIconButton(PbIconName.Close, "Close", true, close)
                Spacer(Modifier.weight(1f))
                LibIconButton(PbIconName.Undo, "Undo", session.canUndo) { session.undo() }
                LibIconButton(PbIconName.Redo, "Redo", session.canRedo) { session.redo() }
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .height(44.dp)
                        .pbTap({ if (session.changed) onDone(session.layout, session.view) else onClose() }, RoundedCornerShape(22.dp), haptic = true, role = Role.Button)
                        .clip(RoundedCornerShape(22.dp))
                        .background(t.ink)
                        .padding(horizontal = 22.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Done", color = t.bg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            }
            Text(
                "Customize Library",
                color = t.ink,
                fontFamily = PbSerif,
                fontSize = 26.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 4.dp),
            )
            PbSegmented(
                options = listOf(LibrarySession.Tab.Blocks to "Blocks", LibrarySession.Tab.Style to "Style"),
                selected = session.tab,
                onSelect = { session.tab = it },
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (session.tab) {
                    LibrarySession.Tab.Blocks -> LibBlocksTab(session) { askOriginal = true }
                    LibrarySession.Tab.Style -> LibStyleTab(session)
                }
            }
            if (session.tab == LibrarySession.Tab.Blocks) {
                val block = session.selected
                if (block != null) LibBlockPanel(session, block)
            }
        }
    }

    if (askDiscard) {
        PbConfirmDialog(
            title = "Discard your changes?",
            message = "Library stays the way it was before you opened Customize Library.",
            confirm = "Discard",
            onConfirm = { askDiscard = false; onClose() },
            onDismiss = { askDiscard = false },
        )
    }
    if (askOriginal) {
        PbConfirmDialog(
            title = "Use the original Library?",
            message = "Everything comes back: the search bar, the chips and the scanner card. The look of the books stays as it is now.",
            confirm = "Use original",
            onConfirm = { askOriginal = false; onUseOriginal() },
            onDismiss = { askOriginal = false },
        )
    }
}

// ---- the picture of the page ---------------------------------------------------------------------

private class LibPen(val d: DrawScope, val s: Float, val ox: Float, val ink: WireInk) {
    fun box(x: Float, y: Float, w: Float, h: Float, r: Float = 2f, c: Color = ink.faint) {
        d.drawRoundRect(c, Offset(ox + x * s, y * s), Size(w * s, h * s), CornerRadius(r * s, r * s))
    }
}

/** The Library as a few grey shapes, drawn on a phone-shaped page. It follows the layout and the look of the books. */
@Composable
private fun LibPreview(layout: LibraryLayout, view: LibraryView, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val ink = rememberWireInk()
    val frame = RoundedCornerShape(28.dp)
    Box(modifier.fillMaxWidth().clip(frame).background(t.card)) {
        Canvas(Modifier.fillMaxWidth().height(216.dp).clipToBounds()) {
            // a page 100 units wide and 160 tall, in the middle; a unit is as big as the room allows
            val s = minOf(size.width * 0.5f / 100f, size.height / 160f)
            val ox = (size.width - 100f * s) / 2f
            val p = LibPen(this, s, ox, ink)
            // the phone's own edge
            p.box(-5f, 3f, 110f, 154f, 9f, t.bg)
            val gap = layout.spacing.dp * 0.4f
            var y = 12f
            for (block in layout.shown) {
                when (block) {
                    LibraryBlock.Search -> {
                        p.box(0f, y, 100f, 9f, 4.5f, ink.faint)
                        p.box(4f, y + 2.5f, 4f, 4f, 2f, ink.mid)
                        p.box(11f, y + 3.6f, 34f, 1.8f, 0.9f, ink.mid)
                        y += 9f + gap
                    }
                    LibraryBlock.Status -> {
                        var x = 0f
                        p.box(x, y, 15f, 6f, 3f, ink.accent)
                        x += 17f
                        LibraryCatalog.optionsOf(block).forEach { o ->
                            if (layout.isOn(o.key)) {
                                p.box(x, y, 19f, 6f, 3f, ink.faint)
                                x += 21f
                            }
                        }
                        y += 6f + gap
                    }
                    LibraryBlock.Tools -> {
                        var x = 0f
                        LibraryCatalog.optionsOf(block).forEach { o ->
                            if (layout.isOn(o.key)) {
                                p.box(x, y, 28f, 6f, 3f, ink.faint)
                                x += 30f
                            }
                        }
                        y += 6f + gap
                    }
                    LibraryBlock.Scanner -> {
                        p.box(0f, y, 100f, 26f, 5f, ink.faint)
                        p.box(5f, y + 4f, 7f, 7f, 2f, ink.mid)
                        p.box(15f, y + 6f, 24f, 2f, 1f, ink.mid)
                        p.box(5f, y + 14f, 40f, 3f, 1.5f, ink.mid)
                        p.box(5f, y + 19.5f, 22f, 4f, 2f, ink.accent)
                        y += 26f + gap
                    }
                    LibraryBlock.Books -> {
                        y += 2f
                        when (view) {
                            LibraryView.Shelves -> for (row in 0..1) {
                                val widths = floatArrayOf(11f, 15f, 10f, 13f, 16f, 11f, 13f)
                                val heights = floatArrayOf(20f, 25f, 17f, 22f, 25f, 19f, 22f)
                                var x = 0f
                                for (i in widths.indices) {
                                    if (x + widths[i] > 100f) break
                                    p.box(x, y + 26f - heights[i], widths[i], heights[i], 1.5f, if (i % 3 == 0) ink.mid else ink.faint)
                                    x += widths[i] + 3f
                                }
                                p.box(-2f, y + 26f, 104f, 3f, 1.5f, ink.mid)
                                y += 36f
                            }
                            LibraryView.Frosted -> for (row in 0..1) {
                                for (i in 0..3) p.box(i * 25f, y, 22f, 26f, 2f, ink.mid)
                                p.box(-2f, y + 25f, 104f, 6f, 3f, ink.accent.copy(alpha = 0.3f))
                                y += 36f
                            }
                            LibraryView.Covers -> for (row in 0..1) {
                                for (i in 0..2) p.box(i * 34f, y, 30f, 34f, 3f, ink.mid)
                                y += 38f
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---- Blocks tab ----------------------------------------------------------------------------------

private val LibRowHeight = 64.dp
private val LibRowGap = 8.dp

private fun libSummary(layout: LibraryLayout, block: LibraryBlock, view: LibraryView): String = when {
    block == LibraryBlock.Books -> view.label
    !layout.isVisible(block) -> "Hidden"
    block == LibraryBlock.Status -> (listOf("All") + LibraryCatalog.optionsOf(block).filter { layout.isOn(it.key) }.map { it.label }).joinToString(", ")
    block == LibraryBlock.Tools -> LibraryCatalog.optionsOf(block).filter { layout.isOn(it.key) }.joinToString(", ") { it.label }
    block == LibraryBlock.Scanner -> "Shown when there is something to review"
    else -> "Shown"
}

@Composable
private fun LibBlocksTab(session: LibrarySession, onUseOriginal: () -> Unit) {
    val t = pbTokens()
    val layout = session.layout
    val density = LocalDensity.current
    val pitch = with(density) { (LibRowHeight + LibRowGap).toPx() }
    var dragBlock by remember { mutableStateOf<LibraryBlock?>(null) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val shape = RoundedCornerShape(20.dp)
    val scroll = rememberScrollState()
    // where the finger is on screen, and where the list is, so a drag near an edge can scroll the list
    var fingerY by remember { mutableFloatStateOf(0f) }
    var viewTop by remember { mutableFloatStateOf(0f) }
    var viewBottom by remember { mutableFloatStateOf(0f) }

    // swaps the dragged block with its neighbours for as long as it has moved more than half a row away
    val settle: (LibraryBlock) -> Unit = { moved ->
        var again = true
        while (again) {
            again = false
            val now = session.layout.order
            val at = now.indexOf(moved)
            val lastMovable = now.lastIndex - 1 // the books stay last
            if (dragY > pitch / 2f && at in 0 until lastMovable) {
                session.moveLive(at, at + 1)
                dragY -= pitch
                again = true
            } else if (dragY < -pitch / 2f && at > 0) {
                session.moveLive(at, at - 1)
                dragY += pitch
                again = true
            }
        }
    }

    // holding a block near the top or bottom edge scrolls the list, faster the closer to the edge
    LaunchedEffect(dragBlock) {
        val held = dragBlock ?: return@LaunchedEffect
        val edge = with(density) { 80.dp.toPx() }
        val fastest = with(density) { 16.dp.toPx() }
        while (isActive) {
            withFrameNanos { }
            val step = when {
                fingerY < viewTop + edge -> -fastest * ((viewTop + edge - fingerY) / edge).coerceIn(0f, 1f)
                fingerY > viewBottom - edge -> fastest * ((fingerY - (viewBottom - edge)) / edge).coerceIn(0f, 1f)
                else -> 0f
            }
            if (step != 0f) {
                val moved = scroll.scrollBy(step)
                if (moved != 0f) {
                    dragY += moved
                    settle(held)
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned {
                viewTop = it.positionInRoot().y
                viewBottom = viewTop + it.size.height
            }
            .verticalScroll(scroll)
            .padding(horizontal = 20.dp)
            .padding(top = 4.dp, bottom = 32.dp),
    ) {
        LibPreview(layout, session.view)
        Eyebrow("Start from", Modifier.padding(top = 16.dp, bottom = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LibraryPresets.all.forEach { preset ->
                TogglePill(preset.name, preset.matches(layout)) { session.edit { preset.appliedTo(it) } }
            }
        }
        Text(
            "Drag a block by its handle to move it. The eye hides a block. Tap a block to change what is in it.",
            color = t.setSub,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(top = 18.dp, bottom = 12.dp),
        )
        Column(verticalArrangement = Arrangement.spacedBy(LibRowGap)) {
            for (block in layout.order) {
                androidx.compose.runtime.key(block) {
                    val dragging = dragBlock == block
                    val picked = session.selected == block
                    val visible = layout.isVisible(block)
                    var gripTop by remember { mutableFloatStateOf(0f) }
                    val lift by animateDpAsState(if (dragging) 10.dp else 0.dp, spring(stiffness = 600f), label = "libRowLift")
                    val accent = MaterialTheme.colorScheme.primary
                    val edge by animateColorAsState(if (picked) accent else Color.Transparent, tween(PB_MS_ENTER), label = "libRowEdge")
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(LibRowHeight)
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer { translationY = if (dragging) dragY else 0f }
                            .shadow(lift, shape)
                            .clip(shape)
                            .background(t.card)
                            .border(2.dp, edge, shape)
                            .alpha(if (visible) 1f else 0.55f),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (block.isMovable) {
                            Box(
                                Modifier
                                    .size(width = 44.dp, height = LibRowHeight)
                                    .onGloballyPositioned { gripTop = it.positionInRoot().y }
                                    .pointerInput(block) {
                                        detectDragGestures(
                                            onDragStart = { start -> dragBlock = block; dragY = 0f; fingerY = gripTop + start.y },
                                            onDragEnd = { dragBlock = null; dragY = 0f; session.endLive() },
                                            onDragCancel = { dragBlock = null; dragY = 0f; session.endLive() },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                fingerY += amount.y
                                                dragY += amount.y
                                                settle(block)
                                            },
                                        )
                                    },
                                contentAlignment = Alignment.Center,
                            ) { PbIcon(PbIconName.Grip, size = 22.dp, tint = t.setSub, strokeWidth = 3.4f, contentDescription = "Move ${block.label}") }
                        } else {
                            Spacer(Modifier.width(18.dp))
                        }
                        Column(
                            Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                ) { session.selected = if (picked) null else block },
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Text(block.label, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(libSummary(layout, block, session.view), color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (block.isMovable) {
                            LibIconButton(
                                if (visible) PbIconName.Eye else PbIconName.EyeOff,
                                if (visible) "Hide ${block.label}" else "Show ${block.label}",
                                true,
                            ) { session.toggleHidden(block) }
                            Spacer(Modifier.width(4.dp))
                        } else {
                            Spacer(Modifier.width(18.dp))
                        }
                    }
                }
            }
        }
        Row(Modifier.padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionPill("Use the original Library", onUseOriginal)
        }
    }
}

/** What is inside the block you tapped: its switches, or the look of the books. */
@Composable
private fun LibBlockPanel(session: LibrarySession, block: LibraryBlock) {
    val t = pbTokens()
    val layout = session.layout
    val options = LibraryCatalog.optionsOf(block)
    Column(Modifier.fillMaxWidth().clip(LibSheetTop).background(t.card)) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(block.label, color = t.ink, fontFamily = PbSerif, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(block.about, color = t.setSub, fontSize = 13.sp, lineHeight = 17.sp)
            }
            LibIconButton(PbIconName.Close, "Close", true) { session.selected = null }
        }
        Column(
            Modifier
                .heightIn(max = 300.dp)
                .verticalScroll(rememberScrollState())
                .padding(top = 6.dp, bottom = 14.dp),
        ) {
            if (block.isMovable) {
                LibSwitchRow("Show on Library", layout.isVisible(block)) { session.toggleHidden(block) }
            }
            if (options.isNotEmpty()) {
                Eyebrow("Show", Modifier.padding(start = 20.dp, top = 8.dp, bottom = 2.dp))
                options.forEach { option ->
                    LibSwitchRow(option.label, layout.isOn(option.key)) { on -> session.edit { it.withOption(option.key, on) } }
                }
                if (block == LibraryBlock.Status) {
                    Text("\"All\" is always there.", color = t.setSub, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
                }
                if (block == LibraryBlock.Tools) {
                    Text(
                        "With View switched off you can still change the look here, under Books.",
                        color = t.setSub,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    )
                }
            }
            if (block == LibraryBlock.Scanner) {
                Text(
                    "Hiding the card only removes it from Library. The scanner keeps working, and Settings > Book scanner is always there.",
                    color = t.setSub,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
            if (block == LibraryBlock.Search) {
                Text(
                    "The search in the top bar of the app is separate and stays.",
                    color = t.setSub,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
            if (block == LibraryBlock.Books) {
                Eyebrow("Look", Modifier.padding(start = 20.dp, top = 8.dp, bottom = 8.dp))
                PbSegmented(
                    options = listOf(LibraryView.Shelves to "Shelves", LibraryView.Frosted to "Frosted", LibraryView.Covers to "Covers"),
                    selected = session.view,
                    onSelect = { session.chooseView(it) },
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        }
    }
}

// ---- Style tab -----------------------------------------------------------------------------------

@Composable
private fun LibStyleTab(session: LibrarySession) {
    val t = pbTokens()
    val layout = session.layout
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 4.dp, bottom = 32.dp),
    ) {
        LibPreview(layout, session.view)
        Eyebrow("Books", Modifier.padding(top = 18.dp, bottom = 8.dp))
        PbSegmented(
            options = listOf(LibraryView.Shelves to "Shelves", LibraryView.Frosted to "Frosted", LibraryView.Covers to "Covers"),
            selected = session.view,
            onSelect = { session.chooseView(it) },
        )
        Eyebrow("Space between search and chips", Modifier.padding(top = 18.dp, bottom = 8.dp))
        PbSegmented(
            options = LibrarySpacing.entries.map { it to it.label },
            selected = layout.spacing,
            onSelect = { s -> session.edit { it.copy(spacing = s) } },
        )
        Box(Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(t.card)) {
            LibSwitchRow(
                "Keep the top in place",
                layout.pinned,
                sub = "The search bar and chips at the top stay put while the books scroll. Off: they scroll away with the books.",
            ) { on -> session.edit { it.copy(pinned = on) } }
        }
    }
}

// ---- small parts ---------------------------------------------------------------------------------

/** A round icon button, 44 dp. */
@Composable
private fun LibIconButton(icon: PbIconName, description: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .alpha(if (enabled) 1f else 0.3f)
            .pbTap(onClick, CircleShape, enabled = enabled, haptic = true, role = Role.Button),
        contentAlignment = Alignment.Center,
    ) { PbIcon(icon, size = 22.dp, tint = pbTokens().ink, contentDescription = description) }
}

/** A line with a label (and a small line under it) and a switch; the whole line is the target. */
@Composable
private fun LibSwitchRow(label: String, on: Boolean, modifier: Modifier = Modifier, sub: String? = null, onChange: (Boolean) -> Unit) {
    val t = pbTokens()
    Row(
        modifier
            .fillMaxWidth()
            .pbTap({ onChange(!on) }, RoundedCornerShape(16.dp), pressedScale = 0.99f, haptic = true, role = Role.Switch)
            .padding(horizontal = 20.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label, color = t.ink, fontSize = 15.sp)
            if (sub != null) Text(sub, color = t.setSub, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 2.dp))
        }
        PbSwitchMark(on)
    }
}
