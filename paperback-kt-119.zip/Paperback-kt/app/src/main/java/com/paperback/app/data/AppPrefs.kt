package com.paperback.app.data

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.Coral
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Settings → App style → Header. The three sizes of the TypeScript app, plus one with the buttons and no wordmark. */
enum class HeaderSize(val label: String) {
    Compact("Compact"),
    Regular("Regular"),
    Large("Large"),
    Minimal("Buttons only"),
}

/** Settings → App style → Navigation. */
/** Settings → App style → Book page: how a book's own page is laid out. */
enum class BookPageStyle(val label: String) {
    Classic("Classic"),
    Floating("Floating bar"),
}

enum class NavStyle(val label: String) {
    Bar("Bar"),
    Clean("Clean"),
    Dots("Dots"),
}

/** Settings → App style → Daily goal: how the goal on Stats → Activity is drawn. */
enum class GoalStyle(val label: String) {
    Ring("Ring"),
    Cover("Cover"),
    Bar("Bar"),
}

/** Settings → App style → Activity: how the chart on Stats → Activity is drawn. */
enum class ActivityStyle(val label: String) {
    Chart("Chart"),
    List("List"),
    Big("Big number"),
}

/** Settings → App style → Stats header: the Stats page's own title bar, or the same header as the other pages. */
enum class StatsHeader(val label: String) {
    Own("Stats header"),
    App("Like other pages"),
}

/** Settings → App style → Stats background: graphite cards on grey, or the app's own black / white. */
enum class StatsBackground(val label: String) {
    Gray("Grey"),
    Match("Match the app"),
}

/** Settings → App style → App background: the app's own black / white, or the grey page and cards of the Stats look on every screen. */
enum class AppBackground(val label: String) {
    Match("Black / white"),
    Gray("Grey"),
}

/** Settings → App style → More page: how the More page lays its pages out. */
enum class MoreStyle(val label: String) {
    Accordion("Accordion"),
    Bento("Bento"),
}

/**
 * A suggestion you said "not interested" to. The id keeps it from coming back, and what it was about
 * (author and subjects) teaches the recommender a little about what you do not want.
 */
class Dismissal(val id: String, val title: String, val author: String, val subjects: List<String>)

private fun writeDismissed(list: List<Dismissal>): String {
    val arr = JSONArray()
    for (d in list) {
        arr.put(
            JSONObject()
                .put("id", d.id)
                .put("title", d.title)
                .put("author", d.author)
                .put("subjects", JSONArray(d.subjects.take(12))),
        )
    }
    return arr.toString()
}

private fun readDismissed(raw: String?): List<Dismissal> {
    if (raw.isNullOrBlank()) return emptyList()
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id")
            if (id.isBlank()) return@mapNotNull null
            val subs = o.optJSONArray("subjects")
            Dismissal(
                id,
                o.optString("title"),
                o.optString("author"),
                if (subs == null) emptyList() else (0 until subs.length()).map { subs.optString(it) },
            )
        }
    } catch (e: Exception) {
        emptyList()
    }
}

private fun writeCounts(m: Map<Int, List<Int>>): String {
    val o = JSONObject()
    for ((k, v) in m) o.put(k.toString(), JSONArray(v))
    return o.toString()
}

private fun readCounts(raw: String?): Map<Int, List<Int>> {
    if (raw.isNullOrBlank()) return emptyMap()
    return try {
        val o = JSONObject(raw)
        val out = HashMap<Int, List<Int>>()
        for (key in o.keys()) {
            val k = key.toIntOrNull() ?: continue
            val a = o.optJSONArray(key) ?: continue
            out[k] = listOf(a.optInt(0, 0), a.optInt(1, 0), a.optInt(2, 0))
        }
        out
    } catch (e: Exception) {
        emptyMap()
    }
}

private fun writeNames(list: List<String>): String {
    val arr = JSONArray()
    for (n in list) arr.put(n)
    return arr.toString()
}

private fun readNames(raw: String?): List<String> {
    if (raw.isNullOrBlank()) return emptyList()
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    } catch (e: Exception) {
        emptyList()
    }
}

private fun writeFeedback(m: Map<Int, DoubleArray>): String {
    val o = JSONObject()
    for ((k, v) in m) o.put(k.toString(), JSONArray().put(v[0]).put(v[1]))
    return o.toString()
}

private fun readFeedback(raw: String?): MutableMap<Int, DoubleArray> {
    val out = HashMap<Int, DoubleArray>()
    if (raw.isNullOrBlank()) return out
    try {
        val o = JSONObject(raw)
        for (key in o.keys()) {
            val k = key.toIntOrNull() ?: continue
            val a = o.optJSONArray(key) ?: continue
            out[k] = doubleArrayOf(a.optDouble(0, 0.0), a.optDouble(1, 0.0))
        }
    } catch (e: Exception) {
        out.clear()
    }
    return out
}

/** Home: how the books in a section are drawn. Every Home section has its own pick. */
enum class HomeView(val label: String, val short: String) {
    Spines("Spines", "Spines"),
    ShelfCovers("Covers on shelf", "Shelf"),
    Frosted("Frosted shelf", "Frosted"),
    CoverRow("Cover row", "Row"),
    Grid("Cover grid", "Grid"),
    List("List", "List"),
}

/**
 * The Home sections with a view picker. [prefKey] is where the pick is saved ("recentView" is the key the
 * Recently read picker always used, so an existing pick carries over) and [views] are the looks that suit
 * the section: online catalog books have no spines to stand on a shelf.
 */
enum class HomeSection(val prefKey: String, val views: kotlin.collections.List<HomeView>, val default: HomeView) {
    Favorites("homeView_favorites", BOOK_VIEWS, HomeView.Spines),
    Recent("recentView", BOOK_VIEWS, HomeView.Spines),
    Recommended("homeView_recommended", BOOK_VIEWS, HomeView.Spines),
    WantToRead("homeView_want", CATALOG_VIEWS, HomeView.CoverRow),
    MightLike("homeView_mightLike", CATALOG_VIEWS, HomeView.CoverRow),
    /** The "Because you liked ..." rows. */
    Because("homeView_because", CATALOG_VIEWS, HomeView.CoverRow),
    /** Books you loved long ago. */
    Reread("homeView_reread", BOOK_VIEWS, HomeView.Spines),
    /** New books by authors you like. */
    NewReleases("homeView_new", CATALOG_VIEWS, HomeView.CoverRow),
    /** Books at the edge of your taste. */
    Stretch("homeView_stretch", CATALOG_VIEWS, HomeView.CoverRow),
}

private val BOOK_VIEWS = HomeView.values().toList()
private val CATALOG_VIEWS = HomeView.values().filter { it != HomeView.Spines && it != HomeView.Frosted }

/** Settings → Appearance. */
enum class ThemeMode(val label: String) {
    System("Match system"),
    Light("Light"),
    Dark("Dark"),
}

/** Reading goals (port of app/stats/goals.ts). Anything that is not a sensible number falls back to the default. */
data class Goals(
    val booksPerYear: Int = 24,
    val pagesPerDay: Int = 30,
    val minutesPerDay: Int = 30,
    val streakDays: Int = 30,
    /** Stats round 3: minutes in a week (Monday to Sunday), minutes and books in a month. */
    val weeklyMinutes: Int = 210,
    val monthlyMinutes: Int = 900,
    val monthlyBooks: Int = 2,
    /** The tiny goal: the least that still counts as showing up on a day you cannot do the whole goal. */
    val tinyMinutes: Int = 5,
    /** Rest days a week (0 to 3) that do not break the protected streak. */
    val restDays: Int = 1,
) {
    fun normalized(): Goals {
        val daily = sane(minutesPerDay, DEFAULT.minutesPerDay)
        return Goals(
            booksPerYear = sane(booksPerYear, DEFAULT.booksPerYear),
            pagesPerDay = sane(pagesPerDay, DEFAULT.pagesPerDay),
            minutesPerDay = daily,
            streakDays = sane(streakDays, DEFAULT.streakDays),
            weeklyMinutes = sane(weeklyMinutes, DEFAULT.weeklyMinutes),
            monthlyMinutes = sane(monthlyMinutes, DEFAULT.monthlyMinutes),
            monthlyBooks = sane(monthlyBooks, DEFAULT.monthlyBooks),
            // the tiny goal is never more than the daily goal
            tinyMinutes = sane(tinyMinutes, DEFAULT.tinyMinutes).coerceAtMost(daily),
            restDays = restDays.coerceIn(0, 3),
        )
    }

    companion object {
        val DEFAULT = Goals()
        private fun sane(v: Int, fallback: Int): Int = if (v in 1..99999) v else fallback
    }
}

/** The app's own choices (look and goals), kept on this device. Each one is a flow so screens update at once. */
class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("app", Context.MODE_PRIVATE)

    private val _headerSize = MutableStateFlow(
        HeaderSize.values().firstOrNull { it.name == sp.getString("headerSize", null) } ?: HeaderSize.Regular,
    )
    val headerSize: StateFlow<HeaderSize> = _headerSize.asStateFlow()

    fun setHeaderSize(value: HeaderSize) {
        _headerSize.value = value
        sp.edit().putString("headerSize", value.name).apply()
    }

    private val _bookPageStyle = MutableStateFlow(
        BookPageStyle.values().firstOrNull { it.name == sp.getString("bookPageStyle", null) } ?: BookPageStyle.Classic,
    )
    val bookPageStyle: StateFlow<BookPageStyle> = _bookPageStyle.asStateFlow()

    private val _navStyle = MutableStateFlow(
        NavStyle.values().firstOrNull { it.name == sp.getString("navStyle", null) } ?: NavStyle.Bar,
    )
    val navStyle: StateFlow<NavStyle> = _navStyle.asStateFlow()

    private val _moreStyle = MutableStateFlow(
        MoreStyle.values().firstOrNull { it.name == sp.getString("moreStyle", null) } ?: MoreStyle.Accordion,
    )
    val moreStyle: StateFlow<MoreStyle> = _moreStyle.asStateFlow()

    fun setMoreStyle(value: MoreStyle) {
        _moreStyle.value = value
        sp.edit().putString("moreStyle", value.name).apply()
    }

    private val _goalStyle = MutableStateFlow(
        GoalStyle.values().firstOrNull { it.name == sp.getString("goalStyle", null) } ?: GoalStyle.Ring,
    )
    val goalStyle: StateFlow<GoalStyle> = _goalStyle.asStateFlow()

    fun setGoalStyle(value: GoalStyle) {
        _goalStyle.value = value
        sp.edit().putString("goalStyle", value.name).apply()
    }

    private val _statsHeader = MutableStateFlow(
        StatsHeader.values().firstOrNull { it.name == sp.getString("statsHeader", null) } ?: StatsHeader.Own,
    )
    val statsHeader: StateFlow<StatsHeader> = _statsHeader.asStateFlow()

    fun setStatsHeader(value: StatsHeader) {
        _statsHeader.value = value
        sp.edit().putString("statsHeader", value.name).apply()
    }

    private val _statsBackground = MutableStateFlow(
        StatsBackground.values().firstOrNull { it.name == sp.getString("statsBackground", null) } ?: StatsBackground.Gray,
    )
    val statsBackground: StateFlow<StatsBackground> = _statsBackground.asStateFlow()

    fun setStatsBackground(value: StatsBackground) {
        _statsBackground.value = value
        sp.edit().putString("statsBackground", value.name).apply()
    }

    private val _activityStyle = MutableStateFlow(
        ActivityStyle.values().firstOrNull { it.name == sp.getString("activityStyle", null) } ?: ActivityStyle.Chart,
    )
    val activityStyle: StateFlow<ActivityStyle> = _activityStyle.asStateFlow()

    fun setActivityStyle(value: ActivityStyle) {
        _activityStyle.value = value
        sp.edit().putString("activityStyle", value.name).apply()
    }

    private val _appBackground = MutableStateFlow(
        AppBackground.values().firstOrNull { it.name == sp.getString("appBackground", null) } ?: AppBackground.Match,
    )
    val appBackground: StateFlow<AppBackground> = _appBackground.asStateFlow()

    fun setAppBackground(value: AppBackground) {
        _appBackground.value = value
        sp.edit().putString("appBackground", value.name).apply()
    }

    private val _openBookPage = MutableStateFlow(sp.getBoolean("openBookPage", true))
    /** true = tapping a book opens its page (read, timer, entries); false = it opens the reader at once. */
    val openBookPage: StateFlow<Boolean> = _openBookPage.asStateFlow()

    fun setOpenBookPage(value: Boolean) {
        _openBookPage.value = value
        sp.edit().putBoolean("openBookPage", value).apply()
    }

    private val _swipeBack = MutableStateFlow(sp.getBoolean("swipeBack", true))
    /** Swipe to the right anywhere on a page that is not a main page to go back. */
    val swipeBack: StateFlow<Boolean> = _swipeBack.asStateFlow()

    fun setSwipeBack(value: Boolean) {
        _swipeBack.value = value
        sp.edit().putBoolean("swipeBack", value).apply()
    }

    private val _swipeTabs = MutableStateFlow(sp.getBoolean("swipeTabs", false))
    /** Swipe left or right on Home, Library, Stats and Settings to move to the next or previous one. */
    val swipeTabs: StateFlow<Boolean> = _swipeTabs.asStateFlow()

    fun setSwipeTabs(value: Boolean) {
        _swipeTabs.value = value
        sp.edit().putBoolean("swipeTabs", value).apply()
    }

    private val _ratingScale = MutableStateFlow(if (sp.getInt("ratingScale", 5) == 10) 10 else 5)
    /** The number next to the stars: out of 5 or out of 10. The bar always has five stars. */
    val ratingScale: StateFlow<Int> = _ratingScale.asStateFlow()

    fun setRatingScale(value: Int) {
        val v = if (value == 10) 10 else 5
        _ratingScale.value = v
        sp.edit().putInt("ratingScale", v).apply()
    }

    private val _ratingSteps = MutableStateFlow(sp.getInt("ratingSteps", 2).let { if (it == 1 || it == 4) it else 2 })
    /** How fine a rating is: 1 = whole numbers, 2 = halves, 4 = quarters. */
    val ratingSteps: StateFlow<Int> = _ratingSteps.asStateFlow()

    fun setRatingSteps(value: Int) {
        val v = if (value == 1 || value == 4) value else 2
        _ratingSteps.value = v
        sp.edit().putInt("ratingSteps", v).apply()
    }

    /** A cover link that came with an imported book (from a Bookshelf backup). Used once, in place of whatever the catalog offers. */
    fun coverHint(id: String): String? = sp.getString("coverHint:$id", null)
    fun setCoverHint(id: String, url: String) { sp.edit().putString("coverHint:$id", url).apply() }

    private val _catalogOnline = MutableStateFlow(sp.getBoolean("catalogOnline", true))
    /** Whether Search may ask the online catalog (Open Library) for trending and recommended books. */
    val catalogOnline: StateFlow<Boolean> = _catalogOnline.asStateFlow()

    fun setCatalogOnline(value: Boolean) {
        _catalogOnline.value = value
        sp.edit().putBoolean("catalogOnline", value).apply()
    }

    /** Stats -> Reading rhythm shows this month as a calendar of covers instead of the squares. */
    private val _showRecommendations = MutableStateFlow(sp.getBoolean("homeRecommendations", true))
    /** false = Home leaves out "Recommended for you" and "Books you might like". */
    val showRecommendations: StateFlow<Boolean> = _showRecommendations.asStateFlow()

    fun setShowRecommendations(value: Boolean) {
        _showRecommendations.value = value
        sp.edit().putBoolean("homeRecommendations", value).apply()
    }

    /** The daily reading reminder: when it goes off (off / your usual hour / your own time) and your own time (minute of the day). */
    private val _reminderMode = MutableStateFlow(reminderModeOf(sp.getString("reminderMode", null)))
    val reminderMode: StateFlow<ReminderMode> = _reminderMode.asStateFlow()

    fun setReminderMode(value: ReminderMode) {
        _reminderMode.value = value
        sp.edit().putString("reminderMode", value.key).apply()
    }

    private val _reminderMinute = MutableStateFlow(sp.getInt("reminderMinute", DEFAULT_REMINDER_MINUTE).coerceIn(0, 24 * 60 - 1))
    val reminderMinute: StateFlow<Int> = _reminderMinute.asStateFlow()

    fun setReminderMinute(value: Int) {
        val clean = value.coerceIn(0, 24 * 60 - 1)
        _reminderMinute.value = clean
        sp.edit().putInt("reminderMinute", clean).apply()
    }

    /** The weekly summary notification (Sunday evening). */
    private val _weeklySummary = MutableStateFlow(sp.getBoolean("weeklySummary", false))
    val weeklySummary: StateFlow<Boolean> = _weeklySummary.asStateFlow()

    fun setWeeklySummary(value: Boolean) {
        _weeklySummary.value = value
        sp.edit().putBoolean("weeklySummary", value).apply()
    }

    private val _homePinned = MutableStateFlow(parsePinned(sp.getString("homePinned", null)))
    /** The stats pinned under "Today" on Home, in order (the goal ring and the streak until you pick your own). */
    val homePinned: StateFlow<List<PinnedStat>> = _homePinned.asStateFlow()

    fun setHomePinned(list: List<PinnedStat>) {
        val clean = parsePinned(pinnedText(list))
        _homePinned.value = clean
        sp.edit().putString("homePinned", pinnedText(clean)).apply()
    }

    private val _dismissed = MutableStateFlow(readDismissed(sp.getString("dismissedPicks", null)))
    /** Suggestions you said "not interested" to, oldest first. */
    val dismissed: StateFlow<List<Dismissal>> = _dismissed.asStateFlow()

    private fun saveDismissed(list: List<Dismissal>) {
        _dismissed.value = list
        sp.edit().putString("dismissedPicks", writeDismissed(list)).apply()
    }

    fun dismiss(d: Dismissal) {
        if (_dismissed.value.any { it.id == d.id }) return
        saveDismissed((_dismissed.value + d).takeLast(300))
    }

    /** Brings every hidden suggestion back. */
    fun clearDismissed() = saveDismissed(emptyList())

    /** Brings one hidden suggestion back (the Undo of "Not interested"). */
    fun undismiss(id: String) = saveDismissed(_dismissed.value.filterNot { it.id == id })

    private val _adventure = MutableStateFlow(sp.getInt("adventure", 1).coerceIn(0, 2))
    /** How far suggestions may go from your usual taste: 0 = not at all, 1 = a little (the default), 2 = far. */
    val adventure: StateFlow<Int> = _adventure.asStateFlow()

    fun setAdventure(value: Int) {
        val v = value.coerceIn(0, 2)
        _adventure.value = v
        sp.edit().putInt("adventure", v).apply()
    }

    fun dismissedJson(): String = writeDismissed(_dismissed.value)

    /** From a backup: adds what is not hidden yet. */
    fun restoreDismissed(raw: String?) {
        val have = _dismissed.value.map { it.id }.toSet()
        val extra = readDismissed(raw).filter { it.id !in have }
        if (extra.isNotEmpty()) saveDismissed((_dismissed.value + extra).takeLast(300))
    }

    private val _suggestionCounts = MutableStateFlow(readCounts(sp.getString("suggestionCounts", null)))
    /** By kind of suggestion ([SuggestionKinds]): how many you opened, saved and hid, as [opened, saved, hidden]. */
    val suggestionCounts: StateFlow<Map<Int, List<Int>>> = _suggestionCounts.asStateFlow()

    /** Counts what you did with a suggestion of [kind]; a negative number takes one back (an Undo). */
    @Synchronized
    fun countSuggestion(kind: Int, opened: Int = 0, saved: Int = 0, hidden: Int = 0) {
        if (kind < 0) return
        val cur = _suggestionCounts.value[kind] ?: listOf(0, 0, 0)
        val next = listOf((cur[0] + opened).coerceAtLeast(0), (cur[1] + saved).coerceAtLeast(0), (cur[2] + hidden).coerceAtLeast(0))
        _suggestionCounts.value = _suggestionCounts.value + (kind to next)
        sp.edit().putString("suggestionCounts", writeCounts(_suggestionCounts.value)).apply()
    }

    @Synchronized
    fun suggestionCountsJson(): String = writeCounts(_suggestionCounts.value)

    /** From a backup: used only when nothing has been counted here yet. */
    @Synchronized
    fun restoreSuggestionCounts(raw: String?) {
        if (_suggestionCounts.value.isNotEmpty()) return
        val restored = readCounts(raw)
        if (restored.isEmpty()) return
        _suggestionCounts.value = restored
        sp.edit().putString("suggestionCounts", writeCounts(restored)).apply()
    }

    private val _mutedSubjects = MutableStateFlow(readNames(sp.getString("mutedSubjects", null)))
    /** Subjects you asked to see less of in online suggestions, as written. */
    val mutedSubjects: StateFlow<List<String>> = _mutedSubjects.asStateFlow()

    private fun saveMuted(list: List<String>) {
        _mutedSubjects.value = list
        sp.edit().putString("mutedSubjects", writeNames(list)).apply()
    }

    fun muteSubject(name: String) {
        val clean = name.trim()
        if (clean.isEmpty() || _mutedSubjects.value.any { it.equals(clean, ignoreCase = true) }) return
        saveMuted((_mutedSubjects.value + clean).takeLast(60))
    }

    fun unmuteSubject(name: String) = saveMuted(_mutedSubjects.value.filterNot { it.equals(name, ignoreCase = true) })

    fun mutedJson(): String = writeNames(_mutedSubjects.value)

    /** From a backup: adds what is not muted yet. */
    fun restoreMuted(raw: String?) {
        val extra = readNames(raw).filter { n -> _mutedSubjects.value.none { it.equals(n, ignoreCase = true) } }
        if (extra.isNotEmpty()) saveMuted((_mutedSubjects.value + extra).takeLast(60))
    }

    // How each kind of suggestion has gone: kind -> [taken, turned away]. Only the numbers are kept, never the books.
    private val feedback: MutableMap<Int, DoubleArray> = readFeedback(sp.getString("reasonFeedback", null))

    /** A suggestion of this kind ([com.paperback.app.catalog.Ranker] KIND_*) was taken (opened, saved) or turned away. */
    @Synchronized
    fun recordFeedback(kind: Int, taken: Double, turnedAway: Double) {
        if (kind < 0) return
        val cur = feedback.getOrPut(kind) { DoubleArray(2) }
        cur[0] = (cur[0] + taken).coerceAtLeast(0.0)
        cur[1] = (cur[1] + turnedAway).coerceAtLeast(0.0)
        if (cur[0] + cur[1] > 60.0) { // old answers fade, so a change of taste shows
            cur[0] *= 0.7
            cur[1] *= 0.7
        }
        sp.edit().putString("reasonFeedback", writeFeedback(feedback)).apply()
    }

    /**
     * How much each kind of suggestion (by the kind's number, 0 to 4) has pleased you so far: 1.0 until you have
     * answered some, then between 0.75 and 1.25.
     */
    @Synchronized
    fun kindWeights(): DoubleArray = DoubleArray(5) { k ->
        val f = feedback[k]
        if (f == null) 1.0 else 0.75 + 0.5 * (f[0] + 1.0) / (f[0] + f[1] + 2.0)
    }

    @Synchronized
    fun feedbackJson(): String = writeFeedback(feedback)

    /** From a backup: used only when nothing has been learned here yet. */
    @Synchronized
    fun restoreFeedback(raw: String?) {
        if (feedback.isNotEmpty()) return
        feedback.putAll(readFeedback(raw))
        if (feedback.isNotEmpty()) sp.edit().putString("reasonFeedback", writeFeedback(feedback)).apply()
    }

    private val _rhythmCalendar = MutableStateFlow(sp.getBoolean("rhythmCalendar", false))
    val rhythmCalendar: StateFlow<Boolean> = _rhythmCalendar.asStateFlow()
    fun setRhythmCalendar(value: Boolean) {
        _rhythmCalendar.value = value
        sp.edit().putBoolean("rhythmCalendar", value).apply()
    }

    private val _libraryShelf = MutableStateFlow(sp.getBoolean("libraryShelf", true))
    /** true = books stand on shelves (spines); false = the grid of covers. */
    val libraryShelf: StateFlow<Boolean> = _libraryShelf.asStateFlow()

    fun setLibraryShelf(value: Boolean) {
        _libraryShelf.value = value
        sp.edit().putBoolean("libraryShelf", value).apply()
    }

    private val _libraryFrosted = MutableStateFlow(sp.getBoolean("libraryFrosted", false))
    /** true = the Library shows the frosted-ledge shelves, grouped by genre (wins over [libraryShelf]). */
    val libraryFrosted: StateFlow<Boolean> = _libraryFrosted.asStateFlow()

    fun setLibraryFrosted(value: Boolean) {
        _libraryFrosted.value = value
        sp.edit().putBoolean("libraryFrosted", value).apply()
    }

    private val _ledgeColor = MutableStateFlow(sp.getInt("ledgeColor", 0xFFF5A54A.toInt()))
    /** The colour of the frosted ledge, as ARGB. Set with the three RGB sliders in App style. */
    val ledgeColor: StateFlow<Int> = _ledgeColor.asStateFlow()

    fun setLedgeColor(value: Int) {
        _ledgeColor.value = value
        sp.edit().putInt("ledgeColor", value).apply()
    }

    private val _homeViews = MutableStateFlow(
        HomeSection.values().associateWith { sec ->
            HomeView.values().firstOrNull { it.name == sp.getString(sec.prefKey, null) && it in sec.views } ?: sec.default
        },
    )
    /** How each Home section looks. Spines is the original look of the book sections. */
    val homeViews: StateFlow<Map<HomeSection, HomeView>> = _homeViews.asStateFlow()

    fun setHomeView(section: HomeSection, value: HomeView) {
        if (value !in section.views) return
        _homeViews.value = _homeViews.value + (section to value)
        sp.edit().putString(section.prefKey, value.name).apply()
    }

    fun setBookPageStyle(value: BookPageStyle) {
        _bookPageStyle.value = value
        sp.edit().putString("bookPageStyle", value.name).apply()
    }

    private val _homeLayout = MutableStateFlow(sp.getString("homeLayout", null)?.let { HomeLayoutCodec.decode(it) })
    /** The Home built with Customize Home (blocks, their looks and order); null = the original Home. */
    val homeLayout: StateFlow<HomeLayout?> = _homeLayout.asStateFlow()

    fun setHomeLayout(layout: HomeLayout?) {
        _homeLayout.value = layout
        val edit = sp.edit()
        if (layout == null) edit.remove("homeLayout") else edit.putString("homeLayout", HomeLayoutCodec.encode(layout))
        edit.apply()
    }

    private val _libraryLayout = MutableStateFlow(sp.getString("libraryLayout", null)?.let { LibraryLayoutCodec.decode(it) })
    /** The Library built with Customize Library (which blocks show, their order); null = the Library as it always was. */
    val libraryLayout: StateFlow<LibraryLayout?> = _libraryLayout.asStateFlow()

    fun setLibraryLayout(layout: LibraryLayout?) {
        _libraryLayout.value = layout
        val edit = sp.edit()
        if (layout == null) edit.remove("libraryLayout") else edit.putString("libraryLayout", LibraryLayoutCodec.encode(layout))
        edit.apply()
    }

    fun setNavStyle(value: NavStyle) {
        _navStyle.value = value
        sp.edit().putString("navStyle", value.name).apply()
    }

    private val _iconStyle = MutableStateFlow(
        IconStyle.values().firstOrNull { it.name == sp.getString("iconStyle", null) } ?: IconStyle.Glassy,
    )
    /** The launcher icon. This only remembers the choice; [AppIcon.apply] switches the real icon. */
    val iconStyle: StateFlow<IconStyle> = _iconStyle.asStateFlow()

    fun setIconStyle(value: IconStyle) {
        _iconStyle.value = value
        sp.edit().putString("iconStyle", value.name).apply()
    }

    /** The accent colour as an ARGB number. Setting it also repaints the whole app (see [Accent]). */
    private val _accent = MutableStateFlow(sp.getInt("accent", Coral.toArgb()).let { 0xFF000000.toInt() or it })
    val accent: StateFlow<Int> = _accent.asStateFlow()

    init {
        Accent.color = Color(_accent.value)
    }

    fun setAccent(argb: Int) {
        val v = 0xFF000000.toInt() or argb
        _accent.value = v
        Accent.color = Color(v)
        sp.edit().putInt("accent", v).apply()
    }

    private val _themeMode = MutableStateFlow(
        ThemeMode.values().firstOrNull { it.name == sp.getString("themeMode", null) } ?: ThemeMode.System,
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    fun setThemeMode(value: ThemeMode) {
        _themeMode.value = value
        sp.edit().putString("themeMode", value.name).apply()
    }

    private val _goals = MutableStateFlow(
        Goals(
            booksPerYear = sp.getInt("goalBooks", Goals.DEFAULT.booksPerYear),
            pagesPerDay = sp.getInt("goalPages", Goals.DEFAULT.pagesPerDay),
            minutesPerDay = sp.getInt("goalMinutes", Goals.DEFAULT.minutesPerDay),
            streakDays = sp.getInt("goalStreak", Goals.DEFAULT.streakDays),
            weeklyMinutes = sp.getInt("goalWeekly", Goals.DEFAULT.weeklyMinutes),
            monthlyMinutes = sp.getInt("goalMonthMin", Goals.DEFAULT.monthlyMinutes),
            monthlyBooks = sp.getInt("goalMonthBooks", Goals.DEFAULT.monthlyBooks),
            tinyMinutes = sp.getInt("goalTiny", Goals.DEFAULT.tinyMinutes),
            restDays = sp.getInt("goalRest", Goals.DEFAULT.restDays),
        ).normalized(),
    )
    val goals: StateFlow<Goals> = _goals.asStateFlow()

    fun setGoals(value: Goals) {
        val g = value.normalized()
        _goals.value = g
        sp.edit()
            .putInt("goalBooks", g.booksPerYear)
            .putInt("goalPages", g.pagesPerDay)
            .putInt("goalMinutes", g.minutesPerDay)
            .putInt("goalStreak", g.streakDays)
            .putInt("goalWeekly", g.weeklyMinutes)
            .putInt("goalMonthMin", g.monthlyMinutes)
            .putInt("goalMonthBooks", g.monthlyBooks)
            .putInt("goalTiny", g.tinyMinutes)
            .putInt("goalRest", g.restDays)
            .apply()
    }

    private val _statsLayout = MutableStateFlow(sp.getString("statsLayout", "") ?: "")
    /** Which cards each Stats page shows and in what order (see [StatsLayout]); empty = everything as it comes. */
    val statsLayout: StateFlow<String> = _statsLayout.asStateFlow()

    fun setStatsLayout(json: String) {
        if (json == _statsLayout.value) return
        _statsLayout.value = json
        sp.edit().putString("statsLayout", json).apply()
    }

    private val _recapGenerated = MutableStateFlow(sp.getStringSet("recapGenerated", emptySet())?.toSet() ?: emptySet())
    /** The months whose recap you opened ("2026-09"). The reminder only asks about a month that is not in here. */
    val recapGenerated: StateFlow<Set<String>> = _recapGenerated.asStateFlow()

    fun addRecapGenerated(keys: Collection<String>) {
        val next = _recapGenerated.value + keys
        if (next == _recapGenerated.value) return
        _recapGenerated.value = next
        sp.edit().putStringSet("recapGenerated", next).apply()
    }

    private val _recapRemind = MutableStateFlow(sp.getBoolean("recapRemind", true))
    /** Ask on Home when last month's recap is ready. */
    val recapRemind: StateFlow<Boolean> = _recapRemind.asStateFlow()

    fun setRecapRemind(value: Boolean) {
        _recapRemind.value = value
        sp.edit().putBoolean("recapRemind", value).apply()
    }

    private val _recapSnoozeUntil = MutableStateFlow(sp.getLong("recapSnoozeUntil", 0L))
    /** "Maybe later" on the reminder: it stays quiet until this time (ms). */
    val recapSnoozeUntil: StateFlow<Long> = _recapSnoozeUntil.asStateFlow()

    fun snoozeRecap(untilMs: Long) {
        _recapSnoozeUntil.value = untilMs
        sp.edit().putLong("recapSnoozeUntil", untilMs).apply()
    }

    private val _contextPrompt = MutableStateFlow(sp.getBoolean("contextPrompt", true))
    /** Ask on Home, after a reading session, where you were and how it felt (optional; nothing is saved unless you tap Save). */
    val contextPrompt: StateFlow<Boolean> = _contextPrompt.asStateFlow()

    fun setContextPrompt(value: Boolean) {
        _contextPrompt.value = value
        sp.edit().putBoolean("contextPrompt", value).apply()
    }

    private val _contextAskedId = MutableStateFlow(sp.getLong("contextAskedId", 0L))
    /** The newest session the question was already shown or answered for; it is not asked again for it. */
    val contextAskedId: StateFlow<Long> = _contextAskedId.asStateFlow()

    fun setContextAskedId(id: Long) {
        _contextAskedId.value = id
        sp.edit().putLong("contextAskedId", id).apply()
    }

    private val _keepPrompt = MutableStateFlow(sp.getBoolean("keepPrompt", true))
    /** After you close a book, ask whether to keep the session (it is saved already; "Discard" removes it). */
    val keepPrompt: StateFlow<Boolean> = _keepPrompt.asStateFlow()

    fun setKeepPrompt(value: Boolean) {
        _keepPrompt.value = value
        sp.edit().putBoolean("keepPrompt", value).apply()
    }

    private val _keepAskedId = MutableStateFlow(sp.getLong("keepAskedId", 0L))
    /** The newest entry the keep question was answered for. */
    val keepAskedId: StateFlow<Long> = _keepAskedId.asStateFlow()

    fun setKeepAskedId(id: Long) {
        _keepAskedId.value = id
        sp.edit().putLong("keepAskedId", id).apply()
    }

    private val _recordSeenId = MutableStateFlow(sp.getLong("recordSeenId", 0L))
    /** The newest session whose record card was already shown and dismissed. */
    val recordSeenId: StateFlow<Long> = _recordSeenId.asStateFlow()

    fun setRecordSeenId(id: Long) {
        _recordSeenId.value = id
        sp.edit().putLong("recordSeenId", id).apply()
    }
}
