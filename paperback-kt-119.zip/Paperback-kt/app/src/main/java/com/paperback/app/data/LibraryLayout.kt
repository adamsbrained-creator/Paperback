package com.paperback.app.data

/*
 * Customize Library: the Library page is a few blocks one under the other (search bar, status chips, sort/view/genre
 * chips, the scanner card, and the books). This file is the model of that stack and nothing else, so it has no
 * Android in it and can be tested on a computer: the blocks, the switches inside them, the ready-made layouts and the
 * plain-text form the layout is saved in (preferences and backups).
 */

/** The parts of the Library page. [key] is what gets saved; [about] is the line under the name in the editor. */
enum class LibraryBlock(val key: String, val label: String, val about: String) {
    Search("search", "Search bar", "Find a book by title, author or genre."),
    Status("status", "Status chips", "All, Reading, Finished and Favorites."),
    Tools("tools", "Sort, view and genre", "The chips that sort the books, change the view and pick a genre."),
    Scanner("scanner", "Book scanner card", "New books found on this phone, with Review."),
    Books("books", "Books", "Your books. This is the part that scrolls, and it always comes last."),
    ;

    /** The chips and the search bar: the blocks that can stay in place while the books scroll. */
    val isControl: Boolean get() = this == Search || this == Status || this == Tools

    /** The books can't be hidden or moved; every other block can. */
    val isMovable: Boolean get() = this != Books

    companion object {
        fun of(key: String): LibraryBlock? = entries.firstOrNull { it.key == key }
    }
}

/** How the books are laid out. This is the same choice as the "View" chip, so the editor can change it too. */
enum class LibraryView(val label: String) {
    Shelves("Shelves"),
    Frosted("Frosted shelves"),
    Covers("Covers"),
    ;

    companion object {
        /** The look the two saved switches stand for (frosted wins over shelves). */
        fun of(frosted: Boolean, shelves: Boolean): LibraryView =
            if (frosted) Frosted else if (shelves) Shelves else Covers
    }
}

/** The gap between the search bar and the chip rows, in dp. */
enum class LibrarySpacing(val label: String, val dp: Int) { Compact("Compact", 4), Cozy("Cozy", 10), Roomy("Roomy", 18) }

/** One on/off switch inside a block. */
class LibraryOption(val key: String, val label: String)

object LibraryCatalog {

    val options: Map<LibraryBlock, List<LibraryOption>> = mapOf(
        LibraryBlock.Status to listOf(
            LibraryOption("status.reading", "Reading"),
            LibraryOption("status.finished", "Finished"),
            LibraryOption("status.favorites", "Favorites"),
        ),
        LibraryBlock.Tools to listOf(
            LibraryOption("tools.sort", "Sort"),
            LibraryOption("tools.view", "View"),
            LibraryOption("tools.genre", "Genre"),
        ),
    )

    fun optionsOf(block: LibraryBlock): List<LibraryOption> = options[block].orEmpty()

    val allOptionKeys: Set<String> = options.values.flatten().map { it.key }.toSet()
}

/**
 * The whole Library: the order of its blocks, which are hidden, which switches inside the chips are off, and the look
 * that applies to all of them. The default is the Library as it always was.
 */
data class LibraryLayout(
    /** Every block exactly once, the books last. */
    val order: List<LibraryBlock> = DEFAULT_ORDER,
    val hidden: Set<LibraryBlock> = emptySet(),
    /** The keys of the switches that are turned off (see [LibraryCatalog]). Everything not listed is on. */
    val off: Set<String> = emptySet(),
    val spacing: LibrarySpacing = LibrarySpacing.Cozy,
    /** The search bar and chips at the top stay in place while the books scroll. */
    val pinned: Boolean = true,
) {
    fun isOn(option: String): Boolean = option !in off

    /**
     * Whether the block is drawn. A chip row with every one of its switches off has nothing left to show, so it counts
     * as hidden.
     */
    fun isVisible(block: LibraryBlock): Boolean = when (block) {
        LibraryBlock.Books -> true
        LibraryBlock.Search, LibraryBlock.Scanner -> block !in hidden
        LibraryBlock.Status, LibraryBlock.Tools -> block !in hidden && LibraryCatalog.optionsOf(block).any { isOn(it.key) }
    }

    /** The blocks that are drawn, top to bottom (the books last). */
    val shown: List<LibraryBlock> get() = order.filter { isVisible(it) }

    /** The blocks that stay above the scrolling part: the controls at the very top, up to the first block that is not one. */
    val pinnedBlocks: List<LibraryBlock> get() = if (pinned) shown.takeWhile { it.isControl } else emptyList()

    /** The blocks that scroll away with the books (not counting the books). */
    val scrollingBlocks: List<LibraryBlock> get() = shown.drop(pinnedBlocks.size).filter { it != LibraryBlock.Books }

    /** How many blocks are hidden, counting the chip rows that have nothing left in them. */
    val hiddenCount: Int get() = LibraryBlock.entries.count { it.isMovable && !isVisible(it) }

    fun hiding(block: LibraryBlock, hide: Boolean): LibraryLayout =
        if (!block.isMovable) this else copy(hidden = if (hide) hidden + block else hidden - block)

    fun withOption(key: String, on: Boolean): LibraryLayout {
        if (key !in LibraryCatalog.allOptionKeys) return this
        return copy(off = if (on) off - key else off + key)
    }

    /** Moves the block at index [from] to index [to] of [order]. The books stay last. */
    fun moving(from: Int, to: Int): LibraryLayout {
        val last = order.lastIndex
        if (from !in 0 until last || to !in 0 until last || from == to) return this
        return copy(order = order.toMutableList().apply { add(to, removeAt(from)) })
    }

    /** The same layout, repaired if it came from somewhere odd: every block once, the books last, no hidden books, no unknown switches. */
    fun normalized(): LibraryLayout {
        val movable = order.filter { it.isMovable }.distinct()
        val full = movable + LibraryBlock.entries.filter { it.isMovable && it !in movable } + LibraryBlock.Books
        return copy(order = full, hidden = hidden - LibraryBlock.Books, off = off.filter { it in LibraryCatalog.allOptionKeys }.toSet())
    }

    companion object {
        val DEFAULT_ORDER: List<LibraryBlock> = listOf(
            LibraryBlock.Search, LibraryBlock.Status, LibraryBlock.Tools, LibraryBlock.Scanner, LibraryBlock.Books,
        )

        /** The Library as it was before there was a constructor. */
        val ORIGINAL = LibraryLayout()
    }
}

/** A ready-made Library to start from. */
class LibraryPreset(val key: String, val name: String, val layout: LibraryLayout) {
    /** Whether [other] shows and hides the same things as this preset (the spacing and pinning don't count). */
    fun matches(other: LibraryLayout): Boolean {
        val mine = layout.normalized()
        val theirs = other.normalized()
        return mine.order == theirs.order && mine.hidden == theirs.hidden && mine.off == theirs.off
    }

    /** This preset's blocks, with [from]'s spacing and pinning kept. */
    fun appliedTo(from: LibraryLayout): LibraryLayout = layout.copy(spacing = from.spacing, pinned = from.pinned).normalized()
}

object LibraryPresets {
    val all: List<LibraryPreset> = listOf(
        LibraryPreset("classic", "As it was", LibraryLayout()),
        LibraryPreset("tidy", "No scanner card", LibraryLayout(hidden = setOf(LibraryBlock.Scanner))),
        LibraryPreset("search", "Just search", LibraryLayout(hidden = setOf(LibraryBlock.Status, LibraryBlock.Tools, LibraryBlock.Scanner))),
        LibraryPreset("books", "Only books", LibraryLayout(hidden = setOf(LibraryBlock.Search, LibraryBlock.Status, LibraryBlock.Tools, LibraryBlock.Scanner))),
    )
}

/** Saves a [LibraryLayout] as plain text, one line per setting, written by hand so it can be tested without a phone. */
object LibraryLayoutCodec {

    private const val VERSION = "pl1"

    fun encode(layout: LibraryLayout): String = buildString {
        appendLine(VERSION)
        appendLine("order=" + layout.order.joinToString(",") { it.key })
        appendLine("hidden=" + layout.hidden.joinToString(",") { it.key })
        appendLine("off=" + layout.off.joinToString(","))
        appendLine("spacing=${layout.spacing.name}")
        appendLine("pinned=${if (layout.pinned) 1 else 0}")
    }

    /** The layout in [text], or null when the text is not one this app wrote. */
    fun decode(text: String): LibraryLayout? {
        val lines = text.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
        if (lines.firstOrNull() != VERSION) return null
        var layout = LibraryLayout()
        for (line in lines.drop(1)) {
            val at = line.indexOf('=')
            if (at < 0) continue
            val key = line.substring(0, at)
            val value = line.substring(at + 1)
            val parts = value.split(',').filter { it.isNotEmpty() }
            when (key) {
                "order" -> layout = layout.copy(order = parts.mapNotNull { LibraryBlock.of(it) })
                "hidden" -> layout = layout.copy(hidden = parts.mapNotNull { LibraryBlock.of(it) }.toSet())
                "off" -> layout = layout.copy(off = parts.toSet())
                "spacing" -> LibrarySpacing.entries.firstOrNull { it.name == value }?.let { layout = layout.copy(spacing = it) }
                "pinned" -> layout = layout.copy(pinned = value == "1")
            }
        }
        return layout.normalized()
    }
}
