package com.paperback.app.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.LocalPbDark
import com.paperback.app.ui.theme.LocalPbTokensOverride
import com.paperback.app.ui.theme.pbTokens
import com.paperback.app.ui.theme.statsGrayTokens
import com.paperback.app.data.StatsBackground
import com.paperback.app.data.AppBackground
import com.paperback.app.data.StatsHeader
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.width
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.height
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Brush
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape as NavPillShape
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.layout
import kotlin.math.roundToInt as navRound
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.AppViewModel
import com.paperback.app.data.Authors
import com.paperback.app.data.Book
import com.paperback.app.scan.ScanNeed
import com.paperback.app.data.buildShelf
import com.paperback.app.data.pendingRecap
import com.paperback.app.data.recapKey
import com.paperback.app.data.recapMonthOf
import com.paperback.app.data.recapRows
import com.paperback.app.data.BookSort
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.NavStyle
import com.paperback.app.data.Similar
import com.paperback.app.data.Tags
import com.paperback.app.data.Stats
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.roundToInt

@Composable
fun PaperbackRoot(
    vm: AppViewModel,
    onPickBooks: () -> Unit,
    onOpenReader: () -> Unit,
    onSaveBackup: () -> Unit,
    onPickBackup: () -> Unit,
    onPickCover: (Book) -> Unit,
    onShareText: (String) -> Unit,
    /** Saves a file the person picks: file name, MIME type, text (stats exports). */
    onExport: (fileName: String, mime: String, text: String) -> Unit = { _, _, _ -> },
    /** The book scanner: ask Android for "All files access", for a folder to look in, and for permission to show notifications. */
    onRequestAllFiles: () -> Unit = {},
    onPickScanFolder: () -> Unit = {},
    onRequestNotifications: () -> Unit = {},
) {
    val books by vm.books.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val statsLayout by vm.statsLayout.collectAsStateWithLifecycle()
    val rawSessions by vm.rawSessions.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val reflow by vm.reflow.collectAsStateWithLifecycle()
    // a scan takes minutes to read; the screen stays on meanwhile, because the phone may stop the work when it sleeps
    val view = LocalView.current
    val reflowing = reflow != null
    DisposableEffect(reflowing) {
        view.keepScreenOn = reflowing
        onDispose { view.keepScreenOn = false }
    }
    val message by vm.message.collectAsStateWithLifecycle()
    val headerSize by vm.headerSize.collectAsStateWithLifecycle()
    val themeMode by vm.themeMode.collectAsStateWithLifecycle()
    val navStyle by vm.navStyle.collectAsStateWithLifecycle()
    val bookPageStyle by vm.bookPageStyle.collectAsStateWithLifecycle()
    val moreStyle by vm.moreStyle.collectAsStateWithLifecycle()
    val iconStyle by vm.iconStyle.collectAsStateWithLifecycle()
    val libraryShelf by vm.libraryShelf.collectAsStateWithLifecycle()
    val libraryFrosted by vm.libraryFrosted.collectAsStateWithLifecycle()
    val libraryLayout by vm.libraryLayout.collectAsStateWithLifecycle()
    val ledgeColor by vm.ledgeColor.collectAsStateWithLifecycle()
    val rhythmCalendar by vm.rhythmCalendar.collectAsStateWithLifecycle()
    val goalStyle by vm.goalStyle.collectAsStateWithLifecycle()
    val statsHeader by vm.statsHeader.collectAsStateWithLifecycle()
    val statsBackground by vm.statsBackground.collectAsStateWithLifecycle()
    val appBackground by vm.appBackground.collectAsStateWithLifecycle()
    val activityStyle by vm.activityStyle.collectAsStateWithLifecycle()
    val homeViews by vm.homeViews.collectAsStateWithLifecycle()
    val homePinned by vm.homePinned.collectAsStateWithLifecycle()
    val reminderMode by vm.reminderMode.collectAsStateWithLifecycle()
    val weeklySummary by vm.weeklySummary.collectAsStateWithLifecycle()
    val reminderMinute by vm.reminderMinute.collectAsStateWithLifecycle()
    val showRecommendations by vm.showRecommendations.collectAsStateWithLifecycle()
    val accent by vm.accent.collectAsStateWithLifecycle()
    val goals by vm.goals.collectAsStateWithLifecycle()
    val backupCounts by vm.backupCounts.collectAsStateWithLifecycle()
    val pendingBackup by vm.pendingBackup.collectAsStateWithLifecycle()
    val collections by vm.collections.collectAsStateWithLifecycle()
    val membership by vm.membership.collectAsStateWithLifecycle()
    val contextPrompt by vm.contextPrompt.collectAsStateWithLifecycle()
    val contextAskedId by vm.contextAskedId.collectAsStateWithLifecycle()
    val highlights by vm.allHighlights.collectAsStateWithLifecycle()
    val savedWords by vm.savedWords.collectAsStateWithLifecycle()
    val lookups by vm.lookups.collectAsStateWithLifecycle()
    val bookmarks by vm.allBookmarks.collectAsStateWithLifecycle()
    val recentSearches by vm.recentSearches.collectAsStateWithLifecycle()
    val catalogOpen by vm.discover.browser.collectAsStateWithLifecycle()
    val wishlist by vm.wishlist.collectAsStateWithLifecycle()
    val openBookPage by vm.openBookPage.collectAsStateWithLifecycle()
    val swipeBack by vm.swipeBack.collectAsStateWithLifecycle()
    val swipeTabs by vm.swipeTabs.collectAsStateWithLifecycle()
    val ratingScale by vm.ratingScale.collectAsStateWithLifecycle()
    val ratingSteps by vm.ratingSteps.collectAsStateWithLifecycle()
    val timerState by vm.timer.state.collectAsStateWithLifecycle()
    val recapGenerated by vm.recapGenerated.collectAsStateWithLifecycle()
    val recapRemind by vm.recapRemind.collectAsStateWithLifecycle()
    val recapSnoozeUntil by vm.recapSnoozeUntil.collectAsStateWithLifecycle()
    // The optional "where were you, how did it feel" question: the newest reader session of the last three hours, once
    val recordSeenId by vm.recordSeenId.collectAsStateWithLifecycle()
    val sessionRecords = remember(sessions, recordSeenId) {
        com.paperback.app.data.sessionRecords(sessions, java.time.ZoneId.systemDefault(), System.currentTimeMillis())?.takeIf { it.sessionId > recordSeenId }
    }
    val keepPrompt by vm.keepPrompt.collectAsStateWithLifecycle()
    val keepAskedId by vm.keepAskedId.collectAsStateWithLifecycle()
    val keepRows = remember(rawSessions, keepPrompt, keepAskedId) {
        if (!keepPrompt) emptyList() else com.paperback.app.data.pendingKeep(rawSessions, keepAskedId, System.currentTimeMillis())
    }
    val contextSession = remember(sessions, contextPrompt, contextAskedId) {
        if (!contextPrompt) null else sessions
            .filter { it.kind == com.paperback.app.data.SessionKind.READ && !it.manual && it.seconds >= 120 && it.place == 0 && it.mood == 0 }
            .maxByOrNull { it.startMs }
            ?.takeIf { it.id > contextAskedId && System.currentTimeMillis() - (it.startMs + it.seconds * 1000L) < 3 * 60 * 60 * 1000L }
    }

    // Where we are: a stack of screens, kept as text so it survives rotation. The first is a tab.
    // An entry is a Dest name ("Settings") or a screen about one thing: "Book:<id>", "Collection:<id>", "NotesOf:<bookId>".
    var stackRaw by rememberSaveable { mutableStateOf(Dest.Home.name) }
    val stack = remember(stackRaw) { stackRaw.split(',').filter { it.isNotEmpty() }.ifEmpty { listOf(Dest.Home.name) } }
    val route = stack.last()
    val kind = route.substringBefore(':')
    val arg = route.substringAfter(':', "")
    val simple: Dest? = Dest.values().firstOrNull { it.name == route }
    // Which menu entry to light up. A book page counts as Library, a collection page as Collections, a book's notes as Notes.
    val current: Dest = simple ?: when (kind) {
        "Collection" -> Dest.Collections
        "NotesOf" -> Dest.Notes
        "Tag" -> Dest.Genres
        "Author" -> Dest.Authors
        "Shelf", "Calendar", "Recap", "Recaps" -> Dest.Stats
        "Catalog", "Browse" -> Dest.Search
        else -> Dest.Library
    }
    val onTabScreen = simple?.isTab == true
    var searchQuery by rememberSaveable { mutableStateOf("") } // kept here so Back from a result returns to the same search
    var menuOpen by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.consumeMessage()
        }
    }
    val undoMessage by vm.undoMessage.collectAsStateWithLifecycle()
    LaunchedEffect(undoMessage) {
        undoMessage?.let {
            val result = snackbar.showSnackbar(it.text, actionLabel = "Undo", duration = SnackbarDuration.Long)
            if (result == SnackbarResult.ActionPerformed) it.undo()
            vm.consumeUndo()
        }
    }
    LaunchedEffect(current) {
        if (current == Dest.Backup) vm.refreshBackupCounts()
    }

    val open: (Book) -> Unit = { book -> vm.open(book, onOpenReader) }
    val pop: () -> Unit = { stackRaw = stack.dropLast(1).joinToString(",").ifEmpty { Dest.Home.name } }

    // Tabs replace each other; every other screen is pushed on top so Back returns to where you were.
    val navigate: (Dest) -> Unit = { dest ->
        menuOpen = false
        when {
            // Main pages keep a history too, so Back (or a swipe) returns to where you were instead of closing the app.
            // With the bottom bar, Home is the one place Back returns to.
            dest.isTab -> {
                val next = when {
                    dest.name == route -> stack
                    (navStyle == NavStyle.Bar || navStyle == NavStyle.Dots) -> if (dest == Dest.Home) listOf(Dest.Home.name) else listOf(Dest.Home.name, dest.name)
                    stack.contains(dest.name) -> stack.take(stack.indexOf(dest.name) + 1)
                    else -> (stack + dest.name).takeLast(30)
                }
                stackRaw = next.joinToString(",")
            }
            dest.name == route -> Unit
            stack.contains(dest.name) -> stackRaw = stack.take(stack.indexOf(dest.name) + 1).joinToString(",")
            else -> stackRaw = "$stackRaw,${dest.name}"
        }
    }
    val push: (String) -> Unit = { next ->
        menuOpen = false
        if (next != route) stackRaw = "$stackRaw,$next"
    }
    val details: (Book) -> Unit = { book -> push("Book:${book.id}") }
    // A tap on a book goes to its page (or straight into the reader, if you chose that in App style).
    val tapBook: (Book) -> Unit = { book -> if (openBookPage) details(book) else open(book) }
    // A genre or an author is part of the route, so it is encoded (the back-stack is comma-separated text).
    val openTag: (String) -> Unit = { tag -> push("Tag:${Uri.encode(tag)}") }
    val openAuthor: (String) -> Unit = { name -> push("Author:${Uri.encode(name)}") }
    // The online catalog: a book page is "Catalog:<id>", a "see all" grid is "Browse:<kind>~<encoded value>".
    val openCatalogBook: (CatalogBook) -> Unit = { b ->
        vm.catalog.remember(listOf(b))
        push("Catalog:${b.id}")
    }
    val browse: (String, String) -> Unit = { k, v ->
        if (k == "want") navigate(Dest.WantToRead) else push("Browse:$k~${Uri.encode(v)}")
    }
    val soon: () -> Unit = {
        menuOpen = false
        vm.say("Coming soon")
    }
    val openMenu: () -> Unit = { menuOpen = true }
    val search: () -> Unit = { navigate(Dest.Search) }

    // ---- the book scanner ----
    val scanner = vm.scanner
    val scanNeed: (ScanNeed) -> Unit = { need ->
        when (need) {
            ScanNeed.AllFiles -> onRequestAllFiles()
            ScanNeed.Folder -> onPickScanFolder()
            ScanNeed.None -> Unit
        }
    }
    // A notification ("12 new books found") asks for the scanner's results screen
    val scannerRequest by vm.scannerRequest.collectAsStateWithLifecycle()
    LaunchedEffect(scannerRequest) {
        if (scannerRequest) {
            scanner.openResults()
            navigate(Dest.Scanner)
            vm.consumeScannerRequest()
        }
    }

    // ---- monthly recaps ----
    // A recap that wants to open Stats -> History on a day leaves the day here; StatsScreen picks it up.
    var historyRequest by remember { mutableStateOf<LocalDate?>(null) }
    // A Stats page asked for from outside (a tile on Home), by its name; StatsScreen shows it and clears this.
    var statsPageRequest by remember { mutableStateOf<String?>(null) }
    val recapHost = RecapHost(
        generated = recapGenerated,
        remind = recapRemind,
        onRemind = vm::setRecapRemind,
        onOpen = { m ->
            // Opening a finished month's recap is what generates it; the month still going is only a preview.
            if (m != YearMonth.now()) vm.markRecapGenerated(recapKey(m))
            push("Recap:${recapKey(m)}")
        },
    )
    // Last month, when it has reading and its recap was not opened yet (and the reminder is on).
    val pendingRecapRow = remember(books, sessions, recapGenerated, recapRemind) {
        if (!recapRemind) {
            null
        } else {
            val zone = ZoneId.systemDefault()
            val now = System.currentTimeMillis()
            pendingRecap(recapRows(books, sessions, zone, now), recapGenerated, now, zone)
        }
    }
    val discover: () -> Unit = { navigate(Dest.Discover) }

    val goBack: () -> Unit = {
        when {
            menuOpen -> menuOpen = false
            // inside a catalog, Back goes back one page of the catalog first
            current == Dest.Discover && catalogOpen != null -> vm.discover.back()
            current == Dest.Scanner && scanner.back() -> Unit
            else -> pop()
        }
    }
    BackHandler(enabled = menuOpen || stack.size > 1, onBack = goBack)

    // Swipes: right goes back (or to the previous main page), left goes to the next main page.
    val mainPages = listOf(Dest.Home, Dest.Library, Dest.Stats, Dest.Settings)
    val canGoBack = stack.size > 1 || (current == Dest.Discover && catalogOpen != null)
    val swipeRight: (() -> Unit)? = when {
        onTabScreen && (swipeTabs || navStyle == NavStyle.Dots) -> mainPages.getOrNull(mainPages.indexOf(current) - 1)?.let { prev -> { navigate(prev) } }
        swipeBack && canGoBack -> goBack
        else -> null
    }
    val swipeLeft: (() -> Unit)? =
        if (onTabScreen && (swipeTabs || navStyle == NavStyle.Dots)) mainPages.getOrNull(mainPages.indexOf(current) + 1)?.let { next -> { navigate(next) } } else null

    val dismissed by vm.dismissed.collectAsStateWithLifecycle()
    val mutedSubjects by vm.mutedSubjects.collectAsStateWithLifecycle()
    val wishlistOutcomes by vm.wishlistOutcomes.collectAsStateWithLifecycle()
    val suggestionCounts by vm.suggestionCounts.collectAsStateWithLifecycle()
    val hiddenIds = remember(dismissed) { dismissed.map { it.id }.toSet() }
    val marks = remember(highlights) { com.paperback.app.data.Implicit.highlightCounts(highlights) }
    val recommended = remember(books, hiddenIds, marks) { Similar.recommend(books, hidden = hiddenIds, marks = marks) }
    val rereads = remember(books, hiddenIds) { Similar.rereads(books, hiddenIds) }
    val adventure by vm.adventure.collectAsStateWithLifecycle()
    // "Pick my next read" asks again when a mood is chosen; the hour of the day is read when it is asked
    val pickNext = remember(books, hiddenIds, marks, sessions) {
        { mood: Int ->
            Similar.pickNext(books, hiddenIds, marks = marks, sessions = sessions, mood = mood, hour = java.time.LocalTime.now().hour)
        }
    }
    val pickMoods = remember(sessions) {
        sessions.filter { it.mood > 0 }.groupBy { it.mood }.filter { (_, l) -> l.sumOf { it.seconds } >= 1200 }.keys.sorted()
    }
    // Home, as the app shows it (no preview) and as Customize Home shows it: the layout being edited, inert, with frames.
    val homeLayout by vm.homeLayout.collectAsStateWithLifecycle()
    val homeScreen: @Composable (com.paperback.app.data.HomeLayout?, HomePreview?) -> Unit = { homeDraft, homePreview ->
        HomeScreen(books, sessions, recommended, goalMinutes = goals.minutesPerDay, tinyMinutes = goals.tinyMinutes, goals = goals, pinned = homePinned, onPinned = vm::setHomePinned, onOpenGoals = { navigate(Dest.Goals) }, onOpenStat = { stat -> statsPageRequest = statsPageFor(stat); navigate(Dest.Stats) }, onOpen = tapBook, onRead = open, onDetails = details, onImport = onPickBooks, onDiscover = discover, catalog = vm.catalog, wishlist = wishlist, onOpenCatalogBook = openCatalogBook, onBrowse = browse, homeViews = homeViews, onHomeView = vm::setHomeView, showRecommendations = showRecommendations, onDismissRecommended = vm::dismissRecommended, pickNext = pickNext, pickMoods = pickMoods, rereads = rereads, recap = pendingRecapRow, onOpenRecap = { pendingRecapRow?.let { recapHost.onOpen(it.month) } }, contextSession = contextSession, contextTitle = contextSession?.let { s -> books.firstOrNull { it.id == s.bookId }?.title }.orEmpty(), onContextSave = vm::saveSessionContext, onContextDismiss = vm::dismissContext, onContextNever = { vm.setContextPrompt(false) }, records = sessionRecords, onRecordsDone = vm::dismissRecords, quote = com.paperback.app.data.quoteOfTheDay(highlights, java.time.LocalDate.now()), quoteBookTitle = com.paperback.app.data.quoteOfTheDay(highlights, java.time.LocalDate.now())?.let { q -> books.firstOrNull { it.id == q.bookId }?.title }.orEmpty(), layout = homeDraft, onCustomize = if (homePreview == null) ({ vm.homeSession = HomeSession(homeLayout) }) else null, onOpenLibrary = { navigate(Dest.Library) }, onOpenStats = { navigate(Dest.Stats) }, preview = homePreview)
    }
    val today = LocalDate.now()
    val secondsToday = remember(sessions) { Stats.secondsByDay(sessions)[today] ?: 0L }
    val reader = vm.readerSettings

    // Grey on every screen (Settings -> App style -> App background), or on the Stats tab alone (Stats background).
    val darkNow = LocalPbDark.current
    val accentNow = Accent.color
    val statsGray = appBackground == AppBackground.Gray || (simple == Dest.Stats && statsBackground == StatsBackground.Gray)
    val grayTokens = if (statsGray) remember(darkNow, accentNow) { statsGrayTokens(darkNow, accentNow) } else null
    val pageBg = grayTokens?.bg ?: MaterialTheme.colorScheme.background

    // The bottom bar floats: it slides away and fades while the page scrolls down, and comes back on the first scroll up.
    var navShown by remember { mutableStateOf(true) }
    LaunchedEffect(current) { navShown = true }
    // Every time the page changes the new one fades in and rises a few dp, so a tap on the menu or a tab never just snaps.
    val pageIn = remember { Animatable(1f) }
    LaunchedEffect(route) {
        pageIn.snapTo(0f)
        pageIn.animateTo(1f, tween(PB_MS_ENTER, easing = PbEaseOut))
    }
    val navAnim = animateFloatAsState(if (navShown) 1f else 0f, tween(260), label = "navShown")
    val navScroll = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) navShown = false else if (available.y > 6f) navShown = true
                return Offset.Zero
            }
        }
    }

    CompositionLocalProvider(LocalPbTokensOverride provides grayTokens, LocalLedgeColor provides Color(ledgeColor)) {
    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = pageBg,
            snackbarHost = {
                SnackbarHost(snackbar) { data ->
                    val t = pbTokens()
                    Snackbar(
                        data,
                        shape = RoundedCornerShape(22.dp),
                        containerColor = t.ink,
                        contentColor = t.bg,
                        actionColor = MaterialTheme.colorScheme.primary,
                    )
                }
            },
        ) { inner ->
            SwipeHost(
                enabled = !menuOpen,
                onSwipeRight = swipeRight,
                onSwipeLeft = swipeLeft,
                modifier = Modifier.fillMaxSize().nestedScroll(navScroll).padding(inner),
            ) {
                // The tab bar floats over the page instead of taking a strip of it: no solid block, the page fades into it,
                // and it slides down and fades away while you scroll down.
                if (onTabScreen && navStyle == NavStyle.Bar && (navShown || navAnim.value > 0.01f)) {
                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .zIndex(1f)
                            .fillMaxWidth()
                            .graphicsLayer {
                                alpha = navAnim.value
                                translationY = (1f - navAnim.value) * 48.dp.toPx()
                            },
                    ) {
                        // a short soft fade on top, so the page does not end in a hard line; behind the icons it is solid
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(32.dp)
                                .background(Brush.verticalGradient(listOf(Color.Transparent, pageBg))),
                        )
                        Box(Modifier.fillMaxWidth().background(pageBg)) {
                        NavigationBar(containerColor = Color.Transparent, tonalElevation = 0.dp, windowInsets = WindowInsets(0, 0, 0, 0)) {
                            val colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = grayTokens?.card ?: MaterialTheme.colorScheme.surfaceVariant,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            NavigationBarItem(
                                selected = current == Dest.Home, onClick = { navigate(Dest.Home) }, colors = colors,
                                icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                                label = { Text("Home") },
                            )
                            NavigationBarItem(
                                selected = current == Dest.Library, onClick = { navigate(Dest.Library) }, colors = colors,
                                icon = {
                                    LibraryGlyph(
                                        if (current == Dest.Library) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                },
                                label = { Text("Library") },
                            )
                            NavigationBarItem(
                                selected = current == Dest.Stats, onClick = { navigate(Dest.Stats) }, colors = colors,
                                icon = {
                                    StatsGlyph(
                                        if (current == Dest.Stats) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                },
                                label = { Text("Stats") },
                            )
                            NavigationBarItem(
                                selected = current == Dest.Settings, onClick = { navigate(Dest.Settings) }, colors = colors,
                                icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                                label = { Text("Settings") },
                            )
                        }
                        }
                    }
                }
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        alpha = 0.35f + 0.65f * pageIn.value
                        translationY = (1f - pageIn.value) * 14.dp.toPx()
                    },
                ) {
                // Dots style: just the name of the page and four dots. Swipe sideways (always on in this style) or tap a dot.
                if (onTabScreen && navStyle == NavStyle.Dots && (navShown || navAnim.value > 0.01f)) {
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .zIndex(1f)
                            .padding(bottom = 10.dp)
                            .graphicsLayer {
                                alpha = navAnim.value
                                translationY = (1f - navAnim.value) * 40.dp.toPx()
                            }
                            .clip(NavPillShape(22.dp))
                            .background(pageBg.copy(alpha = 0.92f))
                            .padding(horizontal = 14.dp),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                current.name,
                                modifier = Modifier.padding(top = 8.dp),
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                            )
                            // Hold on the dots and slide: the page under your finger opens, moving exactly as fast as you do.
                            val navigateNow by rememberUpdatedState(navigate)
                            val currentNow by rememberUpdatedState(current)
                            val haptic = LocalHapticFeedback.current
                            Row(
                                modifier = Modifier
                                    .pointerInput(Unit) {
                                        var last = -1
                                        detectHorizontalDragGestures(
                                            onDragStart = { last = -1 },
                                            onDragEnd = { last = -1 },
                                            onDragCancel = { last = -1 },
                                            onHorizontalDrag = { change, _ ->
                                                val count = mainPages.size
                                                val i = ((change.position.x / size.width) * count).toInt().coerceIn(0, count - 1)
                                                if (i != last) {
                                                    last = i
                                                    if (mainPages[i] != currentNow) {
                                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                        navigateNow(mainPages[i])
                                                    }
                                                }
                                            },
                                        )
                                    }
                                    .padding(horizontal = 16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                mainPages.forEach { page ->
                                    val on = page == current
                                    val w = animateDpAsState(if (on) 22.dp else 6.dp, tween(200), label = "dotW")
                                    Box(
                                        Modifier
                                            .height(36.dp)
                                            .width(if (on) 40.dp else 30.dp)
                                            .clickable { navigate(page) },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Box(
                                            Modifier
                                                .width(w.value)
                                                .height(6.dp)
                                                .clip(NavPillShape(3.dp))
                                                .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f)),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                when (simple) {
                    Dest.Home, Dest.Library, Dest.Stats -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                      Column(Modifier.widthIn(max = 560.dp).fillMaxSize()) {
                        if (current == Dest.Stats && statsHeader == StatsHeader.Own) {
                            StatsOwnHeader(
                                onMenu = openMenu,
                                onSearch = search,
                                onCalendar = { push("Calendar") },
                                modifier = Modifier.padding(horizontal = 20.dp).padding(top = 4.dp),
                            )
                        } else {
                            PageHeader(
                                label = when (current) {
                                    Dest.Home -> "Home"
                                    Dest.Library -> "Library"
                                    else -> "Stats"
                                },
                                size = headerSize,
                                chip = if (current == Dest.Library) "${books.size} ${if (books.size == 1) "book" else "books"}" else null,
                                onMenu = openMenu,
                                onSearch = search,
                                modifier = Modifier.padding(horizontal = 20.dp).padding(top = 4.dp),
                            )
                        }
                        Box(Modifier.weight(1f)) {
                            when (current) {
                                Dest.Home -> homeScreen(homeLayout, null)
                                Dest.Library -> LibraryScreen(
                                    books = books,
                                    onOpen = tapBook,
                                    onDetails = details,
                                    onImport = onPickBooks,
                                    onDiscover = discover,
                                    onToggleFavorite = vm::toggleFavorite,
                                    onToggleFinished = vm::toggleFinished,
                                    onRemove = vm::remove,
                                    shelfView = libraryShelf,
                                    onShelfView = vm::setLibraryShelf,
                                    frosted = libraryFrosted,
                                    onFrosted = vm::setLibraryFrosted,
                                    layout = libraryLayout ?: com.paperback.app.data.LibraryLayout.ORIGINAL,
                                    onCustomize = {
                                        vm.librarySession = LibrarySession(libraryLayout, com.paperback.app.data.LibraryView.of(libraryFrosted, libraryShelf))
                                    },
                                    scanCard = {
                                        ScanEntryCard(
                                            scanner = scanner,
                                            onOpen = { navigate(Dest.Scanner) },
                                            onNeed = scanNeed,
                                            onChooseFolders = {
                                                scanner.store.setWholePhone(false)
                                                scanner.openBefore()
                                                navigate(Dest.Scanner)
                                            },
                                            onSettings = {
                                                scanner.openSettings()
                                                navigate(Dest.Scanner)
                                            },
                                        )
                                    },
                                )
                                else -> StatsScreen(
                                    books = books,
                                    sessions = sessions,
                                    goals = goals,
                                    highlights = highlights,
                                    onOpenBook = details,
                                    onOpenGoals = { navigate(Dest.Goals) },
                                    loadGoalDays = { vm.goalDays() },
                                    loadReadings = { vm.readings() },
                                    statsLayout = statsLayout,
                                    onStatsLayout = vm::setStatsLayout,
                                    onExport = onExport,
                                    collections = collections,
                                    membership = membership,
                                    wishlist = wishlist,
                                    wishlistAddedAt = vm::wishlistAddedAt,
                                    wishlistOutcomes = wishlistOutcomes,
                                    onShareText = onShareText,
                                    onOpenNotes = { id -> if (id == null) navigate(Dest.Notes) else push("NotesOf:$id") },
                                    onOpenFinished = { navigate(Dest.Finished) },
                                    onOpenShelf = { kind -> push("Shelf:$kind") },
                                    onOpenDictionary = { navigate(Dest.Dictionary) },
                                    savedWords = savedWords,
                                    onOpenPage = { navigate(it) },
                                    onOpenAuthor = openAuthor,
                                    onSetStatus = vm::setStatus,
                                    rhythmCalendar = rhythmCalendar,
                                    goalStyle = goalStyle,
                                    activityStyle = activityStyle,
                                    onRhythmCalendar = vm::setRhythmCalendar,
                                    onOpenCalendar = { push("Calendar") },
                                    recaps = recapHost,
                                    historyRequest = historyRequest,
                                    onHistoryConsumed = { historyRequest = null },
                                    pageRequest = statsPageRequest,
                                    onPageConsumed = { statsPageRequest = null },
                                )
                            }
                        }
                      }
                    }

                    Dest.Settings -> SettingsScreen(
                        headerSize = headerSize,
                        secondsToday = secondsToday,
                        goalMinutes = goals.minutesPerDay,
                        readerValue = "${com.paperback.app.reader.ReaderThemes.name(reader.theme)} · ${(reader.fontSize * 100).roundToInt()}%",
                        appearanceValue = themeMode.label,
                        navLabel = navStyle.label,
                        version = rememberAppVersion(),
                        onMenu = openMenu,
                        onSearch = search,
                        onOpen = { d -> if (d == Dest.Scanner) scanner.openSettings(); navigate(d) },
                    )

                    Dest.AppStyle -> AppStyleScreen(headerSize, vm::setHeaderSize, navStyle, vm::setNavStyle, openBookPage, vm::setOpenBookPage, swipeBack, vm::setSwipeBack, swipeTabs, vm::setSwipeTabs, ratingScale, vm::setRatingScale, ratingSteps, vm::setRatingSteps, iconStyle, vm::setIconStyle, moreStyle, vm::setMoreStyle, goalStyle, vm::setGoalStyle, statsHeader, vm::setStatsHeader, statsBackground, vm::setStatsBackground, appBackground, vm::setAppBackground, activityStyle, vm::setActivityStyle, showRecommendations, vm::setShowRecommendations, dismissed.size, vm::clearDismissed, { navigate(Dest.Taste) }, openMenu, search, ledgeColor = ledgeColor, onLedgeColor = vm::setLedgeColor, bookPageStyle = bookPageStyle, onBookPageStyle = vm::setBookPageStyle, homeLayoutName = homeLayout?.name, onCustomizeHome = { vm.homeSession = HomeSession(homeLayout) }, onResetHome = { vm.setHomeLayout(null) }, libraryLayoutSet = libraryLayout != null, onCustomizeLibrary = { vm.librarySession = LibrarySession(libraryLayout, com.paperback.app.data.LibraryView.of(libraryFrosted, libraryShelf)) }, onResetLibrary = { vm.setLibraryLayout(null) })

                    Dest.Taste -> {
                        val taste = remember(books, wishlist, dismissed, marks, mutedSubjects) {
                            com.paperback.app.data.catalog.CatalogController.tasteOf(books, wishlist, dismissed, marks, mutedSubjects)
                        }
                        TasteScreen(
                            headerSize = headerSize,
                            taste = taste,
                            muted = mutedSubjects,
                            hiddenCount = dismissed.size,
                            onMute = vm::muteSubject,
                            onUnmute = vm::unmuteSubject,
                            onForgetHidden = vm::clearDismissed,
                            adventure = adventure,
                            onAdventure = vm::setAdventure,
                            suggestionRows = remember(suggestionCounts) {
                                com.paperback.app.data.suggestionRows(suggestionCounts, vm.kindWeights())
                            },
                            onMenu = openMenu,
                            onSearch = search,
                        )
                    }

                    Dest.About -> AboutScreen(headerSize, rememberAppVersion(), iconStyle, openMenu, search)

                    Dest.Appearance -> AppearanceScreen(headerSize, themeMode, vm::setThemeMode, accent, vm::setAccent, openMenu, search)

                    Dest.Goals -> GoalsScreen(headerSize, goals, books, sessions, vm::setGoals, reminderMode, reminderMinute, vm::setReminder, openMenu, search, weeklySummary, vm::setWeeklySummary)

                    Dest.ReaderDefaults -> ReaderDefaultsScreen(
                        headerSize = headerSize,
                        fontSize = reader.fontSize,
                        theme = reader.theme,
                        look = reader.look,
                        chromeStyle = reader.chromeStyle,
                        onFontSize = { reader.fontSize = it },
                        onTheme = { reader.theme = it },
                        onLook = { reader.look = it },
                        onChromeStyle = { reader.chromeStyle = it },
                        askKeep = keepPrompt,
                        onAskKeep = vm::setKeepPrompt,
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.ReadAloud -> com.paperback.app.tts.TtsSettingsScreen(headerSize, openMenu, search)

                    Dest.Scanner -> ScannerScreens(
                        scanner = scanner,
                        headerSize = headerSize,
                        shelfNames = collections.map { it.name },
                        onClose = { pop() },
                        onOpenLibrary = { navigate(Dest.Library) },
                        onOpenShelves = { navigate(Dest.Collections) },
                        onRequestAllFiles = onRequestAllFiles,
                        onPickFolder = onPickScanFolder,
                        onRequestNotifications = onRequestNotifications,
                        onMessage = vm::say,
                    )

                    Dest.Import -> ImportScreen(
                        headerSize = headerSize,
                        busy = busy,
                        onPick = onPickBooks,
                        onDiscover = discover,
                        onLibrary = { navigate(Dest.Library) },
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Backup -> BackupScreen(
                        headerSize = headerSize,
                        counts = backupCounts,
                        pending = pendingBackup,
                        onSave = onSaveBackup,
                        onPick = onPickBackup,
                        onApply = vm::applyBackup,
                        onCancel = vm::cancelBackup,
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Discover -> DiscoverScreen(
                        controller = vm.discover,
                        books = books,
                        headerSize = headerSize,
                        onOpenBook = open,
                        onMenu = openMenu,
                        onSearch = search,
                    )

                    Dest.Search -> SearchScreen(
                        query = searchQuery,
                        onQuery = { searchQuery = it },
                        recent = recentSearches,
                        onCommit = vm::addRecentSearch,
                        onClearRecent = vm::clearRecentSearches,
                        books = books,
                        collections = collections,
                        membership = membership,
                        highlights = highlights,
                        headerSize = headerSize,
                        onMenu = openMenu,
                        onOpenBook = details,
                        onOpenCollection = { push("Collection:${it.id}") },
                        onOpenNote = { book, place -> vm.open(book, onOpenReader, place) },
                        onOpenPage = navigate,
                        onOpenTag = openTag,
                        onOpenAuthor = openAuthor,
                        catalog = vm.catalog,
                        wishlist = wishlist,
                        onOpenCatalogBook = openCatalogBook,
                        onBrowse = browse,
                    )

                    Dest.WantToRead -> WantToReadScreen(
                        items = wishlist,
                        headerSize = headerSize,
                        onMenu = openMenu,
                        onSearch = search,
                        onOpenBook = openCatalogBook,
                        onRemove = { vm.removeFromWishlist(it.id) },
                        bestFit = remember(wishlist, books) { vm.catalog.rankWanted(wishlist) },
                    )

                    Dest.Collections -> CollectionsScreen(
                        collections = collections,
                        membership = membership,
                        books = books,
                        headerSize = headerSize,
                        onMenu = openMenu,
                        onSearch = search,
                        onOpen = { push("Collection:${it.id}") },
                        onCreate = vm::createCollection,
                    )

                    Dest.Notes, Dest.Bookmarks -> NotesScreen(
                        books = books,
                        highlights = highlights,
                        bookmarks = bookmarks,
                        onlyBookId = null,
                        initialTab = if (simple == Dest.Bookmarks) 1 else 0,
                        headerSize = headerSize,
                        onMenu = openMenu,
                        onSearch = search,
                        onOpenAt = { book, place -> vm.open(book, onOpenReader, place) },
                        onDeleteHighlight = vm::deleteHighlight,
                        onDeleteBookmark = vm::deleteBookmark,
                        onShare = onShareText,
                        onMarkSent = vm::markNotesSent,
                    )

                    Dest.Genres -> {
                        val counts = remember(books) { Tags.counts(books) }
                        NameCountScreen(
                            label = "Genres",
                            items = counts,
                            emptyText = "No genres yet. Paperback reads them from your books, and from Discover downloads, and fills this page in.",
                            filterHint = "Filter genres",
                            headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpen = openTag,
                        )
                    }

                    Dest.Dictionary -> DictionaryScreen(
                        saved = savedWords,
                        lookups = lookups,
                        sessions = sessions,
                        books = books,
                        headerSize = headerSize, onMenu = openMenu, onSearch = search,
                        onLookup = vm::addLookup,
                        onSave = vm::saveWord,
                        onRemove = vm::removeWord,
                    )

                    Dest.More -> MoreScreen(headerSize, moreStyle, openMenu, search, navigate, soon)

                    Dest.Authors -> {
                        val counts = remember(books) { Authors.counts(books) }
                        NameCountScreen(
                            label = "Authors",
                            items = counts,
                            emptyText = "No authors yet. Add books and they show up here.",
                            filterHint = "Filter authors",
                            headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpen = openAuthor,
                        )
                    }

                    Dest.Reading -> ShelfScreen(
                        label = "Currently reading",
                        books = books.filter { it.isReading }.sortedByDescending { it.lastOpenedAt },
                        emptyText = "Nothing in progress. Open a book to start.",
                        headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                    )

                    Dest.Recent -> ShelfScreen(
                        label = "Recently read",
                        books = books.filter { it.lastOpenedAt > 0 }.sortedByDescending { it.lastOpenedAt },
                        emptyText = "Books you open show up here.",
                        headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                    )

                    Dest.Finished -> ShelfScreen(
                        label = "Finished",
                        books = books.filter { it.finished }.sortedByDescending { if (it.finishedAt > 0) it.finishedAt else it.lastOpenedAt },
                        emptyText = "No finished books yet.",
                        headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                    )

                    Dest.Favorites -> ShelfScreen(
                        label = "Favorites",
                        books = books.filter { it.favorite },
                        emptyText = "No favorites yet. Open a book's page and tap Favorite.",
                        headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                    )

                    // Screens about one thing: a book, a collection, one book's notes.
                    null -> when (kind) {
                        "Book" -> {
                            val book = books.firstOrNull { it.id == arg }
                            if (book == null) {
                                // not loaded yet, or just removed: leave once the library is known
                                if (books.isNotEmpty()) LaunchedEffect(Unit) { pop() }
                            } else {
                                val similar = remember(books, book) { Similar.like(book, books) }
                                BookDetailScreen(
                                    book = book,
                                    sessions = sessions,
                                    collections = collections,
                                    membership = membership,
                                    noteCount = highlights.count { it.bookId == book.id },
                                    bookmarkCount = bookmarks.count { it.bookId == book.id },
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onRead = { if (book.hasFile) open(book) else onPickBooks() },
                                    onFindDetails = { vm.findDetails(book) },
                                    onToggleFavorite = { vm.toggleFavorite(book) },
                                    onToggleFinished = { vm.toggleFinished(book) },
                                    ratingScale = ratingScale,
                                    ratingSteps = ratingSteps,
                                    onRate = { vm.rate10(book, it) },
                                    onToggleCollection = { c ->
                                        vm.setMember(c, book, membership[c.id]?.contains(book.id) != true)
                                    },
                                    onOpenNotes = { push("NotesOf:${book.id}") },
                                    similar = similar,
                                    onOpenBook = details,
                                    onOpenTag = openTag,
                                    onOpenAuthor = openAuthor,
                                    reflow = reflow,
                                    onReflow = { vm.reflowPdf(book) },
                                    onCancelReflow = vm::cancelReflow,
                                    timerRunning = timerState.running && timerState.bookId == book.id,
                                    onOpenProgress = { push("BookProgress:${book.id}") },
                                    onEdit = { push("EditBook:${book.id}") },
                                    bookPageStyle = bookPageStyle,
                                    onRemove = {
                                        vm.remove(book)
                                        pop()
                                    },
                                )
                            }
                        }

                        "Collection" -> {
                            val c = collections.firstOrNull { it.id == arg }
                            if (c == null) {
                                LaunchedEffect(Unit) { pop() }
                            } else {
                                CollectionDetailScreen(
                                    collection = c,
                                    allBooks = books,
                                    memberIds = membership[c.id].orEmpty(),
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onOpenBook = details,
                                    onRename = { vm.renameCollection(c, it) },
                                    onDelete = {
                                        vm.deleteCollection(c)
                                        pop()
                                    },
                                    onSetMember = { book, member -> vm.setMember(c, book, member) },
                                )
                            }
                        }

                        "BookProgress" -> {
                            val pb = books.firstOrNull { it.id == arg }
                            if (pb == null) {
                                if (books.isNotEmpty()) LaunchedEffect(Unit) { pop() }
                            } else {
                                BookProgressScreen(
                                    book = pb,
                                    sessions = sessions,
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    timerRunning = timerState.running && timerState.bookId == pb.id,
                                    onStartTimer = { push("Timer:${pb.id}") },
                                    onAddEntry = { push("Entry:${pb.id}~0~0~${System.currentTimeMillis()}") },
                                    onEditEntry = { e -> push("Entry:${pb.id}~${e.id}~${e.seconds}~${e.startMs}") },
                                    books = books,
                                    highlights = highlights,
                                    bookmarks = bookmarks,
                                    onShare = onShareText,
                                    onOpenAt = { b, place -> vm.open(b, onOpenReader, place) },
                                    savedWords = savedWords,
                                    lookups = lookups,
                                )
                            }
                        }

                        "EditBook" -> {
                            val eb2 = books.firstOrNull { it.id == arg }
                            if (eb2 == null) {
                                if (books.isNotEmpty()) LaunchedEffect(Unit) { pop() }
                            } else {
                                val order = remember(books) { BookSort.Custom.apply(books).map { it.id } }
                                EditBookScreen(
                                    book = eb2,
                                    shelfPlace = order.indexOf(eb2.id) + 1,
                                    shelfCount = books.size,
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onPickCover = { onPickCover(eb2) },
                                    onSave = { edits ->
                                        vm.saveEdits(eb2, edits)
                                        pop()
                                    },
                                )
                            }
                        }

                        "NotesOf" -> NotesScreen(
                            books = books,
                            highlights = highlights,
                            bookmarks = bookmarks,
                            onlyBookId = arg,
                            initialTab = 0,
                            headerSize = headerSize,
                            onMenu = openMenu,
                            onSearch = search,
                            onOpenAt = { book, place -> vm.open(book, onOpenReader, place) },
                            onDeleteHighlight = vm::deleteHighlight,
                            onDeleteBookmark = vm::deleteBookmark,
                            onShare = onShareText,
                            onMarkSent = vm::markNotesSent,
                            journal = books.firstOrNull { it.id == arg }?.journal.orEmpty(),
                            onSaveJournal = books.firstOrNull { it.id == arg }?.let { b -> { text: String -> vm.saveJournal(b, text) } },
                        )

                        "Calendar" -> ReadingCalendarScreen(
                            books = books,
                            sessions = sessions,
                            headerSize = headerSize,
                            onMenu = openMenu,
                            onSearch = search,
                            onOpenBook = details,
                        )

                        // The books behind a number on Stats: "Shelf:langs", "Shelf:rated" and "Shelf:epic".
                        "Shelf" -> {
                            val view = remember(arg, books, sessions) { buildShelf(arg, books, sessions = sessions) }
                            if (view != null) {
                                SectionShelfScreen(view, headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details)
                            } else {
                                LaunchedEffect(route) { pop() }
                            }
                        }

                        // Monthly recaps: the list ("Recaps") and one month ("Recap:2026-09").
                        "Recaps" -> PbListPage("Reading recaps", headerSize, openMenu, search) {
                            RecapsContent(books, sessions, recapHost, Modifier.weight(1f), sidePad = 0.dp)
                        }

                        "Recap" -> {
                            val month = remember(arg) { recapMonthOf(arg) }
                            if (month != null) {
                                RecapScreen(
                                    month = month,
                                    books = books,
                                    sessions = sessions,
                                    highlights = highlights,
                                    bookmarks = bookmarks,
                                    goals = goals,
                                    links = RecapLinks(
                                        book = { id -> books.firstOrNull { it.id == id }?.let(details) },
                                        notes = { id -> if (id == null) navigate(Dest.Notes) else push("NotesOf:$id") },
                                        history = { day ->
                                            historyRequest = day
                                            navigate(Dest.Stats)
                                        },
                                        shelf = { k -> push("Shelf:$k") },
                                        author = openAuthor,
                                        tag = openTag,
                                        goals = { navigate(Dest.Goals) },
                                        share = onShareText,
                                    ),
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                )
                            } else {
                                LaunchedEffect(route) { pop() }
                            }
                        }

                        "Tag" -> {
                            val tag = remember(arg) { Uri.decode(arg) }
                            ShelfScreen(
                                label = tag,
                                books = remember(books, tag) { books.filter { Tags.has(it, tag) }.sortedBy { it.title.lowercase() } },
                                emptyText = "No books with this genre.",
                                headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                            )
                        }

                        "Author" -> {
                            val name = remember(arg) { Uri.decode(arg) }
                            val authorFigs = remember(books, sessions, name) {
                                com.paperback.app.data.authorFigures(name, books, sessions, java.time.ZoneId.systemDefault())
                            }
                            ShelfScreen(
                                label = name,
                                books = remember(books, name) { books.filter { Authors.has(it, name) }.sortedBy { it.title.lowercase() } },
                                emptyText = "No books by this author.",
                                headerSize = headerSize, onMenu = openMenu, onSearch = search, onOpenBook = details,
                                top = { authorFigs?.let { AuthorStatsCard(it, details) } },
                            )
                        }

                        "Catalog" -> {
                            val cb = remember(arg) { vm.catalog.find(arg) }
                            if (cb == null) {
                                // the app was restarted on this page and the book is not in memory any more
                                LaunchedEffect(Unit) { pop() }
                            } else {
                                CatalogBookScreen(
                                    book = cb,
                                    owned = books.firstOrNull { TitleKey.same(it.title, cb.title) },
                                    wished = wishlist.any { it.id == cb.id },
                                    onToggleWish = { vm.toggleWishlist(cb) },
                                    onAddWithoutFile = { pages, tags -> vm.addWithoutFile(cb, pages, tags) },
                                    ownedKeys = remember(books) { ownedKeys(books) },
                                    catalog = vm.catalog,
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onOpenOwned = details,
                                    onOpenCatalogBook = openCatalogBook,
                                    onBrowse = browse,
                                )
                            }
                        }

                        "Timer" -> {
                            val tb = books.firstOrNull { it.id == arg }
                            if (tb == null) {
                                if (books.isNotEmpty()) LaunchedEffect(Unit) { pop() }
                            } else {
                                val busyWith = timerState.takeIf { it.active && it.bookId != tb.id }?.bookId
                                ReadingTimerScreen(
                                    book = tb,
                                    timer = vm.timer,
                                    otherTitle = busyWith?.let { id -> books.firstOrNull { it.id == id }?.title },
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onFinish = { seconds, startMs -> push("Entry:${tb.id}~0~$seconds~$startMs") },
                                    onOpenOther = { busyWith?.let { push("Timer:$it") } },
                                )
                            }
                        }

                        "Entry" -> {
                            val parts = arg.split('~')
                            val eBookId = parts.getOrElse(0) { "" }
                            val eId = parts.getOrElse(1) { "0" }.toLongOrNull() ?: 0L
                            val eSeconds = parts.getOrElse(2) { "0" }.toIntOrNull() ?: 0
                            val eStart = parts.getOrElse(3) { "0" }.toLongOrNull() ?: System.currentTimeMillis()
                            val eb = books.firstOrNull { it.id == eBookId }
                            val existing = if (eId != 0L) rawSessions.firstOrNull { it.id == eId } else null
                            if (eb == null || (eId != 0L && existing == null && rawSessions.isNotEmpty())) {
                                if (books.isNotEmpty()) LaunchedEffect(Unit) { pop() }
                            } else {
                                // after saving, go back to the book page, past the timer if it was used
                                val backToBook: () -> Unit = {
                                    stackRaw = stack.dropLastWhile { it.startsWith("Timer:") || it.startsWith("Entry:") }
                                        .joinToString(",").ifEmpty { Dest.Home.name }
                                }
                                EntryScreen(
                                    book = eb,
                                    entry = existing,
                                    counted = rawSessions,
                                    initialSeconds = eSeconds,
                                    initialStartMs = eStart,
                                    headerSize = headerSize,
                                    onMenu = openMenu,
                                    onSearch = search,
                                    onSave = { startMs, seconds, pages, from, to ->
                                        vm.saveEntry(eId, eb.id, startMs, seconds, pages, from, to)
                                        if (eId == 0L && eSeconds > 0 && timerState.bookId == eb.id) vm.timer.clear()
                                        backToBook()
                                    },
                                    onDelete = if (existing != null) {
                                        {
                                            vm.deleteEntry(existing.id)
                                            pop()
                                        }
                                    } else null,
                                )
                            }
                        }

                        "Browse" -> {
                            val browseKind = arg.substringBefore('~')
                            val browseValue = remember(arg) { Uri.decode(arg.substringAfter('~', "")) }
                            CatalogBrowseScreen(
                                kind = browseKind,
                                arg = browseValue,
                                ownedKeys = remember(books) { ownedKeys(books) },
                                catalog = vm.catalog,
                                headerSize = headerSize,
                                onMenu = openMenu,
                                onSearch = search,
                                onOpenBook = openCatalogBook,
                            )
                        }

                        else -> LaunchedEffect(route) { pop() }
                    }
                }
                }
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }

        // Screens that are not tabs get the round menu button at the bottom right, like the old app's Settings.
        if (!onTabScreen && !menuOpen && current != Dest.Scanner) {
            MenuFab(
                onClick = openMenu,
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 24.dp),
            )
        }

        // "Your September recap is ready", once the month is over; "Maybe later" keeps it quiet for a day.
        val askRecap = pendingRecapRow
        if (askRecap != null && current == Dest.Home && stack.size == 1 && !menuOpen && vm.homeSession == null && System.currentTimeMillis() >= recapSnoozeUntil) {
            RecapPromptDialog(
                row = askRecap,
                onOpen = { recapHost.onOpen(askRecap.month) },
                onLater = { vm.snoozeRecap(System.currentTimeMillis() + 24L * 60L * 60L * 1000L) },
            )
        }

        // After you close a book: how long you read and how many pages. Saved already; only "Discard" removes it.
        if (keepRows.isNotEmpty()) {
            KeepSessionDialog(
                bookTitle = books.firstOrNull { it.id == keepRows.first().bookId }?.title.orEmpty(),
                rows = keepRows,
                onKeep = { vm.keepSession(keepRows) },
                onDiscard = { vm.discardSession(keepRows) },
            )
        }

        MenuOverlay(
            open = menuOpen,
            current = current,
            onClose = { menuOpen = false },
            onGo = navigate,
            onSoon = soon,
            onMore = { navigate(Dest.More) },
        )

        // Customize Home covers everything while it is open; nothing is saved until Done.
        vm.homeSession?.let { session ->
            HomeConstructor(
                session = session,
                home = homeScreen,
                onDone = { layout -> vm.setHomeLayout(layout); vm.homeSession = null },
                onUseOriginal = { vm.setHomeLayout(null); vm.homeSession = null },
                onClose = { vm.homeSession = null },
            )
        }

        // Customize Library works the same way: it covers everything, and nothing is saved until Done.
        vm.librarySession?.let { session ->
            LibraryConstructor(
                session = session,
                onDone = { layout, view ->
                    vm.setLibraryLayout(layout)
                    vm.setLibraryFrosted(view == com.paperback.app.data.LibraryView.Frosted)
                    if (view != com.paperback.app.data.LibraryView.Frosted) vm.setLibraryShelf(view == com.paperback.app.data.LibraryView.Shelves)
                    vm.librarySession = null
                },
                onUseOriginal = { vm.setLibraryLayout(null); vm.librarySession = null },
                onClose = { vm.librarySession = null },
            )
        }
    }
    }
}
