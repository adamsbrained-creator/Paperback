package com.paperback.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.data.HeaderSize
import com.paperback.app.scan.Dedup
import com.paperback.app.scan.Found
import com.paperback.app.scan.Grouper
import com.paperback.app.scan.ScanController
import com.paperback.app.scan.ScanJobs
import com.paperback.app.scan.ScanKind
import com.paperback.app.scan.ScanNeed
import com.paperback.app.scan.ScanScreen
import com.paperback.app.scan.ScanStore
import com.paperback.app.scan.StorageAccess
import com.paperback.app.ui.theme.pbTokens
import java.util.Locale

/**
 * The book scanner's seven screens (Before, Scanning, Results, Review, Done, Settings; the first card lives on the
 * Library page). Which one shows is up to [ScanController.screen].
 */
@Composable
fun ScannerScreens(
    scanner: ScanController,
    headerSize: HeaderSize,
    shelfNames: List<String>,
    /** Leaves the scanner (back to where it was opened from). */
    onClose: () -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenShelves: () -> Unit,
    onRequestAllFiles: () -> Unit,
    onPickFolder: () -> Unit,
    onRequestNotifications: () -> Unit,
    onMessage: (String) -> Unit,
) {
    val screen by scanner.screen.collectAsStateWithLifecycle()
    val message by scanner.message.collectAsStateWithLifecycle()
    LaunchedEffect(message) {
        message?.let {
            onMessage(it)
            scanner.messageShown()
        }
    }
    val act: (ScanNeed) -> Unit = { need ->
        when (need) {
            ScanNeed.AllFiles -> onRequestAllFiles()
            ScanNeed.Folder -> onPickFolder()
            ScanNeed.None -> {}
        }
    }
    when (screen) {
        ScanScreen.Before -> BeforeScreen(scanner, headerSize, onClose, act, onPickFolder)
        ScanScreen.Scanning -> ScanningScreen(scanner, headerSize, onClose, onRequestNotifications)
        ScanScreen.Results -> ResultsScreen(scanner, headerSize, onClose)
        ScanScreen.Review -> ReviewScreen(scanner, headerSize)
        ScanScreen.Done -> DoneScreen(scanner, headerSize, shelfNames, onClose, onOpenLibrary, onOpenShelves) { scanner.openSettings() }
        ScanScreen.Settings -> ScannerSettings(scanner, headerSize, onClose, act, onPickFolder, onRequestAllFiles, onRequestNotifications)
    }
}

// ---- 2. Before you scan -----------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BeforeScreen(
    scanner: ScanController,
    headerSize: HeaderSize,
    onClose: () -> Unit,
    act: (ScanNeed) -> Unit,
    onPickFolder: () -> Unit,
) {
    val t = pbTokens()
    val store = scanner.store
    val whole by store.wholePhone.collectAsStateWithLifecycle()
    val kinds by store.kinds.collectAsStateWithLifecycle()
    val trees by store.trees.collectAsStateWithLifecycle()
    val canWhole = StorageAccess.canAskForWholePhone()
    val wholeOn = whole && canWhole

    ScanPage(
        title = "Scan this phone",
        headerSize = headerSize,
        leftIcon = PbIconName.Close,
        leftDescription = "Close",
        onLeft = onClose,
        bottom = {
            PbButton("Start scan", { act(scanner.begin()) })
            PbButton("Not now", onClose, ghost = true)
        },
    ) {
        Text(
            "Paperback looks for book files, reads their titles and covers, and sorts them into shelves. Nothing is added until you say so.",
            color = t.sub,
            fontSize = 15.sp,
            lineHeight = 22.sp,
            modifier = Modifier.padding(top = 14.dp, start = 2.dp, end = 2.dp),
        )
        SectionLabel("WHERE TO LOOK")
        PbCard {
            PlaceRow("Whole phone", if (canWhole) "Internal storage and the SD card. Skips Android, app data and cache folders." else "Android 10 doesn't allow this. Pick folders instead.", wholeOn, canWhole) { store.setWholePhone(true) }
            CardDivider(18.dp)
            PlaceRow("Only some folders", "Pick them yourself, for example Downloads and Books.", !wholeOn, true) { store.setWholePhone(false) }
            if (!wholeOn) {
                trees.forEach { tree ->
                    CardDivider(18.dp)
                    Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tree.name, color = t.ink, fontSize = 15.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        QuietAction("Remove", { store.removeTree(tree.uri) })
                    }
                }
                CardDivider(18.dp)
                Box(
                    Modifier.fillMaxWidth().pbTap(onPickFolder, RoundedCornerShape(0.dp), role = Role.Button).padding(horizontal = 18.dp, vertical = 14.dp),
                ) { Text("+ Add a folder", color = MaterialTheme.colorScheme.primary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
        SectionLabel("WHAT TO LOOK FOR")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScanKind.chips().forEach { k -> TogglePill(k.label(), k in kinds) { store.setKind(k, k !in kinds) } }
        }
        PbNote("Comics, Word files and plain text are turned into EPUB when you add them.")
        PbNote("Everything stays on your phone. Android will ask once to let Paperback see your files.")
    }
}

@Composable
private fun PlaceRow(title: String, sub: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .pbTap(onClick, RoundedCornerShape(0.dp), enabled = enabled, haptic = true, role = Role.RadioButton)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        RadioMark(selected)
        Column(Modifier.weight(1f)) {
            Text(title, color = if (enabled) t.ink else t.setSub, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

// ---- 3. Scanning ------------------------------------------------------------------------------

@Composable
private fun ScanningScreen(scanner: ScanController, headerSize: HeaderSize, onClose: () -> Unit, onRequestNotifications: () -> Unit) {
    val t = pbTokens()
    val p by scanner.progress.collectAsStateWithLifecycle()
    // the phone shows a progress notification while this runs: asked for once, the first time
    LaunchedEffect(Unit) { onRequestNotifications() }

    ScanPage(
        title = "Scanning",
        headerSize = headerSize,
        leftIcon = PbIconName.Close,
        leftDescription = "Close. The scan keeps going",
        onLeft = onClose,
        chip = "${p.percent}%",
        bottom = {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (p.paused) "Resume" else "Pause", { if (p.paused) scanner.resume() else scanner.pause() }, Modifier.width(120.dp), ghost = true)
                PillButton("Stop and review", { scanner.stopAndReview() }, Modifier.weight(1f))
            }
        },
    ) {
        Column(
            Modifier.padding(top = 14.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Found so far", color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(String.format(Locale.getDefault(), "%,d", p.books), color = t.ink, fontSize = 44.sp, fontWeight = FontWeight.Medium)
                Text(if (p.books == 1) " book" else " books", color = t.sub, fontSize = 18.sp, modifier = Modifier.padding(bottom = 8.dp))
            }
            ProgressTrack(p.percent / 100f)
            Text(String.format(Locale.getDefault(), "%,d files checked", p.files), color = t.sub, fontSize = 13.sp)
            if (p.folder.isNotEmpty()) {
                Text("Looking in ${p.folder}", color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (p.byKind.isNotEmpty()) {
            SectionLabel("BY FORMAT")
            PbCard(Modifier) {
                val top = p.byKind.maxOf { it.second }.coerceAtLeast(1)
                Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    p.byKind.forEach { (name, n) ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(name, color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.width(66.dp), maxLines = 1)
                            Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(t.rule)) {
                                Box(Modifier.fillMaxHeight().fillMaxWidth(n / top.toFloat()).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.primary))
                            }
                            Text("$n", color = t.sub, fontSize = 13.sp, modifier = Modifier.width(36.dp), maxLines = 1)
                        }
                    }
                }
            }
        }
        if (p.recent.isNotEmpty()) {
            SectionLabel("JUST FOUND")
            PbCard(Modifier) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                    p.recent.forEach { b -> BookLine(b, subtitle = b.author.ifEmpty { b.folder.ifEmpty { b.rootKey } }) }
                }
            }
        }
        PbNote("You can leave this screen. The scan keeps going in the background.")
    }
}

/** A book as a line: cover block, title, a second line, and its format. */
@Composable
private fun BookLine(b: Found, subtitle: String, leading: (@Composable () -> Unit)? = null, modifier: Modifier = Modifier) {
    val t = pbTokens()
    Row(modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        leading?.invoke()
        CoverBlock(b.shownTitle())
        Column(Modifier.weight(1f)) {
            Text(b.shownTitle(), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        FormatTag(if (b.kind == ScanKind.BLOCKED) b.name.substringAfterLast('.', "").uppercase() else b.kind.label())
    }
}

// ---- 4. Results -------------------------------------------------------------------------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ResultsScreen(scanner: ScanController, headerSize: HeaderSize, onClose: () -> Unit) {
    val t = pbTokens()
    val results by scanner.results.collectAsStateWithLifecycle()
    val adding by scanner.adding.collectAsStateWithLifecycle()
    val sort by scanner.store.sort.collectAsStateWithLifecycle()
    val shelves by scanner.store.shelves.collectAsStateWithLifecycle()
    val r = results

    if (r == null) {
        // nothing waiting (it was added or dismissed): a short way back
        ScanPage("Scan finished", headerSize, PbIconName.Close, "Close", onClose, bottom = { PbButton("Scan again", { scanner.openBefore() }) }) {
            Text("There are no scan results waiting.", color = t.sub, fontSize = 15.sp, modifier = Modifier.padding(top = 20.dp))
        }
        return
    }
    val groups = remember(r.offered, sort) { Grouper.group(r.offered, sort) }
    val problems = r.duplicates + r.problems
    val selectedCount = r.selected.size
    val allOn = r.unchecked.isEmpty()
    val noneOn = selectedCount == 0

    ScanFrame(
        title = if (r.total == 1) "1 book found" else "${String.format(Locale.getDefault(), "%,d", r.total)} books found",
        headerSize = headerSize,
        leftIcon = PbIconName.Close,
        leftDescription = "Close. Nothing is added yet",
        onLeft = onClose,
        bottom = {
            val a = adding
            if (a != null) {
                ProgressTrack(if (a.second == 0) 0f else a.first / a.second.toFloat())
                PbButton("Adding ${a.first} of ${a.second}…", {}, enabled = false)
            } else {
                PbButton(if (selectedCount == 1) "Add 1 book" else "Add $selectedCount books", { scanner.addSelected() }, enabled = !noneOn)
                if (problems > 0) PbButton(if (problems == 1) "Review 1 problem" else "Review $problems problems", { scanner.openReview() }, ghost = true)
            }
        },
    ) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 16.dp)) {
            item(key = "summary") {
                val parts = buildList {
                    add("${r.offered.size} new")
                    add(if (r.duplicates == 1) "1 duplicate" else "${r.duplicates} duplicates")
                    add(if (r.problems == 1) "1 can't be opened" else "${r.problems} can't be opened")
                }
                Text(parts.joinToString(" · "), color = t.sub, fontSize = 14.sp, modifier = Modifier.padding(start = 2.dp, top = 12.dp))
            }
            item(key = "sorts") {
                Row(Modifier.padding(top = 14.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Grouper.By.values().forEach { by -> TogglePill(by.label, sort == by) { scanner.store.setSort(by) } }
                }
            }
            item(key = "shelves") {
                PbCard(Modifier.padding(top = 14.dp)) {
                    ScanSwitchRow("Make shelves automatically", "From series, folders and genres", shelves) { scanner.store.setShelves(it) }
                }
            }
            if (r.offered.isEmpty()) {
                item(key = "empty") {
                    Text(
                        if (problems > 0) "No new books to add. The files below are copies of books you have, or can't be opened." else "No new books were found.",
                        color = t.sub,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(top = 24.dp, start = 2.dp),
                    )
                }
            } else {
                item(key = "all") {
                    Row(
                        Modifier
                            .padding(top = 14.dp)
                            .fillMaxWidth()
                            .pbTap({ scanner.selectAll(!allOn) }, RoundedCornerShape(20.dp), pressedScale = 0.99f, role = Role.Checkbox)
                            .padding(horizontal = 6.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        SelectDot(allOn)
                        Text("Select all ${r.offered.size} new books", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        Text(Grouper.sizeText(r.offeredBytes), color = t.setSub, fontSize = 13.sp)
                    }
                }
                groups.forEach { g ->
                    stickyHeader(key = "g-${g.name}") {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(t.bg)
                                .pbTap({ scanner.toggleGroup(g.books) }, RoundedCornerShape(12.dp), pressedScale = 0.99f)
                                .padding(start = 6.dp, end = 6.dp, top = 14.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                if (g.name == "\u0000") "Other" else g.name,
                                color = t.ink,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(if (g.books.size == 1) "1 book" else "${g.books.size} books", color = t.setSub, fontSize = 13.sp)
                        }
                    }
                    items(g.books, key = { it.fileKey() }) { b ->
                        val on = b.fileKey() !in r.unchecked
                        BookLine(
                            b,
                            subtitle = Grouper.detail(b),
                            leading = { SelectDot(on) },
                            modifier = Modifier
                                .pbTap({ scanner.toggle(b.fileKey()) }, RoundedCornerShape(14.dp), pressedScale = 0.99f, role = Role.Checkbox)
                                .padding(horizontal = 6.dp),
                        )
                    }
                }
            }
        }
    }
}

// ---- 5. Review the problems -------------------------------------------------------------------

@Composable
private fun ReviewScreen(scanner: ScanController, headerSize: HeaderSize) {
    val t = pbTokens()
    val results by scanner.results.collectAsStateWithLifecycle()
    val r = results
    var tab by remember { mutableStateOf(0) }
    if (r == null) {
        LaunchedEffect(Unit) { scanner.closeReview() }
        return
    }
    val dups = r.dedup.copies
    val blocked = r.dedup.problems

    ScanFrame(
        title = "Review",
        headerSize = headerSize,
        leftIcon = PbIconName.CaretLeft,
        leftDescription = "Back to the results",
        onLeft = { scanner.closeReview() },
        bottom = { PbButton("Keep the best of each", { scanner.keepBestOfEach() }) },
    ) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item(key = "tabs") {
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TogglePill("Duplicates ${dups.size}", tab == 0) { tab = 0 }
                    TogglePill("Can't open ${blocked.size}", tab == 1) { tab = 1 }
                }
            }
            if (tab == 0) {
                item(key = "dup-note") {
                    Text(
                        "The same book found more than once. Paperback keeps the best copy and leaves your files where they are.",
                        color = t.sub,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        modifier = Modifier.padding(horizontal = 2.dp),
                    )
                }
                if (dups.isEmpty()) item(key = "no-dups") { Text("No duplicates.", color = t.setSub, fontSize = 15.sp, modifier = Modifier.padding(start = 2.dp)) }
                items(dups.size, key = { "d$it" }) { i -> CopiesCard(scanner, dups[i]) }
            } else {
                item(key = "blocked-head") { SectionLabel("CAN'T BE OPENED (${blocked.size})") }
                if (blocked.isEmpty()) item(key = "no-blocked") { Text("Nothing here.", color = t.setSub, fontSize = 15.sp, modifier = Modifier.padding(start = 2.dp)) }
                items(blocked.size, key = { "b$it" }) { i ->
                    val b = blocked[i]
                    PbCard {
                        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                            Text(b.name, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(b.problem ?: "", color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                }
            }
        }
    }
}

/** One book found more than once: a choice of which copy to keep. */
@Composable
private fun CopiesCard(scanner: ScanController, c: Dedup.Copies) {
    val t = pbTokens()
    PbCard {
        Text(c.title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 4.dp))
        if (c.owned) {
            CopyRow("In your library", "Already added", c.keep == -1, "In library") { scanner.keepCopy(c, -1) }
        }
        c.copies.forEachIndexed { i, f ->
            CopyRow(
                "${f.kind.label()} · ${Grouper.sizeText(f.size)}",
                (if (f.folder.isEmpty()) f.rootKey else f.folder) + "/" + f.name,
                c.keep == i,
                if (i == 0 && !c.owned) "Best" else "",
            ) { scanner.keepCopy(c, i) }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun CopyRow(title: String, path: String, selected: Boolean, tag: String, onClick: () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier.fillMaxWidth().pbTap(onClick, RoundedCornerShape(0.dp), role = Role.RadioButton).padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        RadioMark(selected)
        Column(Modifier.weight(1f)) {
            Text(title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(path, color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (tag.isNotEmpty()) {
            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primary).padding(horizontal = 8.dp, vertical = 3.dp)) {
                Text(tag, color = MaterialTheme.colorScheme.onPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ---- 6. Scan finished -------------------------------------------------------------------------

@Composable
private fun DoneScreen(
    scanner: ScanController,
    headerSize: HeaderSize,
    shelfNames: List<String>,
    onClose: () -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenShelves: () -> Unit,
    onSettings: () -> Unit,
) {
    val t = pbTokens()
    val summary by scanner.summary.collectAsStateWithLifecycle()
    val auto by scanner.store.auto.collectAsStateWithLifecycle()
    val whenMode by scanner.store.whenMode.collectAsStateWithLifecycle()
    var sortDialog by remember { mutableStateOf(false) }
    val s = summary

    ScanPage(
        title = "Scan finished",
        headerSize = headerSize,
        leftIcon = PbIconName.Close,
        leftDescription = "Close",
        onLeft = onClose,
        bottom = {
            PbButton("Open library", onOpenLibrary)
            PbButton("Scanner settings", onSettings, ghost = true)
        },
    ) {
        if (s == null) {
            Text("Nothing to show yet.", color = t.sub, fontSize = 15.sp, modifier = Modifier.padding(top = 20.dp))
            return@ScanPage
        }
        Column(
            Modifier.padding(top = 14.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Added to your library", color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Row(verticalAlignment = Alignment.Bottom) {
                Text("${s.added}", color = t.ink, fontSize = 44.sp, fontWeight = FontWeight.Medium)
                Text(if (s.added == 1) " book" else " books", color = t.sub, fontSize = 18.sp, modifier = Modifier.padding(bottom = 8.dp))
            }
            val sentences = buildList {
                if (s.shelves.isNotEmpty()) add(if (s.shelves.size == 1) "Sorted into 1 shelf." else "Sorted into ${s.shelves.size} shelves.")
                if (s.converted > 0) add(if (s.converted == 1) "1 file was converted to EPUB, so it opens like any other book." else "${s.converted} files were converted to EPUB, so they open like any other book.")
                if (s.alreadyHad > 0) add(if (s.alreadyHad == 1) "1 was already in your library." else "${s.alreadyHad} were already in your library.")
            }
            if (sentences.isNotEmpty()) Text(sentences.joinToString(" "), color = t.sub, fontSize = 14.sp, lineHeight = 20.sp)
        }
        if (s.failed.isNotEmpty()) {
            Text(
                (if (s.failed.size == 1) "1 file couldn't be added: " else "${s.failed.size} files couldn't be added: ") + s.failed.first() + (if (s.failed.size > 1) " and more" else ""),
                color = t.sub,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier.padding(start = 2.dp, top = 10.dp),
            )
        }
        if (s.shelves.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("YOUR NEW SHELVES", color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(start = 4.dp))
                QuietAction("Edit", onOpenShelves, color = t.ink, fontSize = 13.sp)
            }
            PbCard {
                val top = s.shelves.maxOf { it.second }.coerceAtLeast(1)
                Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    s.shelves.forEach { (name, n) ->
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row {
                                Text(name, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("$n", color = t.sub, fontSize = 14.sp)
                            }
                            Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(t.rule)) {
                                Box(Modifier.fillMaxHeight().fillMaxWidth(n / top.toFloat()).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.primary))
                            }
                        }
                    }
                }
            }
        }
        if (s.unsorted.isNotEmpty()) {
            PbCard(Modifier.padding(top = 14.dp)) {
                Row(Modifier.padding(start = 18.dp, end = 10.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (s.unsorted.size == 1) "1 book needs a shelf" else "${s.unsorted.size} books need a shelf", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text("No author or folder to go by", color = t.setSub, fontSize = 13.sp)
                    }
                    PillButton("Sort them", { sortDialog = true }, ghost = true, fontSize = 14)
                }
            }
        }
        PbNote(
            when {
                !auto || whenMode == ScanStore.WHEN_MANUAL -> "Next scan: when you tap Scan now."
                whenMode == ScanStore.WHEN_DAILY -> "Next scan: once a day, while the phone charges."
                else -> "Next scan: when new book files appear on your phone."
            },
        )
    }

    if (sortDialog) {
        var name by remember { mutableStateOf("") }
        PbDialog("Sort into a shelf", onDismiss = { sortDialog = false }) {
            PbField(name, { name = it }, "Shelf name")
            if (shelfNames.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    shelfNames.take(12).forEach { n -> TogglePill(n, name.equals(n, ignoreCase = true)) { name = n } }
                }
            }
            PbDialogButtons(confirm = "Sort", onConfirm = { scanner.sortRemaining(name); sortDialog = false }, onCancel = { sortDialog = false }, enabled = name.isNotBlank())
        }
    }
}

// ---- 7. Scanner settings ----------------------------------------------------------------------

@Composable
private fun ScannerSettings(
    scanner: ScanController,
    headerSize: HeaderSize,
    onClose: () -> Unit,
    act: (ScanNeed) -> Unit,
    onPickFolder: () -> Unit,
    onRequestAllFiles: () -> Unit,
    onRequestNotifications: () -> Unit,
) {
    val t = pbTokens()
    val context = LocalContext.current
    val store = scanner.store
    val auto by store.auto.collectAsStateWithLifecycle()
    val whenMode by store.whenMode.collectAsStateWithLifecycle()
    val ask by store.ask.collectAsStateWithLifecycle()
    val minKb by store.minKb.collectAsStateWithLifecycle()
    val folders by store.folders.collectAsStateWithLifecycle()
    val trees by store.trees.collectAsStateWithLifecycle()
    val whole by store.wholePhone.collectAsStateWithLifecycle()
    store.lastTick.collectAsStateWithLifecycle().value // redraws the "last scan" line when a scan finishes
    var sizeDialog by remember { mutableStateOf(false) }

    // the phone's own scheduler follows these two settings
    LaunchedEffect(auto, whenMode) { ScanJobs.schedule(context, store) }

    val shown = remember(folders, trees) {
        val extra = trees.filter { tr -> folders.none { it.key == "tree:" + tr.uri } }.map { tr -> ScanStore.Folder("tree:" + tr.uri, tr.name, 0, true) }
        folders + extra
    }

    ScanPage(
        title = "Book scanner",
        headerSize = headerSize,
        leftIcon = PbIconName.CaretLeft,
        leftDescription = "Back",
        onLeft = onClose,
        bottom = { PbButton("Scan now", { act(scanner.scanNow()) }) },
    ) {
        PbCard(Modifier.padding(top = 14.dp)) {
            ScanSwitchRow("Scan automatically", scanner.lastScanText() ?: "Not scanned yet", auto) { on ->
                store.setAuto(on)
                if (on) {
                    // the phone asks for one thing at a time: the files first (the scan can't run without them), then notifications
                    if (whole && !StorageAccess.canReadWholePhone(context) && StorageAccess.canAskForWholePhone()) onRequestAllFiles() else onRequestNotifications()
                }
            }
        }
        SectionLabel("WHEN")
        PbCard(Modifier.alpha(if (auto) 1f else 0.45f)) {
            listOf(
                ScanStore.WHEN_APPEAR to "When new book files appear",
                ScanStore.WHEN_DAILY to "Once a day, while charging",
                ScanStore.WHEN_MANUAL to "Only when I tap Scan now",
            ).forEachIndexed { i, (mode, label) ->
                if (i > 0) CardDivider(18.dp)
                Row(
                    Modifier.fillMaxWidth().pbTap({ store.setWhenMode(mode) }, RoundedCornerShape(0.dp), enabled = auto, haptic = true, role = Role.RadioButton).padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    RadioMark(whenMode == mode)
                    Text(label, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("FOLDERS TO LOOK IN", color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(start = 4.dp))
            QuietAction("Add", onPickFolder, color = t.ink, fontSize = 13.sp)
        }
        PbCard {
            if (shown.isEmpty()) {
                Text(
                    if (whole) "Run a scan and the folders with books in them are listed here, so you can switch each one on or off." else "Add the folders to look in.",
                    color = t.setSub,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(18.dp),
                )
            }
            shown.forEachIndexed { i, f ->
                if (i > 0) CardDivider(18.dp)
                val isTree = f.key.startsWith("tree:")
                ScanSwitchRow(
                    f.name,
                    if (f.count == 0 && isTree) "Not scanned yet" else if (f.count == 1) "1 book" else "${f.count} books",
                    f.enabled,
                ) { store.setFolderEnabled(f.key, it) }
                if (isTree && f.enabled.not()) {
                    // a folder you added and switched off can be removed for good
                    Box(Modifier.padding(start = 12.dp, bottom = 6.dp)) { QuietAction("Remove this folder", { store.removeTree(f.key.removePrefix("tree:")); store.setFolderEnabled(f.key, true) }) }
                }
            }
        }
        SectionLabel("NEW BOOKS")
        PbCard {
            ScanSwitchRow("Ask before adding", "A notification lets you review them", ask) { store.setAsk(it) }
            CardDivider(18.dp)
            Row(
                Modifier.fillMaxWidth().pbTap({ sizeDialog = true }, RoundedCornerShape(0.dp), role = Role.Button).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Ignore files smaller than", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text("Skips flyers and one-page PDFs", color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
                Text(sizeLabel(minKb), color = t.sub, fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (sizeDialog) {
        PbDialog("Ignore files smaller than", onDismiss = { sizeDialog = false }) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ScanStore.MIN_KB_CHOICES.forEach { kb ->
                    Row(
                        Modifier.fillMaxWidth().pbTap({ store.setMinKb(kb); sizeDialog = false }, RoundedCornerShape(14.dp), role = Role.RadioButton).padding(horizontal = 6.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        RadioMark(minKb == kb)
                        Text(sizeLabel(kb), color = t.ink, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

private fun sizeLabel(kb: Int): String = when {
    kb <= 0 -> "Don't skip any"
    kb >= 1024 -> "${kb / 1024} MB"
    else -> "$kb KB"
}
