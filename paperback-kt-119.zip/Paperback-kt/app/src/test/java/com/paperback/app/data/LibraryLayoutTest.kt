package com.paperback.app.data

import com.paperback.app.data.LibraryBlock
import com.paperback.app.data.LibraryBlock as B
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LibraryLayoutTest {

    @Test
    fun theDefaultIsTheLibraryAsItAlwaysWas() {
        val l = LibraryLayout.ORIGINAL
        assertEquals(listOf(B.Search, B.Status, B.Tools, B.Scanner, B.Books), l.shown)
        assertEquals(listOf(B.Search, B.Status, B.Tools), l.pinnedBlocks)
        assertEquals(listOf(B.Scanner), l.scrollingBlocks)
        assertEquals(0, l.hiddenCount)
    }

    @Test
    fun hidingABlockRemovesItAndTheBooksCannotBeHidden() {
        val l = LibraryLayout.ORIGINAL.hiding(B.Search, true).hiding(B.Scanner, true).hiding(B.Books, true)
        assertEquals(listOf(B.Status, B.Tools, B.Books), l.shown)
        assertTrue(l.isVisible(B.Books))
        assertEquals(2, l.hiddenCount)
        assertEquals(listOf(B.Status, B.Tools, B.Scanner, B.Books), l.hiding(B.Scanner, false).shown)
    }

    @Test
    fun aChipRowWithEverySwitchOffCountsAsHidden() {
        var l = LibraryLayout.ORIGINAL
        for (o in LibraryCatalog.optionsOf(B.Tools)) l = l.withOption(o.key, false)
        assertFalse(l.isVisible(B.Tools))
        assertFalse(B.Tools in l.shown)
        assertEquals(1, l.hiddenCount)
        l = l.withOption("tools.sort", true)
        assertTrue(l.isVisible(B.Tools))
    }

    @Test
    fun unknownSwitchesAreIgnored() {
        assertEquals(LibraryLayout.ORIGINAL, LibraryLayout.ORIGINAL.withOption("nope", false))
    }

    @Test
    fun movingKeepsTheBooksLast() {
        val l = LibraryLayout.ORIGINAL
        assertEquals(listOf(B.Scanner, B.Search, B.Status, B.Tools, B.Books), l.moving(3, 0).order)
        // nothing can be moved onto or off the books' place
        assertEquals(l, l.moving(3, 4))
        assertEquals(l, l.moving(4, 0))
        assertEquals(l, l.moving(0, 0))
        assertEquals(l, l.moving(-1, 2))
    }

    @Test
    fun onlyTheLeadingControlsArePinned() {
        val scannerFirst = LibraryLayout.ORIGINAL.moving(3, 0)
        assertEquals(emptyList<LibraryBlock>(), scannerFirst.pinnedBlocks)
        assertEquals(listOf(B.Scanner, B.Search, B.Status, B.Tools), scannerFirst.scrollingBlocks)

        val middle = LibraryLayout.ORIGINAL.moving(3, 1)
        assertEquals(listOf(B.Search), middle.pinnedBlocks)
        assertEquals(listOf(B.Scanner, B.Status, B.Tools), middle.scrollingBlocks)

        val unpinned = LibraryLayout.ORIGINAL.copy(pinned = false)
        assertEquals(emptyList<LibraryBlock>(), unpinned.pinnedBlocks)
        assertEquals(listOf(B.Search, B.Status, B.Tools, B.Scanner), unpinned.scrollingBlocks)
    }

    @Test
    fun hiddenBlocksDoNotBreakPinning() {
        val l = LibraryLayout.ORIGINAL.hiding(B.Search, true)
        assertEquals(listOf(B.Status, B.Tools), l.pinnedBlocks)
        val onlyScanner = LibraryLayout.ORIGINAL.hiding(B.Search, true).hiding(B.Status, true).hiding(B.Tools, true)
        assertEquals(emptyList<LibraryBlock>(), onlyScanner.pinnedBlocks)
        assertEquals(listOf(B.Scanner), onlyScanner.scrollingBlocks)
    }

    @Test
    fun normalizedRepairsOddLayouts() {
        val odd = LibraryLayout(
            order = listOf(B.Books, B.Tools, B.Tools, B.Search),
            hidden = setOf(B.Books, B.Status),
            off = setOf("tools.sort", "made.up"),
        ).normalized()
        assertEquals(listOf(B.Tools, B.Search, B.Status, B.Scanner, B.Books), odd.order)
        assertEquals(setOf(B.Status), odd.hidden)
        assertEquals(setOf("tools.sort"), odd.off)
        assertEquals(odd, odd.normalized())
    }

    @Test
    fun presetsAreValidAndMatchThemselves() {
        for (preset in LibraryPresets.all) {
            assertEquals(preset.layout.normalized(), preset.layout)
            assertTrue(preset.matches(preset.layout))
            assertTrue(preset.layout.isVisible(B.Books))
        }
        assertEquals(LibraryPresets.all.size, LibraryPresets.all.map { it.key }.toSet().size)
        assertEquals(LibraryLayout.ORIGINAL, LibraryPresets.all.first().layout)
        val booksOnly = LibraryPresets.all.first { it.key == "books" }
        assertEquals(listOf(B.Books), booksOnly.layout.shown)
        // applying a preset keeps the spacing and pinning chosen so far
        val mine = LibraryLayout(spacing = LibrarySpacing.Roomy, pinned = false)
        val applied = booksOnly.appliedTo(mine)
        assertEquals(LibrarySpacing.Roomy, applied.spacing)
        assertFalse(applied.pinned)
        assertEquals(listOf(B.Books), applied.shown)
        assertTrue(booksOnly.matches(applied))
    }

    @Test
    fun codecRoundTrips() {
        val l = LibraryLayout(
            order = listOf(B.Scanner, B.Tools, B.Search, B.Status, B.Books),
            hidden = setOf(B.Status),
            off = setOf("tools.genre", "status.favorites"),
            spacing = LibrarySpacing.Compact,
            pinned = false,
        )
        assertEquals(l, LibraryLayoutCodec.decode(LibraryLayoutCodec.encode(l)))
        assertEquals(LibraryLayout.ORIGINAL, LibraryLayoutCodec.decode(LibraryLayoutCodec.encode(LibraryLayout.ORIGINAL)))
        for (preset in LibraryPresets.all) {
            assertEquals(preset.layout, LibraryLayoutCodec.decode(LibraryLayoutCodec.encode(preset.layout)))
        }
    }

    @Test
    fun codecRejectsForeignTextAndToleratesJunk() {
        assertNull(LibraryLayoutCodec.decode(""))
        assertNull(LibraryLayoutCodec.decode("pb1\nname=x"))
        val decoded = LibraryLayoutCodec.decode("pl1\norder=tools,nonsense,search\nhidden=books,scanner\nspacing=Huge\nwhat\npinned=1\n")!!
        assertEquals(listOf(B.Tools, B.Search, B.Status, B.Scanner, B.Books), decoded.order)
        assertEquals(setOf(B.Scanner), decoded.hidden)
        assertEquals(LibrarySpacing.Cozy, decoded.spacing)
        assertNotEquals(LibraryLayout.ORIGINAL, decoded)
    }

    @Test
    fun viewFollowsTheTwoSavedSwitches() {
        assertEquals(LibraryView.Frosted, LibraryView.of(frosted = true, shelves = true))
        assertEquals(LibraryView.Frosted, LibraryView.of(frosted = true, shelves = false))
        assertEquals(LibraryView.Shelves, LibraryView.of(frosted = false, shelves = true))
        assertEquals(LibraryView.Covers, LibraryView.of(frosted = false, shelves = false))
    }

    @Test
    fun everyBlockHasAKeyThatFindsItAgain() {
        for (b in LibraryBlock.entries) assertEquals(b, LibraryBlock.of(b.key))
        assertEquals(LibraryBlock.entries.size, LibraryBlock.entries.map { it.key }.toSet().size)
        assertNull(LibraryBlock.of("nope"))
    }
}
