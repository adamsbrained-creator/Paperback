package com.paperback.app.reader

import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.content.Intent
import com.paperback.app.data.QUICK_DICTIONARY
import com.paperback.app.data.QUICK_SEARCH
import com.paperback.app.data.QUICK_SHARE
import com.paperback.app.data.QUICK_SPEAK
import com.paperback.app.data.TOOL_COPY
import com.paperback.app.data.TOOL_DICTIONARY
import com.paperback.app.data.TOOL_HIGHLIGHT
import com.paperback.app.data.TOOL_NOTE
import com.paperback.app.data.TOOL_SEARCH
import com.paperback.app.data.TOOL_SHARE
import com.paperback.app.data.TOOL_SPEAK
import com.paperback.app.data.ReaderFonts
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.core.view.ViewCompat
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.ui.unit.dp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.material3.Text
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.ComposeView
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commitNow
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.paperback.app.PaperbackApp
import com.paperback.app.R
import com.paperback.app.data.Bookmark
import com.paperback.app.data.Highlight
import com.paperback.app.data.HighlightColors
import com.paperback.app.data.ReaderLook
import com.paperback.app.data.EpubSizes
import com.paperback.app.data.LocationCounter
import com.paperback.app.data.ReaderPlace
import com.paperback.app.data.TocRef
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PaperbackTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Collections
import java.util.zip.ZipFile
import kotlin.math.ceil
import org.json.JSONObject
import org.json.JSONTokener
import org.readium.r2.navigator.DecorableNavigator
import org.readium.r2.navigator.Decoration
import org.readium.r2.navigator.epub.EpubNavigatorFragment
import org.readium.r2.navigator.input.InputListener
import org.readium.r2.navigator.input.TapEvent
import org.readium.r2.shared.publication.Link
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.services.search.search
import org.readium.r2.shared.publication.services.locateProgression
import org.readium.r2.shared.publication.services.positions

class ReaderActivity : FragmentActivity() {

    private val graph get() = (application as PaperbackApp).graph

    private var session: ReaderSession? = null
    private var navigator: EpubNavigatorFragment? = null
    private val tracker = ReadingTracker()

    private val chromeVisible = mutableStateOf(false)
    private val locatorState = mutableStateOf<Locator?>(null)
    private val fontSizeState = mutableDoubleStateOf(1.0)
    /** What the reader picked: a page colour, or -1 (Auto) to follow the phone. */
    private val themeState = mutableIntStateOf(ReaderThemes.AUTO)

    /** True while the phone is in its dark theme; it decides the page colour while the choice is Auto. */
    private val darkState = mutableStateOf(false)

    private val bookmarks = mutableStateOf<List<Bookmark>>(emptyList())
    private val highlights = mutableStateOf<List<Highlight>>(emptyList())
    private val panelOpen = mutableStateOf(false)
    private val editor = mutableStateOf<NoteEditorState?>(null)

    private val panelTab = mutableIntStateOf(0)
    private val toc = mutableStateOf<List<TocEntry>>(emptyList())
    private val lookOpen = mutableStateOf(false)
    private val autoScroll = mutableStateOf(false)
    private val autoPaused = mutableStateOf(false)
    private var autoJob: Job? = null
    private val lookState = mutableStateOf(ReaderLook())
    private val searchOpen = mutableStateOf(false)
    private val searchUi = mutableStateOf(SearchUi())
    private var searchJob: Job? = null

    // Chapter name and "pages left" in the margins (see ReaderMarginInfo).
    private var tocRefs: List<TocRef> = emptyList()
    private var resourceByHref: Map<String, Int> = emptyMap()
    private val positionsPerResource = mutableStateOf<List<Int>>(emptyList())
    private val screenCount = mutableIntStateOf(0)
    private val screenHref = mutableStateOf("")
    private var measureJob: Job? = null
    private var resourceCount = 0
    private var hrefByIndex: List<String> = emptyList()
    private val locationCounter = mutableStateOf<LocationCounter?>(null)
    private var settleUntil = 0L

    /**
     * The little menu that appears when you select text. Reader settings → Selection chooses which tools it shows (Highlight, Note,
     * Copy, Dictionary, Search, Speak, Share) and an optional quick action that runs by itself the moment text is selected.
     */
    private val selectionCallback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            val l = lookState.value
            var order = 0
            fun add(flag: Int, id: Int, title: String) {
                if (l.tools and flag != 0) menu.add(Menu.NONE, id, order++, title)
            }
            add(TOOL_HIGHLIGHT, MENU_HIGHLIGHT, "Highlight")
            add(TOOL_NOTE, MENU_NOTE, "Note")
            add(TOOL_COPY, MENU_COPY, if (l.copyToNotebook) "Copy to notebook" else "Copy")
            add(TOOL_DICTIONARY, MENU_DICTIONARY, "Dictionary")
            add(TOOL_SEARCH, MENU_SEARCH, "Search")
            add(TOOL_SPEAK, MENU_SPEAK, "Speak")
            add(TOOL_SHARE, MENU_SHARE, "Share")
            val quick = when (l.quickAction) {
                QUICK_DICTIONARY -> MENU_DICTIONARY
                QUICK_SEARCH -> MENU_SEARCH
                QUICK_SPEAK -> MENU_SPEAK
                QUICK_SHARE -> MENU_SHARE
                else -> 0
            }
            if (quick != 0) {
                lifecycleScope.launch {
                    delay(250) // let the selection settle
                    val text = navigator?.currentSelection()?.locator?.text?.highlight.orEmpty().trim()
                    if (text.isNotEmpty()) runSelectionAction(quick, text, mode = null)
                }
            }
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            val id = item.itemId
            if (id != MENU_HIGHLIGHT && id != MENU_NOTE && id != MENU_COPY && id != MENU_DICTIONARY &&
                id != MENU_SEARCH && id != MENU_SPEAK && id != MENU_SHARE
            ) return false
            val nav = navigator
            val s = session
            if (nav == null || s == null) {
                mode.finish()
                return true
            }
            lifecycleScope.launch {
                // Read the selection first, then close the menu (closing it clears the selection).
                val selection = nav.currentSelection()
                if (selection != null) {
                    val quote = selection.locator.text.highlight.orEmpty()
                    when (id) {
                        MENU_NOTE -> editor.value = NoteEditorState(null, selection.locator, quote, "", HighlightColors.DEFAULT)
                        MENU_HIGHLIGHT -> {
                            graph.repo.addHighlight(s.book.id, selection.locator, quote, "", HighlightColors.DEFAULT)
                            highlights.value = graph.repo.highlights(s.book.id)
                        }
                        else -> runSelectionAction(id, quote.trim(), mode = mode, locator = selection.locator)
                    }
                }
                mode.finish()
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode) {}
    }

    /** What the selection tools do with the selected [text]. [locator] is only needed for Copy to notebook. */
    private fun runSelectionAction(id: Int, text: String, mode: ActionMode?, locator: Locator? = null) {
        if (text.isEmpty()) return
        when (id) {
            MENU_COPY -> {
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Paperback", text))
                val s = session
                if (lookState.value.copyToNotebook && s != null && locator != null) {
                    lifecycleScope.launch {
                        graph.repo.addHighlight(s.book.id, locator, text, "", HighlightColors.DEFAULT)
                        highlights.value = graph.repo.highlights(s.book.id)
                    }
                }
            }
            MENU_DICTIONARY -> {
                // Any dictionary or translate app on the phone can take the text; if there is none, a web search does.
                val process = Intent(Intent.ACTION_PROCESS_TEXT).setType("text/plain")
                    .putExtra(Intent.EXTRA_PROCESS_TEXT, text)
                    .putExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, true)
                try {
                    startActivity(Intent.createChooser(process, "Look up"))
                } catch (_: Exception) {
                    runCatching {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode("define $text"))))
                    }
                }
            }
            MENU_SEARCH -> {
                mode?.finish()
                chromeVisible.value = false
                searchUi.value = searchUi.value.copy(query = text)
                searchOpen.value = true
                runSearch()
            }
            MENU_SPEAK -> speak(text)
            MENU_SHARE -> {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(send, null))
            }
        }
    }

    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false
    private var ttsPending: String? = null

    /** Reads the selected text aloud with the phone's own voice. */
    private fun speak(text: String) {
        val engine = tts
        if (engine != null && ttsReady) {
            engine.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "paperback-selection")
            return
        }
        ttsPending = text
        if (engine == null) {
            tts = android.speech.tts.TextToSpeech(this) { status ->
                ttsReady = status == android.speech.tts.TextToSpeech.SUCCESS
                if (ttsReady) ttsPending?.let { tts?.speak(it, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "paperback-selection") }
                ttsPending = null
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val s = graph.readerSession
        if (s == null) {
            // The app was killed and Android is restoring this screen with nothing to show. The Readium
            // fragment still needs *a* factory to be restored, so give it a dummy one and leave.
            supportFragmentManager.fragmentFactory = EpubNavigatorFragment.createDummyFactory()
            super.onCreate(null)
            finish()
            return
        }
        session = s
        fontSizeState.doubleValue = graph.settings.fontSize
        darkState.value = systemDark()
        themeState.intValue = graph.settings.theme
        lookState.value = graph.settings.look
        toc.value = buildToc(s)
        buildPlaceData(s)

        // IMPORTANT: the factory has to be set before super.onCreate().
        supportFragmentManager.fragmentFactory = s.navigatorFactory.createFragmentFactory(
            initialLocator = s.initialLocator,
            initialPreferences = graph.settings.toEpubPreferences(darkState.value),
            configuration = EpubNavigatorFragment.Configuration(selectionActionModeCallback = selectionCallback),
        )
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_reader)
        applyBand(lookState.value)
        applyKeepScreenOn(lookState.value.keepScreenOn)
        applyOrientation(lookState.value.orientation)
        applyPageBackground()
        loadPositions(s)

        if (savedInstanceState == null) {
            supportFragmentManager.commitNow {
                add(R.id.navigator_container, EpubNavigatorFragment::class.java, Bundle(), NAV_TAG)
            }
        }
        val nav = supportFragmentManager.findFragmentByTag(NAV_TAG) as EpubNavigatorFragment
        navigator = nav
        window.decorView.post { applyPageStyle(lookState.value) }

        // Tap near the left/right edge turns the page (the Behavior settings change how); tap in the middle shows or hides the controls.
        nav.addInputListener(
            object : InputListener {
                override fun onTap(event: TapEvent): Boolean {
                    val w = (nav.view?.width ?: resources.displayMetrics.widthPixels).toFloat().coerceAtLeast(1f)
                    return handleTap(event.point.x / w)
                }
            },
        )

        // Tap on a highlight: open it to edit the note, change the colour or delete it.
        nav.addDecorationListener(
            HIGHLIGHT_GROUP,
            object : DecorableNavigator.Listener {
                override fun onDecorationActivated(event: DecorableNavigator.OnActivatedEvent): Boolean {
                    val h = highlights.value.firstOrNull { it.id == event.decoration.id } ?: return false
                    editor.value = NoteEditorState(h.id, null, h.text, h.note, h.color)
                    return true
                }
            },
        )

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                nav.currentLocator.collect { onLocator(s, it) }
            }
        }

        // Keep the highlights drawn on the page in sync with the list.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                snapshotFlow { highlights.value }.collect { list ->
                    nav.applyDecorations(toDecorations(list), HIGHLIGHT_GROUP)
                }
            }
        }

        lifecycleScope.launch {
            bookmarks.value = graph.repo.bookmarks(s.book.id)
            highlights.value = graph.repo.highlights(s.book.id)
        }

        val pace = Stats.paceSecondsPerPosition(graph.repo.sessions.value)

        findViewById<ComposeView>(R.id.chrome).setContent {
            PaperbackTheme {
                val position = locatorState.value?.locations?.position ?: s.book.position
                Box(Modifier.fillMaxSize()) {
                    val place = placeInfo(locatorState.value)
                    ReaderMarginInfo(
                        themeIndex = effectiveTheme(),
                        hidden = chromeVisible.value,
                        chapter = place.chapter,
                        pagesLeft = place.pagesLeft,
                        position = if (place.location > 0) place.location else locatorState.value?.locations?.position ?: 0,
                        totalPositions = if (place.location > 0) place.locationTotal else s.totalPositions,
                        headerSpace = lookState.value.headerSpace,
                        bottomSpace = lookState.value.bottomSpace,
                        percent = (locatorState.value?.locations?.totalProgression ?: s.book.progress.toDouble()).toFloat(),
                        footerItems = lookState.value.footerItems,
                        showHeader = lookState.value.showHeader,
                        headerSize = lookState.value.headerSize,
                        footerSize = lookState.value.footerSize,
                        secondsLeft = pace?.let { ((s.totalPositions - position).coerceAtLeast(0) * it).toLong() },
                    )
                    ReaderChrome(
                        title = s.book.title,
                        visible = chromeVisible.value,
                        position = position,
                        totalPositions = s.totalPositions,
                        shownPosition = if (place.location > 0) place.location else position,
                        shownTotal = if (place.location > 0) place.locationTotal else s.totalPositions,
                        progress = (locatorState.value?.locations?.totalProgression ?: s.book.progress.toDouble()).toFloat(),
                        secondsPerPage = pace,
                        fontSize = fontSizeState.doubleValue,
                        themeIndex = effectiveTheme(),
                        themeChoice = themeState.intValue,
                        brightness = lookState.value.brightness,
                        style = chromeStyle,
                        bookmarked = bookmarks.value.any { it.position == position },
                        onBack = { finish() },
                        onToggleBookmark = { toggleBookmark() },
                        onOpenPanel = { openPanel(1) },
                        onOpenContents = { openPanel(0) },
                        onOpenSearch = {
                            chromeVisible.value = false
                            searchOpen.value = true
                        },
                        onOpenLook = {
                            chromeVisible.value = false
                            lookOpen.value = true
                        },
                        onSeek = { fraction ->
                            // locateProgression is a suspend function, so it needs a coroutine.
                            lifecycleScope.launch {
                                s.publication.locateProgression(fraction.toDouble())?.let { nav.go(it) }
                            }
                        },
                        onFontSize = { delta -> changeFontSize(delta) },
                        onTheme = { index -> changeTheme(index) },
                        onBrightness = { value -> changeLook(lookState.value.copy(brightness = value)) },
                        scrolled = lookState.value.scrolled,
                        invertImages = lookState.value.invertImages,
                        onSetScrolled = { on -> changeLook(lookState.value.copy(scrolled = on)) },
                        onSetInvertImages = { on -> changeLook(lookState.value.copy(invertImages = on)) },
                        autoScroll = autoScroll.value,
                        onToggleAutoScroll = {
                            chromeVisible.value = false
                            setAutoScroll(!autoScroll.value)
                        },
                    )

                    // Auto scroll controls: slower, faster, pause (a tap on the page does the same) and stop.
                    if (autoScroll.value && !chromeVisible.value) {
                        val ac = readerColors(effectiveTheme())
                        Row(
                            Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 72.dp)
                                .clip(androidx.compose.foundation.shape.RoundedCornerShape(22.dp))
                                .background(ac.card)
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            val speed = lookState.value.autoScrollSpeed
                            Pill(ac, "\u2212") { changeLook(lookState.value.copy(autoScrollSpeed = (speed - 25).coerceAtLeast(25))) }
                            Text("$speed%", color = ac.ink, fontSize = 14.sp)
                            Pill(ac, "+") { changeLook(lookState.value.copy(autoScrollSpeed = (speed + 25).coerceAtMost(500))) }
                            Pill(ac, if (autoPaused.value) "Resume" else "Pause") { autoPaused.value = !autoPaused.value }
                            Pill(ac, "Stop") { setAutoScroll(false) }
                        }
                    }

                    // Pull down to bookmark: drag down from the top edge; past the line, letting go adds or removes the bookmark.
                    // A tap in this strip is passed on to handleTap, so page turns and the controls still work there.
                    if (lookState.value.pullBookmark && !chromeVisible.value) {
                        var pull by remember { mutableFloatStateOf(0f) }
                        val strip = maxOf(lookState.value.topSpace, 48f).dp
                        val bookmarkedHere = bookmarks.value.any { it.position == position }
                        Box(
                            Modifier
                                .align(Alignment.TopStart)
                                .fillMaxWidth()
                                .height(strip)
                                .pointerInput(Unit) {
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        val density = this.density
                                        var total = Offset.Zero
                                        var pulling = false
                                        while (true) {
                                            val ev = awaitPointerEvent()
                                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                            if (!ch.pressed) {
                                                if (pulling) {
                                                    if (pull >= 100f) toggleBookmark()
                                                } else if (total.getDistance() < viewConfiguration.touchSlop) {
                                                    handleTap(down.position.x / size.width.coerceAtLeast(1))
                                                }
                                                pull = 0f
                                                break
                                            }
                                            total += ch.positionChange()
                                            val dy = total.y / density
                                            if (!pulling && dy >= 18f && dy > kotlin.math.abs(total.x / density)) pulling = true
                                            if (pulling) {
                                                ch.consume()
                                                pull = if (dy <= 120f) dy else 120f + (dy - 120f) * 0.35f
                                            }
                                        }
                                    }
                                },
                        )
                        if (pull > 0f) {
                            val pc = readerColors(effectiveTheme())
                            val past = pull >= 100f
                            // the ribbon shows what letting go would do: filled = bookmarked afterwards
                            val filled = if (past) !bookmarkedHere else bookmarkedHere
                            Box(
                                Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = (pull * 0.6f).dp)
                                    .clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(pc.card)
                                    .padding(10.dp),
                            ) {
                                com.paperback.app.ui.PbIcon(
                                    com.paperback.app.ui.PbIconName.Bookmark,
                                    size = 24.dp,
                                    tint = if (past) androidx.compose.material3.MaterialTheme.colorScheme.primary else pc.ink,
                                    filled = filled,
                                    contentDescription = "Bookmark",
                                )
                            }
                        }
                    }

                    // Behavior → Swipe for brightness: a thin strip along the left edge that you slide up or down.
                    if (lookState.value.brightnessSwipe) {
                        Box(
                            Modifier
                                .align(Alignment.CenterStart)
                                .fillMaxHeight(0.7f)
                                .width(28.dp)
                                .pointerInput(Unit) {
                                    detectVerticalDragGestures { change, dy ->
                                        change.consume()
                                        val l = lookState.value
                                        val cur = if (l.brightness >= 0f) l.brightness
                                        else window.attributes.screenBrightness.takeIf { it >= 0f } ?: 0.5f
                                        val next = (cur - dy / size.height * 1.3f).coerceIn(0.05f, 1f)
                                        changeLook(l.copy(brightness = next))
                                    }
                                },
                        )
                    }

                    if (panelOpen.value) {
                        ReaderPanel(
                            themeIndex = effectiveTheme(),
                            initialTab = panelTab.intValue,
                            toc = toc.value,
                            currentHref = locatorState.value?.href?.toString(),
                            bookmarks = bookmarks.value,
                            highlights = highlights.value,
                            onGo = { json -> goTo(json) },
                            onDeleteBookmark = { b -> deleteBookmark(b) },
                            onDeleteHighlight = { h -> deleteHighlight(h) },
                            onClose = { panelOpen.value = false },
                        )
                    }

                    if (lookOpen.value) {
                        ReaderLookSheet(
                            themeIndex = effectiveTheme(),
                            themeChoice = themeState.intValue,
                            fontSize = fontSizeState.doubleValue,
                            look = lookState.value,
                            onFontSize = { value -> setFontSize(value) },
                            onTheme = { index -> changeTheme(index) },
                            onLook = { look -> changeLook(look) },
                            onClose = { lookOpen.value = false },
                            modifier = Modifier.align(Alignment.BottomStart),
                        )
                    }

                    if (searchOpen.value) {
                        ReaderSearchPanel(
                            themeIndex = effectiveTheme(),
                            ui = searchUi.value,
                            onQuery = { q -> searchUi.value = searchUi.value.copy(query = q) },
                            onSubmit = { runSearch() },
                            onGo = { hit -> goToHit(hit) },
                            onClose = { closeSearch() },
                        )
                    }

                    editor.value?.let { state ->
                        NoteEditorDialog(
                            state = state,
                            themeIndex = effectiveTheme(),
                            onSave = { note, color -> saveEditor(state, note, color) },
                            onDelete = state.highlightId?.let { id -> { deleteHighlightById(id) } },
                            onDismiss = { editor.value = null },
                        )
                    }
                }
            }
        }

        hideSystemBars()
        applyBrightness(lookState.value.brightness)
    }

    // ---- reading position and time --------------------------------------------------------

    private fun onLocator(s: ReaderSession, locator: Locator) {
        locatorState.value = locator
        scheduleMeasure(false, 150L, 450L, 1000L, 2000L)
        tracker.onPosition(System.currentTimeMillis(), locator.locations.position ?: 0)
        graph.appScope.launch { graph.repo.saveProgress(s.book.id, locator) }
    }

    private fun changeFontSize(delta: Double) {
        val next = (fontSizeState.doubleValue + delta).coerceIn(0.6, 2.5)
        fontSizeState.doubleValue = next
        graph.settings.fontSize = next
        navigator?.submitPreferences(graph.settings.toEpubPreferences(darkState.value))
        relayout()
    }

    private fun setFontSize(value: Double) {
        val next = value.coerceIn(0.6, 2.5)
        fontSizeState.doubleValue = next
        graph.settings.fontSize = next
        navigator?.submitPreferences(graph.settings.toEpubPreferences(darkState.value))
        relayout()
    }

    private fun changeLook(look: ReaderLook) {
        lookState.value = look
        graph.settings.look = look
        applyBand(look)
        applyKeepScreenOn(look.keepScreenOn)
        applyOrientation(look.orientation)
        if (!look.scrolled && autoScroll.value) setAutoScroll(false)
        window.decorView.post { applyPageStyle(look) }
        navigator?.submitPreferences(graph.settings.toEpubPreferences(darkState.value))
        relayout()
        applyBrightness(look.brightness)
    }

    /** A value from 0.05 to 1 dims or brightens this screen only; below zero follows the phone again. */
    private fun applyBrightness(value: Float) {
        val attrs = window.attributes
        attrs.screenBrightness = if (value < 0f) android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else value.coerceIn(0.05f, 1f)
        window.attributes = attrs
    }

    private fun changeTheme(index: Int) {
        themeState.intValue = index
        graph.settings.theme = index
        navigator?.submitPreferences(graph.settings.toEpubPreferences(darkState.value))
        applyPageBackground()
    }

    // ---- bookmarks, highlights, notes -----------------------------------------------------

    private fun toggleBookmark() {
        val s = session ?: return
        val loc = locatorState.value ?: return
        val position = loc.locations.position ?: return
        lifecycleScope.launch {
            val existing = bookmarks.value.firstOrNull { it.position == position }
            if (existing != null) graph.repo.removeBookmark(existing.id) else graph.repo.addBookmark(s.book.id, loc)
            bookmarks.value = graph.repo.bookmarks(s.book.id)
        }
    }

    private fun deleteBookmark(b: Bookmark) {
        val s = session ?: return
        lifecycleScope.launch {
            graph.repo.removeBookmark(b.id)
            bookmarks.value = graph.repo.bookmarks(s.book.id)
        }
    }

    private fun saveEditor(state: NoteEditorState, note: String, color: Int) {
        val s = session ?: return
        editor.value = null
        lifecycleScope.launch {
            val id = state.highlightId
            val locator = state.locator
            if (id != null) graph.repo.updateHighlight(id, note, color)
            else if (locator != null) graph.repo.addHighlight(s.book.id, locator, state.quote, note, color)
            highlights.value = graph.repo.highlights(s.book.id)
        }
    }

    private fun deleteHighlight(h: Highlight) = deleteHighlightById(h.id)

    private fun deleteHighlightById(id: String) {
        val s = session ?: return
        editor.value = null
        lifecycleScope.launch {
            graph.repo.removeHighlight(id)
            highlights.value = graph.repo.highlights(s.book.id)
        }
    }

    /**
     * A tap at [fraction] of the screen width (0 = left edge). While auto scroll runs a tap pauses or resumes it. Otherwise the edges turn
     * the page (the Behavior settings change how) and the middle shows or hides the controls.
     */
    private fun handleTap(fraction: Float): Boolean {
        val nav = navigator ?: return false
        val l = lookState.value
        if (autoScroll.value) {
            autoPaused.value = !autoPaused.value
            return true
        }
        if (l.tapTurn && !l.scrolled) {
            val left = fraction < 0.3f
            val right = fraction > 0.7f
            if (left || right) {
                // "Left" means the page on the left: the previous one in a left-to-right book, the next one in a right-to-left book.
                val rtl = when (l.direction) {
                    1 -> false
                    2 -> true
                    else -> session?.publication?.metadata?.readingProgression?.toString().equals("rtl", ignoreCase = true)
                }
                val forward = when {
                    l.tapBoth -> true
                    left -> (rtl) != l.swapTaps
                    else -> (!rtl) != l.swapTaps
                }
                if (forward) nav.goForward(animated = l.pageAnimation) else nav.goBackward(animated = l.pageAnimation)
                return true
            }
        }
        chromeVisible.value = !chromeVisible.value
        return true
    }

    /**
     * Auto scroll, from the TypeScript version: a slow, steady scroll in scrolled mode, 20 dp per second at 100%. It steps the page view
     * a little every frame, and when the page stops moving for 0.8 s it goes on to the next chapter; at the end of the book it stops.
     */
    private fun setAutoScroll(on: Boolean) {
        autoJob?.cancel()
        autoJob = null
        autoScroll.value = on
        autoPaused.value = false
        if (!on) return
        autoJob = lifecycleScope.launch {
            var last = System.nanoTime()
            var residual = 0f
            var stalledMs = 0
            while (true) {
                delay(16)
                val now = System.nanoTime()
                val dt = (now - last) / 1_000_000_000f
                last = now
                if (autoPaused.value || panelOpen.value || lookOpen.value || searchOpen.value || chromeVisible.value) continue
                val web = navigator?.view?.let { visibleWebView(it) } ?: continue
                residual += 20f * lookState.value.autoScrollSpeed / 100f * resources.displayMetrics.density * dt
                val step = residual.toInt()
                if (step < 1) continue
                residual -= step
                val before = web.scrollY
                web.scrollBy(0, step)
                if (web.scrollY == before) stalledMs += 16 * step.coerceAtMost(4) else stalledMs = 0
                if (stalledMs >= 800) {
                    stalledMs = 0
                    if (navigator?.goForward() != true) {
                        autoScroll.value = false
                        break
                    }
                }
            }
        }
    }

    // Volume keys turn the page when the reader asked for it (Behavior → Volume keys turn pages).
    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (lookState.value.volumeKeys && (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP || keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (event?.repeatCount == 0) {
                val animated = lookState.value.pageAnimation
                if (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP) navigator?.goBackward(animated = animated) else navigator?.goForward(animated = animated)
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (lookState.value.volumeKeys && (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP || keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN)) return true
        return super.onKeyUp(keyCode, event)
    }

    /**
     * Paging animation style. Readium turns pages with an Android ViewPager, whose page transformer decides how the two pages move:
     * Push is the plain strip (the transformer only resets the pages), Slide keeps the incoming page still underneath while the
     * outgoing one slides away over it. The pager is found in the view tree and driven by reflection, so an engine update that
     * changes it only switches the style off instead of breaking the reader.
     */
    private fun applyPageStyle(look: ReaderLook) {
        val root = navigator?.view ?: return
        fun find(v: View): View? {
            if (generateSequence<Class<*>>(v.javaClass) { it.superclass }.any { it.name == "androidx.viewpager.widget.ViewPager" }) return v
            if (v is ViewGroup) for (i in 0 until v.childCount) find(v.getChildAt(i))?.let { return it }
            return null
        }
        val pager = find(root) ?: return
        try {
            val base = generateSequence<Class<*>>(pager.javaClass) { it.superclass }.first { it.name == "androidx.viewpager.widget.ViewPager" }
            val transformer = Class.forName("androidx.viewpager.widget.ViewPager\$PageTransformer")
            // Slide is skipped on right-to-left pagers, where the page positions run the other way.
            val slide = look.pageAnimation && look.pageStyle == 1 && !pager.javaClass.name.contains("RTL")
            val proxy = java.lang.reflect.Proxy.newProxyInstance(transformer.classLoader, arrayOf(transformer)) { self, method, args ->
                when (method.name) {
                    "transformPage" -> {
                        val page = args[0] as View
                        val pos = args[1] as Float
                        if (slide && pos > 0f && pos <= 1f) page.translationX = -page.width * pos else page.translationX = 0f
                        null
                    }
                    "hashCode" -> 0
                    "equals" -> args[0] === self
                    else -> "PageTransformer"
                }
            }
            base.getMethod("setPageTransformer", java.lang.Boolean.TYPE, transformer).invoke(pager, slide, proxy)
        } catch (_: Throwable) {
            // leave the pager as Readium made it
        }
    }

    private fun applyOrientation(mode: Int) {
        requestedOrientation = when (mode) {
            1 -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun openPanel(tab: Int) {
        panelTab.intValue = tab
        chromeVisible.value = false
        panelOpen.value = true
    }

    /** The book's table of contents as a flat list, each line remembering how deep it is nested. */
    private fun buildToc(s: ReaderSession): List<TocEntry> {
        val out = ArrayList<TocEntry>()
        fun walk(links: List<Link>, depth: Int) {
            for (link in links) {
                val locator = s.publication.locatorFromLink(link)
                if (locator != null) {
                    out += TocEntry(
                        title = link.title?.trim().orEmpty().ifBlank { "Untitled" },
                        depth = depth,
                        locatorJson = locator.toJSON().toString(),
                        href = locator.href.toString(),
                    )
                }
                walk(link.children, depth + 1)
            }
        }
        walk(s.publication.tableOfContents, 0)
        return out
    }

    // ---- chapter name and "pages left in chapter" in the margins -----------------------------

    private class PlaceInfo(val chapter: String, val pagesLeft: Int, val location: Int = 0, val locationTotal: Int = 0)

    /** Which file of the book each contents entry starts in, and which file every href is (in reading order). */
    private fun buildPlaceData(s: ReaderSession) {
        val byHref = HashMap<String, Int>()
        s.publication.readingOrder.forEachIndexed { i, link ->
            s.publication.locatorFromLink(link)?.let { byHref[it.href.toString().substringBefore('#')] = i }
        }
        resourceByHref = byHref
        hrefByIndex = List(s.publication.readingOrder.size) { i -> byHref.entries.firstOrNull { it.value == i }?.key.orEmpty() }
        resourceCount = s.publication.readingOrder.size
        val refs = ArrayList<TocRef>()
        fun walk(links: List<Link>) {
            for (link in links) {
                val locator = s.publication.locatorFromLink(link)
                val resource = locator?.let { byHref[it.href.toString().substringBefore('#')] } ?: -1
                refs += TocRef(link.title?.trim().orEmpty(), resource)
                walk(link.children)
            }
        }
        walk(s.publication.tableOfContents)
        tocRefs = refs
    }

    /** How many reading "positions" each file has (Readium's own count, the same one the "2 / 196" counter uses). */
    private fun loadPositions(s: ReaderSession) {
        lifecycleScope.launch {
            val all = s.publication.positions()
            val counts = withContext(Dispatchers.Default) {
                val c = IntArray(resourceCount)
                for (p in all) {
                    val r = resourceByHref[p.href.toString().substringBefore('#')] ?: continue
                    c[r]++
                }
                c.toList()
            }
            positionsPerResource.value = counts
            // The unpacked size of every file of the book, read from the EPUB (a zip) itself; the "25 / 136" counter is cut from it.
            val sizes = withContext(Dispatchers.IO) {
                val entries = runCatching {
                    ZipFile(File(s.book.filePath)).use { z -> Collections.list(z.entries()).associate { it.name to it.size } }
                }.getOrDefault(emptyMap())
                if (entries.isEmpty()) null
                else List(resourceCount) { i -> EpubSizes.sizeOf(entries, hrefByIndex[i]) ?: (counts.getOrElse(i) { 0 } * 3072L) }
            }
            if (sizes != null) locationCounter.value = LocationCounter(sizes)
        }
    }

    private fun placeInfo(locator: Locator?): PlaceInfo {
        locator ?: return PlaceInfo("", 0)
        val href = locator.href.toString().substringBefore('#')
        val resource = resourceByHref[href] ?: return PlaceInfo("", 0)
        val chapter = ReaderPlace.chapterIndex(tocRefs, resource)
        val title = if (chapter >= 0) tocRefs[chapter].title else ""
        val counter = locationCounter.value
        val location = counter?.current(resource, locator.locations.progression ?: 0.0) ?: 0
        val locationTotal = counter?.total ?: 0
        val screens = screenCount.intValue
        if (screens <= 0 || screenHref.value != href) return PlaceInfo(title, 0, location, locationTotal)
        val perResource = positionsPerResource.value
        val end = if (chapter >= 0) ReaderPlace.chapterEnd(tocRefs, chapter, resourceCount) else resource + 1
        val left = ReaderPlace.pagesLeft(
            screens = screens,
            screenIndex = ReaderPlace.screenIndex(locator.locations.progression ?: 0.0, screens),
            positionsHere = perResource.getOrElse(resource) { 0 },
            positionsAfter = ReaderPlace.positionsAfter(perResource, resource, end),
        )
        return PlaceInfo(title, left, location, locationTotal)
    }

    /** The page changed shape (text size, margins, font): forget the old screen count and measure again. */
    private fun relayout() {
        screenHref.value = ""
        settleUntil = System.currentTimeMillis() + 4000L
        scheduleMeasure(true, 500L, 1000L, 2000L, 3500L)
    }

    /** The text is measured a few times, because the page can still be laying itself out (images, fonts) for a moment. */
    private fun scheduleMeasure(settle: Boolean, vararg delaysMs: Long) {
        // While a size change is settling its own measuring job runs; a page turn must not cancel it.
        if (!settle && System.currentTimeMillis() < settleUntil) return
        measureJob?.cancel()
        measureJob = lifecycleScope.launch {
            for (d in delaysMs) {
                delay(d)
                measureScreens()
            }
        }
    }

    /** Asks the page on screen how wide it is: its width divided by the screen width is the number of pages in this file. */
    private val fontData = HashMap<String, String>()

    /**
     * An imported font file is not something the reading engine can serve, so it is given to the page itself: once per page, as a
     * data address through the page's FontFace list. The page then reflows with it, and the screens are counted again.
     */
    private fun injectFont() {
        val l = lookState.value
        val name = l.fontName
        if (!l.custom || name.isBlank()) return
        val file = ReaderFonts.file(this, name) ?: return // not an imported font (a system font needs nothing)
        val web = navigator?.view?.let { visibleWebView(it) } ?: return
        val quoted = org.json.JSONObject.quote(name)
        web.evaluateJavascript("(function(){var n=$quoted;for(var f of document.fonts){if(f.family.replace(/[\"']/g,'')===n)return true}return false})()") { has ->
            if (has == "true") return@evaluateJavascript
            lifecycleScope.launch {
                val data = fontData[name] ?: withContext(Dispatchers.IO) {
                    android.util.Base64.encodeToString(file.readBytes(), android.util.Base64.NO_WRAP)
                }.also { fontData[name] = it }
                val js = "(function(){var n=$quoted;var f=new FontFace(n,'url(data:${ReaderFonts.mime(file)};base64,$data)');" +
                    "return f.load().then(function(){document.fonts.add(f);return 'ok'})})()"
                web.evaluateJavascript(js, null)
                scheduleMeasure(true, 600L, 1500L)
            }
        }
    }

    private fun measureScreens() {
        injectFont()
        val root = navigator?.view ?: return
        val web = visibleWebView(root) ?: return
        val href = locatorState.value?.href?.toString()?.substringBefore('#') ?: return
        web.evaluateJavascript(MEASURE_JS) { raw ->
            val text = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull() ?: return@evaluateJavascript
            val parts = text.split(',', limit = 3)
            val width = parts.getOrNull(0)?.toDoubleOrNull() ?: return@evaluateJavascript
            val inner = parts.getOrNull(1)?.toDoubleOrNull() ?: return@evaluateJavascript
            val path = Uri.decode(parts.getOrNull(2).orEmpty())
            // Only trust it when the page on screen really is the file we are in (same file name) (during a page change it may not be yet).
            if (inner <= 0.0 || path.substringAfterLast('/') != Uri.decode(href).substringAfterLast('/')) return@evaluateJavascript
            val n = ceil(width / inner - 0.25).toInt() // a spread can end on a half screen
            if (n >= 1) {
                screenCount.intValue = n
                screenHref.value = href
            }
        }
    }

    private fun visibleWebView(root: View): WebView? {
        var best: WebView? = null
        var bestWidth = 0
        fun walk(v: View) {
            if (v is WebView) {
                val r = Rect()
                if (v.isShown && v.getGlobalVisibleRect(r) && r.width() > bestWidth) {
                    best = v
                    bestWidth = r.width()
                }
            } else if (v is ViewGroup) {
                for (i in 0 until v.childCount) walk(v.getChildAt(i))
            }
        }
        walk(root)
        return best
    }

    private fun applyKeepScreenOn(on: Boolean) {
        if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    /** Sets how far the text stays from the top and bottom edges of the screen (the Top and Bottom sliders). */
    private fun applyBand(look: ReaderLook) {
        val root = findViewById<View>(R.id.reader_root)
        val container = findViewById<View>(R.id.navigator_container)
        // The same frame as Readest: fixed distances from the screen edges, the same as the strips drawn in ReaderMarginInfo.
        val d = resources.displayMetrics.density
        container.setPadding(0, (look.topSpace * d).toInt(), 0, (look.bottomSpace * d).toInt())
    }

    /** Behind the strips the page colour shows, so they look like part of the page. */
    private fun applyPageBackground() {
        findViewById<View>(R.id.reader_root)?.setBackgroundColor(readerColors(effectiveTheme()).page.toArgb())
    }

    // ---- search inside the book ----------------------------------------------------------

    private fun runSearch() {
        val s = session ?: return
        val query = searchUi.value.query.trim()
        searchJob?.cancel()
        clearSearchMark()
        if (query.length < 2) {
            searchUi.value = searchUi.value.copy(hits = emptyList(), running = false, done = false, capped = false, error = null)
            return
        }
        searchUi.value = searchUi.value.copy(hits = emptyList(), running = true, done = false, capped = false, error = null)
        searchJob = lifecycleScope.launch {
            val hits = ArrayList<SearchHit>()
            var error: String? = null
            var capped = false
            val iterator = s.publication.search(query)
            if (iterator == null) {
                error = "This book can't be searched."
            } else {
                try {
                    while (true) {
                        val page = iterator.next().getOrNull() ?: break
                        for (locator in page.locators) {
                            hits += SearchHit(
                                locatorJson = locator.toJSON().toString(),
                                before = locator.text.before.orEmpty(),
                                hit = locator.text.highlight.orEmpty(),
                                after = locator.text.after.orEmpty(),
                                chapter = locator.title,
                                progress = (locator.locations.totalProgression ?: 0.0).toFloat(),
                            )
                        }
                        searchUi.value = searchUi.value.copy(hits = hits.toList())
                        if (hits.size >= MAX_SEARCH_HITS) {
                            capped = true
                            break
                        }
                    }
                } finally {
                    iterator.close()
                }
            }
            searchUi.value = searchUi.value.copy(hits = hits.toList(), running = false, done = true, capped = capped, error = error)
        }
    }

    private fun goToHit(hit: SearchHit) {
        val nav = navigator ?: return
        val locator = runCatching { Locator.fromJSON(JSONObject(hit.locatorJson)) }.getOrNull() ?: return
        searchOpen.value = false
        chromeVisible.value = false
        lifecycleScope.launch {
            nav.go(locator)
            // Mark the match on the page until the next search (or until the book is closed).
            nav.applyDecorations(
                listOf(Decoration(id = "match", locator = locator, style = Decoration.Style.Highlight(tint = SEARCH_TINT))),
                SEARCH_GROUP,
            )
        }
    }

    private fun closeSearch() {
        searchOpen.value = false
    }

    private fun clearSearchMark() {
        val nav = navigator ?: return
        lifecycleScope.launch { nav.applyDecorations(emptyList(), SEARCH_GROUP) }
    }

    private fun goTo(locatorJson: String) {
        val nav = navigator ?: return
        val locator = runCatching { Locator.fromJSON(JSONObject(locatorJson)) }.getOrNull() ?: return
        panelOpen.value = false
        chromeVisible.value = false
        lifecycleScope.launch { nav.go(locator) }
    }

    private fun toDecorations(list: List<Highlight>): List<Decoration> = list.mapNotNull { h ->
        val locator = runCatching { Locator.fromJSON(JSONObject(h.locatorJson)) }.getOrNull() ?: return@mapNotNull null
        Decoration(id = h.id, locator = locator, style = Decoration.Style.Highlight(tint = h.color))
    }

    // ---- system bars: hidden for the whole reading session, so nothing resizes when controls toggle ----

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        val dark = systemDark()
        if (session != null && dark != darkState.value) {
            darkState.value = dark
            // On Auto the page changes colour with the phone's theme, as soon as it happens.
            if (themeState.intValue < 0) {
                navigator?.submitPreferences(graph.settings.toEpubPreferences(dark))
                applyPageBackground()
            }
        }
        if (session != null) relayout() // turning the phone changes how many screens a chapter has
    }

    private fun systemDark(): Boolean =
        (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    /** The page colour on screen: the reader's choice, or for Auto White / Black following the phone. */
    private fun effectiveTheme(): Int = ReaderThemes.resolve(themeState.intValue, darkState.value)

    /** Which layout of the bottom controls Settings → Reader defaults chose. */
    private val chromeStyle: Int get() = graph.settings.chromeStyle

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && session != null) hideSystemBars() // e.g. after a dialog closes
    }

    // ---- lifecycle ------------------------------------------------------------------------

    override fun onResume() {
        super.onResume()
        tracker.resume(System.currentTimeMillis())
    }

    override fun onPause() {
        if (autoScroll.value) setAutoScroll(false)
        super.onPause()
        val s = session ?: return
        tracker.pause(System.currentTimeMillis())?.let { flush ->
            // appScope, not lifecycleScope: this has to finish even if the activity is going away.
            graph.appScope.launch { graph.repo.addSession(s.book.id, flush.startMs, flush.seconds, flush.pages, flush.fromPos, flush.toPos) }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        tts = null
        super.onDestroy()
        if (isFinishing && session != null) graph.closeReader()
    }

    private companion object {
        const val NAV_TAG = "navigator"
        const val MEASURE_JS =
            "(function(){var e=document.scrollingElement||document.documentElement;" +
                "return [e.scrollWidth,window.innerWidth,location.pathname].join(',');})()"
        const val HIGHLIGHT_GROUP = "highlights"
        const val SEARCH_GROUP = "search"
        const val SEARCH_TINT = 0xFFFFC857.toInt()
        const val MAX_SEARCH_HITS = 200
        const val MENU_HIGHLIGHT = 1
        const val MENU_NOTE = 2
        const val MENU_COPY = 3
        const val MENU_DICTIONARY = 4
        const val MENU_SEARCH = 5
        const val MENU_SPEAK = 6
        const val MENU_SHARE = 7
    }
}
