package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.Bookmark
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.Highlight

/**
 * Every highlight, note and bookmark, across all books (or just one book). Tap one to open the book there.
 * [initialTab]: 0 = notes, 1 = bookmarks (the menu's "Bookmarks" opens this page on the second tab).
 */
@Composable
fun NotesScreen(
    books: List<Book>,
    highlights: List<Highlight>,
    bookmarks: List<Bookmark>,
    onlyBookId: String?,
    initialTab: Int,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenAt: (Book, String) -> Unit,
    onDeleteHighlight: (Highlight) -> Unit,
    onDeleteBookmark: (Bookmark) -> Unit,
    onShare: (String) -> Unit,
) {
    var tab by rememberSaveable(initialTab) { mutableStateOf(initialTab) }
    var query by rememberSaveable { mutableStateOf("") }
    val byId = remember(books) { books.associateBy { it.id } }
    val scoped = remember(onlyBookId, books) { books.firstOrNull { it.id == onlyBookId } }

    val shownHighlights = remember(highlights, query, onlyBookId) {
        val q = query.trim()
        highlights.filter { h ->
            (onlyBookId == null || h.bookId == onlyBookId) &&
                (q.isEmpty() || h.text.contains(q, ignoreCase = true) || h.note.contains(q, ignoreCase = true))
        }
    }
    val shownBookmarks = remember(bookmarks, onlyBookId) {
        bookmarks.filter { onlyBookId == null || it.bookId == onlyBookId }
    }

    PbListPage(scoped?.title ?: "Notes", headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TogglePill("Notes (${shownHighlights.size})", tab == 0) { tab = 0 }
            TogglePill("Bookmarks (${shownBookmarks.size})", tab == 1) { tab = 1 }
            if (tab == 0 && shownHighlights.isNotEmpty()) {
                Spacer(Modifier.weight(1f))
                Text(
                    "Share",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { onShare(buildNotesMarkdown(byId, shownHighlights)) }.padding(8.dp),
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        if (tab == 0) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search your notes") },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
            )
            if (shownHighlights.isEmpty()) {
                Text(
                    if (highlights.isEmpty()) "No notes yet. In the reader, select text and choose Highlight or Note." else "Nothing matches.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 16.dp),
                )
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 8.dp, bottom = 112.dp)) {
                    items(shownHighlights, key = { it.id }) { h ->
                        val book = byId[h.bookId]
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable(enabled = book != null) { book?.let { onOpenAt(it, h.locatorJson) } }
                                .padding(vertical = 12.dp),
                        ) {
                            Box(Modifier.width(4.dp).height(56.dp).clip(RoundedCornerShape(2.dp)).background(Color(h.color)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                if (onlyBookId == null) {
                                    Text(
                                        book?.title ?: "Removed book",
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                Text(h.text.ifBlank { "(no text)" }, fontSize = 15.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
                                if (h.note.isNotBlank()) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(h.note, fontSize = 14.sp, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Text(
                                "Remove",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                modifier = Modifier.clickable { onDeleteHighlight(h) }.padding(8.dp),
                            )
                        }
                    }
                }
            }
        } else {
            if (shownBookmarks.isEmpty()) {
                Text(
                    "No bookmarks yet. Tap the bookmark button at the top of a page in the reader.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 16.dp),
                )
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 112.dp)) {
                    items(shownBookmarks, key = { it.id }) { b ->
                        val book = byId[b.bookId]
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable(enabled = book != null) { book?.let { onOpenAt(it, b.locatorJson) } }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                if (onlyBookId == null) {
                                    Text(book?.title ?: "Removed book", fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(
                                    "Page ${b.position} \u00B7 ${(b.progress * 100).toInt().coerceIn(0, 100)}%",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 14.sp,
                                )
                            }
                            Text(
                                "Remove",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                modifier = Modifier.clickable { onDeleteBookmark(b) }.padding(8.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Notes as Markdown, grouped by book, ready to paste into any notes app. */
private fun buildNotesMarkdown(books: Map<String, Book>, highlights: List<Highlight>): String = buildString {
    highlights.groupBy { it.bookId }.forEach { (bookId, list) ->
        val book = books[bookId]
        append("## ").append(book?.title ?: "Removed book").append('\n')
        if (book != null && book.author.isNotBlank()) append("*").append(book.author).append("*\n")
        append('\n')
        list.sortedBy { it.progress }.forEach { h ->
            append("> ").append(h.text.replace("\n", " ")).append("\n\n")
            if (h.note.isNotBlank()) append(h.note).append("\n\n")
        }
    }
}
