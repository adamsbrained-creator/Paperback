package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.BookCollection
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.theme.PbSerif

@Composable
fun CollectionsScreen(
    collections: List<BookCollection>,
    membership: Map<String, Set<String>>,
    books: List<Book>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpen: (BookCollection) -> Unit,
    onCreate: (String) -> Unit,
) {
    var creating by remember { mutableStateOf(false) }

    PbListPage("Collections", headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(12.dp))
        PbButton("New collection", onClick = { creating = true }, ghost = true)
        Spacer(Modifier.height(8.dp))
        if (collections.isEmpty()) {
            Text(
                "No collections yet. Make one, like \u201CTo read in winter\u201D.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 16.dp),
            )
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 112.dp)) {
                items(collections, key = { it.id }) { c ->
                    val ids = membership[c.id].orEmpty()
                    val first = books.firstOrNull { it.id in ids }
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(c) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (first != null) BookCover(first, Modifier.width(48.dp)) else Box(Modifier.width(48.dp).height(72.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${ids.size} ${if (ids.size == 1) "book" else "books"}",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 14.sp,
                            )
                        }
                    }
                }
            }
        }
    }

    if (creating) {
        NameDialog(
            title = "New collection",
            initial = "",
            confirmLabel = "Create",
            onConfirm = { creating = false; onCreate(it) },
            onDismiss = { creating = false },
        )
    }
}

@Composable
fun CollectionDetailScreen(
    collection: BookCollection,
    allBooks: List<Book>,
    memberIds: Set<String>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenBook: (Book) -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onSetMember: (Book, Boolean) -> Unit,
) {
    var renaming by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val members = remember(allBooks, memberIds) { allBooks.filter { it.id in memberIds } }

    PbListPage(collection.name, headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(12.dp))
        PbButton("Add books", onClick = { adding = true })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { renaming = true }) { Text("Rename") }
            TextButton(onClick = { confirmDelete = true }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
        }
        if (members.isEmpty()) {
            Text("This collection is empty.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 16.dp))
        } else {
            CoverGrid(members, onOpenBook, Modifier.weight(1f))
        }
    }

    if (renaming) {
        NameDialog(
            title = "Rename collection",
            initial = collection.name,
            confirmLabel = "Save",
            onConfirm = { renaming = false; onRename(it) },
            onDismiss = { renaming = false },
        )
    }

    if (adding) {
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Add books") },
            text = {
                if (allBooks.isEmpty()) {
                    Text("Your library is empty.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(allBooks, key = { it.id }) { b ->
                            val inIt = b.id in memberIds
                            Row(
                                Modifier.fillMaxWidth().clickable { onSetMember(b, !inIt) }.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Checkbox(checked = inIt, onCheckedChange = { onSetMember(b, it) })
                                Text(b.title, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { adding = false }) { Text("Done") } },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this collection?") },
            text = { Text("The books stay in your library.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; onDelete() }) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

/** Covers in rows of three, scrolling. Used by collections and the shelf pages (Favorites, Finished...). */
@Composable
fun CoverGrid(books: List<Book>, onOpen: (Book) -> Unit, modifier: Modifier = Modifier) {
    val rows = remember(books) { books.chunked(3) }
    LazyColumn(modifier, contentPadding = PaddingValues(top = 12.dp, bottom = 112.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        items(rows, key = { row -> row.first().id }) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { b ->
                    Column(Modifier.weight(1f).clickable { onOpen(b) }) {
                        BookCover(b)
                        Spacer(Modifier.height(6.dp))
                        Text(b.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                placeholder = { Text("Name") },
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onConfirm(name.trim()) }) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
