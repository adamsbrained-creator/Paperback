package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.BookCollection
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/** One book: rating, favorite / finished, time read, collections, notes, journal. Reached from Library (long-press -> Details) or Home. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookDetailScreen(
    book: Book,
    sessions: List<ReadingSession>,
    collections: List<BookCollection>,
    membership: Map<String, Set<String>>,
    noteCount: Int,
    bookmarkCount: Int,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onRead: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleFinished: () -> Unit,
    onRate: (Int) -> Unit,
    onSaveJournal: (String) -> Unit,
    onToggleCollection: (BookCollection) -> Unit,
    onOpenNotes: () -> Unit,
    onRemove: () -> Unit,
) {
    val mine = remember(sessions, book.id) { sessions.filter { it.bookId == book.id } }
    val seconds = mine.sumOf { it.seconds.toLong() }
    var journal by remember(book.id, book.journal) { mutableStateOf(book.journal) }
    var confirmRemove by remember { mutableStateOf(false) }
    val added = remember(book.addedAt) {
        Instant.ofEpochMilli(book.addedAt).atZone(ZoneId.systemDefault()).toLocalDate()
            .format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
    }

    PbPage("Book", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            BookCover(book, Modifier.width(170.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(
            book.title,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontFamily = PbSerif,
            fontSize = 26.sp,
            fontWeight = FontWeight.Medium,
        )
        if (book.author.isNotBlank()) {
            Text(
                book.author,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            (1..5).forEach { i ->
                Text(
                    if (i <= book.rating) "\u2605" else "\u2606",
                    fontSize = 30.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.clickable { onRate(if (book.rating == i) 0 else i) }.padding(horizontal = 4.dp),
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        PbButton(
            when {
                book.isReading -> "Resume reading"
                book.finished -> "Read again"
                else -> "Start reading"
            },
            onClick = onRead,
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TogglePill("Favorite", book.favorite, onToggleFavorite)
            TogglePill("Finished", book.finished, onToggleFinished)
        }

        Spacer(Modifier.height(24.dp))
        Eyebrow("This book")
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Progress", "${book.percent}%", Modifier.weight(1f))
            StatTile("Time read", Stats.duration(seconds), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(
                "Page",
                if (book.totalPositions > 0) "${book.position} / ${book.totalPositions}" else "\u2014",
                Modifier.weight(1f),
            )
            StatTile("Sessions", "${mine.size}", Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))
        Eyebrow("Collections")
        Spacer(Modifier.height(10.dp))
        if (collections.isEmpty()) {
            Text(
                "No collections yet. Make one from the menu \u2192 Collections.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
            )
        } else {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                collections.forEach { c ->
                    TogglePill(c.name, membership[c.id]?.contains(book.id) == true) { onToggleCollection(c) }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Eyebrow("Notes")
        Spacer(Modifier.height(10.dp))
        PbButton("Notes & bookmarks \u00B7 ${noteCount + bookmarkCount}", onClick = onOpenNotes, ghost = true)

        Spacer(Modifier.height(24.dp))
        Eyebrow("Journal")
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = journal,
            onValueChange = { journal = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Your thoughts on this book") },
            minLines = 3,
            shape = RoundedCornerShape(20.dp),
        )
        if (journal != book.journal) {
            Spacer(Modifier.height(10.dp))
            PbButton("Save journal", onClick = { onSaveJournal(journal.trim()) })
        }

        Spacer(Modifier.height(24.dp))
        Eyebrow("About")
        Spacer(Modifier.height(10.dp))
        Text("Added $added", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        if (book.language.isNotBlank()) {
            Text("Language: ${book.language}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        }

        Spacer(Modifier.height(20.dp))
        TextButton(onClick = { confirmRemove = true }) {
            Text("Remove from library", color = MaterialTheme.colorScheme.error)
        }
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            title = { Text("Remove this book?") },
            text = { Text("The book file is deleted from Paperback. Your reading history stays in your stats.") },
            confirmButton = {
                TextButton(onClick = { confirmRemove = false; onRemove() }) {
                    Text("Remove", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel") } },
        )
    }
}
