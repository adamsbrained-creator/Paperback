package com.paperback.app.reminder

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.paperback.app.MainActivity
import com.paperback.app.PaperbackApp
import com.paperback.app.Graph
import com.paperback.app.data.ReminderMode
import com.paperback.app.data.Stats
import com.paperback.app.data.nextReminderAtMs
import com.paperback.app.data.peakHourOf
import com.paperback.app.data.reminderMessage
import com.paperback.app.data.reminderMinute
import java.time.LocalDate
import java.time.ZoneId

/**
 * The daily reading reminder. An alarm is set for the next time to remind; when it goes off the receiver looks at today's
 * reading, posts a notification only if you have not read yet, and sets the next alarm. The alarm is not exact (Android may
 * move it a few minutes to save battery), which needs no special permission.
 */
object Reminders {
    const val ACTION_FIRE = "com.paperback.app.READING_REMINDER"
    private const val CHANNEL = "reading_reminder"
    private const val REQUEST = 4107
    private const val NOTIFICATION_ID = 4107

    private fun alarmIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            REQUEST,
            Intent(context, ReminderReceiver::class.java).setAction(ACTION_FIRE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    /** True when Paperback may post notifications (Android 13 and later ask for it; before that it always may). */
    fun canNotify(context: Context): Boolean {
        val allowed = Build.VERSION.SDK_INT < 33 ||
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return allowed && nm.areNotificationsEnabled()
    }

    /** Sets (or clears) the next alarm from the saved choice. Reads the database, so call it off the main thread. */
    fun schedule(context: Context, graph: Graph) {
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val mode = graph.prefs.reminderMode.value
        if (mode == ReminderMode.Off) {
            alarms.cancel(alarmIntent(context))
            return
        }
        val zone = ZoneId.systemDefault()
        val peak = if (mode == ReminderMode.Peak) peakHourOf(graph.db.allSessions(), LocalDate.now(zone), zone) else null
        val minute = reminderMinute(mode, graph.prefs.reminderMinute.value, peak) ?: return
        val at = nextReminderAtMs(System.currentTimeMillis(), minute, zone)
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent(context))
    }

    /** The alarm went off: remind, unless you already read today or the phone does not allow notifications. */
    fun fire(context: Context, graph: Graph) {
        if (graph.prefs.reminderMode.value == ReminderMode.Off || !canNotify(context)) return
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val sessions = graph.db.allSessions()
        val byDay = Stats.secondsByDay(sessions, zone)
        val message = reminderMessage(
            todaySeconds = byDay[today] ?: 0L,
            goals = graph.prefs.goals.value,
            streak = Stats.currentStreak(byDay, today),
            bookTitle = graph.db.allBooks().filter { it.isReading && it.hasFile }.maxByOrNull { it.lastOpenedAt }?.title,
        ) ?: return

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Reading reminder", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "One reminder a day, only when you have not read yet"
                setShowBadge(false)
            },
        )
        val open = PendingIntent.getActivity(
            context,
            REQUEST,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(message.title)
            .setContentText(message.text)
            .setStyle(Notification.BigTextStyle().bigText(message.text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIFICATION_ID, notification)
    }

    /** Convenience for places that only have a context (the app class). */
    fun graphOf(context: Context): Graph = (context.applicationContext as PaperbackApp).graph
}
