package com.paperback.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.launch

/**
 * Gets the daily alarm, and the phone starting up, Paperback being updated or the time zone changing (alarms are lost
 * on a restart, so each of those sets the next one).
 */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val graph = Reminders.graphOf(app)
        val pending = goAsync()
        graph.appScope.launch {
            try {
                if (intent.action == Reminders.ACTION_FIRE) Reminders.fire(app, graph)
                Reminders.schedule(app, graph)
            } catch (e: Exception) {
                // a reminder that fails is just a reminder that does not show
            } finally {
                pending.finish()
            }
        }
    }
}
