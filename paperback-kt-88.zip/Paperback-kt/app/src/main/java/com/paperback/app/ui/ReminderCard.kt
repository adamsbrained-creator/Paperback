package com.paperback.app.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.ReminderMode
import com.paperback.app.data.clockText
import com.paperback.app.reminder.Reminders
import com.paperback.app.ui.theme.pbTokens
import kotlin.math.roundToInt

/**
 * "Reading reminder" on the Goals page: one notification a day, at the hour you usually read or at a time you pick, and only
 * when you have not read yet today. [peakHour] is that usual hour (null until there is enough reading to tell).
 */
@Composable
fun ReminderCard(mode: ReminderMode, minute: Int, peakHour: Int?, onChange: (ReminderMode, Int) -> Unit) {
    val t = pbTokens()
    val context = LocalContext.current
    // bumped when the permission answer comes back, so the "allowed" line is read again
    var answered by remember { mutableIntStateOf(0) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { answered++ }
    val allowed = remember(answered, mode) { Reminders.canNotify(context) }
    // the slider moves in quarter hours; the choice is saved when the finger lifts
    var dragging by remember(minute) { mutableIntStateOf(minute / 15) }

    fun pick(next: ReminderMode) {
        onChange(next, minute)
        if (next != ReminderMode.Off && Build.VERSION.SDK_INT >= 33 && !Reminders.canNotify(context)) {
            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(18.dp)) {
        Text("Reading reminder", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(
            when (mode) {
                ReminderMode.Off -> "A notification once a day, at your reading hour, only when you have not read yet."
                ReminderMode.Peak ->
                    if (peakHour != null) "At ${clockText(peakHour * 60)}, the hour you read most. Skipped if you already read today."
                    else "Not enough reading yet to know your hour. Until then: ${clockText(minute)}."
                ReminderMode.Fixed -> "At ${clockText(minute)} every day. Skipped if you already read today."
            },
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
            color = t.sub, fontSize = 13.sp, lineHeight = 18.sp,
        )
        PbSegmented(ReminderMode.values().map { it to it.label }, mode, { next -> pick(next) })

        // your own time (also the fall-back for "Usual hour" while it is unknown)
        if (mode == ReminderMode.Fixed || (mode == ReminderMode.Peak && peakHour == null)) {
            Spacer(Modifier.height(14.dp))
            Text(clockText(dragging * 15), color = t.ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            PbSlider(
                value = dragging.toFloat(),
                onValueChange = { dragging = it.roundToInt().coerceIn(0, 95) },
                trackColor = t.ink.copy(alpha = 0.08f),
                modifier = Modifier.padding(top = 8.dp),
                valueRange = 0f..95f,
                fillColor = MaterialTheme.colorScheme.primary,
                onValueChangeFinished = { onChange(mode, dragging * 15) },
            )
        }

        if (mode != ReminderMode.Off && !allowed) {
            Spacer(Modifier.height(14.dp))
            Text(
                "Notifications are off for Paperback, so nothing will show.",
                color = t.sub, fontSize = 13.sp, lineHeight = 18.sp,
            )
            Spacer(Modifier.height(8.dp))
            PbButton(
                "Allow notifications",
                {
                    // the first time the phone's own question is shown; once it was answered, only the phone's settings can change it
                    if (Build.VERSION.SDK_INT >= 33 && answered == 0 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        context.startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                },
                ghost = true,
            )
        }
    }
}
