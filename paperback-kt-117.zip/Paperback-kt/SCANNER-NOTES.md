# Book scanner (kt-117)

New: Library card "Find books on this phone", Settings > Library > Book scanner, and the seven scanner screens.
Code: app/src/main/java/com/paperback/app/scan/ (engine + Android layer) and ui/ScannerParts.kt, ui/ScannerScreens.kt.
Logic tests: app/src/test/java/com/paperback/app/scan/ScanTest.java (23 tests, passed when written).

Notes
- Whole-phone scan needs "All files access" (Android 11+) or storage permission (Android 6-9). Android 10 can only scan folders you pick.
- Automatic scans run through Android's job scheduler: new files trigger a scan, with a gap of about 15 minutes between runs.
- The Kotlin/Compose side was written without a compiler. If the GitHub build fails, send me the error lines.
