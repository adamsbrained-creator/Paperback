package com.paperback.app.scan

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import java.io.File
import java.nio.file.Files

/** Whether Paperback may look through the phone's storage, and the list of places to scan. */
object StorageAccess {
    /** True when the whole of the phone's storage can be read with ordinary files. */
    fun canReadWholePhone(context: Context): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
        Build.VERSION.SDK_INT == 29 -> false
        else -> context.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    /** Android 10 gives an app no way to ask for the whole phone: there, only folders you pick can be scanned. */
    fun canAskForWholePhone(): Boolean = Build.VERSION.SDK_INT != 29

    /** The phone's storage and any SD card, as folders. */
    private fun volumes(context: Context): List<Pair<File, Boolean>> {
        val out = ArrayList<Pair<File, Boolean>>()
        @Suppress("DEPRECATION")
        out.add(Environment.getExternalStorageDirectory() to true)
        runCatching {
            context.getExternalFilesDirs(null).drop(1).forEach { dir ->
                val root = dir?.path?.substringBefore("/Android/", "")?.takeIf { it.isNotEmpty() } ?: return@forEach
                val f = File(root)
                if (f.isDirectory && f.canRead()) out.add(f to false)
            }
        }
        return out
    }

    /**
     * One place per folder at the top of the storage, so each can be switched off by itself, plus one for the files lying
     * loose at the top. Android's own folders, hidden folders and the media folders are left out here.
     */
    fun wholePhoneRoots(context: Context): List<ScanWalker.Root> {
        val roots = ArrayList<ScanWalker.Root>()
        for ((dir, primary) in volumes(context)) {
            val prefix = if (primary) "" else "sd:"
            val label = if (primary) "" else "SD card · "
            roots.add(ScanWalker.Root(dir.path, prefix + "(top)", if (primary) "Phone" else "SD card", false, true))
            dir.listFiles()
                ?.filter { it.isDirectory && !Files.isSymbolicLink(it.toPath()) && !ScanWalker.skipDir(it.name, true) }
                ?.sortedBy { it.name.lowercase() }
                ?.forEach { roots.add(ScanWalker.Root(it.path, prefix + it.name, label + it.name, false)) }
        }
        return roots
    }

    /** The scan place for a folder picked on the file picker. */
    fun treeRoot(tree: ScanStore.Tree): ScanWalker.Root {
        val uri = Uri.parse(tree.uri)
        val doc = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
        return ScanWalker.Root(doc.toString(), "tree:" + tree.uri, tree.name, false)
    }

    /** A short name for a picked folder: "primary:Books/Fantasy" is "Fantasy". */
    fun treeName(uri: Uri): String {
        val id = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrDefault("")
        return id.substringAfterLast(':').substringAfterLast('/').ifBlank { "Folder" }
    }
}
