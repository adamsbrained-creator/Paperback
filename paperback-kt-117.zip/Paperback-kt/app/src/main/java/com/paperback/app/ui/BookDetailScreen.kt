package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import com.paperback.app.data.BookPageStyle
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.ReflowState
import com.paperback.app.data.Book
import com.paperback.app.data.BookCollection
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/**
 * One book: rating, read / finished, favorite, notes and edit as small icons, then a Progress card that opens the
 * Progress page (time read, timer, entries), and the book's details. Reached from Library, Home or any shelf.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookDetailScreen(
    book: Book,
    sessions: List<ReadingSession>,
    collections: List<BookCollection>,
    membership: Map<String, Set<String>>,
    noteCount: Int,
    bookmarkCount: Int,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onRead: () -> Unit,
    onFindDetails: () -> Unit = {},
    onToggleFavorite: () -> Unit,
    onToggleFinished: () -> Unit,
    ratingScale: Int,
    ratingSteps: Int,
    onRate: (Double) -> Unit,
    onToggleCollection: (BookCollection) -> Unit,
    onOpenNotes: () -> Unit,
    onRemove: () -> Unit,
    similar: List<Book>,
    onOpenBook: (Book) -> Unit,
    onOpenTag: (String) -> Unit,
    onOpenAuthor: (String) -> Unit,
    reflow: ReflowState?,
    onReflow: () -> Unit,
    onCancelReflow: () -> Unit,
    timerRunning: Boolean,
    onOpenProgress: () -> Unit,
    onEdit: () -> Unit,
    bookPageStyle: BookPageStyle = BookPageStyle.Classic,
) {
    val t = pbTokens()
    val seconds0 = remember(sessions, book.id) { sessions.filter { it.bookId == book.id }.sumOf { it.seconds.toLong() } }
    val seconds = seconds0
    var confirmRemove by remember { mutableStateOf(false) }
    var descOpen by remember(book.id) { mutableStateOf(false) }
    val floating = bookPageStyle == BookPageStyle.Floating
    val readLabel = when {
        !book.hasFile -> "Add the book file"
        book.isReading -> "Resume reading"
        book.finished -> "Read again"
        else -> "Start reading"
    }
    val added = remember(book.addedAt) {
        Instant.ofEpochMilli(book.addedAt).atZone(ZoneId.systemDefault()).toLocalDate()
            .format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
    }

    Box(Modifier.fillMaxSize()) {
    PbPage("Book", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        if (floating) {
            FloatingTop(
                book, ratingScale, ratingSteps, onRate, onToggleFinished, onEdit, onOpenAuthor, onFindDetails,
                descOpen, { descOpen = !descOpen },
            )
        } else {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            BookCover(book, Modifier.width(176.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text(
            book.title,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            color = t.ink,
            fontFamily = PbSerif,
            fontSize = 26.sp,
            lineHeight = 32.sp,
            fontWeight = FontWeight.Medium,
        )
        if (book.author.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                book.author,
                modifier = Modifier.fillMaxWidth().clickable { onOpenAuthor(book.author) },
                textAlign = TextAlign.Center,
                color = t.setSub,
                fontSize = 16.sp,
            )
        }

        Spacer(Modifier.height(6.dp))
        RatingBar(book.rating10, ratingScale, ratingSteps, onRate)

        Spacer(Modifier.height(10.dp))
        PbButton(
            when {
                !book.hasFile -> "Add the book file"
                book.isReading -> "Resume reading"
                book.finished -> "Read again"
                else -> "Start reading"
            },
            onClick = onRead,
            ghost = !book.hasFile,
        )
        if (!book.hasFile) {
            Spacer(Modifier.height(10.dp))
            NoteCard(
                "This book is in your library without a file, so it can be rated, finished and logged, but not read. Add its book file (EPUB, PDF, MOBI, AZW3, FB2…) and everything here moves over to it.",
                title = "No book file yet",
            )
            Spacer(Modifier.height(10.dp))
            PbButton(if (book.coverPath == null) "Find cover and details online" else "Refresh details online", onClick = onFindDetails, ghost = true)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            TogglePill("Finished", book.finished, Modifier.weight(1f), onToggleFinished)
            BookIconButton(PbIconName.Star, if (book.favorite) "Remove from favorites" else "Add to favorites", active = book.favorite, onClick = onToggleFavorite)
            BookIconButton(PbIconName.Note, "Notes, bookmarks and journal", badge = noteCount + bookmarkCount, onClick = onOpenNotes)
            BookIconButton(PbIconName.Edit, "Edit this book", onClick = onEdit)
        }
        }

        if (book.isPdf) {
            SectionLabel("Reflow")
            PbCard {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Text("Reflow as EPUB", color = t.ink, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    val running = reflow != null && reflow.bookId == book.id
                    if (running && reflow != null) {
                        Text(
                            when {
                                reflow.page >= reflow.total -> "Building the book\u2026"
                                reflow.ocr -> "Recognising text on page ${reflow.page + 1} of ${reflow.total}"
                                else -> "Reading page ${reflow.page + 1} of ${reflow.total}"
                            },
                            color = t.setSub,
                            fontSize = 14.sp,
                        )
                        if (reflow.ocr) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "This PDF is a scan, so every page is being read as a picture. It takes a few minutes. Keep Paperback open.",
                                color = t.setSub,
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        ProgressTrack(if (reflow.total > 0) reflow.page.toFloat() / reflow.total else 0f)
                        Spacer(Modifier.height(14.dp))
                        PbButton("Cancel", onClick = onCancelReflow, ghost = true)
                    } else {
                        Text(
                            "Makes a copy as a normal book, so text size, fonts, margins and themes all work. Your PDF stays as it is. A scanned PDF is read with text recognition, which takes a few minutes and can make small mistakes.",
                            color = t.setSub,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                        )
                        Spacer(Modifier.height(14.dp))
                        PbButton("Reflow as EPUB", onClick = onReflow, enabled = reflow == null)
                    }
                }
            }
        }

        if (book.tags.isNotEmpty()) {
            SectionLabel("Genres")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                book.tags.forEach { tag -> TagChip(tag) { onOpenTag(tag) } }
            }
        }

        if (!floating && book.description.isNotBlank()) {
            SectionLabel("About this book")
            val long = book.description.length > 260
            Text(
                book.description,
                color = t.ink,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                maxLines = if (descOpen || !long) Int.MAX_VALUE else 5,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            if (long) {
                Text(
                    if (descOpen) "Show less" else "Read more",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { descOpen = !descOpen }.padding(horizontal = 4.dp, vertical = 8.dp),
                )
            }
        }

        SectionLabel("Progress")
        PbCard {
            Column(Modifier.clickable(onClick = onOpenProgress).padding(horizontal = 18.dp, vertical = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${book.percent}%", fontFamily = PbSerif, fontSize = 28.sp, fontWeight = FontWeight.Medium, color = t.ink)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            buildList<String> {
                                if (book.pageCount > 0) add("Page ${book.currentPage} of ${book.pageCount}")
                                add(if (seconds > 0) "${Stats.duration(seconds)} read" else "No time logged yet")
                            }.joinToString("  \u00B7  "),
                            color = t.setSub,
                            fontSize = 14.sp,
                        )
                    }
                    PbIcon(PbIconName.CaretRight, size = 20.dp, tint = t.setSub)
                }
                Spacer(Modifier.height(12.dp))
                ProgressTrack(book.progress.coerceIn(0f, 1f))
                Spacer(Modifier.height(10.dp))
                Text(
                    if (timerRunning) "Timer running" else "Timer, entries and reading history",
                    color = if (timerRunning) MaterialTheme.colorScheme.primary else t.setSub,
                    fontSize = 13.sp,
                    fontWeight = if (timerRunning) FontWeight.Medium else FontWeight.Normal,
                )
            }
        }

        SectionLabel("Collections")
        if (collections.isEmpty()) {
            PbNote("No collections yet. Make one from the menu \u2192 Collections.")
        } else {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                collections.forEach { c ->
                    TogglePill(c.name, membership[c.id]?.contains(book.id) == true) { onToggleCollection(c) }
                }
            }
        }

        SectionLabel("About")
        PbCard {
            InfoRow("Added", added)
            if (book.language.isNotBlank()) {
                CardDivider(18.dp)
                InfoRow("Language", book.language.uppercase())
            }
            if (book.pageCount > 0) {
                CardDivider(18.dp)
                InfoRow("Length", "${book.pageCount} pages" + if (book.customPages > 0) " (yours)" else "")
            }
            if (book.publisher.isNotBlank()) {
                CardDivider(18.dp)
                InfoRow("Publisher", book.publisher)
            }
            if (book.published.isNotBlank()) {
                CardDivider(18.dp)
                InfoRow("Published", book.published)
            }
        }

        if (similar.isNotEmpty()) {
            SectionLabel("Similar in your library")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
                items(similar, key = { it.id }) { b ->
                    Column(Modifier.width(96.dp).clickable { onOpenBook(b) }) {
                        BookCover(b)
                        Spacer(Modifier.height(6.dp))
                        Text(b.title, color = t.ink, fontSize = 12.sp, lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        Spacer(Modifier.height(28.dp))
        PbButton("Remove from library", onClick = { confirmRemove = true }, ghost = true, destructive = true)
        if (floating) Spacer(Modifier.height(100.dp))
    }
    if (floating) {
        FloatingBookBar(
            book, readLabel, noteCount + bookmarkCount, onRead, onToggleFavorite, onOpenNotes,
            Modifier.align(Alignment.BottomCenter),
        )
    }
    }

    if (confirmRemove) {
        PbConfirmDialog(
            title = "Remove this book?",
            message = "The book file is deleted from Paperback. Your reading history stays in your stats.",
            confirm = "Remove",
            onConfirm = {
                confirmRemove = false
                onRemove()
            },
            onDismiss = { confirmRemove = false },
        )
    }
}


/** A round icon button on the book page: favorite, notes, edit. [badge] > 0 shows a small count. */
@Composable
private fun BookIconButton(icon: PbIconName, label: String, active: Boolean = false, badge: Int = 0, onClick: () -> Unit) {
    val t = pbTokens()
    val accent = MaterialTheme.colorScheme.primary
    Box(
        Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(if (active) accent.copy(alpha = 0.16f) else t.card)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        PbIcon(icon, size = 22.dp, tint = if (active) accent else t.ink, filled = active, contentDescription = label)
        if (badge > 0) {
            Text(
                if (badge > 99) "99+" else badge.toString(),
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 2.dp, end = 2.dp)
                    .clip(CircleShape)
                    .background(accent)
                    .padding(horizontal = 5.dp, vertical = 1.dp),
            )
        }
    }
}

/** The Floating bar page's top: a big cover with your progress beside it, then title, author, rating and description. */
@Composable
private fun FloatingTop(
    book: Book,
    ratingScale: Int,
    ratingSteps: Int,
    onRate: (Double) -> Unit,
    onToggleFinished: () -> Unit,
    onEdit: () -> Unit,
    onOpenAuthor: (String) -> Unit,
    onFindDetails: () -> Unit,
    descOpen: Boolean,
    onToggleDesc: () -> Unit,
) {
    val t = pbTokens()
    val accent = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        BookCover(book, Modifier.width(148.dp))
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f).padding(bottom = 6.dp)) {
            Text("${book.percent}%", color = t.ink, fontFamily = PbSerif, fontSize = 36.sp, fontWeight = FontWeight.Medium)
            if (book.pageCount > 0) {
                Text("Page ${book.currentPage} of ${book.pageCount}", color = t.setSub, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            ProgressTrack(book.progress.coerceIn(0f, 1f))
        }
    }
    Spacer(Modifier.height(24.dp))
    Text(
        book.title,
        color = t.ink,
        fontFamily = PbSerif,
        fontSize = 32.sp,
        lineHeight = 38.sp,
        fontWeight = FontWeight.Medium,
    )
    if (book.author.isNotBlank()) {
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.clip(RoundedCornerShape(16.dp)).clickable { onOpenAuthor(book.author) },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Text(book.author.trim().take(1).uppercase(), color = accent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.width(10.dp))
            Text(book.author, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            if (book.pageCount > 0) Text("  \u00B7  ${book.pageCount} pages", color = t.setSub, fontSize = 15.sp, maxLines = 1)
        }
    }
    Spacer(Modifier.height(12.dp))
    RatingBar(book.rating10, ratingScale, ratingSteps, onRate)
    if (!book.hasFile) {
        Spacer(Modifier.height(10.dp))
        NoteCard(
            "This book is in your library without a file, so it can be rated, finished and logged, but not read. Add its book file (EPUB, PDF, MOBI, AZW3, FB2…) and everything here moves over to it.",
            title = "No book file yet",
        )
        Spacer(Modifier.height(10.dp))
        PbButton(if (book.coverPath == null) "Find cover and details online" else "Refresh details online", onClick = onFindDetails, ghost = true)
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        TogglePill("Finished", book.finished, Modifier.weight(1f), onToggleFinished)
        BookIconButton(PbIconName.Edit, "Edit this book", onClick = onEdit)
    }
    if (book.description.isNotBlank()) {
        Spacer(Modifier.height(20.dp))
        val long = book.description.length > 260
        val collapsed = long && !descOpen
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(enabled = long, onClick = onToggleDesc)) {
            Text(
                book.description,
                color = t.sub,
                fontSize = 16.sp,
                lineHeight = 25.sp,
                maxLines = if (collapsed) 6 else Int.MAX_VALUE,
                overflow = TextOverflow.Clip,
            )
            if (collapsed) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(64.dp)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, t.bg))),
                )
            }
        }
        if (long) {
            Text(
                if (descOpen) "Show less" else "Read more",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onToggleDesc).padding(vertical = 8.dp),
            )
        }
    }
}

/** One bar floating at the bottom: favorite, notes, share, and the Read button. */
@Composable
private fun FloatingBookBar(
    book: Book,
    readLabel: String,
    noteTotal: Int,
    onRead: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenNotes: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val accent = MaterialTheme.colorScheme.primary
    val context = LocalContext.current
    val shape = RoundedCornerShape(32.dp)
    val share = {
        val text = listOf(book.title, book.author).filter { it.isNotBlank() }.joinToString(" \u2014 ")
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, null))
    }
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .fillMaxWidth()
            .height(64.dp)
            .shadow(14.dp, shape, ambientColor = Color.Black.copy(alpha = 0.3f), spotColor = Color.Black.copy(alpha = 0.3f))
            .clip(shape)
            .background(t.menuBg)
            .padding(start = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BarIcon(PbIconName.Star, if (book.favorite) "Remove from favorites" else "Add to favorites", active = book.favorite, onClick = onToggleFavorite)
        BarIcon(PbIconName.Note, "Notes, bookmarks and journal", badge = noteTotal, onClick = onOpenNotes)
        BarIcon(PbIconName.Share, "Share this book", onClick = share)
        Spacer(Modifier.weight(1f))
        Row(
            Modifier
                .height(48.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(t.ink)
                .clickable(onClick = onRead)
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (book.hasFile) {
                PbIcon(PbIconName.Play, size = 16.dp, tint = t.bg, filled = true)
                Spacer(Modifier.width(8.dp))
            }
            Text(readLabel, color = t.bg, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

@Composable
private fun BarIcon(icon: PbIconName, label: String, active: Boolean = false, badge: Int = 0, onClick: () -> Unit) {
    val t = pbTokens()
    val accent = MaterialTheme.colorScheme.primary
    Box(Modifier.size(48.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        PbIcon(icon, size = 22.dp, tint = if (active) accent else t.ink, filled = active, contentDescription = label)
        if (badge > 0) {
            Text(
                if (badge > 99) "99+" else badge.toString(),
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 2.dp, end = 2.dp)
                    .clip(CircleShape)
                    .background(accent)
                    .padding(horizontal = 5.dp, vertical = 1.dp),
            )
        }
    }
}
