package com.paperback.app

import android.app.Application
import com.paperback.app.data.AppIcon
import com.paperback.app.data.AppPrefs
import com.paperback.app.data.LogOnlyEnricher
import com.paperback.app.data.OpdsStore
import com.paperback.app.data.catalog.CatalogApi
import com.paperback.app.data.opds.OpdsHttp
import com.paperback.app.data.Book
import com.paperback.app.data.PaperbackDb
import com.paperback.app.data.Readium
import com.paperback.app.data.ReadingTimer
import com.paperback.app.data.SearchHistory
import com.paperback.app.data.Wishlist
import com.paperback.app.data.ReaderSettings
import com.paperback.app.data.Repository
import com.paperback.app.reader.PdfSession
import com.paperback.app.reader.ReaderSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.readium.r2.navigator.epub.EpubNavigatorFactory
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication
import org.readium.r2.shared.publication.services.positions
import java.io.File

class PaperbackApp : Application() {
    lateinit var graph: Graph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = Graph(this)
        // after a reinstall or a restored backup the launcher can disagree with the saved choice: make them match
        AppIcon.apply(this, graph.prefs.iconStyle.value)
        // keeps the reading reminder's alarm current (your usual hour can move as you read)
        graph.appScope.launch { runCatching { com.paperback.app.reminder.Reminders.schedule(this@PaperbackApp, graph) } }
        // the book scanner's automatic scan (new files appear / once a day) is set up again on every start
        runCatching { com.paperback.app.scan.ScanJobs.schedule(this, graph.scanStore) }
    }
}

/** The app's long-lived objects, created once. */
class Graph(app: Application) {
    /** For work that must finish even if the screen that started it is gone (saving a reading session). */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val db = PaperbackDb(app)
    val readium = Readium(app)
    val repo = Repository(app, db, readium)
    val settings = ReaderSettings(app)
    val prefs = AppPrefs(app)
    val searchHistory = SearchHistory(app)
    val opdsHttp = OpdsHttp()
    val opdsStore = OpdsStore(app)
    val catalogApi = CatalogApi(opdsHttp, app.cacheDir)
    /** Fills covers and details of books kept without a file from the online catalog. */
    val enricher = LogOnlyEnricher(app, catalogApi, opdsHttp, repo, prefs)
    val wishlist = Wishlist(app)
    val timer = ReadingTimer(app)
    val scanStore = com.paperback.app.scan.ScanStore(app)
    /** The book scanner: finds book files on the phone and adds them. It lives here so a scan goes on after you leave its screen. */
    val scanner = com.paperback.app.scan.ScanController(app, repo, scanStore, appScope)

    /** The book being read right now. Set by [openReader], used by ReaderActivity. */
    @Volatile
    var readerSession: ReaderSession? = null

    /** The PDF being read right now (PDFs have their own viewer). Null while an EPUB is open. */
    @Volatile
    var pdfSession: PdfSession? = null

    /** [startAtJson]: open at this saved place (a note or bookmark) instead of where you stopped. */
    suspend fun openReader(book: Book, startAtJson: String? = null): Boolean = withContext(Dispatchers.IO) {
        val file = File(book.filePath)
        if (!file.exists()) return@withContext false

        if (book.isPdf) {
            // Readium isn't involved: just remember which page to start on. The viewer opens the file itself.
            val saved = (startAtJson ?: book.locatorJson)?.let { json ->
                runCatching { JSONObject(json).getJSONObject("locations").getInt("position") }.getOrNull()
            }
            // pages logged in an entry may be ahead of the last page the viewer saved
            val page = (if (startAtJson == null) maxOf(saved ?: 0, book.position) else (saved ?: book.position)).coerceAtLeast(1)
            readerSession?.publication?.close()
            readerSession = null
            pdfSession = PdfSession(book, page)
            repo.markOpened(book.id)
            return@withContext true
        }
        pdfSession = null

        val publication = readium.open(file) ?: return@withContext false
        if (!publication.conformsTo(Publication.Profile.EPUB)) {
            publication.close()
            return@withContext false
        }

        val total = if (book.totalPositions > 0) book.totalPositions else publication.positions().size
        val saved: Locator? = (startAtJson ?: book.locatorJson)?.let { json ->
            runCatching { Locator.fromJSON(JSONObject(json)) }.getOrNull()
        }
        // Pages logged in an entry or the timer move the book ahead of the last place the reader saved: resume there.
        val initial: Locator? = if (startAtJson == null && book.position > (saved?.locations?.position ?: 0)) {
            runCatching { publication.positions().getOrNull(book.position - 1) }.getOrNull() ?: saved
        } else {
            saved
        }

        readerSession?.publication?.close()
        readerSession = ReaderSession(
            book = book,
            publication = publication,
            navigatorFactory = EpubNavigatorFactory(publication = publication),
            initialLocator = initial,
            totalPositions = total,
        )
        repo.markOpened(book.id)
        true
    }

    fun closePdf() {
        pdfSession = null
    }

    fun closeReader() {
        readerSession?.publication?.close()
        readerSession = null
    }
}
