package com.paperback.app.scan

import android.content.Context
import android.net.Uri
import com.paperback.app.data.ImportOutcome
import com.paperback.app.data.Repository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** The seven screens of the book scanner. */
enum class ScanScreen { Before, Scanning, Results, Review, Done, Settings }

/** What the Scanning screen shows. */
class ScanProgress(
    val percent: Int = 0,
    val books: Int = 0,
    val files: Long = 0L,
    val folder: String = "",
    val byKind: List<Pair<String, Int>> = emptyList(),
    val recent: List<Found> = emptyList(),
    val paused: Boolean = false,
)

/** What a finished scan found. A new object after every change, so the screens redraw. */
class ScanResults(
    val dedup: Dedup.Result,
    /** Files the person switched off in the list: [Found.fileKey]. */
    val unchecked: Set<String>,
    /** Every book file found, new or not. */
    val total: Int,
) {
    /** Books offered: the ones that are new. */
    val offered: List<Found> = dedup.toAdd()
    val selected: List<Found> = offered.filter { it.fileKey() !in unchecked }
    val duplicates: Int = dedup.duplicateCount()
    val problems: Int = dedup.problems.size
    val offeredBytes: Long = offered.sumOf { it.size }
}

/** What the Done screen shows. */
class ScanSummary(
    val added: Int,
    val converted: Int,
    val alreadyHad: Int,
    val failed: List<String>,
    val shelves: List<Pair<String, Int>>,
    /** Ids of the books that got no shelf. */
    val unsorted: List<String>,
)

/** The notification text and progress (0..100, or -1 for none) while a scan or an add runs. */
class ScanNotice(val text: String = "", val percent: Int = -1)

enum class ScanNeed { None, AllFiles, Folder }

/**
 * Runs the scan and the adding, and keeps what the screens show. It lives as long as the app, so a scan goes on when you
 * leave the screen, and a finished scan waits for you to look at it.
 */
class ScanController(
    private val context: Context,
    private val repo: Repository,
    val store: ScanStore,
    private val scope: CoroutineScope,
) {
    private val _screen = MutableStateFlow(ScanScreen.Before)
    val screen: StateFlow<ScanScreen> = _screen.asStateFlow()
    private val _progress = MutableStateFlow(ScanProgress())
    val progress: StateFlow<ScanProgress> = _progress.asStateFlow()
    private val _results = MutableStateFlow<ScanResults?>(null)
    val results: StateFlow<ScanResults?> = _results.asStateFlow()
    /** Books added so far and how many there are to add, while adding. */
    private val _adding = MutableStateFlow<Pair<Int, Int>?>(null)
    val adding: StateFlow<Pair<Int, Int>?> = _adding.asStateFlow()
    private val _summary = MutableStateFlow<ScanSummary?>(null)
    val summary: StateFlow<ScanSummary?> = _summary.asStateFlow()
    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()
    /** True while a scan or an add runs: the background service keeps the app alive for as long as this is true. */
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _notice = MutableStateFlow(ScanNotice())
    val notice: StateFlow<ScanNotice> = _notice.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    /** A short line for the screen to show once ("Pick a folder first"). */
    val message: StateFlow<String?> = _message.asStateFlow()
    fun messageShown() {
        _message.value = null
    }

    private val running = AtomicBoolean(false)
    @Volatile private var cancelled = false
    @Volatile private var paused = false
    @Volatile private var pendingStart = false
    private var lastEmit = 0L

    // ---- moving between screens -----------------------------------------------------------

    /**
     * The Library's "Scan now": the first-time page the first time, afterwards straight to scanning. Returns what the screen
     * must ask the person for first (see [begin]).
     */
    fun scanNow(): ScanNeed {
        when {
            _scanning.value -> _screen.value = ScanScreen.Scanning
            _adding.value != null -> _screen.value = ScanScreen.Results
            !store.introSeen -> _screen.value = ScanScreen.Before
            else -> {
                _screen.value = ScanScreen.Before
                return begin()
            }
        }
        return ScanNeed.None
    }

    /** Opens the screen for a found-books notification or the Library card's "Review". */
    fun openResults() {
        _screen.value = when {
            _scanning.value -> ScanScreen.Scanning
            _results.value != null || _adding.value != null -> ScanScreen.Results
            _summary.value != null -> ScanScreen.Done
            else -> ScanScreen.Before
        }
    }

    fun openBefore() {
        _screen.value = if (_scanning.value) ScanScreen.Scanning else ScanScreen.Before
    }

    fun openSettings() {
        _screen.value = ScanScreen.Settings
    }

    fun openReview() {
        _screen.value = ScanScreen.Review
    }

    fun closeReview() {
        _screen.value = ScanScreen.Results
    }

    /** The system back button: true when the scanner used it to go back a step itself. */
    fun back(): Boolean {
        if (_screen.value == ScanScreen.Review) {
            _screen.value = ScanScreen.Results
            return true
        }
        return false
    }

    /** What the Library card says: how many books wait, or how far a scan has got. Null for the plain card. */
    fun hasWaiting(): Boolean = _results.value?.offered?.isNotEmpty() == true

    // ---- starting -------------------------------------------------------------------------

    /**
     * The "Start scan" button. Returns what the screen must ask for first (all-files access, or a folder to look in); once
     * that is given, [resumed] or [addTree] carries on.
     */
    fun begin(): ScanNeed {
        store.introSeen = true
        if (store.wholePhone.value && !StorageAccess.canAskForWholePhone()) store.setWholePhone(false)
        val need = if (store.wholePhone.value) {
            if (StorageAccess.canReadWholePhone(context)) ScanNeed.None else ScanNeed.AllFiles
        } else {
            if (store.trees.value.isEmpty()) ScanNeed.Folder else ScanNeed.None
        }
        if (need == ScanNeed.None) {
            pendingStart = false
            start()
        } else {
            pendingStart = true
        }
        return need
    }

    /** Called when the app comes back to the front: carries on a scan that was waiting for a permission. */
    fun resumed() {
        if (!pendingStart) return
        if (store.wholePhone.value && StorageAccess.canReadWholePhone(context)) {
            pendingStart = false
            start()
        }
    }

    /** The permission was refused: forget the waiting scan. */
    fun permissionRefused() {
        pendingStart = false
        _message.value = "Paperback needs access to your files to scan. You can also choose folders instead."
    }

    /** The folder picker was closed without a choice: forget the waiting scan. */
    fun folderRefused() {
        pendingStart = false
    }

    fun addTree(uri: Uri) {
        store.addTree(ScanStore.Tree(uri.toString(), StorageAccess.treeName(uri)))
        if (pendingStart && !store.wholePhone.value) {
            pendingStart = false
            start()
        }
    }

    fun start() {
        if (!running.compareAndSet(false, true)) return
        cancelled = false
        paused = false
        _progress.value = ScanProgress()
        _summary.value = null
        _scanning.value = true
        _busy.value = true
        _screen.value = ScanScreen.Scanning
        _notice.value = ScanNotice("Looking for books…", 0)
        ScanService.start(context)
        scope.launch(Dispatchers.IO) {
            try {
                scanBlocking(auto = false)
            } finally {
                running.set(false)
                _scanning.value = false
                _busy.value = _adding.value != null
            }
        }
    }

    /** A scan started by the phone (new files appeared, or the daily one): quiet, and it tells you only if there is something new. */
    suspend fun runAuto() = withContext(Dispatchers.IO) {
        if (!store.auto.value) return@withContext
        if (System.currentTimeMillis() - store.lastAutoAt < 15 * 60_000L) return@withContext
        if (store.wholePhone.value && !StorageAccess.canReadWholePhone(context)) return@withContext
        if (!running.compareAndSet(false, true)) return@withContext
        store.lastAutoAt = System.currentTimeMillis()
        cancelled = false
        paused = false
        _scanning.value = false
        try {
            scanBlocking(auto = true)
        } finally {
            running.set(false)
        }
    }

    fun pause() {
        paused = true
        _progress.value = copyProgress(paused = true)
    }

    fun resume() {
        paused = false
        _progress.value = copyProgress(paused = false)
    }

    /** "Stop and review": ends the walk here and shows what was found so far. */
    fun stopAndReview() {
        cancelled = true
        paused = false
    }

    private fun copyProgress(paused: Boolean): ScanProgress = _progress.value.let {
        ScanProgress(it.percent, it.books, it.files, it.folder, it.byKind, it.recent, paused)
    }

    // ---- the scan itself ------------------------------------------------------------------

    private fun scanBlocking(auto: Boolean) {
        val options = ScanOptions(store.kinds.value, store.minKb.value * 1024L, store.excludedKeys())
        val roots = ArrayList<ScanWalker.Root>()
        if (store.wholePhone.value) roots.addAll(StorageAccess.wholePhoneRoots(context))
        store.trees.value.forEach { roots.add(StorageAccess.treeRoot(it)) }
        if (roots.isEmpty()) {
            _message.value = "There is nothing to scan yet. Choose a folder first."
            _screen.value = ScanScreen.Before
            return
        }
        val fs = RoutingFs(FileFs(), SafFs(context.contentResolver))
        val found = ArrayList<Found>()
        val kindCounts = LinkedHashMap<ScanKind, Int>()
        val recent = ArrayList<Found>()
        var checked = 0L
        var percent = 0
        var folder = ""

        fun emit(force: Boolean) {
            val now = System.currentTimeMillis()
            if (!force && now - lastEmit < 120) return
            lastEmit = now
            if (auto) return
            val bars = kindCounts.filterKeys { it != ScanKind.BLOCKED }.entries.sortedByDescending { it.value }.take(6).map { it.key.label() to it.value }
            _progress.value = ScanProgress(percent, found.size, checked, folder, bars, recent.toList(), paused)
            _notice.value = ScanNotice("${found.size} books found · $percent%", percent)
        }

        val walker = ScanWalker(fs, options, object : ScanWalker.Listener {
            override fun onBook(book: Found) {
                InfoReader.read(fs, book)
                found.add(book)
                kindCounts[book.kind] = (kindCounts[book.kind] ?: 0) + 1
                recent.add(0, book)
                while (recent.size > 3) recent.removeAt(recent.size - 1)
                emit(false)
            }

            override fun onFolder(path: String, progress: Double, filesChecked: Long) {
                folder = path
                percent = (progress * 100).toInt().coerceIn(0, 100)
                checked = filesChecked
                emit(false)
            }

            override fun stop(): Boolean {
                while (paused && !cancelled) {
                    try {
                        Thread.sleep(120)
                    } catch (e: InterruptedException) {
                        return true
                    }
                }
                return cancelled
            }
        })
        walker.walk(roots)
        checked = walker.filesChecked()
        percent = 100
        emit(true)
        finish(found, roots, auto)
    }

    private fun finish(found: List<Found>, roots: List<ScanWalker.Root>, auto: Boolean) {
        // where the books were, for "Folders to look in"
        val counts = LinkedHashMap<String, Pair<String, Int>>()
        for (f in found) {
            val name = roots.firstOrNull { it.key == f.rootKey }?.name ?: f.rootKey
            val prev = counts[f.rootKey]
            counts[f.rootKey] = name to ((prev?.second ?: 0) + 1)
        }
        val visible = found.filter { !store.isResolved(it.fileKey()) }
        val owned = repo.books.value.map { Dedup.Owned(it.title, it.author) }
        val dedup = Dedup.run(visible, owned)
        store.updateFolders(counts)
        val offered = dedup.toAdd()
        store.finished(offered.size)
        if (auto) {
            val fresh = offered.filter { !store.wasNotified(it.fileKey()) }
            store.markNotified(offered.map { it.fileKey() })
            if (fresh.isEmpty()) return
            if (store.ask.value) {
                _results.value = ScanResults(dedup, emptySet(), visible.size)
                ScanNotify.found(context, fresh.size)
            } else {
                _busy.value = true
                val done = addBlocking(offered, dedup, showProgress = false)
                _busy.value = false
                ScanNotify.added(context, done.added)
            }
            return
        }
        _results.value = ScanResults(dedup, emptySet(), visible.size)
        _screen.value = ScanScreen.Results
        if (offered.isNotEmpty()) store.markNotified(offered.map { it.fileKey() })
    }

    // ---- the results list -----------------------------------------------------------------

    private fun update(change: (ScanResults) -> ScanResults) {
        _results.value = _results.value?.let(change)
    }

    fun toggle(fileKey: String) = update { r ->
        ScanResults(r.dedup, if (fileKey in r.unchecked) r.unchecked - fileKey else r.unchecked + fileKey, r.total)
    }

    /** Switches a whole group on, or off when all of it is on already. */
    fun toggleGroup(books: List<Found>) = update { r ->
        val keys = books.map { it.fileKey() }
        val allOn = keys.none { it in r.unchecked }
        ScanResults(r.dedup, if (allOn) r.unchecked + keys else r.unchecked - keys.toSet(), r.total)
    }

    fun selectAll(on: Boolean) = update { r ->
        ScanResults(r.dedup, if (on) emptySet() else r.offered.map { it.fileKey() }.toSet(), r.total)
    }

    /** Chooses which copy of a book is kept (-1 is the one already in the library). */
    fun keepCopy(group: Dedup.Copies, index: Int) {
        group.keep = index
        update { r -> ScanResults(r.dedup, r.unchecked, r.total) }
    }

    fun keepBestOfEach() {
        _results.value?.dedup?.copies?.forEach { it.keepBest() }
        update { r -> ScanResults(r.dedup, r.unchecked, r.total) }
        _screen.value = ScanScreen.Results
    }

    /** Drops the waiting results (the Library card's dismiss). */
    fun discardResults() {
        _results.value = null
    }

    // ---- adding ---------------------------------------------------------------------------

    fun addSelected() {
        val r = _results.value ?: return
        if (_adding.value != null || r.selected.isEmpty()) return
        val list = r.selected
        _busy.value = true
        _adding.value = 0 to list.size
        _notice.value = ScanNotice("Adding ${list.size} books…", 0)
        ScanService.start(context)
        scope.launch(Dispatchers.IO) {
            try {
                val summary = addBlocking(list, r.dedup, showProgress = true)
                _summary.value = summary
                _results.value = null
                _screen.value = ScanScreen.Done
            } finally {
                _adding.value = null
                _busy.value = _scanning.value
            }
        }
    }

    private fun addBlocking(list: List<Found>, dedup: Dedup.Result, showProgress: Boolean): ScanSummary {
        var converted = 0
        var alreadyHad = 0
        val failed = ArrayList<String>()
        val added = ArrayList<Pair<Found, String>>()
        val resolved = ArrayList<String>()
        for ((i, f) in list.withIndex()) {
            val outcome = runCatching { kotlinx.coroutines.runBlocking { importOne(f) } }.getOrElse { ImportOutcome.Failed(f.name, null) }
            when (outcome) {
                is ImportOutcome.Added -> {
                    added.add(f to outcome.id)
                    if (f.kind.needsConversion()) converted++
                }
                is ImportOutcome.Duplicate -> {
                    alreadyHad++
                    resolved.add(f.fileKey())
                }
                is ImportOutcome.Unsupported -> failed.add(f.name)
                is ImportOutcome.Failed -> failed.add(f.name)
            }
            if (showProgress) {
                _adding.value = (i + 1) to list.size
                _notice.value = ScanNotice("Adding books · ${i + 1} of ${list.size}", ((i + 1) * 100) / list.size)
            }
        }
        // the copies that were left aside are dealt with: they are not offered again
        for (c in dedup.copies) {
            c.copies.forEachIndexed { idx, f -> if (idx != c.keep) resolved.add(f.fileKey()) }
        }
        store.markResolved(resolved)

        // series from the file, for books whose import didn't find one
        val byId = repo.books.value.associateBy { it.id }
        for ((f, id) in added) {
            if (f.series.isNotEmpty() && byId[id]?.series.isNullOrEmpty()) {
                runCatching { kotlinx.coroutines.runBlocking { repo.setBookFacts(id, series = f.series, seriesNo = if (f.seriesNo > 0f) f.seriesNo else null) } }
            }
        }

        val shelfCounts = LinkedHashMap<String, Int>()
        val unsorted = ArrayList<String>()
        if (store.shelves.value) {
            val seriesCounts = ShelfPlanner.countSeries(added.map { it.first })
            val books = repo.books.value.associateBy { it.id }
            for ((f, id) in added) {
                val book = books[id]
                val genres = (book?.tags ?: emptyList()) + f.subjects
                val series = book?.series?.ifEmpty { null } ?: f.series
                val shelf = ShelfPlanner.shelfFor(ShelfPlanner.Input(f.kind, genres, series, f.folder), seriesCounts)
                if (shelf == null) {
                    unsorted.add(id)
                } else {
                    runCatching { kotlinx.coroutines.runBlocking { putOnShelf(shelf, id) } }
                    shelfCounts[shelf] = (shelfCounts[shelf] ?: 0) + 1
                }
            }
        } else {
            unsorted.addAll(added.map { it.second })
        }
        return ScanSummary(
            added = added.size,
            converted = converted,
            alreadyHad = alreadyHad,
            failed = failed,
            shelves = shelfCounts.entries.sortedByDescending { it.value }.map { it.key to it.value },
            unsorted = unsorted,
        )
    }

    private suspend fun importOne(f: Found): ImportOutcome {
        if (f.ref.startsWith("content:")) return repo.importBook(Uri.parse(f.ref))
        // the file is copied first: importing takes the file it is given, and your own files stay where they are
        val tmp = File(context.cacheDir, "scan-${System.nanoTime()}-${f.name}")
        try {
            File(f.ref).inputStream().use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
        } catch (e: Exception) {
            tmp.delete()
            return ImportOutcome.Failed(f.name, "Couldn't read the file")
        }
        return repo.importFile(tmp, f.name)
    }

    private suspend fun putOnShelf(name: String, bookId: String) {
        var shelf = repo.collections.value.firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (shelf == null) {
            repo.createCollection(name)
            shelf = repo.collections.value.firstOrNull { it.name.equals(name, ignoreCase = true) }
        }
        if (shelf != null) repo.setMember(shelf.id, bookId, true)
    }

    /** "Sort them": puts the books that got no shelf on [shelfName] (a new shelf, or one you already have). */
    fun sortRemaining(shelfName: String) {
        val s = _summary.value ?: return
        val name = shelfName.trim()
        if (name.isEmpty() || s.unsorted.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            s.unsorted.forEach { runCatching { putOnShelf(name, it) } }
            val shelves = LinkedHashMap<String, Int>()
            s.shelves.forEach { shelves[it.first] = it.second }
            val key = shelves.keys.firstOrNull { it.equals(name, true) } ?: name
            shelves[key] = (shelves[key] ?: 0) + s.unsorted.size
            _summary.value = ScanSummary(s.added, s.converted, s.alreadyHad, s.failed, shelves.entries.sortedByDescending { it.value }.map { it.key to it.value }, emptyList())
        }
    }

    // ---- words for the screens ------------------------------------------------------------

    /** "Last scan today, 21:40 · 3 new books", or null before the first scan. */
    fun lastScanText(): String? {
        val at = store.lastAt
        if (at == 0L) return null
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = at }
        val now = java.util.Calendar.getInstance()
        val time = String.format(Locale.getDefault(), "%02d:%02d", cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE))
        val day = when {
            cal.get(java.util.Calendar.YEAR) == now.get(java.util.Calendar.YEAR) && cal.get(java.util.Calendar.DAY_OF_YEAR) == now.get(java.util.Calendar.DAY_OF_YEAR) -> "today"
            else -> java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(cal.time)
        }
        val n = store.lastNew
        return "Last scan $day, $time · " + (if (n == 0) "nothing new" else if (n == 1) "1 new book" else "$n new books")
    }
}
