package com.paperback.app.scan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Sorts what a scan found into books to add, copies of the same book, and files that can't be opened. A book you
 * already have counts as a copy too, so a second scan never offers it again.
 */
public final class Dedup {
    private Dedup() {}

    /** A book already in the library, for matching. */
    public static final class Owned {
        public final String title;
        public final String author;

        public Owned(String title, String author) {
            this.title = title;
            this.author = author;
        }
    }

    /** The same book found more than once (or found and already owned): one of [copies] is kept. */
    public static final class Copies {
        public final String title;
        /** Best copy first. */
        public final List<Found> copies;
        /** True when the library already has the book: by default nothing is added. */
        public final boolean owned;
        /** Which copy is kept: an index into [copies], or -1 for "the one in the library". */
        public int keep;

        Copies(String title, List<Found> copies, boolean owned) {
            this.title = title;
            this.copies = copies;
            this.owned = owned;
            this.keep = owned ? -1 : 0;
        }

        /** Back to the best choice. */
        public void keepBest() {
            keep = owned ? -1 : 0;
        }

        /** How many files are left aside by the current choice. */
        public int leftAside() {
            return copies.size() - (keep >= 0 ? 1 : 0);
        }
    }

    public static final class Result {
        /** Books that exist once and are not in the library: all of them are offered. */
        public final List<Found> single = new ArrayList<Found>();
        public final List<Copies> copies = new ArrayList<Copies>();
        public final List<Found> problems = new ArrayList<Found>();

        /** Everything to offer for adding right now: the single books and the kept copy of each group. */
        public List<Found> toAdd() {
            List<Found> out = new ArrayList<Found>(single);
            for (Copies c : copies) if (c.keep >= 0) out.add(c.copies.get(c.keep));
            return out;
        }

        /** Files left aside because another copy is kept. */
        public int duplicateCount() {
            int n = 0;
            for (Copies c : copies) n += c.leftAside();
            return n;
        }
    }

    private static final Comparator<Found> BEST_FIRST = new Comparator<Found>() {
        @Override
        public int compare(Found a, Found b) {
            if (a.rank() != b.rank()) return b.rank() - a.rank();
            if (a.size != b.size) return a.size < b.size ? 1 : -1;
            return a.name.compareToIgnoreCase(b.name);
        }
    };

    public static Result run(List<Found> found, List<Owned> library) {
        Result r = new Result();
        // buckets by title key, then split by author, so the work stays small even for thousands of books
        Map<String, List<Found>> byTitle = new LinkedHashMap<String, List<Found>>();
        for (Found f : found) {
            if (f.problem != null) {
                r.problems.add(f);
                continue;
            }
            String key = ScanKey.title(f.shownTitle());
            if (key.length() < 2) key = "\u0000" + f.fileKey(); // nothing to compare: it stands alone
            List<Found> bucket = byTitle.get(key);
            if (bucket == null) {
                bucket = new ArrayList<Found>();
                byTitle.put(key, bucket);
            }
            bucket.add(f);
        }
        Map<String, List<Owned>> ownedByTitle = new HashMap<String, List<Owned>>();
        for (Owned o : library) {
            String key = ScanKey.title(o.title);
            if (key.length() < 2) continue;
            List<Owned> l = ownedByTitle.get(key);
            if (l == null) {
                l = new ArrayList<Owned>();
                ownedByTitle.put(key, l);
            }
            l.add(o);
        }
        for (Map.Entry<String, List<Found>> e : byTitle.entrySet()) {
            // within a bucket the same title can still be different authors: cluster by author compatibility
            List<List<Found>> clusters = new ArrayList<List<Found>>();
            for (Found f : e.getValue()) {
                List<Found> home = null;
                for (List<Found> c : clusters) {
                    if (compatible(c, f)) {
                        home = c;
                        break;
                    }
                }
                if (home == null) {
                    home = new ArrayList<Found>();
                    clusters.add(home);
                }
                home.add(f);
            }
            for (List<Found> c : clusters) {
                Found first = c.get(0);
                boolean owned = false;
                List<Owned> mine = ownedByTitle.get(e.getKey());
                if (mine != null) {
                    String author = authorOf(c);
                    for (Owned o : mine) {
                        if (ScanKey.sameBook(first.shownTitle(), author, o.title, o.author)) {
                            owned = true;
                            break;
                        }
                    }
                }
                if (c.size() == 1 && !owned) {
                    r.single.add(first);
                } else {
                    Collections.sort(c, BEST_FIRST);
                    r.copies.add(new Copies(c.get(0).shownTitle(), c, owned));
                }
            }
        }
        Collections.sort(r.copies, new Comparator<Copies>() {
            @Override
            public int compare(Copies a, Copies b) {
                return a.title.compareToIgnoreCase(b.title);
            }
        });
        return r;
    }

    private static String authorOf(List<Found> cluster) {
        for (Found f : cluster) if (!f.author.isEmpty()) return f.author;
        return "";
    }

    private static boolean compatible(List<Found> cluster, Found f) {
        for (Found g : cluster) {
            if (ScanKey.sameBook(g.shownTitle(), g.author, f.shownTitle(), f.author)) return true;
        }
        return false;
    }
}
