package com.paperback.app.scan

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.io.IOException
import java.io.InputStream

/** Reads a folder picked on Android's file picker. Every reference is a document address ("content://..."). */
class SafFs(private val resolver: ContentResolver) : ScanFs {
    override fun list(dirRef: String): List<ScanEntry> {
        val out = ArrayList<ScanEntry>()
        try {
            val doc = Uri.parse(dirRef)
            val tree = DocumentsContract.buildTreeDocumentUri(doc.authority, DocumentsContract.getTreeDocumentId(doc))
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(doc))
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            )
            resolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    val dir = c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR
                    // a size the provider doesn't know is taken as "big enough", so the file is still looked at
                    val size = if (c.isNull(3)) 1_000_000L else c.getLong(3)
                    out.add(ScanEntry(name, dir, if (dir) 0L else size, if (c.isNull(4)) 0L else c.getLong(4), DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)).toString()))
                }
            }
        } catch (e: Exception) {
            // permission lost, folder gone: nothing to list
        }
        return out
    }

    @Throws(IOException::class)
    override fun open(fileRef: String): InputStream =
        resolver.openInputStream(Uri.parse(fileRef)) ?: throw IOException("Can't open $fileRef")

    override fun file(fileRef: String): File? = null
}

/** Sends each reference to the right reader: document addresses to [SafFs], everything else to plain files. */
class RoutingFs(private val files: ScanFs, private val picked: ScanFs) : ScanFs {
    private fun pick(ref: String) = if (ref.startsWith("content:")) picked else files
    override fun list(dirRef: String) = pick(dirRef).list(dirRef)
    override fun open(fileRef: String) = pick(fileRef).open(fileRef)
    override fun file(fileRef: String): File? = pick(fileRef).file(fileRef)
}
