package com.paperback.app.scan;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/** Where the scanner reads from: ordinary files ([FileFs]) or a folder the person picked on Android's file picker. */
public interface ScanFs {
    /** What is directly inside the folder [dirRef]. Returns an empty list when it can't be read. */
    List<ScanEntry> list(String dirRef);

    /** The bytes of the file [fileRef]. */
    InputStream open(String fileRef) throws IOException;

    /** A real file on disk for [fileRef], or null when this source can only give a stream. */
    File file(String fileRef);
}
