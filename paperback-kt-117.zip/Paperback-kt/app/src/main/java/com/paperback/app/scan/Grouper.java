package com.paperback.app.scan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Puts books under headings for the results list: by author, folder, series or format. */
public final class Grouper {
    private Grouper() {}

    public enum By {
        AUTHOR("By author"), FOLDER("By folder"), SERIES("By series"), FORMAT("By format");

        public final String label;

        By(String label) {
            this.label = label;
        }
    }

    public static final class Group {
        public final String name;
        public final List<Found> books = new ArrayList<Found>();

        Group(String name) {
            this.name = name;
        }
    }

    public static List<Group> group(List<Found> books, By by) {
        Map<String, Group> map = new LinkedHashMap<String, Group>();
        for (Found f : books) {
            String name = nameFor(f, by);
            Group g = map.get(name);
            if (g == null) {
                g = new Group(name);
                map.put(name, g);
            }
            g.books.add(f);
        }
        List<Group> out = new ArrayList<Group>(map.values());
        final String unknown = unknownName(by);
        Collections.sort(out, new Comparator<Group>() {
            @Override
            public int compare(Group a, Group b) {
                boolean ua = a.name.equals(unknown), ub = b.name.equals(unknown);
                if (ua != ub) return ua ? 1 : -1;
                return a.name.toLowerCase(Locale.ROOT).compareTo(b.name.toLowerCase(Locale.ROOT));
            }
        });
        for (Group g : out) {
            Collections.sort(g.books, new Comparator<Found>() {
                @Override
                public int compare(Found a, Found b) {
                    boolean sa = a.seriesNo > 0f, sb = b.seriesNo > 0f;
                    if (sa && sb && !a.series.isEmpty() && a.series.equals(b.series) && a.seriesNo != b.seriesNo) return a.seriesNo < b.seriesNo ? -1 : 1;
                    return a.shownTitle().compareToIgnoreCase(b.shownTitle());
                }
            });
        }
        return out;
    }

    private static String unknownName(By by) {
        switch (by) {
            case AUTHOR: return "Unknown author";
            case SERIES: return "Not in a series";
            default: return "\u0000";
        }
    }

    private static String nameFor(Found f, By by) {
        switch (by) {
            case AUTHOR: return f.author.isEmpty() ? unknownName(by) : firstAuthor(f.author);
            case SERIES: return f.series.isEmpty() ? unknownName(by) : f.series;
            case FOLDER: return f.folder.isEmpty() ? f.rootKey : f.folder;
            default: return f.kind == ScanKind.BLOCKED ? "Other" : f.kind.label();
        }
    }

    /** Several authors are listed under the first. */
    static String firstAuthor(String authors) {
        String[] parts = authors.split("\\s*[;&]\\s*|,\\s+(?=\\S+\\s+\\S)");
        return parts.length == 0 || parts[0].trim().isEmpty() ? authors : parts[0].trim();
    }

    /** The second line of a book row: "Stormlight 1 · 6.2 MB", or the folder when the book is in no series. */
    public static String detail(Found f) {
        String where;
        if (!f.series.isEmpty()) {
            where = f.series + (f.seriesNo > 0f ? " " + numberText(f.seriesNo) : "");
        } else {
            where = f.folder.isEmpty() ? f.rootKey : f.folder;
        }
        return where + " · " + sizeText(f.size);
    }

    static String numberText(float n) {
        return n == (long) n ? Long.toString((long) n) : Float.toString(n);
    }

    public static String sizeText(long bytes) {
        if (bytes >= 1024L * 1024L * 1024L) return String.format(Locale.US, "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
        if (bytes >= 1024L * 1024L) return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
        return Math.max(1, Math.round(bytes / 1024.0)) + " KB";
    }
}
