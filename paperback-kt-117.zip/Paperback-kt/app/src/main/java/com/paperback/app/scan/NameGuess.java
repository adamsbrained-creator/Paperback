package com.paperback.app.scan;

import java.util.Locale;
import java.util.regex.Pattern;

/** A title (and sometimes an author) worked out from a file name, for books whose file says nothing. */
final class NameGuess {
    private NameGuess() {}

    private static final String[] KNOWN = {".zip", ".fb2", ".fbz", ".mobi", ".azw", ".azw3", ".kf8", ".prc", ".epub", ".pdf", ".txt",
        ".md", ".markdown", ".html", ".htm", ".xhtml", ".docx", ".cbz", ".cbt", ".cbr", ".cb7", ".lit", ".lrf", ".djvu", ".djv", ".kfx"};
    // "(z-lib.org)", "[Calibre]", "(retail)": the tags download sites and tools add to a name
    private static final Pattern NOISE = Pattern.compile(
        "\\s*[\\[(][^\\])]*(z-lib|zlib|libgen|calibre|retail|epub|pdf|mobi|azw|ebook|scan|ocr|www\\.|\\.com|\\.org)[^\\])]*[\\])]",
        Pattern.CASE_INSENSITIVE);

    /** "my_book-v2.fb2.zip" is "my book-v2". */
    static String titleOf(String fileName) {
        String n = fileName == null ? "" : fileName;
        int slash = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (slash >= 0) n = n.substring(slash + 1);
        boolean again = true;
        while (again) {
            again = false;
            String low = n.toLowerCase(Locale.ROOT);
            for (String e : KNOWN) {
                if (low.endsWith(e) && n.length() > e.length()) {
                    n = n.substring(0, n.length() - e.length());
                    again = true;
                    break;
                }
            }
        }
        n = NOISE.matcher(n).replaceAll("");
        n = n.replace('_', ' ').trim().replaceAll("\\s+", " ");
        return n.isEmpty() ? "Untitled" : n;
    }

    /** Fills the title, and the author when the name reads "Author - Title", for a file that has no details of its own. */
    static void fill(Found f) {
        String t = titleOf(f.name);
        int i = t.indexOf(" - ");
        if (i > 0 && t.indexOf(" - ", i + 3) < 0) {
            String left = t.substring(0, i).trim();
            String right = t.substring(i + 3).trim();
            if (!right.isEmpty() && looksLikeName(left)) {
                if (f.author.isEmpty()) f.author = left;
                if (f.title.isEmpty()) f.title = right;
                return;
            }
        }
        if (f.title.isEmpty()) f.title = t;
    }

    /** One to four words, none with digits: "Frank Herbert", "Herbert, Frank", not "Part 2" or a long sentence. */
    private static boolean looksLikeName(String s) {
        if (s.isEmpty() || s.length() > 40) return false;
        String[] words = s.split("[\\s,.]+");
        if (words.length < 1 || words.length > 4) return false;
        for (String w : words) {
            if (w.isEmpty()) continue;
            if (w.matches(".*\\d.*")) return false;
            if (!Character.isUpperCase(w.codePointAt(0))) return false;
        }
        // a single word could be a title ("Dune - ..."): only trust it when there are at least two words
        return words.length >= 2;
    }
}
