package com.paperback.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.data.HeaderSize
import com.paperback.app.scan.ScanController
import com.paperback.app.scan.ScanNeed
import com.paperback.app.ui.theme.pbTokens

/*
 * Pieces shared by the scanner's seven screens: the page frame, the pill buttons, the switch and radio marks, the cover
 * block, and the card on the Library page that starts it all.
 */

/** The page every scanner screen sits in: the app's header (with Back or Close on the left), the body, and buttons pinned at the bottom. */
@Composable
internal fun ScanFrame(
    title: String,
    headerSize: HeaderSize,
    leftIcon: PbIconName,
    leftDescription: String,
    onLeft: () -> Unit,
    chip: String? = null,
    bottom: (@Composable ColumnScope.() -> Unit)? = null,
    body: @Composable ColumnScope.() -> Unit,
) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 560.dp).fillMaxSize()) {
            Column(Modifier.padding(horizontal = 20.dp)) {
                PageHeader(
                    label = title,
                    size = headerSize,
                    chip = chip,
                    onMenu = onLeft,
                    leftIcon = leftIcon,
                    leftDescription = leftDescription,
                    rightIcon = null,
                )
            }
            Column(Modifier.weight(1f).fillMaxWidth(), content = body)
            if (bottom != null) {
                Column(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    content = bottom,
                )
            }
        }
    }
}

/** [ScanFrame] with a body that scrolls (the screens that are not long lists). */
@Composable
internal fun ScanPage(
    title: String,
    headerSize: HeaderSize,
    leftIcon: PbIconName,
    leftDescription: String,
    onLeft: () -> Unit,
    chip: String? = null,
    bottom: (@Composable ColumnScope.() -> Unit)? = null,
    body: @Composable ColumnScope.() -> Unit,
) {
    ScanFrame(title, headerSize, leftIcon, leftDescription, onLeft, chip, bottom) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp), content = body)
    }
}

/** A rounded pill button of the size the scanner uses side by side. */
@Composable
internal fun PillButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, ghost: Boolean = false, enabled: Boolean = true, fontSize: Int = 15) {
    val t = pbTokens()
    Box(
        modifier
            .height(50.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .pbTap(onClick, RoundedCornerShape(25.dp), enabled = enabled, role = Role.Button)
            .background(if (ghost) t.card else t.ink)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (ghost) t.ink else t.bg, fontSize = fontSize.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** The on/off pill: fills with the accent, and the round handle slides over (the same look as the other switches in the app). */
@Composable
internal fun ScanSwitch(on: Boolean) {
    val t = pbTokens()
    val bg by animateColorAsState(if (on) MaterialTheme.colorScheme.primary else t.rule, tween(PB_MS_QUICK), label = "scanSwitchBg")
    val knob by animateDpAsState(if (on) 22.dp else 2.dp, tween(PB_MS_QUICK), label = "scanSwitchKnob")
    Box(Modifier.size(width = 50.dp, height = 30.dp).clip(CircleShape).background(bg)) {
        Box(Modifier.padding(start = knob, top = 3.dp).size(24.dp).clip(CircleShape).background(if (on) MaterialTheme.colorScheme.onPrimary else t.sub))
    }
}

/** A line with a title, an optional second line, and a switch; the whole line is the target. */
@Composable
internal fun ScanSwitchRow(title: String, sub: String?, on: Boolean, onChange: (Boolean) -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .pbTap({ onChange(!on) }, RoundedCornerShape(20.dp), pressedScale = 0.99f, haptic = true, role = Role.Switch)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        }
        ScanSwitch(on)
    }
}

/** The round choice mark: an empty ring, or a ring with a coral dot inside. */
@Composable
internal fun RadioMark(selected: Boolean) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    val ring by animateColorAsState(if (selected) primary else t.setSub.copy(alpha = 0.55f), tween(PB_MS_QUICK), label = "radioRing")
    Box(Modifier.size(24.dp).clip(CircleShape).border(2.dp, ring, CircleShape), contentAlignment = Alignment.Center) {
        if (selected) Box(Modifier.size(12.dp).clip(CircleShape).background(primary))
    }
}

private val COVER_COLORS = listOf(
    Color(0xFF7A2E3A), Color(0xFF2F4F4F), Color(0xFF5A3E85), Color(0xFF8A5A1F),
    Color(0xFF1F5E4A), Color(0xFF4A4A4A), Color(0xFF2E4A7A), Color(0xFF7A5A2E),
)

/** A small cover stand-in: a block of colour that is always the same for the same title (the real cover comes when the book is added). */
@Composable
internal fun CoverBlock(title: String, modifier: Modifier = Modifier, width: Int = 40, height: Int = 56) {
    val color = COVER_COLORS[(title.hashCode() and 0x7FFFFFFF) % COVER_COLORS.size]
    Box(modifier.size(width = width.dp, height = height.dp).clip(RoundedCornerShape(6.dp)).background(color), contentAlignment = Alignment.Center) {
        Text(
            title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "",
            color = Color.White.copy(alpha = 0.85f),
            fontSize = (width * 0.4f).sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/** "EPUB" in a small rounded tag. */
@Composable
internal fun FormatTag(text: String) {
    val t = pbTokens()
    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(t.card).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text(text, color = t.sub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** The Library page's card: "Find books on this phone", or how the scan is going, or how many books are waiting. */
@Composable
fun ScanEntryCard(
    scanner: ScanController,
    onOpen: () -> Unit,
    onNeed: (ScanNeed) -> Unit,
    onChooseFolders: () -> Unit,
    onSettings: () -> Unit,
) {
    val t = pbTokens()
    val scanning by scanner.scanning.collectAsStateWithLifecycle()
    val adding by scanner.adding.collectAsStateWithLifecycle()
    val results by scanner.results.collectAsStateWithLifecycle()
    val progress by scanner.progress.collectAsStateWithLifecycle()
    val waiting = results?.offered?.size ?: 0

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(t.bg), contentAlignment = Alignment.Center) {
                PbIcon(PbIconName.Scan, size = 20.dp, tint = MaterialTheme.colorScheme.primary)
            }
            Text("Book scanner", color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            QuietAction("Settings", onSettings, color = t.ink, fontSize = 13.sp)
        }
        when {
            scanning -> {
                Text("Scanning your phone", color = t.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("${progress.percent}% · ${progress.books} books found so far. It goes on in the background.", color = t.sub, fontSize = 14.sp, lineHeight = 20.sp)
                PillButton("See progress", { scanner.openResults(); onOpen() }, Modifier.fillMaxWidth())
            }
            adding != null -> {
                Text("Adding books", color = t.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("${adding?.first ?: 0} of ${adding?.second ?: 0} added so far.", color = t.sub, fontSize = 14.sp)
                PillButton("See progress", { scanner.openResults(); onOpen() }, Modifier.fillMaxWidth())
            }
            waiting > 0 -> {
                Text(if (waiting == 1) "1 new book found" else "$waiting new books found", color = t.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("Nothing is added until you say so.", color = t.sub, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Review", { scanner.openResults(); onOpen() }, Modifier.weight(1f))
                    PillButton("Dismiss", { scanner.discardResults() }, Modifier.weight(1f), ghost = true)
                }
            }
            else -> {
                Text("Find books on this phone", color = t.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("Look through your storage for ebooks and comics, then sort them for you.", color = t.sub, fontSize = 14.sp, lineHeight = 20.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Scan now", { onNeed(scanner.scanNow()); onOpen() }, Modifier.weight(1f))
                    PillButton("Choose folders instead", onChooseFolders, Modifier.weight(1.4f), ghost = true, fontSize = 14)
                }
            }
        }
    }
}
