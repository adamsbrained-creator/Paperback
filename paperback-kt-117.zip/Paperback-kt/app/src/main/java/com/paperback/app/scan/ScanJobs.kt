package com.paperback.app.scan

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import com.paperback.app.PaperbackApp
import kotlinx.coroutines.launch

/** Schedules the automatic scan: when new files appear on the phone, or once a day while it charges. */
object ScanJobs {
    private const val ID = 7117

    fun schedule(context: Context, store: ScanStore) {
        val js = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler ?: return
        js.cancel(ID)
        if (!store.auto.value || store.whenMode.value == ScanStore.WHEN_MANUAL) return
        val b = JobInfo.Builder(ID, ComponentName(context, ScanJobService::class.java))
        if (store.whenMode.value == ScanStore.WHEN_APPEAR) {
            b.addTriggerContentUri(JobInfo.TriggerContentUri(MediaStore.Files.getContentUri("external"), JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS))
            b.setTriggerContentUpdateDelay(30_000L)
            b.setTriggerContentMaxDelay(5 * 60_000L)
        } else {
            b.setPeriodic(24L * 60 * 60 * 1000)
            b.setRequiresCharging(true)
            b.setPersisted(true)
        }
        runCatching { js.schedule(b.build()) }
    }
}

/** Runs the automatic scan in the background. */
class ScanJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val graph = (application as PaperbackApp).graph
        // a job that waits for new files runs once: put the next one in line before this one starts
        ScanJobs.schedule(this, graph.scanStore)
        graph.appScope.launch {
            try {
                graph.scanner.runAuto()
            } finally {
                jobFinished(params, false)
            }
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean {
        (application as PaperbackApp).graph.scanner.stopAndReview()
        return true
    }
}

/** After a restart the "when new files appear" job is gone: puts it back. */
class ScanBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val graph = (context.applicationContext as PaperbackApp).graph
        ScanJobs.schedule(context, graph.scanStore)
    }
}
