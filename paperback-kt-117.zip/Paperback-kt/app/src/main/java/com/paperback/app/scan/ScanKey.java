package com.paperback.app.scan;

import java.text.Normalizer;
import java.util.Locale;

/**
 * Titles and authors reduced to what identifies them, so "The Hobbit (z-lib.org)" and "the hobbit" match, and
 * so do Cyrillic and other non-Latin titles. Stricter than the catalog's TitleKey on purpose: "Dune" and
 * "Dune: Messiah" are two books here, because calling a different book a duplicate would hide it.
 */
public final class ScanKey {
    private ScanKey() {}

    public static String title(String title) {
        if (title == null) return "";
        String s = fold(title);
        s = s.replaceAll("\\([^)]*\\)|\\[[^\\]]*\\]", " ").trim();
        s = s.replaceAll("^(the|a|an) ", "");
        return s.replaceAll("[^\\p{L}\\p{N}]+", "");
    }

    /** The surname of the first author, folded: "Herbert, Frank", "Frank Herbert" and "Frank Herbert; Brian Herbert" agree. */
    public static String author(String author) {
        if (author == null) return "";
        String s = fold(author).trim();
        if (s.isEmpty()) return "";
        String first = s.split("\\s*(;|&|\\band\\b|\\bи\\b)\\s*")[0].trim();
        String[] comma = first.split(",");
        String surname;
        if (comma.length >= 2 && comma[0].trim().indexOf(' ') < 0) {
            surname = comma[0].trim(); // "Herbert, Frank"
        } else {
            String one = comma[0].trim(); // "Frank Herbert, Brian Herbert": the first of them
            String[] words = one.split("\\s+");
            surname = words[words.length - 1];
        }
        return surname.replaceAll("[^\\p{L}\\p{N}]+", "");
    }

    /** Same book: the titles match and the authors do not disagree (an unknown author agrees with anyone). */
    public static boolean sameBook(String titleA, String authorA, String titleB, String authorB) {
        String ta = title(titleA), tb = title(titleB);
        if (ta.length() < 2 || !ta.equals(tb)) return false;
        String aa = author(authorA), ab = author(authorB);
        return aa.isEmpty() || ab.isEmpty() || aa.equals(ab);
    }

    private static String fold(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.toLowerCase(Locale.ROOT);
    }
}
