package com.paperback.app.scan;

import com.paperback.app.convert.BookConverter;

/** Fills in a found book's title, author, series, subjects and problem, whatever its kind. Never throws. */
public final class InfoReader {
    private InfoReader() {}

    public static void read(ScanFs fs, Found f) {
        try {
            switch (f.kind) {
                case EPUB:
                    EpubInfo.read(fs, f);
                    break;
                case MOBI:
                case AZW3:
                    MobiInfo.read(fs, f);
                    break;
                case FB2:
                    Fb2Info.read(fs, f);
                    break;
                case DOCX:
                    DocxInfo.read(fs, f);
                    break;
                case BLOCKED:
                    f.problem = BookConverter.unsupportedMessage(f.name);
                    break;
                default:
                    break; // PDF, comics, text, Markdown and HTML say nothing useful inside: the file name is the title
            }
        } catch (RuntimeException e) {
            // a file that broke the reader is still listed, by its name
        }
        NameGuess.fill(f);
        f.title = f.title.trim();
        f.author = f.author.trim();
        f.series = f.series.trim();
    }
}
