package com.paperback.app.scan;

/** One thing inside a folder: a file or a folder. [ref] is whatever the [ScanFs] needs to open or list it again. */
public final class ScanEntry {
    public final String name;
    public final boolean isDir;
    public final long size;
    public final long modified;
    public final String ref;

    public ScanEntry(String name, boolean isDir, long size, long modified, String ref) {
        this.name = name;
        this.isDir = isDir;
        this.size = size;
        this.modified = modified;
        this.ref = ref;
    }
}
