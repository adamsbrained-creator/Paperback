package com.paperback.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Arrangement
import com.paperback.app.ui.theme.pbTokens
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.BookSort
import com.paperback.app.data.Tags

private enum class Filter(val label: String) { All("All"), Reading("Reading"), Finished("Finished"), Favorites("Favorites") }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    books: List<Book>,
    onOpen: (Book) -> Unit,
    onDetails: (Book) -> Unit,
    onImport: () -> Unit,
    onDiscover: () -> Unit,
    onToggleFavorite: (Book) -> Unit,
    onToggleFinished: (Book) -> Unit,
    onRemove: (Book) -> Unit,
    modifier: Modifier = Modifier,
    shelfView: Boolean = true,
    onShelfView: (Boolean) -> Unit = {},
    frosted: Boolean = false,
    onFrosted: (Boolean) -> Unit = {},
    /** The book scanner's card, shown at the top of the plain library (no search or filter) and on the empty library. */
    scanCard: (@Composable () -> Unit)? = null,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(Filter.All) }
    var sort by rememberSaveable { mutableStateOf(BookSort.Added) }
    var genre by rememberSaveable { mutableStateOf("") } // "" = every genre
    val genres = remember(books) { Tags.counts(books).take(40) }

    val shown = remember(books, query, filter, sort, genre) {
        sort.apply(books).filter { b ->
            val matchesFilter = when (filter) {
                Filter.All -> true
                Filter.Reading -> b.isReading
                Filter.Finished -> b.finished
                Filter.Favorites -> b.favorite
            }
            val q = query.trim()
            val matchesGenre = genre.isEmpty() || Tags.has(b, genre)
            matchesFilter && matchesGenre && (q.isEmpty() || b.title.contains(q, ignoreCase = true) ||
                b.author.contains(q, ignoreCase = true) || b.tags.any { it.contains(q, ignoreCase = true) })
        }
    }

    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                PbField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = "Search title, author or genre",
                    leading = PbIconName.Search,
                    onClear = { query = "" },
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Filter.values().forEach { f ->
                        TogglePill(f.label, filter == f) { filter = f }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MenuPill("Sort: ${sort.label}", active = sort != BookSort.Added) { close ->
                        BookSort.values().forEach { s ->
                            DropdownMenuItem(
                                text = { Text((if (s == sort) "\u2713 " else "") + s.label) },
                                onClick = { close(); sort = s },
                            )
                        }
                    }
                    MenuPill("View: ${if (frosted) "Frosted" else if (shelfView) "Shelves" else "Covers"}") { close ->
                        DropdownMenuItem(
                            text = { Text((if (!frosted && shelfView) "\u2713 " else "") + "Shelves") },
                            onClick = { close(); onFrosted(false); onShelfView(true) },
                        )
                        DropdownMenuItem(
                            text = { Text((if (frosted) "\u2713 " else "") + "Frosted shelves") },
                            onClick = { close(); onFrosted(true) },
                        )
                        DropdownMenuItem(
                            text = { Text((if (!frosted && !shelfView) "\u2713 " else "") + "Covers") },
                            onClick = { close(); onFrosted(false); onShelfView(false) },
                        )
                    }
                    if (genres.isNotEmpty() || genre.isNotEmpty()) {
                        MenuPill(if (genre.isEmpty()) "Genre" else genre, active = genre.isNotEmpty()) { close ->
                            DropdownMenuItem(
                                text = { Text((if (genre.isEmpty()) "\u2713 " else "") + "All genres") },
                                onClick = { close(); genre = "" },
                            )
                            genres.forEach { (name, count) ->
                                DropdownMenuItem(
                                    text = { Text((if (name.equals(genre, ignoreCase = true)) "\u2713 " else "") + "$name ($count)") },
                                    onClick = { close(); genre = name },
                                )
                            }
                        }
                    }
                }
            }

            if (shown.isEmpty()) {
                if (books.isEmpty()) {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        LibraryEmpty(onImport = onImport, onDiscover = onDiscover)
                        scanCard?.invoke()
                    }
                } else {
                    Box(Modifier.fillMaxSize().padding(32.dp)) {
                        Text("Nothing matches.", color = pbTokens().setSub)
                    }
                }
            } else if (frosted) {
                // One frosted shelf per genre (favorites first in the plain view), each a row you swipe sideways.
                val plain = filter == Filter.All && query.isBlank() && genre.isEmpty()
                val groups = remember(shown, plain) { frostedGroups(shown, plain) }
                val menu = remember(onDetails, onToggleFavorite, onToggleFinished, onRemove) {
                    bookMenu(onDetails, onToggleFavorite, onToggleFinished, onRemove)
                }
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    if (plain && scanCard != null) item(key = "scan-card") { scanCard() }
                    items(groups.size, key = { groups[it].first }) { i ->
                        FrostedShelfGroup(groups[i].first, groups[i].second, onOpen, menu)
                    }
                }
            } else if (shelfView) {
                // Favorites get their own shelf on top, but only in the plain, unfiltered view.
                val plain = filter == Filter.All && query.isBlank() && genre.isEmpty()
                val pinned = if (plain) shown.filter { it.favorite } else emptyList()
                val rest = if (pinned.isEmpty()) shown else shown.filter { !it.favorite }
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val inner = maxWidth - 40.dp
                    val pinnedRows = remember(pinned, inner) { packShelves(pinned, inner) }
                    val restRows = remember(rest, inner) { packShelves(rest, inner) }
                    LazyColumn(
                        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 96.dp),
                        verticalArrangement = Arrangement.spacedBy(22.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        if (plain && scanCard != null) item(key = "scan-card") { scanCard() }
                        if (pinnedRows.isNotEmpty()) {
                            item(key = "h-pinned") { Eyebrow("Favorites") }
                            items(pinnedRows.size, key = { "p$it" }) { i -> LibraryShelf(pinnedRows[i], onOpen, onDetails, onToggleFavorite, onToggleFinished, onRemove) }
                            if (restRows.isNotEmpty()) item(key = "h-rest") { Eyebrow("Library") }
                        }
                        items(restRows.size, key = { "r$it" }) { i -> LibraryShelf(restRows[i], onOpen, onDetails, onToggleFavorite, onToggleFinished, onRemove) }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(112.dp),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    if (filter == Filter.All && query.isBlank() && genre.isEmpty() && scanCard != null) {
                        item(key = "scan-card", span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) { scanCard() }
                    }
                    items(shown, key = { it.id }) { book ->
                        var menu by remember { mutableStateOf(false) }
                        Box {
                            Column(Modifier.pbTapLong({ onOpen(book) }, { menu = true })) {
                                BookCover(book)
                                Spacer(Modifier.height(8.dp))
                                Text(book.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                if (book.author.isNotBlank()) {
                                    Text(book.author, fontSize = 12.sp, color = pbTokens().setSub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (book.isReading) {
                                    Spacer(Modifier.height(6.dp))
                                    ProgressTrack(book.progress, height = 4.dp)
                                } else if (book.finished) {
                                    Text("Finished", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            DropdownMenu(
                                expanded = menu,
                                onDismissRequest = { menu = false },
                                shape = RoundedCornerShape(22.dp),
                                containerColor = pbTokens().menuBg,
                                tonalElevation = 0.dp,
                                shadowElevation = 12.dp,
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Details") },
                                    onClick = { menu = false; onDetails(book) },
                                )
                                DropdownMenuItem(
                                    text = { Text(if (book.favorite) "Remove from favorites" else "Add to favorites") },
                                    onClick = { menu = false; onToggleFavorite(book) },
                                )
                                DropdownMenuItem(
                                    text = { Text(if (book.finished) "Mark as not finished" else "Mark as finished") },
                                    onClick = { menu = false; onToggleFinished(book) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Remove from library") },
                                    onClick = { menu = false; onRemove(book) },
                                )
                            }
                        }
                    }
                }
            }
        }

        // Round coral "+" like the old app's import button.
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .size(56.dp)
                .shadow(8.dp, CircleShape)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .clickable(onClick = onImport),
            contentAlignment = Alignment.Center,
        ) { PbIcon(PbIconName.Plus, size = 26.dp, tint = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.4f, contentDescription = "Import books") }
    }
}

/** One shelf of the library, with the same long-press menu the covers have. */
@Composable
private fun LibraryShelf(
    row: List<Book>,
    onOpen: (Book) -> Unit,
    onDetails: (Book) -> Unit,
    onToggleFavorite: (Book) -> Unit,
    onToggleFinished: (Book) -> Unit,
    onRemove: (Book) -> Unit,
) {
    ShelfRow(row, leanId = null, onClick = onOpen) { book, close ->
        DropdownMenuItem(text = { Text("Details") }, onClick = { close(); onDetails(book) })
        DropdownMenuItem(
            text = { Text(if (book.favorite) "Remove from favorites" else "Add to favorites") },
            onClick = { close(); onToggleFavorite(book) },
        )
        DropdownMenuItem(
            text = { Text(if (book.finished) "Mark as not finished" else "Mark as finished") },
            onClick = { close(); onToggleFinished(book) },
        )
        DropdownMenuItem(text = { Text("Remove from library") }, onClick = { close(); onRemove(book) })
    }
}

/** The long-press menu every book gets on the library shelves. */
private fun bookMenu(
    onDetails: (Book) -> Unit,
    onToggleFavorite: (Book) -> Unit,
    onToggleFinished: (Book) -> Unit,
    onRemove: (Book) -> Unit,
): @Composable ColumnScope.(Book, () -> Unit) -> Unit = { book, close ->
    DropdownMenuItem(text = { Text("Details") }, onClick = { close(); onDetails(book) })
    DropdownMenuItem(
        text = { Text(if (book.favorite) "Remove from favorites" else "Add to favorites") },
        onClick = { close(); onToggleFavorite(book) },
    )
    DropdownMenuItem(
        text = { Text(if (book.finished) "Mark as not finished" else "Mark as finished") },
        onClick = { close(); onToggleFinished(book) },
    )
    DropdownMenuItem(text = { Text("Remove from library") }, onClick = { close(); onRemove(book) })
}
