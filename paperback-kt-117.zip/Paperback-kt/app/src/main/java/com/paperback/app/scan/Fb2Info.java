package com.paperback.app.scan;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Title, author, series and genre from the top of an FB2 book (also when it is zipped). Reads the first part only. */
final class Fb2Info {
    private Fb2Info() {}

    static void read(ScanFs fs, Found f) {
        try {
            InputStream in = fs.open(f.ref);
            try {
                byte[] bytes;
                if (f.name.toLowerCase(Locale.ROOT).endsWith(".zip") || f.name.toLowerCase(Locale.ROOT).endsWith(".fbz")) {
                    ZipInputStream zin = new ZipInputStream(in);
                    ZipEntry e;
                    bytes = null;
                    while ((e = zin.getNextEntry()) != null) {
                        if (e.getName().toLowerCase(Locale.ROOT).endsWith(".fb2")) {
                            bytes = Xmlish.read(zin, 96 * 1024);
                            break;
                        }
                    }
                    if (bytes == null) return;
                } else {
                    bytes = Xmlish.read(in, 96 * 1024);
                }
                parse(Xmlish.decode(bytes), f);
            } finally {
                in.close();
            }
        } catch (IOException e) {
            // unreadable now: the title comes from the file name
        }
    }

    static void parse(String xml, Found f) {
        int a = xml.indexOf("<title-info");
        int b = xml.indexOf("</title-info>");
        String info = a >= 0 ? xml.substring(a, b > a ? b : xml.length()) : xml;
        String title = Xmlish.first(info, "book-title");
        if (!title.isEmpty()) f.title = title;
        Matcher am = Pattern.compile("<author>(.*?)</author>", Pattern.DOTALL).matcher(info);
        StringBuilder authors = new StringBuilder();
        int count = 0;
        while (am.find() && count < 3) {
            String first = Xmlish.first(am.group(1), "first-name");
            String last = Xmlish.first(am.group(1), "last-name");
            String name = (first + " " + last).trim();
            if (name.isEmpty()) name = Xmlish.first(am.group(1), "nickname");
            if (name.isEmpty()) continue;
            if (count++ > 0) authors.append(", ");
            authors.append(name);
        }
        if (authors.length() > 0) f.author = authors.toString();
        for (String g : Xmlish.all(info, "genre")) {
            if (f.subjects.size() < 8) f.subjects.add(genreName(g));
        }
        Matcher sm = Pattern.compile("<sequence\\b[^>]*>", Pattern.CASE_INSENSITIVE).matcher(info);
        if (sm.find()) {
            f.series = Xmlish.attr(sm.group(), "name");
            f.seriesNo = EpubInfo.number(Xmlish.attr(sm.group(), "number"));
        }
        String lang = Xmlish.first(info, "lang");
        if (!lang.isEmpty()) f.language = lang;
    }

    /** FB2 genre codes like "sf_fantasy" or "prose_classic" as words the shelf rules understand. */
    static String genreName(String code) {
        String c = code.toLowerCase(Locale.ROOT).trim();
        if (c.startsWith("sf_fantasy") || c.equals("fantasy")) return "Fantasy";
        if (c.startsWith("sf")) return "Science fiction";
        if (c.startsWith("prose_classic") || c.startsWith("antique") || c.equals("russian_classic")) return "Classics";
        if (c.startsWith("det_") || c.startsWith("thriller")) return "Mystery and thriller";
        if (c.startsWith("love")) return "Romance";
        if (c.startsWith("child")) return "Children";
        if (c.startsWith("poetry")) return "Poetry";
        if (c.startsWith("nonf") || c.startsWith("sci_") || c.startsWith("science")) return "Non-fiction";
        if (c.startsWith("ref_")) return "Reference";
        if (c.startsWith("comp_")) return "Computers";
        if (c.startsWith("humor")) return "Humor";
        return code.replace('_', ' ');
    }
}
