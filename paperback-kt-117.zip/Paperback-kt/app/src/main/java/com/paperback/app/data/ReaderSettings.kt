package com.paperback.app.data

import android.content.Context
import org.readium.r2.navigator.epub.EpubPreferences
import org.readium.r2.navigator.preferences.ColumnCount
import org.readium.r2.navigator.preferences.FontFamily
import org.readium.r2.navigator.preferences.ImageFilter
import org.readium.r2.navigator.preferences.ReadingProgression
import org.readium.r2.navigator.preferences.TextAlign
import org.readium.r2.navigator.preferences.Color as ReadiumColor
import org.readium.r2.navigator.preferences.Theme
import com.paperback.app.reader.ReaderThemes

/**
 * How the page is laid out. While [custom] is off the book keeps its own fonts, spacing and alignment
 * (that is what Readium calls publisher styles); turning it on applies [fontFamily], [lineSpacing], [justify], [paragraphSpacing] and [indent].
 * The Readest look is [ReaderLook.readest]: Readest's own defaults (sans, line height 1.4, left aligned, 0.6 between paragraphs, no indent).
 * [margins] and [brightness] work either way. [brightness] below zero means "follow the phone".
 */
data class ReaderLook(
    val custom: Boolean = false,
    /** 0 = serif, 1 = sans, 2 = mono */
    val fontFamily: Int = 0,
    val lineSpacing: Float = 1.5f,
    val margins: Float = 1.0f,
    val justify: Boolean = true,
    val brightness: Float = -1f,
    /** Space between paragraphs, in lines of text (Readium's rem). Readest uses 0.6. */
    val paragraphSpacing: Float = 0.6f,
    /** First-line indent in em. Readest uses 0. */
    val indent: Float = 0f,
    /** Distance in dp from the top edge of the screen to the first line of text. 64 = Readest's, 0 = the text starts at the very edge. */
    val topSpace: Float = DEFAULT_TOP_SPACE,
    /** Distance in dp from the bottom edge of the screen to the last line of text. 44 = Readest's, 0 = the very edge. */
    val bottomSpace: Float = DEFAULT_BOTTOM_SPACE,
    /** Distance in dp from the top edge of the screen to the chapter name ("header helper"). It is independent of [topSpace]. */
    val headerSpace: Float = DEFAULT_HEADER_SPACE,
    /** Which small texts show at the bottom of the page: a mix of [FOOTER_LEFT_PAGES], [FOOTER_PERCENT] and [FOOTER_TOTAL]. */
    val footerItems: Int = FOOTER_LEFT_PAGES or FOOTER_TOTAL,
    /** Font weight, 1 = normal (custom layout only). */
    val fontWeight: Float = 1f,
    /** Extra space between letters and between words, in em (custom layout only). */
    val letterSpacing: Float = 0f,
    val wordSpacing: Float = 0f,
    /** Break long words with a hyphen at the end of a line (custom layout only). */
    val hyphens: Boolean = true,
    /** 0 = automatic (two columns on a wide screen), 1 = always one column. */
    val columns: Int = 0,
    /** The chapter name at the top of the page, and the size of the small texts around the page, in sp. */
    val showHeader: Boolean = true,
    val headerSize: Float = 12f,
    val footerSize: Float = 12f,
    /** Keep the screen on while reading. */
    val keepScreenOn: Boolean = false,
    /** Scroll the book instead of turning pages. */
    val scrolled: Boolean = false,
    /** Invert images on the dark page colours, so white diagrams do not glare. */
    val invertImages: Boolean = false,
    /** Tapping near the left or right edge turns the page. */
    val tapTurn: Boolean = true,
    /** Both edges go forward, whichever side you tap. */
    val tapBoth: Boolean = false,
    /** Left edge goes forward and right edge goes back. */
    val swapTaps: Boolean = false,
    /** Volume up = previous page, volume down = next page. */
    val volumeKeys: Boolean = false,
    /** Slide a finger up or down along the left edge to change the brightness. */
    val brightnessSwipe: Boolean = false,
    /** 0 = follow the phone, 1 = portrait, 2 = landscape. */
    val orientation: Int = 0,
    /** 0 = from the book, 1 = left to right, 2 = right to left. */
    val direction: Int = 0,
    /** Vertical writing (Japanese, Chinese). */
    val verticalText: Boolean = false,
    /** Page turns by tap or volume key glide instead of jumping. */
    val pageAnimation: Boolean = true,
    /** 0 = Push (both pages move together as one strip), 1 = Slide (the old page slides away over the new one). */
    val pageStyle: Int = 0,
    /** Auto scroll speed in percent (25 to 500, 100 = 20 dp per second), as in the TypeScript version. */
    val autoScrollSpeed: Int = 100,
    /** Pull down from the top edge of the page to add or remove a bookmark. */
    val pullBookmark: Boolean = true,
    /** Which tools the menu over selected text shows (TOOL_ flags). */
    val tools: Int = TOOL_HIGHLIGHT or TOOL_NOTE,
    /** Quick action: runs by itself as soon as you select text. QUICK_NONE, or one of the QUICK_ actions. */
    val quickAction: Int = QUICK_NONE,
    /** Copying selected text also saves it as a highlight in the book's notes. */
    val copyToNotebook: Boolean = false,
    /** A font by name (an imported file, see ReaderFonts, or an Android system font). Empty = use the Serif / Sans / Mono choice. */
    val fontName: String = "",
    /** Joined letter shapes such as fi and fl (custom layout only). On is the normal look, so only Off is sent to the book. */
    val ligatures: Boolean = true,
) {
    companion object {
        /** Readest's defaults on a phone, keeping the phone's brightness choice. */
        fun readest(brightness: Float) = ReaderLook(
            custom = true, fontFamily = 1, lineSpacing = 1.4f, margins = 1.0f, justify = false,
            brightness = brightness, paragraphSpacing = 0.6f, indent = 0f,
            topSpace = DEFAULT_TOP_SPACE, bottomSpace = DEFAULT_BOTTOM_SPACE, headerSpace = DEFAULT_HEADER_SPACE,
        )
    }
}

/** Bottom-of-page texts (bit flags): "4 pages left", "98.8%" and "492 / 496". */
const val FOOTER_LEFT_PAGES = 1
const val FOOTER_PERCENT = 2
const val FOOTER_TOTAL = 4
const val FOOTER_TIME_LEFT = 8
const val FOOTER_BATTERY = 16
const val FOOTER_CLOCK = 32
const val FOOTER_BAR = 64
const val FOOTER_ALL = 127
/** Tools in the menu over selected text (bit flags) and the quick actions (a number). */
const val TOOL_HIGHLIGHT = 1
const val TOOL_NOTE = 2
const val TOOL_COPY = 4
const val TOOL_DICTIONARY = 8
const val TOOL_SEARCH = 16
const val TOOL_SPEAK = 32
const val TOOL_SHARE = 64
const val TOOL_ALL = 127
const val QUICK_NONE = 0
const val QUICK_DICTIONARY = 1
const val QUICK_SEARCH = 2
const val QUICK_SPEAK = 3
const val QUICK_SHARE = 4
const val DEFAULT_TOP_SPACE = 64f
const val DEFAULT_BOTTOM_SPACE = 44f
const val DEFAULT_HEADER_SPACE = 40f
const val SPACE_MIN = 0f
const val SPACE_MAX = 160f
const val HEADER_MIN = 0f
const val HEADER_MAX = 160f

/** The reader choices Paperback remembers. */
class ReaderSettings(context: Context) {
    private val sp = context.getSharedPreferences("reader", Context.MODE_PRIVATE)

    var fontSize: Double
        get() = sp.getFloat("fontSize", 1.0f).toDouble()
        set(v) = sp.edit().putFloat("fontSize", v.toFloat()).apply()

    /** The page colour (see [ReaderThemes]); -1, the default, follows the phone: white in the light theme, black in the dark one. */
    var theme: Int
        get() = sp.getInt("theme", ReaderThemes.AUTO).let { if (it in 0..5) it else ReaderThemes.AUTO }
        set(v) = sp.edit().putInt("theme", v).apply()

    /** The reader's bottom controls: 0 = compact card, 1 = quick settings, 2 = icon tiles, 3 = settings panel (tiles, sliders and the Advanced settings page). */
    var chromeStyle: Int
        get() = sp.getInt("chromeStyle", 0).coerceIn(0, 3)
        set(v) = sp.edit().putInt("chromeStyle", v).apply()

    /** PDF viewer: true turns pages right to left (manga). */
    var pdfRtl: Boolean
        get() = sp.getBoolean("pdfRtl", false)
        set(v) = sp.edit().putBoolean("pdfRtl", v).apply()

    var look: ReaderLook
        get() {
            val d = ReaderLook()
            return ReaderLook(
                custom = sp.getBoolean("custom", d.custom),
                fontFamily = sp.getInt("fontFamily", d.fontFamily).coerceIn(0, 2),
                lineSpacing = sp.getFloat("lineSpacing", d.lineSpacing).coerceIn(1.0f, 2.2f),
                margins = sp.getFloat("margins", d.margins).coerceIn(0.5f, 2.5f),
                justify = sp.getBoolean("justify", d.justify),
                brightness = sp.getFloat("brightness", d.brightness),
                paragraphSpacing = sp.getFloat("paragraphSpacing", d.paragraphSpacing).coerceIn(0f, 2f),
                indent = sp.getFloat("indent", d.indent).coerceIn(0f, 3f),
                // Older versions had one 0..1.5 "Top and bottom space" slider; turn it into the new dp values once.
                topSpace = (if (sp.contains("topSpace")) sp.getFloat("topSpace", d.topSpace)
                    else if (sp.contains("verticalSpace")) 20f + (DEFAULT_TOP_SPACE - 20f) * sp.getFloat("verticalSpace", 1f)
                    else d.topSpace).coerceIn(SPACE_MIN, SPACE_MAX),
                bottomSpace = (if (sp.contains("bottomSpace")) sp.getFloat("bottomSpace", d.bottomSpace)
                    else if (sp.contains("verticalSpace")) 20f + (DEFAULT_BOTTOM_SPACE - 20f) * sp.getFloat("verticalSpace", 1f)
                    else d.bottomSpace).coerceIn(SPACE_MIN, SPACE_MAX),
                headerSpace = sp.getFloat("headerSpace", d.headerSpace).coerceIn(HEADER_MIN, HEADER_MAX),
                footerItems = sp.getInt("footerItems", d.footerItems).and(FOOTER_ALL),
                fontWeight = sp.getFloat("fontWeight", d.fontWeight).coerceIn(0.5f, 2.0f),
                letterSpacing = sp.getFloat("letterSpacing", d.letterSpacing).coerceIn(0f, 0.5f),
                wordSpacing = sp.getFloat("wordSpacing", d.wordSpacing).coerceIn(0f, 1f),
                hyphens = sp.getBoolean("hyphens", d.hyphens),
                columns = sp.getInt("columns", d.columns).coerceIn(0, 2),
                showHeader = sp.getBoolean("showHeader", d.showHeader),
                headerSize = sp.getFloat("headerSize", d.headerSize).coerceIn(8f, 20f),
                footerSize = sp.getFloat("footerSize", d.footerSize).coerceIn(8f, 20f),
                keepScreenOn = sp.getBoolean("keepScreenOn", d.keepScreenOn),
                scrolled = sp.getBoolean("scrolled", d.scrolled),
                invertImages = sp.getBoolean("invertImages", d.invertImages),
                tapTurn = sp.getBoolean("tapTurn", d.tapTurn),
                tapBoth = sp.getBoolean("tapBoth", d.tapBoth),
                swapTaps = sp.getBoolean("swapTaps", d.swapTaps),
                volumeKeys = sp.getBoolean("volumeKeys", d.volumeKeys),
                brightnessSwipe = sp.getBoolean("brightnessSwipe", d.brightnessSwipe),
                orientation = sp.getInt("orientation", d.orientation).coerceIn(0, 2),
                direction = sp.getInt("direction", d.direction).coerceIn(0, 2),
                verticalText = sp.getBoolean("verticalText", d.verticalText),
                pageAnimation = sp.getBoolean("pageAnimation", d.pageAnimation),
                pageStyle = sp.getInt("pageStyle", d.pageStyle).coerceIn(0, 1),
                autoScrollSpeed = sp.getInt("autoScrollSpeed", d.autoScrollSpeed).coerceIn(25, 500),
                pullBookmark = sp.getBoolean("pullBookmark", d.pullBookmark),
                tools = sp.getInt("tools", d.tools).and(TOOL_ALL),
                quickAction = sp.getInt("quickAction", d.quickAction).coerceIn(0, 4),
                copyToNotebook = sp.getBoolean("copyToNotebook", d.copyToNotebook),
                fontName = sp.getString("fontName", d.fontName).orEmpty(),
                ligatures = sp.getBoolean("ligatures", d.ligatures),
            )
        }
        set(v) {
            sp.edit()
                .putBoolean("custom", v.custom)
                .putInt("fontFamily", v.fontFamily)
                .putFloat("lineSpacing", v.lineSpacing)
                .putFloat("margins", v.margins)
                .putBoolean("justify", v.justify)
                .putFloat("brightness", v.brightness)
                .putFloat("paragraphSpacing", v.paragraphSpacing)
                .putFloat("indent", v.indent)
                .putFloat("topSpace", v.topSpace)
                .putFloat("bottomSpace", v.bottomSpace)
                .putFloat("headerSpace", v.headerSpace)
                .putInt("footerItems", v.footerItems)
                .putFloat("fontWeight", v.fontWeight)
                .putFloat("letterSpacing", v.letterSpacing)
                .putFloat("wordSpacing", v.wordSpacing)
                .putBoolean("hyphens", v.hyphens)
                .putInt("columns", v.columns)
                .putBoolean("showHeader", v.showHeader)
                .putFloat("headerSize", v.headerSize)
                .putFloat("footerSize", v.footerSize)
                .putBoolean("keepScreenOn", v.keepScreenOn)
                .putBoolean("scrolled", v.scrolled)
                .putBoolean("invertImages", v.invertImages)
                .putBoolean("tapTurn", v.tapTurn)
                .putBoolean("tapBoth", v.tapBoth)
                .putBoolean("swapTaps", v.swapTaps)
                .putBoolean("volumeKeys", v.volumeKeys)
                .putBoolean("brightnessSwipe", v.brightnessSwipe)
                .putInt("orientation", v.orientation)
                .putInt("direction", v.direction)
                .putBoolean("verticalText", v.verticalText)
                .putBoolean("pageAnimation", v.pageAnimation)
                .putInt("pageStyle", v.pageStyle)
                .putInt("autoScrollSpeed", v.autoScrollSpeed)
                .putBoolean("pullBookmark", v.pullBookmark)
                .putInt("tools", v.tools)
                .putInt("quickAction", v.quickAction)
                .putBoolean("copyToNotebook", v.copyToNotebook)
                .putString("fontName", v.fontName)
                .putBoolean("ligatures", v.ligatures)
                .apply()
        }

    /** [systemDark] is the phone's theme, which decides the page colour while [theme] is Auto. */
    fun toEpubPreferences(systemDark: Boolean = false): EpubPreferences {
        val l = look
        val page = ReaderThemes.resolve(theme, systemDark)
        return EpubPreferences(
            fontSize = fontSize,
            theme = when (page) {
                1 -> Theme.SEPIA
                2, 4, 5 -> Theme.DARK
                else -> Theme.LIGHT
            },
            // Sage, Slate and Dark are Readium's light or dark theme with their own paper and ink colours.
            backgroundColor = when (page) {
                3 -> ReadiumColor(0xFFD6E3D3.toInt())
                4 -> ReadiumColor(0xFF4A4F57.toInt())
                5 -> ReadiumColor(0xFF1C1C1C.toInt())
                else -> null
            },
            textColor = when (page) {
                3 -> ReadiumColor(0xFF22332A.toInt())
                4 -> ReadiumColor(0xFFECEFF3.toInt())
                5 -> ReadiumColor(0xFFE8E8E8.toInt())
                else -> null
            },
            // 100% is Readest's side margin: 2.5% of the width plus 8 dp (about 18 dp on a phone) against Readium's own 20 dp.
            pageMargins = l.margins * READEST_SIDE,
            publisherStyles = if (l.custom) false else null,
            fontFamily = if (l.custom && l.fontName.isNotBlank()) {
                FontFamily(l.fontName)
            } else if (l.custom) {
                when (l.fontFamily) {
                    1 -> FontFamily.SANS_SERIF
                    2 -> FontFamily.MONOSPACE
                    else -> FontFamily.SERIF
                }
            } else null,
            lineHeight = if (l.custom) l.lineSpacing.toDouble() else null,
            textAlign = if (l.custom) (if (l.justify) TextAlign.JUSTIFY else TextAlign.START) else null,
            paragraphSpacing = if (l.custom) l.paragraphSpacing.toDouble() else null,
            paragraphIndent = if (l.custom) l.indent.toDouble() else null,
            hyphens = if (l.custom) l.hyphens else null,
            ligatures = if (l.custom && !l.ligatures) false else null,
            // Only sent when changed from normal, so the default look is exactly what it was.
            fontWeight = if (l.custom && l.fontWeight != 1f) l.fontWeight.toDouble() else null,
            letterSpacing = if (l.custom && l.letterSpacing > 0f) l.letterSpacing.toDouble() else null,
            wordSpacing = if (l.custom && l.wordSpacing > 0f) l.wordSpacing.toDouble() else null,
            columnCount = when (l.columns) { 1 -> ColumnCount.ONE; 2 -> ColumnCount.TWO; else -> null },
            scroll = if (l.scrolled) true else null,
            imageFilter = if (l.invertImages && page in intArrayOf(2, 4, 5)) ImageFilter.INVERT else null,
            readingProgression = when (l.direction) { 1 -> ReadingProgression.LTR; 2 -> ReadingProgression.RTL; else -> null },
            verticalText = if (l.verticalText) true else null,
        )
    }
}

/** Readest's side margin (about 18.3 dp on a 411 dp wide phone) divided by Readium's default page margin of 20 dp. */
private const val READEST_SIDE = 0.915
