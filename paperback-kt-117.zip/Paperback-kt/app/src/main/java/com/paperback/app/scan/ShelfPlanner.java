package com.paperback.app.scan;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Decides which shelf (collection) a new book goes on: a comic goes on Comics; otherwise its genre
 * (Fantasy, Classics...) when the book names one; otherwise its series when the scan found several of it;
 * otherwise a folder that has a name of its own. A book none of that applies to has no shelf yet.
 */
public final class ShelfPlanner {
    private ShelfPlanner() {}

    private static final String[][] GENRES = {
        {"Comics", "graphic novel", "comic", "manga"},
        {"Fantasy", "fantasy"},
        {"Science fiction", "science fiction", "sci-fi", "scifi"},
        {"Mystery and thriller", "mystery", "detective", "crime", "thriller", "suspense"},
        {"Horror", "horror", "vampire", "ghost stor"},
        {"Romance", "romance", "love stor"},
        {"Classics", "classic", "literature"},
        {"Biographies", "biograph", "memoir"},
        {"History", "history", "historical"},
        {"Philosophy", "philosoph"},
        {"Poetry", "poetry", "poems"},
        {"Children", "children", "juvenile", "young adult"},
        {"Reference", "reference", "dictionar", "encyclopedi", "handbook", "manual", "textbook", "computers", "programming"},
        {"Non-fiction", "non-fiction", "nonfiction", "science", "psychology", "self-help", "business", "economics", "politic", "religion", "cooking", "health", "technology"},
        {"Fiction", "fiction", "novel", "stories"},
    };

    /** Folder names that say where a file was saved, not what it is about. */
    private static final String[] GENERIC = {
        "download", "downloads", "books", "book", "ebooks", "ebook", "e-books", "documents", "document", "docs", "files", "library",
        "my books", "telegram", "telegram documents", "whatsapp documents", "bluetooth", "sdcard", "storage", "phone", "new folder", "misc", "other", "temp",
    };

    /** What a book is told apart by when the shelf is chosen. */
    public static final class Input {
        public final ScanKind kind;
        public final List<String> genres;
        public final String series;
        public final String folder;

        public Input(ScanKind kind, List<String> genres, String series, String folder) {
            this.kind = kind;
            this.genres = genres;
            this.series = series == null ? "" : series;
            this.folder = folder == null ? "" : folder;
        }
    }

    /** The shelf for one book, or null when there is nothing to go by. [seriesCounts]: how many books of each series the scan has. */
    public static String shelfFor(Input in, Map<String, Integer> seriesCounts) {
        if (in.kind == ScanKind.CBZ) return "Comics";
        String g = genreShelf(in.genres);
        if (g != null) return g;
        if (!in.series.isEmpty()) {
            Integer n = seriesCounts.get(in.series.toLowerCase(Locale.ROOT));
            if (n != null && n >= 2) return in.series;
        }
        return folderShelf(in.folder);
    }

    static String genreShelf(List<String> genres) {
        for (String raw : genres) {
            String tag = raw.toLowerCase(Locale.ROOT);
            for (String[] row : GENRES) {
                for (int i = 1; i < row.length; i++) {
                    if (tag.contains(row[i])) return row[0];
                }
            }
        }
        return null;
    }

    /** The deepest folder on the path that is named for something: "Downloads/Books/Fantasy" is "Fantasy". */
    static String folderShelf(String folder) {
        if (folder.isEmpty()) return null;
        String[] parts = folder.split("/");
        for (int i = parts.length - 1; i >= 0; i--) {
            String p = parts[i].trim();
            if (p.isEmpty() || isGeneric(p)) continue;
            return p;
        }
        return null;
    }

    private static boolean isGeneric(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String g : GENERIC) if (g.equals(n)) return true;
        return false;
    }

    public static Map<String, Integer> countSeries(List<Found> books) {
        Map<String, Integer> out = new HashMap<String, Integer>();
        for (Found f : books) {
            if (f.series.isEmpty()) continue;
            String k = f.series.toLowerCase(Locale.ROOT);
            Integer n = out.get(k);
            out.put(k, n == null ? 1 : n + 1);
        }
        return out;
    }
}
