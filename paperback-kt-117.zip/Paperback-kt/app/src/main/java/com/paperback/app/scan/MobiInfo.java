package com.paperback.app.scan;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/** Title, author and subjects from the header of a MOBI / AZW3, and whether it is copy protected. Reads only the first record. */
final class MobiInfo {
    private MobiInfo() {}

    private static final Charset LATIN1 = Charset.forName("ISO-8859-1");

    static void read(ScanFs fs, Found f) {
        try {
            InputStream in = fs.open(f.ref);
            try {
                // the PalmDB header (78 bytes) and the first two entries of its records table
                byte[] head = Xmlish.read(in, 78 + 16);
                if (head.length < 78 + 16 || !tag(head)) {
                    f.problem = "This Kindle file is in a format Paperback can't open";
                    return;
                }
                if (u16(head, 76) < 2) return;
                int start = u32(head, 78);
                int end = u32(head, 78 + 8);
                if (start < head.length || end <= start || end - start > 1024 * 1024) return;
                if (!skipFully(in, start - head.length)) return;
                byte[] rec0 = Xmlish.read(in, end - start);
                if (rec0.length < 32) return;
                parse(rec0, rec0.length, f);
            } finally {
                in.close();
            }
        } catch (IOException e) {
            // unreadable now: the title comes from the file name
        }
    }

    private static boolean skipFully(InputStream in, long n) throws IOException {
        while (n > 0) {
            long s = in.skip(n);
            if (s <= 0) {
                if (in.read() < 0) return false;
                s = 1;
            }
            n -= s;
        }
        return true;
    }

    /** "BOOKMOBI" or "TEXtREAd" at byte 60 of the PalmDB header. */
    private static boolean tag(byte[] h) {
        String tc = new String(h, 60, 8, LATIN1);
        return tc.equals("BOOKMOBI") || tc.equals("TEXtREAd");
    }

    static void parse(byte[] r, int len, Found f) {
        if (u16(r, 12) != 0) {
            f.problem = "Copy protected (DRM)";
        }
        boolean hasMobi = len >= 20 && r[16] == 'M' && r[17] == 'O' && r[18] == 'B' && r[19] == 'I';
        if (!hasMobi) return; // a PalmDOC: no details inside
        int headerLen = u32(r, 20);
        int codepage = u32(r, 28);
        int fullNameOff = u32(r, 84);
        int fullNameLen = u32(r, 88);
        int exthFlags = u32(r, 128);
        Charset cs;
        try {
            cs = codepage == 65001 ? Charset.forName("UTF-8") : Charset.forName("windows-" + codepage);
        } catch (RuntimeException e) {
            cs = Charset.forName("windows-1252");
        }
        String title = "";
        String author = "";
        List<String> subjects = new ArrayList<String>();
        String lang = "";
        if ((exthFlags & 0x40) != 0) {
            int at = 16 + headerLen;
            if (at + 12 <= len && r[at] == 'E' && r[at + 1] == 'X' && r[at + 2] == 'T' && r[at + 3] == 'H') {
                int count = u32(r, at + 8);
                int p = at + 12;
                for (int i = 0; i < count && p + 8 <= len; i++) {
                    int type = u32(r, p);
                    int rl = u32(r, p + 4);
                    if (rl < 8 || p + rl > len) break;
                    String s = new String(r, p + 8, rl - 8, cs).replaceAll("\\s+", " ").trim();
                    if (type == 503 && title.isEmpty()) title = s;
                    else if (type == 100 && author.isEmpty()) author = fixName(s);
                    else if (type == 105) for (String x : s.split("[;/]")) {
                        String t = x.trim();
                        if (!t.isEmpty() && subjects.size() < 12) subjects.add(t);
                    } else if (type == 524 && lang.isEmpty()) lang = s;
                    p += rl;
                }
            }
        }
        if (title.isEmpty() && fullNameOff > 0 && fullNameLen > 0 && fullNameOff + fullNameLen <= len) {
            title = new String(r, fullNameOff, fullNameLen, cs).replaceAll("\\s+", " ").trim();
        }
        if (!title.isEmpty()) f.title = title;
        if (!author.isEmpty()) f.author = author;
        f.subjects.addAll(subjects);
        if (!lang.isEmpty()) f.language = lang;
    }

    /** "Herbert, Frank" is "Frank Herbert". */
    private static String fixName(String s) {
        String[] parts = s.split(",");
        if (parts.length == 2 && parts[0].trim().indexOf(' ') < 0) return parts[1].trim() + " " + parts[0].trim();
        return s;
    }

    private static int u16(byte[] b, int o) {
        if (o + 2 > b.length) return 0;
        return ((b[o] & 0xFF) << 8) | (b[o + 1] & 0xFF);
    }

    private static int u32(byte[] b, int o) {
        if (o + 4 > b.length) return 0;
        return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }
}
