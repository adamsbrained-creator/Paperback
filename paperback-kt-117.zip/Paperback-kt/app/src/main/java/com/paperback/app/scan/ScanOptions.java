package com.paperback.app.scan;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

/** What a scan looks for: which kinds, how small a file may be, and which scanned places are switched off. */
public final class ScanOptions {
    public final Set<ScanKind> kinds;
    public final long minBytes;
    /** [Root.key] of the places to leave out. */
    public final Set<String> excluded;

    public ScanOptions(Set<ScanKind> kinds, long minBytes, Set<String> excluded) {
        this.kinds = kinds;
        this.minBytes = minBytes;
        this.excluded = excluded;
    }

    public static ScanOptions defaults() {
        EnumSet<ScanKind> on = EnumSet.noneOf(ScanKind.class);
        for (ScanKind k : ScanKind.chips()) if (k.defaultOn()) on.add(k);
        return new ScanOptions(on, 50L * 1024, new HashSet<String>());
    }

    /** Whether a file of [kind] is looked for. Files Paperback can't open are always reported, so they are never a surprise later. */
    public boolean wants(ScanKind kind) {
        return kind == ScanKind.BLOCKED || kinds.contains(kind);
    }
}
