package com.paperback.app.scan;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Walks folders and reports the book files in them. The progress is an estimate that never goes backwards: a folder
 * hands equal shares of its own share to its files and each of its sub-folders, so it reaches 100% exactly when the
 * last folder is done, without a first pass to count anything.
 */
public final class ScanWalker {
    /** A place to scan: the top folder, a short [key] to switch it off by, and a [name] to show. */
    public static final class Root {
        public final String ref;
        public final String key;
        public final String name;
        /** True for the phone's own storage, where Android's app data and the media folders are skipped. */
        public final boolean storageRoot;
        /** True to look at the files directly in this folder only, not the folders inside it. */
        public final boolean shallow;

        public Root(String ref, String key, String name, boolean storageRoot) {
            this(ref, key, name, storageRoot, false);
        }

        public Root(String ref, String key, String name, boolean storageRoot, boolean shallow) {
            this.ref = ref;
            this.key = key;
            this.name = name;
            this.storageRoot = storageRoot;
            this.shallow = shallow;
        }
    }

    public interface Listener {
        /** Called for each file that is a book. Reading its details is up to the listener. */
        void onBook(Found book);

        /** Called when the walker enters a folder: [path] to show and the progress so far, 0..1. */
        void onFolder(String path, double progress, long filesChecked);

        /** True when the scan should stop. A paused scan waits inside this call until it is resumed or stopped. */
        boolean stop();
    }

    private static final int MAX_DEPTH = 40;

    private final ScanFs fs;
    private final ScanOptions options;
    private final Listener listener;
    private double done = 0.0;
    private long checked = 0L;

    public ScanWalker(ScanFs fs, ScanOptions options, Listener listener) {
        this.fs = fs;
        this.options = options;
        this.listener = listener;
    }

    public long filesChecked() {
        return checked;
    }

    /** Scans every root in turn. Returns false when it was stopped before the end. */
    public boolean walk(List<Root> roots) {
        done = 0.0;
        checked = 0L;
        if (roots.isEmpty()) return true;
        double share = 1.0 / roots.size();
        for (Root r : roots) {
            if (listener.stop()) return false;
            if (options.excluded.contains(r.key)) {
                done += share;
                continue;
            }
            if (!dir(r, r.ref, "", share, r.shallow ? MAX_DEPTH : 0)) return false;
        }
        listener.onFolder("", 1.0, checked);
        return true;
    }

    private boolean dir(Root root, String ref, String rel, double share, int depth) {
        if (listener.stop()) return false;
        listener.onFolder(rel.isEmpty() ? root.name : root.name + "/" + rel, Math.min(done, 1.0), checked);
        List<ScanEntry> kids = fs.list(ref);
        List<ScanEntry> subdirs = new ArrayList<ScanEntry>();
        for (ScanEntry e : kids) {
            if (e.isDir) {
                if (depth < MAX_DEPTH && !skipDir(e.name, root.storageRoot && depth == 0)) subdirs.add(e);
            } else {
                checked++;
                ScanKind kind = ScanKind.fromName(e.name);
                if (kind == null || !options.wants(kind) || e.size < options.minBytes) continue;
                listener.onBook(new Found(e.ref, e.name, rel, root.key, e.size, e.modified, kind));
            }
        }
        double unit = share / (subdirs.size() + 1);
        done += unit; // this folder's own files
        for (ScanEntry sub : subdirs) {
            String next = rel.isEmpty() ? sub.name : rel + "/" + sub.name;
            if (!dir(root, sub.ref, next, unit, depth + 1)) return false;
        }
        return true;
    }

    /** Folders that never hold books you would want: hidden ones, caches, and (at the top of the phone) app data and media. */
    public static boolean skipDir(String name, boolean top) {
        if (name.startsWith(".")) return true;
        String n = name.toLowerCase(Locale.ROOT);
        if (n.equals("cache") || n.equals("caches") || n.equals("thumbnails") || n.equals("__macosx") || n.equals("node_modules") || n.equals("lost+found")) return true;
        if (!top) return false;
        switch (n) {
            case "android": case "dcim": case "pictures": case "movies": case "music": case "alarms":
            case "ringtones": case "notifications": case "podcasts": case "lost.dir":
                return true;
            default:
                return false;
        }
    }
}
