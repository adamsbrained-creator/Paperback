package com.paperback.app.scan;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/** Title, author, series and subjects from inside an EPUB, and whether it is copy protected. Reads only the small files. */
final class EpubInfo {
    private EpubInfo() {}

    private static final int SMALL = 2 * 1024 * 1024;

    static void read(ScanFs fs, Found f) {
        try {
            java.io.File file = fs.file(f.ref);
            if (file != null) {
                ZipFile zip = new ZipFile(file);
                try {
                    fromZipFile(zip, f);
                } finally {
                    zip.close();
                }
            } else {
                InputStream in = fs.open(f.ref);
                try {
                    fromStream(in, f);
                } finally {
                    in.close();
                }
            }
        } catch (java.util.zip.ZipException e) {
            f.problem = "This EPUB is damaged and can't be opened";
        } catch (IOException e) {
            // unreadable right now (a file picker hiccup): keep it as a book, the title comes from its name
        }
    }

    private static void fromZipFile(ZipFile zip, Found f) throws IOException {
        ZipEntry enc = zip.getEntry("META-INF/encryption.xml");
        boolean rights = zip.getEntry("META-INF/rights.xml") != null;
        String encXml = enc == null ? "" : new String(Xmlish.read(zip.getInputStream(enc), SMALL), "UTF-8");
        if (isProtected(encXml, rights)) f.problem = "Copy protected (DRM)";
        ZipEntry container = zip.getEntry("META-INF/container.xml");
        if (container == null) {
            f.problem = f.problem != null ? f.problem : "This EPUB has no content list and can't be opened";
            return;
        }
        String path = opfPath(new String(Xmlish.read(zip.getInputStream(container), SMALL), "UTF-8"));
        ZipEntry opf = path.isEmpty() ? null : zip.getEntry(path);
        if (opf == null) return;
        fromOpf(new String(Xmlish.read(zip.getInputStream(opf), SMALL), "UTF-8"), f);
    }

    /** One pass through the zip, for a book that is only available as a stream. Stops as soon as it has what it needs. */
    private static void fromStream(InputStream raw, Found f) throws IOException {
        ZipInputStream zin = new ZipInputStream(raw);
        Map<String, String> opfs = new HashMap<String, String>();
        String containerXml = null;
        String encXml = "";
        boolean rights = false;
        ZipEntry e;
        int seen = 0;
        while ((e = zin.getNextEntry()) != null && seen++ < 20000) {
            String n = e.getName();
            if (n.equals("META-INF/container.xml")) containerXml = new String(Xmlish.read(zin, SMALL), "UTF-8");
            else if (n.equals("META-INF/encryption.xml")) encXml = new String(Xmlish.read(zin, SMALL), "UTF-8");
            else if (n.equals("META-INF/rights.xml")) rights = true;
            else if (n.toLowerCase(java.util.Locale.ROOT).endsWith(".opf")) opfs.put(n, new String(Xmlish.read(zin, SMALL), "UTF-8"));
            if (containerXml != null && opfs.containsKey(opfPath(containerXml))) break;
        }
        if (isProtected(encXml, rights)) f.problem = "Copy protected (DRM)";
        if (containerXml == null) {
            f.problem = f.problem != null ? f.problem : "This EPUB has no content list and can't be opened";
            return;
        }
        String want = opfPath(containerXml);
        String opf = opfs.get(want);
        if (opf == null && opfs.size() == 1) opf = opfs.values().iterator().next();
        if (opf != null) fromOpf(opf, f);
    }

    static String opfPath(String containerXml) {
        Matcher m = Pattern.compile("full-path\\s*=\\s*[\"']([^\"']+)[\"']").matcher(containerXml);
        return m.find() ? Xmlish.unescape(m.group(1)) : "";
    }

    /**
     * Fonts are often scrambled on purpose (that is not copy protection); anything else listed in encryption.xml, or a
     * rights.xml, is Adobe or Kobo DRM.
     */
    static boolean isProtected(String encryptionXml, boolean hasRights) {
        if (hasRights) return true;
        if (encryptionXml.isEmpty()) return false;
        Matcher m = Pattern.compile("Algorithm\\s*=\\s*[\"']([^\"']+)[\"']").matcher(encryptionXml);
        while (m.find()) {
            String a = m.group(1);
            if (!a.equals("http://www.idpf.org/2008/embedding") && !a.equals("http://ns.adobe.com/pdf/enc#RC")) return true;
        }
        return false;
    }

    static void fromOpf(String opf, Found f) {
        String title = Xmlish.first(opf, "title");
        if (!title.isEmpty()) f.title = title;
        List<String> authors = Xmlish.all(opf, "creator");
        if (!authors.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < authors.size() && i < 3; i++) {
                if (i > 0) sb.append(", ");
                sb.append(authors.get(i));
            }
            f.author = sb.toString();
        }
        for (String s : Xmlish.all(opf, "subject")) {
            if (f.subjects.size() < 12) f.subjects.add(s);
        }
        String lang = Xmlish.first(opf, "language");
        if (!lang.isEmpty()) f.language = lang;

        // series: Calibre writes <meta name="calibre:series" content="..."/>; EPUB 3 uses belongs-to-collection
        Matcher mm = Pattern.compile("<meta\\b[^>]*>", Pattern.CASE_INSENSITIVE).matcher(opf);
        while (mm.find()) {
            String tag = mm.group();
            String name = Xmlish.attr(tag, "name");
            if (name.equals("calibre:series") && f.series.isEmpty()) f.series = Xmlish.attr(tag, "content");
            else if (name.equals("calibre:series_index") && f.seriesNo == 0f) f.seriesNo = number(Xmlish.attr(tag, "content"));
        }
        if (f.series.isEmpty()) {
            Matcher col = Pattern.compile("<meta\\b[^>]*property\\s*=\\s*[\"']belongs-to-collection[\"'][^>]*>(.*?)</meta>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE).matcher(opf);
            if (col.find()) f.series = Xmlish.text(col.group(1));
            Matcher pos = Pattern.compile("<meta\\b[^>]*property\\s*=\\s*[\"']group-position[\"'][^>]*>(.*?)</meta>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE).matcher(opf);
            if (pos.find() && f.seriesNo == 0f) f.seriesNo = number(Xmlish.text(pos.group(1)));
        }
    }

    static float number(String s) {
        try {
            return Float.parseFloat(s.trim());
        } catch (RuntimeException e) {
            return 0f;
        }
    }
}
