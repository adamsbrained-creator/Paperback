package com.paperback.app.scan;

import java.util.Locale;

/**
 * The kinds of book file the scanner looks for. The first ten are the chips on "What to look for"; [BLOCKED] is
 * every kind Paperback knows by name but can't open (CBR, LIT, DjVu...), which is reported under "Can't open".
 * Plain Java with no Android, so it can be tested on a computer.
 */
public enum ScanKind {
    EPUB("EPUB", true, false, "epub"),
    PDF("PDF", true, false, "pdf"),
    MOBI("MOBI", true, true, "mobi", "prc"),
    AZW3("AZW3", true, true, "azw3", "azw", "kf8"),
    FB2("FB2", true, true, "fb2", "fbz"),
    DOCX("DOCX", true, true, "docx"),
    CBZ("CBZ", true, true, "cbz", "cbt"),
    TXT("TXT", true, true, "txt"),
    MARKDOWN("Markdown", false, true, "md", "markdown"),
    HTML("HTML", false, true, "html", "htm", "xhtml"),
    BLOCKED("Other", true, false, "cbr", "cb7", "lit", "lrf", "djvu", "djv", "kfx");

    private final String label;
    private final boolean defaultOn;
    private final boolean converted;
    private final String[] extensions;

    ScanKind(String label, boolean defaultOn, boolean converted, String... extensions) {
        this.label = label;
        this.defaultOn = defaultOn;
        this.converted = converted;
        this.extensions = extensions;
    }

    /** "EPUB", "Markdown": what the chip says. */
    public String label() {
        return label;
    }

    /** Whether the chip starts switched on (Markdown and HTML do not: they are mostly not books). */
    public boolean defaultOn() {
        return defaultOn;
    }

    /** True for the kinds that are turned into an EPUB when they are added. */
    public boolean needsConversion() {
        return converted;
    }

    /** The kinds with a chip, in the order the chips are shown. */
    public static ScanKind[] chips() {
        return new ScanKind[] {EPUB, PDF, MOBI, AZW3, FB2, DOCX, CBZ, TXT, MARKDOWN, HTML};
    }

    /** The kind for a file name, or null when it is not a book file at all. ".fb2.zip" counts as FB2. */
    public static ScanKind fromName(String name) {
        if (name == null) return null;
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".fb2.zip")) return FB2;
        int dot = n.lastIndexOf('.');
        if (dot < 0 || dot == n.length() - 1) return null;
        String ext = n.substring(dot + 1);
        for (ScanKind k : values()) {
            for (String e : k.extensions) if (e.equals(ext)) return k;
        }
        return null;
    }
}
