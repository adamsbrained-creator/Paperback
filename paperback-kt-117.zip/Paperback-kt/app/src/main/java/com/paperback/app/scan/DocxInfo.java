package com.paperback.app.scan;

import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/** Title and author from a Word file's properties (docProps/core.xml), when it has any. */
final class DocxInfo {
    private DocxInfo() {}

    static void read(ScanFs fs, Found f) {
        try {
            String xml = null;
            java.io.File file = fs.file(f.ref);
            if (file != null) {
                ZipFile zip = new ZipFile(file);
                try {
                    ZipEntry e = zip.getEntry("docProps/core.xml");
                    if (e != null) xml = new String(Xmlish.read(zip.getInputStream(e), 256 * 1024), "UTF-8");
                } finally {
                    zip.close();
                }
            } else {
                InputStream in = fs.open(f.ref);
                try {
                    ZipInputStream zin = new ZipInputStream(in);
                    ZipEntry e;
                    int seen = 0;
                    while ((e = zin.getNextEntry()) != null && seen++ < 200) {
                        if (e.getName().equals("docProps/core.xml")) {
                            xml = new String(Xmlish.read(zin, 256 * 1024), "UTF-8");
                            break;
                        }
                    }
                } finally {
                    in.close();
                }
            }
            if (xml == null) return;
            String title = Xmlish.first(xml, "title");
            String author = Xmlish.first(xml, "creator");
            if (!title.isEmpty()) f.title = title;
            if (!author.isEmpty()) f.author = author;
        } catch (IOException e) {
            // unreadable now: the title comes from the file name
        }
    }
}
