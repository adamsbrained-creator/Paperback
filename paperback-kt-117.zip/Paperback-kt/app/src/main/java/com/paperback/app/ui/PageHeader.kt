package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.pbTokens

// Header design: four looks (App style → Header). Numbers are from components/paperback/PageHeader.tsx.
private class HeaderSpec(val btn: Dp, val round: Boolean, val word: TextUnit, val top: Dp, val col: Dp, val wordmark: Boolean = true)

private fun specFor(size: HeaderSize): HeaderSpec = when (size) {
    HeaderSize.Compact -> HeaderSpec(btn = 44.dp, round = false, word = 20.sp, top = 2.dp, col = 44.dp)
    HeaderSize.Regular -> HeaderSpec(btn = 40.dp, round = true, word = 24.sp, top = 6.dp, col = 44.dp)
    HeaderSize.Large -> HeaderSpec(btn = 46.dp, round = true, word = 30.sp, top = 12.dp, col = 46.dp)
    HeaderSize.Minimal -> HeaderSpec(btn = 40.dp, round = true, word = 24.sp, top = 6.dp, col = 44.dp, wordmark = false)
}


/**
 * Menu button · "paperback" · search, then the screen's label (and an optional chip) underneath.
 * Leave [onMenu] and [onSearch] null for a static sample (the App style screen).
 */
@Composable
fun PageHeader(
    label: String,
    size: HeaderSize,
    modifier: Modifier = Modifier,
    chip: String? = null,
    onMenu: (() -> Unit)? = null,
    onSearch: (() -> Unit)? = null,
    /** The scanner screens swap the two buttons: Back or Close on the left, and nothing (null) or an action on the right. */
    leftIcon: PbIconName = PbIconName.Menu,
    leftDescription: String = "Open library menu",
    rightIcon: PbIconName? = PbIconName.Search,
    rightDescription: String = "Search",
) {
    val t = pbTokens()
    val s = specFor(size)
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HeaderButton(leftIcon, leftDescription, s, onMenu)
            Spacer(Modifier.width(4.dp))
            if (!s.wordmark) Spacer(Modifier.weight(1f)) else Text(
                "paperback",
                modifier = Modifier.weight(1f),
                color = t.ink,
                fontSize = s.word,
                fontWeight = FontWeight.Medium,
                letterSpacing = (-0.02).em,
                textAlign = if (size == HeaderSize.Compact) TextAlign.Start else TextAlign.Center,
                maxLines = 1,
            )
            Spacer(Modifier.width(4.dp))
            if (rightIcon != null) HeaderButton(rightIcon, rightDescription, s, onSearch) else Spacer(Modifier.width(s.col))
        }
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 24.dp)
                .padding(start = 10.dp, end = 10.dp, top = s.top),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                label,
                modifier = Modifier.weight(1f),
                color = t.ink,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (chip != null) {
                Row(
                    Modifier
                        .height(36.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(t.card)
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Accent.color))
                    Spacer(Modifier.width(8.dp))
                    Text(chip, color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun HeaderButton(icon: PbIconName, description: String, s: HeaderSpec, onClick: (() -> Unit)?) {
    val t = pbTokens()
    Box(Modifier.width(s.col).height(s.btn), contentAlignment = Alignment.Center) {
        var button = Modifier.size(s.btn)
        // Compact has no circles: just the icon.
        button = if (s.round) button.pbTap(onClick, CircleShape, pressedScale = 0.9f).background(t.card) else button.pbTap(onClick, CircleShape, pressedScale = 0.9f)
        Box(button, contentAlignment = Alignment.Center) {
            PbIcon(icon, size = 22.dp, tint = t.ink, contentDescription = if (onClick != null) description else null)
        }
    }
}

/** The round floating menu button (bottom right) that opens the page list. [close] turns it into the close button. */
@Composable
fun MenuFab(onClick: () -> Unit, modifier: Modifier = Modifier, close: Boolean = false) {
    val t = pbTokens()
    Box(
        modifier
            .size(60.dp)
            .shadow(10.dp, CircleShape)
            .pbTap(onClick, CircleShape, pressedScale = 0.92f)
            .background(t.ink),
        contentAlignment = Alignment.Center,
    ) {
        PbIcon(
            if (close) PbIconName.Close else PbIconName.MenuLines,
            size = 24.dp,
            tint = t.bg,
            strokeWidth = 2f,
            contentDescription = if (close) "Close menu" else "Open menu",
        )
    }
}
