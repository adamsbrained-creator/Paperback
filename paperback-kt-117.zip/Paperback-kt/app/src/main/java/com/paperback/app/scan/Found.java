package com.paperback.app.scan;

import java.util.ArrayList;
import java.util.List;

/** One book file the scan found, with what could be read from it without opening the whole book. */
public final class Found {
    /** What the [ScanFs] needs to open the file again. */
    public final String ref;
    public final String name;
    /** The folder it is in, from the top of the place that was scanned: "Download/Books". Empty at the top. */
    public final String folder;
    /** The scanned place it came from ("Download", or the name of a folder you picked). */
    public final String rootKey;
    public final long size;
    public final long modified;
    public final ScanKind kind;

    public String title = "";
    public String author = "";
    public String series = "";
    public float seriesNo = 0f;
    public final List<String> subjects = new ArrayList<String>();
    public String language = "";
    /** Why the book can't be added ("Copy protected (DRM)"), or null when it can. */
    public String problem = null;

    public Found(String ref, String name, String folder, String rootKey, long size, long modified, ScanKind kind) {
        this.ref = ref;
        this.name = name;
        this.folder = folder;
        this.rootKey = rootKey;
        this.size = size;
        this.modified = modified;
        this.kind = kind;
    }

    /** Names this exact file: the same path, size and date. A file you already handled is recognised by it. */
    public String fileKey() {
        return ref + "|" + size + "|" + modified;
    }

    /** The title to show: what the book says, or what its file is called. */
    public String shownTitle() {
        return title.isEmpty() ? NameGuess.titleOf(name) : title;
    }

    /** How good a copy this is to keep when the same book was found more than once. Higher is better. */
    public int rank() {
        switch (kind) {
            case EPUB: return 100;
            case AZW3: return 90;
            case MOBI: return 80;
            case FB2: return 70;
            case DOCX: return 60;
            case PDF: return 55;
            case TXT: return 40;
            case MARKDOWN: case HTML: return 35;
            case CBZ: return 30;
            default: return 0;
        }
    }
}
