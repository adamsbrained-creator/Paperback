package com.paperback.app.scan

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Everything the book scanner remembers: what to look for and where, how it runs by itself, and what it has already dealt with. */
class ScanStore(context: Context) {
    private val sp = context.getSharedPreferences("paperback_scan", Context.MODE_PRIVATE)
    private val knownFile = File(context.filesDir, "scan_known.txt")

    /** A folder picked on Android's file picker. */
    data class Tree(val uri: String, val name: String)

    /** A place the scan has found books in (or that was switched off). [key] is [ScanWalker.Root.key]. */
    data class Folder(val key: String, val name: String, val count: Int, val enabled: Boolean)

    companion object {
        const val WHEN_APPEAR = 0
        const val WHEN_DAILY = 1
        const val WHEN_MANUAL = 2
        val MIN_KB_CHOICES = listOf(0, 10, 50, 100, 500, 1024)
    }

    // ---- what to look for -----------------------------------------------------------------

    private val _kinds = MutableStateFlow(readKinds())
    val kinds: StateFlow<Set<ScanKind>> = _kinds.asStateFlow()

    private fun readKinds(): Set<ScanKind> {
        val saved = sp.getString("kinds", null) ?: return ScanKind.chips().filter { it.defaultOn() }.toSet()
        return saved.split(',').mapNotNull { n -> ScanKind.chips().firstOrNull { it.name == n } }.toSet()
    }

    fun setKind(kind: ScanKind, on: Boolean) {
        val next = if (on) _kinds.value + kind else _kinds.value - kind
        _kinds.value = next
        sp.edit().putString("kinds", next.joinToString(",") { it.name }).apply()
    }

    // ---- where to look --------------------------------------------------------------------

    private val _wholePhone = MutableStateFlow(sp.getBoolean("wholePhone", true))
    val wholePhone: StateFlow<Boolean> = _wholePhone.asStateFlow()
    fun setWholePhone(value: Boolean) {
        _wholePhone.value = value
        sp.edit().putBoolean("wholePhone", value).apply()
    }

    private val _trees = MutableStateFlow(readTrees())
    val trees: StateFlow<List<Tree>> = _trees.asStateFlow()

    private fun readTrees(): List<Tree> = runCatching {
        val arr = JSONArray(sp.getString("trees", "[]"))
        (0 until arr.length()).map { arr.getJSONObject(it).let { o -> Tree(o.getString("uri"), o.getString("name")) } }
    }.getOrDefault(emptyList())

    fun addTree(tree: Tree) {
        if (_trees.value.any { it.uri == tree.uri }) return
        writeTrees(_trees.value + tree)
    }

    fun removeTree(uri: String) = writeTrees(_trees.value.filter { it.uri != uri })

    private fun writeTrees(list: List<Tree>) {
        _trees.value = list
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name)) }
        sp.edit().putString("trees", arr.toString()).apply()
    }

    private val _folders = MutableStateFlow(readFolders())
    val folders: StateFlow<List<Folder>> = _folders.asStateFlow()

    private fun readFolders(): List<Folder> = runCatching {
        val arr = JSONArray(sp.getString("folders", "[]"))
        (0 until arr.length()).map {
            arr.getJSONObject(it).let { o -> Folder(o.getString("key"), o.getString("name"), o.getInt("count"), o.getBoolean("enabled")) }
        }
    }.getOrDefault(emptyList())

    private fun writeFolders(list: List<Folder>) {
        _folders.value = list
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("key", it.key).put("name", it.name).put("count", it.count).put("enabled", it.enabled)) }
        sp.edit().putString("folders", arr.toString()).apply()
    }

    fun setFolderEnabled(key: String, enabled: Boolean) {
        writeFolders(_folders.value.map { if (it.key == key) it.copy(enabled = enabled) else it })
    }

    /** After a scan: the places that had books, with their counts. Places you switched off stay in the list. */
    fun updateFolders(counts: Map<String, Pair<String, Int>>) {
        val old = _folders.value.associateBy { it.key }
        val keys = LinkedHashSet<String>()
        keys.addAll(old.keys)
        keys.addAll(counts.keys)
        val next = keys.mapNotNull { key ->
            val was = old[key]
            val now = counts[key]
            when {
                now != null -> Folder(key, now.first, now.second, was?.enabled ?: true)
                was != null && !was.enabled -> was // switched off: it was not scanned, so it keeps its last count
                else -> null // nothing found there this time
            }
        }.sortedByDescending { it.count }
        writeFolders(next)
    }

    /** The places that are switched off, for [ScanOptions]. */
    fun excludedKeys(): Set<String> = _folders.value.filter { !it.enabled }.map { it.key }.toSet()

    // ---- how it runs ----------------------------------------------------------------------

    private val _auto = MutableStateFlow(sp.getBoolean("auto", false))
    val auto: StateFlow<Boolean> = _auto.asStateFlow()
    fun setAuto(value: Boolean) {
        _auto.value = value
        sp.edit().putBoolean("auto", value).apply()
    }

    private val _whenMode = MutableStateFlow(sp.getInt("when", WHEN_APPEAR))
    val whenMode: StateFlow<Int> = _whenMode.asStateFlow()
    fun setWhenMode(value: Int) {
        _whenMode.value = value
        sp.edit().putInt("when", value).apply()
    }

    private val _ask = MutableStateFlow(sp.getBoolean("ask", true))
    val ask: StateFlow<Boolean> = _ask.asStateFlow()
    fun setAsk(value: Boolean) {
        _ask.value = value
        sp.edit().putBoolean("ask", value).apply()
    }

    private val _minKb = MutableStateFlow(sp.getInt("minKb", 50))
    val minKb: StateFlow<Int> = _minKb.asStateFlow()
    fun setMinKb(value: Int) {
        _minKb.value = value
        sp.edit().putInt("minKb", value).apply()
    }

    private val _shelves = MutableStateFlow(sp.getBoolean("shelves", true))
    val shelves: StateFlow<Boolean> = _shelves.asStateFlow()
    fun setShelves(value: Boolean) {
        _shelves.value = value
        sp.edit().putBoolean("shelves", value).apply()
    }

    private val _sort = MutableStateFlow(Grouper.By.values().firstOrNull { it.name == sp.getString("sort", null) } ?: Grouper.By.AUTHOR)
    val sort: StateFlow<Grouper.By> = _sort.asStateFlow()
    fun setSort(value: Grouper.By) {
        _sort.value = value
        sp.edit().putString("sort", value.name).apply()
    }

    /** True once the person has seen the "Before you scan" page and pressed Start. */
    var introSeen: Boolean
        get() = sp.getBoolean("intro", false)
        set(value) = sp.edit().putBoolean("intro", value).apply()

    /** When the last scan finished (ms), and how many new books it offered. */
    var lastAt: Long
        get() = sp.getLong("lastAt", 0L)
        set(value) = sp.edit().putLong("lastAt", value).apply()
    var lastNew: Int
        get() = sp.getInt("lastNew", 0)
        set(value) = sp.edit().putInt("lastNew", value).apply()

    private val _lastTick = MutableStateFlow(0)
    /** Changes whenever [lastAt] / [lastNew] are set, so the screens redraw. */
    val lastTick: StateFlow<Int> = _lastTick.asStateFlow()

    fun finished(newBooks: Int) {
        lastAt = System.currentTimeMillis()
        lastNew = newBooks
        _lastTick.value = _lastTick.value + 1
    }

    /** The last automatic scan (ms): a busy phone changes files all the time, so automatic scans keep a gap between them. */
    var lastAutoAt: Long
        get() = sp.getLong("lastAutoAt", 0L)
        set(value) = sp.edit().putLong("lastAutoAt", value).apply()

    // ---- what it has dealt with -----------------------------------------------------------

    private val lock = Any()
    private val resolved: MutableSet<String> by lazy { load("k|") }
    private val notified: MutableSet<String> by lazy { load("s|") }

    private fun load(prefix: String): MutableSet<String> {
        val out = HashSet<String>()
        runCatching {
            if (knownFile.exists()) knownFile.forEachLine { if (it.startsWith(prefix)) out.add(it.substring(prefix.length)) }
        }
        return out
    }

    /** Files already dealt with: the copies left aside when you kept the best of each. They are not offered again. */
    fun isResolved(fileKey: String): Boolean = synchronized(lock) { fileKey in resolved }

    fun markResolved(keys: Collection<String>) = mark(resolved, "k|", keys)

    /** Files an automatic scan has already told you about. */
    fun wasNotified(fileKey: String): Boolean = synchronized(lock) { fileKey in notified }

    fun markNotified(keys: Collection<String>) = mark(notified, "s|", keys)

    private fun mark(set: MutableSet<String>, prefix: String, keys: Collection<String>) {
        synchronized(lock) {
            val fresh = keys.filter { set.add(it) }
            if (fresh.isEmpty()) return
            runCatching { knownFile.appendText(fresh.joinToString("") { "$prefix$it\n" }) }
            // a very long list is cut to the newest part, so the file never grows without end
            if (knownFile.length() > 4_000_000L) {
                runCatching {
                    val lines = knownFile.readLines().takeLast(20_000)
                    knownFile.writeText(lines.joinToString("\n", postfix = "\n"))
                    resolved.clear(); resolved.addAll(lines.filter { it.startsWith("k|") }.map { it.substring(2) })
                    notified.clear(); notified.addAll(lines.filter { it.startsWith("s|") }.map { it.substring(2) })
                }
            }
        }
    }
}
