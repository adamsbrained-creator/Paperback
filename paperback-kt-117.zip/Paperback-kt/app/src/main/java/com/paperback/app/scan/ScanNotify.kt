package com.paperback.app.scan

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.paperback.app.MainActivity
import com.paperback.app.R

/** The notifications of the scanner: progress while it runs (a foreground notification), and what an automatic scan found. */
object ScanNotify {
    const val EXTRA_OPEN = "paperback.scan.open"
    const val PROGRESS_CHANNEL = "scan_progress"
    const val FOUND_CHANNEL = "scan_found"
    private const val FOUND_ID = 7118
    private const val OPEN_REQUEST = 7119

    fun ensureChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(PROGRESS_CHANNEL, "Book scan", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shown while Paperback looks for books or adds them"
                setShowBadge(false)
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(FOUND_CHANNEL, "New books found", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "When an automatic scan finds books that are not in your library yet"
                setShowBadge(false)
            },
        )
    }

    private fun openApp(context: Context): PendingIntent = PendingIntent.getActivity(
        context,
        OPEN_REQUEST,
        Intent(context, MainActivity::class.java)
            .putExtra(EXTRA_OPEN, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    /** The ongoing notification of a running scan or add. */
    fun progress(context: Context, notice: ScanNotice): Notification {
        val b = Notification.Builder(context, PROGRESS_CHANNEL)
            .setSmallIcon(R.drawable.ic_tile_book)
            .setContentTitle("Paperback")
            .setContentText(notice.text.ifEmpty { "Working…" })
            .setContentIntent(openApp(context))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_PROGRESS)
        if (notice.percent >= 0) b.setProgress(100, notice.percent, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun allowed(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun post(context: Context, title: String, text: String) {
        if (!allowed(context)) return
        ensureChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(
            FOUND_ID,
            Notification.Builder(context, FOUND_CHANNEL)
                .setSmallIcon(R.drawable.ic_tile_book)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openApp(context))
                .setAutoCancel(true)
                .build(),
        )
    }

    fun found(context: Context, count: Int) =
        post(context, if (count == 1) "1 new book found" else "$count new books found", "Tap to look through them and add the ones you want.")

    fun added(context: Context, count: Int) =
        post(context, if (count == 1) "Added 1 new book" else "Added $count new books", "Found on your phone and put in your library.")
}
