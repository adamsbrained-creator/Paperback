package com.paperback.app.scan;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Just enough XML reading for book details: the text of a few tags, without a full parser. */
final class Xmlish {
    private Xmlish() {}

    /** The text of every <[tag]> element (the tag may carry a prefix like dc:), tags inside removed and entities decoded. */
    static List<String> all(String xml, String tag) {
        List<String> out = new ArrayList<String>();
        Matcher m = Pattern.compile("<(?:[A-Za-z0-9_]+:)?" + Pattern.quote(tag) + "(?:\\s[^>]*)?>(.*?)</(?:[A-Za-z0-9_]+:)?" + Pattern.quote(tag) + "\\s*>",
            Pattern.DOTALL | Pattern.CASE_INSENSITIVE).matcher(xml);
        while (m.find()) {
            String t = text(m.group(1));
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    static String first(String xml, String tag) {
        List<String> l = all(xml, tag);
        return l.isEmpty() ? "" : l.get(0);
    }

    /** The value of the attribute [name] in the first tag that has it, or "". */
    static String attr(String tagText, String name) {
        Matcher m = Pattern.compile("\\b" + Pattern.quote(name) + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", Pattern.CASE_INSENSITIVE).matcher(tagText);
        if (!m.find()) return "";
        return unescape(m.group(1) != null ? m.group(1) : m.group(2)).trim();
    }

    /** Tags and CDATA wrappers dropped, entities decoded, white space squeezed. */
    static String text(String s) {
        String t = s.replaceAll("(?s)<!\\[CDATA\\[(.*?)\\]\\]>", "$1").replaceAll("(?s)<[^>]*>", " ");
        return unescape(t).replaceAll("\\s+", " ").trim();
    }

    static String unescape(String s) {
        if (s.indexOf('&') < 0) return s;
        Matcher m = Pattern.compile("&(#x[0-9a-fA-F]+|#[0-9]+|amp|lt|gt|quot|apos|nbsp);").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String e = m.group(1);
            String r;
            if (e.startsWith("#x")) r = cp(e.substring(2), 16);
            else if (e.startsWith("#")) r = cp(e.substring(1), 10);
            else if (e.equals("amp")) r = "&";
            else if (e.equals("lt")) r = "<";
            else if (e.equals("gt")) r = ">";
            else if (e.equals("quot")) r = "\"";
            else if (e.equals("apos")) r = "'";
            else r = " ";
            m.appendReplacement(sb, Matcher.quoteReplacement(r));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String cp(String digits, int radix) {
        try {
            int c = Integer.parseInt(digits, radix);
            return Character.isValidCodePoint(c) ? new String(Character.toChars(c)) : "";
        } catch (NumberFormatException e) {
            return "";
        }
    }

    /** At most [limit] bytes of [in]; the rest is not read. */
    static byte[] read(InputStream in, int limit) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(Math.min(limit, 16 * 1024));
        byte[] buf = new byte[16 * 1024];
        int total = 0;
        while (total < limit) {
            int n = in.read(buf, 0, Math.min(buf.length, limit - total));
            if (n < 0) break;
            bo.write(buf, 0, n);
            total += n;
        }
        return bo.toByteArray();
    }

    /** Decodes XML bytes by the encoding in its <?xml ... encoding="..."?> line (FB2 books are often windows-1251). */
    static String decode(byte[] b) {
        Charset cs = Charset.forName("UTF-8");
        String head = new String(b, 0, Math.min(b.length, 200), Charset.forName("ISO-8859-1"));
        Matcher m = Pattern.compile("encoding\\s*=\\s*[\"']([A-Za-z0-9_\\-]+)[\"']").matcher(head);
        if (m.find()) {
            try {
                cs = Charset.forName(m.group(1));
            } catch (RuntimeException ignored) {
                // an encoding this phone does not know: UTF-8 is the best guess
            }
        }
        return new String(b, cs);
    }
}
