package com.paperback.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.data.Backup
import com.paperback.app.data.ThemeMode
import com.paperback.app.reader.PdfReaderActivity
import com.paperback.app.reader.ReaderActivity
import com.paperback.app.ui.LocalShareImage
import com.paperback.app.ui.PaperbackRoot
import com.paperback.app.ui.theme.PaperbackTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val pickBooks =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.importBooks(uris)
        }

    private val saveBackup =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) vm.saveBackup(uri)
        }

    // Stats exports: the text waits here while the person picks where to save the file.
    private var pendingExport: String? = null
    private val saveCsv =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
            val text = pendingExport
            pendingExport = null
            if (uri != null && text != null) vm.writeText(uri, text, "Exported.")
        }
    private val saveJsonExport =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            val text = pendingExport
            pendingExport = null
            if (uri != null && text != null) vm.writeText(uri, text, "Exported.")
        }

    private val pickBackup =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.readBackup(uri)
        }

    // The Edit book page asks for a picture; this remembers which book it is for.
    private var coverFor: com.paperback.app.data.Book? = null
    private val pickCover =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            val book = coverFor
            if (uri != null && book != null) vm.setCover(book, uri) { }
        }

    // ---- the book scanner ----
    // Android 6 to 10 ask for reading the storage in a pop-up; from Android 11 the person flips "All files access" in Settings.
    private val askStorage =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val scanner = (application as PaperbackApp).graph.scanner
            if (granted) scanner.resumed() else scanner.permissionRefused()
        }

    private val pickScanFolder =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                runCatching {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                (application as PaperbackApp).graph.scanner.addTree(uri)
            } else {
                (application as PaperbackApp).graph.scanner.folderRefused()
            }
        }

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun requestAllFiles() {
        if (Build.VERSION.SDK_INT >= 30) {
            val here = Uri.parse("package:$packageName")
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, here)
            runCatching { startActivity(intent) }.onFailure {
                runCatching { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            }
        } else {
            askStorage.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    /** The scan shows a progress notification; Android 13 wants to be asked once. */
    private fun requestNotificationsOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        val sp = getSharedPreferences("paperback_scan", MODE_PRIVATE)
        if (sp.getBoolean("notifAsked", false)) return
        sp.edit().putBoolean("notifAsked", true).apply()
        askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    /** A "new books found" notification opens the scanner's results. */
    private fun handleScannerIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(com.paperback.app.scan.ScanNotify.EXTRA_OPEN, false) == true) {
            intent.removeExtra(com.paperback.app.scan.ScanNotify.EXTRA_OPEN)
            vm.requestScanner()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleScannerIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleScannerIntent(intent)
        enableEdgeToEdge()
        setContent {
            // Settings → Appearance can force light or dark whatever the phone is set to.
            val mode by vm.themeMode.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            val dark = when (mode) {
                ThemeMode.System -> systemDark
                ThemeMode.Light -> false
                ThemeMode.Dark -> true
            }
            // Keep the status and navigation bar icons readable on the chosen theme.
            DisposableEffect(dark) {
                this@MainActivity.enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                )
                onDispose { }
            }
            PaperbackTheme(dark = dark) {
                CompositionLocalProvider(LocalShareImage provides { card -> shareCard(card) }) {
                PaperbackRoot(
                    vm = vm,
                    // "*/*": some file pickers don't label .epub files as application/epub+zip.
                    onPickBooks = { pickBooks.launch(arrayOf("*/*")) },
                    onOpenReader = {
                        // PDFs have their own viewer; the book was prepared by Graph.openReader.
                        val pdf = (application as PaperbackApp).graph.pdfSession != null
                        startActivity(Intent(this, if (pdf) PdfReaderActivity::class.java else ReaderActivity::class.java))
                    },
                    onSaveBackup = { saveBackup.launch(Backup.filename()) },
                    onPickBackup = { pickBackup.launch(arrayOf("*/*")) },
                    onPickCover = { book ->
                        coverFor = book
                        pickCover.launch("image/*")
                    },
                    onExport = { name, mime, text ->
                        pendingExport = text
                        if (mime == "text/csv") saveCsv.launch(name) else saveJsonExport.launch(name)
                    },
                    onRequestAllFiles = { requestAllFiles() },
                    onPickScanFolder = { pickScanFolder.launch(null) },
                    onRequestNotifications = { requestNotificationsOnce() },
                    onShareText = { text ->
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        startActivity(Intent.createChooser(send, "Share notes"))
                    },
                )
                }
            }
        }
    }

    /** Draws the card as a picture in the cache and opens the share sheet with it (and its caption, for apps that take one). */
    private fun shareCard(card: com.paperback.app.data.ShareCard) {
        Thread {
            val file = runCatching {
                val dir = java.io.File(cacheDir, "share").apply { mkdirs() }
                val out = java.io.File(dir, "paperback-card.png")
                val d = java.time.LocalDate.now()
                val bitmap = com.paperback.app.share.ShareImage.render(
                    card, "${d.dayOfMonth} ${com.paperback.app.data.StatNames.MONTHS_SHORT[d.monthValue - 1]} ${d.year}",
                )
                out.outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                bitmap.recycle()
                out
            }.getOrNull()
            runOnUiThread {
                if (file == null) {
                    android.widget.Toast.makeText(this, "Could not make the picture.", android.widget.Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    if (card.caption.isNotBlank()) putExtra(Intent.EXTRA_TEXT, card.caption)
                    clipData = android.content.ClipData.newRawUri("", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "Share picture"))
            }
        }.start()
    }

    override fun onStart() {
        super.onStart()
        vm.refresh() // picks up progress and reading time saved by the reader
    }

    override fun onResume() {
        super.onResume()
        // back from Settings after switching on "All files access": a waiting scan carries on
        (application as PaperbackApp).graph.scanner.resumed()
    }
}
