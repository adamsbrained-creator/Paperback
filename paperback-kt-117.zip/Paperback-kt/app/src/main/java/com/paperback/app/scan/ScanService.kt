package com.paperback.app.scan

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.paperback.app.PaperbackApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Keeps Paperback running while it scans or adds books, so the work goes on after you leave the screen. It shows one
 * notification with the progress, and stops itself when the work is done.
 */
class ScanService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val scanner = (application as PaperbackApp).graph.scanner
        ScanNotify.ensureChannels(this)
        val first = ScanNotify.progress(this, scanner.notice.value)
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(ID, first)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        scope.launch {
            scanner.notice.collect { nm.notify(ID, ScanNotify.progress(this@ScanService, it)) }
        }
        scope.launch {
            scanner.busy.first { !it }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val ID = 7116

        /** Starts the service; a phone that refuses (the app is not in front) just scans without the notification. */
        fun start(context: Context) {
            try {
                context.startForegroundService(Intent(context, ScanService::class.java))
            } catch (e: Exception) {
                // scanning still works while the app is open
            }
        }
    }
}
