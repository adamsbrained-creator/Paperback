package com.paperback.app.scan;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** The phone's own storage, read with ordinary files (needs "All files access" on Android 11 and later). */
public final class FileFs implements ScanFs {
    @Override
    public List<ScanEntry> list(String dirRef) {
        File[] kids = new File(dirRef).listFiles();
        List<ScanEntry> out = new ArrayList<ScanEntry>();
        if (kids == null) return out;
        for (File k : kids) {
            boolean dir = k.isDirectory();
            // a link to a folder could lead back to where we are: never follow one
            if (dir && Files.isSymbolicLink(k.toPath())) continue;
            out.add(new ScanEntry(k.getName(), dir, dir ? 0L : k.length(), k.lastModified(), k.getPath()));
        }
        return out;
    }

    @Override
    public InputStream open(String fileRef) throws IOException {
        return new FileInputStream(fileRef);
    }

    @Override
    public File file(String fileRef) {
        return new File(fileRef);
    }
}
