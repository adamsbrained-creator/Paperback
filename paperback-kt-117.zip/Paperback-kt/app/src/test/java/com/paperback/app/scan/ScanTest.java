package com.paperback.app.scan;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.junit.Test;

public class ScanTest {
    // ---- helpers ----------------------------------------------------------------------------

    private static File tempDir() throws IOException {
        File d = java.nio.file.Files.createTempDirectory("scan").toFile();
        d.deleteOnExit();
        return d;
    }

    private static File write(File dir, String path, byte[] data) throws IOException {
        File f = new File(dir, path);
        f.getParentFile().mkdirs();
        FileOutputStream o = new FileOutputStream(f);
        try {
            o.write(data);
        } finally {
            o.close();
        }
        return f;
    }

    private static byte[] zip(String... namesAndText) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ZipOutputStream z = new ZipOutputStream(bo);
        for (int i = 0; i < namesAndText.length; i += 2) {
            z.putNextEntry(new ZipEntry(namesAndText[i]));
            z.write(namesAndText[i + 1].getBytes("UTF-8"));
            z.closeEntry();
        }
        z.close();
        return bo.toByteArray();
    }

    private static String container(String opf) {
        return "<?xml version=\"1.0\"?><container><rootfiles><rootfile full-path=\"" + opf + "\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>";
    }

    private static byte[] epub(String opfBody, String... extra) throws IOException {
        List<String> all = new ArrayList<String>(Arrays.asList("mimetype", "application/epub+zip", "META-INF/container.xml", container("OEBPS/content.opf"),
            "OEBPS/content.opf", "<package xmlns=\"http://www.idpf.org/2007/opf\"><metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\">" + opfBody + "</metadata></package>",
            "OEBPS/ch1.xhtml", "<html/>"));
        all.addAll(Arrays.asList(extra));
        return zip(all.toArray(new String[0]));
    }

    private static Found found(String name, ScanKind kind, String title, String author, long size) {
        Found f = new Found("/x/" + name, name, "Download", "Download", size, 1L, kind);
        f.title = title;
        f.author = author;
        return f;
    }

    private static byte[] padded(int n) {
        return new byte[n];
    }

    // ---- kinds ------------------------------------------------------------------------------

    @Test
    public void kindsComeFromTheFileName() {
        assertEquals(ScanKind.EPUB, ScanKind.fromName("Dune.EPUB"));
        assertEquals(ScanKind.AZW3, ScanKind.fromName("x.azw"));
        assertEquals(ScanKind.MOBI, ScanKind.fromName("x.prc"));
        assertEquals(ScanKind.FB2, ScanKind.fromName("book.fb2.zip"));
        assertEquals(ScanKind.CBZ, ScanKind.fromName("a.cbz"));
        assertEquals(ScanKind.BLOCKED, ScanKind.fromName("Berserk.cbr"));
        assertNull(ScanKind.fromName("photo.jpg"));
        assertNull(ScanKind.fromName("README"));
        assertNull(ScanKind.fromName("trailing."));
    }

    @Test
    public void markdownAndHtmlStartOff() {
        ScanOptions o = ScanOptions.defaults();
        assertTrue(o.wants(ScanKind.EPUB));
        assertFalse(o.wants(ScanKind.MARKDOWN));
        assertFalse(o.wants(ScanKind.HTML));
        assertTrue(o.wants(ScanKind.BLOCKED));
    }

    // ---- walking ----------------------------------------------------------------------------

    private static class Collect implements ScanWalker.Listener {
        final List<Found> books = new ArrayList<Found>();
        final List<Double> progress = new ArrayList<Double>();
        boolean stopNow = false;

        public void onBook(Found b) {
            books.add(b);
        }

        public void onFolder(String path, double p, long checked) {
            progress.add(p);
        }

        public boolean stop() {
            return stopNow;
        }
    }

    @Test
    public void walkFindsBooksSkipsTheRightFoldersAndReachesOneHundredPercent() throws Exception {
        File root = tempDir();
        write(root, "Download/Dune.epub", padded(70000));
        write(root, "Download/tiny.epub", padded(100));
        write(root, "Download/photo.jpg", padded(70000));
        write(root, "Books/Fantasy/Sanderson/Way.mobi", padded(70000));
        write(root, "Books/old.cbr", padded(70000));
        write(root, "Android/data/com.x/files/hidden.epub", padded(70000));
        write(root, "DCIM/Camera/x.pdf", padded(70000));
        write(root, ".hidden/secret.epub", padded(70000));
        write(root, "Books/cache/junk.epub", padded(70000));
        write(root, "Books/notes.md", padded(70000));
        Collect c = new Collect();
        ScanWalker w = new ScanWalker(new FileFs(), ScanOptions.defaults(), c);
        assertTrue(w.walk(Arrays.asList(new ScanWalker.Root(root.getPath(), "phone", "Phone", true))));
        List<String> names = new ArrayList<String>();
        for (Found f : c.books) names.add(f.name);
        java.util.Collections.sort(names);
        assertEquals(Arrays.asList("Dune.epub", "Way.mobi", "old.cbr"), names);
        double last = -1;
        for (double p : c.progress) {
            assertTrue("progress never goes back", p >= last);
            last = p;
        }
        assertEquals(1.0, c.progress.get(c.progress.size() - 1), 1e-9);
        for (Found f : c.books) if (f.name.equals("Way.mobi")) assertEquals("Books/Fantasy/Sanderson", f.folder);
    }

    @Test
    public void aPickedFolderIsScannedEvenInsideAFolderNamedLikeAMediaFolder() throws Exception {
        File root = tempDir();
        write(root, "Music/Audiobooks/x.epub", padded(70000));
        Collect c = new Collect();
        new ScanWalker(new FileFs(), ScanOptions.defaults(), c).walk(Arrays.asList(new ScanWalker.Root(root.getPath(), "picked", "Picked", false)));
        assertEquals(1, c.books.size());
    }

    @Test
    public void switchedOffPlacesAreSkippedAndStopEndsTheWalk() throws Exception {
        File root = tempDir();
        File a = new File(root, "A");
        File b = new File(root, "B");
        write(a, "one.epub", padded(70000));
        write(b, "two.epub", padded(70000));
        HashSet<String> off = new HashSet<String>(Arrays.asList("A"));
        ScanOptions o = new ScanOptions(EnumSet.of(ScanKind.EPUB), 0, off);
        Collect c = new Collect();
        new ScanWalker(new FileFs(), o, c).walk(Arrays.asList(
            new ScanWalker.Root(a.getPath(), "A", "A", false), new ScanWalker.Root(b.getPath(), "B", "B", false)));
        assertEquals(1, c.books.size());
        assertEquals("two.epub", c.books.get(0).name);

        Collect stopped = new Collect();
        stopped.stopNow = true;
        assertFalse(new ScanWalker(new FileFs(), ScanOptions.defaults(), stopped).walk(Arrays.asList(new ScanWalker.Root(a.getPath(), "A", "A", false))));
    }

    @Test
    public void aLinkBackToAParentFolderIsNotFollowed() throws Exception {
        File root = tempDir();
        write(root, "Books/x.epub", padded(70000));
        try {
            java.nio.file.Files.createSymbolicLink(new File(root, "Books/loop").toPath(), root.toPath());
        } catch (UnsupportedOperationException | IOException e) {
            return; // no links on this machine
        }
        Collect c = new Collect();
        assertTrue(new ScanWalker(new FileFs(), ScanOptions.defaults(), c).walk(Arrays.asList(new ScanWalker.Root(root.getPath(), "r", "R", false))));
        assertEquals(1, c.books.size());
    }

    // ---- reading details --------------------------------------------------------------------

    @Test
    public void epubTitleAuthorSeriesAndSubjects() throws Exception {
        File root = tempDir();
        File f = write(root, "a.epub", epub(
            "<dc:title>The Way of Kings</dc:title><dc:creator opf:role=\"aut\">Brandon Sanderson</dc:creator><dc:subject>Fantasy fiction</dc:subject>"
                + "<dc:language>en</dc:language><meta name=\"calibre:series\" content=\"The Stormlight Archive\"/><meta name=\"calibre:series_index\" content=\"1.0\"/>"));
        Found b = new Found(f.getPath(), "a.epub", "", "r", f.length(), 1, ScanKind.EPUB);
        InfoReader.read(new FileFs(), b);
        assertEquals("The Way of Kings", b.title);
        assertEquals("Brandon Sanderson", b.author);
        assertEquals("The Stormlight Archive", b.series);
        assertEquals(1f, b.seriesNo, 0f);
        assertEquals(Arrays.asList("Fantasy fiction"), b.subjects);
        assertEquals("en", b.language);
        assertNull(b.problem);
    }

    @Test
    public void epub3SeriesAndEntitiesAndManyAuthors() throws Exception {
        File root = tempDir();
        File f = write(root, "a.epub", epub(
            "<dc:title>Tom &amp; Jerry &#8211; Part 1</dc:title><dc:creator>A One</dc:creator><dc:creator>B Two</dc:creator>"
                + "<meta property=\"belongs-to-collection\" id=\"c\">Cat Saga</meta><meta refines=\"#c\" property=\"group-position\">3</meta>"));
        Found b = new Found(f.getPath(), "a.epub", "", "r", f.length(), 1, ScanKind.EPUB);
        InfoReader.read(new FileFs(), b);
        assertEquals("Tom & Jerry – Part 1", b.title);
        assertEquals("A One, B Two", b.author);
        assertEquals("Cat Saga", b.series);
        assertEquals(3f, b.seriesNo, 0f);
    }

    @Test
    public void epubStreamReadingGivesTheSameAnswerAsFileReading() throws Exception {
        File root = tempDir();
        byte[] data = epub("<dc:title>Streamed</dc:title><dc:creator>Some One</dc:creator>");
        File f = write(root, "s.epub", data);
        ScanFs streamOnly = new ScanFs() {
            public List<ScanEntry> list(String d) {
                return new ArrayList<ScanEntry>();
            }

            public java.io.InputStream open(String r) throws IOException {
                return new java.io.FileInputStream(r);
            }

            public File file(String r) {
                return null;
            }
        };
        Found b = new Found(f.getPath(), "s.epub", "", "r", f.length(), 1, ScanKind.EPUB);
        InfoReader.read(streamOnly, b);
        assertEquals("Streamed", b.title);
        assertEquals("Some One", b.author);
    }

    @Test
    public void protectedEpubsAreFlaggedButScrambledFontsAreNot() throws Exception {
        File root = tempDir();
        String adobe = "<encryption><EncryptedData><EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#aes128-cbc\"/></EncryptedData></encryption>";
        String fonts = "<encryption><EncryptedData><EncryptionMethod Algorithm=\"http://www.idpf.org/2008/embedding\"/></EncryptedData></encryption>";
        File drm = write(root, "drm.epub", epub("<dc:title>Locked</dc:title>", "META-INF/encryption.xml", adobe));
        File ok = write(root, "ok.epub", epub("<dc:title>Free</dc:title>", "META-INF/encryption.xml", fonts));
        Found a = new Found(drm.getPath(), "drm.epub", "", "r", 1, 1, ScanKind.EPUB);
        Found b = new Found(ok.getPath(), "ok.epub", "", "r", 1, 1, ScanKind.EPUB);
        InfoReader.read(new FileFs(), a);
        InfoReader.read(new FileFs(), b);
        assertEquals("Copy protected (DRM)", a.problem);
        assertNull(b.problem);
    }

    @Test
    public void aBrokenEpubIsAProblemNotACrash() throws Exception {
        File root = tempDir();
        File f = write(root, "bad.epub", "not a zip at all".getBytes("UTF-8"));
        Found b = new Found(f.getPath(), "bad.epub", "", "r", f.length(), 1, ScanKind.EPUB);
        InfoReader.read(new FileFs(), b);
        assertNotNull(b.problem);
        assertEquals("bad", b.title);
    }

    /** A PalmDB with one header record: the smallest MOBI that has details. */
    private static byte[] mobi(String title, String author, int crypto) throws IOException {
        ByteArrayOutputStream exth = new ByteArrayOutputStream();
        byte[] t = title.getBytes("UTF-8");
        byte[] a = author.getBytes("UTF-8");
        exth.write(new byte[] {'E', 'X', 'T', 'H'});
        int len = 12 + 8 + t.length + 8 + a.length;
        exth.write(be(len));
        exth.write(be(2));
        exth.write(be(503));
        exth.write(be(8 + t.length));
        exth.write(t);
        exth.write(be(100));
        exth.write(be(8 + a.length));
        exth.write(a);
        byte[] r0 = new byte[16 + 232 + exth.size()];
        r0[1] = 2; // compression
        r0[12] = (byte) (crypto >> 8);
        r0[13] = (byte) crypto;
        r0[16] = 'M'; r0[17] = 'O'; r0[18] = 'B'; r0[19] = 'I';
        put32(r0, 20, 232); // header length
        put32(r0, 28, 65001); // UTF-8
        put32(r0, 36, 6);
        put32(r0, 128, 0x40); // has EXTH
        System.arraycopy(exth.toByteArray(), 0, r0, 16 + 232, exth.size());
        int table = 78 + 2 * 8 + 2;
        byte[] file = new byte[table + r0.length + 10];
        byte[] name = "BOOKNAME".getBytes("ISO-8859-1");
        System.arraycopy(name, 0, file, 0, name.length);
        System.arraycopy("BOOKMOBI".getBytes("ISO-8859-1"), 0, file, 60, 8);
        file[76] = 0;
        file[77] = 2;
        put32(file, 78, table);
        put32(file, 78 + 8, table + r0.length);
        System.arraycopy(r0, 0, file, table, r0.length);
        return file;
    }

    private static byte[] be(int v) {
        return new byte[] {(byte) (v >> 24), (byte) (v >> 16), (byte) (v >> 8), (byte) v};
    }

    private static void put32(byte[] b, int o, int v) {
        System.arraycopy(be(v), 0, b, o, 4);
    }

    @Test
    public void mobiDetailsAndProtection() throws Exception {
        File root = tempDir();
        File f = write(root, "d.mobi", mobi("Dune Messiah", "Herbert, Frank", 0));
        Found b = new Found(f.getPath(), "d.mobi", "", "r", f.length(), 1, ScanKind.MOBI);
        InfoReader.read(new FileFs(), b);
        assertEquals("Dune Messiah", b.title);
        assertEquals("Frank Herbert", b.author);
        assertNull(b.problem);

        File g = write(root, "locked.azw", mobi("Locked", "Someone", 2));
        Found l = new Found(g.getPath(), "locked.azw", "", "r", g.length(), 1, ScanKind.AZW3);
        InfoReader.read(new FileFs(), l);
        assertEquals("Copy protected (DRM)", l.problem);
        assertEquals("Locked", l.title);

        File h = write(root, "notmobi.azw3", padded(500));
        Found n = new Found(h.getPath(), "notmobi.azw3", "", "r", 500, 1, ScanKind.AZW3);
        InfoReader.read(new FileFs(), n);
        assertNotNull(n.problem);
    }

    @Test
    public void fb2InWindows1251() throws Exception {
        File root = tempDir();
        String xml = "<?xml version=\"1.0\" encoding=\"windows-1251\"?><FictionBook><description><title-info><genre>prose_classic</genre>"
            + "<author><first-name>Михаил</first-name><last-name>Булгаков</last-name></author>"
            + "<book-title>Мастер и Маргарита</book-title><lang>ru</lang>"
            + "<sequence name=\"Серия\" number=\"2\"/></title-info></description><body/></FictionBook>";
        File f = write(root, "m.fb2", xml.getBytes(Charset.forName("windows-1251")));
        Found b = new Found(f.getPath(), "m.fb2", "", "r", f.length(), 1, ScanKind.FB2);
        InfoReader.read(new FileFs(), b);
        assertEquals("Мастер и Маргарита", b.title);
        assertEquals("Михаил Булгаков", b.author);
        assertEquals("Серия", b.series);
        assertEquals(2f, b.seriesNo, 0f);
        assertEquals(Arrays.asList("Classics"), b.subjects);
        assertEquals("ru", b.language);

        File z = write(root, "m.fb2.zip", zip("m.fb2", "<FictionBook><description><title-info><book-title>Zipped</book-title></title-info></description></FictionBook>"));
        Found zf = new Found(z.getPath(), "m.fb2.zip", "", "r", z.length(), 1, ScanKind.FB2);
        InfoReader.read(new FileFs(), zf);
        assertEquals("Zipped", zf.title);
    }

    @Test
    public void docxProperties() throws Exception {
        File root = tempDir();
        File f = write(root, "n.docx", zip("docProps/core.xml", "<cp:coreProperties xmlns:dc=\"x\"><dc:title>My Novel</dc:title><dc:creator>Me Myself</dc:creator></cp:coreProperties>"));
        Found b = new Found(f.getPath(), "n.docx", "", "r", f.length(), 1, ScanKind.DOCX);
        InfoReader.read(new FileFs(), b);
        assertEquals("My Novel", b.title);
        assertEquals("Me Myself", b.author);
    }

    @Test
    public void blockedKindsExplainThemselves() {
        Found b = new Found("/x/Berserk vol 3.cbr", "Berserk vol 3.cbr", "", "r", 9, 1, ScanKind.BLOCKED);
        InfoReader.read(new FileFs(), b);
        assertTrue(b.problem.contains("CBZ"));
        Found l = new Found("/x/old-novel.lit", "old-novel.lit", "", "r", 9, 1, ScanKind.BLOCKED);
        InfoReader.read(new FileFs(), l);
        assertTrue(l.problem.contains("LIT"));
    }

    @Test
    public void fileNamesGiveTitleAndAuthor() {
        Found a = new Found("/x/Frank Herbert - Dune (z-lib.org).epub", "Frank Herbert - Dune (z-lib.org).epub", "", "r", 1, 1, ScanKind.PDF);
        InfoReader.read(new FileFs(), a);
        assertEquals("Dune", a.title);
        assertEquals("Frank Herbert", a.author);
        Found b = new Found("/x/my_book-v2.pdf", "my_book-v2.pdf", "", "r", 1, 1, ScanKind.PDF);
        InfoReader.read(new FileFs(), b);
        assertEquals("my book-v2", b.title);
        assertEquals("", b.author);
        Found c = new Found("/x/Dune - Part 2.pdf", "Dune - Part 2.pdf", "", "r", 1, 1, ScanKind.PDF);
        InfoReader.read(new FileFs(), c);
        assertEquals("Dune - Part 2", c.title); // one word before the dash is not an author
        assertEquals("", c.author);
    }

    // ---- matching and duplicates ------------------------------------------------------------

    @Test
    public void keysWorkForAnyAlphabet() {
        assertTrue(ScanKey.sameBook("The Hobbit (z-lib.org)", "J. R. R. Tolkien", "the hobbit", "Tolkien, J. R. R."));
        assertTrue(ScanKey.sameBook("Мастер и Маргарита", "", "мастер и маргарита", "Булгаков"));
        assertFalse(ScanKey.sameBook("Dune", "Frank Herbert", "Dune: Messiah", "Frank Herbert"));
        assertFalse(ScanKey.sameBook("Dune", "Frank Herbert", "Dune", "Brian Herbert's Cousin Smith"));
        assertFalse(ScanKey.sameBook("A", "", "A", ""));
        assertEquals("herbert", ScanKey.author("Herbert, Frank"));
        assertEquals("herbert", ScanKey.author("Frank Herbert; Brian Herbert"));
        assertEquals("herbert", ScanKey.author("Frank Herbert and Brian Herbert"));
    }

    @Test
    public void duplicatesKeepTheBestCopy() {
        Found epub = found("Dune.epub", ScanKind.EPUB, "Dune", "Frank Herbert", 1_400_000);
        Found mobi = found("dune.mobi", ScanKind.MOBI, "Dune", "Frank Herbert", 1_600_000);
        Found other = found("Emma.epub", ScanKind.EPUB, "Emma", "Jane Austen", 500_000);
        Found drm = found("Locked.azw", ScanKind.AZW3, "Locked", "X", 500_000);
        drm.problem = "Copy protected (DRM)";
        Dedup.Result r = Dedup.run(Arrays.asList(mobi, other, epub, drm), new ArrayList<Dedup.Owned>());
        assertEquals(1, r.single.size());
        assertEquals(1, r.copies.size());
        assertEquals(1, r.problems.size());
        assertEquals(1, r.duplicateCount());
        assertSame(epub, r.copies.get(0).copies.get(0));
        List<Found> add = r.toAdd();
        assertEquals(2, add.size());
        assertTrue(add.contains(epub) && add.contains(other));
        // choosing the other copy
        r.copies.get(0).keep = 1;
        assertTrue(r.toAdd().contains(mobi));
        r.copies.get(0).keepBest();
        assertTrue(r.toAdd().contains(epub));
    }

    private static void assertSame(Object a, Object b) {
        org.junit.Assert.assertSame(a, b);
    }

    @Test
    public void aBookYouOwnIsNotOfferedAgain() {
        Found dune = found("Dune.epub", ScanKind.EPUB, "Dune", "Frank Herbert", 1_400_000);
        Found messiah = found("Messiah.epub", ScanKind.EPUB, "Dune Messiah", "Frank Herbert", 1_400_000);
        List<Dedup.Owned> mine = Arrays.asList(new Dedup.Owned("Dune", "Frank Herbert"));
        Dedup.Result r = Dedup.run(Arrays.asList(dune, messiah), mine);
        assertEquals(Arrays.asList(messiah), r.single);
        assertEquals(1, r.copies.size());
        assertTrue(r.copies.get(0).owned);
        assertEquals(1, r.duplicateCount());
        assertEquals(1, r.toAdd().size());
        // the person can still choose the file over the one in the library
        r.copies.get(0).keep = 0;
        assertEquals(2, r.toAdd().size());
        assertEquals(0, r.duplicateCount());
    }

    @Test
    public void sameTitleByDifferentAuthorsAreTwoBooks() {
        Found a = found("a.epub", ScanKind.EPUB, "Home", "Toni Morrison", 100000);
        Found b = found("b.epub", ScanKind.EPUB, "Home", "Marilynne Robinson", 100000);
        Dedup.Result r = Dedup.run(Arrays.asList(a, b), new ArrayList<Dedup.Owned>());
        assertEquals(2, r.single.size());
        assertEquals(0, r.copies.size());
    }

    @Test
    public void countsAddUp() {
        List<Found> all = new ArrayList<Found>();
        for (int i = 0; i < 20; i++) all.add(found("b" + i + ".epub", ScanKind.EPUB, "Book " + i, "Author " + (i % 3), 100000));
        all.add(found("b3.mobi", ScanKind.MOBI, "Book 3", "Author 0", 100000));
        Found bad = found("x.cbr", ScanKind.BLOCKED, "x", "", 1);
        bad.problem = "no";
        all.add(bad);
        Dedup.Result r = Dedup.run(all, new ArrayList<Dedup.Owned>());
        assertEquals(all.size(), r.toAdd().size() + r.duplicateCount() + r.problems.size());
    }

    // ---- grouping and shelves ---------------------------------------------------------------

    @Test
    public void groupingModes() {
        Found a = found("a.epub", ScanKind.EPUB, "Words of Radiance", "Brandon Sanderson", 5_900_000);
        a.series = "Stormlight";
        a.seriesNo = 2;
        Found b = found("b.epub", ScanKind.EPUB, "The Way of Kings", "Brandon Sanderson", 6_200_000);
        b.series = "Stormlight";
        b.seriesNo = 1;
        Found c = found("c.pdf", ScanKind.PDF, "Anon", "", 100_000);
        List<Found> all = Arrays.asList(c, a, b);
        List<Grouper.Group> byAuthor = Grouper.group(all, Grouper.By.AUTHOR);
        assertEquals("Brandon Sanderson", byAuthor.get(0).name);
        assertEquals("Unknown author", byAuthor.get(1).name);
        assertEquals("The Way of Kings", byAuthor.get(0).books.get(0).title); // series order
        assertEquals("Stormlight", Grouper.group(all, Grouper.By.SERIES).get(0).name);
        assertEquals("EPUB", Grouper.group(all, Grouper.By.FORMAT).get(0).name);
        assertEquals("Download", Grouper.group(all, Grouper.By.FOLDER).get(0).name);
        assertEquals("Stormlight 2 · 5.6 MB", Grouper.detail(a));
        assertEquals("Download · 98 KB", Grouper.detail(c));
        assertEquals("1.9 GB", Grouper.sizeText(2_000_000_000L));
    }

    @Test
    public void shelves() {
        java.util.Map<String, Integer> none = new java.util.HashMap<String, Integer>();
        assertEquals("Comics", ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.CBZ, new ArrayList<String>(), "", ""), none));
        assertEquals("Fantasy", ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.EPUB, Arrays.asList("Epic fantasy", "Fiction"), "", ""), none));
        assertEquals("Classics", ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.EPUB, Arrays.asList("English literature"), "", ""), none));
        assertEquals("Science fiction", ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.EPUB, Arrays.asList("Science fiction"), "", ""), none));
        assertEquals("Fiction", ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.EPUB, Arrays.asList("Fiction"), "", ""), none));
        // a series needs two books in the scan
        java.util.Map<String, Integer> two = new java.util.HashMap<String, Integer>();
        two.put("cat saga", 2);
        assertEquals("Cat Saga", ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.EPUB, new ArrayList<String>(), "Cat Saga", "Download"), two));
        assertEquals("Fantasy", ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.EPUB, new ArrayList<String>(), "Lone Book", "Downloads/Books/Fantasy"), two));
        assertEquals("Sanderson", ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.PDF, new ArrayList<String>(), "", "Download/Books/Sanderson"), none));
        assertNull(ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.PDF, new ArrayList<String>(), "", "Download"), none));
        assertNull(ShelfPlanner.shelfFor(new ShelfPlanner.Input(ScanKind.PDF, new ArrayList<String>(), "", ""), none));
    }
}
