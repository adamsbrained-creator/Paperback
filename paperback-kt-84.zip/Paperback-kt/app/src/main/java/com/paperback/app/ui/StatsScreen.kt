package com.paperback.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.paperback.app.data.Book
import com.paperback.app.data.Goals
import com.paperback.app.data.Highlight
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.StatsFilter
import com.paperback.app.data.filterOptions
import java.time.LocalDate

/** The pages of the Stats tab. Every page of the TypeScript Stats screen is here now. */
private enum class StatsPage(val label: String) {
    Activity("Activity"),
    Goals("Goals"),
    Milestones("Milestones"),
    Books("Books"),
    History("History"),
    Insights("Insights"),
    Habits("Habits"),
    Explore("Explore"),
    Year("Year"),
    Recaps("Recaps"),
}

private const val NO_FOCUS = Long.MIN_VALUE

/**
 * The Stats tab: a row of pages at the top and the chosen page under it.
 * Activity and Milestones link to History for a day ("View sessions", a tier unlocked that day), which opens
 * History on that day. Milestones and Books also open books, notes, shelves and other pages, through the lambdas below.
 */
@Composable
fun StatsScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    goals: Goals,
    highlights: List<Highlight>,
    onOpenBook: (Book) -> Unit,
    onOpenGoals: () -> Unit,
    /** The minutes goal saved for each past day, for the Goals page. */
    loadGoalDays: suspend () -> Map<Long, Int> = { emptyMap() },
    /** Every finished reading of every book, for re-reads on Explore. */
    loadReadings: suspend () -> List<com.paperback.app.data.Reading> = { emptyList() },
    /** The saved card layout (JSON) of the customizable pages, and how to change it. */
    statsLayout: String = "",
    onStatsLayout: (String) -> Unit = {},
    /** Saves a file the person picks (an export): file name, MIME type, text. */
    onExport: (fileName: String, mime: String, text: String) -> Unit = { _, _, _ -> },
    /** Collections, which books are in each, and the Want to read list with the day each was saved (for Explore). */
    collections: List<com.paperback.app.data.BookCollection> = emptyList(),
    membership: Map<String, Set<String>> = emptyMap(),
    wishlist: List<com.paperback.app.catalog.CatalogBook> = emptyList(),
    wishlistAddedAt: (String) -> Long = { 0L },
    /** Shares plain text through the share sheet. */
    onShareText: (String) -> Unit = {},
    /** The notes of one book, or all notes and highlights when null. */
    onOpenNotes: (bookId: String?) -> Unit,
    onOpenFinished: () -> Unit,
    /** A shelf of the books behind a number: "langs", "rated" or "epic". */
    onOpenShelf: (kind: String) -> Unit,
    onOpenDictionary: () -> Unit,
    /** A page of the app: the Library, the books you are reading, the list of authors. */
    onOpenPage: (Dest) -> Unit,
    onOpenAuthor: (name: String) -> Unit,
    /** Pause, drop or resume a book (BookStatus). */
    onSetStatus: (bookId: String, status: Int) -> Unit = { _, _ -> },
    /** Reading rhythm as a calendar of covers (a look option) and the full-screen calendar. */
    rhythmCalendar: Boolean = false,
    goalStyle: com.paperback.app.data.GoalStyle = com.paperback.app.data.GoalStyle.Ring,
    onRhythmCalendar: (Boolean) -> Unit = {},
    onOpenCalendar: () -> Unit = {},
    /** The monthly recaps: which were opened, the reminder, and how to open one. */
    recaps: RecapHost,
    /** Another screen (a recap) asks for History on this day; [onHistoryConsumed] says it was shown. */
    historyRequest: LocalDate? = null,
    onHistoryConsumed: () -> Unit = {},
    /** A page to show, by name (a tile on Home was tapped); [onPageConsumed] says it was shown. */
    pageRequest: String? = null,
    onPageConsumed: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    var page by rememberSaveable { mutableStateOf(StatsPage.Activity.name) }
    var focusDay by rememberSaveable { mutableLongStateOf(NO_FOCUS) }
    // The filter narrows every page to some of your books (genre, format, language, collection).
    var filterText by rememberSaveable { mutableStateOf("") }
    var showFilter by remember { mutableStateOf(false) }
    val filter = remember(filterText) { StatsFilter.parse(filterText) }
    val filterChoices = remember(books, collections) { filterOptions(books, collections) }
    val fBooks = remember(books, filter, membership) { if (filter.isEmpty) books else books.filter { filter.matches(it, membership) } }
    val fIds = remember(fBooks) { fBooks.map { it.id }.toHashSet() }
    val fSessions = remember(sessions, fIds, filter) { if (filter.isEmpty) sessions else sessions.filter { it.bookId in fIds } }
    val fHighlights = remember(highlights, fIds, filter) { if (filter.isEmpty) highlights else highlights.filter { it.bookId in fIds } }

    // finished readings of every book, for the Re-reads milestone (loaded once, again when the books change)
    val milestoneReadings by produceState(emptyList<com.paperback.app.data.Reading>(), books) {
        value = runCatching { loadReadings() }.getOrDefault(emptyList())
    }

    LaunchedEffect(pageRequest) {
        val wanted = pageRequest
        if (wanted != null) {
            if (StatsPage.values().any { it.name == wanted }) {
                page = wanted
                focusDay = NO_FOCUS
            }
            onPageConsumed()
        }
    }

    LaunchedEffect(historyRequest) {
        val day = historyRequest
        if (day != null) {
            focusDay = day.toEpochDay()
            page = StatsPage.History.name
            onHistoryConsumed()
        }
    }

    if (showFilter) {
        StatsFilterDialog(
            options = filterChoices,
            filter = filter,
            shown = fBooks.size,
            total = books.size,
            onChange = { filterText = it.encode() },
            onDismiss = { showFilter = false },
        )
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            StatsTabPill(if (filter.isEmpty) "Filter" else "Filter \u00B7 ${filter.count}", !filter.isEmpty) { showFilter = true }
            StatsPage.values().forEach { p ->
                StatsTabPill(p.label, page == p.name) {
                    page = p.name
                    focusDay = NO_FOCUS
                }
            }
        }
        when (StatsPage.valueOf(page)) {
            StatsPage.Activity -> ActivityScreen(
                books = fBooks,
                sessions = fSessions,
                goals = goals,
                onOpenBook = onOpenBook,
                onOpenGoals = onOpenGoals,
                onViewDay = { day ->
                    focusDay = day.toEpochDay()
                    page = StatsPage.History.name
                },
                calendarLook = rhythmCalendar,
                goalStyle = goalStyle,
                onCalendarLook = onRhythmCalendar,
                onOpenCalendar = onOpenCalendar,
                onShareText = onShareText,
                modifier = Modifier.weight(1f),
            )
            StatsPage.Goals -> GoalsStatsScreen(
                books = fBooks,
                sessions = fSessions,
                goals = goals,
                loadGoalDays = loadGoalDays,
                links = GoalsLinks(
                    history = { day ->
                        focusDay = day.toEpochDay()
                        page = StatsPage.History.name
                    },
                    editGoals = onOpenGoals,
                ),
                modifier = Modifier.weight(1f),
            )
            StatsPage.Milestones -> MilestonesScreen(
                books = fBooks,
                sessions = fSessions,
                highlights = fHighlights,
                readings = milestoneReadings,
                links = MilestoneLinks(
                    book = { id -> books.firstOrNull { it.id == id }?.let(onOpenBook) },
                    notes = onOpenNotes,
                    history = { day ->
                        focusDay = day?.toEpochDay() ?: NO_FOCUS
                        page = StatsPage.History.name
                    },
                    finished = onOpenFinished,
                    shelf = onOpenShelf,
                    dictionary = onOpenDictionary,
                ),
                modifier = Modifier.weight(1f),
            )
            StatsPage.Books -> BooksScreen(
                books = fBooks,
                links = BooksLinks(
                    library = { onOpenPage(Dest.Library) },
                    finished = onOpenFinished,
                    reading = { onOpenPage(Dest.Reading) },
                    book = { id -> books.firstOrNull { it.id == id }?.let(onOpenBook) },
                    shelf = onOpenShelf,
                    author = onOpenAuthor,
                    authors = { onOpenPage(Dest.Authors) },
                ),
                modifier = Modifier.weight(1f),
            )
            StatsPage.History -> HistoryScreen(
                books = fBooks,
                sessions = fSessions,
                focus = if (focusDay == NO_FOCUS) null else LocalDate.ofEpochDay(focusDay),
                onOpenBook = onOpenBook,
                modifier = Modifier.weight(1f),
            )
            StatsPage.Insights -> InsightsScreen(
                books = fBooks,
                sessions = fSessions,
                goals = goals,
                links = InsightsLinks(
                    history = { day ->
                        focusDay = day.toEpochDay()
                        page = StatsPage.History.name
                    },
                    book = { id -> books.firstOrNull { it.id == id }?.let(onOpenBook) },
                    shelf = onOpenShelf,
                ),
                modifier = Modifier.weight(1f),
            )
            StatsPage.Habits -> HabitsScreen(
                books = fBooks,
                sessions = fSessions,
                statsLayout = statsLayout,
                onStatsLayout = onStatsLayout,
                modifier = Modifier.weight(1f),
            )
            StatsPage.Year -> YearScreen(
                books = fBooks,
                sessions = fSessions,
                highlights = fHighlights,
                onOpenBook = onOpenBook,
                onShareText = onShareText,
                statsLayout = statsLayout,
                onStatsLayout = onStatsLayout,
                modifier = Modifier.weight(1f),
            )
            StatsPage.Explore -> ExploreScreen(
                books = fBooks,
                sessions = fSessions,
                goals = goals,
                highlights = fHighlights,
                onOpenBook = onOpenBook,
                onSetStatus = onSetStatus,
                loadReadings = loadReadings,
                statsLayout = statsLayout,
                onStatsLayout = onStatsLayout,
                onExport = onExport,
                collections = collections,
                membership = membership,
                wishlist = wishlist,
                wishlistAddedAt = wishlistAddedAt,
                modifier = Modifier.weight(1f),
            )
            StatsPage.Recaps -> RecapsContent(
                books = fBooks,
                sessions = fSessions,
                host = recaps,
                modifier = Modifier.weight(1f),
            )
        }
    }
}
