'use client';

import clsx from 'clsx';
import { useEffect, useRef } from 'react';
import { commas, shortDate, type Milestone } from '@/services/statistics/milestonesStats';
import { SIcon } from './StatsIcons';
import { MILESTONE_COLOR, ac } from './parts';

/** The tiers of one milestone, as a sheet that rises from the bottom. */
export default function TierSheet({ m, now, onClose }: { m: Milestone; now: Date; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const before = document.activeElement as HTMLElement | null;
    ref.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      before?.focus?.();
    };
  }, [onClose]);

  const name = m.short ?? m.name;
  const left = m.next === null ? 0 : m.next - m.value;

  return (
    <div className={clsx('pbs pbm-scrim', ac(MILESTONE_COLOR[m.id]))} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} className='pbm-sheet' role='dialog' aria-modal='true' aria-labelledby='pbm-sheet-title' tabIndex={-1}>
        <div className='pbm-grab' aria-hidden='true' />
        <div className='pbm-sh-top'>
          <span className='pbm-ic'>
            <SIcon name={m.icon} />
          </span>
          <div>
            <h3 id='pbm-sheet-title'>{name}</h3>
            <div className='pbm-sub'>
              Tier {m.unlocked} of {m.tiers.length} unlocked
            </div>
          </div>
          <button type='button' className='pbm-sh-x' aria-label='Close' onClick={onClose}>
            <SIcon name='x' />
          </button>
        </div>

        <div className='pbm-sh-val'>
          <span>{commas(m.value)}</span>
          <small>{m.next !== null ? `/ ${commas(m.next)} ${m.unit}` : m.unit}</small>
        </div>
        <div className='pbm-sh-bar'>
          <div className='pbm-bar' aria-hidden='true'>
            <i style={{ width: `${m.pct.toFixed(1)}%` }} />
          </div>
          <p>
            {m.next !== null ? (
              <>
                <b>
                  {commas(left)} {m.unit}
                </b>{' '}
                to tier {m.unlocked + 1}
              </>
            ) : (
              'Every tier unlocked'
            )}
          </p>
        </div>

        <ul className='pbm-tiers'>
          {m.tiers.map((t, k) => {
            const state = k < m.unlocked ? 'done' : k === m.unlocked ? 'next' : 'lock';
            const when = m.dates[k];
            const status =
              state === 'done' ? (when ? shortDate(when, now) : 'Unlocked') : state === 'next' ? `${commas(t - m.value)} to go` : 'Locked';
            return (
              <li key={t} className={clsx('pbm-tr', `pbm-${state}`)}>
                <span className='pbm-n'>{state === 'done' ? <SIcon name='check' /> : k + 1}</span>
                <div>
                  <b>
                    {commas(t)} {m.unit}
                  </b>
                  <span className='pbm-d'>Tier {k + 1}</span>
                </div>
                <span className='pbm-st'>{status}</span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
