'use client';

import clsx from 'clsx';
import { useMemo, useState } from 'react';
import {
  buildMilestones,
  buildTimeline,
  commas,
  etaText,
  goalText,
  monthHeading,
  pickNextUp,
  shortDate,
  shortNum,
  tiersUnlocked,
  type MBook,
  type Milestone,
  type MilestoneInput,
  type MNote,
  type TimelineEvent,
  type TimelineKind,
} from '@/services/statistics/milestonesStats';
import type { StatEventRow } from '@/services/statistics/statsAggregate';
import TierSheet from './TierSheet';
import { MILESTONE_COLOR, ac, type Accent } from './parts';

type View = 'progress' | 'timeline';
type Filter = 'all' | TimelineKind;

const FILTERS: { id: Filter; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'book', label: 'Books' },
  { id: 'read', label: 'Reading' },
  { id: 'note', label: 'Notes' },
];

function eventColor(e: TimelineEvent): Accent {
  if (e.icon === 'done') return 'mint';
  if (e.icon === 'plus' || e.icon === 'trophy') return 'yellow';
  if (e.icon === 'stack') return 'blue';
  return e.kind === 'note' ? 'pink' : e.kind === 'read' ? 'blue' : 'mint';
}

const HEX = '32,3 59,18 59,54 32,69 5,54 5,18';

interface Props {
  events: StatEventRow[];
  books: MBook[];
  /** Highlights and notes; null while they are still being read from the books. */
  notes: MNote[] | null;
  savedWords: { word: string; addedAt: number }[];
  ratings: Record<string, number>;
  now: Date;
}

/** Stats → Milestones: lifetime achievements with five tiers each, what is next, and a timeline. */
export default function MilestonesView({ events, books, notes, savedWords, ratings, now }: Props) {
  const [view, setView] = useState<View>('progress');
  const [filter, setFilter] = useState<Filter>('all');
  const [openId, setOpenId] = useState<string | null>(null);

  const input: MilestoneInput = useMemo(
    () => ({ events, books, notes: notes ?? [], savedWords, ratings, now }),
    [events, books, notes, savedWords, ratings, now],
  );
  const list = useMemo(() => buildMilestones(input), [input]);
  const timeline = useMemo(() => buildTimeline(input, list), [input, list]);
  const next = useMemo(() => pickNextUp(list), [list]);
  const { done, total } = tiersUnlocked(list);
  const open = list.find((m) => m.id === openId) ?? null;

  const shown = timeline.filter((e) => filter === 'all' || e.kind === filter);
  // One card per month, newest first (the timeline is already newest first).
  const months: { name: string; events: TimelineEvent[] }[] = [];
  for (const e of shown) {
    const name = monthHeading(e.at, now);
    const last = months[months.length - 1];
    if (last && last.name === name) last.events.push(e);
    else months.push({ name, events: [e] });
  }

  return (
    <div className='pbs-screen pbs-col'>
      {next && <NextUpCard next={next} done={done} total={total} onOpen={() => setOpenId(next.milestone.id)} />}

      <div className='pbs-seg' role='group' aria-label='View'>
        <button type='button' aria-pressed={view === 'progress'} onClick={() => setView('progress')}>
          Progress · {list.length}
        </button>
        <button type='button' aria-pressed={view === 'timeline'} onClick={() => setView('timeline')}>
          Timeline · {timeline.length}
        </button>
      </div>

      {view === 'progress' ? (
        <section className='pbm-view' aria-label='Milestone progress'>
          <div className='pbm-grid'>
            {list.map((m) => (
              <MilestoneCard key={m.id} m={m} onOpen={() => setOpenId(m.id)} />
            ))}
          </div>
        </section>
      ) : (
        <section className='pbm-view' aria-label='Timeline'>
          <div className='pbm-chips' role='group' aria-label='Filter timeline'>
            {FILTERS.map((f) => (
              <button key={f.id} type='button' className='pbm-fc' aria-pressed={filter === f.id} onClick={() => setFilter(f.id)}>
                {f.label}
              </button>
            ))}
          </div>
          {months.length === 0 ? (
            <p className='pbm-empty'>Nothing here yet.</p>
          ) : (
            months.map((mo) => (
              <div key={mo.name} className='pbs-card pbm-tl'>
                <span className='pbs-label'>Timeline · {mo.name}</span>
                {mo.events.map((e, i) => (
                  <div key={e.key} className={clsx('pbm-ev', ac(eventColor(e)), i === mo.events.length - 1 && 'pbm-last')}>
                    <div className='pbm-rail'>
                      <i className='pbm-dot' />
                      <i className='pbm-line' />
                    </div>
                    <div className='pbm-cd'>
                      <div className='pbm-l1'>
                        <h4>{e.title}</h4>
                        <time>{shortDate(e.at, now)}</time>
                      </div>
                      <p>{e.sub.map((p, k) => (p.b ? <b key={k}>{p.t}</b> : <span key={k}>{p.t}</span>))}</p>
                    </div>
                  </div>
                ))}
              </div>
            ))
          )}
        </section>
      )}

      {open && <TierSheet m={open} now={now} onClose={() => setOpenId(null)} />}
    </div>
  );
}

function MilestoneCard({ m, onOpen }: { m: Milestone; onOpen: () => void }) {
  const color = MILESTONE_COLOR[m.id];
  return (
    <button
      type='button'
      className={clsx('pbm-m', ac(color), m.value === 0 && 'pbm-zero')}
      aria-label={`${m.name}: ${commas(m.value)}${m.next !== null ? ` of ${commas(m.next)}` : ''}, tier ${m.unlocked} of ${m.tiers.length}. Open tiers.`}
      onClick={onOpen}
    >
      <div className='pbm-tx'>
        <div className='pbm-nm'>{m.short ?? m.name}</div>
        <div className='pbm-val'>
          {shortNum(m.value)}
          {m.next !== null && <small>/{shortNum(m.next)}</small>}
        </div>
        <div className='pbm-pips' aria-hidden='true'>
          {m.tiers.map((t, k) => (
            <i key={t} className={clsx(k < m.unlocked && 'pbm-on', k === m.unlocked && 'pbm-cur')} />
          ))}
        </div>
      </div>
      <svg className='pbm-ring' viewBox='0 0 44 44' aria-hidden='true'>
        <circle cx='22' cy='22' r='18' fill='none' stroke='var(--track)' strokeWidth='5' />
        <circle
          cx='22'
          cy='22'
          r='18'
          fill='none'
          stroke='var(--ac)'
          strokeWidth='5'
          strokeLinecap='round'
          strokeDasharray={`${((m.pct / 100) * 113).toFixed(1)} 113`}
          transform='rotate(-90 22 22)'
        />
      </svg>
    </button>
  );
}

function NextUpCard({
  next,
  done,
  total,
  onOpen,
}: {
  next: NonNullable<ReturnType<typeof pickNextUp>>;
  done: number;
  total: number;
  onOpen: () => void;
}) {
  const m = next.milestone;
  const color = MILESTONE_COLOR[m.id];
  const needText = commas(next.need);
  return (
    <button
      type='button'
      className={clsx('pbs-card pbm-hero pbm-hero-btn', ac(color))}
      aria-label={`Next up: ${needText} more to ${goalText(m, next.target)}. Open tiers.`}
      onClick={onOpen}
    >
        <div className='pbm-hexes' aria-hidden='true'>
          {m.tiers.map((t, k) => {
            const state = k < m.unlocked ? 'done' : k === m.unlocked ? 'cur' : 'lock';
            const big = state === 'cur';
            return (
              <svg key={t} width={big ? 64 : 56} height={big ? 72 : 64} viewBox='0 0 64 72'>
                {state === 'done' && <polygon points={HEX} fill='var(--ac)' stroke='var(--ac)' strokeWidth='3' strokeLinejoin='round' />}
                {state === 'cur' && <polygon points={HEX} fill='var(--ac-m)' stroke='var(--ac)' strokeWidth='3' strokeLinejoin='round' />}
                {state === 'lock' && <polygon points={HEX} fill='var(--inset)' stroke='var(--track)' strokeWidth='3' strokeDasharray='5 5' strokeLinejoin='round' />}
                {state === 'done' && <path d='M22 37 29 44 43 28' fill='none' stroke='var(--on-accent)' strokeWidth='4' strokeLinecap='round' strokeLinejoin='round' />}
                {state === 'cur' && (
                  <text x='32' y='44' textAnchor='middle' fill='var(--ac)' fontSize='24' fontWeight='700'>
                    {k + 1}
                  </text>
                )}
              </svg>
            );
          })}
        </div>
        <span className='pbs-label'>
          Next up · tier {next.tier} of {m.tiers.length}
        </span>
        <div className='pbm-n-row'>
          <span className='pbm-n-num'>{needText}</span>
          <span className='pbm-n-unit'>{m.unit} to go</span>
        </div>
        <div className='pbm-n-until'>until {goalText(m, next.target)}</div>
        <div className='pbm-bar' aria-hidden='true'>
          <i style={{ width: `${m.pct.toFixed(1)}%` }} />
        </div>
        <div className='pbm-n-foot'>
          <span>
            <b>{commas(m.value)}</b> of {commas(next.target)}
          </span>
          <span>{next.days !== null ? etaText(next.days) : `${done} of ${total} tiers`}</span>
        </div>
    </button>
  );
}
