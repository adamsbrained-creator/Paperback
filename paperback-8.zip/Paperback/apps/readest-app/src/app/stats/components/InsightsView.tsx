'use client';

import clsx from 'clsx';
import { useEffect, useMemo, useState } from 'react';
import type { PBook } from '@/services/paperback/library';
import { MONTH_SHORT, WEEKDAY_NAMES } from '@/services/statistics/activityStats';
import {
  consistency,
  finishForecast,
  inDaysText,
  monthCompare,
  readingRecords,
  readingSpeed,
  yearPace,
} from '@/services/statistics/insightsStats';
import { formatCount, type StatEventRow } from '@/services/statistics/statsAggregate';
import { DEFAULT_GOALS, loadGoals } from '../goals';
import { countFinishedThisYear } from '../useStatsData';
import { Thumb } from './ui';
import { RingArc, ac, fmtMin } from './parts';

interface Props {
  events: StatEventRow[];
  library: PBook[];
  booksByHash: Map<string, PBook>;
  now: Date;
}

const dayText = (d: Date) => `${d.getDate()} ${MONTH_SHORT[d.getMonth()]}`;

/** Stats → Insights: how this month compares, consistency, speed, records, finish estimates, the year's pace. */
export default function InsightsView({ events, library, booksByHash, now }: Props) {
  const [goals, setGoals] = useState(DEFAULT_GOALS);
  useEffect(() => setGoals(loadGoals()), []);

  const month = useMemo(() => monthCompare(events, now), [events, now]);
  const cons = useMemo(() => consistency(events, now), [events, now]);
  const speed = useMemo(() => readingSpeed(events, now), [events, now]);
  const rec = useMemo(() => readingRecords(events), [events]);
  const forecast = useMemo(() => finishForecast(library, events, now), [library, events, now]);
  const finished = useMemo(() => countFinishedThisYear(library, now), [library, now]);
  const year = yearPace(finished, goals.booksPerYear, now);

  if (events.length === 0) {
    return (
      <div className='pbs-card pbs-empty'>
        <b>No insights yet</b>
        Read for a few days and what stands out will show up here.
      </div>
    );
  }

  const up = month.pct !== null && month.pct >= 0;
  const maxMonth = Math.max(1, month.cur, month.prev);
  const maxPace = Math.max(1, ...speed.months.map((s) => s.pace));
  const yearMark = Math.min(100, (year.expected / Math.max(1, year.goal)) * 100);

  return (
    <div className='pbs-screen pbs-col'>
      {/* ---------- this month vs last ---------- */}
      <section className='pbs-card pbs-ins-head' aria-label='This month'>
        <div className='pbs-label'>{month.monthName} so far</div>
        <p className='pbs-sentence'>
          {month.pct === null ? (
            <>
              You&apos;ve read <em>{fmtMin(month.cur)}</em> this month.
            </>
          ) : month.pct === 0 ? (
            <>You&apos;re reading about the same as last month.</>
          ) : (
            <>
              You&apos;re reading <em className={clsx(!up && 'pbs-down')}>{Math.abs(month.pct)}% {up ? 'more' : 'less'}</em> than{' '}
              {month.prevName}.
            </>
          )}
        </p>
        <div className='pbs-cmp'>
          <div className='pbs-c-blue'>
            <span>{month.monthName.slice(0, 3)}</span>
            <div className='pbs-meter'>
              <i style={{ width: `${Math.max(2, (month.cur / maxMonth) * 100)}%` }} />
            </div>
            <b>{fmtMin(month.cur)}</b>
          </div>
          <div className='pbs-c-yellow'>
            <span>{month.prevName.slice(0, 3)}</span>
            <div className='pbs-meter'>
              <i style={{ width: `${Math.max(2, (month.prev / maxMonth) * 100)}%`, opacity: 0.55 }} />
            </div>
            <b>{fmtMin(month.prev)}</b>
          </div>
        </div>
        <p className='pbs-note' style={{ margin: '12px 0 0' }}>
          {month.monthName} is compared with the same days of {month.prevName}.
        </p>
      </section>

      {/* ---------- consistency ---------- */}
      <section className='pbs-card' aria-label='Consistency'>
        <div className='pbs-label'>Consistency</div>
        <div className='pbs-cons' style={{ marginTop: 14 }}>
          <RingArc value={cons.pct} color='var(--mint)'>
            <text x='52' y='60' textAnchor='middle' fill='var(--text)' fontSize='22' fontWeight='700'>
              {Math.round(cons.pct * 100)}%
            </text>
          </RingArc>
          <div>
            <div className='pbs-n'>
              {cons.activeDays}
              <span className='pbs-u'> of {cons.of} days</span>
            </div>
            <p>You opened a book on {cons.activeDays} of the last {cons.of} days.</p>
          </div>
        </div>
        <div className='pbs-trio' style={{ marginTop: 16 }}>
          <div>
            <div className='pbs-n' style={{ color: 'var(--yellow)' }}>
              {cons.streak}d
            </div>
            <div className='pbs-sub'>Streak</div>
          </div>
          <div>
            <div className='pbs-n'>{cons.longestStreak}d</div>
            <div className='pbs-sub'>Best streak</div>
          </div>
        </div>
      </section>

      {/* ---------- reading speed ---------- */}
      <section className='pbs-card' aria-label='Reading speed'>
        <div className='pbs-card-head'>
          <h3>Reading speed</h3>
          <span>pages per hour</span>
        </div>
        <div className='pbs-n' style={{ fontSize: 44, marginTop: 14, color: 'var(--yellow)' }}>
          {speed.current || '–'}
          {speed.current ? <span className='pbs-u'> p/h</span> : null}
        </div>
        <div className='pbs-sub' style={{ marginTop: 6 }}>
          {speed.best ? `Fastest month: ${speed.best.label} · ${speed.best.pace} p/h` : 'Read a little longer to see how your speed changes.'}
        </div>
        <div className='pbs-bars' role='img' aria-label='Pages per hour in each of the last six months'>
          {speed.months.map((s) => (
            <div key={s.label}>
              <i
                className={clsx(speed.best?.label === s.label && s.pace === speed.best.pace && 'pbs-top')}
                style={{ height: s.pace ? `${Math.max(10, Math.round((s.pace / maxPace) * 62))}px` : undefined, opacity: s.pace ? undefined : 0.25 }}
              />
              <span>{s.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- records ---------- */}
      <div className='pbs-label pbs-section-label'>Your records</div>
      <div className='pbs-tiles'>
        <div className={clsx('pbs-tile', ac('blue'))}>
          <div className='pbs-label'>Best day</div>
          <div className='pbs-n'>{rec.bestDay ? fmtMin(rec.bestDay.seconds) : '–'}</div>
          <div className='pbs-sub'>{rec.bestDay ? dayText(rec.bestDay.date) : ''}</div>
        </div>
        <div className={clsx('pbs-tile', ac('mint'))}>
          <div className='pbs-label'>Longest session</div>
          <div className='pbs-n'>{rec.longestSession ? fmtMin(rec.longestSession.seconds) : '–'}</div>
          <div className='pbs-sub'>{rec.longestSession ? dayText(new Date(rec.longestSession.start * 1000)) : ''}</div>
        </div>
        <div className={clsx('pbs-tile', ac('pink'))}>
          <div className='pbs-label'>Best week</div>
          <div className='pbs-n'>{rec.bestWeek ? fmtMin(rec.bestWeek.seconds) : '–'}</div>
          <div className='pbs-sub'>{rec.bestWeek ? `from ${dayText(rec.bestWeek.start)}` : ''}</div>
        </div>
        <div className={clsx('pbs-tile', ac('yellow'))}>
          <div className='pbs-label'>Most pages a day</div>
          <div className='pbs-n'>{rec.mostPages ? formatCount(rec.mostPages.pages) : '–'}</div>
          <div className='pbs-sub'>
            {rec.mostPages ? `${WEEKDAY_NAMES[rec.mostPages.date.getDay()]!.slice(0, 3)} ${dayText(rec.mostPages.date)}` : ''}
          </div>
        </div>
      </div>

      {/* ---------- when you will finish ---------- */}
      {forecast.length > 0 && (
        <section className='pbs-card' aria-label='Finish estimates'>
          <div className='pbs-card-head'>
            <h3>When you&apos;ll finish</h3>
            <span>at your pace</span>
          </div>
          <div className='pbs-fc'>
            {forecast.map((r, i) => (
              <div key={r.hash} className={ac((['blue', 'mint', 'pink', 'yellow'] as const)[i % 4]!)}>
                <div className='pbs-sc'>
                  <Thumb md5={r.hash} book={booksByHash.get(r.hash)} />
                </div>
                <div className='pbs-t'>
                  <h4>{r.title}</h4>
                  <p>
                    {formatCount(r.pagesLeft)} {r.pagesLeft === 1 ? 'page' : 'pages'} left · {fmtMin(r.secondsLeft)} of reading
                  </p>
                </div>
                {r.days !== null && <span className='pbs-eta'>{inDaysText(r.days)}</span>}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ---------- the year ---------- */}
      <section className='pbs-card pbs-yearpace' aria-label='Books this year'>
        <div className='pbs-card-head'>
          <h3>Books in {now.getFullYear()}</h3>
          <span>goal {year.goal}</span>
        </div>
        <div className='pbs-n' style={{ fontSize: 44, marginTop: 14, color: 'var(--mint)' }}>
          {year.finished}
          <span className='pbs-u'> of {year.goal}</span>
        </div>
        <div className='pbs-gb'>
          <i style={{ width: `${Math.min(100, (year.finished / Math.max(1, year.goal)) * 100)}%` }} />
          <s style={{ left: `${yearMark}%` }} />
        </div>
        <div className='pbs-foot'>
          <span>{year.finished >= year.expected ? 'On pace or ahead' : `${year.expected - year.finished} behind the line`}</span>
          <span>{year.projected > 0 ? `${year.projected} by December at this rate` : ''}</span>
        </div>
      </section>
    </div>
  );
}
