'use client';

import clsx from 'clsx';
import { useMemo } from 'react';
import type { PBook } from '@/services/paperback/library';
import { booksOverview } from '@/services/statistics/booksStats';
import { formatCount, type StatEventRow } from '@/services/statistics/statsAggregate';
import { Thumb } from './ui';
import { ACCENTS, Stars, ac } from './parts';

const MAX_PROGRESS = 6;
const MAX_AUTHORS = 14;

interface Props {
  events: StatEventRow[];
  library: PBook[];
  ratings: Record<string, number>;
}

/** Stats → Books: what is in the library, what you are reading, authors and ratings. */
export default function BooksView({ events, library, ratings }: Props) {
  const o = useMemo(() => booksOverview(library, events, ratings), [library, events, ratings]);

  if (o.total === 0) {
    return (
      <div className='pbs-card pbs-empty'>
        <b>No books yet</b>
        Add a book to the library and its stats will show up here.
      </div>
    );
  }

  const shownProgress = o.progress.slice(0, MAX_PROGRESS);
  const hiddenProgress = o.progress.length - shownProgress.length;
  const shownAuthors = o.authors.slice(0, MAX_AUTHORS);
  const hiddenAuthors = o.authors.length - shownAuthors.length;

  return (
    <div className='pbs-screen pbs-col'>
      <section className='pbs-card pbs-lib' aria-label='Library'>
        <div>
          <div className='pbs-label'>Library</div>
          <div className='pbs-n'>{formatCount(o.total)}</div>
          <div className='pbs-sub' style={{ marginTop: 6 }}>
            {o.total === 1 ? 'book' : 'books'}
          </div>
        </div>
        <div className={clsx('pbs-fan', o.recent.length === 1 && 'pbs-one')} aria-hidden='true'>
          {o.recent.map((b) => (
            <div key={b.hash}>
              <Thumb md5={b.hash} book={library.find((x) => x.hash === b.hash)} />
            </div>
          ))}
        </div>
      </section>

      <div className='pbs-tiles'>
        <div className={clsx('pbs-tile', ac('mint'))}>
          <div className='pbs-label'>Finished</div>
          <div className='pbs-n'>{o.finished}</div>
        </div>
        <div className={clsx('pbs-tile', ac('pink'))}>
          <div className='pbs-label'>Reading</div>
          <div className='pbs-n'>{o.reading}</div>
        </div>
        <div className={clsx('pbs-tile', ac('blue'))}>
          <div className='pbs-label'>Longest read</div>
          <div className='pbs-n'>
            {o.longest ? formatCount(o.longest.pages) : '–'}
            {o.longest && <span className='pbs-u'>pages</span>}
          </div>
          {o.longest && <div className='pbs-sub' style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{o.longest.title}</div>}
        </div>
        <div className={clsx('pbs-tile', ac('yellow'))}>
          <div className='pbs-label'>Languages</div>
          <div className='pbs-n'>{o.languages.length || '–'}</div>
          {o.languages.length > 0 && <div className='pbs-sub'>{o.languages.join(' · ')}</div>}
        </div>
      </div>

      {shownProgress.length > 0 && (
        <section className='pbs-card' aria-label='Reading progress'>
          <div className='pbs-label'>Reading progress</div>
          <div className='pbs-prog'>
            {shownProgress.map((r, i) => (
              <div key={r.hash} className={ac(ACCENTS[(i + 3) % 4]!)}>
                <div className='pbs-pr'>
                  <span>{r.title}</span>
                  <b>{r.pct}%</b>
                </div>
                <div className='pbs-meter'>
                  <i style={{ width: `${Math.max(r.pct, 1)}%` }} />
                </div>
              </div>
            ))}
          </div>
          {hiddenProgress > 0 && (
            <p className='pbs-note' style={{ margin: '14px 0 0' }}>
              and {hiddenProgress} more
            </p>
          )}
        </section>
      )}

      {shownAuthors.length > 0 && (
        <section className='pbs-card' aria-label='Authors'>
          <div className='pbs-label'>Authors</div>
          <div className='pbs-tags'>
            {shownAuthors.map((a) => (
              <span key={a.name}>
                {a.name}
                {a.count > 1 && <small>{a.count}</small>}
              </span>
            ))}
            {hiddenAuthors > 0 && <span>+{hiddenAuthors}</span>}
          </div>
        </section>
      )}

      <section className='pbs-card pbs-rate' aria-label='Ratings'>
        <div>
          <div className='pbs-label'>Ratings</div>
          <div className='pbs-sub' style={{ marginTop: 8 }}>
            {o.rated} of {o.total} rated{o.avgRating !== null ? ` · average ${o.avgRating.toFixed(1)}` : ''}
          </div>
        </div>
        <Stars filled={o.avgRating === null ? 0 : Math.round(o.avgRating)} />
      </section>
    </div>
  );
}
