'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Shell from '@/components/paperback/Shell';
import { useBooknotes } from '@/components/paperback/useBooknotes';
import { useShelves } from '@/components/paperback/useShelves';
import { useStatsData } from './useStatsData';
import ActivityView from './components/ActivityView';
import GoalsView from './components/GoalsView';
import MilestonesView from './components/MilestonesView';
import BooksView from './components/BooksView';
import HistoryView from './components/HistoryView';
import InsightsView from './components/InsightsView';
import StatsNav, { STATS_PAGES, type StatsPage } from './components/StatsNav';
import { SIcon } from './components/StatsIcons';

// A page of Stats, or the reading-goals screen opened from Activity.
type Screen = 'main' | 'goals';

/**
 * ?tab=goals opens the goals screen; ?tab=milestones | books | history | insights opens that page.
 * Older links use ?tab=sessions for the session list, which is now the History page.
 */
function readUrl(): { screen: Screen; page: StatsPage } {
  const t = new URLSearchParams(window.location.search).get('tab');
  if (t === 'sessions') return { screen: 'main', page: 'history' };
  if (t === 'goals') return { screen: 'goals', page: 'activity' };
  const page = STATS_PAGES.find((p) => p.id === t)?.id ?? 'activity';
  return { screen: 'main', page };
}

const scroller = () => document.querySelector<HTMLElement>('.pb-root');

export default function StatsPage() {
  const [screen, setScreen] = useState<Screen>('main');
  const [page, setPage] = useState<StatsPage>('activity');
  const { events, error, now, library, booksByHash } = useStatsData();
  const scrollBefore = useRef(0);

  // Milestones count notes, saved words and ratings. Notes are read from every book's own file, so that
  // starts the first time Milestones is opened and then stays loaded.
  const [shelves] = useShelves();
  const [wantNotes, setWantNotes] = useState(false);
  useEffect(() => {
    if (page === 'milestones') setWantNotes(true);
  }, [page]);
  const liveBooks = useMemo(() => library.filter((b) => !b.deletedAt), [library]);
  const notes = useBooknotes(liveBooks, wantNotes);

  useEffect(() => {
    const sync = () => {
      const s = readUrl();
      setScreen(s.screen);
      if (s.screen === 'main') {
        requestAnimationFrame(() => {
          const el = scroller();
          if (el) el.scrollTop = scrollBefore.current;
        });
      }
    };
    const first = readUrl();
    setScreen(first.screen);
    setPage(first.page);
    window.addEventListener('popstate', sync);
    return () => window.removeEventListener('popstate', sync);
  }, []);

  // Switching pages starts at the top.
  const go = useCallback((p: StatsPage) => {
    setPage(p);
    const el = scroller();
    if (el) el.scrollTop = 0;
  }, []);

  const open = useCallback((s: Exclude<Screen, 'main'>) => {
    scrollBefore.current = scroller()?.scrollTop ?? 0;
    window.history.pushState({ pbs: s }, '', `${window.location.pathname}?tab=${s}`);
    setScreen(s);
    const el = scroller();
    if (el) el.scrollTop = 0;
  }, []);

  // Back: undo the push when this screen was opened from Activity, else just show Activity.
  const close = useCallback(() => {
    if ((window.history.state as { pbs?: string } | null)?.pbs) {
      window.history.back();
    } else {
      window.history.replaceState({}, '', window.location.pathname);
      setScreen('main');
    }
  }, []);

  const header = (
    <div className='pbs pbs-top' style={{ height: 76, paddingTop: 4 }}>
      <h1>Stats</h1>
      <span className='pbs-chip'>
        <i className='pbs-dot' /> On this device
      </span>
    </div>
  );

  const ready = events !== null;
  const hasEvents = ready && events.length > 0;

  return (
    <Shell title='Stats' tab='stats' header={screen === 'main' ? header : <></>}>
      {error && (
        <div className='pb-card pb-pk'>
          Couldn&apos;t open the reading statistics database.
          <div className='pb-note'>{error}</div>
        </div>
      )}
      {!error && events === null && <div className='pb-empty'>Loading…</div>}

      {ready && (
        <>
          {/* Activity stays mounted while a screen is open on top of it, so its period and scroll are kept. */}
          <div className='pbs pbs-col' hidden={screen !== 'main'}>
            <StatsNav value={page} onChange={go} />
            {page === 'activity' ? (
              hasEvents ? (
                <ActivityView
                  events={events}
                  library={library}
                  booksByHash={booksByHash}
                  now={now}
                  onOpenHistory={() => go('history')}
                  onOpenGoals={() => open('goals')}
                />
              ) : (
                <div className='pbs-card pbs-empty'>
                  Nothing tracked yet. Read a few pages and your stats will appear here.
                </div>
              )
            ) : page === 'milestones' ? (
              <MilestonesView
                events={events}
                books={library}
                notes={notes}
                savedWords={shelves.savedWords}
                ratings={shelves.ratings}
                now={now}
              />
            ) : page === 'books' ? (
              <BooksView events={events} library={library} ratings={shelves.ratings} />
            ) : page === 'history' ? (
              <HistoryView events={events} booksByHash={booksByHash} now={now} />
            ) : (
              <InsightsView events={events} library={library} booksByHash={booksByHash} now={now} />
            )}
          </div>

          {screen === 'goals' && (
            <div className='pbs pbs-col'>
              <div className='pbs-stop'>
                <button type='button' className='pbs-round' aria-label='Back to Activity' onClick={close}>
                  <SIcon name='back' />
                </button>
                <h2>Goals</h2>
              </div>
              <GoalsView events={events} library={library} now={now} />
            </div>
          )}
        </>
      )}
    </Shell>
  );
}
