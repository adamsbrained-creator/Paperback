package com.paperback.app.data.catalog

import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.Ranker
import com.paperback.app.catalog.Taste
import com.paperback.app.catalog.TasteBook
import com.paperback.app.catalog.Themes
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.AppPrefs
import com.paperback.app.data.Book
import com.paperback.app.data.BookStatus
import com.paperback.app.data.Dismissal
import com.paperback.app.data.Implicit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Something that is loading, has loaded, or could not be loaded. */
sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    class Ready<T>(val value: T) : Load<T>
    class Failed(val message: String) : Load<Nothing>
}

/** A page of catalog books for the "see all" screen; [reasons] (book id -> why) is filled for "For you". */
class CatalogList(val title: String, val books: List<CatalogBook>, val reasons: Map<String, String> = emptyMap())

/**
 * Everything behind the online side of Search: trending books, recommendations built from your own library,
 * category lists, catalog search and book details. Lives in the view model so what has been loaded survives
 * leaving the page. Nothing is fetched while the online catalog is switched off.
 */
class CatalogController(
    private val scope: CoroutineScope,
    private val api: CatalogApi,
    private val prefs: AppPrefs,
    private val library: () -> List<Book>,
    /** Books on the Want to read list: interest in what they are about counts a little. */
    private val wanted: () -> List<CatalogBook> = { emptyList() },
    /** Shows a short message at the bottom of the screen. */
    private val say: (String) -> Unit = {},
    /** Shows a short message with an Undo that runs the given action. */
    private val sayUndo: (String, () -> Unit) -> Unit = { _, _ -> },
    /** How many highlights you made in each book, by book id: many for its length means it spoke to you. */
    private val marks: () -> Map<String, Int> = { emptyMap() },
) {
    val enabled: StateFlow<Boolean> = prefs.catalogOnline
    fun setEnabled(on: Boolean) = prefs.setCatalogOnline(on)

    private val _trending = MutableStateFlow<Load<List<CatalogBook>>>(Load.Loading)
    val trending: StateFlow<Load<List<CatalogBook>>> = _trending.asStateFlow()

    private val _forYou = MutableStateFlow<Load<List<Ranker.Pick>>>(Load.Loading)
    val forYou: StateFlow<Load<List<Ranker.Pick>>> = _forYou.asStateFlow()

    /** The reason for each recommended book, by id, for the book page and the "see all" list. */
    private val reasons = ConcurrentHashMap<String, String>()

    /** The taste the lists were last made from, for "Why this?". */
    @Volatile
    private var lastTaste: Taste? = null

    private val _stretch = MutableStateFlow<List<CatalogBook>>(emptyList())
    /** Well-rated books from subjects you have only dipped into: a way to something new. Empty when the adventure setting is 0. */
    val stretch: StateFlow<List<CatalogBook>> = _stretch.asStateFlow()

    private val _newFromAuthors = MutableStateFlow<List<CatalogBook>>(emptyList())
    /** Recent books by the authors you like most, newest first. */
    val newFromAuthors: StateFlow<List<CatalogBook>> = _newFromAuthors.asStateFlow()

    /** The kind of reason behind each recommended book ([Ranker] KIND_*), by id, to learn which kinds you take. */
    private val kinds = ConcurrentHashMap<String, Int>()

    /** Books whose opening was already counted as a sign of liking, so looking twice counts once. */
    private val counted = ConcurrentHashMap.newKeySet<String>()

    /** Books seen on any screen, so a book page can open from just its id. */
    private val known = ConcurrentHashMap<String, CatalogBook>()

    private val gate = Semaphore(2)
    private var trendingAt = 0L
    private var forYouAt = 0L
    private var forYouSignature = ""
    private var job: Job? = null

    fun find(id: String): CatalogBook? = known[id]
    fun reasonFor(id: String): String? = reasons[id]

    fun remember(list: List<CatalogBook>) {
        for (b in list) known.putIfAbsent(b.id, b)
    }

    private suspend fun <T> online(block: () -> T): T = withContext(Dispatchers.IO) { gate.withPermit { block() } }

    private fun message(e: Exception): String =
        if (e is java.io.IOException) "Couldn't reach the online catalog. Check your connection and try again."
        else "The online catalog sent something Paperback couldn't read."

    /** Loads what the search page shows (once an hour, or again when your taste changed). Safe to call often. */
    fun refresh(force: Boolean = false) {
        if (!enabled.value) return
        val now = System.currentTimeMillis()
        val taste = tasteNow()
        lastTaste = taste
        val sig = taste.signature() + "^" + prefs.adventure.value
        val trendingStale = force || _trending.value !is Load.Ready || now - trendingAt > HOUR
        val forYouStale = force || _forYou.value !is Load.Ready || sig != forYouSignature || now - forYouAt > 6 * HOUR
        if (!trendingStale && !forYouStale) return
        if (job?.isActive == true && !force) return
        job?.cancel()
        job = scope.launch {
            if (trendingStale) {
                if (_trending.value !is Load.Ready) _trending.value = Load.Loading
                try {
                    val list = online { api.trending() }
                    remember(list)
                    _trending.value = Load.Ready(list)
                    trendingAt = System.currentTimeMillis()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (_trending.value !is Load.Ready) _trending.value = Load.Failed(message(e))
                }
            }
            if (forYouStale) loadForYou(taste, sig)
        }
    }

    private fun tasteNow(): Taste = tasteOf(library(), wanted(), prefs.dismissed.value, marks(), prefs.mutedSubjects.value)

    /** A suggested book was opened: a small sign that you take this kind of suggestion. Counted once per book. */
    fun opened(book: CatalogBook) {
        val kind = kinds[book.id] ?: return
        if (counted.add(book.id)) prefs.recordFeedback(kind, 1.0, 0.0)
    }

    /** A suggested book was put on Want to read: a stronger sign. */
    fun saved(book: CatalogBook) {
        val kind = kinds[book.id] ?: return
        prefs.recordFeedback(kind, 3.0, 0.0)
    }

    /** "Not interested": the book leaves the lists at once, and the next picks lean away from what it was about. */
    fun dismiss(book: CatalogBook) {
        val kind = kinds[book.id]
        kind?.let { prefs.recordFeedback(it, 0.0, 2.0) }
        prefs.dismiss(Dismissal(book.id, book.title, book.author, book.subjects))
        _newFromAuthors.value = _newFromAuthors.value.filterNot { it.id == book.id }
        _stretch.value = _stretch.value.filterNot { it.id == book.id }
        val have = _forYou.value
        if (have is Load.Ready) _forYou.value = Load.Ready(have.value.filterNot { it.book.id == book.id })
        sayUndo("Hidden from your suggestions.") {
            prefs.undismiss(book.id)
            kind?.let { prefs.recordFeedback(it, 0.0, -2.0) }
            forYouSignature = "" // make the lists again, with the book back in
            refresh()
        }
        refresh()
    }

    /** What links a suggested book to you, as short lines: for the "Why this?" sheet. */
    fun explain(book: CatalogBook): List<String> {
        val taste = lastTaste ?: tasteNow()
        val lines = ArrayList<String>()
        reasons[book.id]?.let { lines += it }
        val subjects = book.subjects.mapNotNull { taste.subject(it) }.filter { it.weight > 0.5 }
            .distinctBy { it.name }.sortedByDescending { it.weight }.take(3)
        if (subjects.isNotEmpty()) lines += "Subjects you like: ${subjects.joinToString(", ") { it.name }}"
        taste.author(book.firstAuthor())?.takeIf { it.weight > 1.0 }?.let { lines += "You like books by ${it.name}" }
        val era = taste.eraFit(book.year)
        if (era >= 0.6) lines += "Published around the years you usually read (${book.year})"
        else if (era in 0.0..0.25) lines += "A bit older or newer than what you usually read (${book.year})"
        kinds[book.id]?.let { k ->
            val w = prefs.kindWeights().getOrElse(k) { 1.0 }
            if (w >= 1.1) lines += "You tend to take suggestions like this"
            else if (w <= 0.9) lines += "You tend to pass on suggestions like this"
        }
        if (book.ratingCount >= 100) lines += "Rated ${"%.1f".format(book.rating)} out of 5 by ${book.ratingCount} readers"
        if (lines.isEmpty()) lines += "It matches the subjects and authors of books you liked."
        return lines
    }

    /** Your Want to read list with the best fit for you first (ties keep the saved order); blank reason = nothing links it. */
    fun rankWanted(items: List<CatalogBook>): List<Ranker.Pick> {
        val taste = tasteOf(library(), emptyList(), prefs.dismissed.value, marks(), prefs.mutedSubjects.value)
        return items
            .map { Ranker.fitPick(it, taste) ?: Ranker.Pick(it, "", 0.0, Ranker.KIND_GENERAL, "") }
            .sortedByDescending { it.score }
    }

    /**
     * Books at the edge of your taste: the best rated ones of subjects you have only dipped into, so a suggestion
     * can take you somewhere new. How far it goes depends on the adventure setting; at 0 there are none.
     */
    private suspend fun loadStretch(taste: Taste) {
        val level = prefs.adventure.value
        if (level == 0) {
            _stretch.value = emptyList()
            return
        }
        val edge = if (level == 1) taste.subjectsBetween(0.3, 2, 4) else taste.subjectsBetween(0.0, 1, 2)
        val found = ArrayList<CatalogBook>()
        for (s in edge.take(if (level == 1) 2 else 3)) {
            try {
                val good = online { api.bySubject(s.name, 20) }
                    .filter { b ->
                        b.rating >= 3.8 && b.ratingCount >= 50 && !taste.owns(b.title) && !taste.blocks(b) &&
                            !taste.dislikesAuthor(b.firstAuthor())
                    }
                    .sortedByDescending { it.rating * Math.log(it.ratingCount + 1.0) }
                    .take(if (level == 1) 3 else 4)
                for (b in good) {
                    reasons[b.id] = "A different kind of book \u00B7 ${s.name}"
                    found += b
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // leave this subject out this time
            }
        }
        val hidden = prefs.dismissed.value.map { it.id }.toSet()
        val seen = HashSet<String>()
        val out = found.filter { it.id !in hidden && seen.add(TitleKey.of(it.title)) }.take(if (level == 1) 6 else 10)
        remember(out)
        _stretch.value = out
    }

    /** Books from the last few years by the authors you like most, one cached request per author. */
    private suspend fun loadNewFromAuthors(taste: Taste) {
        val thisYear = java.time.Year.now().value
        val found = ArrayList<CatalogBook>()
        for (a in taste.likedAuthors(4)) {
            try {
                val target = normalize(a.name)
                for (b in online { api.newestByAuthor(a.name, 12) }) {
                    if (b.year < thisYear - 2) continue
                    if (taste.owns(b.title) || taste.blocks(b)) continue
                    if (normalize(b.firstAuthor()) != target) continue // the search also finds books that only mention the name
                    found += b
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // leave this author out this time
            }
        }
        val hidden = prefs.dismissed.value.map { it.id }.toSet()
        val seen = HashSet<String>()
        val fresh = found.filter { it.id !in hidden && seen.add(TitleKey.of(it.title)) }.sortedByDescending { it.year }.take(10)
        remember(fresh)
        _newFromAuthors.value = fresh
    }

    /** Shows [picks] as "For you", with the reason and the kind of each remembered for the book page and learning. */
    private fun publish(picks: List<Ranker.Pick>) {
        for (p in picks) {
            reasons[p.book.id] = p.reason
            kinds[p.book.id] = p.kind
        }
        _forYou.value = Load.Ready(picks)
    }

    /**
     * Looks at what the best suggestions are about: compares their descriptions with those of the books you
     * liked, moves up the ones with the same themes, and names those themes in the reason. Only the top few are
     * looked at (one cached request each); a lookup that fails leaves its suggestion as it was. Returns [picks]
     * itself when there was nothing to compare.
     */
    private suspend fun refine(picks: List<Ranker.Pick>, taste: Taste): List<Ranker.Pick> {
        val liked = library().filter {
            it.status != BookStatus.DROPPED && it.description.length > 80 &&
                (it.rating >= 4 || it.favorite || (it.finished && it.rating == 0))
        }.take(14)
        if (liked.size < 2) return picks
        val texts = HashMap<String, String>()
        var failures = 0
        for (p in picks.filter { it.kind != Ranker.KIND_SERIES }.take(14)) {
            if (failures >= 3) break
            try {
                val text = online { api.blurb(p.book) }
                if (text.length > 80) texts[p.book.id] = text
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failures++
            }
        }
        if (texts.size < 4) return picks
        val scorer = Themes.Scorer(
            liked.map { it.description },
            liked.map { if (it.favorite || it.rating == 5) 1.5 else 1.0 },
            texts.values.toList(),
        )
        if (!scorer.usable()) return picks
        val sims = texts.mapValues { scorer.similarity(it.value) }
        val mean = sims.values.average()
        val sd = Math.sqrt(sims.values.map { (it - mean) * (it - mean) }.average()).coerceAtLeast(0.01)
        val refined = picks.map { p ->
            val sim = sims[p.book.id] ?: return@map p
            val z = ((sim - mean) / sd).coerceIn(-2.0, 2.0)
            var reason = p.reason
            if (z > 0.3) {
                val words = scorer.shared(texts.getValue(p.book.id), 2)
                if (words.isNotEmpty()) reason = "$reason · ${words.joinToString(", ")}"
            }
            Ranker.Pick(p.book, reason, p.score + 0.8 * z, p.kind, p.anchor)
        }
        return refined.sortedByDescending { it.score }
    }

    private suspend fun loadForYou(taste: Taste, sig: String) {
        if (taste.isEmpty()) {
            _forYou.value = Load.Ready(emptyList())
            _newFromAuthors.value = emptyList()
            _stretch.value = emptyList()
            forYouSignature = sig
            return
        }
        if (_forYou.value !is Load.Ready) _forYou.value = Load.Loading
        try {
            val candidates = ArrayList<CatalogBook>()
            var failures = 0
            val queries: List<() -> List<CatalogBook>> =
                taste.likedSubjects(6).map { s -> { api.bySubject(s.name, 20) } } +
                    taste.likedAuthors(3).map { a -> { api.byAuthor(a.name, 12) } }
            for (q in queries) {
                try {
                    candidates += online { q() }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failures++
                }
            }

            // more of a series you are in: the author's books whose title carries the series name
            val seriesPicks = ArrayList<Ranker.Pick>()
            for (lead in seriesLeads(library()).take(2)) {
                try {
                    val found = online { api.byAuthor(lead.author, 40) }
                    val want = normalize(lead.series)
                    if (want.length < 3) continue
                    var n = 0
                    for (b in found) {
                        if (n >= 6) break
                        if (taste.owns(b.title) || !normalize(b.title).contains(want)) continue
                        seriesPicks += Ranker.Pick(b, "More in the ${lead.series} series", 100.0 - seriesPicks.size, Ranker.KIND_SERIES, lead.series)
                        n++
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failures++
                }
            }

            if (candidates.isEmpty() && seriesPicks.isEmpty() && failures > 0) {
                if (_forYou.value !is Load.Ready) _forYou.value = Load.Failed("Couldn't reach the online catalog. Check your connection and try again.")
                return
            }
            val hidden = prefs.dismissed.value.map { it.id }.toSet()
            val seen = HashSet<String>()
            val picks = (seriesPicks + Ranker.rank(candidates, taste, 36, prefs.kindWeights()))
                .filter { it.book.id !in hidden && seen.add(TitleKey.of(it.book.title)) }
            remember(picks.map { it.book })
            publish(picks)
            forYouSignature = sig
            forYouAt = System.currentTimeMillis()

            loadNewFromAuthors(taste)
            loadStretch(taste)

            // then look at what the best ones are about, which takes a few more requests, and show the result
            val refined = refine(picks, taste)
            if (refined !== picks) {
                val nowHidden = prefs.dismissed.value.map { it.id }.toSet()
                publish(refined.filter { it.book.id !in nowHidden })
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (_forYou.value !is Load.Ready) _forYou.value = Load.Failed(message(e))
        }
    }

    // ---- one-off requests for screens ---------------------------------------------------------------

    suspend fun search(query: String): Result<List<CatalogBook>> = attempt {
        online { api.search(query.trim(), 20) }.also { remember(it) }
    }

    suspend fun details(book: CatalogBook): Result<CatalogDetails> = attempt { online { api.details(book) } }

    /** Books for the "see all" page. [kind] is "trending", "foryou", "cat" (value = subject slug), "subject" or "author". */
    suspend fun list(kind: String, value: String): Result<CatalogList> = attempt {
        when (kind) {
            "trending" -> {
                val have = trending.value
                val l = if (have is Load.Ready) have.value else online { api.trending() }.also { remember(it) }
                CatalogList("Trending this week", l)
            }
            "foryou" -> {
                val have = forYou.value
                val picks = if (have is Load.Ready) have.value else emptyList()
                CatalogList("For you", picks.map { it.book }, picks.associate { it.book.id to it.reason })
            }
            "cat" -> {
                val cat = Categories.bySlug(value)
                val name = cat?.name ?: value
                var l = online { api.subject(value, 40) }
                if (l.isEmpty()) l = online { api.bySubject(name, 40) }
                remember(l)
                CatalogList(name, l)
            }
            "author" -> CatalogList(value, online { api.byAuthor(value, 40) }.also { remember(it) })
            else -> CatalogList(value, online { api.bySubject(value, 40) }.also { remember(it) })
        }
    }

    private suspend fun <T> attempt(block: suspend () -> T): Result<T> =
        try {
            Result.success(block())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(IllegalStateException(message(e)))
        }

    /** A series you finished a book of, and who wrote it. */
    private class SeriesLead(val series: String, val author: String)

    /** The series you have read into, the one you read last first. */
    private fun seriesLeads(books: List<Book>): List<SeriesLead> =
        books.asSequence()
            .filter { it.series.isNotBlank() && it.finished && it.rating !in 1..2 && it.author.isNotBlank() }
            .sortedByDescending { maxOf(it.finishedAt, it.lastOpenedAt) }
            .distinctBy { it.series.trim().lowercase() }
            .map { SeriesLead(it.series.trim(), it.author.split(';', '&').first().split(" and ").first().trim()) }
            .filter { it.author.isNotBlank() }
            .toList()

    companion object {
        private const val HOUR = 3_600_000L
        private const val DAY = 86_400_000L
        private val notWord = Regex("[^\\p{L}\\p{N}]+")

        /** "The Lord of the Rings!" -> "lord of the rings", to find a series name inside a title. */
        private fun normalize(s: String): String = s.lowercase().replace(notWord, " ").trim().removePrefix("the ")

        /**
         * What your books say about your taste. Recent reading counts more, and books you dropped, left early or
         * said "not interested" to count against what they were about; the Want to read list counts a little for.
         */
        fun tasteOf(
            books: List<Book>,
            wanted: List<CatalogBook> = emptyList(),
            dismissed: List<Dismissal> = emptyList(),
            marks: Map<String, Int> = emptyMap(),
            muted: List<String> = emptyList(),
        ): Taste {
            val now = System.currentTimeMillis()
            val paces = Implicit.paceRatios(books)
            val list = ArrayList<TasteBook>()
            for (b in books) {
                val last = maxOf(b.finishedAt, b.lastOpenedAt, b.ratedAt, b.addedAt)
                val age = if (last > 0L) ((now - last) / DAY).toInt().coerceAtLeast(0) else 0
                // dropped on purpose, or started a little and left for three months
                val dropped = b.status == 2 || (!b.finished && b.status == 0 && b.progress in 0.02f..0.3f && age > 90)
                list += TasteBook(b.title, b.author, b.tags, b.rating, b.progress.toDouble(), b.finished, b.favorite, dropped, false, false, age).also {
                    it.pace = paces[b.id] ?: 0.0
                    it.year = Implicit.yearOf(b.published)
                    it.pages = b.pageCount
                    it.marksBoost = Implicit.markBoost(marks[b.id] ?: 0, b.pageCount)
                }
            }
            for (w in wanted) {
                list += TasteBook(w.title, w.author, w.subjects, 0, 0.0, false, false, false, true, false, 0).also { it.year = w.year }
            }
            for (d in dismissed) list += TasteBook(d.title, d.author, d.subjects, 0, 0.0, false, false, false, false, true, 0)
            return Taste.of(list, muted)
        }
    }
}
