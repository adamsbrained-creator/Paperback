package com.paperback.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.AppIcon
import com.paperback.app.data.Backup
import com.paperback.app.data.BackupCounts
import com.paperback.app.data.GoalStyle
import com.paperback.app.data.IconStyle
import com.paperback.app.data.Book
import com.paperback.app.data.BookCollection
import com.paperback.app.data.BookEdits
import com.paperback.app.data.Bookmark
import com.paperback.app.data.DiscoverController
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.Goals
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.NavStyle
import com.paperback.app.data.MoreStyle
import com.paperback.app.data.Highlight
import com.paperback.app.data.ImportOutcome
import com.paperback.app.data.PendingBackup
import com.paperback.app.data.ReflowOutcome
import com.paperback.app.data.ReaderSettings
import com.paperback.app.data.Dismissal
import com.paperback.app.data.HomeSection
import com.paperback.app.data.HomeView
import com.paperback.app.data.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A PDF being turned into an EPUB: [page] of [total] read so far. */
data class ReflowState(val bookId: String, val page: Int, val total: Int, val ocr: Boolean = false)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val graph = (app as PaperbackApp).graph

    val books = graph.repo.books
    val sessions = graph.repo.sessions
    val rawSessions = graph.repo.rawSessions
    val collections = graph.repo.collections
    val membership = graph.repo.membership
    val allHighlights = graph.repo.allHighlights
    val savedWords = graph.repo.savedWords
    val lookups = graph.repo.lookups
    fun saveWord(w: com.paperback.app.data.SavedWord) { viewModelScope.launch { graph.repo.saveWord(w) } }
    fun removeWord(word: String) { viewModelScope.launch { graph.repo.removeWord(word) } }
    fun addLookup(word: String) { viewModelScope.launch { graph.repo.addLookup(word, "") } }
    val allBookmarks = graph.repo.allBookmarks

    /** Everything behind the Discover pages (catalogs, browsing, downloads). Lives here so a half-browsed catalog survives leaving the page. */
    val discover = DiscoverController(
        scope = viewModelScope,
        appScope = graph.appScope,
        http = graph.opdsHttp,
        store = graph.opdsStore,
        repo = graph.repo,
        cacheDir = app.cacheDir,
        say = { text -> say(text) },
    )

    /** The online side of Search: trending, recommendations, categories, book details. */
    val catalog = CatalogController(
        scope = viewModelScope,
        api = graph.catalogApi,
        prefs = graph.prefs,
        library = { books.value },
        wanted = { graph.wishlist.items.value },
        say = { text -> say(text) },
        sayUndo = { text, undo -> sayWithUndo(text, undo) },
        marks = { com.paperback.app.data.Implicit.highlightCounts(graph.repo.allHighlights.value) },
    )

    /** Catalog books you saved to read later. */
    val wishlist: StateFlow<List<CatalogBook>> = graph.wishlist.items
    fun toggleWishlist(book: CatalogBook) = graph.wishlist.toggle(book)
    fun wishlistAddedAt(id: String): Long = graph.wishlist.addedAt(id)
    fun removeFromWishlist(id: String) = graph.wishlist.remove(id)

    /** Looks up one book kept without a file in the catalog, for its cover and details. */
    fun findDetails(book: Book) {
        viewModelScope.launch {
            _message.value = "Looking for ${book.title}\u2026"
            _message.value = when (graph.enricher.one(book)) {
                com.paperback.app.data.EnrichOutcome.Found -> "Cover and details added to ${book.title}."
                com.paperback.app.data.EnrichOutcome.NotFound -> "Couldn't find ${book.title} in the online catalog."
                com.paperback.app.data.EnrichOutcome.Offline -> "Couldn't reach the online catalog. Check your connection and try again."
                com.paperback.app.data.EnrichOutcome.Disabled -> "The online catalog is switched off. Turn it on in Settings first."
            }
        }
    }

    init {
        // books kept without a file get their cover and details from the catalog, a few seconds after start
        viewModelScope.launch {
            kotlinx.coroutines.delay(4000)
            graph.enricher.run()
        }
        // a book leaves "Want to read" once you add it to the library
        viewModelScope.launch {
            books.collect { list ->
                if (list.isNotEmpty()) graph.wishlist.prune(list.mapTo(HashSet()) { TitleKey.of(it.title) })
            }
        }
    }

    // ---- app look and goals (Settings) ----------------------------------------------------

    val headerSize: StateFlow<HeaderSize> = graph.prefs.headerSize
    val navStyle: StateFlow<NavStyle> = graph.prefs.navStyle
    val moreStyle: StateFlow<MoreStyle> = graph.prefs.moreStyle
    val libraryShelf: StateFlow<Boolean> = graph.prefs.libraryShelf
    val libraryFrosted: StateFlow<Boolean> = graph.prefs.libraryFrosted
    val ledgeColor: StateFlow<Int> = graph.prefs.ledgeColor
    val openBookPage: StateFlow<Boolean> = graph.prefs.openBookPage
    fun setOpenBookPage(value: Boolean) = graph.prefs.setOpenBookPage(value)
    val swipeBack: StateFlow<Boolean> = graph.prefs.swipeBack
    val swipeTabs: StateFlow<Boolean> = graph.prefs.swipeTabs
    fun setSwipeBack(value: Boolean) = graph.prefs.setSwipeBack(value)
    fun setSwipeTabs(value: Boolean) = graph.prefs.setSwipeTabs(value)
    val ratingScale: StateFlow<Int> = graph.prefs.ratingScale
    val ratingSteps: StateFlow<Int> = graph.prefs.ratingSteps
    fun setRatingScale(value: Int) = graph.prefs.setRatingScale(value)
    fun setRatingSteps(value: Int) = graph.prefs.setRatingSteps(value)

    /** The reading timer (one book at a time). */
    val timer = graph.timer

    /** Saves a reading entry (id 0 = new) and reloads the history. */
    fun saveEntry(id: Long, bookId: String, startMs: Long, seconds: Int, pages: Int, fromPos: Int, toPos: Int) {
        viewModelScope.launch { graph.repo.saveEntry(id, bookId, startMs, seconds, pages, fromPos, toPos) }
    }

    fun deleteEntry(id: Long) {
        viewModelScope.launch { graph.repo.deleteEntry(id) }
    }
    val accent: StateFlow<Int> = graph.prefs.accent
    val themeMode: StateFlow<ThemeMode> = graph.prefs.themeMode
    val goals: StateFlow<Goals> = graph.prefs.goals

    /** The minutes goal saved for each past day (epoch day -> minutes), for the Goals page. */
    suspend fun goalDays(): Map<Long, Int> = graph.repo.goalDays()

    /** Every finished reading of every book (a re-read is a second one), for the Explore page. */
    suspend fun readings(): List<com.paperback.app.data.Reading> = graph.repo.readings()
    val readerSettings: ReaderSettings get() = graph.settings

    // ---- search ---------------------------------------------------------------------------

    private val _recentSearches = MutableStateFlow(graph.searchHistory.recent())
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    fun addRecentSearch(query: String) {
        _recentSearches.value = graph.searchHistory.add(query)
    }

    fun clearRecentSearches() {
        graph.searchHistory.clear()
        _recentSearches.value = emptyList()
    }

    fun setHeaderSize(value: HeaderSize) = graph.prefs.setHeaderSize(value)
    fun setAccent(argb: Int) = graph.prefs.setAccent(argb)
    fun setNavStyle(value: NavStyle) = graph.prefs.setNavStyle(value)
    fun setMoreStyle(value: MoreStyle) = graph.prefs.setMoreStyle(value)
    val goalStyle: StateFlow<GoalStyle> = graph.prefs.goalStyle
    fun setGoalStyle(value: GoalStyle) = graph.prefs.setGoalStyle(value)
    val statsHeader: StateFlow<com.paperback.app.data.StatsHeader> = graph.prefs.statsHeader
    fun setStatsHeader(value: com.paperback.app.data.StatsHeader) = graph.prefs.setStatsHeader(value)
    val activityStyle: StateFlow<com.paperback.app.data.ActivityStyle> = graph.prefs.activityStyle
    fun setActivityStyle(value: com.paperback.app.data.ActivityStyle) = graph.prefs.setActivityStyle(value)
    val appBackground: StateFlow<com.paperback.app.data.AppBackground> = graph.prefs.appBackground
    fun setAppBackground(value: com.paperback.app.data.AppBackground) = graph.prefs.setAppBackground(value)
    val statsBackground: StateFlow<com.paperback.app.data.StatsBackground> = graph.prefs.statsBackground
    fun setStatsBackground(value: com.paperback.app.data.StatsBackground) = graph.prefs.setStatsBackground(value)

    val iconStyle: StateFlow<IconStyle> = graph.prefs.iconStyle
    fun setIconStyle(value: IconStyle) {
        if (value == graph.prefs.iconStyle.value) return
        graph.prefs.setIconStyle(value)
        AppIcon.apply(getApplication(), value)
        say("${value.label} icon on. Your launcher may take a few seconds to show it.")
    }
    fun setLibraryShelf(value: Boolean) = graph.prefs.setLibraryShelf(value)
    fun setLibraryFrosted(value: Boolean) = graph.prefs.setLibraryFrosted(value)
    fun setLedgeColor(value: Int) = graph.prefs.setLedgeColor(value)
    val rhythmCalendar: StateFlow<Boolean> = graph.prefs.rhythmCalendar
    fun setRhythmCalendar(value: Boolean) = graph.prefs.setRhythmCalendar(value)
    /** Library suggestions you said "not interested" to (and online ones: all share the list). */
    val dismissed: StateFlow<List<Dismissal>> = graph.prefs.dismissed
    fun dismissRecommended(book: Book) {
        graph.prefs.dismiss(Dismissal(book.id, book.title, book.author, book.tags))
        sayWithUndo("Hidden from your suggestions.") { graph.prefs.undismiss(book.id) }
    }
    fun clearDismissed() = graph.prefs.clearDismissed()
    /** Subjects you asked to see less of in online suggestions. */
    val mutedSubjects: StateFlow<List<String>> = graph.prefs.mutedSubjects
    fun muteSubject(name: String) = graph.prefs.muteSubject(name)
    fun unmuteSubject(name: String) = graph.prefs.unmuteSubject(name)
    /** How far suggestions may go from your usual taste: 0 = not at all, 1 = a little, 2 = far. */
    val adventure: StateFlow<Int> = graph.prefs.adventure
    fun setAdventure(value: Int) = graph.prefs.setAdventure(value)
    val showRecommendations: StateFlow<Boolean> = graph.prefs.showRecommendations
    fun setShowRecommendations(value: Boolean) = graph.prefs.setShowRecommendations(value)
    val homePinned: StateFlow<List<com.paperback.app.data.PinnedStat>> = graph.prefs.homePinned
    fun setHomePinned(list: List<com.paperback.app.data.PinnedStat>) = graph.prefs.setHomePinned(list)
    val reminderMode: StateFlow<com.paperback.app.data.ReminderMode> = graph.prefs.reminderMode
    val reminderMinute: StateFlow<Int> = graph.prefs.reminderMinute
    val weeklySummary: StateFlow<Boolean> = graph.prefs.weeklySummary
    fun setWeeklySummary(on: Boolean) {
        graph.prefs.setWeeklySummary(on)
        val app = getApplication<Application>()
        graph.appScope.launch { com.paperback.app.reminder.Reminders.schedule(app, graph) }
    }

    /** Saves the reminder choice and sets (or clears) the alarm to match. */
    fun setReminder(mode: com.paperback.app.data.ReminderMode, minute: Int) {
        graph.prefs.setReminderMode(mode)
        graph.prefs.setReminderMinute(minute)
        val app = getApplication<Application>()
        graph.appScope.launch { com.paperback.app.reminder.Reminders.schedule(app, graph) }
    }
    val homeViews: StateFlow<Map<HomeSection, HomeView>> = graph.prefs.homeViews
    fun setHomeView(section: HomeSection, value: HomeView) = graph.prefs.setHomeView(section, value)
    fun setThemeMode(value: ThemeMode) = graph.prefs.setThemeMode(value)
    fun setGoals(value: Goals) = graph.prefs.setGoals(value)

    // ---- monthly recaps ----
    val recapGenerated: StateFlow<Set<String>> = graph.prefs.recapGenerated

    /** Which cards each Stats page shows and in what order (JSON, see StatsLayout). */
    val statsLayout: StateFlow<String> = graph.prefs.statsLayout
    fun setStatsLayout(json: String) = graph.prefs.setStatsLayout(json)

    /** Writes text to a file the person chose (an export), and says so. */
    fun writeText(uri: Uri, text: String, done: String) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt") ?: error("no output stream")
                    out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }.isSuccess
            }
            _message.value = if (ok) done else "Could not save the file."
        }
    }
    val recapRemind: StateFlow<Boolean> = graph.prefs.recapRemind
    val recapSnoozeUntil: StateFlow<Long> = graph.prefs.recapSnoozeUntil
    fun markRecapGenerated(key: String) = graph.prefs.addRecapGenerated(listOf(key))
    fun setRecapRemind(value: Boolean) = graph.prefs.setRecapRemind(value)
    fun snoozeRecap(untilMs: Long) = graph.prefs.snoozeRecap(untilMs)

    val contextPrompt: StateFlow<Boolean> = graph.prefs.contextPrompt
    val contextAskedId: StateFlow<Long> = graph.prefs.contextAskedId
    fun setContextPrompt(value: Boolean) = graph.prefs.setContextPrompt(value)
    fun dismissContext(sessionId: Long) = graph.prefs.setContextAskedId(sessionId)
    val recordSeenId: StateFlow<Long> = graph.prefs.recordSeenId
    fun dismissRecords(sessionId: Long) = graph.prefs.setRecordSeenId(sessionId)
    fun setBookPlan(id: String, deadlineMs: Long? = null, fiction: Int? = null) {
        viewModelScope.launch { graph.repo.setBookPlan(id, deadlineMs, fiction) }
    }
    fun saveSessionContext(sessionId: Long, place: Int, mood: Int) {
        graph.prefs.setContextAskedId(sessionId)
        viewModelScope.launch { graph.repo.setSessionContext(sessionId, place, mood) }
    }

    /** Shows a short message at the bottom of the screen. */
    fun say(text: String) {
        _message.value = text
    }

    /** A short message with an Undo button; [undo] runs if it is tapped. */
    class UndoMessage(val text: String, val undo: () -> Unit)

    private val _undoMessage = MutableStateFlow<UndoMessage?>(null)
    val undoMessage: StateFlow<UndoMessage?> = _undoMessage.asStateFlow()

    fun sayWithUndo(text: String, undo: () -> Unit) {
        _undoMessage.value = UndoMessage(text, undo)
    }

    fun consumeUndo() {
        _undoMessage.value = null
    }

    // ---- backup and restore ---------------------------------------------------------------

    private val _backupCounts = MutableStateFlow<BackupCounts?>(null)
    val backupCounts: StateFlow<BackupCounts?> = _backupCounts.asStateFlow()

    private val _pendingBackup = MutableStateFlow<PendingBackup?>(null)
    val pendingBackup: StateFlow<PendingBackup?> = _pendingBackup.asStateFlow()

    fun refreshBackupCounts() {
        viewModelScope.launch {
            _backupCounts.value = withContext(Dispatchers.IO) { Backup.currentCounts(graph.db) }
        }
    }

    /** Writes the backup file the person chose in the system file picker. */
    fun saveBackup(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val json = Backup.build(graph.db, graph.prefs, graph.settings, graph.wishlist)
                    val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                        ?: error("no output stream")
                    out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                }.isSuccess
            }
            _message.value = if (ok) "Backup saved." else "Could not save the backup file."
        }
    }

    /** Reads a backup file and waits for the person to confirm before anything changes. */
    fun readBackup(uri: Uri) {
        viewModelScope.launch {
            var note: String? = null
            val text = withContext(Dispatchers.IO) {
                runCatching {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { s ->
                        val bytes = s.readBytes()
                        if (!com.paperback.app.data.BookshelfImport.isZip(bytes)) bytes.toString(Charsets.UTF_8)
                        else {
                            // a Bookshelf export (zip of CSV files): turned into a backup, applied after you confirm
                            val r = com.paperback.app.data.BookshelfImport.convert(
                                bytes, graph.db.allBooks(), graph.db.allSessions(), graph.db.allHighlights(),
                                wishlistTitles = graph.wishlist.items.value.mapTo(HashSet()) { TitleKey.of(it.title) },
                                goals = graph.prefs.goals.value,
                            ).getOrElse { e -> throw IllegalArgumentException(e.message ?: "That zip could not be read as a Bookshelf export.") }
                            note = "From Bookshelf: ${r.newBooks} new books, ${r.sessions} sessions and ${r.quotes} quotes that you do not have yet" +
                                (if (r.skippedShelf > 0) ", ${r.skippedShelf} to-read books for Want to read" else "") +
                                (if (r.goalBooks != null) ", and a goal of ${r.goalBooks} books a year" else "") + "."
                            r.json
                        }
                    }
                }.getOrElse { e ->
                    if (e is IllegalArgumentException) { note = e.message; null } else null
                }
            }
            if (text == null) {
                _pendingBackup.value = null
                _message.value = note ?: "Could not read that file."
                return@launch
            }
            Backup.parse(text).fold(
                onSuccess = { _pendingBackup.value = it; note?.let { n -> _message.value = n } },
                onFailure = {
                    _pendingBackup.value = null
                    _message.value = it.message ?: "That file could not be read as a Paperback backup."
                },
            )
        }
    }

    fun cancelBackup() {
        _pendingBackup.value = null
    }

    fun applyBackup() {
        val pending = _pendingBackup.value ?: return
        viewModelScope.launch {
            val matched = withContext(Dispatchers.IO) {
                runCatching { Backup.restore(pending, graph.db, graph.prefs, graph.settings, graph.wishlist) }.getOrNull()
            }
            _pendingBackup.value = null
            if (matched == null) {
                _message.value = "The backup could not be restored."
            } else {
                graph.repo.refresh()
                refreshBackupCounts()
                // a restored backup may carry a reminder: set its alarm
                val app = getApplication<Application>()
                graph.appScope.launch { com.paperback.app.reminder.Reminders.schedule(app, graph) }
                _message.value = if (matched == 1) "Backup restored for 1 book." else "Backup restored for $matched books."
                // covers and details for the books that came without a file
                val filled = graph.enricher.run()
                if (filled > 0) _message.value = "Backup restored. Added covers and details to $filled books."
            }
        }
    }

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        // the minutes goal of each day is saved, so changing the goal later never rewrites the past
        viewModelScope.launch { goals.collect { g -> runCatching { graph.repo.recordGoalToday(g.minutesPerDay) } } }
        refresh()
        // Books added before genres existed get theirs read from the files, once, in the background.
        viewModelScope.launch { runCatching { graph.repo.backfillMeta() } }
        // ...and the same for word counts (a count you typed is never replaced)
        viewModelScope.launch { runCatching { graph.repo.backfillWords() } }
    }

    fun refresh() {
        viewModelScope.launch { graph.repo.refresh() }
    }

    fun consumeMessage() {
        _message.value = null
    }

    fun importBooks(uris: List<Uri>) {
        viewModelScope.launch {
            _busy.value = true
            var added = 0
            val problems = mutableListOf<String>()
            for (uri in uris) {
                when (val r = graph.repo.importBook(uri)) {
                    is ImportOutcome.Added -> added++
                    is ImportOutcome.Duplicate -> problems += "${r.name} is already in your library"
                    is ImportOutcome.Unsupported -> problems += "${r.name}: only EPUB and PDF for now"
                    is ImportOutcome.Failed -> problems += "Couldn't read ${r.name}"
                }
            }
            _busy.value = false
            _message.value = buildString {
                if (added > 0) append(if (added == 1) "Added 1 book" else "Added $added books")
                if (problems.isNotEmpty()) {
                    if (isNotEmpty()) append(". ")
                    append(problems.first())
                    if (problems.size > 1) append(" (+${problems.size - 1} more)")
                }
            }.ifEmpty { null }
        }
    }

    /** Prepares the reader, then calls [onReady] so the screen can start ReaderActivity. */
    /** Adds a catalog book to the library without a file, so it can be tracked like any other. */
    fun addWithoutFile(book: com.paperback.app.catalog.CatalogBook, pages: Int, tags: List<String>) {
        viewModelScope.launch {
            val cover = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.paperback.app.data.catalog.CatalogApi.coverUrl(book, "L")
                    ?.let { runCatching { graph.opdsHttp.getBytes(it, null) }.getOrNull() }
            }
            graph.repo.addLogOnly(book, pages, tags, cover)
            _message.value = "${book.title} is in your library without a file."
        }
    }

    fun open(book: Book, onReady: () -> Unit, startAtJson: String? = null) {
        if (_busy.value) return
        if (book.filePath.isBlank()) {
            _message.value = "${book.title} has no book file yet. Add the EPUB or PDF and everything you recorded moves to it."
            return
        }
        viewModelScope.launch {
            _busy.value = true
            val ok = graph.openReader(book, startAtJson)
            _busy.value = false
            if (ok) onReady() else _message.value = "Couldn't open ${book.title}"
        }
    }

    // ---- reflow a PDF as an EPUB ----------------------------------------------------------

    private val _reflow = MutableStateFlow<ReflowState?>(null)
    val reflow: StateFlow<ReflowState?> = _reflow.asStateFlow()
    private var reflowJob: Job? = null

    /** Converts [book] (a PDF) to a new EPUB book in the library. One at a time; keeps going if you leave the page. */
    fun reflowPdf(book: Book) {
        if (!book.isPdf) return
        if (reflowJob?.isActive == true) {
            _message.value = "Another book is being converted. Wait for it to finish."
            return
        }
        _reflow.value = ReflowState(book.id, 0, book.totalPositions.coerceAtLeast(1))
        reflowJob = graph.appScope.launch {
            val outcome = try {
                graph.repo.reflowPdf(book) { page, total, ocr -> _reflow.value = ReflowState(book.id, page, total, ocr) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                _reflow.value = null
                _message.value = "Conversion cancelled."
                return@launch
            }
            _reflow.value = null
            _message.value = when (outcome) {
                is ReflowOutcome.Done -> "Added \u201C${outcome.title}\u201D to your Library"
                is ReflowOutcome.Exists -> "This PDF has already been reflowed. It's in your Library."
                is ReflowOutcome.Failed -> outcome.message
            }
        }
    }

    fun cancelReflow() {
        reflowJob?.cancel()
    }

    /** Pauses, drops or resumes a book (BookStatus), remembering the percent you had read. */
    fun setStatus(bookId: String, status: Int) {
        viewModelScope.launch { graph.repo.setStatus(bookId, status) }
    }

    fun toggleFavorite(book: Book) {
        viewModelScope.launch { graph.repo.setFavorite(book.id, !book.favorite) }
    }

    fun toggleFinished(book: Book) {
        viewModelScope.launch { graph.repo.setFinished(book.id, !book.finished) }
    }

    fun remove(book: Book) {
        viewModelScope.launch { graph.repo.remove(book) }
    }

    fun rate(book: Book, stars: Int) {
        viewModelScope.launch { graph.repo.setRating(book.id, stars) }
    }

    /** [value] is on the 0..10 scale. */
    fun rate10(book: Book, value: Double) {
        viewModelScope.launch { graph.repo.setRating10(book.id, value) }
    }

    fun saveEdits(book: Book, edits: BookEdits) {
        viewModelScope.launch { graph.repo.applyEdits(book.id, edits) }
    }

    fun setCover(book: Book, uri: android.net.Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch { onDone(graph.repo.setCover(book.id, uri)) }
    }

    fun saveJournal(book: Book, text: String) {
        viewModelScope.launch { graph.repo.setJournal(book.id, text) }
    }

    // ---- collections ----------------------------------------------------------------------

    fun createCollection(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { graph.repo.createCollection(name) }
    }

    fun renameCollection(c: BookCollection, name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { graph.repo.renameCollection(c, name) }
    }

    fun deleteCollection(c: BookCollection) {
        viewModelScope.launch { graph.repo.deleteCollection(c.id) }
    }

    fun setMember(c: BookCollection, book: Book, member: Boolean) {
        viewModelScope.launch { graph.repo.setMember(c.id, book.id, member) }
    }

    // ---- notes ----------------------------------------------------------------------------

    fun markNotesSent(list: List<Highlight>) {
        viewModelScope.launch { graph.repo.markHighlightsSent(list.map { it.id }, System.currentTimeMillis()) }
    }

    fun deleteHighlight(h: Highlight) {
        viewModelScope.launch { graph.repo.deleteHighlight(h.id) }
    }

    fun deleteBookmark(b: Bookmark) {
        viewModelScope.launch { graph.repo.deleteBookmark(b.id) }
    }
}
