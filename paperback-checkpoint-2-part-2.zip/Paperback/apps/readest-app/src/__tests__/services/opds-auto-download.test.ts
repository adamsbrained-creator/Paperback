import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { Book } from '@/types/book';
import type { OPDSCatalog } from '@/types/opds';
import type { AppService } from '@/types/system';
import type { OPDSSubscriptionState, PendingItem } from '@/services/opds/types';

vi.mock('@/services/environment', () => ({
  isWebAppPlatform: vi.fn(() => false),
  isTauriAppPlatform: vi.fn(() => true),
  getAPIBaseUrl: () => '/api',
  getNodeAPIBaseUrl: () => '/node-api',
}));

vi.mock('@tauri-apps/plugin-http', () => ({
  fetch: vi.fn(),
}));

vi.mock('@/libs/storage', () => ({
  downloadFile: vi.fn().mockResolvedValue({ 'content-disposition': '' }),
}));

vi.mock('@/app/opds/utils/opdsReq', () => ({
  fetchWithAuth: vi.fn(),
  probeAuth: vi.fn().mockResolvedValue(null),
  needsProxy: vi.fn(() => false),
  getProxiedURL: vi.fn((url: string) => url),
  probeFilename: vi.fn().mockResolvedValue(''),
}));

vi.mock('@/services/opds/feedChecker', () => ({
  checkFeedForNewItems: vi.fn().mockResolvedValue([]),
}));

vi.mock('@/services/opds/sourceMap', () => ({
  upsertOPDSSourceMapping: vi.fn().mockResolvedValue(undefined),
  findBookByOPDSSources: vi.fn().mockResolvedValue(null),
}));

vi.mock('@/services/opds/cover', () => ({
  applyOPDSCover: vi.fn().mockResolvedValue(true),
}));

vi.mock('@/services/opds/subscriptionState', () => ({
  loadSubscriptionState: vi.fn().mockResolvedValue({
    catalogId: 'cat-1',
    lastCheckedAt: 0,
    knownEntryIds: [],
    failedEntries: [],
  }),
  saveSubscriptionState: vi.fn().mockResolvedValue(undefined),
  pruneKnownEntryIds: vi.fn((ids: string[]) => ids),
  emptyState: vi.fn((id: string) => ({
    catalogId: id,
    lastCheckedAt: 0,
    knownEntryIds: [],
    failedEntries: [],
  })),
}));

import { syncSubscribedCatalogs } from '@/services/opds/autoDownload';
import { checkFeedForNewItems } from '@/services/opds/feedChecker';
import { saveSubscriptionState, loadSubscriptionState } from '@/services/opds/subscriptionState';
import { upsertOPDSSourceMapping } from '@/services/opds/sourceMap';
import { applyOPDSCover } from '@/services/opds/cover';
import { downloadFile } from '@/libs/storage';
import { MAX_RETRY_ATTEMPTS, PERSIST_BATCH_SIZE } from '@/services/opds/types';

const createMockAppService = () =>
  ({
    resolveFilePath: vi.fn(async (path: string) => `/cache/${path}`),
    importBook: vi.fn(async () => ({
      hash: 'abc123',
      format: 'EPUB',
      title: 'Test Book',
      author: 'Author',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    })),
    copyFile: vi.fn(async () => {}),
    deleteFile: vi.fn(async () => {}),
    exists: vi.fn(async () => false),
    readFile: vi.fn(async () => '{}'),
    writeFile: vi.fn(async () => {}),
    createDir: vi.fn(async () => {}),
  }) as unknown as AppService;

describe('OPDS auto-download orchestrator', () => {
  let appService: AppService;

  beforeEach(() => {
    vi.clearAllMocks();
    appService = createMockAppService();
  });

  it('skips catalogs without autoDownload enabled', async () => {
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Test', url: 'https://example.com/opds' },
    ];
    const result = await syncSubscribedCatalogs(catalogs, appService, []);
    expect(result.totalNewBooks).toBe(0);
    expect(checkFeedForNewItems).not.toHaveBeenCalled();
  });

  it('skips disabled catalogs even with autoDownload', async () => {
    const catalogs: OPDSCatalog[] = [
      {
        id: 'cat-1',
        name: 'Test',
        url: 'https://example.com/opds',
        autoDownload: true,
        disabled: true,
      },
    ];
    const result = await syncSubscribedCatalogs(catalogs, appService, []);
    expect(result.totalNewBooks).toBe(0);
  });

  it('downloads new items and returns them', async () => {
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];

    const pendingItems: PendingItem[] = [
      {
        entryId: 'urn:shelf:1',
        title: 'Issue 1',
        acquisitionHref: '/dl/1.epub',
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      },
    ];
    vi.mocked(checkFeedForNewItems).mockResolvedValue(pendingItems);

    const result = await syncSubscribedCatalogs(catalogs, appService, []);
    expect(result.totalNewBooks).toBe(1);
    expect(result.newBooks).toHaveLength(1);
    expect(saveSubscriptionState).toHaveBeenCalled();

    const savedState = vi.mocked(saveSubscriptionState).mock.calls[0]![1] as OPDSSubscriptionState;
    expect(savedState.knownEntryIds).toContain('urn:shelf:1');
    expect(savedState.lastCheckedAt).toBeGreaterThan(0);
    expect(upsertOPDSSourceMapping).toHaveBeenCalledWith(appService, {
      catalogId: 'cat-1',
      sourceUrl: 'https://shelf.example.com/dl/1.epub',
      bookHash: 'abc123',
    });
  });

  it('downloads with skipSslVerification like the manual download path', async () => {
    // The manual OPDS download (page.tsx handleDownload) passes
    // skipSslVerification as a workaround for self-signed/private-CA OPDS
    // servers (#2871): the native download_file validates TLS with rustls,
    // which ignores the OS trust store, while the feed fetch and auth probe
    // go through the http plugin with acceptInvalidCerts. Without the same
    // flag here, auto-download dies in the TLS handshake on servers where
    // manual download works (#4988).
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];
    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:shelf:1',
        title: 'Issue 1',
        acquisitionHref: '/dl/1.epub',
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      },
    ]);

    await syncSubscribedCatalogs(catalogs, appService, []);

    expect(downloadFile).toHaveBeenCalledTimes(1);
    expect(vi.mocked(downloadFile).mock.calls[0]![0]).toMatchObject({
      skipSslVerification: true,
    });
  });

  it('applies the feed-provided cover to the imported book (issue #5270)', async () => {
    const catalogs: OPDSCatalog[] = [
      {
        id: 'cat-1',
        name: 'Shelf',
        url: 'https://shelf.example.com/opds',
        autoDownload: true,
        username: 'user',
        password: 'pass',
      },
    ];
    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:shelf:1',
        title: 'Issue 1',
        acquisitionHref: '/dl/1.epub',
        coverHref: '/cwa/opds/cover/572',
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      },
    ]);

    const result = await syncSubscribedCatalogs(catalogs, appService, []);

    expect(applyOPDSCover).toHaveBeenCalledWith(
      expect.objectContaining({
        appService,
        book: result.newBooks[0],
        coverUrl: 'https://shelf.example.com/cwa/opds/cover/572',
        username: 'user',
        password: 'pass',
      }),
    );
  });

  it('skips the cover step for entries without artwork', async () => {
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];
    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:shelf:1',
        title: 'Issue 1',
        acquisitionHref: '/dl/1.epub',
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      },
    ]);

    const result = await syncSubscribedCatalogs(catalogs, appService, []);
    expect(result.totalNewBooks).toBe(1);
    expect(applyOPDSCover).not.toHaveBeenCalled();
  });

  it('still imports the book when the feed cover cannot be fetched', async () => {
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];
    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:shelf:1',
        title: 'Issue 1',
        acquisitionHref: '/dl/1.epub',
        coverHref: '/cwa/opds/cover/572',
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      },
    ]);
    vi.mocked(applyOPDSCover).mockRejectedValueOnce(new Error('cover server down'));

    const result = await syncSubscribedCatalogs(catalogs, appService, []);
    expect(result.totalNewBooks).toBe(1);
  });

  it('handles import failure by adding to failedEntries', async () => {
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Test', url: 'https://example.com/opds', autoDownload: true },
    ];

    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:fail:1',
        title: 'Bad Book',
        acquisitionHref: '/dl/bad.epub',
        mimeType: 'application/epub+zip',
        baseURL: 'https://example.com',
      },
    ]);
    (appService.importBook as ReturnType<typeof vi.fn>).mockRejectedValue(
      new Error('corrupt file'),
    );

    const result = await syncSubscribedCatalogs(catalogs, appService, []);
    expect(result.totalNewBooks).toBe(0);

    const savedState = vi.mocked(saveSubscriptionState).mock.calls[0]![1] as OPDSSubscriptionState;
    expect(savedState.failedEntries).toHaveLength(1);
    expect(savedState.failedEntries[0]!.entryId).toBe('urn:fail:1');
    expect(savedState.failedEntries[0]!.attempts).toBe(1);
    expect(savedState.knownEntryIds).not.toContain('urn:fail:1');
  });

  it('returns empty result when no catalogs have autoDownload', async () => {
    const result = await syncSubscribedCatalogs([], appService, []);
    expect(result).toEqual({ newBooks: [], totalNewBooks: 0, errors: [] });
  });

  it('does not re-attempt or duplicate an in-backoff failed entry that reappears in the feed', async () => {
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Test', url: 'https://example.com/opds', autoDownload: true },
    ];

    // Entry X failed once, very recently — well within the backoff window,
    // so isRetryEligible() returns false.
    vi.mocked(loadSubscriptionState).mockResolvedValueOnce({
      catalogId: 'cat-1',
      lastCheckedAt: 0,
      knownEntryIds: [],
      failedEntries: [
        {
          entryId: 'urn:backoff:1',
          href: '/dl/x.epub',
          title: 'Backed-off Book',
          attempts: 1,
          lastAttemptAt: Date.now(), // freshly attempted, still in backoff
        },
      ],
    });

    // The entry is still in the feed (not in knownEntryIds), so discovery
    // returns it again.
    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:backoff:1',
        title: 'Backed-off Book',
        acquisitionHref: '/dl/x.epub',
        mimeType: 'application/epub+zip',
        baseURL: 'https://example.com/opds',
      },
    ]);

    await syncSubscribedCatalogs(catalogs, appService, []);

    // No download should have been attempted while in backoff.
    expect(downloadFile).not.toHaveBeenCalled();

    // And the saved state must not contain duplicate failedEntries for the
    // same entryId.
    const savedState = vi
      .mocked(saveSubscriptionState)
      .mock.calls.at(-1)![1] as OPDSSubscriptionState;
    const ids = savedState.failedEntries.map((fe) => fe.entryId);
    expect(ids).toEqual(Array.from(new Set(ids)));
    expect(savedState.failedEntries.filter((fe) => fe.entryId === 'urn:backoff:1')).toHaveLength(1);
  });

  it('does not download the same entry twice when it is both pending and a retry-eligible failure', async () => {
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Test', url: 'https://example.com/opds', autoDownload: true },
    ];

    vi.mocked(loadSubscriptionState).mockResolvedValueOnce({
      catalogId: 'cat-1',
      lastCheckedAt: 0,
      knownEntryIds: [],
      failedEntries: [
        {
          entryId: 'urn:dup:1',
          href: '/dl/dup.epub',
          title: 'Dup Book',
          attempts: 1,
          lastAttemptAt: 0, // far in the past, retry eligible
        },
      ],
    });

    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:dup:1',
        title: 'Dup Book',
        acquisitionHref: '/dl/dup.epub',
        mimeType: 'application/epub+zip',
        baseURL: 'https://example.com/opds',
      },
    ]);

    await syncSubscribedCatalogs(catalogs, appService, []);

    expect(downloadFile).toHaveBeenCalledTimes(1);
  });

  // The module-level loadSubscriptionState mock resolves one SHARED state
  // object that earlier tests' runs mutate (knownEntryIds grows across
  // tests); these tests need a pristine state per call.
  const freshStatePerLoad = () => {
    vi.mocked(loadSubscriptionState).mockImplementation(async (_appService, catalogId) => ({
      catalogId,
      lastCheckedAt: 0,
      knownEntryIds: [],
      failedEntries: [],
    }));
  };

  it('persists imported books before recording their entries as known (#5658)', async () => {
    // Once an entry lands in knownEntryIds it is never downloaded again, so
    // the library rows must be on disk first — a kill between the two writes
    // must lose at most the "already known" marker, never the books.
    freshStatePerLoad();
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];
    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:shelf:1',
        title: 'Issue 1',
        acquisitionHref: '/dl/1.epub',
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      },
    ]);

    const callOrder: string[] = [];
    const onBooksImported = vi.fn(async (books: Book[]) => {
      expect(books).toHaveLength(1);
      callOrder.push('persist-library');
    });
    vi.mocked(saveSubscriptionState).mockImplementation(async () => {
      callOrder.push('save-state');
    });

    const result = await syncSubscribedCatalogs(catalogs, appService, [], onBooksImported);

    expect(result.totalNewBooks).toBe(1);
    expect(onBooksImported).toHaveBeenCalledTimes(1);
    expect(callOrder).toEqual(['persist-library', 'save-state']);
  });

  it('does not record entries as known when persisting the library fails', async () => {
    freshStatePerLoad();
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];
    vi.mocked(checkFeedForNewItems).mockResolvedValue([
      {
        entryId: 'urn:shelf:1',
        title: 'Issue 1',
        acquisitionHref: '/dl/1.epub',
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      },
    ]);

    const onBooksImported = vi.fn(async () => {
      throw new Error('disk full');
    });

    const result = await syncSubscribedCatalogs(catalogs, appService, [], onBooksImported);

    // The catalog run fails and is surfaced, and the entry stays unknown so
    // the next sync retries the download (imports are idempotent).
    expect(result.errors).toHaveLength(1);
    for (const call of vi.mocked(saveSubscriptionState).mock.calls) {
      expect((call[1] as OPDSSubscriptionState).knownEntryIds).not.toContain('urn:shelf:1');
    }
  });

  // Regression (large first sync on memory-constrained devices): a catalog with
  // many entries must persist progress WHILE downloading, not only after every
  // item has resolved. Android's low-memory killer terminates the app partway
  // through a several-hundred-book first sync; if state is written only at the
  // end, every completed import is discarded and the next run restarts from
  // zero, so the sync can never converge no matter how often it is retried.
  it('persists progress incrementally during a large sync', async () => {
    freshStatePerLoad();
    const TOTAL = PERSIST_BATCH_SIZE * 3;
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];
    const pendingItems: PendingItem[] = Array.from({ length: TOTAL }, (_, i) => ({
      entryId: `urn:shelf:${i}`,
      title: `Book ${i}`,
      acquisitionHref: `/dl/${i}.epub`,
      mimeType: 'application/epub+zip',
      baseURL: 'https://shelf.example.com/opds',
    }));
    vi.mocked(checkFeedForNewItems).mockResolvedValue(pendingItems);

    let completed = 0;
    const completedAtSave: number[] = [];
    const knownAtSave: number[] = [];
    vi.mocked(downloadFile).mockImplementation(async () => {
      completed += 1;
      return { 'content-disposition': '' };
    });
    vi.mocked(saveSubscriptionState).mockImplementation(async (_appService, state) => {
      completedAtSave.push(completed);
      knownAtSave.push(state.knownEntryIds.length);
    });

    await syncSubscribedCatalogs(catalogs, appService, []);

    // On the unbatched implementation there is a single save at item TOTAL, so
    // a kill at item N loses all N. Bounding the loss means one save per batch,
    // the first landing as soon as a batch's worth of items has resolved.
    expect(completedAtSave).toEqual([PERSIST_BATCH_SIZE, PERSIST_BATCH_SIZE * 2, TOTAL]);
    // Each save has to carry the entries earned so far, not an empty marker.
    expect(knownAtSave).toEqual([PERSIST_BATCH_SIZE, PERSIST_BATCH_SIZE * 2, TOTAL]);
  });

  it('still reports books from batches committed before a later batch failed', async () => {
    // Once a batch is persisted its entries are in knownEntryIds, so no later
    // sync rediscovers them. Dropping those books with the exception would
    // mean they are never queued for cloud upload — they are already on disk,
    // so they have to reach the caller even though the catalog run failed.
    freshStatePerLoad();
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];
    vi.mocked(checkFeedForNewItems).mockResolvedValue(
      Array.from({ length: PERSIST_BATCH_SIZE * 2 }, (_, i) => ({
        entryId: `urn:shelf:${i}`,
        title: `Book ${i}`,
        acquisitionHref: `/dl/${i}.epub`,
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      })),
    );
    vi.mocked(saveSubscriptionState).mockResolvedValue(undefined);
    const onBooksImported = vi
      .fn<(books: Book[]) => Promise<void>>()
      .mockResolvedValueOnce(undefined)
      .mockRejectedValueOnce(new Error('disk full'));

    const result = await syncSubscribedCatalogs(catalogs, appService, [], onBooksImported);

    expect(result.errors).toHaveLength(1);
    expect(result.newBooks).toHaveLength(PERSIST_BATCH_SIZE);
  });

  it('keeps counting retry attempts for an entry in a later persist batch', async () => {
    // Retry items are appended after the freshly-discovered ones, so on a
    // large catalog they land past the first batch boundary. The attempt
    // counter must still come from the state as it was loaded: reading
    // `state.failedEntries` again after batch 1 has reassigned it would see
    // an array that no longer holds the retry-eligible originals, reset the
    // count to 1, and retry the entry forever instead of giving up at
    // MAX_RETRY_ATTEMPTS.
    vi.mocked(loadSubscriptionState).mockImplementation(async (_appService, catalogId) => ({
      catalogId,
      lastCheckedAt: 0,
      knownEntryIds: [],
      failedEntries: [
        {
          entryId: 'urn:shelf:doomed',
          href: '/dl/doomed.epub',
          title: 'Doomed Book',
          attempts: MAX_RETRY_ATTEMPTS - 1,
          lastAttemptAt: 0, // far in the past, retry eligible
        },
      ],
    }));
    const catalogs: OPDSCatalog[] = [
      { id: 'cat-1', name: 'Shelf', url: 'https://shelf.example.com/opds', autoDownload: true },
    ];
    // A full first batch of healthy entries pushes the retry item into the second.
    vi.mocked(checkFeedForNewItems).mockResolvedValue(
      Array.from({ length: PERSIST_BATCH_SIZE }, (_, i) => ({
        entryId: `urn:shelf:${i}`,
        title: `Book ${i}`,
        acquisitionHref: `/dl/${i}.epub`,
        mimeType: 'application/epub+zip',
        baseURL: 'https://shelf.example.com/opds',
      })),
    );
    vi.mocked(downloadFile).mockImplementation(async ({ url }) => {
      if (url?.includes('doomed.epub')) throw new Error('still unreachable');
      return { 'content-disposition': '' };
    });

    await syncSubscribedCatalogs(catalogs, appService, []);

    const savedState = vi
      .mocked(saveSubscriptionState)
      .mock.calls.at(-1)![1] as OPDSSubscriptionState;
    // Third strike: permanently skipped, not queued for a fourth attempt.
    expect(savedState.failedEntries.map((fe) => fe.entryId)).not.toContain('urn:shelf:doomed');
    expect(savedState.knownEntryIds).toContain('urn:shelf:doomed');
  });
});
