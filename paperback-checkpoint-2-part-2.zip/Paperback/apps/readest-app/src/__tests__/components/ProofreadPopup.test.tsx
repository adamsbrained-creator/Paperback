import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor, cleanup } from '@testing-library/react';
import { EnvProvider } from '@/context/EnvContext';
import ProofreadPopup from '@/app/reader/components/annotator/ProofreadPopup';
import { useReaderStore } from '@/store/readerStore';
import { eventDispatcher } from '@/utils/event';

vi.mock('@/services/environment', async () => {
  const actual = await vi.importActual('@/services/environment');

  const mockAppService = {
    init: vi.fn().mockResolvedValue(undefined),
    // EnvProvider's mount effect calls appService.loadSettings() to seed
    // replica sync. Returning a settings object without replicaDeviceId
    // makes init early-exit cleanly (no warn, no real network).
    loadSettings: vi.fn().mockResolvedValue({}),
    // Add any other methods from AppService interface
  };

  return {
    ...actual,
    default: {
      getAppService: vi.fn().mockResolvedValue(mockAppService),
    },
  };
});

global.ResizeObserver = class ResizeObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
};

// A real Range over one text node -- the shape a selection rule needs, since
// the transformer replays it by splicing inside a single node.
const singleNodeRange = (text: string, start: number, end: number): Range => {
  const p = document.createElement('p');
  const node = document.createTextNode(text);
  p.appendChild(node);
  document.body.appendChild(p);
  const range = document.createRange();
  range.setStart(node, start);
  range.setEnd(node, end);
  return range;
};

function renderWithProviders(ui: React.ReactNode) {
  return render(<EnvProvider>{ui}</EnvProvider>);
}

describe('ProofreadPopup Component', () => {
  const mockOnConfirm = vi.fn();
  const mockOnClose = vi.fn();

  const defaultProps = {
    bookKey: 'test-book',
    isVertical: false,
    selectedText: 'test word',
    selection: {
      key: 'test-book',
      text: 'test word',
      cfi: 'epubcfi(/6/2[chapter1]!/4/1:0)',
      index: 0,
      range: singleNodeRange('test word here', 5, 9),
      page: 1,
    },
    position: { point: { x: 100, y: 100 } },
    trianglePosition: { point: { x: 100, y: 100 } },
    popupWidth: 440,
    popupHeight: 200,
    onConfirm: mockOnConfirm,
    onDismiss: mockOnClose,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    // Applying a selection rule now edits the text node for real, so every
    // test needs its own range instead of sharing one across the file.
    defaultProps.selection.range = singleNodeRange('test word here', 5, 9);
  });

  afterEach(() => {
    cleanup();
  });

  describe('Rendering', () => {
    it('should render default replacement scope options', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      expect(screen.getByText('Current selection')).toBeTruthy();
    });

    it('should render the replacement text input field', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const input = screen.getByPlaceholderText('Enter text...');
      expect(input).toBeTruthy();
    });

    it('should render the case sensitive checkbox', () => {
      const { container } = renderWithProviders(<ProofreadPopup {...defaultProps} />);

      expect(screen.getByText('Case sensitive:')).toBeTruthy();
      expect(container.querySelector('input[type="checkbox"]')).toBeTruthy();
    });

    it('should render the Apply button', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      expect(screen.getByText('Apply')).toBeTruthy();
    });

    it('should display selected text preview', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      expect(screen.getByText(/Selected text:/)).toBeTruthy();
      expect(screen.getByText(/"test word"/)).toBeTruthy();
    });
  });

  describe('Case Sensitive Checkbox', () => {
    it('should be checked by default (case-sensitive)', () => {
      const { container } = renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const checkbox = container.querySelector('input[type="checkbox"]') as HTMLInputElement;
      expect(checkbox.checked).toBe(true);
    });

    it('should toggle when clicked', async () => {
      const { container } = renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const checkbox = container.querySelector('input[type="checkbox"]') as HTMLInputElement;
      expect(checkbox.checked).toBe(true);

      fireEvent.click(checkbox);
      expect(checkbox.checked).toBe(false);

      fireEvent.click(checkbox);
      expect(checkbox.checked).toBe(true);
    });
  });

  describe('Replacement Text Input', () => {
    it('should update value when user types', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const input = screen.getByPlaceholderText('Enter text...') as HTMLInputElement;
      fireEvent.change(input, { target: { value: 'new text' } });

      expect(input.value).toBe('new text');
    });

    it('should trim whitespace from replacement text', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const input = screen.getByPlaceholderText('Enter text...');
      fireEvent.change(input, { target: { value: '  trimmed  ' } });

      const confirmButton = screen.getByText('Apply');
      fireEvent.click(confirmButton);

      expect(mockOnConfirm).toHaveBeenCalledWith(
        expect.objectContaining({
          replacement: 'trimmed',
        }),
      );
    });
  });

  describe('Scope Selection Handlers', () => {
    beforeEach(() => {
      vi.clearAllMocks();
    });

    const createValidSelection = () => ({
      ...defaultProps,
      selection: {
        ...defaultProps.selection,
        text: 'word',
        cfi: 'epubcfi(/6/4[chap01ref]!/4/2/1:0)',
        range: singleNodeRange('test word here', 5, 9),
      },
    });

    it('should call onConfirm with correct scope for "selection"', async () => {
      renderWithProviders(<ProofreadPopup {...createValidSelection()} />);

      const input = screen.getByPlaceholderText('Enter text...');
      fireEvent.change(input, { target: { value: 'replacement' } });

      const applyButton = screen.getByText('Apply');
      fireEvent.click(applyButton);

      await waitFor(() => {
        expect(mockOnConfirm).toHaveBeenCalledWith(expect.objectContaining({ scope: 'selection' }));
      });
    });

    it('should call onConfirm with correct scope for "book"', async () => {
      renderWithProviders(<ProofreadPopup {...createValidSelection()} />);

      const input = screen.getByPlaceholderText('Enter text...');
      fireEvent.change(input, { target: { value: 'replacement' } });

      const scopeSelect = screen.getByRole('combobox');
      fireEvent.change(scopeSelect, { target: { value: 'book' } });

      const applyButton = screen.getByText('Apply');
      fireEvent.click(applyButton);

      await waitFor(() => {
        expect(mockOnConfirm).toHaveBeenCalledWith(expect.objectContaining({ scope: 'book' }));
      });
    });

    it('should call onConfirm with correct scope for "library"', async () => {
      renderWithProviders(<ProofreadPopup {...createValidSelection()} />);

      const input = screen.getByPlaceholderText('Enter text...');
      fireEvent.change(input, { target: { value: 'replacement' } });

      const scopeSelect = screen.getByRole('combobox');
      fireEvent.change(scopeSelect, { target: { value: 'library' } });

      const applyButton = screen.getByText('Apply');
      fireEvent.click(applyButton);

      await waitFor(() => {
        expect(mockOnConfirm).toHaveBeenCalledWith(expect.objectContaining({ scope: 'library' }));
      });
    });
  });

  describe('Regex Toggle', () => {
    it('should render the regex checkbox (off by default)', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const regexLabel = screen.getByText('Regex:');
      expect(regexLabel).toBeTruthy();
      const checkbox = regexLabel
        .closest('label')!
        .querySelector('input[type="checkbox"]') as HTMLInputElement | null;
      expect(checkbox).toBeTruthy();
      expect(checkbox!.checked).toBe(false);
    });

    it('should call onConfirm with isRegex true when regex is enabled', async () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const regexLabel = screen.getByText('Regex:');
      const regexCheckbox = regexLabel
        .closest('label')!
        .querySelector('input[type="checkbox"]') as HTMLInputElement;
      fireEvent.click(regexCheckbox);

      const input = screen.getByPlaceholderText('Enter text...');
      fireEvent.change(input, { target: { value: 'replacement' } });

      const applyButton = screen.getByText('Apply');
      fireEvent.click(applyButton);

      await waitFor(() => {
        expect(mockOnConfirm).toHaveBeenCalledWith(expect.objectContaining({ isRegex: true }));
      });
    });

    it('should default isRegex to false when the toggle is left off', async () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const input = screen.getByPlaceholderText('Enter text...');
      fireEvent.change(input, { target: { value: 'replacement' } });

      const applyButton = screen.getByText('Apply');
      fireEvent.click(applyButton);

      await waitFor(() => {
        expect(mockOnConfirm).toHaveBeenCalledWith(expect.objectContaining({ isRegex: false }));
      });
    });
  });

  /**
   * `Popup` caps the popup at the space available above the selection. When the
   * selection sits near the top of the viewport that cap can be shorter than the
   * form, and with `overflow: visible` the excess simply painted outside the
   * rounded box: the scope row (the last child) hung past the bottom edge.
   *
   * Invariant: the scope row is pinned outside the scrollable region, so the
   * upper content absorbs any shortfall and the scope select stays reachable.
   */
  describe('Constrained Popup Height', () => {
    it('pins the scope row outside the scrollable region so it cannot overflow', () => {
      const { container } = renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const select = container.querySelector('select') as HTMLSelectElement;
      const scopeRow = select.closest('div') as HTMLElement;
      expect(scopeRow.className).toContain('shrink-0');

      const scrollArea = container.querySelector('.overflow-y-auto');
      expect(scrollArea).not.toBeNull();
      expect(scrollArea!.contains(select)).toBe(false);
    });

    it('clips the popup surface so no child paints past the rounded box', () => {
      const { container } = renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const popup = container.querySelector('.popup-container') as HTMLElement;
      expect(popup.className).toContain('overflow-hidden');
    });
  });

  describe('Click Outside Behavior', () => {
    it('should not call onClose when clicking inside the menu', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      const input = screen.getByPlaceholderText('Enter text...');
      fireEvent.mouseDown(input);

      expect(mockOnClose).not.toHaveBeenCalled();
    });
  });

  describe('Manage Replacement Rules Shortcut', () => {
    it('should not render manage button when onManage is not provided', () => {
      renderWithProviders(<ProofreadPopup {...defaultProps} />);

      expect(screen.queryByLabelText('Proofread Replacement Rules')).toBeNull();
    });

    it('should render manage button and invoke onManage when provided', () => {
      const mockOnManage = vi.fn();
      renderWithProviders(<ProofreadPopup {...defaultProps} onManage={mockOnManage} />);

      const button = screen.getByLabelText('Proofread Replacement Rules');
      expect(button).toBeTruthy();

      fireEvent.click(button);
      expect(mockOnManage).toHaveBeenCalledTimes(1);
    });
  });

  describe('Section Anchoring', () => {
    // The transformer matches a selection rule against the spine item href it
    // is handed on every section load (foliate's `detail.name`). `progress`
    // carries the TOC href instead, which points at the nearest preceding nav
    // entry -- the same file only when every spine item has its own TOC entry.
    // Storing the TOC href left the rule unmatched on reload, so it applied
    // once (the popup edits the live DOM) and never again (#6148).
    it('anchors a selection rule to the spine href, not the TOC href', async () => {
      const restore = useReaderStore.getState();
      useReaderStore.setState({
        getProgress: () => ({ sectionHref: 'OEBPS/Text/contents.xhtml' }) as never,
        getView: () => ({ book: { sections: [{ id: 'OEBPS/Text/ch1.xhtml' }] } }) as never,
      });
      try {
        renderWithProviders(
          <ProofreadPopup
            {...defaultProps}
            selection={{ ...defaultProps.selection, text: 'word', index: 0 }}
          />,
        );

        fireEvent.change(screen.getByPlaceholderText('Enter text...'), {
          target: { value: 'replacement' },
        });
        fireEvent.click(screen.getByText('Apply'));

        await waitFor(() => {
          expect(mockOnConfirm).toHaveBeenCalledWith(
            expect.objectContaining({
              scope: 'selection',
              sectionHref: 'OEBPS/Text/ch1.xhtml',
            }),
          );
        });
      } finally {
        useReaderStore.setState(restore);
      }
    });
  });

  describe('Live Document Edit', () => {
    const rangeOver = (host: HTMLElement, node: Text, start: number, end: number) => {
      document.body.appendChild(host);
      const range = document.createRange();
      range.setStart(node, start);
      range.setEnd(node, end);
      return range;
    };

    it('splices the replacement in place and leaves neighbouring markup alone', async () => {
      const p = document.createElement('p');
      p.innerHTML = 'Hello <em>brave</em> world';
      const tail = p.lastChild as Text; // ' world'
      const range = rangeOver(p, tail, 1, 6);
      expect(range.toString()).toBe('world');

      renderWithProviders(
        <ProofreadPopup
          {...defaultProps}
          selection={{ ...defaultProps.selection, text: 'world', range }}
        />,
      );

      fireEvent.change(screen.getByPlaceholderText('Enter text...'), {
        target: { value: 'planet' },
      });
      fireEvent.click(screen.getByText('Apply'));

      await waitFor(() => {
        expect(mockOnConfirm).toHaveBeenCalled();
      });
      expect(p.innerHTML).toBe('Hello <em>brave</em> planet');
      // deleteContents() + insertNode() also split the text node in two, which
      // shifts the text-node indices every later CFI in the section counts on.
      expect(p.childNodes.length).toBe(3);
    });

    it('splices the same trimmed text the rule will persist', async () => {
      // The rule stores the trimmed replacement, so an untrimmed live edit
      // would show text this session that no later replay reproduces.
      const p = document.createElement('p');
      p.innerHTML = 'Hello <em>brave</em> world';
      const tail = p.lastChild as Text;
      const range = rangeOver(p, tail, 1, 6);

      renderWithProviders(
        <ProofreadPopup
          {...defaultProps}
          selection={{ ...defaultProps.selection, text: 'world', range }}
        />,
      );

      fireEvent.change(screen.getByPlaceholderText('Enter text...'), {
        target: { value: '  planet  ' },
      });
      fireEvent.click(screen.getByText('Apply'));

      await waitFor(() => {
        expect(mockOnConfirm).toHaveBeenCalledWith(
          expect.objectContaining({ replacement: 'planet' }),
        );
      });
      expect(p.innerHTML).toBe('Hello <em>brave</em> planet');
    });

    it('refuses a selection rule the transformer could never replay', async () => {
      const toast = vi.spyOn(eventDispatcher, 'dispatch');
      const p = document.createElement('p');
      p.innerHTML = 'Hello <em>brave</em> world';
      document.body.appendChild(p);
      const range = document.createRange();
      range.setStart(p.firstChild as Text, 0);
      range.setEnd(p.lastChild as Text, 6);

      renderWithProviders(
        <ProofreadPopup
          {...defaultProps}
          selection={{ ...defaultProps.selection, text: 'Hello brave world', range }}
        />,
      );

      fireEvent.change(screen.getByPlaceholderText('Enter text...'), {
        target: { value: 'hi' },
      });
      fireEvent.click(screen.getByText('Apply'));

      await waitFor(() => {
        expect(toast).toHaveBeenCalledWith('toast', expect.objectContaining({ type: 'warning' }));
      });
      expect(mockOnConfirm).not.toHaveBeenCalled();
      expect(p.innerHTML).toBe('Hello <em>brave</em> world');
    });
  });
});
