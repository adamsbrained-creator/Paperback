package com.paperback.app.reader

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.ReaderLook
import com.paperback.app.ui.PbSlider
import com.paperback.app.ui.theme.PbSerif
import kotlin.math.roundToInt

private fun tenth(v: Float): Float = (v * 10f).roundToInt() / 10f

@Composable
private fun Section(c: ReaderColors, label: String, value: String? = null, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f), color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (value != null) Text(value, color = c.ink.copy(alpha = 0.6f), fontSize = 13.sp)
        }
        Spacer(Modifier.height(6.dp))
        content()
    }
}

/**
 * Margins, layout (book's own or custom: font, line spacing, alignment) and brightness. Used by the reader's
 * text sheet and by Settings → Reader defaults (without brightness, which only makes sense while reading).
 * Colours come from [c], so it matches the page theme in both places.
 */
@Composable
fun ReaderLookControls(
    look: ReaderLook,
    onChange: (ReaderLook) -> Unit,
    c: ReaderColors,
    showBrightness: Boolean,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Section(c, "Margins", "${(look.margins * 100).roundToInt()}%") {
            PbSlider(
                value = look.margins,
                onValueChange = { onChange(look.copy(margins = tenth(it))) },
                valueRange = 0.5f..2.5f,
                trackColor = c.ink.copy(alpha = 0.15f),
            )
        }
        Section(c, "Top and bottom space", "${(look.verticalSpace * 100).roundToInt()}%") {
            PbSlider(
                value = look.verticalSpace,
                onValueChange = { onChange(look.copy(verticalSpace = tenth(it))) },
                valueRange = 0f..1.5f,
                trackColor = c.ink.copy(alpha = 0.15f),
            )
        }
        Section(c, "Layout") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(c, "Book's own", selected = !look.custom) { onChange(look.copy(custom = false)) }
                Pill(c, "Custom", selected = look.custom) { onChange(look.copy(custom = true)) }
                Pill(c, "Readest", selected = false) { onChange(ReaderLook.readest(look.brightness)) }
            }
        }
        if (look.custom) {
            Section(c, "Font") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Serif", "Sans", "Mono").forEachIndexed { i, name ->
                        Pill(c, name, selected = look.fontFamily == i) { onChange(look.copy(fontFamily = i)) }
                    }
                }
            }
            Section(c, "Line spacing", "%.1f".format(look.lineSpacing)) {
                PbSlider(
                    value = look.lineSpacing,
                    onValueChange = { onChange(look.copy(lineSpacing = tenth(it))) },
                    valueRange = 1.0f..2.2f,
                    trackColor = c.ink.copy(alpha = 0.15f),
                )
            }
            Section(c, "Paragraph spacing", "%.1f".format(look.paragraphSpacing)) {
                PbSlider(
                    value = look.paragraphSpacing,
                    onValueChange = { onChange(look.copy(paragraphSpacing = tenth(it))) },
                    valueRange = 0f..2f,
                    trackColor = c.ink.copy(alpha = 0.15f),
                )
            }
            Section(c, "First-line indent", "%.1f".format(look.indent)) {
                PbSlider(
                    value = look.indent,
                    onValueChange = { onChange(look.copy(indent = tenth(it))) },
                    valueRange = 0f..3f,
                    trackColor = c.ink.copy(alpha = 0.15f),
                )
            }
            Section(c, "Alignment") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(c, "Left", selected = !look.justify) { onChange(look.copy(justify = false)) }
                    Pill(c, "Justified", selected = look.justify) { onChange(look.copy(justify = true)) }
                }
            }
        }
        if (showBrightness) {
            val auto = look.brightness < 0f
            Section(c, "Brightness", if (auto) "Same as phone" else "${(look.brightness * 100).roundToInt()}%") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PbSlider(
                        value = if (auto) 0.5f else look.brightness,
                        onValueChange = { onChange(look.copy(brightness = it.coerceIn(0.05f, 1f))) },
                        valueRange = 0.05f..1f,
                        trackColor = c.ink.copy(alpha = 0.15f),
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Pill(c, "Auto", selected = auto) { onChange(look.copy(brightness = -1f)) }
                }
            }
        }
    }
}

/**
 * The "Text" sheet at the bottom of the reader. It sits over the page without dimming it, so every change is
 * visible straight away.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderLookSheet(
    themeIndex: Int,
    themeChoice: Int,
    fontSize: Double,
    look: ReaderLook,
    onFontSize: (Double) -> Unit,
    onTheme: (Int) -> Unit,
    onLook: (ReaderLook) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = readerColors(themeIndex)
    BackHandler(onBack = onClose)
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(c.card)
            // swallow touches so nothing reaches the book underneath
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
            .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
            .heightIn(max = 520.dp)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Reader settings",
                modifier = Modifier.weight(1f),
                color = c.ink,
                fontFamily = PbSerif,
                fontSize = 22.sp,
                fontWeight = FontWeight.Medium,
            )
            Pill(c, "Done", onClick = onClose)
        }
        Section(c, "Font size", "${(fontSize * 100).roundToInt()}%") {
            PbSlider(
                value = fontSize.toFloat(),
                onValueChange = { onFontSize(tenth(it).toDouble()) },
                valueRange = 0.6f..2.5f,
                trackColor = c.ink.copy(alpha = 0.15f),
            )
        }
        Section(c, "Page colors") {
            ThemePickerRow(c, themeChoice, onTheme)
        }
        ReaderLookControls(look = look, onChange = onLook, c = c, showBrightness = true)
        Box(Modifier.height(4.dp))
    }
}
