package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Bar
import com.paperback.app.data.Book
import com.paperback.app.data.Highlight
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.StatNames
import com.paperback.app.data.Stats
import com.paperback.app.data.commas
import com.paperback.app.data.timeOfDayName
import com.paperback.app.data.wordsText
import com.paperback.app.data.yearChange
import com.paperback.app.data.yearReview
import com.paperback.app.data.yearShareText
import com.paperback.app.data.yearsWithReading
import com.paperback.app.ui.theme.pbTokens
import java.time.ZoneId

/**
 * Stats -> Year: your year in review. Pick a year; every card can be hidden or moved with Customize.
 * Share sends a short text summary through the share sheet.
 */
@Composable
fun YearScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    highlights: List<Highlight>,
    onOpenBook: (Book) -> Unit,
    onShareText: (String) -> Unit,
    statsLayout: String = "",
    onStatsLayout: (String) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val zone = remember { ZoneId.systemDefault() }
    val years = remember(books, sessions) { yearsWithReading(books, sessions, zone) }

    if (years.isEmpty()) {
        Box(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("No year to review yet", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("Your year in review appears once you have read.", color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        }
        return
    }

    var chosen by rememberSaveable { mutableStateOf(years.first()) }
    val year = if (chosen in years) chosen else years.first()
    val review = remember(year, books, sessions, highlights) { yearReview(year, books, sessions, highlights, zone) }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            years.forEach { y -> TogglePill(y.toString(), year == y) { chosen = y } }
        }

        val r = review
        if (r == null) {
            Text("Nothing logged in $year.", color = t.setSub, fontSize = 14.sp, modifier = Modifier.padding(20.dp))
            return@Column
        }

        val cards = ArrayList<StatCard>()
        fun card(key: String, title: String, content: @Composable () -> Unit) {
            cards.add(StatCard(key, title, content))
        }

        card("hero", "${r.year} at a glance") {
            YrCard("${r.year} at a glance") {
                TileRow(
                    { m -> StatTile("Time", StatsAccent.Blue, m, null, "${Stats.duration(r.seconds)} read") { BigNumber(Stats.duration(r.seconds)) } },
                    { m -> StatTile("Books", StatsAccent.Mint, m, null, "${r.booksFinished} books finished") { BigNumber(r.booksFinished.toString()) } },
                )
                Spacer(Modifier.height(10.dp))
                TileRow(
                    { m -> StatTile("Pages", StatsAccent.Pink, m, null, "${r.pages} pages") { BigNumber(commas(r.pages)) } },
                    { m -> StatTile("Days read", StatsAccent.Yellow, m, null, "${r.readingDays} days read") { BigNumber(r.readingDays.toString()) } },
                )
                val prev = r.previous
                if (prev != null) {
                    Spacer(Modifier.height(10.dp))
                    yearChange(r.seconds, prev.seconds)?.let { YrFact("Time", it) }
                    yearChange(r.pages.toLong(), prev.pages.toLong())?.let { YrFact("Pages", it) }
                    if (prev.books > 0) YrFact("Books", "${r.booksFinished} against ${prev.books} in ${prev.year}")
                    if (prev.days > 0) YrFact("Reading days", "${r.readingDays} against ${prev.days}")
                }
            }
        }

        card("reading", "How you read") {
            YrCard("How you read") {
                YrFact("Sessions", r.sessions.toString())
                if (r.words > 0) YrFact("Words read", wordsText(r.words))
                if (r.listenedSeconds > 0) YrFact("Listened", Stats.duration(r.listenedSeconds))
                r.avgStars?.let { YrFact("Average rating of books finished", "%.1f".format(it) + "\u2605") }
                if (r.fiveStars > 0) YrFact("Five-star books", r.fiveStars.toString())
            }
        }

        if (r.topGenres.isNotEmpty()) card("genres", "Top genres") {
            YrCard("Top genres") { YrBars(r.topGenres, StatsAccent.Pink) }
        }
        if (r.topAuthors.isNotEmpty()) card("authors", "Top authors") {
            YrCard("Top authors") { YrBars(r.topAuthors, StatsAccent.Yellow) }
        }
        if (r.topLanguages.size > 1) card("languages", "Languages") {
            YrCard("Languages") { YrBars(r.topLanguages, StatsAccent.Blue) }
        }

        card("rhythm", "Streak and best day") {
            YrCard("Streak and best day") {
                if (r.longestStreak > 0) {
                    val start = r.streakStart
                    YrFact(
                        "Longest streak",
                        "${r.longestStreak} ${if (r.longestStreak == 1) "day" else "days"}" +
                            (if (start != null && r.longestStreak > 1) " from ${start.dayOfMonth} ${StatNames.MONTHS_SHORT[start.monthValue - 1]}" else ""),
                    )
                }
                r.busiestDay?.let { (d, secs) ->
                    YrFact("Busiest day", "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]} \u00B7 ${Stats.duration(secs)}")
                }
                r.favoriteHour?.let { YrFact("Favorite time", "${timeOfDayName(it).lowercase()}, around ${"%02d".format(it)}:00") }
            }
        }

        card("months", "Month by month") {
            YrCard("Month by month") {
                Text("Books finished", color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                YrMonthBars(r.booksPerMonth.map { it.toDouble() }, r.booksPerMonth.map { it.toString() }, StatsAccent.Mint)
                Spacer(Modifier.height(12.dp))
                Text("Time read", color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                YrMonthBars(
                    r.secondsPerMonth.map { it.toDouble() },
                    r.secondsPerMonth.map { if (it >= 3600L) "${it / 3600}h" else if (it >= 60L) "${it / 60}m" else "" },
                    StatsAccent.Blue,
                )
            }
        }

        val fast = r.fastest
        val slow = r.slowest
        if (fast != null || slow != null) card("pace", "Fastest and slowest finish") {
            YrCard("Fastest and slowest finish") {
                fast?.let { YrBookFact("Fastest", it.book, if (it.days == 1) "1 day" else "${it.days} days", onOpenBook) }
                slow?.let { if (slow.book.id != fast?.book?.id) YrBookFact("Slowest", it.book, if (it.days == 1) "1 day" else "${it.days} days", onOpenBook) }
            }
        }

        val longest = r.longestBook
        val shortest = r.shortestBook
        if (longest != null) card("sizes", "Longest and shortest book") {
            YrCard("Longest and shortest book") {
                YrBookFact("Longest", longest, "${longest.pageCount} pages", onOpenBook)
                if (shortest != null && shortest.id != longest.id) YrBookFact("Shortest", shortest, "${shortest.pageCount} pages", onOpenBook)
            }
        }

        r.mostMarkedUp?.let { (book, n) ->
            card("marked", "Most highlighted book") {
                YrCard("Most highlighted book") {
                    if (book != null) YrBookFact("Book", book, "$n highlights", onOpenBook) else YrFact("Removed book", "$n highlights")
                }
            }
        }

        if (r.finished.isNotEmpty()) card("finished", "Books of the year") {
            YrCard("Books of the year") {
                r.finished.forEach { b ->
                    Row(Modifier.fillMaxWidth().clickable { onOpenBook(b) }.padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(b.title, color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        val stars = com.paperback.app.data.ratingStars(b)
                        if (stars > 0) Text("$stars\u2605", color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
                    }
                }
            }
        }

        card("share", "Share this year") {
            YrCard("Share this year") {
                Text("Sends a short summary of your ${r.year} as text.", color = t.setSub, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Row { ActionPill("Share", { onShareText(yearShareText(r)) }) }
            }
        }

        CardList("year", cards, statsLayout, onStatsLayout, Modifier.weight(1f))
    }
}

// ---- pieces ------------------------------------------------------------------------------------

@Composable
private fun YrCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 18.dp)) {
        CardLabel(title)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun YrFact(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.setSub, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(1.3f))
    }
}

@Composable
private fun YrBookFact(label: String, book: Book, value: String, onOpenBook: (Book) -> Unit) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth().clickable { onOpenBook(book) }.padding(vertical = 5.dp)) {
        Text(label.uppercase(), color = t.setSub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(book.title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text(value, color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
        }
    }
}

@Composable
private fun YrBars(bars: List<Bar>, color: Color) {
    val t = pbTokens()
    val max = (bars.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(0.000001)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        bars.forEach { bar ->
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(bar.label, color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Text(if (bar.sub.isEmpty()) bar.text else "${bar.text} \u00B7 ${bar.sub}", color = t.setSub, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 10.dp))
                }
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(t.ink.copy(alpha = 0.08f))) {
                    val fraction = (bar.value / max).toFloat().coerceIn(0f, 1f)
                    if (fraction > 0f) Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(color))
                }
            }
        }
    }
}

/** Twelve columns, January to December; [labels] are written above each one (empty = nothing). */
@Composable
private fun YrMonthBars(values: List<Double>, labels: List<String>, color: Color) {
    val t = pbTokens()
    val max = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    Row(Modifier.fillMaxWidth().height(110.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { i, v ->
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                val label = labels.getOrElse(i) { "" }
                if (label.isNotEmpty() && v > 0.0) Text(label, color = t.ink, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(if (v <= 0.0) 3.dp else (64.dp * (v / max).toFloat()).coerceAtLeast(4.dp))
                        .clip(RoundedCornerShape(5.dp))
                        .background(if (v > 0.0) color else t.ink.copy(alpha = 0.08f)),
                )
                Spacer(Modifier.height(4.dp))
                Text(StatNames.MONTHS_SHORT[i].take(1), color = t.setSub, fontSize = 10.sp)
            }
        }
    }
}
