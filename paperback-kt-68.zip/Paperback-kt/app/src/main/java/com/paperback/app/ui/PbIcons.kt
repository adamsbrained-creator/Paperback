package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Paperback's icon set, copied from components/paperback/icons.tsx: a 24 px grid, 1.9 px stroke, round caps
 * and joins. The path strings are the same ones the TypeScript app draws, so the icons are identical.
 * [solid] is the shape that fills in for the active state.
 */
enum class PbIconName(val d: String, val solid: String? = null) {
    Home("M4 11l8-7 8 7 M6 10v10h12V10", "M4 11l8-7 8 7 M6 10v10h12V10"),
    Discover("M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 1 0 0-17z M15.5 8.5l-2 5-5 2 2-5z"),
    Collections("M4 8l8-4 8 4-8 4z M4 12l8 4 8-4 M4 16l8 4 8-4", "M4 8l8-4 8 4-8 4z"),
    Bookmark("M7 4h10v16l-5-4-5 4z", "M7 4h10v16l-5-4-5 4z"),
    Stats("M5 20v-8 M12 20V5 M19 20v-5"),
    Settings("M4 7h9 M17 7h3 M15 5a2 2 0 1 0 0 4 2 2 0 1 0 0-4z M4 17h3 M11 17h9 M9 15a2 2 0 1 0 0 4 2 2 0 1 0 0-4z"),
    Theme(
        "M12 3 a9 9 0 1 0 0 18 c1.4 0 2 -1 1.5 -2.2 c-0.5 -1.2 0.2 -2.3 1.5 -2.3 H17 a4 4 0 0 0 4 -4 c0 -5 -4 -9.5 -9 -9.5 z M7.5 11 h0.01 M10 7 h0.01 M15 7.5 h0.01",
    ),
    Search("M11 4.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 1 0 0-13z M16 16l4.5 4.5"),
    AppStyle("M4 7 a3 3 0 0 1 3 -3 h10 a3 3 0 0 1 3 3 v10 a3 3 0 0 1 -3 3 H7 a3 3 0 0 1 -3 -3 z M4 10 h16 M8 7 h5"),
    Goals("M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 1 0 0-17z M12 8a4 4 0 1 0 0 8 4 4 0 1 0 0-8z M12 12 h0.01"),
    Backup("M7 18 a4 4 0 0 1 0 -8 a5 5 0 0 1 9.6 -1 A4.5 4.5 0 0 1 17 18 z M12 16 v-5 M9.5 13.5 L12 11 l2.5 2.5"),
    About("M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 1 0 0-17z M12 11v5 M12 8 h0.01"),
    Menu("M4 7h16 M4 12h10 M4 17h14"),
    MenuLines("M5 7h14 M5 12h14 M5 17h14"),
    Close("M6 6l12 12 M18 6L6 18"),
    Dots("M5 12 h0.01 M12 12 h0.01 M19 12 h0.01"),
    Library("M5 4v16 M10 4v16 M14 5.5l4.5 14"),
    Reader("M5 4 h11 a3 3 0 0 1 3 3 v13 H8 a3 3 0 0 1 -3 -3 z M5 17 a3 3 0 0 1 3 -3 h11"),
    ImportFile("M12 4v11 M7.5 10.5L12 15l4.5-4.5 M5 19h14"),
    Plus("M12 5v14 M5 12h14"),
    CaretRight("M9 5l7 7-7 7"),
    CaretLeft("M15 5l-7 7 7 7"),
    Star("M12 3.6l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.9l6-.8z", "M12 3.6l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.9l6-.8z"),
    Note("M6 3.5h9l3.5 3.5v13.5H6z M14.5 3.5V7.5H18.5 M9 12h6 M9 16h6"),
    Edit("M4 20l1-4.2L16.3 4.5a2.1 2.1 0 0 1 3 3L8 18.8z M14.5 6.3l3 3"),
    // Added for the More page.
    Book("M2.5 5.5 c3 -1.3 6.5 -1 9.5 1.5 c3 -2.5 6.5 -2.8 9.5 -1.5 V19 c-3 -1.3 -6.5 -1 -9.5 1.5 C9 18 5.5 17.7 2.5 19 z M12 7 v13.5"),
    Clock("M12 3 a9 9 0 1 0 0 18 9 9 0 1 0 0 -18 z M12 7.5 V12 l3 2"),
    Check("M12 3 a9 9 0 1 0 0 18 9 9 0 1 0 0 -18 z M8 12.5 l3 3 5 -6"),
    Person("M12 4 a4 4 0 1 0 0 8 4 4 0 1 0 0 -8 z M4.5 20.5 c0.5 -3.8 3.6 -6 7.5 -6 s7 2.2 7.5 6"),
    Heart("M12 20 s-7.5 -4.5 -7.5 -10.2 A4.2 4.2 0 0 1 12 7.5 a4.2 4.2 0 0 1 7.5 2.3 C19.5 15.5 12 20 12 20 z"),
    ListPlus("M4 6 h11 M4 12 h7 M4 18 h7 M17 13 v7 M13.5 16.5 h7"),
    Tag("M3.5 12.5 v-8 a1 1 0 0 1 1 -1 h8 L21 12 l-8.5 8.5 z M8 8.5 h0.01"),
    Dictionary("M6 3 h11 a2 2 0 0 1 2 2 v16 H7.5 A2.5 2.5 0 0 1 5 18.5 V4 a1 1 0 0 1 1 -1 z M9 8 h6 M5 18.5 A2.5 2.5 0 0 1 7.5 16 H19"),
    History("M3.5 12 a8.5 8.5 0 1 0 2.5 -6 M3.5 4.5 v4 h4 M12 8 v4.5 l3 1.5"),
    CaretDown("M5 9 l7 7 7 -7"),
    CaretUp("M5 15 l7 -7 7 7"),
    // Added for the reader's quick controls.
    Sun("M12 8 a4 4 0 1 0 0 8 4 4 0 1 0 0 -8 z M12 3 v2 M12 19 v2 M3 12 h2 M19 12 h2 M5.6 5.6 l1.4 1.4 M17 17 l1.4 1.4 M5.6 18.4 l1.4 -1.4 M17 7 l1.4 -1.4"),
    Chapters("M9 6 h11 M9 12 h11 M9 18 h11 M4.5 6 h0.01 M4.5 12 h0.01 M4.5 18 h0.01"),
    // Added for the Milestones page (same paths as the TypeScript app's stats icons).
    Flame("M12 3c1 3.2 4.5 4.8 4.5 9a4.5 4.5 0 0 1-9 0c0-1.7.7-3 1.8-4 .2 1.3.9 2 1.7 2.2C11 8.5 11.2 5.5 12 3z"),
    Quote("M9 7H5v5h4v3a3 3 0 0 1-3 3 M19 7h-4v5h4v3a3 3 0 0 1-3 3"),
    Trophy("M8 21h8 M12 17v4 M7 4h10v5a5 5 0 0 1-10 0V4z M7 6H4v1.5A3.5 3.5 0 0 0 7 11 M17 6h3v1.5A3.5 3.5 0 0 1 17 11"),
    Timer("M4 13a8 8 0 1 0 16 0 8 8 0 1 0-16 0 M12 9v4l2 2 M9 2h6"),
    Stack("M12 3l9 5-9 5-9-5z M3 13l9 5 9-5"),
    Tick("M4 12.5 L9.5 18 L20 6.5"),
    // Added for read aloud.
    Headphones("M4 17 v-5 a8 8 0 0 1 16 0 v5 M4 14 h3 a1 1 0 0 1 1 1 v4 a1 1 0 0 1 -1 1 H6 a2 2 0 0 1 -2 -2 z M20 14 h-3 a1 1 0 0 0 -1 1 v4 a1 1 0 0 0 1 1 h1 a2 2 0 0 0 2 -2 z"),
    Play("M8 5 v14 l11 -7 z", "M8 5 v14 l11 -7 z"),
    Pause("M8 5 v14 M16 5 v14", "M7 5 h3 v14 H7 z M14 5 h3 v14 h-3 z"),
    SkipPrev("M7 5 v14 M19 5 L9 12 l10 7 z", "M7 5 v14 M19 5 L9 12 l10 7 z"),
    SkipNext("M17 5 v14 M5 5 l10 7 -10 7 z", "M17 5 v14 M5 5 l10 7 -10 7 z"),
    DoubleLeft("M12 6 l-6 6 6 6 M19 6 l-6 6 6 6"),
    DoubleRight("M5 6 l6 6 -6 6 M12 6 l6 6 -6 6"),
    Alarm("M12 7 a7 7 0 1 0 0 14 7 7 0 1 0 0 -14 z M12 10 v4 l2.5 1.5 M4 7 l3 -3 M20 7 l-3 -3"),
    Voice("M12 4 a3 3 0 0 0 -3 3 v5 a3 3 0 0 0 6 0 V7 a3 3 0 0 0 -3 -3 z M6 11 v1 a6 6 0 0 0 12 0 v-1 M12 18 v3"),
    PauseAfter("M5 12 h6 M14 6 v12 M19 6 v12"),
    // Added for the monthly recaps.
    Calendar("M5 5 h14 a1 1 0 0 1 1 1 v13 a1 1 0 0 1 -1 1 H5 a1 1 0 0 1 -1 -1 V6 a1 1 0 0 1 1 -1 z M4 10 h16 M8 3 v4 M16 3 v4"),
    Share("M18 8 a3 3 0 1 0 0 -6 3 3 0 0 0 0 6 z M6 15 a3 3 0 1 0 0 -6 3 3 0 0 0 0 6 z M18 22 a3 3 0 1 0 0 -6 3 3 0 0 0 0 6 z M8.6 13.5 l6.8 4 M15.4 6.5 l-6.8 4"),
    Sparkle("M12 3 l1.8 5.2 L19 10 l-5.2 1.8 L12 17 l-1.8 -5.2 L5 10 l5.2 -1.8 z M19 16 l0.7 2 2 0.7 -2 0.7 -0.7 2 -0.7 -2 -2 -0.7 2 -0.7 z"),
    Trend("M3 17 l6 -6 4 4 8 -8 M15 7 h6 v6"),
    DoubleCheck("M2 12.5 l4.5 4.5 L14 8 M9 14 l2 2 L19 8"),
}

/** One icon. [size] is the drawn size; the icon scales from its 24 px grid. */
@Composable
fun PbIcon(
    name: PbIconName,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    tint: Color = LocalContentColor.current,
    filled: Boolean = false,
    strokeWidth: Float? = null,
    contentDescription: String? = null,
) {
    val line = remember(name) { PathParser().parsePathString(name.d).toPath() }
    val solid = remember(name) { name.solid?.let { PathParser().parsePathString(it).toPath() } }
    val sw = strokeWidth ?: if (filled && name.solid == null) 2.6f else 1.9f
    val described = if (contentDescription != null) {
        modifier.semantics { this.contentDescription = contentDescription }
    } else {
        modifier
    }
    Canvas(described.size(size)) {
        scale(this.size.width / 24f, pivot = Offset.Zero) {
            if (filled && solid != null) drawPath(solid, tint, style = Fill)
            drawPath(line, tint, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}
