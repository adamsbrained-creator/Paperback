package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.BacklogFigures
import com.paperback.app.data.Bar
import com.paperback.app.data.Book
import com.paperback.app.data.BookStatus
import com.paperback.app.data.Goals
import com.paperback.app.data.Highlight
import com.paperback.app.data.Reading
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.droppedFigures
import com.paperback.app.data.minutesText
import com.paperback.app.data.fictionSplit
import com.paperback.app.data.genreExplorer
import com.paperback.app.data.noteStreak
import com.paperback.app.data.booksCsv
import com.paperback.app.data.reReadFigures
import com.paperback.app.data.sessionsCsv
import com.paperback.app.data.statsJson
import com.paperback.app.data.StatNames
import com.paperback.app.data.Stats
import com.paperback.app.data.allTime
import com.paperback.app.data.authorsOf
import com.paperback.app.data.broadGenresOf
import com.paperback.app.data.booksAddedPerMonth
import com.paperback.app.data.chapterFigures
import com.paperback.app.data.favoriteFigures
import com.paperback.app.data.formatBars
import com.paperback.app.data.journalFigures
import com.paperback.app.data.monthCompare
import com.paperback.app.data.quoteOfTheDay
import com.paperback.app.data.recentlyAdded
import com.paperback.app.data.recentlyFinished
import com.paperback.app.data.seriesRows
import com.paperback.app.data.sourceBars
import com.paperback.app.data.backlogFigures
import com.paperback.app.data.booksPerMonth
import com.paperback.app.data.booksPerYear
import com.paperback.app.data.breakFigures
import com.paperback.app.data.commas
import com.paperback.app.data.completionFigures
import com.paperback.app.data.finishFigures
import com.paperback.app.data.genresOf
import com.paperback.app.data.idleBooks
import com.paperback.app.data.languageOf
import com.paperback.app.data.lengthFigures
import com.paperback.app.data.lengthSpread
import com.paperback.app.data.noteFigures
import com.paperback.app.data.pageFigures
import com.paperback.app.data.publicationFigures
import com.paperback.app.data.ratingFigures
import com.paperback.app.data.timeBars
import com.paperback.app.data.timeSplit
import com.paperback.app.data.yearCompare
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Stats -> Explore: the deeper numbers. Time by genre, author and language, listened vs read, pages, days to
 * finish, books per month and year, this year against last, session lengths, breaks, ratings, book lengths,
 * publication years, completion, the pile of unread books, books gone quiet, and notes.
 * Every card hides itself until there is something to show.
 */
@Composable
fun ExploreScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    goals: Goals,
    highlights: List<Highlight>,
    onOpenBook: (Book) -> Unit,
    /** Pause, drop or resume a book: [BookStatus]. */
    onSetStatus: (bookId: String, status: Int) -> Unit,
    /** Every finished reading of every book, for the re-reads card. */
    loadReadings: suspend () -> List<Reading> = { emptyList() },
    /** The saved card layout (JSON) and how to change it; Customize on this page edits it. */
    statsLayout: String = "",
    onStatsLayout: (String) -> Unit = {},
    /** Saves a file the person picks: file name, MIME type and text. */
    onExport: (fileName: String, mime: String, text: String) -> Unit = { _, _, _ -> },
    /** Collections and who is in them, and the Want to read list with the day each was saved. */
    collections: List<com.paperback.app.data.BookCollection> = emptyList(),
    membership: Map<String, Set<String>> = emptyMap(),
    wishlist: List<com.paperback.app.catalog.CatalogBook> = emptyList(),
    wishlistAddedAt: (String) -> Long = { 0L },
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val zone = remember { ZoneId.systemDefault() }
    val today = remember { LocalDate.now() }

    if (books.isEmpty() && sessions.isEmpty()) {
        Box(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Nothing to explore yet", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("Read a little and these numbers fill in.", color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        }
        return
    }

    val split = remember(sessions) { timeSplit(sessions) }
    val byGenre = remember(sessions, books) { timeBars(sessions, books, 8, ::genresOf) }
    val byAuthor = remember(sessions, books) { timeBars(sessions, books, 8, ::authorsOf) }
    val byLanguage = remember(sessions, books) { timeBars(sessions, books, 6, ::languageOf) }
    val pages = remember(sessions, books) { pageFigures(sessions, books, today, zone) }
    val finish = remember(sessions, books) { finishFigures(books, sessions, zone) }
    val years = remember(books) { booksPerYear(books, zone) }
    val compare = remember(sessions, books) { yearCompare(sessions, books, today, zone) }
    val spread = remember(sessions) { lengthSpread(sessions) }
    val breaks = remember(sessions) { breakFigures(sessions, today, zone) }
    val ratings = remember(books) { ratingFigures(books) }
    val lengths = remember(books) { lengthFigures(books) }
    val publication = remember(books) { publicationFigures(books) }
    val completion = remember(books) { completionFigures(books) }
    val backlog = remember(books, sessions) { backlogFigures(books, sessions, today, zone) }
    val idle = remember(books, sessions) { idleBooks(books, sessions, today, zone) }
    val notes = remember(highlights, books) { noteFigures(highlights, books, today, zone) }
    var year by rememberSaveable { mutableStateOf(today.year) }
    var grouped by rememberSaveable { mutableStateOf(true) }
    val readings by produceState(emptyList<Reading>(), books) {
        value = try {
            loadReadings()
        } catch (e: Exception) {
            emptyList()
        }
    }
    val fiction = remember(books, sessions) { fictionSplit(books, sessions) }
    val explorer = remember(books, sessions) { genreExplorer(books, sessions) }
    val reReads = remember(readings, books) { reReadFigures(readings, books) }
    val droppedRep = remember(books) { droppedFigures(books) }
    val noteRun = remember(highlights) { noteStreak(highlights, today, zone) }
    val byBroadGenre = remember(sessions, books) { timeBars(sessions, books, 8, ::broadGenresOf) }
    val formats = remember(books, sessions) { formatBars(books, sessions) }
    val sources = remember(books) { sourceBars(books) }
    val series = remember(books) { seriesRows(books) }
    val chapters = remember(sessions, books) { chapterFigures(sessions, books) }
    val months2 = remember(sessions, books) { monthCompare(sessions, books, today, zone) }
    val totals = remember(sessions, books) { allTime(sessions, books, zone) }
    val added = remember(books) { recentlyAdded(books) }
    val finishedRecent = remember(books) { recentlyFinished(books) }
    val favorites = remember(books) { favoriteFigures(books) }
    val quote = remember(highlights) { quoteOfTheDay(highlights, today) }
    val journals = remember(books) { journalFigures(books) }
    val streakRuns = remember(sessions) { com.paperback.app.data.streakHistory(sessions, today, zone) }
    val collectionStats = remember(collections, membership, books, sessions) { com.paperback.app.data.collectionRows(collections, membership, books, sessions) }
    val wishMix = remember(wishlist) { com.paperback.app.data.wishlistMix(wishlist, wishlistAddedAt, today, zone) }

    val byId = remember(books) { books.associateBy { it.id } }
    fun open(bar: Bar) { bar.bookId?.let { id -> byId[id]?.let(onOpenBook) } }

    val cards = ArrayList<StatCard>()
    fun card(key: String, title: String, content: @Composable () -> Unit) {
        cards.add(StatCard(key, title, content))
    }
    run {
        // quote of the day
        quote?.let { q ->
            card("quote", "Quote of the day") {
                val qb = byId[q.bookId]
                ExCard("Quote of the day") {
                    Text("\u201C${q.text.trim().take(320)}\u201D", color = t.ink, fontSize = 16.sp, lineHeight = 24.sp, fontFamily = com.paperback.app.ui.theme.PbSerif)
                    if (q.note.isNotBlank()) Text(q.note.trim().take(200), color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        qb?.title ?: "Removed book", color = t.setSub, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                        modifier = if (qb != null) Modifier.clickable { onOpenBook(qb) } else Modifier,
                    )
                }
            }
        }

        // everything so far
        if (totals.books > 0 || totals.seconds > 0) card("alltime", "All time") {
            ExCard("All time") {
                TileRow(
                    { m -> StatTile("Books", StatsAccent.Pink, m, null, "${totals.books} books, ${totals.finished} finished") { BigNumber(totals.books.toString()) } },
                    { m -> StatTile("Days read", StatsAccent.Mint, m, null, "${totals.daysRead} days read") { BigNumber(commas(totals.daysRead)) } },
                )
                Spacer(Modifier.height(10.dp))
                Fact("Finished", totals.finished.toString())
                Fact("Time", Stats.duration(totals.seconds))
                Fact("Pages turned", commas(totals.pagesTurned))
                Fact("Pages in the library", commas(totals.libraryPages))
                Fact("Best streak", "${totals.bestStreak} ${if (totals.bestStreak == 1) "day" else "days"}")
            }
        }

        // this month so far against last month
        card("monthcompare", "This month so far") {
            val (a, b) = months2
            if (a.seconds > 0 || b.seconds > 0 || a.books > 0 || b.books > 0) {
                ExCard("${a.label} so far") {
                    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                        Spacer(Modifier.weight(1f))
                        Text(a.label.take(3), Modifier.weight(0.6f), color = t.ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
                        Text(b.label.take(3), Modifier.weight(0.6f), color = t.setSub, fontSize = 12.sp, textAlign = TextAlign.End)
                        Text("Change", Modifier.weight(0.6f), color = t.setSub, fontSize = 12.sp, textAlign = TextAlign.End)
                    }
                    CompareRow("Time", Stats.duration(a.seconds), Stats.duration(b.seconds), change(a.seconds, b.seconds))
                    CompareRow("Pages", commas(a.pages), commas(b.pages), change(a.pages.toLong(), b.pages.toLong()))
                    CompareRow("Sessions", a.sessions.toString(), b.sessions.toString(), change(a.sessions.toLong(), b.sessions.toLong()))
                    CompareRow("Books finished", a.books.toString(), b.books.toString(), change(a.books.toLong(), b.books.toLong()))
                    CompareRow("Reading days", a.days.toString(), b.days.toString(), change(a.days.toLong(), b.days.toLong()))
                    Hint("Last month only up to the same day of the month.")
                }
            }
        }

        // listened vs read
        if (split.total > 0) card("split", "Read, listened, logged") {
            ExCard("Read, listened, logged") {
                TileRow(
                    { m -> StatTile("Read", StatsAccent.Blue, m, null, "Read ${Stats.duration(split.readSeconds)}") { BigNumber(Stats.duration(split.readSeconds)) } },
                    { m -> StatTile("Listened", StatsAccent.Mint, m, null, "Listened ${Stats.duration(split.listenSeconds)}") { BigNumber(Stats.duration(split.listenSeconds)) } },
                )
                Spacer(Modifier.height(10.dp))
                Fact("Timer and hand-made entries", Stats.duration(split.loggedSeconds))
                Fact("Share of listening", "${split.listenPercent}%")
                split.topListened?.let { (id, secs) ->
                    Fact("Most listened", "${byId[id]?.title ?: "Removed book"} \u00B7 ${Stats.duration(secs)}")
                }
                Hint("Listening is told apart from reading from this update on. Earlier read-aloud time stays under Read.")
            }
        }

        if (byGenre.isNotEmpty()) card("genre", "Time by genre") {
            ExCard("Time by genre") {
                PbSegmented(listOf(true to "Grouped", false to "As tagged"), grouped, { grouped = it })
                Spacer(Modifier.height(12.dp))
                BarRows(if (grouped) byBroadGenre else byGenre, StatsAccent.Pink)
                Hint(
                    (if (grouped) "Your tags sorted into about fifteen broad genres. " else "Your tags as they are. ") +
                        "A book with several genres shares its time between them.",
                )
            }
        }
        if (byAuthor.isNotEmpty()) card("author", "Time by author") { ExCard("Time by author") { BarRows(byAuthor, StatsAccent.Yellow) } }
        if (byLanguage.size > 1) card("language", "Time by language") { ExCard("Time by language") { BarRows(byLanguage, StatsAccent.Blue) } }

        if (formats.isNotEmpty()) card("formats", "Format") {
            ExCard("Format") {
                BarRows(formats, StatsAccent.Blue)
                Hint("Set a book's format in Edit book. Books with a file count as e-books or PDFs until you set one.")
            }
        }
        if (sources.size > 1) card("sources", "Where your books come from") { ExCard("Where your books come from") { BarRows(sources, StatsAccent.Mint) } }

        if (series.isNotEmpty()) card("series", "Series") {
            ExCard("Series") {
                series.take(8).forEach { row ->
                    val next = row.next
                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).then(if (next != null) Modifier.clickable { onOpenBook(next) } else Modifier)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(row.name, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text("${row.finished} of ${row.total}", color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
                        }
                        Spacer(Modifier.height(4.dp))
                        ProgressTrack(if (row.total > 0) row.finished / row.total.toFloat() else 0f, height = 8.dp)
                        if (next != null) Text("Next: ${next.title}", color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                        else Text("Complete", color = t.setSub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                if (series.size > 8) Hint("${series.size - 8} more series.")
                Hint("Set the series and the number in Edit book. Counts books you have in the library.")
            }
        }

        chapters?.let { c ->
            card("chapters", "Chapters") {
                ExCard("Chapters") {
                    TileRow(
                        { m -> StatTile("Logged", StatsAccent.Yellow, m, null, "${c.chapters} chapters logged") { BigNumber(commas(c.chapters)) } },
                        { m -> StatTile("Books", StatsAccent.Pink, m, null, "${c.booksWithChapters} books with chapters") { BigNumber(c.booksWithChapters.toString()) } },
                    )
                    Spacer(Modifier.height(10.dp))
                    c.pagesPerChapter?.let { Fact("Pages a chapter", "%.1f".format(it)) }
                    c.minutesPerChapter?.let { Fact("Minutes a chapter", "%.1f".format(it)) }
                    Spacer(Modifier.height(8.dp)); SubHead("Most chapters")
                    BarRows(c.topBooks, StatsAccent.Yellow, onTap = ::open)
                }
            }
        }

        // pages
        if (pages.turned > 0 || pages.libraryPages > 0) card("pages", "Pages") {
            ExCard("Pages") {
                TileRow(
                    { m -> StatTile("Turned", StatsAccent.Pink, m, null, "${pages.turned} pages turned") { BigNumber(commas(pages.turned)) } },
                    { m -> StatTile("A month", StatsAccent.Yellow, m, null, "${pages.avgPerMonth} pages a month") { BigNumber(commas(pages.avgPerMonth)) } },
                )
                Spacer(Modifier.height(10.dp))
                Fact("Average a session", "${pages.avgPerSession} pages")
                Fact("Longest session", "${pages.longestSessionPages} pages")
                Fact("All books together", "${commas(pages.libraryPages)} pages")
                Fact("Books left to read", "${pages.booksLeft} \u00B7 ${commas(pages.pagesLeft)} pages")
                Hint("Pages turned count page turns, so going back over a page counts again.")
            }
        }

        // days to finish
        finish?.let { f ->
            card("finish", "Days to finish") {
                ExCard("Days to finish") {
                    TileRow(
                        { m -> StatTile("Average", StatsAccent.Mint, m, null, "${f.avgDays} days on average") { BigNumber(f.avgDays.toString(), "days") } },
                        { m -> StatTile("Typical", StatsAccent.Blue, m, null, "${f.medianDays} days is typical") { BigNumber(f.medianDays.toString(), "days") } },
                    )
                    Spacer(Modifier.height(12.dp))
                    SubHead("Fastest")
                    BarRows(
                        f.fastest.map { Bar(it.book.title, it.days.toDouble(), daysText(it.days), "", it.book.id) },
                        StatsAccent.Mint, onTap = ::open,
                    )
                    Spacer(Modifier.height(8.dp))
                    SubHead("Slowest")
                    BarRows(
                        f.slowest.map { Bar(it.book.title, it.days.toDouble(), daysText(it.days), "", it.book.id) },
                        StatsAccent.Pink, onTap = ::open,
                    )
                    Hint("From the day of the first reading entry to the finish day. ${f.count} books counted.")
                }
            }
        }

        // books per month and year
        if (years.isNotEmpty()) card("months", "Books per month") {
            val yearList = remember(years) { (years.map { it.first } + today.year).distinct().sortedDescending() }
            val counts = remember(books, year) { booksPerMonth(books, year, zone) }
            ExCard("Books per month") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    yearList.forEach { y -> TogglePill(y.toString(), year == y) { year = y } }
                }
                Spacer(Modifier.height(12.dp))
                MonthBars(counts, StatsAccent.Mint)
                Spacer(Modifier.height(6.dp))
                Fact("$year", "${counts.sum()} ${if (counts.sum() == 1) "book" else "books"} finished")
                val addedCounts = remember(books, year) { booksAddedPerMonth(books, year, zone) }
                if (addedCounts.sum() > 0) {
                    Spacer(Modifier.height(10.dp))
                    SubHead("Added to the library")
                    MonthBars(addedCounts, StatsAccent.Blue)
                    Fact("Added in $year", addedCounts.sum().toString())
                    Hint(if (addedCounts.sum() > counts.sum()) "The pile is growing: more added than finished." else "You finished at least as many as you added.")
                }
                Spacer(Modifier.height(4.dp))
                SubHead("Every year")
                val most = (years.maxOfOrNull { it.second } ?: 1).toDouble()
                BarRows(years.map { Bar(it.first.toString(), it.second / most, it.second.toString()) }, StatsAccent.Blue)
            }
        }

        // this year vs last year
        card("yoy", "This year against last") {
            val (a, b) = compare
            if (a.seconds > 0 || b.seconds > 0 || a.books > 0 || b.books > 0) {
                ExCard("${a.year} against ${b.year}") {
                    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                        Spacer(Modifier.weight(1f))
                        Text(a.year.toString(), Modifier.weight(0.6f), color = pbTokens().ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
                        Text(b.year.toString(), Modifier.weight(0.6f), color = pbTokens().setSub, fontSize = 12.sp, textAlign = TextAlign.End)
                        Text("Change", Modifier.weight(0.6f), color = pbTokens().setSub, fontSize = 12.sp, textAlign = TextAlign.End)
                    }
                    CompareRow("Time", Stats.duration(a.seconds), Stats.duration(b.seconds), change(a.seconds, b.seconds))
                    CompareRow("Pages", commas(a.pages), commas(b.pages), change(a.pages.toLong(), b.pages.toLong()))
                    CompareRow("Books", a.books.toString(), b.books.toString(), change(a.books.toLong(), b.books.toLong()))
                    CompareRow("Reading days", a.days.toString(), b.days.toString(), change(a.days.toLong(), b.days.toLong()))
                    Hint("Both years only up to ${today.dayOfMonth} ${StatNames.MONTHS_SHORT[today.monthValue - 1]}.")
                }
            }
        }

        // session lengths
        spread?.let { s ->
            card("spread", "Session lengths") {
                val most = (s.buckets.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(1.0)
                ExCard("Session lengths") {
                    BarRows(s.buckets.map { Bar(it.label, it.value / most, it.text, it.sub) }, StatsAccent.Yellow)
                    Spacer(Modifier.height(6.dp))
                    Fact("Median session", Stats.duration(s.medianSeconds))
                    Fact("Most common", s.commonBucket)
                    Fact("Sessions", s.count.toString())
                }
            }
        }

        // breaks
        breaks?.let { b ->
            card("breaks", "Breaks") {
                ExCard("Breaks") {
                    TileRow(
                        { m -> StatTile("Since you read", StatsAccent.Blue, m, null, if (b.daysSince == 0) "You read today" else "${b.daysSince} days since you read") {
                            BigNumber(b.daysSince.toString(), if (b.daysSince == 1) "day" else "days")
                        } },
                        { m -> StatTile("Longest break", StatsAccent.Pink, m, null, "${b.longestBreak} days longest break") {
                            BigNumber(b.longestBreak.toString(), if (b.longestBreak == 1) "day" else "days")
                        } },
                    )
                    Spacer(Modifier.height(10.dp))
                    Fact("Days you read", b.readingDays.toString())
                    Fact("Average gap between reading days", "%.1f days".format(b.avgGap))
                }
            }
        }

        // ratings
        ratings?.let { r ->
            card("ratings", "Ratings") {
                val most = (r.histogram.maxOrNull() ?: 1).coerceAtLeast(1).toDouble()
                ExCard("Ratings") {
                    BarRows(
                        (4 downTo 0).map { i -> Bar("${i + 1} ${if (i == 0) "star" else "stars"}", r.histogram[i] / most, r.histogram[i].toString()) },
                        StatsAccent.Yellow,
                    )
                    Spacer(Modifier.height(6.dp))
                    Fact("Average", "%.2f".format(r.average) + "\u2605 \u00B7 ${r.rated} rated")
                    if (r.byGenre.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Best rated genres")
                        BarRows(r.byGenre.map { Bar(it.label, it.value / 5.0, it.text, it.sub) }, StatsAccent.Pink)
                    }
                    if (r.byAuthor.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Best rated authors")
                        BarRows(r.byAuthor.map { Bar(it.label, it.value / 5.0, it.text, it.sub) }, StatsAccent.Blue)
                    }
                    Hint("Genres and authors need at least two rated books.")
                }
            }
        }

        // book lengths
        lengths?.let { l ->
            card("lengths", "Book lengths") {
                val most = (l.buckets.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(1.0)
                ExCard("Book lengths") {
                    BarRows(l.buckets.map { Bar(it.label, it.value / most, it.text, it.sub) }, StatsAccent.Mint)
                    Spacer(Modifier.height(6.dp))
                    Fact("Average finished book", "${commas(l.avgPages)} pages")
                    Fact("Pages of finished books", commas(l.finishedPages))
                }
            }
        }

        // publication years
        publication?.let { p ->
            card("publication", "Publication years") {
                ExCard("Publication years") {
                    BarRows(p.decades, StatsAccent.Blue)
                    Spacer(Modifier.height(6.dp))
                    Fact("Oldest", "${p.oldest.first.title} \u00B7 ${p.oldest.second}")
                    Fact("Newest", "${p.newest.first.title} \u00B7 ${p.newest.second}")
                    if (p.publishers.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Top publishers")
                        BarRows(p.publishers, StatsAccent.Yellow)
                    }
                }
            }
        }

        // completion
        if (completion.started > 0) card("completion", "Finishing what you start") {
            ExCard("Finishing what you start") {
                TileRow(
                    { m -> StatTile("Finish rate", StatsAccent.Mint, m, null, "${completion.rate} percent of started books finished") { BigNumber("${completion.rate}%") } },
                    { m -> StatTile("Started", StatsAccent.Blue, m, null, "${completion.started} books started") { BigNumber(completion.started.toString()) } },
                )
                Spacer(Modifier.height(10.dp))
                Fact("Finished", completion.finished.toString())
                Fact("Paused", completion.paused.toString())
                Fact("Dropped", completion.dropped.toString())
                completion.avgDroppedAt?.let { Fact("Dropped at on average", "$it%") }
            }
        }

        // backlog
        if (backlog.books > 0) card("backlog", "Unread pile") { BacklogCard(backlog, onOpenBook) }

        // books gone quiet
        if (idle.isNotEmpty()) card("idle", "Gone quiet") {
            ExCard("Gone quiet") {
                Text("Started, and not opened for 30 days or more.", color = t.setSub, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                idle.take(6).forEach { row ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(
                            row.book.title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.clickable { onOpenBook(row.book) },
                        )
                        Text("${row.book.percent}% read \u00B7 ${row.idleDays} days idle", color = t.setSub, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (row.book.status == BookStatus.NORMAL) {
                                ActionPill("Pause", { onSetStatus(row.book.id, BookStatus.PAUSED) })
                            } else {
                                ActionPill("Back to reading", { onSetStatus(row.book.id, BookStatus.NORMAL) })
                            }
                            ActionPill("Drop", { onSetStatus(row.book.id, BookStatus.DROPPED) }, danger = true)
                        }
                    }
                }
                if (idle.size > 6) Hint("${idle.size - 6} more.")
            }
        }

        if (added.isNotEmpty()) card("recent", "Recently added and finished") {
            ExCard("Recently added and finished") {
                SubHead("Added")
                added.forEach { d -> DatedRow(d.book, dateText(d.ms), onOpenBook) }
                if (finishedRecent.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp)); SubHead("Finished")
                    finishedRecent.forEach { d -> DatedRow(d.book, dateText(d.ms), onOpenBook) }
                }
            }
        }

        favorites?.let { f ->
            card("favorites", "Favorites") {
                ExCard("Favorites") {
                    Fact("Favorite books", "${f.count} \u00B7 ${f.sharePercent}% of the library")
                    Spacer(Modifier.height(8.dp)); SubHead("By genre")
                    BarRows(f.byGenre, StatsAccent.Pink)
                }
            }
        }

        streakRuns?.takeIf { it.runs.isNotEmpty() }?.let { h ->
            card("streaks", "Streak history") {
                ExCard("Streak history") {
                    val fmt = java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy")
                    Fact("Streaks of 2 days or more", h.runs.size.toString())
                    Fact("Average length", "%.1f days".format(h.average))
                    h.longest?.let { l -> Fact("Longest", "${l.length} days \u00B7 ${l.start.format(fmt)}") }
                    if (h.atRiskTonight) Fact("Tonight", "${h.currentLength}-day streak ends if you don't read")
                    Spacer(Modifier.height(8.dp)); SubHead("Every streak, newest first")
                    h.runs.take(12).forEach { r ->
                        Fact(
                            if (r.start == r.end) r.start.format(fmt) else "${r.start.format(fmt)} \u2013 ${r.end.format(fmt)}",
                            "${r.length} days" + if (r.current) " \u00B7 now" else "",
                        )
                    }
                    if (h.runs.size > 12) Hint("And ${h.runs.size - 12} older ones.")
                }
            }
        }

        if (collectionStats.isNotEmpty()) {
            card("collections", "Collections") {
                ExCard("Collections") {
                    collectionStats.forEach { c ->
                        Fact(c.name, "${c.books} books \u00B7 ${minutesText((c.seconds / 60).toInt())} \u00B7 ${c.percentFinished}% finished")
                    }
                    Hint("Time is the reading you logged on the books in each collection. A book in two collections counts in both.")
                }
            }
        }

        wishMix?.let { w ->
            card("wishlist", "Want to read") {
                ExCard("Want to read") {
                    Fact("Books on the list", w.size.toString())
                    if (w.averageDays >= 0) Fact("Average time on the list", if (w.averageDays < 1) "Added today" else "${w.averageDays} days")
                    w.oldest?.let { o -> Fact("On the list longest", "${o.first} \u00B7 ${o.second} days") }
                    if (w.genres.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Top genres")
                        w.genres.forEach { g -> Fact(g.first, "${g.second} books") }
                    }
                    if (w.authors.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Authors you saved more than once")
                        w.authors.forEach { a -> Fact(a.first, "${a.second} books") }
                    }
                    Hint("Books saved before dates were kept have no date.")
                }
            }
        }

        journals?.let { j ->
            card("journals", "Journal") {
                ExCard("Journal") {
                    Fact("Books with a journal", j.books.toString())
                    Fact("Words written", commas(j.words))
                    j.longest?.let { b -> Fact("Longest journal", b.title) }
                }
            }
        }

        // genre explorer
        explorer?.let { g ->
            card("explorer", "Genre explorer") {
                ExCard("Genre explorer") {
                    TileRow(
                        { m -> StatTile("Genres read", StatsAccent.Mint, m, null, "${g.genresRead} genres read") { BigNumber(g.genresRead.toString()) } },
                        { m -> StatTile("Variety", StatsAccent.Yellow, m, null, "Variety ${g.variety} of 100") { BigNumber(g.variety.toString(), "of 100") } },
                    )
                    g.topGenre?.let { Spacer(Modifier.height(10.dp)); Fact("Most read", it) }
                    if (g.untouched.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Waiting, never touched")
                        BarRows(g.untouched, StatsAccent.Pink)
                    }
                    Hint("Variety: 100 means your time is spread evenly over the genres you read, 0 means one genre. Genres come from your tags, sorted into broad ones.")
                }
            }
        }

        // fiction and non-fiction
        fiction?.let { f ->
            card("fiction", "Fiction and non-fiction") {
                ExCard("Fiction and non-fiction") {
                    ProgressTrack(f.fictionPercent / 100f, height = 10.dp)
                    Spacer(Modifier.height(8.dp))
                    Fact("Fiction", "${f.fictionBooks} books \u00B7 ${Stats.duration(f.fictionSeconds)}")
                    Fact("Non-fiction", "${f.nonFictionBooks} books \u00B7 ${Stats.duration(f.nonFictionSeconds)}")
                    Fact("Share of your time in fiction", "${f.fictionPercent}%")
                    if (f.unknownBooks > 0) Fact("Cannot tell from the tags", "${f.unknownBooks} books")
                    Hint("Decided from each book's tags and genres.")
                }
            }
        }

        // dropped and paused
        droppedRep?.let { d ->
            card("dropped", "Dropped and paused") {
                ExCard("Dropped and paused") {
                    TileRow(
                        { m -> StatTile("Dropped", StatsAccent.Pink, m, null, "${d.dropped} books dropped") { BigNumber(d.dropped.toString()) } },
                        { m -> StatTile("Paused", StatsAccent.Blue, m, null, "${d.paused} books paused") { BigNumber(d.paused.toString()) } },
                    )
                    Spacer(Modifier.height(10.dp))
                    Fact("Drop rate", "${d.dropRatePercent}% of books you finished or dropped")
                    d.avgDroppedAt?.let { Fact("Dropped at on average", "$it%") }
                    if (d.byGenre.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Genres you drop most")
                        BarRows(d.byGenre, StatsAccent.Pink)
                    }
                    if (d.droppedBooks.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Dropped")
                        d.droppedBooks.take(6).forEach { b -> DatedRow(b, "at ${b.droppedPct}%", onOpenBook) }
                    }
                    if (d.pausedBooks.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp)); SubHead("Paused")
                        d.pausedBooks.take(6).forEach { b ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    b.title, color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f).clickable { onOpenBook(b) },
                                )
                                ActionPill("Resume", { onSetStatus(b.id, BookStatus.NORMAL) })
                            }
                        }
                    }
                    Hint("Pause or drop a book from Gone quiet, or by tapping its card there.")
                }
            }
        }

        // re-reads
        reReads?.let { r ->
            card("rereads", "Re-reads") {
                ExCard("Re-reads") {
                    Fact("Books read more than once", r.booksReread.toString())
                    Fact("Readings in total", r.totalReadings.toString())
                    Spacer(Modifier.height(6.dp))
                    r.rows.take(6).forEach { row ->
                        val book = row.book
                        Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).then(if (book != null) Modifier.clickable { onOpenBook(book) } else Modifier)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(row.title, color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                Text("${row.times} times", color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
                            }
                            if (row.firstStars > 0.0 && row.lastStars > 0.0 && row.firstStars != row.lastStars) {
                                Text(
                                    "Rating: " + "%.1f".format(row.firstStars) + "\u2605 then " + "%.1f".format(row.lastStars) + "\u2605",
                                    color = t.setSub, fontSize = 12.sp,
                                )
                            }
                        }
                    }
                    Hint("A book you finish again counts as another reading. Finishing it again within a few hours is treated as a slip, not a re-read.")
                }
            }
        }

        // export
        card("export", "Export") {
            ExCard("Export your reading") {
                Text("Keep your numbers outside the app: for a spreadsheet, or to move to another one.", color = t.setSub, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                val stamp = LocalDate.now().toString()
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionPill("Sessions (CSV)", { onExport("paperback-sessions-$stamp.csv", "text/csv", sessionsCsv(sessions, books, zone)) })
                    ActionPill("Books (CSV)", { onExport("paperback-books-$stamp.csv", "text/csv", booksCsv(books, sessions, zone)) })
                    ActionPill("Everything (JSON)", { onExport("paperback-stats-$stamp.json", "application/json", statsJson(books, sessions, highlights, zone)) })
                }
                Hint("One line per reading session or per book. Dates are yyyy-MM-dd, time is in minutes.")
            }
        }

        // notes
        notes?.let { n ->
            card("notes", "Notes and highlights") {
                val monthMax = (n.byMonth.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(1.0)
                ExCard("Notes and highlights") {
                    TileRow(
                        { m -> StatTile("Highlights", StatsAccent.Yellow, m, null, "${n.total} highlights") { BigNumber(n.total.toString()) } },
                        { m -> StatTile("With a note", StatsAccent.Pink, m, null, "${n.withNote} with a note") { BigNumber(n.withNote.toString()) } },
                    )
                    Spacer(Modifier.height(10.dp))
                    Fact("Plain highlights", n.plain.toString())
                    noteRun?.let { r ->
                        Fact("Days with a note", r.daysWithNotes.toString())
                        Fact("Notes streak", "${r.current} \u00B7 best ${r.best}")
                    }
                    Fact("Per 100 pages read", "%.1f".format(n.perHundredPages))
                    Spacer(Modifier.height(8.dp)); SubHead("Colours")
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        n.byColor.forEach { (c, count) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(12.dp).clip(CircleShape).background(Color(c)))
                                Text(" $count", color = t.ink, fontSize = 14.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp)); SubHead("Most annotated")
                    BarRows(n.topBooks.map { Bar(it.label, it.value, it.text, "", it.bookId) }, StatsAccent.Yellow, onTap = ::open)
                    Spacer(Modifier.height(8.dp)); SubHead("Last six months")
                    BarRows(n.byMonth.map { Bar(it.label, it.value / monthMax, it.text) }, StatsAccent.Pink)
                }
            }
        }
    }
    CardList("explore", cards, statsLayout, onStatsLayout, modifier)
}

// ---- cards -------------------------------------------------------------------------------------

@Composable
private fun BacklogCard(b: BacklogFigures, onOpenBook: (Book) -> Unit) {
    ExCard("Unread pile") {
        TileRow(
            { m -> StatTile("Books", StatsAccent.Blue, m, null, "${b.books} unread books") { BigNumber(b.books.toString()) } },
            { m -> StatTile("Pages", StatsAccent.Yellow, m, null, "${b.pages} unread pages") { BigNumber(commas(b.pages)) } },
        )
        Spacer(Modifier.height(10.dp))
        b.oldest?.let { o ->
            Row(Modifier.fillMaxWidth().clickable { onOpenBook(o) }.padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Waiting the longest", color = pbTokens().setSub, fontSize = 14.sp)
                Text(o.title, color = pbTokens().ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 12.dp), textAlign = TextAlign.End)
            }
        }
        b.daysToClear?.let { d -> Fact("At your pace of the last 90 days", durationDays(d)) }
        Hint("Books with no reading and no finish. Paused and dropped books are not in the pile.")
    }
}

@Composable
private fun ExCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 18.dp)) {
        CardLabel(title)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun SubHead(text: String) {
    Text(text, color = pbTokens().ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 4.dp))
}

@Composable
private fun Hint(text: String) {
    Text(text, color = pbTokens().setSub, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
}

@Composable
private fun Fact(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.setSub, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
    }
}

@Composable
private fun CompareRow(label: String, now: String, before: String, change: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.setSub, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(now, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.6f), textAlign = TextAlign.End)
        Text(before, color = t.setSub, fontSize = 14.sp, modifier = Modifier.weight(0.6f), textAlign = TextAlign.End)
        Text(change, color = t.ink, fontSize = 13.sp, modifier = Modifier.weight(0.6f), textAlign = TextAlign.End)
    }
}

/** Horizontal bars. A bar's [Bar.value] is sized against the biggest value in the list. */
@Composable
private fun BarRows(bars: List<Bar>, color: Color, onTap: ((Bar) -> Unit)? = null) {
    val t = pbTokens()
    val max = (bars.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(0.000001)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        bars.forEach { bar ->
            val tap = if (onTap != null && bar.bookId != null) Modifier.clickable { onTap(bar) } else Modifier
            Column(Modifier.fillMaxWidth().then(tap)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(bar.label, color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Text(
                        if (bar.sub.isEmpty()) bar.text else "${bar.text} \u00B7 ${bar.sub}",
                        color = t.setSub, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 10.dp),
                    )
                }
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(t.ink.copy(alpha = 0.08f))) {
                    val fraction = (bar.value / max).toFloat().coerceIn(0f, 1f)
                    if (fraction > 0f) Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(color))
                }
            }
        }
    }
}

/** Twelve small columns, January to December. */
@Composable
private fun MonthBars(counts: IntArray, color: Color) {
    val t = pbTokens()
    val max = (counts.maxOrNull() ?: 0).coerceAtLeast(1)
    Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
        counts.forEachIndexed { i, n ->
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (n > 0) Text(n.toString(), color = t.ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(if (n == 0) 3.dp else (70.dp * n) / max)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (n > 0) color else t.ink.copy(alpha = 0.08f)),
                )
                Spacer(Modifier.height(4.dp))
                Text(StatNames.MONTHS_SHORT[i].take(1), color = t.setSub, fontSize = 11.sp)
            }
        }
    }
}

// ---- small helpers -----------------------------------------------------------------------------

private fun daysText(d: Int): String = if (d == 1) "1 day" else "$d days"

/** "3 weeks", "5 months": a rough length of time in days. */
private fun durationDays(d: Int): String = when {
    d < 14 -> daysText(d)
    d < 60 -> "${d / 7} weeks"
    d < 730 -> "${d / 30} months"
    else -> "%.1f years".format(d / 365.0)
}

/** "+12%" or "-5%"; "\u2013" when there is nothing to compare with. */
private fun change(now: Long, before: Long): String {
    if (before <= 0L) return if (now > 0L) "new" else "\u2013"
    val p = Math.round((now - before) * 100.0 / before).toInt()
    return if (p > 0) "+$p%" else "$p%"
}

private val DATE_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())

private fun dateText(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DATE_FORMAT)

@Composable
private fun DatedRow(book: Book, date: String, onOpenBook: (Book) -> Unit) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().clickable { onOpenBook(book) }.padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(book.title, color = t.ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text(date, color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
    }
}
