package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.StatsLayout
import com.paperback.app.ui.theme.pbTokens

/** One card of a customizable Stats page: a stable [key] (saved in your layout), a [title] for the editor, and what it shows. */
class StatCard(val key: String, val title: String, val content: @Composable () -> Unit)

/**
 * The cards of a Stats page in the order you chose, minus the ones you hid. A Customize button at the top opens an
 * editor with an up and a down arrow and a Show / Hide button for every card, and Reset for the normal layout.
 * [page] names the page in the saved layout ("explore", "habits", "year").
 */
@Composable
fun CardList(
    page: String,
    cards: List<StatCard>,
    layoutJson: String,
    onLayout: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val layout = remember(layoutJson) { StatsLayout.parse(layoutJson) }
    var editing by rememberSaveable { mutableStateOf(false) }
    val keys = cards.map { it.key }
    val ordered = layout.arrange(page, keys)
    val byKey = cards.associateBy { it.key }
    val hiddenCount = ordered.count { layout.isHidden(page, it) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "customize") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when {
                        editing -> "Choose what to show and in what order."
                        hiddenCount > 0 -> "$hiddenCount hidden"
                        else -> ""
                    },
                    color = t.setSub, fontSize = 13.sp, modifier = Modifier.weight(1f),
                )
                ActionPill(if (editing) "Done" else "Customize", { editing = !editing })
            }
        }

        if (editing) {
            item(key = "editor") {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 14.dp)) {
                    ordered.forEachIndexed { index, key ->
                        val card = byKey[key] ?: return@forEachIndexed
                        val hidden = layout.isHidden(page, key)
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                card.title,
                                color = if (hidden) t.setSub else t.ink,
                                fontSize = 15.sp,
                                fontWeight = if (hidden) FontWeight.Normal else FontWeight.Medium,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            if (index > 0) {
                                ActionPill("\u2191", { onLayout(layout.withOrder(page, swap(ordered, index, index - 1)).toJson()) })
                                Spacer(Modifier.padding(start = 6.dp))
                            }
                            if (index < ordered.lastIndex) {
                                ActionPill("\u2193", { onLayout(layout.withOrder(page, swap(ordered, index, index + 1)).toJson()) })
                                Spacer(Modifier.padding(start = 6.dp))
                            }
                            ActionPill(if (hidden) "Show" else "Hide", { onLayout(layout.withHidden(page, key, !hidden).toJson()) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row { ActionPill("Reset this page", { onLayout(layout.reset(page).toJson()) }) }
                }
            }
        } else {
            ordered.forEach { key ->
                val card = byKey[key]
                if (card != null && !layout.isHidden(page, key)) {
                    item(key = card.key) { card.content() }
                }
            }
        }
    }
}

private fun swap(list: List<String>, a: Int, b: Int): List<String> {
    val out = list.toMutableList()
    val tmp = out[a]
    out[a] = out[b]
    out[b] = tmp
    return out
}
