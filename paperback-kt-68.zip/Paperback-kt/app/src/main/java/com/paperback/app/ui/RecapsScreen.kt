package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.RecapRow
import com.paperback.app.data.Stats
import com.paperback.app.data.commas
import com.paperback.app.data.pendingRecap
import com.paperback.app.data.recapKey
import com.paperback.app.data.recapMonthName
import com.paperback.app.data.recapRows
import com.paperback.app.data.recapTitle
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.YearMonth
import java.time.ZoneId

/** What the recap pages need from the app: which months were opened, the reminder, and how to open one. */
class RecapHost(
    /** The months whose recap was opened ("2026-09"). */
    val generated: Set<String>,
    val remind: Boolean,
    val onRemind: (Boolean) -> Unit,
    /** Opens the recap of a month. */
    val onOpen: (YearMonth) -> Unit,
)

private const val STATUS_NEW = "NEW"
private const val STATUS_READY = "Ready"
private const val STATUS_DONE = "Generated"
private const val STATUS_NOW = "In progress"

// ---- the list -------------------------------------------------------------------------------

/**
 * Every month you read in, newest first: this month so far, last month's recap marked NEW until you open it, and the
 * months before. Tapping one opens its recap. Used as a page of Stats and as its own page (from the reminder).
 */
@Composable
fun RecapsContent(
    books: List<Book>,
    sessions: List<ReadingSession>,
    host: RecapHost,
    modifier: Modifier = Modifier,
    sidePad: Dp = 20.dp,
) {
    val zone = remember { ZoneId.systemDefault() }
    val nowMs = remember { System.currentTimeMillis() }
    val rows = remember(books, sessions) { recapRows(books, sessions, zone, nowMs) }
    val pending = remember(rows, host.generated) { pendingRecap(rows, host.generated, nowMs, zone)?.month }
    val current = rows.firstOrNull { it.current }
    val past = rows.filter { !it.current }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = sidePad, end = sidePad, top = 8.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "intro") { IntroCard() }
        if (current != null) {
            item(key = "current") { RecapRowCard(current, STATUS_NOW) { host.onOpen(current.month) } }
        }
        if (past.isEmpty() && current == null) {
            item(key = "empty") { NothingYet() }
        } else if (past.isNotEmpty()) {
            item(key = "label") { CardLabel("Monthly recaps", Modifier.padding(start = 4.dp, top = 10.dp)) }
            items(past, key = { recapKey(it.month) }) { row ->
                val status = when {
                    row.month == pending -> STATUS_NEW
                    recapKey(row.month) in host.generated -> STATUS_DONE
                    else -> STATUS_READY
                }
                RecapRowCard(row, status) { host.onOpen(row.month) }
            }
        }
        item(key = "remind") { RemindCard(host) }
    }
}

@Composable
private fun IntroCard() {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(primary.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            PbIcon(PbIconName.Sparkle, size = 26.dp, tint = primary)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text("Your reading journey", color = t.ink, fontFamily = PbSerif, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            Text(
                "Each month, a look back: books, pages, habits, records and the quotes you saved.",
                modifier = Modifier.padding(top = 2.dp),
                color = t.setSub,
                fontSize = 14.sp,
                lineHeight = 19.sp,
            )
        }
    }
}

@Composable
private fun NothingYet() {
    val t = pbTokens()
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("No recaps yet", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Read for a while and your first monthly recap will be here when the month ends.",
            color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun RecapRowCard(row: RecapRow, status: String, onClick: () -> Unit) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    val isNew = status == STATUS_NEW
    val tile = RoundedCornerShape(20.dp)
    val chip = when (status) {
        STATUS_NEW -> primary
        STATUS_NOW -> inkOf(StatsAccent.Mint)
        STATUS_READY -> inkOf(StatsAccent.Blue)
        else -> primary
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(t.card)
            .semantics(mergeDescendants = true) {
                contentDescription = "${recapTitle(row.month)}, $status. ${row.finished} finished, ${commas(row.pages)} pages. Open recap."
            }
            .clickable(onClickLabel = "Open recap", role = Role.Button, onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(tile)
                .background(primary.copy(alpha = if (isNew) 0.22f else 0.12f))
                .then(if (isNew) Modifier.border(1.5.dp, primary.copy(alpha = 0.5f), tile) else Modifier),
            contentAlignment = Alignment.Center,
        ) {
            PbIcon(if (isNew) PbIconName.Plus else PbIconName.Calendar, size = 28.dp, tint = primary)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    recapTitle(row.month),
                    modifier = Modifier.weight(1f, fill = false),
                    color = t.ink,
                    fontFamily = PbSerif,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.width(8.dp))
                StatusChip(status, chip)
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                PbIcon(PbIconName.Play, size = 12.dp, tint = t.setSub, filled = true)
                Text(" ${row.started} started", color = t.setSub, fontSize = 13.sp, maxLines = 1)
                Spacer(Modifier.width(12.dp))
                PbIcon(PbIconName.Check, size = 14.dp, tint = t.setSub)
                Text(" ${row.finished} finished", color = t.setSub, fontSize = 13.sp, maxLines = 1)
            }
            Text(
                "${commas(row.pages)} pages \u00B7 ${row.days} ${if (row.days == 1) "day" else "days"} \u00B7 ${Stats.duration(row.seconds)}",
                modifier = Modifier.padding(top = 2.dp),
                color = t.setSub,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(6.dp))
        PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub)
    }
}

@Composable
private fun StatusChip(text: String, color: Color) {
    Text(
        text,
        modifier = Modifier.clip(RoundedCornerShape(99.dp)).background(color.copy(alpha = 0.16f)).padding(horizontal = 9.dp, vertical = 3.dp),
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
    )
}

@Composable
private fun RemindCard(host: RecapHost) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 18.dp)) {
        CardLabel("Reminder")
        Spacer(Modifier.height(10.dp))
        Text("Tell me when last month's recap is ready", color = t.ink, fontSize = 15.sp)
        Spacer(Modifier.height(12.dp))
        PbSegmented(
            options = listOf("on" to "On", "off" to "Off"),
            selected = if (host.remind) "on" else "off",
            onSelect = { host.onRemind(it == "on") },
        )
        Text(
            "Home asks once the month is over. \"Maybe later\" keeps it quiet for a day.",
            modifier = Modifier.padding(top = 10.dp),
            color = t.setSub,
            fontSize = 13.sp,
        )
    }
}

// ---- the reminder ---------------------------------------------------------------------------

/** "Your September recap is ready", with a taste of the numbers and what is inside. */
@Composable
fun RecapPromptDialog(row: RecapRow, onOpen: () -> Unit, onLater: () -> Unit) {
    val t = pbTokens()
    PbDialog(title = "Your ${recapMonthName(row.month)} recap is ready", onDismiss = onLater) {
        Text(
            "A look back at ${recapTitle(row.month)}: what you read, how you read, your records and the quotes you saved.",
            color = t.setSub,
            fontSize = 15.sp,
            lineHeight = 21.sp,
        )
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(t.card).padding(vertical = 14.dp)) {
            Mini(commas(row.finished), "finished", Modifier.weight(1f))
            Mini(commas(row.started), "started", Modifier.weight(1f))
            Mini(commas(row.pages), "pages", Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Text("Your recap includes", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Include(PbIconName.DoubleCheck, "Books started and finished")
        Include(PbIconName.Note, "Pages, time and reading pace")
        Include(PbIconName.Calendar, "A reading calendar with covers")
        Include(PbIconName.Clock, "When and how you read")
        Include(PbIconName.Trophy, "Records and milestones")
        Include(PbIconName.Quote, "Quotes and notes you saved")
        PbDialogButtons(confirm = "Open recap", onConfirm = onOpen, onCancel = onLater, cancel = "Maybe later")
    }
}

@Composable
private fun Mini(value: String, label: String, modifier: Modifier) {
    val t = pbTokens()
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = MaterialTheme.colorScheme.primary, fontFamily = PbSerif, fontSize = 26.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        Text(label, color = t.setSub, fontSize = 12.sp)
    }
}

@Composable
private fun Include(icon: PbIconName, text: String) {
    val t = pbTokens()
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        PbIcon(icon, size = 18.dp, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Text(text, color = t.ink, fontSize = 15.sp)
    }
}

// ---- Home -----------------------------------------------------------------------------------

/** A card at the top of Home while last month's recap waits to be opened (also after "Maybe later"). */
@Composable
fun RecapBanner(row: RecapRow, onOpen: () -> Unit) {
    val t = pbTokens()
    val primary = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(primary.copy(alpha = 0.12f))
            .semantics(mergeDescendants = true) { contentDescription = "Your ${recapMonthName(row.month)} recap is ready. Open it." }
            .clickable(onClickLabel = "Open recap", role = Role.Button, onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(primary.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            PbIcon(PbIconName.Sparkle, size = 22.dp, tint = primary)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Your ${recapMonthName(row.month)} recap is ready", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "${row.finished} finished \u00B7 ${commas(row.pages)} pages \u00B7 ${row.days} days",
                color = t.setSub,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub)
    }
}
