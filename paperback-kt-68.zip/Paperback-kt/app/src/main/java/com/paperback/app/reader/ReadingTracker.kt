package com.paperback.app.reader

/**
 * Counts reading time without counting idle time: every page turn credits the time since the previous
 * one, but never more than [capSeconds] (same idea as Readest's per-page cap). Pure logic, no Android.
 */
class ReadingTracker(private val capSeconds: Long = 180) {
    class Flush(
        val startMs: Long, val seconds: Int, val pages: Int, val fromPos: Int = 0, val toPos: Int = 0,
        /** Distinct chapters (files of the book) you were in during the session. */
        val chapters: Int = 0,
        /** Times a gap longer than the cap was cut short: a pause, a phone call, a nap. */
        val breaks: Int = 0,
    )

    private var sessionStart = 0L
    private var lastTick = 0L
    private var seconds = 0L
    private var pages = 0
    private var lastPosition = -1
    private var firstPosition = -1
    private var breaks = 0
    private val chapterKeys = HashSet<String>()

    /** Call when the page you are on changes chapter; a chapter counts once per session. */
    fun onChapter(key: String) {
        if (key.isNotEmpty()) chapterKeys.add(key)
    }

    fun resume(now: Long) {
        if (firstPosition < 0 && lastPosition >= 0) firstPosition = lastPosition // the page you start on
        if (sessionStart == 0L) sessionStart = now
        lastTick = now
    }

    fun onPosition(now: Long, position: Int) {
        credit(now)
        // Small forward steps are pages read; jumps (slider, table of contents) are not.
        if (lastPosition in 0 until position && position - lastPosition <= 3) pages += position - lastPosition
        lastPosition = position
        if (firstPosition < 0) firstPosition = position
    }

    /** Call when the reader goes to the background. Returns what to save, or null if nothing happened. */
    fun pause(now: Long): Flush? {
        credit(now)
        lastTick = 0L
        if (seconds <= 0L && pages <= 0) return null
        val out = Flush(
            sessionStart, seconds.toInt(), pages, firstPosition.coerceAtLeast(0), lastPosition.coerceAtLeast(0),
            chapters = chapterKeys.size, breaks = breaks,
        )
        sessionStart = 0L
        breaks = 0
        chapterKeys.clear()
        seconds = 0L
        pages = 0
        firstPosition = -1
        return out
    }

    private fun credit(now: Long) {
        if (lastTick > 0L) {
            val gap = (now - lastTick) / 1000
            if (gap > capSeconds) breaks++
            seconds += gap.coerceIn(0L, capSeconds)
        }
        lastTick = now
    }
}
