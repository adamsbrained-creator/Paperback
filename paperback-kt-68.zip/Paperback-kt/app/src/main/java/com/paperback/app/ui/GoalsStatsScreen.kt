package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.BestKind
import com.paperback.app.data.CalendarCell
import com.paperback.app.data.DayState
import com.paperback.app.data.GoalHistory
import com.paperback.app.data.Goals
import com.paperback.app.data.HitRate
import com.paperback.app.data.PersonalBest
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.StatNames
import com.paperback.app.data.Stats
import com.paperback.app.data.goalCalendar
import com.paperback.app.data.goalCue
import com.paperback.app.data.hitRates
import com.paperback.app.data.monthMinutesPerDayNeeded
import com.paperback.app.data.monthRates
import com.paperback.app.data.monthTally
import com.paperback.app.data.monthlyProgress
import com.paperback.app.data.personalBests
import com.paperback.app.data.streaks
import com.paperback.app.data.weekCells
import com.paperback.app.data.weekMinutesPerDayNeeded
import com.paperback.app.data.weekStreak
import com.paperback.app.data.weeklyProgress
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Where a tap on the Goals page goes. */
class GoalsLinks(
    /** Stats -> History, on that day. */
    val history: (day: LocalDate) -> Unit,
    /** The Reading goals page (edit the numbers). */
    val editGoals: () -> Unit,
)

private val MEET_TEXT = Color(0xFF123B26)
private val TINY_TEXT = Color(0xFF3F3000)

private fun dayText(d: LocalDate) = "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"

private fun stateWords(s: DayState): String = when (s) {
    DayState.Met -> "goal met"
    DayState.Tiny -> "tiny goal made"
    DayState.Read -> "read, under the tiny goal"
    DayState.Missed -> "no reading"
    DayState.Before -> "before your first day"
    DayState.Future -> "not yet"
}

/**
 * Stats -> Goals: today against the daily and tiny goal, this week and this month against their goals, a calendar of
 * every day (goal met, tiny goal made, read, missed), the hit rate, four streaks (the protected one forgives rest days),
 * and your personal bests. Everything uses the goal that was in force on each day.
 */
@Composable
fun GoalsStatsScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    goals: Goals,
    loadGoalDays: suspend () -> Map<Long, Int>,
    links: GoalsLinks,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val zone = remember { ZoneId.systemDefault() }
    val today = remember { LocalDate.now(zone) }
    val saved by produceState(emptyMap<Long, Int>(), goals.minutesPerDay) {
        value = try {
            loadGoalDays()
        } catch (e: Exception) {
            emptyMap()
        }
    }
    val history = remember(saved, goals.minutesPerDay) { GoalHistory(saved, goals.minutesPerDay, today) }
    val byDay = remember(sessions) { Stats.secondsByDay(sessions, zone) }

    if (sessions.isEmpty()) {
        Box(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("No goals to show yet", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Read for a few minutes and your goals, calendar and streaks will show up here.",
                    color = t.setSub, fontSize = 14.sp, textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                PbButton("Edit goals", { links.editGoals() })
            }
        }
        return
    }

    val todaySeconds = byDay[today] ?: 0L
    val weekRows = remember(byDay, goals.weeklyMinutes) { weeklyProgress(byDay, goals.weeklyMinutes, today) }
    val weekDays = remember(byDay, history, goals.tinyMinutes) { weekCells(byDay, history, goals.tinyMinutes, today) }
    val weekRun = remember(byDay, goals.weeklyMinutes) { weekStreak(byDay, goals.weeklyMinutes, today) }
    val monthRows = remember(byDay, books, goals) { monthlyProgress(byDay, books, goals, today, zone) }
    val rates = remember(byDay, history, goals.tinyMinutes) { hitRates(byDay, history, goals.tinyMinutes, today) }
    val rateMonths = remember(byDay, history, goals.tinyMinutes) { monthRates(byDay, history, goals.tinyMinutes, today) }
    val st = remember(byDay, history, goals) { streaks(byDay, history, goals, today) }
    val bests = remember(sessions, byDay, books, goals, st) { personalBests(sessions, byDay, books, goals, st, today, zone) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "today") { TodayCard(todaySeconds, goals, links) }
        item(key = "week") { WeekCard(weekRows.last(), weekDays, weekRun.first, today, links) }
        item(key = "month") { MonthCard(monthRows, today) }
        item(key = "calendar") { CalendarCard(byDay, history, goals.tinyMinutes, today, links) }
        item(key = "rate") { HitRateCard(rates, rateMonths) }
        item(key = "streaks-label") { CardLabel("Streaks", Modifier.padding(start = 4.dp, top = 12.dp)) }
        item(key = "streaks") { StreakTiles(st, goals, weekRun) }
        if (bests.isNotEmpty()) {
            item(key = "bests-label") { CardLabel("Personal bests", Modifier.padding(start = 4.dp, top = 12.dp)) }
            item(key = "bests") { BestTiles(bests, links) }
        }
        item(key = "edit") {
            Spacer(Modifier.height(4.dp))
            PbButton("Edit goals", { links.editGoals() })
        }
    }
}

// ---- shared bits ----------------------------------------------------------------------------

/** A grey card. With [onTap] it is clickable (and announced as a button). */
@Composable
private fun GoalCard(description: String, onTap: (() -> Unit)?, content: @Composable () -> Unit) {
    val t = pbTokens()
    val tap = if (onTap != null) Modifier.clickable(onClickLabel = "Open", role = Role.Button, onClick = onTap) else Modifier
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(t.card)
            .semantics(mergeDescendants = true) { contentDescription = description }
            .then(tap)
            .padding(horizontal = 20.dp, vertical = 18.dp),
    ) { content() }
}

@Composable
private fun CardHead(title: String, note: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
        Text(title, modifier = Modifier.weight(1f), color = t.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(10.dp))
        Text(note, color = t.setSub, fontSize = 14.sp)
    }
}

/** A bar filled [fraction] (0..1), [color] on the track colour. */
@Composable
private fun FillBar(fraction: Float, color: Color, height: Dp = 10.dp) {
    val f = fraction.coerceIn(0f, 1f)
    Box(Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(height)).background(trackColor())) {
        if (f > 0f) Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(height)).background(color))
    }
}

/** Small vertical bars, one per period; the last is the current one and is drawn solid. */
@Composable
private fun MiniBars(values: List<Float>, labels: List<String>, notes: List<String>, color: Color) {
    val t = pbTokens()
    Row(
        Modifier.fillMaxWidth().height(104.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        values.forEachIndexed { i, v ->
            val last = i == values.lastIndex
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(notes[i], color = t.setSub, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.height(3.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(maxOf(3f, 52f * v.coerceIn(0f, 1f)).dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (last) color else color.copy(alpha = 0.40f)),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    labels[i],
                    color = if (last) t.ink else t.setSub,
                    fontSize = 11.sp,
                    fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                )
            }
        }
    }
}

/** A ring filled [value] (0..1) from the top, with a small tick at [tick] (0..1) and [content] in the middle. */
@Composable
private fun GoalRing(value: Float, tick: Float?, color: Color, size: Dp, stroke: Dp, content: @Composable () -> Unit) {
    val track = trackColor()
    val tickColor = pbTokens().ink
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = stroke.toPx()
            val d = this.size.minDimension - sw
            val tl = Offset(sw / 2f, sw / 2f)
            drawArc(track, 0f, 360f, false, topLeft = tl, size = Size(d, d), style = Stroke(sw))
            val v = value.coerceIn(0f, 1f)
            if (v > 0f) {
                drawArc(color, -90f, 360f * v, false, topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
            }
            if (tick != null && tick > 0f && tick < 1f) {
                val angle = Math.toRadians(-90.0 + 360.0 * tick.toDouble())
                val c = Offset(this.size.width / 2f, this.size.height / 2f)
                val rIn = d / 2f - sw * 0.62f
                val rOut = d / 2f + sw * 0.62f
                drawLine(
                    tickColor,
                    Offset(c.x + (rIn * cos(angle)).toFloat(), c.y + (rIn * sin(angle)).toFloat()),
                    Offset(c.x + (rOut * cos(angle)).toFloat(), c.y + (rOut * sin(angle)).toFloat()),
                    strokeWidth = 2.5.dp.toPx(),
                )
            }
        }
        content()
    }
}

/** One day as a dot: filled mint (goal met), yellow (tiny goal), blue (read) or grey (missed); today has an outline. */
@Composable
private fun DayDot(cell: CalendarCell, size: Dp, text: String, modifier: Modifier = Modifier, onTap: (() -> Unit)? = null) {
    val t = pbTokens()
    val bg: Color = when (cell.state) {
        DayState.Met -> StatsAccent.Mint
        DayState.Tiny -> StatsAccent.Yellow
        DayState.Read -> StatsAccent.Blue.copy(alpha = 0.40f)
        DayState.Missed -> t.ink.copy(alpha = 0.08f)
        DayState.Before, DayState.Future -> Color.Transparent
    }
    val fg: Color = when (cell.state) {
        DayState.Met -> MEET_TEXT
        DayState.Tiny -> TINY_TEXT
        DayState.Read -> t.ink
        DayState.Missed -> t.setSub
        DayState.Before, DayState.Future -> t.setSub.copy(alpha = 0.55f)
    }
    val outline = if (cell.isToday) Modifier.border(1.5.dp, t.ink, CircleShape) else Modifier
    val tap = if (onTap != null) Modifier.clickable(onClickLabel = "Open that day", role = Role.Button, onClick = onTap) else Modifier
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(bg)
            .then(outline)
            .semantics(mergeDescendants = true) { contentDescription = "${dayText(cell.date)}, ${stateWords(cell.state)}" }
            .then(tap),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun Legend() {
    val t = pbTokens()
    @Composable
    fun item(color: Color, text: String) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(color))
            Text(text, modifier = Modifier.padding(start = 5.dp), color = t.setSub, fontSize = 12.sp)
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        item(StatsAccent.Mint, "Goal")
        item(StatsAccent.Yellow, "Tiny")
        item(StatsAccent.Blue.copy(alpha = 0.40f), "Read")
        item(t.ink.copy(alpha = 0.12f), "Missed")
    }
}

// ---- today ----------------------------------------------------------------------------------

@Composable
private fun TodayCard(todaySeconds: Long, goals: Goals, links: GoalsLinks) {
    val t = pbTokens()
    val goalS = goals.minutesPerDay * 60L
    val fraction = if (goalS > 0) todaySeconds.toFloat() / goalS else 0f
    val tick = if (goals.tinyMinutes in 1 until goals.minutesPerDay) goals.tinyMinutes.toFloat() / goals.minutesPerDay else null
    val minutes = (todaySeconds / 60L).toInt()
    val cue = goalCue(todaySeconds, goals.minutesPerDay, goals.tinyMinutes)
    val done = todaySeconds >= goalS
    GoalCard("Today: $minutes of ${goals.minutesPerDay} minutes. $cue. Edit goals.", { links.editGoals() }) {
        CardHead("Today", "tiny goal ${goals.tinyMinutes} min")
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            GoalRing(fraction, tick, if (done) StatsAccent.Mint else StatsAccent.Yellow, 104.dp, 12.dp) {
                Text("${(fraction.coerceIn(0f, 1f) * 100).roundToInt()}%", color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Row {
                    Text(
                        "$minutes", modifier = Modifier.alignByBaseline(), color = t.ink,
                        fontFamily = PbSerif, fontSize = 40.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                    )
                    Text(
                        "of ${goals.minutesPerDay} min", modifier = Modifier.alignByBaseline().padding(start = 6.dp),
                        color = t.setSub, fontSize = 16.sp, maxLines = 1,
                    )
                }
                Text(cue, modifier = Modifier.padding(top = 4.dp), color = t.setSub, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
        if (tick != null) {
            Text(
                "The small line on the ring is your tiny goal. Reaching it keeps the day alive when you cannot do the whole goal.",
                modifier = Modifier.padding(top = 12.dp), color = t.setSub, fontSize = 12.sp, lineHeight = 17.sp,
            )
        }
    }
}

// ---- this week ------------------------------------------------------------------------------

@Composable
private fun WeekCard(
    row: com.paperback.app.data.WeekRow,
    days: List<CalendarCell>,
    weeksInARow: Int,
    today: LocalDate,
    links: GoalsLinks,
) {
    val t = pbTokens()
    val goalMin = (row.goalSeconds / 60L).toInt()
    val need = weekMinutesPerDayNeeded(row, today)
    val note = if (row.met) "Weekly goal reached" else "$need min a day to finish"
    GoalCard("This week: ${Stats.duration(row.seconds)} of $goalMin minutes. $note.", null) {
        CardHead("This week", "Mon to Sun")
        Spacer(Modifier.height(12.dp))
        Row {
            Text(
                Stats.duration(row.seconds), modifier = Modifier.alignByBaseline(), color = t.ink,
                fontFamily = PbSerif, fontSize = 36.sp, fontWeight = FontWeight.Medium, maxLines = 1,
            )
            Text("of $goalMin min", modifier = Modifier.alignByBaseline().padding(start = 6.dp), color = t.setSub, fontSize = 16.sp)
        }
        Spacer(Modifier.height(10.dp))
        FillBar(row.fraction, StatsAccent.Blue)
        Text(
            if (weeksInARow > 1) "$note · $weeksInARow weeks in a row" else note,
            modifier = Modifier.padding(top = 8.dp), color = t.setSub, fontSize = 13.sp,
        )
        Spacer(Modifier.height(14.dp))
        val initials = listOf("M", "T", "W", "T", "F", "S", "S")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            days.forEachIndexed { i, c ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    DayDot(
                        c, 34.dp, if (c.state == DayState.Met) "✓" else "${c.date.dayOfMonth}",
                        onTap = if (c.state != DayState.Future && c.state != DayState.Before) ({ links.history(c.date) }) else null,
                    )
                    Text(
                        initials[i], modifier = Modifier.padding(top = 3.dp),
                        color = if (c.isToday) t.ink else t.setSub, fontSize = 11.sp,
                        fontWeight = if (c.isToday) FontWeight.SemiBold else FontWeight.Normal,
                    )
                }
            }
        }
    }
}

// ---- this month -----------------------------------------------------------------------------

@Composable
private fun MonthCard(rows: List<com.paperback.app.data.MonthRow>, today: LocalDate) {
    val t = pbTokens()
    val cur = rows.last()
    val goalMin = (cur.goalSeconds / 60L).toInt()
    val name = StatNames.MONTHS[cur.month.monthValue - 1]
    val need = monthMinutesPerDayNeeded(cur, today)
    val timeNote = if (cur.seconds >= cur.goalSeconds) "Minutes goal reached" else "$need min a day to finish"
    val booksLeft = (cur.goalBooks - cur.books).coerceAtLeast(0)
    val bookNote = if (booksLeft == 0) "Books goal reached" else if (booksLeft == 1) "1 book to go" else "$booksLeft books to go"
    GoalCard("$name: ${Stats.duration(cur.seconds)} of $goalMin minutes, ${cur.books} of ${cur.goalBooks} books.", null) {
        CardHead(name, "month goal")
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(Stats.duration(cur.seconds), color = t.ink, fontFamily = PbSerif, fontSize = 30.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text("  of $goalMin min", color = t.setSub, fontSize = 15.sp, maxLines = 1)
        }
        Spacer(Modifier.height(8.dp))
        FillBar(cur.timeFraction, StatsAccent.Mint)
        Text(timeNote, modifier = Modifier.padding(top = 6.dp), color = t.setSub, fontSize = 13.sp)

        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${cur.books}", color = t.ink, fontFamily = PbSerif, fontSize = 30.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text("  of ${cur.goalBooks} ${if (cur.goalBooks == 1) "book" else "books"}", color = t.setSub, fontSize = 15.sp, maxLines = 1)
        }
        Spacer(Modifier.height(8.dp))
        FillBar(cur.bookFraction, StatsAccent.Pink)
        Text(bookNote, modifier = Modifier.padding(top = 6.dp), color = t.setSub, fontSize = 13.sp)

        Spacer(Modifier.height(18.dp))
        Text("Last six months", color = t.setSub, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        MiniBars(
            values = rows.map { it.timeFraction },
            labels = rows.map { StatNames.MONTHS_SHORT[it.month.monthValue - 1] },
            notes = rows.map { "${(it.timeFraction * 100).roundToInt()}%" },
            color = StatsAccent.Mint,
        )
        Text(
            "Each bar is that month's minutes against the monthly goal.",
            modifier = Modifier.padding(top = 8.dp), color = t.setSub, fontSize = 12.sp,
        )
    }
}

// ---- the calendar ---------------------------------------------------------------------------

@Composable
private fun CalendarCard(
    byDay: Map<LocalDate, Long>,
    history: GoalHistory,
    tinyMinutes: Int,
    today: LocalDate,
    links: GoalsLinks,
) {
    val t = pbTokens()
    var back by rememberSaveable { mutableIntStateOf(0) }
    val month = YearMonth.from(today).minusMonths(back.toLong())
    val cells = remember(byDay, history, tinyMinutes, month) { goalCalendar(byDay, history, tinyMinutes, month, today) }
    val tally = remember(cells) { monthTally(cells) }
    val title = "${StatNames.MONTHS[month.monthValue - 1]} ${month.year}"

    GoalCard("Goal calendar, $title: ${tally.met} days met the goal.", null) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Goal calendar", modifier = Modifier.weight(1f), color = t.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "‹",
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(onClickLabel = "Previous month", role = Role.Button) { back += 1 }
                    .padding(horizontal = 14.dp, vertical = 2.dp),
                color = t.ink, fontSize = 26.sp,
            )
            Text(
                "›",
                modifier = Modifier
                    .clip(CircleShape)
                    .then(if (back > 0) Modifier.clickable(onClickLabel = "Next month", role = Role.Button) { back -= 1 } else Modifier)
                    .padding(horizontal = 14.dp, vertical = 2.dp),
                color = if (back > 0) t.ink else t.setSub.copy(alpha = 0.35f), fontSize = 26.sp,
            )
        }
        Text(title, color = t.setSub, fontSize = 14.sp)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth()) {
            StatNames.INITIALS.forEach { i ->
                Text(i, modifier = Modifier.weight(1f), color = t.setSub, fontSize = 11.sp, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(6.dp))
        val weeks = cells.chunked(7)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            weeks.forEach { week ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in 0 until 7) {
                        val c = week.getOrNull(i)
                        Box(Modifier.weight(1f).aspectRatio(1f), contentAlignment = Alignment.Center) {
                            if (c != null) {
                                DayDot(
                                    c, 38.dp, "${c.date.dayOfMonth}",
                                    onTap = if (c.state != DayState.Future && c.state != DayState.Before) ({ links.history(c.date) }) else null,
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Legend()
        if (tally.judged > 0) {
            Text(
                "${tally.met} of ${tally.judged} days met the goal · ${tally.tiny} made the tiny goal or more · ${tally.read} read",
                modifier = Modifier.padding(top = 10.dp), color = t.setSub, fontSize = 13.sp, lineHeight = 18.sp,
            )
        }
    }
}

// ---- hit rate -------------------------------------------------------------------------------

@Composable
private fun HitRateCard(rates: List<HitRate>, months: List<com.paperback.app.data.MonthRate>) {
    val t = pbTokens()
    val all = rates.lastOrNull()
    GoalCard("Goal hit rate: ${all?.met ?: 0} of ${all?.days ?: 0} days since you started.", null) {
        CardHead("Goal hit rate", "days that met the goal")
        Spacer(Modifier.height(12.dp))
        rates.forEachIndexed { i, r ->
            if (i > 0) Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                Text(r.label, modifier = Modifier.weight(1f), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(
                    if (r.days > 0) "${(r.pct * 100).roundToInt()}%" else "–",
                    color = inkOf(StatsAccent.Mint), fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                )
                Text("  ${r.met}/${r.days}", color = t.setSub, fontSize = 13.sp)
            }
            Spacer(Modifier.height(6.dp))
            // the tiny goal is the lighter bar behind, the full goal is the solid bar on top
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(10.dp)).background(trackColor())) {
                if (r.tinyPct > 0f) {
                    Box(Modifier.fillMaxWidth(r.tinyPct.coerceIn(0f, 1f)).fillMaxHeight().background(StatsAccent.Yellow.copy(alpha = 0.55f)))
                }
                if (r.pct > 0f) {
                    Box(Modifier.fillMaxWidth(r.pct.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(10.dp)).background(StatsAccent.Mint))
                }
            }
        }
        Text(
            "Green is the whole goal. The yellow behind it is the days that made the tiny goal.",
            modifier = Modifier.padding(top = 10.dp), color = t.setSub, fontSize = 12.sp, lineHeight = 17.sp,
        )
        Spacer(Modifier.height(16.dp))
        Text("By month", color = t.setSub, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        MiniBars(
            values = months.map { it.pct },
            labels = months.map { StatNames.MONTHS_SHORT[it.month.monthValue - 1] },
            notes = months.map { if (it.days > 0) "${(it.pct * 100).roundToInt()}%" else "" },
            color = StatsAccent.Mint,
        )
    }
}

// ---- streaks --------------------------------------------------------------------------------

@Composable
private fun StreakTiles(st: com.paperback.app.data.Streaks, goals: Goals, week: Pair<Int, Int>) {
    fun daysUnit(n: Int) = if (n == 1) "day" else "days"
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TileRow(
            { m ->
                StatTile("Reading streak", StatsAccent.Pink, m, null, "Reading streak: ${st.reading.length} days. Best ${st.readingBest.length}.") {
                    BigNumber("${st.reading.length}", daysUnit(st.reading.length))
                    TileSub("best ${st.readingBest.length}")
                }
            },
            { m ->
                StatTile(
                    "Protected streak", StatsAccent.Yellow, m, null,
                    "Protected streak: ${st.shielded.length} days. Best ${st.shieldedBest.length}.",
                ) {
                    BigNumber("${st.shielded.length}", daysUnit(st.shielded.length))
                    TileSub(if (goals.restDays > 0) "best ${st.shieldedBest.length}" else "rest days are off")
                }
            },
        )
        TileRow(
            { m ->
                StatTile("Goal streak", StatsAccent.Mint, m, null, "Goal streak: ${st.goal.length} days. Best ${st.goalBest.length}.") {
                    BigNumber("${st.goal.length}", daysUnit(st.goal.length))
                    TileSub("best ${st.goalBest.length}")
                }
            },
            { m ->
                StatTile("Tiny-goal streak", StatsAccent.Blue, m, null, "Tiny-goal streak: ${st.tiny.length} days. Best ${st.tinyBest.length}.") {
                    BigNumber("${st.tiny.length}", daysUnit(st.tiny.length))
                    TileSub("best ${st.tinyBest.length}")
                }
            },
        )
        TileRow(
            { m ->
                StatTile("Weekly goal", StatsAccent.Blue, m, null, "Weeks in a row that reached the weekly goal: ${week.first}. Best ${week.second}.") {
                    BigNumber("${week.first}", if (week.first == 1) "week" else "weeks")
                    TileSub("best ${week.second}")
                }
            },
            { m ->
                StatTile("Rest days", StatsAccent.Pink, m, null, "Rest days left this week: ${st.restLeft} of ${st.restDays}.") {
                    BigNumber("${st.restLeft}", "left")
                    TileSub("of ${st.restDays} a week")
                }
            },
        )
        Text(
            "The protected streak forgives up to ${goals.restDays} ${if (goals.restDays == 1) "rest day" else "rest days"} " +
                "in each Monday to Sunday week; rest days are not counted in its length. Set them in Edit goals.",
            modifier = Modifier.padding(horizontal = 4.dp), color = pbTokens().setSub, fontSize = 12.sp, lineHeight = 17.sp,
        )
    }
}

// ---- personal bests -------------------------------------------------------------------------

@Composable
private fun BestTiles(bests: List<PersonalBest>, links: GoalsLinks) {
    fun accent(k: BestKind): Color = when (k) {
        BestKind.Time -> StatsAccent.Blue
        BestKind.Streak -> StatsAccent.Pink
        BestKind.Goal -> StatsAccent.Mint
        BestKind.Books -> StatsAccent.Yellow
    }

    @Composable
    fun tile(b: PersonalBest, m: Modifier) {
        val start = b.start
        StatTile(
            b.label, accent(b.kind), m,
            onTap = if (start != null) ({ links.history(start) }) else null,
            description = "${b.label}: ${b.value}. ${b.sub}.${if (b.isNew) " New this week." else ""}",
        ) {
            BigNumber(b.value)
            TileSub(if (b.isNew) "New · ${b.sub}" else b.sub)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        bests.chunked(2).forEach { pair ->
            TileRow(
                { m -> tile(pair[0], m) },
                { m -> if (pair.size > 1) tile(pair[1], m) else Spacer(m) },
            )
        }
    }
}
