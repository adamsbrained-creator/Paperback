package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.data.bookInsights
import com.paperback.app.data.wordsText
import com.paperback.app.ui.theme.pbTokens
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DAY_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())

private fun dayText(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DAY_FORMAT)

/**
 * The book's Progress page: how you read this book. Averages and records of its sessions, how far the finish is,
 * a chart of the pages you turned each time with the running total, and a strip showing which parts of the book
 * you have been through.
 */
@Composable
fun BookInsightsCard(book: Book, sessions: List<ReadingSession>) {
    val t = pbTokens()
    val zone = remember { ZoneId.systemDefault() }
    val today = remember { LocalDate.now() }
    val ins = remember(book, sessions) { bookInsights(book, sessions, today, zone) } ?: return
    val accent = MaterialTheme.colorScheme.primary

    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(horizontal = 20.dp, vertical = 18.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("FIRST READ", color = t.setSub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Text(dayText(ins.firstMs), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            Column(Modifier.weight(1f), horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("LAST READ", color = t.setSub, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Text(dayText(ins.lastMs), color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(12.dp))
        BookFact("Sessions", "${ins.sessions} on ${ins.readingDays} ${if (ins.readingDays == 1) "day" else "days"}")
        BookFact("Average session", Stats.duration(ins.avgSeconds))
        BookFact("Longest session", Stats.duration(ins.bestSeconds))
        if (ins.avgPages > 0) BookFact("Pages a session", "${ins.avgPages} on average, ${ins.bestPages} at most")
        ins.minPerPage?.let { BookFact("Pace", "%.1f min per page".format(it)) }
        if (ins.wordsRead > 0) BookFact("Words read", wordsText(ins.wordsRead) + if (ins.wordsEstimated) " (estimated)" else "")
        if (ins.wpm > 0) BookFact("Reading speed", "${ins.wpm} words per minute" + if (ins.wordsEstimated) " (estimated)" else "")
        if (ins.listenSeconds > 0) BookFact("Listened", Stats.duration(ins.listenSeconds))
        ins.daysToFinish?.let { BookFact("Took", if (it == 1) "1 day" else "$it days") }
        ins.estimatedFinish?.let { BookFact("Likely finish", it.format(DAY_FORMAT)) }

        if (ins.sessionPages.size >= 2 && ins.cumulativePages.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("Pages over your sessions", color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            EvolutionChart(ins.sessionPages, ins.cumulativePages, accent)
            Text(
                "Bars: pages turned in each session. Line: pages turned so far.",
                color = t.setSub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
            )
        }

        if (ins.coverage.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("Where in the book you read", color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            CoverageStrip(ins.coverage, book.progress, accent)
        }
    }
}

@Composable
private fun BookFact(label: String, value: String) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = t.setSub, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(1.4f))
    }
}

@Composable
private fun EvolutionChart(pages: List<Int>, cumulative: List<Int>, color: Color) {
    Canvas(Modifier.fillMaxWidth().height(130.dp)) {
        val n = pages.size
        if (n == 0) return@Canvas
        val maxBar = (pages.maxOrNull() ?: 1).coerceAtLeast(1)
        val maxCum = (cumulative.lastOrNull() ?: 1).coerceAtLeast(1)
        val slot = size.width / n
        val barW = slot * 0.6f
        pages.forEachIndexed { i, p ->
            val h = size.height * 0.55f * (p.toFloat() / maxBar)
            drawRoundRect(
                color = color.copy(alpha = 0.35f),
                topLeft = Offset(i * slot + (slot - barW) / 2f, size.height - h),
                size = Size(barW, h.coerceAtLeast(2f)),
                cornerRadius = CornerRadius(4f, 4f),
            )
        }
        val path = Path()
        cumulative.forEachIndexed { i, c ->
            val x = i * slot + slot / 2f
            val y = size.height - size.height * 0.95f * (c.toFloat() / maxCum)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 4f, cap = StrokeCap.Round))
    }
}

/** A bar for the whole book; the stretches you went through are filled and a tick marks where you are now. */
@Composable
private fun CoverageStrip(parts: List<Pair<Float, Float>>, progress: Float, color: Color) {
    val t = pbTokens()
    Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(t.ink.copy(alpha = 0.08f))) {
        Canvas(Modifier.fillMaxWidth().fillMaxHeight()) {
            parts.forEach { (a, b) ->
                val x = a * size.width
                val w = ((b - a) * size.width).coerceAtLeast(2f)
                drawRect(color.copy(alpha = 0.55f), topLeft = Offset(x, 0f), size = Size(w, size.height))
            }
            val px = progress.coerceIn(0f, 1f) * size.width
            drawRect(t.ink, topLeft = Offset((px - 1.5f).coerceAtLeast(0f), 0f), size = Size(3f, size.height))
        }
    }
}
