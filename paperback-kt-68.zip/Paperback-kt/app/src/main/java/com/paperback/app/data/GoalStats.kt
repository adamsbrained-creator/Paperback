package com.paperback.app.data

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import kotlin.math.max

/*
 * Everything the Stats -> Goals page shows, as plain functions: the goal calendar, the hit rate, weekly and monthly
 * goals, the streaks (reading, protected, goal, tiny goal), the tiny goal and the personal bests.
 * No Android, no clock: `today` is passed in, and so is the goal history.
 *
 * Words used on the page, so the numbers mean the same everywhere:
 *  - a "reading day" is a day with at least a minute of reading (the same rule as the reading streak);
 *  - a day "met the goal" when it reached the minutes goal that was in force on that day (the goal changes the
 *    future, never the days already saved: see PaperbackDb.goal_days);
 *  - a day "made the tiny goal" when it reached the tiny goal (a few minutes), whatever the daily goal is;
 *  - weeks run Monday to Sunday (as "Best week" on Insights does); the calendar starts on Sunday like the heatmap.
 */

private const val READ_DAY_SECONDS = 60L

private fun monday(d: LocalDate): LocalDate = d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

// ---- the goal of each day --------------------------------------------------------------------

/**
 * The minutes goal in force on any day. [saved] is the goal saved for each day it was saved (epoch day -> minutes);
 * a day without a saved goal takes the last one saved before it, days before the first save take the first, and
 * today and later take [current].
 */
class GoalHistory(saved: Map<Long, Int>, private val current: Int, private val today: LocalDate) {
    private val days: LongArray = saved.keys.sorted().toLongArray()
    private val values: IntArray = IntArray(days.size) { saved[days[it]] ?: current }

    fun minutesOn(d: LocalDate): Int {
        if (!d.isBefore(today) || days.isEmpty()) return current
        val e = d.toEpochDay()
        var lo = 0
        var hi = days.size - 1
        var at = -1
        while (lo <= hi) {
            val mid = (lo + hi) / 2
            if (days[mid] <= e) {
                at = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        val v = if (at < 0) values[0] else values[at]
        return if (v > 0) v else current
    }
}

// ---- one day -----------------------------------------------------------------------------------

enum class DayState {
    /** A day that has not come yet. */
    Future,

    /** A day before your first reading: nothing to judge. */
    Before,

    /** No reading, or less than a minute. */
    Missed,

    /** At least a minute, but not the tiny goal. */
    Read,

    /** The tiny goal, not the whole goal. */
    Tiny,

    /** The day's minutes goal. */
    Met,
}

fun dayState(seconds: Long, goalMinutes: Int, tinyMinutes: Int): DayState = when {
    seconds >= goalMinutes * 60L -> DayState.Met
    tinyMinutes > 0 && seconds >= tinyMinutes * 60L -> DayState.Tiny
    seconds >= READ_DAY_SECONDS -> DayState.Read
    else -> DayState.Missed
}

class CalendarCell(
    val date: LocalDate,
    val seconds: Long,
    val goalMinutes: Int,
    val state: DayState,
    val isToday: Boolean,
)

/** The first day anything was read (a reading day), or null. */
fun firstReadingDay(byDay: Map<LocalDate, Long>): LocalDate? =
    byDay.filterValues { it >= READ_DAY_SECONDS }.keys.minOrNull()

fun cellOf(
    d: LocalDate,
    byDay: Map<LocalDate, Long>,
    history: GoalHistory,
    tinyMinutes: Int,
    today: LocalDate,
    first: LocalDate?,
): CalendarCell {
    val seconds = byDay[d] ?: 0L
    val goal = history.minutesOn(d)
    val state = when {
        d.isAfter(today) -> DayState.Future
        first == null || d.isBefore(first) -> DayState.Before
        else -> dayState(seconds, goal, tinyMinutes)
    }
    return CalendarCell(d, seconds, goal, state, d == today)
}

// ---- the goal calendar ---------------------------------------------------------------------------

/** One month of days, Sunday first. The list starts with empty slots (null) so the first day lands in its column. */
fun goalCalendar(
    byDay: Map<LocalDate, Long>,
    history: GoalHistory,
    tinyMinutes: Int,
    month: YearMonth,
    today: LocalDate,
): List<CalendarCell?> {
    val first = firstReadingDay(byDay)
    val out = ArrayList<CalendarCell?>()
    val start = month.atDay(1)
    repeat(StatNames.weekdayIndex(start)) { out.add(null) }
    for (i in 1..month.lengthOfMonth()) {
        out.add(cellOf(month.atDay(i), byDay, history, tinyMinutes, today, first))
    }
    return out
}

/** How many days of a month were met / tiny-or-better / read, for the line under the calendar. */
class MonthTally(val met: Int, val tiny: Int, val read: Int, val judged: Int)

fun monthTally(cells: List<CalendarCell?>): MonthTally {
    var met = 0
    var tiny = 0
    var read = 0
    var judged = 0
    for (c in cells) {
        if (c == null) continue
        if (c.state == DayState.Future || c.state == DayState.Before) continue
        // today still open: it only counts once it has been read
        if (c.isToday && c.state == DayState.Missed) continue
        judged++
        if (c.state == DayState.Met) met++
        if (c.state == DayState.Met || c.state == DayState.Tiny) tiny++
        if (c.state != DayState.Missed) read++
    }
    return MonthTally(met, tiny, read, judged)
}

// ---- the hit rate --------------------------------------------------------------------------------

class HitRate(
    val label: String,
    /** Days judged, days that met the goal, days that made the tiny goal (met included), days read (all included). */
    val days: Int,
    val met: Int,
    val tiny: Int,
    val read: Int,
) {
    val pct: Float get() = if (days > 0) met.toFloat() / days else 0f
    val tinyPct: Float get() = if (days > 0) tiny.toFloat() / days else 0f
}

private fun rate(
    label: String,
    from: LocalDate,
    until: LocalDate,
    byDay: Map<LocalDate, Long>,
    history: GoalHistory,
    tinyMinutes: Int,
    today: LocalDate,
    first: LocalDate?,
): HitRate {
    if (first == null) return HitRate(label, 0, 0, 0, 0)
    var d = if (from.isBefore(first)) first else from
    var days = 0
    var met = 0
    var tiny = 0
    var read = 0
    while (!d.isAfter(until)) {
        val c = cellOf(d, byDay, history, tinyMinutes, today, first)
        // today is still open, so it is only counted once it has been read
        if (!(c.isToday && c.state == DayState.Missed)) {
            days++
            if (c.state == DayState.Met) met++
            if (c.state == DayState.Met || c.state == DayState.Tiny) tiny++
            if (c.state != DayState.Missed) read++
        }
        d = d.plusDays(1)
    }
    return HitRate(label, days, met, tiny, read)
}

/** The last 7 days, 30 days, 90 days, this year and since the first day you read. */
fun hitRates(byDay: Map<LocalDate, Long>, history: GoalHistory, tinyMinutes: Int, today: LocalDate): List<HitRate> {
    val first = firstReadingDay(byDay)
    return listOf(
        rate("7 days", today.minusDays(6), today, byDay, history, tinyMinutes, today, first),
        rate("30 days", today.minusDays(29), today, byDay, history, tinyMinutes, today, first),
        rate("90 days", today.minusDays(89), today, byDay, history, tinyMinutes, today, first),
        rate("${today.year}", LocalDate.of(today.year, 1, 1), today, byDay, history, tinyMinutes, today, first),
        rate("All time", first ?: today, today, byDay, history, tinyMinutes, today, first),
    )
}

/** The hit rate of each of the last [months] months (oldest first), for the small bars. The current month is partial. */
class MonthRate(val month: YearMonth, val days: Int, val met: Int) {
    val pct: Float get() = if (days > 0) met.toFloat() / days else 0f
}

fun monthRates(
    byDay: Map<LocalDate, Long>,
    history: GoalHistory,
    tinyMinutes: Int,
    today: LocalDate,
    months: Int = 6,
): List<MonthRate> {
    val first = firstReadingDay(byDay)
    val cur = YearMonth.from(today)
    return (months - 1 downTo 0).map { back ->
        val m = cur.minusMonths(back.toLong())
        val until = if (m.atEndOfMonth().isAfter(today)) today else m.atEndOfMonth()
        val r = rate("", m.atDay(1), until, byDay, history, tinyMinutes, today, first)
        MonthRate(m, r.days, r.met)
    }
}

// ---- streaks -------------------------------------------------------------------------------------

/** A run that ends today (or yesterday while today is still open) and its longest ever. */
class Run(val length: Int, val end: LocalDate?)

class Streaks(
    val reading: Run,
    val readingBest: Run,
    val shielded: Run,
    val shieldedBest: Run,
    val goal: Run,
    val goalBest: Run,
    val tiny: Run,
    val tinyBest: Run,
    /** Rest days of the protected streak: allowed a week, and still free this week. */
    val restDays: Int,
    val restLeft: Int,
)

private fun currentRun(today: LocalDate, first: LocalDate?, ok: (LocalDate) -> Boolean): Run {
    if (first == null) return Run(0, null)
    var d = if (ok(today)) today else today.minusDays(1)
    val end = d
    var n = 0
    while (!d.isBefore(first) && ok(d)) {
        n++
        d = d.minusDays(1)
    }
    return if (n == 0) Run(0, null) else Run(n, end)
}

private fun bestRun(today: LocalDate, first: LocalDate?, ok: (LocalDate) -> Boolean): Run {
    if (first == null) return Run(0, null)
    var best = 0
    var bestEnd: LocalDate? = null
    var run = 0
    var d = first
    while (!d.isAfter(today)) {
        if (ok(d)) {
            run++
            if (run >= best) {
                best = run
                bestEnd = d
            }
        } else {
            run = 0
        }
        d = d.plusDays(1)
    }
    return Run(best, bestEnd)
}

/**
 * The protected streak: reading days in a row, where up to [restDays] days without reading in each Monday-to-Sunday
 * week do not break it. Rest days are not counted in the length (only days you read). Today is skipped while it is
 * still open. With 0 rest days it is the ordinary reading streak.
 */
private fun shieldedCurrent(byDay: Map<LocalDate, Long>, today: LocalDate, first: LocalDate?, restDays: Int): Run {
    if (first == null) return Run(0, null)
    fun read(d: LocalDate) = (byDay[d] ?: 0L) >= READ_DAY_SECONDS
    var d = if (read(today)) today else today.minusDays(1)
    var end: LocalDate? = null
    var n = 0
    val used = HashMap<LocalDate, Int>()
    while (!d.isBefore(first)) {
        if (read(d)) {
            if (end == null) end = d
            n++
        } else {
            val w = monday(d)
            val u = used[w] ?: 0
            if (u >= restDays) break
            used[w] = u + 1
        }
        d = d.minusDays(1)
    }
    return if (n == 0) Run(0, null) else Run(n, end)
}

private fun shieldedBestRun(byDay: Map<LocalDate, Long>, today: LocalDate, first: LocalDate?, restDays: Int): Run {
    if (first == null) return Run(0, null)
    fun read(d: LocalDate) = (byDay[d] ?: 0L) >= READ_DAY_SECONDS
    var best = 0
    var bestEnd: LocalDate? = null
    var run = 0
    val used = HashMap<LocalDate, Int>()
    var d = first
    while (!d.isAfter(today)) {
        if (read(d)) {
            run++
            if (run >= best) {
                best = run
                bestEnd = d
            }
        } else {
            val w = monday(d)
            val u = used[w] ?: 0
            if (u < restDays) {
                used[w] = u + 1
            } else {
                run = 0
                used.clear()
            }
        }
        d = d.plusDays(1)
    }
    return Run(best, bestEnd)
}

fun streaks(byDay: Map<LocalDate, Long>, history: GoalHistory, goals: Goals, today: LocalDate): Streaks {
    val first = firstReadingDay(byDay)
    val read = { d: LocalDate -> (byDay[d] ?: 0L) >= READ_DAY_SECONDS }
    val met = { d: LocalDate -> (byDay[d] ?: 0L) >= history.minutesOn(d) * 60L }
    val tiny = { d: LocalDate -> (byDay[d] ?: 0L) >= goals.tinyMinutes * 60L }

    // rest days still free this week: days since Monday (not today) with no reading, after the first day you read
    var missed = 0
    if (first != null) {
        var d = maxOf(monday(today), first)
        while (d.isBefore(today)) {
            if (!read(d)) missed++
            d = d.plusDays(1)
        }
    }
    return Streaks(
        reading = currentRun(today, first, read),
        readingBest = bestRun(today, first, read),
        shielded = shieldedCurrent(byDay, today, first, goals.restDays),
        shieldedBest = shieldedBestRun(byDay, today, first, goals.restDays),
        goal = currentRun(today, first, met),
        goalBest = bestRun(today, first, met),
        tiny = currentRun(today, first, tiny),
        tinyBest = bestRun(today, first, tiny),
        restDays = goals.restDays,
        restLeft = max(0, goals.restDays - missed),
    )
}

// ---- weekly goal ---------------------------------------------------------------------------------

class WeekRow(val start: LocalDate, val seconds: Long, val goalSeconds: Long, val isCurrent: Boolean) {
    val met: Boolean get() = seconds >= goalSeconds
    val fraction: Float get() = if (goalSeconds > 0) (seconds.toFloat() / goalSeconds).coerceIn(0f, 1f) else 0f
}

private fun secondsByWeek(byDay: Map<LocalDate, Long>): Map<LocalDate, Long> {
    val out = HashMap<LocalDate, Long>()
    for ((d, s) in byDay) {
        val w = monday(d)
        out[w] = (out[w] ?: 0L) + s
    }
    return out
}

/** The last [weeks] weeks (Monday to Sunday), oldest first; the last one is this week. */
fun weeklyProgress(byDay: Map<LocalDate, Long>, weeklyMinutes: Int, today: LocalDate, weeks: Int = 8): List<WeekRow> {
    val by = secondsByWeek(byDay)
    val thisWeek = monday(today)
    return (weeks - 1 downTo 0).map { back ->
        val w = thisWeek.minusWeeks(back.toLong())
        WeekRow(w, by[w] ?: 0L, weeklyMinutes * 60L, back == 0)
    }
}

/** The seven days of this week, Monday first. */
fun weekCells(
    byDay: Map<LocalDate, Long>,
    history: GoalHistory,
    tinyMinutes: Int,
    today: LocalDate,
): List<CalendarCell> {
    val first = firstReadingDay(byDay)
    val start = monday(today)
    return (0 until 7).map { cellOf(start.plusDays(it.toLong()), byDay, history, tinyMinutes, today, first) }
}

/** Weeks in a row that reached the weekly goal. This week counts once it has, and does not break the run before that. */
fun weekStreak(byDay: Map<LocalDate, Long>, weeklyMinutes: Int, today: LocalDate): Pair<Int, Int> {
    val first = firstReadingDay(byDay) ?: return 0 to 0
    val by = secondsByWeek(byDay)
    val goal = weeklyMinutes * 60L
    val thisWeek = monday(today)
    var w = if ((by[thisWeek] ?: 0L) >= goal) thisWeek else thisWeek.minusWeeks(1)
    var cur = 0
    while (!w.isBefore(monday(first)) && (by[w] ?: 0L) >= goal) {
        cur++
        w = w.minusWeeks(1)
    }
    var best = 0
    var run = 0
    var x = monday(first)
    while (!x.isAfter(thisWeek)) {
        if ((by[x] ?: 0L) >= goal) {
            run++
            if (run > best) best = run
        } else {
            run = 0
        }
        x = x.plusWeeks(1)
    }
    return cur to best
}

// ---- monthly goal --------------------------------------------------------------------------------

class MonthRow(
    val month: YearMonth,
    val seconds: Long,
    val books: Int,
    val goalSeconds: Long,
    val goalBooks: Int,
    val isCurrent: Boolean,
) {
    val timeFraction: Float get() = if (goalSeconds > 0) (seconds.toFloat() / goalSeconds).coerceIn(0f, 1f) else 0f
    val bookFraction: Float get() = if (goalBooks > 0) (books.toFloat() / goalBooks).coerceIn(0f, 1f) else 0f
}

/** Books finished in each month (by the day each counts for, as on the other pages). */
fun booksByMonth(books: List<Book>, zone: ZoneId): Map<YearMonth, Int> =
    books.filter { it.finished }.groupingBy { YearMonth.from(finishedDate(it, zone)) }.eachCount()

private fun secondsByMonth(byDay: Map<LocalDate, Long>): Map<YearMonth, Long> {
    val out = HashMap<YearMonth, Long>()
    for ((d, s) in byDay) {
        val m = YearMonth.from(d)
        out[m] = (out[m] ?: 0L) + s
    }
    return out
}

/** The last [months] months, oldest first; the last one is this month. */
fun monthlyProgress(
    byDay: Map<LocalDate, Long>,
    books: List<Book>,
    goals: Goals,
    today: LocalDate,
    zone: ZoneId,
    months: Int = 6,
): List<MonthRow> {
    val sec = secondsByMonth(byDay)
    val bk = booksByMonth(books, zone)
    val cur = YearMonth.from(today)
    return (months - 1 downTo 0).map { back ->
        val m = cur.minusMonths(back.toLong())
        MonthRow(m, sec[m] ?: 0L, bk[m] ?: 0, goals.monthlyMinutes * 60L, goals.monthlyBooks, back == 0)
    }
}

/** Minutes a day, from today on, to still reach the monthly goal (0 when reached or the month is over). */
fun monthMinutesPerDayNeeded(row: MonthRow, today: LocalDate): Int {
    val left = (row.goalSeconds - row.seconds).coerceAtLeast(0L)
    if (left == 0L) return 0
    val daysLeft = (row.month.atEndOfMonth().toEpochDay() - today.toEpochDay() + 1).toInt().coerceAtLeast(1)
    return ((left / 60.0) / daysLeft).let { Math.ceil(it).toInt() }
}

/** Minutes a day, from today on, to still reach the weekly goal (0 when reached). */
fun weekMinutesPerDayNeeded(row: WeekRow, today: LocalDate): Int {
    val left = (row.goalSeconds - row.seconds).coerceAtLeast(0L)
    if (left == 0L) return 0
    val daysLeft = (row.start.plusDays(6).toEpochDay() - today.toEpochDay() + 1).toInt().coerceAtLeast(1)
    return Math.ceil((left / 60.0) / daysLeft).toInt()
}

// ---- the tiny goal cue ----------------------------------------------------------------------------

/** One short line for today, from the daily goal and the tiny goal: what is the next small step. */
fun goalCue(todaySeconds: Long, goalMinutes: Int, tinyMinutes: Int): String {
    val goalS = goalMinutes * 60L
    val tinyS = tinyMinutes * 60L
    return when {
        todaySeconds >= goalS -> "Goal reached"
        tinyMinutes > 0 && todaySeconds >= tinyS -> {
            val left = Math.ceil((goalS - todaySeconds) / 60.0).toInt()
            "Tiny goal done · $left min to the full goal"
        }
        tinyMinutes > 0 -> {
            val left = Math.ceil((tinyS - todaySeconds) / 60.0).toInt()
            "$left min to your tiny goal"
        }
        else -> {
            val left = Math.ceil((goalS - todaySeconds) / 60.0).toInt()
            "$left min to go"
        }
    }
}

// ---- personal bests -------------------------------------------------------------------------------

enum class BestKind { Time, Streak, Goal, Books }

class PersonalBest(
    val label: String,
    val value: String,
    val sub: String,
    val kind: BestKind,
    /** Where a tap goes in History, and the last day of it (to tell if it was set in the last week). */
    val start: LocalDate?,
    val end: LocalDate?,
    val isNew: Boolean,
)

private fun dayText(d: LocalDate): String = "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"

private fun dayYearText(d: LocalDate): String = "${dayText(d)} ${d.year}"

private fun daysText(n: Int): String = if (n == 1) "1 day" else "$n days"

/** A run of [n] days ending on [end], as the sub line of a card. */
private fun runSub(r: Run): String = if (r.end != null) "to ${dayYearText(r.end)}" else "none yet"

fun personalBests(
    rows: List<ReadingSession>,
    byDay: Map<LocalDate, Long>,
    books: List<Book>,
    goals: Goals,
    st: Streaks,
    today: LocalDate,
    zone: ZoneId,
): List<PersonalBest> {
    val out = ArrayList<PersonalBest>()
    val recent = today.minusDays(6)
    fun isNew(end: LocalDate?) = end != null && !end.isBefore(recent)

    // best day
    val bestDay = byDay.entries.maxByOrNull { it.value }
    if (bestDay != null && bestDay.value > 0) {
        out.add(
            PersonalBest(
                "Best day", Stats.duration(bestDay.value), dayYearText(bestDay.key), BestKind.Time,
                bestDay.key, bestDay.key, isNew(bestDay.key),
            ),
        )
    }
    // best week
    val weekTotals = HashMap<LocalDate, Long>()
    for ((d, s) in byDay) weekTotals[monday(d)] = (weekTotals[monday(d)] ?: 0L) + s
    val bestWeek = weekTotals.entries.maxByOrNull { it.value }
    if (bestWeek != null && bestWeek.value > 0) {
        out.add(
            PersonalBest(
                "Best week", Stats.duration(bestWeek.value), "from ${dayYearText(bestWeek.key)}", BestKind.Time,
                bestWeek.key, bestWeek.key.plusDays(6), isNew(bestWeek.key.plusDays(6)),
            ),
        )
    }
    // best month
    val monthTotals = HashMap<YearMonth, Long>()
    for ((d, s) in byDay) monthTotals[YearMonth.from(d)] = (monthTotals[YearMonth.from(d)] ?: 0L) + s
    val bestMonth = monthTotals.entries.maxByOrNull { it.value }
    if (bestMonth != null && bestMonth.value > 0) {
        val m = bestMonth.key
        out.add(
            PersonalBest(
                "Best month", Stats.duration(bestMonth.value), "${StatNames.MONTHS[m.monthValue - 1]} ${m.year}", BestKind.Time,
                m.atDay(1), m.atEndOfMonth(), isNew(m.atEndOfMonth()),
            ),
        )
    }
    // longest session
    val sessions = buildSessions(rows)
    val longest = sessions.maxByOrNull { it.seconds }
    if (longest != null && longest.seconds > 0) {
        val d = dateOf(longest.startMs, zone)
        out.add(PersonalBest("Longest session", Stats.duration(longest.seconds), dayYearText(d), BestKind.Time, d, d, isNew(d)))
    }
    // most pages in a day
    val pagesByDay = HashMap<LocalDate, Int>()
    for (r in rows) {
        val d = dateOf(r.startMs, zone)
        pagesByDay[d] = (pagesByDay[d] ?: 0) + r.pages
    }
    val mostPages = pagesByDay.entries.maxByOrNull { it.value }
    if (mostPages != null && mostPages.value > 0) {
        out.add(
            PersonalBest(
                "Most pages a day", commas(mostPages.value), dayYearText(mostPages.key), BestKind.Time,
                mostPages.key, mostPages.key, isNew(mostPages.key),
            ),
        )
    }
    // streaks
    if (st.readingBest.length > 0) {
        out.add(
            PersonalBest(
                "Longest reading streak", daysText(st.readingBest.length), runSub(st.readingBest), BestKind.Streak,
                st.readingBest.end?.minusDays((st.readingBest.length - 1).toLong()), st.readingBest.end, isNew(st.readingBest.end),
            ),
        )
    }
    if (goals.restDays > 0 && st.shieldedBest.length > 0) {
        out.add(
            PersonalBest(
                "Longest protected streak", daysText(st.shieldedBest.length), runSub(st.shieldedBest), BestKind.Streak,
                null, st.shieldedBest.end, isNew(st.shieldedBest.end),
            ),
        )
    }
    if (st.goalBest.length > 0) {
        out.add(
            PersonalBest(
                "Longest goal streak", daysText(st.goalBest.length), runSub(st.goalBest), BestKind.Goal,
                st.goalBest.end?.minusDays((st.goalBest.length - 1).toLong()), st.goalBest.end, isNew(st.goalBest.end),
            ),
        )
    }
    if (st.tinyBest.length > 0) {
        out.add(
            PersonalBest(
                "Longest tiny-goal streak", daysText(st.tinyBest.length), runSub(st.tinyBest), BestKind.Goal,
                st.tinyBest.end?.minusDays((st.tinyBest.length - 1).toLong()), st.tinyBest.end, isNew(st.tinyBest.end),
            ),
        )
    }
    // weeks in a row that reached the weekly goal
    val ws = weekStreak(byDay, goals.weeklyMinutes, today)
    if (ws.second > 0) {
        val weeks = if (ws.second == 1) "1 week" else "${ws.second} weeks"
        out.add(PersonalBest("Weekly goal streak", weeks, "${goals.weeklyMinutes} min a week", BestKind.Goal, null, null, ws.first == ws.second))
    }
    // books in a month
    val bm = booksByMonth(books, zone)
    val mostBooks = bm.entries.maxByOrNull { it.value }
    if (mostBooks != null && mostBooks.value > 0) {
        val m = mostBooks.key
        out.add(
            PersonalBest(
                "Most books in a month", "${mostBooks.value}", "${StatNames.MONTHS[m.monthValue - 1]} ${m.year}", BestKind.Books,
                m.atDay(1), m.atEndOfMonth(), isNew(m.atEndOfMonth()),
            ),
        )
    }
    return out
}
