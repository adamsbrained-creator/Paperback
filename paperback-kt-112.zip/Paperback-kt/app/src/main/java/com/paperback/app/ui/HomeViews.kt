package com.paperback.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.Book
import com.paperback.app.data.HomeSection
import com.paperback.app.data.HomeView
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

// Home's sections can each be drawn a few ways. The header carries the picker; the two sections below
// draw library books and online-catalog books in whichever way was picked.

/** A Home section title with a small menu to pick the look, and "View all" on the right when [onAll] is given. */
@Composable
fun HomeSectionHeader(
    title: String,
    section: HomeSection,
    view: HomeView,
    onView: (HomeView) -> Unit,
    onAll: (() -> Unit)? = null,
) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) { Eyebrow(title) }
        Box {
            Text(
                "${view.short} ▾",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { open = true }.padding(horizontal = 8.dp, vertical = 6.dp),
            )
            PbMenu(expanded = open, onDismiss = { open = false }) {
                section.views.forEach { v ->
                    DropdownMenuItem(
                        text = { Text((if (v == view) "✓ " else "") + v.label) },
                        onClick = { open = false; onView(v) },
                    )
                }
            }
        }
        if (onAll != null) {
            Text(
                "View all",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onAll).padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
    }
}

/** The long-press menu of a library suggestion on the shelf looks: "Not interested" (none without [onDismiss]). */
private fun dismissMenu(onDismiss: ((Book) -> Unit)?): (@Composable ColumnScope.(Book, () -> Unit) -> Unit)? {
    if (onDismiss == null) return null
    return { book, close ->
        val explain = LocalExplain.current
        if (explain != null) DropdownMenuItem(text = { Text("Why this?") }, onClick = { close(); explain(book) })
        DropdownMenuItem(text = { Text("Not interested") }, onClick = { close(); onDismiss(book) })
    }
}

/**
 * Library books in the picked [view]. [shelfRows] is how many shelves the two shelf looks show, [leanId]
 * is the spine that leans on the others, and [notes] maps a book id to a line under its title (list and rows).
 * With [onDismiss], a long-press on a book offers "Not interested".
 */
@Composable
fun HomeBooks(
    books: List<Book>,
    view: HomeView,
    onClick: (Book) -> Unit,
    shelfRows: Int = 1,
    leanId: String? = null,
    notes: Map<String, String> = emptyMap(),
    onDismiss: ((Book) -> Unit)? = null,
) {
    when (view) {
        HomeView.Spines -> BookShelf(books, leanId = leanId, onClick = onClick, maxRows = shelfRows, menu = dismissMenu(onDismiss))
        HomeView.ShelfCovers -> CoverShelf(books, onClick = onClick, maxRows = shelfRows, menu = dismissMenu(onDismiss))
        HomeView.Frosted -> FrostedRow(books.take(20), onClick = onClick, menu = dismissMenu(onDismiss))
        HomeView.CoverRow -> BookCoverRow(books.take(12), onClick, notes, onDismiss)
        HomeView.Grid -> BookGrid(books, onClick, rows = 2, onDismiss = onDismiss)
        HomeView.List -> BookList(books.take(5), onClick, notes, onDismiss)
    }
}

/**
 * Online-catalog books in the picked [view]; [notes] maps a book id to the line under its title. With
 * [onDismiss], a long-press on a book offers "Not interested".
 */
@Composable
fun HomeCatalogBooks(
    books: List<CatalogBook>,
    view: HomeView,
    owned: Set<String>,
    onOpen: (CatalogBook) -> Unit,
    notes: Map<String, String> = emptyMap(),
    onDismiss: ((CatalogBook) -> Unit)? = null,
) {
    when (view) {
        HomeView.ShelfCovers -> CatalogShelf(books, owned, onOpen, rows = 1, onDismiss = onDismiss)
        HomeView.Grid -> CatalogGrid(books, owned, onOpen, notes, rows = 2, onDismiss = onDismiss)
        HomeView.List -> CatalogList(books.take(5), owned, onOpen, notes, onDismiss)
        // Spines make no sense without a book file, so they fall back to the usual row.
        else -> CatalogRow(books, owned, notes = notes, onDismiss = onDismiss, onOpen = onOpen)
    }
}

/** Covers in a row you swipe sideways, each with its title and author. */
@Composable
private fun BookCoverRow(books: List<Book>, onOpen: (Book) -> Unit, notes: Map<String, String>, onDismiss: ((Book) -> Unit)?) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(books, key = { it.id }) { book ->
            BookTile(book, onOpen, notes[book.id], onDismiss, Modifier.width(112.dp))
        }
    }
}

/** Covers in a grid that wraps to the width, at most [rows] lines of them. */
@Composable
private fun BookGrid(books: List<Book>, onOpen: (Book) -> Unit, rows: Int, onDismiss: ((Book) -> Unit)?) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 14.dp
        val cols = (((maxWidth + gap) / (104.dp + gap)).toInt()).coerceAtLeast(2)
        val w = (maxWidth - gap * (cols - 1)) / cols
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            books.chunked(cols).take(rows).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    row.forEach { b -> BookTile(b, onOpen, null, onDismiss, Modifier.width(w)) }
                }
            }
        }
    }
}

/** One cover with its title, author and progress under it: a tile of the row and the grid. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BookTile(book: Book, onOpen: (Book) -> Unit, note: String?, onDismiss: ((Book) -> Unit)?, modifier: Modifier) {
    var menu by remember { mutableStateOf(false) }
    Box(modifier) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).combinedClickable(
                onClick = { onOpen(book) },
                onLongClick = if (onDismiss != null) ({ menu = true }) else null,
            ),
        ) {
            BookCover(book, Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text(book.title, fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (book.author.isNotBlank()) {
                Text(book.author, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (note != null) {
                Text(note, fontSize = 11.sp, lineHeight = 14.sp, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.primary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (book.isReading) {
                Spacer(Modifier.height(6.dp))
                ProgressTrack(book.progress, height = 4.dp)
            } else if (book.finished) {
                Text("Finished", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
            }
        }
        if (onDismiss != null) SuggestionMenu(menu, { menu = false }, book) { onDismiss(book) }
    }
}

/** One line per book: small cover, title, author and where you are in it. */
@Composable
private fun BookList(books: List<Book>, onOpen: (Book) -> Unit, notes: Map<String, String>, onDismiss: ((Book) -> Unit)?) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        books.forEach { book -> BookListRow(book, onOpen, notes[book.id], onDismiss) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BookListRow(book: Book, onOpen: (Book) -> Unit, note: String?, onDismiss: ((Book) -> Unit)?) {
    var menu by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).combinedClickable(
                onClick = { onOpen(book) },
                onLongClick = if (onDismiss != null) ({ menu = true }) else null,
            ),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BookCover(book, Modifier.width(56.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(book.title, fontFamily = PbSerif, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (book.author.isNotBlank()) {
                    Text(book.author, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (note != null) {
                    Text(note, fontSize = 12.sp, fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.primary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                if (book.isReading) {
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { ProgressTrack(book.progress, height = 4.dp) }
                        Spacer(Modifier.width(10.dp))
                        Text("${book.percent}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else if (book.finished) {
                    Spacer(Modifier.height(4.dp))
                    Text("Finished", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        if (onDismiss != null) SuggestionMenu(menu, { menu = false }, book) { onDismiss(book) }
    }
}

/** Catalog covers standing on planks: the catalog version of [CoverShelf]. */
@Composable
private fun CatalogShelf(books: List<CatalogBook>, owned: Set<String>, onOpen: (CatalogBook) -> Unit, rows: Int, onDismiss: ((CatalogBook) -> Unit)?) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 14.dp
        val cols = (((maxWidth + gap) / (104.dp + gap)).toInt()).coerceAtLeast(2)
        val coverW = (maxWidth - 4.dp - gap * (cols - 1)) / cols
        Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
            books.chunked(cols).take(rows).forEach { row ->
                Column(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(gap),
                        verticalAlignment = Alignment.Bottom,
                    ) {
                        row.forEach { b ->
                            CatalogShelfCover(b, TitleKey.of(b.title) in owned, onOpen, onDismiss, Modifier.width(coverW))
                        }
                    }
                    Plank()
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CatalogShelfCover(b: CatalogBook, owned: Boolean, onOpen: (CatalogBook) -> Unit, onDismiss: ((CatalogBook) -> Unit)?, modifier: Modifier) {
    var menu by remember { mutableStateOf(false) }
    Box(modifier.padding(bottom = 1.dp)) {
        CatalogCover(
            b,
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).combinedClickable(
                onClick = { onOpen(b) },
                onLongClick = if (onDismiss != null) ({ menu = true }) else null,
            ),
        )
        if (owned) InLibraryBadge(Modifier.align(Alignment.BottomStart))
        if (onDismiss != null) SuggestionMenu(menu, { menu = false }, b) { onDismiss(b) }
    }
}

/** Catalog cards in a grid that wraps to the width, at most [rows] lines of them. */
@Composable
private fun CatalogGrid(
    books: List<CatalogBook>,
    owned: Set<String>,
    onOpen: (CatalogBook) -> Unit,
    notes: Map<String, String>,
    rows: Int,
    onDismiss: ((CatalogBook) -> Unit)?,
) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 14.dp
        val cols = (((maxWidth + gap) / (104.dp + gap)).toInt()).coerceAtLeast(2)
        val w = (maxWidth - gap * (cols - 1)) / cols
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            books.chunked(cols).take(rows).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap), verticalAlignment = Alignment.Top) {
                    row.forEach { b ->
                        SuggestionCard(b, Modifier.width(w), note = notes[b.id], owned = TitleKey.of(b.title) in owned, onDismiss = onDismiss) { onOpen(b) }
                    }
                }
            }
        }
    }
}

/** One line per catalog book: small cover, title, author and the reason or rating. */
@Composable
private fun CatalogList(books: List<CatalogBook>, owned: Set<String>, onOpen: (CatalogBook) -> Unit, notes: Map<String, String>, onDismiss: ((CatalogBook) -> Unit)?) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        books.forEach { b -> CatalogListRow(b, TitleKey.of(b.title) in owned, notes[b.id], onOpen, onDismiss) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CatalogListRow(b: CatalogBook, owned: Boolean, note: String?, onOpen: (CatalogBook) -> Unit, onDismiss: ((CatalogBook) -> Unit)?) {
    val t = pbTokens()
    var menu by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).combinedClickable(
                onClick = { onOpen(b) },
                onLongClick = if (onDismiss != null) ({ menu = true }) else null,
            ),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.width(56.dp)) {
                CatalogCover(b, Modifier.fillMaxWidth())
                if (owned) InLibraryBadge(Modifier.align(Alignment.BottomStart), small = true)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(b.title, color = t.ink, fontFamily = PbSerif, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (b.author.isNotBlank()) {
                    Text(b.firstAuthor(), color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                val line = note ?: ratingText(b.rating)
                if (line.isNotEmpty()) {
                    Text(
                        line,
                        color = if (note != null) MaterialTheme.colorScheme.primary else t.setSub,
                        fontSize = 12.sp,
                        fontStyle = if (note != null) FontStyle.Italic else null,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (onDismiss != null) SuggestionMenu(menu, { menu = false }, b) { onDismiss(b) }
    }
}

/** The small "In library" tag on a catalog cover. */
@Composable
private fun InLibraryBadge(modifier: Modifier = Modifier, small: Boolean = false) {
    Text(
        if (small) "✓" else "In library",
        modifier = modifier
            .padding(if (small) 3.dp else 6.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.primary)
            .padding(horizontal = if (small) 5.dp else 7.dp, vertical = 3.dp),
        color = MaterialTheme.colorScheme.onPrimary,
        fontSize = 10.sp,
        fontWeight = FontWeight.Medium,
    )
}
