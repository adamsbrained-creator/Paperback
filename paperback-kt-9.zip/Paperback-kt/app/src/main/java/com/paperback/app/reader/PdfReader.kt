package com.paperback.app.reader

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.systemBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Bookmark
import com.paperback.app.data.PdfDoc
import com.paperback.app.data.Stats
import com.paperback.app.ui.PbIcon
import com.paperback.app.ui.PbIconName
import com.paperback.app.ui.PbSlider
import com.paperback.app.ui.theme.PbSerif
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

private const val MAX_ZOOM = 5f

/** Colours that turn a white PDF page into sepia paper or a dark page. Light leaves it alone. */
private fun pageFilter(theme: Int): ColorFilter? = when (theme) {
    1 -> ColorFilter.colorMatrix(
        ColorMatrix(floatArrayOf(0.98f, 0f, 0f, 0f, 0f, 0f, 0.957f, 0f, 0f, 0f, 0f, 0f, 0.91f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)),
    )
    2 -> ColorFilter.colorMatrix(
        ColorMatrix(floatArrayOf(-0.94f, 0f, 0f, 0f, 240f, 0f, -0.94f, 0f, 0f, 240f, 0f, 0f, -0.94f, 0f, 240f, 0f, 0f, 0f, 1f, 0f)),
    )
    else -> null
}

/**
 * The PDF reader screen: one page at a time, swipe or tap the edges to turn, pinch or double-tap to zoom.
 * Everything that has to survive the screen (theme, bookmarks, the page) lives in PdfReaderActivity.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PdfReaderRoot(
    doc: PdfDoc,
    title: String,
    startPage: Int,
    themeIndex: Int,
    rtl: Boolean,
    brightness: Float,
    chromeVisible: Boolean,
    bookmarks: List<Bookmark>,
    secondsPerPage: Double?,
    onPage: (Int) -> Unit,
    onToggleChrome: () -> Unit,
    onHideChrome: () -> Unit,
    onBack: () -> Unit,
    onToggleBookmark: (Int) -> Unit,
    onDeleteBookmark: (Bookmark) -> Unit,
    onTheme: (Int) -> Unit,
    onRtl: (Boolean) -> Unit,
    onBrightness: (Float) -> Unit,
) {
    val c = readerColors(themeIndex)
    val scope = rememberCoroutineScope()
    val total = doc.pageCount
    val pager = rememberPagerState(initialPage = (startPage - 1).coerceIn(0, total - 1)) { total }
    var zoomed by remember { mutableStateOf(false) }
    var viewOpen by remember { mutableStateOf(false) }
    var listOpen by remember { mutableStateOf(false) }

    val page = pager.currentPage + 1
    LaunchedEffect(pager) {
        snapshotFlow { pager.currentPage }.collect { index ->
            zoomed = false
            onPage(index + 1)
        }
    }

    fun goTo(index: Int) {
        scope.launch { pager.scrollToPage(index.coerceIn(0, total - 1)) }
    }

    // A tap near the left or right edge turns the page (the other way round when reading right to left).
    val onTap: (Float) -> Unit = { fraction ->
        when {
            fraction < 0.25f -> {
                onHideChrome()
                scope.launch { pager.animateScrollToPage((pager.currentPage + if (rtl) 1 else -1).coerceIn(0, total - 1)) }
            }
            fraction > 0.75f -> {
                onHideChrome()
                scope.launch { pager.animateScrollToPage((pager.currentPage + if (rtl) -1 else 1).coerceIn(0, total - 1)) }
            }
            else -> onToggleChrome()
        }
    }

    Box(Modifier.fillMaxSize().background(c.page)) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize(),
            reverseLayout = rtl,
            userScrollEnabled = !zoomed,
            beyondViewportPageCount = 1,
            key = { it },
        ) { index ->
            PdfPageView(
                doc = doc,
                index = index,
                active = index == pager.currentPage,
                theme = themeIndex,
                onZoomed = { zoomed = it },
                onTap = onTap,
            )
        }

        // ---- top bar -------------------------------------------------------------------------
        AnimatedVisibility(
            visible = chromeVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundButton(c, onBack) {
                    PbIcon(PbIconName.CaretLeft, size = 22.dp, tint = c.ink, strokeWidth = 2.2f, contentDescription = "Back")
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    text = title,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(c.card)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    color = c.ink,
                    fontFamily = PbSerif,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.width(10.dp))
                val bookmarked = bookmarks.any { it.position == page }
                RoundButton(c, { onToggleBookmark(page) }) {
                    PbIcon(
                        PbIconName.Bookmark,
                        size = 22.dp,
                        tint = if (bookmarked) MaterialTheme.colorScheme.primary else c.ink,
                        filled = bookmarked,
                        contentDescription = "Bookmark",
                    )
                }
                Spacer(Modifier.width(10.dp))
                RoundButton(c, { listOpen = true }) {
                    PbIcon(PbIconName.MenuLines, size = 22.dp, tint = c.ink, contentDescription = "Bookmarks")
                }
            }
        }

        // ---- bottom card ---------------------------------------------------------------------
        AnimatedVisibility(
            visible = chromeVisible && !viewOpen,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomStart),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .padding(16.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(c.card)
                    .padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                val fraction = if (total > 1) (page - 1f) / (total - 1f) else 1f
                val left = if (secondsPerPage != null) {
                    Stats.duration(((total - page).coerceAtLeast(0) * secondsPerPage).toLong()) + " left"
                } else null
                val label = buildString {
                    append("Page $page of $total · ${(fraction * 100).roundToInt()}%")
                    if (left != null) append(" · $left")
                }
                Text(label, color = c.ink, fontSize = 14.sp)

                var drag by remember { mutableStateOf<Float?>(null) }
                PbSlider(
                    value = drag ?: fraction,
                    onValueChange = { drag = it },
                    onValueChangeFinished = {
                        drag?.let { f -> goTo(if (total > 1) (f * (total - 1)).roundToInt() else 0) }
                        drag = null
                    },
                    trackColor = c.ink.copy(alpha = 0.15f),
                    modifier = Modifier.padding(vertical = 2.dp),
                )
                // While dragging, show which page the finger is on.
                drag?.let { f ->
                    val target = if (total > 1) (f * (total - 1)).roundToInt() + 1 else 1
                    Text("Go to page $target", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(c, "View") {
                        onHideChrome()
                        viewOpen = true
                    }
                }
            }
        }

        // ---- view sheet ----------------------------------------------------------------------
        if (viewOpen) {
            BackHandler { viewOpen = false }
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(c.card)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("View", modifier = Modifier.weight(1f), color = c.ink, fontFamily = PbSerif, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    Pill(c, "Done") { viewOpen = false }
                }
                Column {
                    Text("Page colors", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Light", "Sepia", "Dark").forEachIndexed { i, name ->
                            Pill(c, name, selected = themeIndex == i) { onTheme(i) }
                        }
                    }
                }
                Column {
                    Text("Turn pages", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(c, "Left to right", selected = !rtl) { onRtl(false) }
                        Pill(c, "Right to left", selected = rtl) { onRtl(true) }
                    }
                }
                Column {
                    val auto = brightness < 0f
                    Row(Modifier.fillMaxWidth()) {
                        Text("Brightness", modifier = Modifier.weight(1f), color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(if (auto) "Same as phone" else "${(brightness * 100).roundToInt()}%", color = c.ink.copy(alpha = 0.6f), fontSize = 13.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PbSlider(
                            value = if (auto) 0.5f else brightness,
                            onValueChange = { onBrightness(it.coerceIn(0.05f, 1f)) },
                            valueRange = 0.05f..1f,
                            trackColor = c.ink.copy(alpha = 0.15f),
                            modifier = Modifier.weight(1f),
                        )
                        Spacer(Modifier.width(8.dp))
                        Pill(c, "Auto", selected = auto) { onBrightness(-1f) }
                    }
                }
                Text(
                    "Pinch or double-tap to zoom. Tap the left or right edge to turn the page.",
                    color = c.ink.copy(alpha = 0.6f),
                    fontSize = 13.sp,
                )
            }
        }

        // ---- bookmarks list ------------------------------------------------------------------
        if (listOpen) {
            BackHandler { listOpen = false }
            Column(
                Modifier
                    .fillMaxSize()
                    .background(c.page)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
                    .windowInsetsPadding(WindowInsets.systemBarsIgnoringVisibility)
                    .padding(horizontal = 20.dp),
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Bookmarks", modifier = Modifier.weight(1f), color = c.ink, fontFamily = PbSerif, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                    Pill(c, "Done") { listOpen = false }
                }
                if (bookmarks.isEmpty()) {
                    Text(
                        "No bookmarks yet. Tap the bookmark button at the top of a page.",
                        color = c.ink.copy(alpha = 0.6f),
                        fontSize = 15.sp,
                        modifier = Modifier.padding(vertical = 24.dp),
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(bookmarks, key = { it.id }) { b ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        listOpen = false
                                        onHideChrome()
                                        goTo(b.position - 1)
                                    }
                                    .padding(vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    "Page ${b.position} · ${(b.progress * 100).toInt().coerceIn(0, 100)}%",
                                    modifier = Modifier.weight(1f),
                                    color = c.ink,
                                    fontSize = 16.sp,
                                )
                                Text(
                                    "Remove",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 13.sp,
                                    modifier = Modifier.clickable { onDeleteBookmark(b) }.padding(8.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * One page. At normal size the whole page fits the screen. Two fingers zoom (up to 5x), one finger then moves the
 * zoomed page; a double tap zooms in or back out. While zoomed the pager is locked ([onZoomed]) so dragging pans
 * the page instead of turning it.
 */
@Composable
private fun PdfPageView(
    doc: PdfDoc,
    index: Int,
    active: Boolean,
    theme: Int,
    onZoomed: (Boolean) -> Unit,
    onTap: (Float) -> Unit,
) {
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val vw = constraints.maxWidth
        val vh = constraints.maxHeight
        val dims by produceState<Pair<Int, Int>?>(null, index) { value = doc.pageSize(index) }
        val pageSize = dims ?: return@BoxWithConstraints

        val ratio = pageSize.first.toFloat() / pageSize.second
        val (fitW, fitH) = if (vw.toFloat() / vh < ratio) {
            vw to (vw / ratio).roundToInt().coerceAtLeast(1)
        } else {
            (vh * ratio).roundToInt().coerceAtLeast(1) to vh
        }

        var scale by remember(index) { mutableFloatStateOf(1f) }
        var offset by remember(index) { mutableStateOf(Offset.Zero) }

        fun clamp(o: Offset, sc: Float): Offset {
            val mx = max(0f, (fitW * sc - vw) / 2f)
            val my = max(0f, (fitH * sc - vh) / 2f)
            return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
        }

        LaunchedEffect(active) {
            if (!active) {
                scale = 1f
                offset = Offset.Zero
            }
        }
        val isZoomed = scale > 1.001f
        LaunchedEffect(isZoomed, active) { if (active) onZoomed(isZoomed) }

        // The page at screen size, then a sharper copy once you have zoomed in and stopped.
        val lo by produceState<ImageBitmap?>(null, index, fitW, fitH) {
            value = doc.render(index, fitW, fitH).asImageBitmap()
        }
        val bucket by remember { derivedStateOf { if (scale < 1.25f) 0 else min(ceil(scale).toInt(), MAX_ZOOM.toInt()) } }
        val hi by produceState<ImageBitmap?>(null, index, fitW, fitH, bucket) {
            if (bucket == 0) {
                value = null
            } else {
                delay(180)
                // Keep a zoomed page under about 14 million pixels so it fits in memory.
                val k = min(bucket.toFloat(), sqrt(14_000_000f / (fitW.toFloat() * fitH)))
                if (k > 1.1f) {
                    value = doc.render(index, (fitW * k).roundToInt(), (fitH * k).roundToInt()).asImageBitmap()
                }
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(index, fitW, fitH, vw, vh) {
                    detectTapGestures(
                        onTap = { p -> onTap(p.x / this.size.width) },
                        onDoubleTap = { p ->
                            if (scale > 1.05f) {
                                scale = 1f
                                offset = Offset.Zero
                            } else {
                                val target = (vw.toFloat() / fitW).coerceIn(2.5f, 4f)
                                val centre = Offset(vw / 2f, vh / 2f)
                                scale = target
                                offset = clamp((p - centre) * (1f - target), target)
                            }
                        },
                    )
                }
                .pointerInput(index, fitW, fitH, vw, vh) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val event = awaitPointerEvent()
                            val consumed = event.changes.any { it.isConsumed }
                            if (!consumed) {
                                val fingers = event.changes.count { it.pressed }
                                // One finger on an unzoomed page is left alone so the pager can turn the page.
                                if (fingers > 1 || scale > 1.001f) {
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val centroid = event.calculateCentroid() - Offset(vw / 2f, vh / 2f)
                                    val newScale = (scale * zoom).coerceIn(1f, MAX_ZOOM)
                                    val k = newScale / scale
                                    // Keep the point under the fingers where it was.
                                    val next = centroid - (centroid - pan - offset) * k
                                    scale = newScale
                                    offset = clamp(next, newScale)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            }
                        } while (!consumed && event.changes.any { it.pressed })
                    }
                },
        ) {
            val bmp = hi ?: lo
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = "Page ${index + 1}",
                    contentScale = ContentScale.FillBounds,
                    colorFilter = pageFilter(theme),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(with(density) { fitW.toDp() }, with(density) { fitH.toDp() })
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        },
                )
            }
        }
    }
}
