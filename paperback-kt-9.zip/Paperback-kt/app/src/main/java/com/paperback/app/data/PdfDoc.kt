package com.paperback.app.data

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

/**
 * A PDF opened with Android's own [PdfRenderer] (no extra library). The renderer can only have one page open at a
 * time, so every call takes [lock]. Pages are drawn to bitmaps; there is no text, search or outline from this API.
 */
class PdfDoc private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
) {
    val pageCount: Int = renderer.pageCount

    private val lock = Mutex()
    private val sizes = HashMap<Int, Pair<Int, Int>>()

    /** The page's size in points (width, height). Only the proportions matter. */
    suspend fun pageSize(index: Int): Pair<Int, Int> = withContext(Dispatchers.IO) {
        lock.withLock {
            sizes.getOrPut(index) {
                val page = renderer.openPage(index)
                try {
                    page.width.coerceAtLeast(1) to page.height.coerceAtLeast(1)
                } finally {
                    page.close()
                }
            }
        }
    }

    /** Draws page [index] (0-based) into a new bitmap of exactly [width] x [height] pixels, on white. */
    suspend fun render(index: Int, width: Int, height: Int): Bitmap = withContext(Dispatchers.IO) {
        lock.withLock {
            val bmp = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            val page = renderer.openPage(index)
            try {
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            } finally {
                page.close()
            }
            bmp
        }
    }

    fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }

    companion object {
        /** Opens [file], or returns null if it isn't a readable PDF (damaged, empty, or password-protected). */
        fun open(file: File): PdfDoc? {
            var pfd: ParcelFileDescriptor? = null
            return try {
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                if (renderer.pageCount <= 0) {
                    renderer.close()
                    pfd.close()
                    null
                } else {
                    PdfDoc(pfd, renderer)
                }
            } catch (e: Exception) {
                runCatching { pfd?.close() }
                null
            }
        }

        /** True when the file starts with "%PDF-" (PDF files may begin with a few stray bytes, so look a little in). */
        fun looksLikePdf(file: File): Boolean = runCatching {
            FileInputStream(file).use { input ->
                val head = ByteArray(1024)
                val n = input.read(head)
                n >= 5 && String(head, 0, n, Charsets.ISO_8859_1).contains("%PDF-")
            }
        }.getOrDefault(false)

        /** A readable title from a file name: "my_book-v2.pdf" -> "my book v2". */
        fun titleFromFileName(name: String): String =
            name.substringBeforeLast('.')
                .replace('_', ' ')
                .replace(Regex("\\s+"), " ")
                .trim()
                .ifEmpty { "Untitled" }
    }
}
