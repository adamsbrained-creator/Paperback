package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.catalog.Load
import kotlinx.coroutines.delay
import com.paperback.app.data.Authors
import com.paperback.app.data.Book
import com.paperback.app.data.Tags
import com.paperback.app.data.BookCollection
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.Highlight
import com.paperback.app.data.Search
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

/** An app page the search can jump to, with extra words people might type to find it. */
private class PageEntry(val label: String, val section: String, val dest: Dest, val keywords: String)

private val PAGES = listOf(
    PageEntry("Home", "Tab", Dest.Home, "continue reading today"),
    PageEntry("Library", "Tab", Dest.Library, "books shelf all"),
    PageEntry("Stats", "Tab", Dest.Stats, "statistics streak reading time history"),
    PageEntry("Currently reading", "Shelf", Dest.Reading, "in progress"),
    PageEntry("Recently read", "Shelf", Dest.Recent, "history last opened"),
    PageEntry("Finished", "Shelf", Dest.Finished, "done completed read"),
    PageEntry("Favorites", "Shelf", Dest.Favorites, "favourite liked starred"),
    PageEntry("Want to read", "Shelf", Dest.WantToRead, "wishlist saved later queue to read next"),
    PageEntry("Collections", "Shelf", Dest.Collections, "lists groups"),
    PageEntry("Genres", "Shelf", Dest.Genres, "tags subjects categories topics"),
    PageEntry("Authors", "Shelf", Dest.Authors, "writers people"),
    PageEntry("Notes & highlights", "Notes", Dest.Notes, "annotations quotes"),
    PageEntry("Bookmarks", "Notes", Dest.Bookmarks, "saved pages"),
    PageEntry("Reading goals", "Settings", Dest.Goals, "goal streak minutes pages books year target"),
    PageEntry("Reader defaults", "Settings", Dest.ReaderDefaults, "font size text sepia page colors theme"),
    PageEntry("Read aloud", "Settings", Dest.ReadAloud, "text to speech tts voice listen audio narrator speed sleep timer headphones"),
    PageEntry("Appearance", "Settings", Dest.Appearance, "theme dark light mode system"),
    PageEntry("App style", "Settings", Dest.AppStyle, "header size compact regular large app icon launcher glassy flat more page layout accordion bento"),
    PageEntry("Your taste", "Settings", Dest.Taste, "recommendations suggestions subjects authors like less of this hide mute taste profile hidden not interested"),
    PageEntry("Discover", "Get books", Dest.Discover, "free books catalog online gutenberg standard ebooks opds download calibre"),
    PageEntry("Library & import", "Settings", Dest.Import, "import add epub books files"),
    PageEntry("Backup & restore", "Settings", Dest.Backup, "export save data json restore"),
    PageEntry("Settings", "Settings", Dest.Settings, "preferences options"),
    PageEntry("About", "Settings", Dest.About, "credits licenses version open source"),
)

/**
 * Search across the whole app: books (title, author, journal), your notes and highlights, collections, and
 * the app's own pages. Tap a book for its page, a note to open the book at that passage, a page to go there.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    query: String,
    onQuery: (String) -> Unit,
    recent: List<String>,
    onCommit: (String) -> Unit,
    onClearRecent: () -> Unit,
    books: List<Book>,
    collections: List<BookCollection>,
    membership: Map<String, Set<String>>,
    highlights: List<Highlight>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onOpenBook: (Book) -> Unit,
    onOpenCollection: (BookCollection) -> Unit,
    onOpenNote: (Book, String) -> Unit,
    onOpenPage: (Dest) -> Unit,
    onOpenTag: (String) -> Unit,
    onOpenAuthor: (String) -> Unit,
    catalog: CatalogController,
    wishlist: List<CatalogBook>,
    onOpenCatalogBook: (CatalogBook) -> Unit,
    onBrowse: (kind: String, value: String) -> Unit,
) {
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    // With the online catalog on, an empty Search page shows books to explore, so the keyboard waits for a tap.
    LaunchedEffect(Unit) { if (!catalog.enabled.value || query.isNotEmpty()) runCatching { focus.requestFocus() } }

    val tokens = remember(query) { Search.tokens(query) }
    val bookHits = remember(tokens, books) { Search.books(books, tokens) }
    val noteHits = remember(tokens, highlights) { Search.notes(highlights, tokens) }
    val collectionHits = remember(tokens, collections) { collections.filter { Search.matches(it.name, tokens) } }
    val pageHits = remember(tokens) { PAGES.filter { Search.matches(it.label + " " + it.keywords, tokens) } }
    val tagHits = remember(tokens, books) { Tags.counts(books).filter { Search.matches(it.first, tokens) }.take(MAX_GROUPS) }
    val authorHits = remember(tokens, books) { Authors.counts(books).filter { Search.matches(it.first, tokens) }.take(MAX_GROUPS) }
    val byId = remember(books) { books.associateBy { it.id } }
    val localNothing = tokens.isNotEmpty() && bookHits.isEmpty() && noteHits.isEmpty() && collectionHits.isEmpty() && tagHits.isEmpty() && authorHits.isEmpty() && pageHits.isEmpty()

    // The online catalog is asked once you pause typing, so every letter is not a request.
    val onlineOn by catalog.enabled.collectAsStateWithLifecycle()
    var online by remember { mutableStateOf<Load<List<CatalogBook>>>(Load.Loading) }
    LaunchedEffect(query, onlineOn) {
        val q = query.trim()
        if (!onlineOn || q.length < 2) return@LaunchedEffect
        online = Load.Loading
        delay(600)
        catalog.search(q).fold(
            onSuccess = { online = Load.Ready(it) },
            onFailure = { online = Load.Failed(it.message ?: "Couldn't reach the online catalog.") },
        )
    }
    val owned = remember(books) { ownedKeys(books) }
    val onlineNow = online
    val nothing = localNothing && (!onlineOn || (onlineNow is Load.Ready && onlineNow.value.isEmpty()))

    PbListPage("Search", headerSize, onMenu, onSearch = { runCatching { focus.requestFocus() } }) {
        Spacer(Modifier.height(12.dp))
        PbField(
            value = query,
            onValueChange = onQuery,
            placeholder = "Books, authors, genres, notes, pages",
            modifier = Modifier.focusRequester(focus),
            leading = PbIconName.Search,
            onClear = { onQuery("") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                onCommit(query)
                focusManager.clearFocus()
            }),
        )
        Spacer(Modifier.height(8.dp))

        when {
            tokens.isEmpty() -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 112.dp)) {
                if (recent.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { Eyebrow("Recent searches") }
                        Text(
                            "Clear",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 14.sp,
                            modifier = Modifier.clickable(onClick = onClearRecent).padding(6.dp),
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        recent.forEach { r -> TogglePill(r, false) { onQuery(r) } }
                    }
                } else if (!onlineOn) {
                    Text(
                        "Search your books, authors, journals, notes and collections, or jump to a page like Backup or Reading goals.",
                        color = pbTokens().setSub,
                        modifier = Modifier.padding(vertical = 16.dp),
                    )
                }
                ExploreSection(catalog, books, wishlist, onOpenCatalogBook, onBrowse)
            }

            nothing -> Text(
                "No results for \u201C${query.trim()}\u201D.",
                color = pbTokens().setSub,
                modifier = Modifier.padding(vertical = 16.dp),
            )

            else -> LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 112.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (bookHits.isNotEmpty()) {
                    item(key = "h-books") { SectionLabel("Books \u00B7 ${bookHits.size}") }
                    items(bookHits.take(MAX_BOOKS), key = { "b-${it.book.id}" }) { hit ->
                        BookRow(hit.book, hit.viaJournal, tokens) {
                            onCommit(query)
                            onOpenBook(hit.book)
                        }
                    }
                }
                if (authorHits.isNotEmpty()) {
                    item(key = "h-authors") { SectionLabel("Authors \u00B7 ${authorHits.size}") }
                    items(authorHits, key = { "a-${it.first}" }) { (name, count) ->
                        ResultRow(title = name, detail = "$count ${if (count == 1) "book" else "books"}", tokens = tokens) {
                            onCommit(query)
                            onOpenAuthor(name)
                        }
                    }
                }
                if (tagHits.isNotEmpty()) {
                    item(key = "h-genres") { SectionLabel("Genres \u00B7 ${tagHits.size}") }
                    items(tagHits, key = { "g-${it.first}" }) { (name, count) ->
                        ResultRow(title = name, detail = "$count ${if (count == 1) "book" else "books"}", tokens = tokens) {
                            onCommit(query)
                            onOpenTag(name)
                        }
                    }
                }
                if (collectionHits.isNotEmpty()) {
                    item(key = "h-collections") { SectionLabel("Collections \u00B7 ${collectionHits.size}") }
                    items(collectionHits, key = { "c-${it.id}" }) { c ->
                        val count = membership[c.id].orEmpty().size
                        ResultRow(
                            title = c.name,
                            detail = "$count ${if (count == 1) "book" else "books"}",
                            tokens = tokens,
                        ) {
                            onCommit(query)
                            onOpenCollection(c)
                        }
                    }
                }
                if (noteHits.isNotEmpty()) {
                    item(key = "h-notes") { SectionLabel("Notes & highlights \u00B7 ${noteHits.size}") }
                    items(noteHits.take(MAX_NOTES), key = { "n-${it.id}" }) { h ->
                        NoteRow(h, byId[h.bookId], tokens) {
                            val book = byId[h.bookId]
                            if (book != null) {
                                onCommit(query)
                                onOpenNote(book, h.locatorJson)
                            }
                        }
                    }
                }
                if (pageHits.isNotEmpty()) {
                    item(key = "h-pages") { SectionLabel("Pages \u00B7 ${pageHits.size}") }
                    items(pageHits, key = { "p-${it.dest.name}" }) { p ->
                        ResultRow(title = p.label, detail = p.section, tokens = tokens) {
                            onCommit(query)
                            onOpenPage(p.dest)
                        }
                    }
                }
                if (onlineOn && query.trim().length >= 2) {
                    item(key = "h-online") { SectionLabel("Online catalog") }
                    when (val o = online) {
                        is Load.Loading -> item(key = "o-wait") { Text("Searching the catalog\u2026", color = pbTokens().setSub, modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)) }
                        is Load.Failed -> item(key = "o-fail") { Text(o.message, color = pbTokens().setSub, modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)) }
                        is Load.Ready -> {
                            if (o.value.isEmpty()) {
                                item(key = "o-none") { Text("Nothing found in the catalog.", color = pbTokens().setSub, modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)) }
                            }
                            items(o.value, key = { "o-${it.id}" }) { b ->
                                CatalogResultRow(b, TitleKey.of(b.title) in owned) {
                                    onCommit(query)
                                    onOpenCatalogBook(b)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private const val MAX_BOOKS = 25
private const val MAX_NOTES = 40
private const val MAX_GROUPS = 8

/** [text] with the searched words in coral. */
@Composable
private fun Marked(
    text: String,
    tokens: List<String>,
    modifier: Modifier = Modifier,
    fontSize: Float = 15f,
    fontFamily: FontFamily? = null,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    color: Color = Color.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
) {
    val primary = MaterialTheme.colorScheme.primary
    val annotated = remember(text, tokens, primary) {
        buildAnnotatedString {
            append(text)
            Search.ranges(text, tokens).forEach { r ->
                addStyle(SpanStyle(color = primary, fontWeight = FontWeight.SemiBold), r.first, r.last + 1)
            }
        }
    }
    Text(
        annotated,
        modifier = modifier,
        color = color,
        fontSize = fontSize.sp,
        fontFamily = fontFamily,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
private fun BookRow(book: Book, viaJournal: Boolean, tokens: List<String>, onClick: () -> Unit) {
    Row(
        Modifier.resultCard(onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BookCover(book, Modifier.width(44.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Marked(book.title, tokens, fontSize = 16f, fontFamily = PbSerif, fontWeight = FontWeight.Medium, maxLines = 2)
            if (book.author.isNotBlank()) {
                Marked(book.author, tokens, fontSize = 13f, color = pbTokens().setSub, maxLines = 1)
            }
            val status = when {
                book.finished -> "Finished"
                book.isReading -> "Reading \u00B7 ${book.percent}%"
                else -> ""
            }
            if (status.isNotEmpty()) {
                Text(status, fontSize = 12.sp, color = pbTokens().setSub)
            }
            if (viaJournal) {
                Marked(
                    "Journal: " + Search.snippet(book.journal, tokens, before = 30, after = 90),
                    tokens, fontSize = 13f, fontStyle = FontStyle.Italic,
                    color = pbTokens().setSub, maxLines = 2,
                )
            }
        }
    }
}

@Composable
private fun NoteRow(h: Highlight, book: Book?, tokens: List<String>, onClick: () -> Unit) {
    Row(
        Modifier.resultCard(onClick, enabled = book != null),
    ) {
        Box(Modifier.width(4.dp).height(52.dp).clip(RoundedCornerShape(2.dp)).background(Color(h.color)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                book?.title ?: "Removed book",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (h.text.isNotBlank()) {
                Marked(Search.snippet(h.text, tokens), tokens, fontSize = 15f, maxLines = 4)
            }
            if (h.note.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Marked(
                    Search.snippet(h.note, tokens), tokens, fontSize = 14f, fontStyle = FontStyle.Italic,
                    color = pbTokens().setSub, maxLines = 3,
                )
            }
        }
    }
}

@Composable
private fun ResultRow(title: String, detail: String, tokens: List<String>, onClick: () -> Unit) {
    Row(Modifier.resultCard(onClick), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Marked(title, tokens, fontSize = 16f, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(detail, fontSize = 13.sp, color = pbTokens().setSub)
        }
        PbIcon(PbIconName.CaretRight, size = 18.dp, tint = pbTokens().setSub, strokeWidth = 2f)
    }
}

/** The look of one search result: a rounded card in the card colour. */
@Composable
private fun Modifier.resultCard(onClick: () -> Unit, enabled: Boolean = true): Modifier =
    this
        .fillMaxWidth()
        .clip(RoundedCornerShape(24.dp))
        .background(pbTokens().card)
        .clickable(enabled = enabled, onClick = onClick)
        .padding(horizontal = 16.dp, vertical = 14.dp)

/** A book from the online catalog in the search results. */
@Composable
private fun CatalogResultRow(book: CatalogBook, owned: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    Row(Modifier.resultCard(onClick), verticalAlignment = Alignment.CenterVertically) {
        CatalogCover(book, Modifier.width(44.dp), size = "S")
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(book.title, color = t.ink, fontSize = 16.sp, fontFamily = PbSerif, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (book.author.isNotBlank()) {
                Text(book.author, color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val facts = listOfNotNull(
                if (book.year > 0) book.year.toString() else null,
                ratingText(book.rating).ifEmpty { null },
                if (owned) "In your library" else null,
            ).joinToString("  \u00B7  ")
            if (facts.isNotEmpty()) Text(facts, color = t.setSub, fontSize = 12.sp)
        }
        PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub, strokeWidth = 2f)
    }
}
