package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.pbTokens

/** Every screen of the app. Home, Library and Stats are the tabs; the rest open on top and Back returns. */
enum class Dest(val isTab: Boolean) {
    Home(true),
    Library(true),
    Stats(true),
    Settings(true),
    AppStyle(false),
    Taste(false),
    About(false),
    Appearance(false),
    Goals(false),
    ReaderDefaults(false),
    ReadAloud(false),
    Import(false),
    Backup(false),
    Discover(false),
    Collections(false),
    Notes(false),
    Bookmarks(false),
    Reading(false),
    Recent(false),
    Finished(false),
    Favorites(false),
    Search(false),
    Genres(false),
    Authors(false),
    WantToRead(false),
    More(false),
}

private class MenuItemDef(val name: String, val icon: PbIconName, val dest: Dest?)

// The menu from the design: seven destinations.
private val MAIN = listOf(
    MenuItemDef("Home", PbIconName.Home, Dest.Home),
    MenuItemDef("Library", PbIconName.Library, Dest.Library),
    MenuItemDef("Discover", PbIconName.Discover, Dest.Discover),
    MenuItemDef("Collections", PbIconName.Collections, Dest.Collections),
    MenuItemDef("Bookmarks", PbIconName.Bookmark, Dest.Bookmarks),
    MenuItemDef("Stats", PbIconName.Stats, Dest.Stats),
    MenuItemDef("Settings", PbIconName.Settings, Dest.Settings),
)

/** Pages that count as "being in" Settings (the row is highlighted on them). */
private val SETTINGS_PAGES = setOf(Dest.Settings, Dest.AppStyle, Dest.Taste, Dest.About, Dest.Appearance, Dest.ReaderDefaults, Dest.ReadAloud, Dest.Backup, Dest.Import)

private fun isIn(current: Dest, item: MenuItemDef): Boolean = when (item.dest) {
    null -> false
    Dest.Settings -> current in SETTINGS_PAGES
    Dest.Stats -> current == Dest.Stats || current == Dest.Goals
    else -> current == item.dest
}


/**
 * The menu button's pop-up: a card above the round menu button, over a dimmed screen. The button turns into
 * a close button while it is open (components/paperback/MenuSheet.tsx).
 */
@Composable
fun MenuOverlay(
    open: Boolean,
    current: Dest,
    onClose: () -> Unit,
    onGo: (Dest) -> Unit,
    onSoon: () -> Unit,
    onMore: () -> Unit,
) {
    if (!open) return
    val t = pbTokens()
    Box(Modifier.fillMaxSize()) {
        Scrim(onClose)
        Column(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 20.dp, bottom = 100.dp)
                .width(264.dp)
                .shadow(18.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(t.menuBg)
                .padding(8.dp),
        ) {
            MAIN.forEach { item ->
                val on = isIn(current, item)
                MenuRow(
                    icon = item.icon,
                    name = item.name,
                    on = on,
                    soon = item.dest == null,
                    onClick = {
                        val d = item.dest
                        if (d == null) onSoon() else onGo(d)
                    },
                )
            }
            MenuRow(icon = PbIconName.Dots, name = "More", on = current == Dest.More, soon = false, onClick = onMore)
        }
        MenuFab(
            onClick = onClose,
            close = true,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 24.dp),
        )
    }
}

@Composable
private fun Scrim(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(pbTokens().scrim)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
    )
}

@Composable
private fun MenuRow(icon: PbIconName, name: String, on: Boolean, soon: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (on) t.menuOn else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PbIcon(icon, size = 22.dp, tint = t.ink)
        Spacer(Modifier.width(14.dp))
        Text(
            name,
            modifier = Modifier.weight(1f),
            color = t.ink,
            fontSize = 16.sp,
            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium,
        )
        if (on) Box(Modifier.size(8.dp).clip(CircleShape).background(Accent.color))
        if (soon) Text("Soon", color = t.sub, fontSize = 12.sp)
    }
}
