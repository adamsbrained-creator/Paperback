import React, { useEffect, useState } from 'react';
import { RiRssLine } from 'react-icons/ri';
import { useTranslation } from '@/hooks/useTranslation';
import { useKeyDownActions } from '@/hooks/useKeyDownActions';
import { useSettingsStore } from '@/store/settingsStore';
import { useCustomOPDSStore } from '@/store/customOPDSStore';
import { CatalogManager } from '@/app/opds/components/CatalogManager';
import SubPageHeader from './SubPageHeader';
import { BoxedList, NavigationRow } from './primitives';

type SubPage = 'opds' | null;

/**
 * Integrations: OPDS catalogs (Discover).
 * Each row pushes the panel into an inline sub-page.
 */
const IntegrationsPanel: React.FC = () => {
  const _ = useTranslation();
  const { requestedSubPage, setRequestedSubPage } = useSettingsStore();
  const opdsCatalogs = useCustomOPDSStore((s) => s.catalogs);
  const opdsCount = opdsCatalogs.filter((c) => !c.deletedAt).length;
  const [subPage, setSubPage] = useState<SubPage>(null);

  // Android Back / Esc steps back to the list instead of closing Settings.
  useKeyDownActions({
    enabled: subPage !== null,
    onCancel: () => setSubPage(null),
  });

  // Deep link: a caller (e.g. the OPDS browser's close handler) sets
  // `requestedSubPage` before opening the dialog; drill in and clear it.
  useEffect(() => {
    if (!requestedSubPage) return;
    if (requestedSubPage === 'opds') {
      setSubPage(requestedSubPage);
    }
    setRequestedSubPage(null);
  }, [requestedSubPage, setRequestedSubPage]);

  if (subPage === 'opds')
    return (
      <div className='my-4 w-full'>
        <SubPageHeader
          parentLabel={_('Integrations')}
          currentLabel={_('OPDS Catalogs')}
          description={_('Browse and download books from online catalogs.')}
          onBack={() => setSubPage(null)}
        />
        <CatalogManager inSubPage />
      </div>
    );

  const opdsStatus =
    opdsCount > 0 ? _('{{count}} catalog', { count: opdsCount }) : _('No catalogs');

  return (
    <div className='my-4 w-full space-y-6'>
      <BoxedList
        title={_('Content Sources')}
        data-setting-id='settings.integrations.catalogs'
        cardClassName='overflow-hidden'
      >
        <NavigationRow
          icon={RiRssLine}
          title={_('OPDS Catalogs')}
          status={opdsStatus}
          onClick={() => setSubPage('opds')}
        />
      </BoxedList>
    </div>
  );
};

export default IntegrationsPanel;
