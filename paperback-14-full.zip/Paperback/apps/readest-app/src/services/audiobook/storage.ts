export const getAudiobookDirectory = (bookHash: string): string => `${bookHash}/audiobook`;

export const isAudiobookFilePath = (bookHash: string, path: string): boolean => {
  const prefix = `${getAudiobookDirectory(bookHash)}/`;
  const filename = path.startsWith(prefix) ? path.slice(prefix.length) : '';
  return (
    filename.length > 0 &&
    filename !== '.' &&
    filename !== '..' &&
    !filename.includes('/') &&
    !filename.includes('\\')
  );
};
