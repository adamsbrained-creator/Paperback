import type { TOCItem } from '@/libs/document';

export interface AudiobookTextChapter {
  id: string;
  label: string;
  href: string;
  cfi?: string;
}

export const collectAudiobookTextChapters = (toc: TOCItem[]): AudiobookTextChapter[] => {
  const chapters: AudiobookTextChapter[] = [];
  const seenHrefs = new Set<string>();

  const visit = (items: TOCItem[]) => {
    for (const item of items) {
      const href = item.href.trim();
      if (href && !seenHrefs.has(href)) {
        seenHrefs.add(href);
        chapters.push({
          id: href,
          label: item.label.trim() || href,
          href,
          ...(item.cfi ? { cfi: item.cfi } : {}),
        });
      }
      if (item.subitems?.length) visit(item.subitems);
    }
  };

  visit(toc);
  return chapters;
};
