package com.paperback.app.data.opds

/**
 * Reads OPDS documents: Atom feeds and entries (OPDS 1.x), JSON feeds and publications (OPDS 2.0), OpenSearch
 * descriptions. The TypeScript app used foliate-js for this; the behaviour followed here is the same
 * (publications vs. navigation entries, groups, facets, paging links), written plainly in Kotlin.
 * All links in the result are absolute.
 */
object OpdsParser {
    fun parse(text: String, baseUrl: String): OpdsDoc? {
        val t = text.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        return when {
            t.startsWith("<") -> parseXml(t, baseUrl)
            t.startsWith("{") -> parseJson(t, baseUrl)
            else -> null
        }
    }

    // ---- XML (Atom) -------------------------------------------------------------------------

    private fun parseXml(t: String, base: String): OpdsDoc? {
        val root = MiniXml.parse(t) ?: return null
        return when (root.name) {
            "feed" -> OpdsDoc.Feed(atomFeed(root, base))
            "entry" -> OpdsDoc.Entry(atomPublication(root, base))
            "OpenSearchDescription" -> OpdsDoc.OpenSearch(openSearch(root))
            else -> htmlRedirect(t, base)
        }
    }

    /** A web page that links to its feed: `<link rel="alternate" type="application/atom+xml;profile=opds-catalog" href=...>`. */
    private fun htmlRedirect(text: String, base: String): OpdsDoc.Redirect? {
        for (m in Regex("<link\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(text)) {
            val tag = m.value
            val type = Regex("type\\s*=\\s*[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.get(1) ?: continue
            if (!(type.contains("opds", true) || (type.contains("atom+xml", true) && tag.contains("catalog", true)))) continue
            val href = Regex("href\\s*=\\s*[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.get(1) ?: continue
            val abs = OpdsUrl.resolve(MiniXml.decode(href), base)
            if (abs.isNotEmpty()) return OpdsDoc.Redirect(abs)
        }
        return null
    }

    private fun openSearch(root: XmlNode): List<OpdsSearchTemplate> =
        root.all("Url").mapNotNull { u ->
            val template = u.attr("template")?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            // rel defaults to "results"; skip "suggestions" and friends.
            val rel = u.attr("rel") ?: "results"
            if (!rel.split(' ').contains("results")) return@mapNotNull null
            OpdsSearchTemplate(u.attr("type"), template)
        }

    private fun atomLink(n: XmlNode, base: String): OpdsLink? {
        val href = n.attr("href")?.takeIf { it.isNotBlank() } ?: return null
        val rels = (n.attr("rel") ?: "alternate").split(Regex("\\s+")).filter { it.isNotEmpty() }
        return OpdsLink(
            href = OpdsUrl.resolve(href, base),
            rels = rels,
            type = n.attr("type"),
            title = n.attr("title")?.takeIf { it.isNotBlank() },
            count = (n.attr("count") ?: n.attr("numberOfItems"))?.trim()?.toIntOrNull(),
            active = n.attr("activeFacet") == "true",
            facetGroup = n.attr("facetGroup"),
            indirect = indirectTypes(n),
        )
    }

    private fun indirectTypes(n: XmlNode): List<String> {
        val out = ArrayList<String>()
        fun walk(node: XmlNode) {
            for (c in node.all("indirectAcquisition")) {
                c.attr("type")?.let { out.add(it) }
                walk(c)
            }
        }
        walk(n)
        return out
    }

    private fun fixName(s: String): String = s.replace('|', ',').trim()

    private fun atomPublication(e: XmlNode, base: String): OpdsPublication {
        val links = e.all("link").mapNotNull { atomLink(it, base) }
        val content = e.child("content") ?: e.child("summary")
        val summary = content?.let { c ->
            val type = (c.attr("type") ?: "text").lowercase()
            val raw = if (type == "xhtml" || (c.children.isNotEmpty() && c.text.isBlank())) c.inner else c.text.toString()
            raw.trim().takeIf { it.isNotEmpty() }
        }
        return OpdsPublication(
            id = e.textOf("id"),
            title = e.textOf("title") ?: "Untitled",
            subtitle = null,
            authors = e.all("author").mapNotNull { it.textOf("name") }.map(::fixName).filter { it.isNotEmpty() },
            summary = summary,
            publisher = e.textOf("publisher"),
            published = e.textOf("issued") ?: e.textOf("published") ?: e.textOf("date"),
            updated = e.textOf("updated"),
            languages = e.all("language").map { it.text.toString().trim() }.filter { it.isNotEmpty() },
            identifier = e.textOf("identifier"),
            subjects = e.all("category").mapNotNull { (it.attr("label") ?: it.attr("term"))?.trim()?.takeIf { s -> s.isNotEmpty() } },
            links = links,
            images = links.filter { it.isImage },
        )
    }

    private fun atomFeed(root: XmlNode, base: String): OpdsFeed {
        val links = root.all("link").mapNotNull { atomLink(it, base) }

        val navigation = ArrayList<OpdsNav>()
        val publications = ArrayList<OpdsPublication>()
        // Group key (title + address) -> the entries filed under it, in the order the feed lists them.
        class Bucket(val title: String, val href: String?) {
            val nav = ArrayList<OpdsNav>()
            val pubs = ArrayList<OpdsPublication>()
        }
        val groups = LinkedHashMap<String, Bucket>()

        for (e in root.all("entry")) {
            val entryLinks = e.all("link").mapNotNull { atomLink(it, base) }
            val groupLink = entryLinks.firstOrNull { it.hasRel(Rel.GROUP) }
            val images = entryLinks.filter { it.isImage }
            val acquisitions = entryLinks.filter { it.isAcquisition }
            val navLink = entryLinks.firstOrNull { l ->
                !l.isImage && !l.isAcquisition && !l.hasRel("self") && !l.hasRel("search") &&
                    l.type?.let { it.contains("opds") || it.contains("atom+xml") } == true
            }
            val isPublication = acquisitions.isNotEmpty() || e.child("author") != null ||
                (images.isNotEmpty() && navLink == null)

            if (isPublication) {
                val pub = atomPublication(e, base)
                if (groupLink != null) {
                    groups.getOrPut("${groupLink.title}|${groupLink.href}") { Bucket(groupLink.title ?: "", groupLink.href) }.pubs.add(pub)
                } else {
                    publications.add(pub)
                }
            } else {
                val href = (navLink ?: entryLinks.firstOrNull { !it.isImage && !it.hasRel("self") })?.href ?: continue
                val nav = OpdsNav(
                    title = e.textOf("title") ?: "Untitled",
                    href = href,
                    summary = (e.child("content") ?: e.child("summary"))?.let { c ->
                        OpdsText.plain(if (c.children.isNotEmpty() && c.text.isBlank()) c.inner else c.text.toString()).takeIf { it.isNotEmpty() }
                    },
                    count = navLink?.count,
                )
                if (groupLink != null) {
                    groups.getOrPut("${groupLink.title}|${groupLink.href}") { Bucket(groupLink.title ?: "", groupLink.href) }.nav.add(nav)
                } else {
                    navigation.add(nav)
                }
            }
        }

        // Filters: links with the facet relation, collected by their facet group.
        val facets = links.filter { it.hasRel(Rel.FACET) }
            .groupBy { it.facetGroup }
            .map { (name, ls) -> OpdsFacet(name, ls) }

        return OpdsFeed(
            title = root.textOf("title"),
            subtitle = root.textOf("subtitle"),
            links = links,
            navigation = navigation,
            publications = publications,
            groups = groups.values.map { OpdsGroup(it.title, it.href, it.nav, it.pubs) },
            facets = facets,
        )
    }

    // ---- JSON (OPDS 2.0) --------------------------------------------------------------------

    @Suppress("UNCHECKED_CAST")
    private fun Any?.asMap(): Map<String, Any?>? = this as? Map<String, Any?>

    private fun Any?.list(): List<Any?> = (this as? List<*>) ?: emptyList()

    private fun Any?.text(): String? = (this as? String)?.trim()?.takeIf { it.isNotEmpty() }

    private fun parseJson(t: String, base: String): OpdsDoc? {
        val root = MiniJson.parse(t).asMap() ?: return null
        val isFeed = root.containsKey("navigation") || root.containsKey("publications") ||
            root.containsKey("groups") || root.containsKey("facets")
        if (!isFeed) {
            val meta = root["metadata"].asMap()
            if (meta != null && meta["title"].text() != null) return OpdsDoc.Entry(jsonPublication(root, base))
        }
        val meta = root["metadata"].asMap()
        val links = root["links"].list().mapNotNull { jsonLink(it, base) }
        val navigation = root["navigation"].list().mapNotNull { jsonNav(it, base) }
        val publications = root["publications"].list().mapNotNull { p -> p.asMap()?.let { jsonPublication(it, base) } }
        val groups = root["groups"].list().mapNotNull { g ->
            val gm = g.asMap() ?: return@mapNotNull null
            OpdsGroup(
                title = gm["metadata"].asMap()?.get("title").text() ?: "",
                moreHref = gm["links"].list().mapNotNull { jsonLink(it, base) }.let { ls ->
                    (ls.firstOrNull { it.hasRel("self") } ?: ls.firstOrNull())?.href
                },
                navigation = gm["navigation"].list().mapNotNull { jsonNav(it, base) },
                publications = gm["publications"].list().mapNotNull { p -> p.asMap()?.let { jsonPublication(it, base) } },
            )
        }
        val facets = root["facets"].list().mapNotNull { f ->
            val fm = f.asMap() ?: return@mapNotNull null
            OpdsFacet(
                title = fm["metadata"].asMap()?.get("title").text(),
                links = fm["links"].list().mapNotNull { l -> jsonLink(l, base)?.let { it.copy(active = it.hasRel("self")) } },
            )
        }
        return OpdsDoc.Feed(
            OpdsFeed(
                title = meta?.get("title").text(),
                subtitle = meta?.get("subtitle").text(),
                links = links,
                navigation = navigation,
                publications = publications,
                groups = groups,
                facets = facets,
            ),
        )
    }

    private fun jsonLink(any: Any?, base: String): OpdsLink? {
        val m = any.asMap() ?: return null
        val href = m["href"].text() ?: return null
        val rels = when (val r = m["rel"]) {
            is String -> r.split(Regex("\\s+")).filter { it.isNotEmpty() }
            is List<*> -> r.mapNotNull { (it as? String)?.trim()?.takeIf { s -> s.isNotEmpty() } }
            else -> emptyList()
        }
        val props = m["properties"].asMap()
        val indirect = ArrayList<String>()
        fun walk(items: List<Any?>) {
            for (x in items) {
                val im = x.asMap() ?: continue
                im["type"].text()?.let { indirect.add(it) }
                walk(im["child"].list())
            }
        }
        walk(props?.get("indirectAcquisition").list())
        return OpdsLink(
            href = OpdsUrl.resolve(href, base),
            rels = rels,
            type = m["type"].text(),
            title = m["title"].text(),
            templated = m["templated"] == true,
            count = (props?.get("numberOfItems") as? Double)?.toInt(),
            indirect = indirect,
        )
    }

    private fun jsonNav(any: Any?, base: String): OpdsNav? {
        val link = jsonLink(any, base) ?: return null
        return OpdsNav(title = link.title ?: "Untitled", href = link.href, summary = null, count = link.count)
    }

    private fun names(v: Any?): List<String> = when (v) {
        is String -> listOf(v)
        is Map<*, *> -> listOfNotNull((v["name"] as? String))
        is List<*> -> v.flatMap { names(it) }
        else -> emptyList()
    }.map(::fixName).filter { it.isNotEmpty() }

    private fun jsonPublication(root: Map<String, Any?>, base: String): OpdsPublication {
        val m = root["metadata"].asMap() ?: emptyMap()
        val links = root["links"].list().mapNotNull { jsonLink(it, base) }
        val images = root["images"].list().mapNotNull { jsonLink(it, base) }.map { img ->
            // OPDS 2 images often carry no rel; treat a bare image as the cover.
            if (img.rels.isEmpty()) img.copy(rels = listOf(Rel.COVER[0])) else img
        }
        val languages = when (val l = m["language"]) {
            is String -> listOf(l)
            is List<*> -> l.mapNotNull { it as? String }
            else -> emptyList()
        }.map { it.trim() }.filter { it.isNotEmpty() }
        val subjects = m["subject"].let { s ->
            (if (s is List<*>) s else listOf(s)).mapNotNull { x ->
                when (x) {
                    is String -> x
                    is Map<*, *> -> (x["name"] as? String) ?: (x["code"] as? String)
                    else -> null
                }?.trim()?.takeIf { it.isNotEmpty() }
            }
        }
        return OpdsPublication(
            id = m["identifier"].text() ?: m["id"].text(),
            title = m["title"].text() ?: "Untitled",
            subtitle = m["subtitle"].text(),
            authors = names(m["author"]),
            summary = m["description"].text(),
            publisher = names(m["publisher"]).joinToString(", ").takeIf { it.isNotEmpty() },
            published = m["published"].text(),
            updated = m["modified"].text() ?: m["updated"].text(),
            languages = languages,
            identifier = m["identifier"].text(),
            subjects = subjects,
            links = links + images,
            images = images,
        )
    }
}
