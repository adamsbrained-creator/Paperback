package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Backup
import com.paperback.app.data.BackupCounts
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.PendingBackup
import com.paperback.app.data.ThemeMode
import com.paperback.app.reader.readerColors
import com.paperback.app.ui.theme.Coral
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlin.math.roundToInt

// ---- shared pieces ------------------------------------------------------------------------------

/** The big pill button (.pb-btn): ink on page colour, or [ghost] on the card colour. */
@Composable
fun PbButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, ghost: Boolean = false, enabled: Boolean = true, destructive: Boolean = false) {
    val t = pbTokens()
    Box(
        modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.4f)
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(if (ghost) t.card else t.ink)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (destructive) DangerRed else if (ghost) t.ink else t.bg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** A little note under a card (.pb-note). */
@Composable
fun PbNote(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(start = 2.dp, end = 2.dp, top = 8.dp),
        color = pbTokens().sub,
        fontSize = 13.sp,
        lineHeight = 18.2.sp,
    )
}

/** The rounded segmented switch used on App style (.pb-as-seg). */
@Composable
private fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    val t = pbTokens()
    Row(
        Modifier
            .padding(top = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(t.asTrack)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        options.forEach { (value, label) ->
            val on = value == selected
            val shape = RoundedCornerShape(18.dp)
            Box(
                Modifier
                    .weight(1f)
                    .height(36.dp)
                    .then(if (on) Modifier.shadow(1.dp, shape) else Modifier)
                    .clip(shape)
                    .background(if (on) t.asOn else Color.Transparent)
                    .clickable { onSelect(value) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (on) t.asOnInk else t.setSub,
                    fontSize = 15.sp,
                    fontWeight = if (on) FontWeight.Medium else FontWeight.Normal,
                )
            }
        }
    }
}

/** A card with a title, a one-line hint and whatever [content] adds (.pb-as-card). */
@Composable
private fun AsCard(title: String, hint: String, content: @Composable () -> Unit) {
    val t = pbTokens()
    Column(
        Modifier
            .padding(top = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .padding(16.dp),
    ) {
        Text(title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Text(hint, color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        content()
    }
}

// ---- App style ----------------------------------------------------------------------------------

private class StyleSample(val size: HeaderSize, val note: String? = null, val isDefault: Boolean = false)

private val SAMPLES = listOf(
    StyleSample(HeaderSize.Compact, note = "no circles, left-aligned"),
    StyleSample(HeaderSize.Regular, isDefault = true),
    StyleSample(HeaderSize.Large),
)

@Composable
private fun Badge(text: String, selected: Boolean) {
    val t = pbTokens()
    Text(
        text,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) t.asSelBg else t.asBadge)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        color = if (selected) t.asSelInk else t.setSub,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
    )
}

/** Settings → App style: how much room the top bar takes, with a live sample of each size. */
@Composable
fun AppStyleScreen(
    headerSize: HeaderSize,
    onSize: (HeaderSize) -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    PbPage("App style", headerSize, onMenu, onSearch) {
        Text(
            "Choose how much room the top bar takes on every screen.",
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 18.dp),
            color = t.setSub,
            fontSize = 15.sp,
            lineHeight = 21.75.sp,
        )
        AsCard("Header size", "Compact gives your books the most space.") {
            Segmented(HeaderSize.values().map { it to it.label }, headerSize, onSize)
        }
        SAMPLES.forEachIndexed { index, sample ->
            val on = headerSize == sample.size
            Column(Modifier.padding(top = if (index == 0) 20.dp else 16.dp)) {
                Row(
                    Modifier.padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(sample.size.label, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    if (sample.note != null) Text(sample.note, color = t.setSub, fontSize = 12.sp)
                    if (sample.isDefault) Badge("Default", selected = false)
                    if (on) Badge("Selected", selected = true)
                }
                val topPad = when (sample.size) {
                    HeaderSize.Compact -> 4.dp
                    HeaderSize.Regular -> 6.dp
                    HeaderSize.Large -> 12.dp
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .border(if (on) 2.dp else 1.dp, if (on) Color(0xFFF2674A) else t.asEdge, RoundedCornerShape(22.dp))
                        .padding(start = 12.dp, end = 12.dp, top = topPad, bottom = 12.dp),
                ) {
                    PageHeader(label = "Library", size = sample.size)
                }
            }
        }
    }
}

// ---- About --------------------------------------------------------------------------------------

private class AboutCard(val title: String, val body: List<androidx.compose.ui.text.AnnotatedString>)

/** Settings → About Paperback: the logo, the version, then Credits and Open-source licenses cards. */
@Composable
fun AboutScreen(
    headerSize: HeaderSize,
    version: String,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    var open by remember { mutableStateOf<String?>(null) }

    fun text(vararg parts: Pair<Boolean, String>) = buildAnnotatedString {
        parts.forEach { (bold, s) ->
            if (bold) withStyle(SpanStyle(color = t.ink, fontWeight = FontWeight.SemiBold)) { append(s) } else append(s)
        }
    }

    val cards = listOf(
        AboutCard(
            "Credits",
            listOf(
                text(
                    false to "Paperback is built with Readium's Kotlin toolkit, which renders your books, and Jetpack Compose. Design by you.",
                ),
                text(
                    true to "Your data.",
                    false to " Your library, notes, highlights and reading stats live on this device. There is no account and nothing is sent anywhere.",
                ),
            ),
        ),
        AboutCard(
            "Open-source licenses",
            listOf(
                text(
                    false to "The Readium Kotlin toolkit is released under the ",
                    true to "BSD 3-Clause",
                    false to " license. Jetpack Compose, AndroidX and Kotlin are released under the ",
                    true to "Apache License 2.0",
                    false to ". Their copyright notices stay with them.",
                ),
            ),
        ),
    )

    PbPage("About", headerSize, onMenu, onSearch) {
        Column(Modifier.fillMaxWidth().padding(top = 44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            LogoTile(size = 104.dp, radius = 24.dp, markSize = 66.dp)
            Text(
                "paperback",
                modifier = Modifier.padding(top = 26.dp),
                color = t.ink,
                fontSize = 46.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = (-0.035).em,
            )
            Text(
                "Version $version · personal build",
                modifier = Modifier.padding(top = 10.dp),
                color = t.setSub,
                fontSize = 14.sp,
            )
        }
        Column(Modifier.padding(top = 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            cards.forEach { c ->
                val on = open == c.title
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(t.card)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { open = if (on) null else c.title }
                            .padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            c.title,
                            modifier = Modifier.weight(1f),
                            color = t.ink,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = (-0.01).em,
                        )
                        PbIcon(PbIconName.CaretRight, modifier = Modifier.rotate(if (on) 90f else 0f), size = 22.dp, tint = t.ink)
                    }
                    if (on) {
                        Column(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            c.body.forEach { p -> Text(p, color = t.setSub, fontSize = 14.sp, lineHeight = 21.sp) }
                        }
                    }
                }
            }
        }
    }
}

// ---- Appearance ---------------------------------------------------------------------------------

@Composable
private fun ThemeCard(dark: Boolean, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(28.dp)
    val ring = if (dark) Color(0x2EFFFFFF) else Color(0x1A000000)
    val lineA = if (dark) Color(0xFFCCCCCC) else Color(0xFF444444)
    val line = if (dark) Color(0xFF666666) else Color(0xFF9A9AA0)
    Box(
        modifier
            .height(150.dp)
            .clip(shape)
            .background(if (dark) Color.Black else Color.White)
            .border(if (selected) 3.dp else 1.dp, if (selected) Color(0xFF2330F0) else ring, shape)
            .clickable(onClick = onClick),
    ) {
        Column(Modifier.padding(start = 19.dp, end = 19.dp, top = 20.dp)) {
            Box(Modifier.fillMaxWidth(0.60f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(lineA))
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth(0.85f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(line))
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth(0.50f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(line))
        }
        Text(
            if (dark) "Dark" else "Light",
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 19.dp, bottom = 17.dp),
            color = if (dark) Color.White else Color(0xFF0A0A0A),
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/** Settings → Appearance: Light, Dark or Match system. */
@Composable
fun AppearanceScreen(
    headerSize: HeaderSize,
    mode: ThemeMode,
    onMode: (ThemeMode) -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    PbPage("Appearance", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ThemeCard(dark = false, selected = mode == ThemeMode.Light, onClick = { onMode(ThemeMode.Light) }, modifier = Modifier.weight(1f))
                ThemeCard(dark = true, selected = mode == ThemeMode.Dark, onClick = { onMode(ThemeMode.Dark) }, modifier = Modifier.weight(1f))
            }
            val auto = mode == ThemeMode.System
            Row {
                Box(
                    Modifier
                        .height(36.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (auto) t.ink else t.card)
                        .clickable { onMode(ThemeMode.System) }
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Match system", color = if (auto) t.bg else t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
            PbNote(
                "Page colors and font size for reading are set inside a book (tap the middle of the page) " +
                    "and in Settings → Reader defaults.",
            )
        }
    }
}

// ---- Reader defaults ----------------------------------------------------------------------------

/** Settings → Reader defaults: font size and page colors, the same two choices the reader's controls change. */
@Composable
fun ReaderDefaultsScreen(
    headerSize: HeaderSize,
    fontSize: Double,
    theme: Int,
    onFontSize: (Double) -> Unit,
    onTheme: (Int) -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    var size by remember { mutableFloatStateOf(fontSize.toFloat()) }
    var page by remember { mutableIntStateOf(theme) }
    val c = readerColors(page)
    PbPage("Reader defaults", headerSize, onMenu, onSearch) {
        Text(
            "How books look when you open them. You can also change these while reading.",
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 18.dp),
            color = t.setSub,
            fontSize = 15.sp,
            lineHeight = 21.75.sp,
        )
        AsCard("Font size", "${(size * 100).roundToInt()}% of the book's own size.") {
            Slider(
                value = size,
                onValueChange = {
                    size = (it * 10f).roundToInt() / 10f
                    onFontSize(size.toDouble())
                },
                valueRange = 0.6f..2.5f,
                steps = 18,
                colors = SliderDefaults.colors(
                    thumbColor = Coral,
                    activeTrackColor = Coral,
                    inactiveTrackColor = t.ink.copy(alpha = 0.15f),
                ),
            )
        }
        AsCard("Page colors", "Light, sepia or dark paper.") {
            Segmented(
                listOf(0 to "Light", 1 to "Sepia", 2 to "Dark"),
                page,
            ) {
                page = it
                onTheme(it)
            }
        }
        Text(
            "Call me Ishmael. Some years ago—never mind how long precisely—having little or no money in my purse, " +
                "and nothing particular to interest me on shore, I thought I would sail about a little and see the " +
                "watery part of the world.",
            modifier = Modifier
                .padding(top = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(c.page)
                .border(1.dp, t.asEdge, RoundedCornerShape(24.dp))
                .padding(20.dp),
            color = c.ink,
            fontFamily = PbSerif,
            fontSize = (16f * size).sp,
            lineHeight = (16f * size * 1.5f).sp,
        )
    }
}

// ---- Import -------------------------------------------------------------------------------------

/** Settings → Library & import: add books from the phone. */
@Composable
fun ImportScreen(
    headerSize: HeaderSize,
    busy: Boolean,
    onPick: () -> Unit,
    onDiscover: () -> Unit,
    onLibrary: () -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    PbPage("Import", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(t.card)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("Add books", color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("EPUB", color = t.sub, fontSize = 13.sp)
                PbButton(if (busy) "Importing…" else "Choose books from your phone", onPick, enabled = !busy)
            }
            PbNote("You can pick several files at once. To fetch books from the internet instead, open Discover.")
            PbButton("Discover free books", onDiscover, ghost = true)
            PbButton("Back to the Library", onLibrary, ghost = true)
        }
    }
}

// ---- Backup & restore ---------------------------------------------------------------------------

/** Settings → Backup & restore: one file with everything Paperback adds to your books. */
@Composable
fun BackupScreen(
    headerSize: HeaderSize,
    counts: BackupCounts?,
    pending: PendingBackup?,
    onSave: () -> Unit,
    onPick: () -> Unit,
    onApply: () -> Unit,
    onCancel: () -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    PbPage("Backup & restore", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(t.card).padding(16.dp)) {
                Text("Your Paperback data", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    (counts?.describe() ?: "Counting…") + ", plus your reading goals and settings.",
                    modifier = Modifier.padding(top = 6.dp),
                    color = t.sub,
                    fontSize = 13.sp,
                )
            }

            PbButton("Save a backup file", onSave)
            PbButton("Restore from a backup file", onPick, ghost = true)

            if (pending != null) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(t.card).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("Restore this backup?", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    val made = Backup.madeOn(pending.exportedAt)
                    Text(
                        (if (made != null) "Made $made. " else "") + pending.counts.describe() +
                            ". Favorites, ratings, finished marks, reading progress, goals and settings are set to what " +
                            "the backup says; bookmarks, highlights and reading history are added for the books in " +
                            "your library.",
                        color = t.sub,
                        fontSize = 13.sp,
                        lineHeight = 18.2.sp,
                    )
                    PbButton("Restore my data", onApply)
                    PbButton("Cancel", onCancel, ghost = true)
                }
            }

            PbNote(
                "This file holds only what Paperback adds: progress, favorites, ratings, bookmarks, highlights, " +
                    "notes, reading history, goals and settings. The book files themselves are not inside, so add " +
                    "your books to the library again before restoring.",
            )
        }
    }
}
