package com.paperback.app.reader

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Bookmark
import com.paperback.app.data.Highlight
import com.paperback.app.data.HighlightColors
import com.paperback.app.ui.theme.PbSerif
import org.readium.r2.shared.publication.Locator

/** What the note dialog is editing: a new highlight (highlightId == null) or an existing one. */
data class NoteEditorState(
    val highlightId: String?,
    val locator: Locator?,
    val quote: String,
    val note: String,
    val color: Int,
)

/** Full-screen list of this book's bookmarks and notes. Tap one to jump there. */
@Composable
fun ReaderPanel(
    themeIndex: Int,
    bookmarks: List<Bookmark>,
    highlights: List<Highlight>,
    onGo: (String) -> Unit,
    onDeleteBookmark: (Bookmark) -> Unit,
    onDeleteHighlight: (Highlight) -> Unit,
    onClose: () -> Unit,
) {
    val c = readerColors(themeIndex)
    var tab by remember { mutableIntStateOf(if (bookmarks.isEmpty() && highlights.isNotEmpty()) 1 else 0) }
    BackHandler(onBack = onClose)

    Column(
        Modifier
            .fillMaxSize()
            .background(c.page)
            // swallow touches so nothing reaches the book underneath
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
            .windowInsetsPadding(WindowInsets.systemBarsIgnoringVisibility)
            .padding(horizontal = 20.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Bookmarks & notes",
                modifier = Modifier.weight(1f),
                color = c.ink,
                fontFamily = PbSerif,
                fontSize = 24.sp,
                fontWeight = FontWeight.Medium,
            )
            Pill(c, "Done", onClick = onClose)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(c, "Bookmarks (${bookmarks.size})", selected = tab == 0) { tab = 0 }
            Pill(c, "Notes (${highlights.size})", selected = tab == 1) { tab = 1 }
        }
        Spacer(Modifier.height(12.dp))

        if (tab == 0) {
            if (bookmarks.isEmpty()) {
                Empty(c, "No bookmarks yet. Tap the bookmark button at the top of a page.")
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(bookmarks, key = { it.id }) { b ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onGo(b.locatorJson) }.padding(vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                "Page ${b.position} · ${(b.progress * 100).toInt().coerceIn(0, 100)}%",
                                modifier = Modifier.weight(1f),
                                color = c.ink,
                                fontSize = 16.sp,
                            )
                            Text(
                                "Remove",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                modifier = Modifier.clickable { onDeleteBookmark(b) }.padding(8.dp),
                            )
                        }
                    }
                }
            }
        } else {
            if (highlights.isEmpty()) {
                Empty(c, "No notes yet. Select some text and choose Highlight or Note.")
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(highlights, key = { it.id }) { h ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onGo(h.locatorJson) }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            Box(Modifier.width(4.dp).height(56.dp).clip(RoundedCornerShape(2.dp)).background(Color(h.color)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    h.text.ifBlank { "(no text)" },
                                    color = c.ink,
                                    fontSize = 15.sp,
                                    maxLines = 4,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                if (h.note.isNotBlank()) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(h.note, color = c.ink.copy(alpha = 0.75f), fontSize = 14.sp, fontStyle = FontStyle.Italic)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("${(h.progress * 100).toInt().coerceIn(0, 100)}% into the book", color = c.ink.copy(alpha = 0.5f), fontSize = 12.sp)
                            }
                            Text(
                                "Remove",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                modifier = Modifier.clickable { onDeleteHighlight(h) }.padding(8.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Empty(c: ReaderColors, text: String) {
    Text(text, color = c.ink.copy(alpha = 0.6f), fontSize = 15.sp, modifier = Modifier.padding(vertical = 24.dp))
}

@Composable
fun NoteEditorDialog(
    state: NoteEditorState,
    themeIndex: Int,
    onSave: (note: String, color: Int) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    val c = readerColors(themeIndex)
    var note by remember(state) { mutableStateOf(state.note) }
    var color by remember(state) { mutableIntStateOf(state.color) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.ink,
        textContentColor = c.ink,
        title = { Text(if (state.highlightId == null) "New note" else "Highlight", fontFamily = PbSerif) },
        text = {
            Column {
                if (state.quote.isNotBlank()) {
                    Text(
                        "\u201C${state.quote}\u201D",
                        fontStyle = FontStyle.Italic,
                        fontSize = 14.sp,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(14.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    HighlightColors.all.forEach { argb ->
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(argb))
                                .then(if (argb == color) Modifier.border(2.dp, c.ink, CircleShape) else Modifier)
                                .clickable { color = argb },
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Add a note") },
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = c.ink,
                        unfocusedTextColor = c.ink,
                        cursorColor = MaterialTheme.colorScheme.primary,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = c.ink.copy(alpha = 0.3f),
                        focusedPlaceholderColor = c.ink.copy(alpha = 0.5f),
                        unfocusedPlaceholderColor = c.ink.copy(alpha = 0.5f),
                    ),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(note.trim(), color) }) {
                Text("Save", color = MaterialTheme.colorScheme.primary)
            }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Delete", color = c.ink) }
                }
                TextButton(onClick = onDismiss) { Text("Cancel", color = c.ink) }
            }
        },
    )
}
