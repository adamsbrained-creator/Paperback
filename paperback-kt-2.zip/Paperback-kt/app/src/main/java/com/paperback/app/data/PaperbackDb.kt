package com.paperback.app.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Plain SQLite on purpose: no annotation processor, so nothing to break the build. All calls block; use Dispatchers.IO. */
class PaperbackDb(context: Context) : SQLiteOpenHelper(context, "paperback.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE books (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                language TEXT NOT NULL,
                file_path TEXT NOT NULL,
                cover_path TEXT,
                added_at INTEGER NOT NULL,
                last_opened_at INTEGER NOT NULL DEFAULT 0,
                progress REAL NOT NULL DEFAULT 0,
                position INTEGER NOT NULL DEFAULT 0,
                total_positions INTEGER NOT NULL DEFAULT 0,
                locator TEXT,
                finished INTEGER NOT NULL DEFAULT 0,
                favorite INTEGER NOT NULL DEFAULT 0,
                rating INTEGER NOT NULL DEFAULT 0
            )""",
        )
        db.execSQL(
            """CREATE TABLE sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id TEXT NOT NULL,
                start_ms INTEGER NOT NULL,
                seconds INTEGER NOT NULL,
                pages INTEGER NOT NULL DEFAULT 0
            )""",
        )
        db.execSQL("CREATE INDEX idx_sessions_start ON sessions(start_ms)")
        createAnnotationTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createAnnotationTables(db) // round 2: bookmarks and highlights
    }

    private fun createAnnotationTables(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS bookmarks (
                id TEXT PRIMARY KEY,
                book_id TEXT NOT NULL,
                locator TEXT NOT NULL,
                position INTEGER NOT NULL,
                progress REAL NOT NULL,
                created_at INTEGER NOT NULL
            )""",
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_bookmarks_book ON bookmarks(book_id)")
        db.execSQL(
            """CREATE TABLE IF NOT EXISTS highlights (
                id TEXT PRIMARY KEY,
                book_id TEXT NOT NULL,
                locator TEXT NOT NULL,
                text TEXT NOT NULL,
                note TEXT NOT NULL,
                color INTEGER NOT NULL,
                progress REAL NOT NULL,
                created_at INTEGER NOT NULL
            )""",
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_highlights_book ON highlights(book_id)")
    }

    fun allBooks(): List<Book> =
        readableDatabase.query("books", null, null, null, null, null, "added_at DESC").use { c ->
            buildList { while (c.moveToNext()) add(c.toBook()) }
        }

    fun hasBook(id: String): Boolean =
        readableDatabase.query("books", arrayOf("id"), "id = ?", arrayOf(id), null, null, null).use { it.moveToFirst() }

    /** Returns false when a book with this id already exists. */
    fun insertBook(b: Book): Boolean {
        val cv = ContentValues().apply {
            put("id", b.id)
            put("title", b.title)
            put("author", b.author)
            put("language", b.language)
            put("file_path", b.filePath)
            put("cover_path", b.coverPath)
            put("added_at", b.addedAt)
            put("total_positions", b.totalPositions)
        }
        return writableDatabase.insertWithOnConflict("books", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun updateProgress(id: String, locatorJson: String, progress: Float, position: Int, openedAt: Long) {
        val cv = ContentValues().apply {
            put("locator", locatorJson)
            put("progress", progress)
            put("position", position)
            put("last_opened_at", openedAt)
        }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun touchOpened(id: String, openedAt: Long) {
        val cv = ContentValues().apply { put("last_opened_at", openedAt) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setFlag(id: String, column: String, value: Boolean) {
        require(column == "finished" || column == "favorite")
        val cv = ContentValues().apply { put(column, if (value) 1 else 0) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun setRating(id: String, stars: Int) {
        val cv = ContentValues().apply { put("rating", stars.coerceIn(0, 5)) }
        writableDatabase.update("books", cv, "id = ?", arrayOf(id))
    }

    fun deleteBook(id: String) {
        // Reading sessions stay: your history should survive removing a book.
        writableDatabase.delete("books", "id = ?", arrayOf(id))
    }

    fun insertSession(bookId: String, startMs: Long, seconds: Int, pages: Int) {
        val cv = ContentValues().apply {
            put("book_id", bookId)
            put("start_ms", startMs)
            put("seconds", seconds)
            put("pages", pages)
        }
        writableDatabase.insert("sessions", null, cv)
    }

    fun allSessions(): List<ReadingSession> =
        readableDatabase.query("sessions", null, null, null, null, null, "start_ms ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        ReadingSession(
                            id = c.lng("id"),
                            bookId = c.str("book_id"),
                            startMs = c.lng("start_ms"),
                            seconds = c.int("seconds"),
                            pages = c.int("pages"),
                        ),
                    )
                }
            }
        }

    // ---- bookmarks ------------------------------------------------------------------------

    fun bookmarksFor(bookId: String): List<Bookmark> =
        readableDatabase.query("bookmarks", null, "book_id = ?", arrayOf(bookId), null, null, "progress ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Bookmark(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            position = c.int("position"), progress = c.getFloat(c.col("progress")),
                            createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    fun insertBookmark(b: Bookmark) {
        val cv = ContentValues().apply {
            put("id", b.id)
            put("book_id", b.bookId)
            put("locator", b.locatorJson)
            put("position", b.position)
            put("progress", b.progress)
            put("created_at", b.createdAt)
        }
        writableDatabase.insertWithOnConflict("bookmarks", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun deleteBookmark(id: String) {
        writableDatabase.delete("bookmarks", "id = ?", arrayOf(id))
    }

    // ---- highlights and notes -------------------------------------------------------------

    fun highlightsFor(bookId: String): List<Highlight> =
        readableDatabase.query("highlights", null, "book_id = ?", arrayOf(bookId), null, null, "progress ASC, created_at ASC").use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Highlight(
                            id = c.str("id"), bookId = c.str("book_id"), locatorJson = c.str("locator"),
                            text = c.str("text"), note = c.str("note"), color = c.int("color"),
                            progress = c.getFloat(c.col("progress")), createdAt = c.lng("created_at"),
                        ),
                    )
                }
            }
        }

    fun insertHighlight(h: Highlight) {
        val cv = ContentValues().apply {
            put("id", h.id)
            put("book_id", h.bookId)
            put("locator", h.locatorJson)
            put("text", h.text)
            put("note", h.note)
            put("color", h.color)
            put("progress", h.progress)
            put("created_at", h.createdAt)
        }
        writableDatabase.insertWithOnConflict("highlights", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun updateHighlight(id: String, note: String, color: Int) {
        val cv = ContentValues().apply {
            put("note", note)
            put("color", color)
        }
        writableDatabase.update("highlights", cv, "id = ?", arrayOf(id))
    }

    fun deleteHighlight(id: String) {
        writableDatabase.delete("highlights", "id = ?", arrayOf(id))
    }

    private fun Cursor.col(name: String) = getColumnIndexOrThrow(name)
    private fun Cursor.str(name: String): String = getString(col(name))
    private fun Cursor.strOrNull(name: String): String? = if (isNull(col(name))) null else getString(col(name))
    private fun Cursor.int(name: String): Int = getInt(col(name))
    private fun Cursor.lng(name: String): Long = getLong(col(name))

    private fun Cursor.toBook() = Book(
        id = str("id"),
        title = str("title"),
        author = str("author"),
        language = str("language"),
        filePath = str("file_path"),
        coverPath = strOrNull("cover_path"),
        addedAt = lng("added_at"),
        lastOpenedAt = lng("last_opened_at"),
        progress = getFloat(col("progress")),
        position = int("position"),
        totalPositions = int("total_positions"),
        locatorJson = strOrNull("locator"),
        finished = int("finished") == 1,
        favorite = int("favorite") == 1,
        rating = int("rating"),
    )
}
