package com.paperback.app.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication
import org.readium.r2.shared.publication.services.cover
import org.readium.r2.shared.publication.services.positions
import java.io.File
import java.security.MessageDigest
import java.util.UUID

sealed interface ImportOutcome {
    data class Added(val title: String) : ImportOutcome
    data class Duplicate(val name: String) : ImportOutcome
    data class Unsupported(val name: String) : ImportOutcome
    data class Failed(val name: String) : ImportOutcome
}

class Repository(
    private val context: Context,
    private val db: PaperbackDb,
    private val readium: Readium,
) {
    private val _books = MutableStateFlow<List<Book>>(emptyList())
    val books: StateFlow<List<Book>> = _books.asStateFlow()

    private val _sessions = MutableStateFlow<List<ReadingSession>>(emptyList())
    val sessions: StateFlow<List<ReadingSession>> = _sessions.asStateFlow()

    private val booksDir = File(context.filesDir, "books").apply { mkdirs() }
    private val coversDir = File(context.filesDir, "covers").apply { mkdirs() }

    suspend fun refresh() = withContext(Dispatchers.IO) {
        _books.value = db.allBooks()
        _sessions.value = db.allSessions()
    }

    // ---- import ---------------------------------------------------------------------------

    suspend fun importBook(uri: Uri): ImportOutcome = withContext(Dispatchers.IO) {
        val name = displayName(uri) ?: "book.epub"
        val ext = name.substringAfterLast('.', "epub").lowercase().takeIf { it.length in 2..5 } ?: "epub"
        val tmp = File(context.cacheDir, "import-${System.nanoTime()}.$ext")
        val digest = MessageDigest.getInstance("SHA-256")

        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: return@withContext ImportOutcome.Failed(name)
            input.use { src ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = src.read(buf)
                        if (n < 0) break
                        digest.update(buf, 0, n)
                        out.write(buf, 0, n)
                    }
                }
            }
        } catch (e: Exception) {
            tmp.delete()
            return@withContext ImportOutcome.Failed(name)
        }

        val id = digest.digest().joinToString("") { "%02x".format(it) }
        if (db.hasBook(id)) {
            tmp.delete()
            return@withContext ImportOutcome.Duplicate(name)
        }

        val dest = File(booksDir, "$id.$ext")
        if (!tmp.renameTo(dest)) {
            tmp.copyTo(dest, overwrite = true)
            tmp.delete()
        }

        val publication = readium.open(dest)
        if (publication == null) {
            dest.delete()
            return@withContext ImportOutcome.Failed(name)
        }

        try {
            if (!publication.conformsTo(Publication.Profile.EPUB)) {
                dest.delete()
                return@withContext ImportOutcome.Unsupported(name)
            }

            val title = publication.metadata.title?.takeIf { it.isNotBlank() }
                ?: name.substringBeforeLast('.')
            val author = publication.metadata.authors.joinToString(", ") { it.name }
            val language = publication.metadata.languages.firstOrNull() ?: ""
            val total = publication.positions().size

            val coverPath = publication.cover()?.let { bmp ->
                val file = File(coversDir, "$id.jpg")
                val scaled = scaleDown(bmp, 480)
                file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                file.path
            }

            db.insertBook(
                Book(
                    id = id, title = title, author = author, language = language,
                    filePath = dest.path, coverPath = coverPath,
                    addedAt = System.currentTimeMillis(), lastOpenedAt = 0L,
                    progress = 0f, position = 0, totalPositions = total, locatorJson = null,
                    finished = false, favorite = false, rating = 0,
                ),
            )
            refresh()
            ImportOutcome.Added(title)
        } finally {
            publication.close()
        }
    }

    private fun displayName(uri: Uri): String? =
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()

    private fun scaleDown(bmp: Bitmap, maxSide: Int): Bitmap {
        val side = maxOf(bmp.width, bmp.height)
        if (side <= maxSide) return bmp
        val k = maxSide.toFloat() / side
        return Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
    }

    // ---- reading progress -----------------------------------------------------------------

    suspend fun markOpened(id: String) = withContext(Dispatchers.IO) {
        db.touchOpened(id, System.currentTimeMillis())
    }

    suspend fun saveProgress(id: String, locator: Locator) = withContext(Dispatchers.IO) {
        val progress = (locator.locations.totalProgression ?: 0.0).toFloat().coerceIn(0f, 1f)
        val position = locator.locations.position ?: 0
        db.updateProgress(id, locator.toJSON().toString(), progress, position, System.currentTimeMillis())
        if (progress >= 0.99f) db.setFlag(id, "finished", true)
    }

    suspend fun addSession(bookId: String, startMs: Long, seconds: Int, pages: Int) = withContext(Dispatchers.IO) {
        db.insertSession(bookId, startMs, seconds, pages)
    }

    // ---- bookmarks, highlights, notes -----------------------------------------------------

    suspend fun bookmarks(bookId: String): List<Bookmark> = withContext(Dispatchers.IO) { db.bookmarksFor(bookId) }

    suspend fun addBookmark(bookId: String, locator: Locator) = withContext(Dispatchers.IO) {
        db.insertBookmark(
            Bookmark(
                id = UUID.randomUUID().toString(),
                bookId = bookId,
                locatorJson = locator.toJSON().toString(),
                position = locator.locations.position ?: 0,
                progress = (locator.locations.totalProgression ?: 0.0).toFloat(),
                createdAt = System.currentTimeMillis(),
            ),
        )
    }

    suspend fun removeBookmark(id: String) = withContext(Dispatchers.IO) { db.deleteBookmark(id) }

    suspend fun highlights(bookId: String): List<Highlight> = withContext(Dispatchers.IO) { db.highlightsFor(bookId) }

    suspend fun addHighlight(bookId: String, locator: Locator, text: String, note: String, color: Int) =
        withContext(Dispatchers.IO) {
            db.insertHighlight(
                Highlight(
                    id = UUID.randomUUID().toString(),
                    bookId = bookId,
                    locatorJson = locator.toJSON().toString(),
                    text = text,
                    note = note,
                    color = color,
                    progress = (locator.locations.totalProgression ?: 0.0).toFloat(),
                    createdAt = System.currentTimeMillis(),
                ),
            )
        }

    suspend fun updateHighlight(id: String, note: String, color: Int) = withContext(Dispatchers.IO) {
        db.updateHighlight(id, note, color)
    }

    suspend fun removeHighlight(id: String) = withContext(Dispatchers.IO) { db.deleteHighlight(id) }

    // ---- shelf actions --------------------------------------------------------------------

    suspend fun setFavorite(id: String, value: Boolean) = withContext(Dispatchers.IO) {
        db.setFlag(id, "favorite", value)
        refresh()
    }

    suspend fun setFinished(id: String, value: Boolean) = withContext(Dispatchers.IO) {
        db.setFlag(id, "finished", value)
        refresh()
    }

    suspend fun remove(book: Book) = withContext(Dispatchers.IO) {
        db.deleteBook(book.id)
        File(book.filePath).delete()
        book.coverPath?.let { File(it).delete() }
        refresh()
    }
}
