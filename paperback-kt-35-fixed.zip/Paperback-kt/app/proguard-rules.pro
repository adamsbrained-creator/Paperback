# R8 rules. The libraries (Readium, Compose, ML Kit, AndroidX) bring their own rules; these cover the rest.

# Fragments are created by class (Readium's navigator), so their constructors must stay.
-keep class * extends androidx.fragment.app.Fragment { <init>(...); }

# PDFBox for Android reads fonts, encodings and filters by name from its own resources and optional codecs.
-keep class com.tom_roush.pdfbox.** { *; }
-dontwarn com.gemalto.jp2.**
-dontwarn com.tom_roush.pdfbox.**

# Optional pieces that libraries mention but the app doesn't use.
-dontwarn org.bouncycastle.**
-dontwarn javax.annotation.**
-dontwarn org.slf4j.**

# A missing optional class should not stop the build; a real missing one shows up when it is used.
-ignorewarnings
