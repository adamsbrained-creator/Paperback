package com.paperback.app.reflow;

import java.util.ArrayList;
import java.util.List;

/** The words the recogniser put on one line of text, left to right. */
public final class OcrLine {
    public final List<OcrWord> words = new ArrayList<OcrWord>();

    public OcrLine add(OcrWord w) {
        words.add(w);
        return this;
    }
}
