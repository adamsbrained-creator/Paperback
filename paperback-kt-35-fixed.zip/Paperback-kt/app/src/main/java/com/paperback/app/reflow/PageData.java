package com.paperback.app.reflow;

import java.util.ArrayList;
import java.util.List;

/** Everything read from one PDF page: its size, its characters (in any order) and its pictures. */
public final class PageData {
    public final int index;
    public final float width;
    public final float height;
    public final List<Glyph> glyphs = new ArrayList<Glyph>();
    public final List<PlacedImage> images = new ArrayList<PlacedImage>();

    public PageData(int index, float width, float height) {
        this.index = index;
        this.width = width;
        this.height = height;
    }
}
