package com.paperback.app.catalog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * What your library says about your taste, worked out on the phone: how much you like each subject and each
 * author, from what you finished, rated, favorited and started. Nothing here leaves the device; only a few
 * subject and author names are later used as search words.
 */
public final class Taste {
    /** One subject or author with how much you like it, and the book that shows it best. */
    public static final class Signal {
        public final String name;
        public final double weight;
        /** Title of the book of yours that counts most for it. */
        public final String because;
        /** The strongest single book weight behind it. */
        public final double bestBook;
        /** How many of your books show it. */
        public final int count;

        Signal(String name, double weight, String because, double bestBook, int count) {
            this.name = name;
            this.weight = weight;
            this.because = because;
            this.bestBook = bestBook;
            this.count = count;
        }

        /** Weight with a bonus for being a pattern across several books, used to choose what to search for. */
        double strength() {
            return weight * (1.0 + 0.4 * (count - 1));
        }
    }

    private final Map<String, Signal> subjects;
    private final Map<String, Signal> authors;
    private final List<Signal> topSubjects;
    private final List<Signal> topAuthors;
    private final Map<String, Boolean> owned;

    private Taste(Map<String, Signal> subjects, Map<String, Signal> authors, Map<String, Boolean> owned) {
        this.subjects = subjects;
        this.authors = authors;
        this.owned = owned;
        this.topSubjects = sorted(subjects, 2.0);
        this.topAuthors = sorted(authors, 2.0);
    }

    private static List<Signal> sorted(Map<String, Signal> m, double min) {
        List<Signal> out = new ArrayList<Signal>();
        for (Signal s : m.values()) if (s.weight >= min) out.add(s);
        Collections.sort(out, new Comparator<Signal>() {
            @Override public int compare(Signal a, Signal b) {
                int c = Double.compare(b.strength(), a.strength());
                return c != 0 ? c : a.name.compareToIgnoreCase(b.name);
            }
        });
        return out;
    }

    /** How much one book says you like what it is about. Negative when you rated it low. */
    static double bookWeight(TasteBook b) {
        double w = 0.3; // you added it: a little interest
        switch (b.rating) {
            case 5: w += 3.0; break;
            case 4: w += 2.0; break;
            case 3: w += 0.4; break;
            case 2: w -= 1.5; break;
            case 1: w -= 2.5; break;
            default: break;
        }
        if (b.favorite) w += 2.0;
        if (b.finished) w += b.rating == 0 ? 1.5 : 0.5;
        else if (b.progress > 0.1) w += 0.8 * Math.min(1.0, b.progress);
        return w;
    }

    public static Taste of(List<TasteBook> books) {
        Map<String, double[]> sSum = new LinkedHashMap<String, double[]>(); // [weight, bestBook, count]
        Map<String, String> sName = new HashMap<String, String>();
        Map<String, String> sBecause = new HashMap<String, String>();
        Map<String, double[]> aSum = new LinkedHashMap<String, double[]>();
        Map<String, String> aName = new HashMap<String, String>();
        Map<String, String> aBecause = new HashMap<String, String>();
        Map<String, Boolean> owned = new HashMap<String, Boolean>();

        for (TasteBook b : books) {
            owned.put(TitleKey.of(b.title), Boolean.TRUE);
            double w = bookWeight(b);
            List<String> tags = Subjects.clean(b.tags, 16);
            double share = w / Math.max(1.0, Math.sqrt(tags.size())); // a book with many tags does not outweigh one with few
            for (String t : tags) {
                String k = Subjects.key(t);
                double f = Subjects.isGeneric(t) ? 0.35 : 1.0;
                add(sSum, sName, sBecause, k, t, share * f, w, b.title);
            }
            String a = firstAuthor(b.author);
            if (!a.isEmpty()) add(aSum, aName, aBecause, a.toLowerCase(Locale.ROOT), a, w, w, b.title);
        }
        return new Taste(build(sSum, sName, sBecause), build(aSum, aName, aBecause), owned);
    }

    private static void add(Map<String, double[]> sum, Map<String, String> names, Map<String, String> because,
                            String key, String name, double add, double bookW, String title) {
        double[] cur = sum.get(key);
        if (cur == null) {
            sum.put(key, new double[] {add, bookW, 1});
            names.put(key, name);
            because.put(key, title);
        } else {
            cur[0] += add;
            cur[2] += 1;
            if (bookW > cur[1]) {
                cur[1] = bookW;
                because.put(key, title);
            }
        }
    }

    private static Map<String, Signal> build(Map<String, double[]> sum, Map<String, String> names, Map<String, String> because) {
        Map<String, Signal> out = new LinkedHashMap<String, Signal>();
        for (Map.Entry<String, double[]> e : sum.entrySet()) {
            out.put(e.getKey(), new Signal(names.get(e.getKey()), e.getValue()[0], because.get(e.getKey()), e.getValue()[1], (int) e.getValue()[2]));
        }
        return out;
    }

    /** "Tolkien, J. R. R." / "A and B" -> the first author as written. */
    static String firstAuthor(String author) {
        if (author == null) return "";
        String a = author.trim();
        int i = a.indexOf(';');
        if (i > 0) a = a.substring(0, i);
        i = a.indexOf(" & ");
        if (i > 0) a = a.substring(0, i);
        i = a.indexOf(" and ");
        if (i > 0) a = a.substring(0, i);
        return a.trim();
    }

    // ---- reading the result ---------------------------------------------------------------------

    /** True when there is nothing to base a recommendation on. */
    public boolean isEmpty() {
        return subjects.isEmpty() && authors.isEmpty();
    }

    public double subjectWeight(String subject) {
        Signal s = subjects.get(Subjects.key(subject));
        return s == null ? 0.0 : s.weight;
    }

    public Signal subject(String subject) {
        return subjects.get(Subjects.key(subject));
    }

    public Signal author(String author) {
        return authors.get(firstAuthor(author).toLowerCase(Locale.ROOT));
    }

    public boolean owns(String title) {
        return owned.containsKey(TitleKey.of(title));
    }

    /** Subjects you like most, best first (specific ones before broad ones like "Fiction"). */
    public List<Signal> likedSubjects(int n) {
        List<Signal> specific = new ArrayList<Signal>();
        List<Signal> broad = new ArrayList<Signal>();
        for (Signal s : topSubjects) (Subjects.isGeneric(s.name) ? broad : specific).add(s);
        specific.addAll(broad);
        return specific.subList(0, Math.min(n, specific.size()));
    }

    public List<Signal> likedAuthors(int n) {
        return topAuthors.subList(0, Math.min(n, topAuthors.size()));
    }

    /** Authors you rated low or abandoned, so their books are not suggested. */
    public boolean dislikesAuthor(String author) {
        Signal s = author(author);
        return s != null && s.weight < -1.0;
    }

    /**
     * What the recommendation was based on, as one line: it changes only when your taste does, so the
     * suggestions are not fetched again every time you open the page.
     */
    public String signature() {
        StringBuilder sb = new StringBuilder();
        for (Signal s : likedSubjects(4)) sb.append(Subjects.key(s.name)).append('|');
        sb.append('#');
        for (Signal s : likedAuthors(2)) sb.append(s.name.toLowerCase(Locale.ROOT)).append('|');
        return sb.toString();
    }
}
