package com.paperback.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.data.Book
import com.paperback.app.data.BookText
import com.paperback.app.data.Tags
import com.paperback.app.data.BrowserPage
import com.paperback.app.data.BrowserState
import com.paperback.app.data.Catalog
import com.paperback.app.data.DiscoverController
import com.paperback.app.data.DownloadState
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.opds.OpdsAuth
import com.paperback.app.data.opds.OpdsFormats
import com.paperback.app.data.opds.OpdsGroup
import com.paperback.app.data.opds.OpdsLink
import com.paperback.app.data.opds.OpdsNav
import com.paperback.app.data.opds.OpdsPublication
import com.paperback.app.data.opds.OpdsText
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlin.math.roundToInt

/**
 * Discover: pick an online catalog, then browse it like a shop window. Everything that loads or remembers
 * lives in [DiscoverController]; this file only draws what it says.
 */
@Composable
fun DiscoverScreen(
    controller: DiscoverController,
    books: List<Book>,
    headerSize: HeaderSize,
    onOpenBook: (Book) -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val browser by controller.browser.collectAsStateWithLifecycle()
    val b = browser
    if (b == null) {
        CatalogList(controller, headerSize, onMenu, onSearch)
    } else {
        CatalogBrowser(controller, b, books, headerSize, onOpenBook, onMenu, onSearch)
    }
}

// ---- the list of catalogs ---------------------------------------------------------------------

@Composable
private fun CatalogList(controller: DiscoverController, headerSize: HeaderSize, onMenu: () -> Unit, onSearch: () -> Unit) {
    val t = pbTokens()
    val catalogs by controller.catalogs.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Catalog?>(null) }
    var removing by remember { mutableStateOf<Catalog?>(null) }

    PbPage("Discover", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Free books from online libraries. Pick a catalog to browse it.", color = t.sub, fontSize = 14.sp)
            catalogs.forEach { c ->
                CatalogRow(c, onOpen = { controller.openCatalog(c) }, onEdit = { editing = c }, onRemove = { removing = c })
            }
            PbButton("Add a catalog", onClick = { adding = true }, ghost = true)
            PbNote("You can add your own library server (Calibre, Kavita, COPS and similar) by its OPDS address. Downloads are EPUB only for now.")
        }
    }

    if (adding) {
        CatalogDialog(
            initial = null,
            onSave = { name, address, user, pass -> controller.saveCatalog(null, name, address, user, pass) },
            onDismiss = { adding = false },
        )
    }
    editing?.let { c ->
        CatalogDialog(
            initial = c,
            onSave = { name, address, user, pass -> controller.saveCatalog(c.id, name, address, user, pass) },
            onDismiss = { editing = null },
        )
    }
    removing?.let { c ->
        PbConfirmDialog(
            title = "Remove “${c.name}”?",
            message = "It is taken off this list. Books you already downloaded stay in your library.",
            confirm = "Remove",
            onConfirm = {
                controller.removeCatalog(c.id)
                removing = null
            },
            onDismiss = { removing = null },
        )
    }
}

@Composable
private fun CatalogRow(c: Catalog, onOpen: () -> Unit, onEdit: () -> Unit, onRemove: () -> Unit) {
    val t = pbTokens()
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .clickable(onClick = onOpen)
            .padding(start = 20.dp, top = 6.dp, bottom = 6.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
            Text(c.name, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (c.auth != null) "${c.note} · login saved" else c.note,
                color = t.sub,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (c.builtIn) {
            Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.ink)
            }
        } else {
            Box {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).clickable { menu = true },
                    contentAlignment = Alignment.Center,
                ) {
                    PbIcon(PbIconName.Dots, size = 22.dp, tint = t.ink, contentDescription = "Catalog options")
                }
                PbMenu(expanded = menu, onDismiss = { menu = false }) {
                    DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
                    DropdownMenuItem(text = { Text("Remove") }, onClick = { menu = false; onRemove() })
                }
            }
        }
    }
}

/** Add or change a catalog. [onSave] returns an error message to show, or null when it worked. */
@Composable
private fun CatalogDialog(initial: Catalog?, onSave: (String, String, String, String) -> String?, onDismiss: () -> Unit) {
    val t = pbTokens()
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var address by remember { mutableStateOf(initial?.url ?: "") }
    var user by remember { mutableStateOf(initial?.username ?: "") }
    var pass by remember { mutableStateOf(initial?.password ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    PbDialog(if (initial == null) "Add a catalog" else "Edit catalog", onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PbField(value = name, onValueChange = { name = it }, placeholder = "Name (optional)")
            PbField(
                value = address,
                onValueChange = {
                    address = it
                    error = null
                },
                placeholder = "OPDS address, like books.local:8083/opds",
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            )
            Text("Only fill these in if the catalog is private:", color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
            PbField(value = user, onValueChange = { user = it }, placeholder = "Username")
            PbField(
                value = pass,
                onValueChange = { pass = it },
                placeholder = "Password",
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                visualTransformation = PasswordVisualTransformation(),
            )
            val message = error
            if (message != null) {
                Text(message, color = DangerRed, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
            }
        }
        PbDialogButtons(
            confirm = "Save",
            onConfirm = {
                val problem = onSave(name, address, user, pass)
                if (problem == null) {
                    onDismiss()
                } else {
                    error = problem
                }
            },
            onCancel = onDismiss,
        )
    }
}

// ---- inside one catalog -----------------------------------------------------------------------

@Composable
private fun CatalogBrowser(
    controller: DiscoverController,
    b: BrowserState,
    books: List<Book>,
    headerSize: HeaderSize,
    onOpenBook: (Book) -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val download by controller.download.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        PageHeader(
            label = "Discover",
            size = headerSize,
            modifier = Modifier.padding(horizontal = 20.dp).padding(top = 4.dp),
            onMenu = onMenu,
            onSearch = onSearch,
        )
        BrowserToolbar(controller, b)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val page = b.current
            val problem = b.error
            when {
                b.loading -> PbSpinner(Modifier.align(Alignment.Center))
                problem != null -> ErrorView(
                    message = problem,
                    canRetry = b.failedUrl != null,
                    onRetry = { controller.retry() },
                    onBack = { controller.back() },
                    modifier = Modifier.align(Alignment.Center),
                )
                page is BrowserPage.FeedPage -> key(page.uid) { FeedContent(controller, b, page, books) }
                page is BrowserPage.DetailPage -> key(page.uid) {
                    DetailContent(controller, b, page, books, download, onOpenBook)
                }
            }
        }
    }
}

@Composable
private fun BrowserToolbar(controller: DiscoverController, b: BrowserState) {
    val t = pbTokens()
    val focus = LocalFocusManager.current
    var term by remember(b.catalog.id) { mutableStateOf(b.searchTerm) }
    LaunchedEffect(b.searchTerm) { term = b.searchTerm }
    var filters by remember { mutableStateOf(false) }
    val facets = (b.current as? BrowserPage.FeedPage)?.feed?.facets.orEmpty()
    val submit: () -> Unit = {
        focus.clearFocus()
        controller.search(term)
    }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        ToolButton(PbIconName.CaretLeft, "Back") { controller.back() }
        ToolButton(PbIconName.Home, "Catalog home") { controller.goStart() }
        if (b.searchLink != null) {
            Row(
                Modifier
                    .weight(1f)
                    .height(40.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(t.card)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PbIcon(PbIconName.Search, size = 18.dp, tint = t.sub)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (term.isEmpty()) {
                        Text("Search ${b.catalog.name}", color = t.sub, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    BasicTextField(
                        value = term,
                        onValueChange = { term = it },
                        singleLine = true,
                        textStyle = TextStyle(color = t.ink, fontSize = 15.sp),
                        cursorBrush = SolidColor(t.ink),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { submit() }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
        }
        if (facets.isNotEmpty()) {
            Box {
                ToolButton(PbIconName.Settings, "Filters") { filters = true }
                PbMenu(expanded = filters, onDismiss = { filters = false }) {
                    facets.forEach { f ->
                        val heading = f.title
                        if (heading != null) {
                            DropdownMenuItem(
                                text = { Text(heading.uppercase(), color = t.sub, fontSize = 12.sp) },
                                onClick = {},
                                enabled = false,
                            )
                        }
                        f.links.forEach { l ->
                            DropdownMenuItem(
                                text = {
                                    Text((if (l.active) "✓ " else "") + (l.title ?: l.href) + (l.count?.let { " ($it)" } ?: ""))
                                },
                                onClick = {
                                    filters = false
                                    controller.navigate(l.href)
                                },
                            )
                        }
                    }
                }
            }
        }
        ToolButton(PbIconName.Close, "Close catalog") { controller.closeBrowser() }
    }
}

@Composable
private fun ToolButton(icon: PbIconName, description: String, onClick: () -> Unit) {
    val t = pbTokens()
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(t.card).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        PbIcon(icon, size = 20.dp, tint = t.ink, contentDescription = description)
    }
}

/** The loading spinner: a coral arc turning on a grey ring, with a label (as in the old app). */
@Composable
fun PbSpinner(modifier: Modifier = Modifier, label: String = "Loading…") {
    val t = pbTokens()
    val transition = rememberInfiniteTransition(label = "spinner")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 900, easing = LinearEasing)),
        label = "angle",
    )
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(44.dp)) {
            val stroke = 4.dp.toPx()
            val arc = Size(size.width - stroke, size.height - stroke)
            val corner = Offset(stroke / 2f, stroke / 2f)
            drawArc(color = t.rule, startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = corner, size = arc, style = Stroke(stroke))
            drawArc(
                color = Accent.color, startAngle = angle, sweepAngle = 90f, useCenter = false, topLeft = corner, size = arc,
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
        Spacer(Modifier.height(14.dp))
        Text(label, color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ErrorView(message: String, canRetry: Boolean, onRetry: () -> Unit, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val t = pbTokens()
    Column(
        modifier.widthIn(max = 380.dp).padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Couldn't open that", color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(message, color = t.sub, fontSize = 15.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        if (canRetry) {
            PbButton("Try again", onRetry)
            Spacer(Modifier.height(10.dp))
        }
        PbButton("Go back", onBack, ghost = true)
    }
}

// ---- a list page ------------------------------------------------------------------------------

@Composable
private fun FeedContent(controller: DiscoverController, b: BrowserState, page: BrowserPage.FeedPage, books: List<Book>) {
    val t = pbTokens()
    val feed = page.feed
    val auth = b.catalog.auth
    val saved = remember { controller.scrollOf(page.uid) }
    val state = rememberLazyGridState(saved.first, saved.second)
    DisposableEffect(page.uid) {
        onDispose { controller.saveScroll(page.uid, state.firstVisibleItemIndex, state.firstVisibleItemScrollOffset) }
    }
    val full: LazyGridItemSpanScope.() -> GridItemSpan = { GridItemSpan(maxLineSpan) }

    LazyVerticalGrid(
        state = state,
        columns = GridCells.Adaptive(112.dp),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 112.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        val title = feed.title?.takeIf { it.isNotBlank() }
        if (title != null) {
            item(span = full) {
                Column(Modifier.fillMaxWidth().padding(top = 2.dp)) {
                    Text(title, color = t.ink, fontFamily = PbSerif, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                    val sub = feed.subtitle?.let { OpdsText.plain(it) }.orEmpty()
                    if (sub.isNotEmpty()) {
                        Text(sub, color = t.sub, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }

        items(feed.navigation.size, span = { GridItemSpan(maxLineSpan) }) { i ->
            val nav = feed.navigation[i]
            NavCard(nav, Modifier.fillMaxWidth()) { controller.navigate(nav.href) }
        }

        items(feed.groups.size, span = { GridItemSpan(maxLineSpan) }) { i ->
            GroupBlock(feed.groups[i], auth, books, controller)
        }

        items(feed.publications.size) { i ->
            val pub = feed.publications[i]
            PubCard(pub, auth, inLibrary = controller.existingBook(pub, books) != null, onClick = { controller.openPublication(pub) })
        }

        if (feed.isEmpty) {
            item(span = full) {
                Text("Nothing here.", color = t.sub, fontSize = 15.sp, modifier = Modifier.padding(vertical = 24.dp))
            }
        }

        val first = feed.page("first")
        val previous = feed.page("previous") ?: feed.page("prev")
        val next = feed.page("next")
        val last = feed.page("last")
        if (previous != null || next != null) {
            item(span = full) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                ) {
                    if (previous != null && first != null) PagerPill("First") { controller.navigate(first.href) }
                    if (previous != null) PagerPill("Previous") { controller.navigate(previous.href) }
                    if (next != null) PagerPill("Next") { controller.navigate(next.href) }
                    if (next != null && last != null) PagerPill("Last") { controller.navigate(last.href) }
                }
            }
        }
    }
}

@Composable
private fun PagerPill(text: String, onClick: () -> Unit) {
    val t = pbTokens()
    Box(
        Modifier.height(40.dp).clip(RoundedCornerShape(20.dp)).background(t.card).clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun NavCard(nav: OpdsNav, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = pbTokens()
    Row(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(t.card)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(nav.title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val summary = nav.summary?.let { OpdsText.plain(it) }.orEmpty()
            if (summary.isNotEmpty()) {
                Text(summary, color = t.sub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
            }
        }
        val count = nav.count
        if (count != null) {
            Text("$count", color = t.sub, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Spacer(Modifier.width(8.dp))
        PbIcon(PbIconName.CaretRight, size = 16.dp, tint = t.sub)
    }
}

/** One shelf of a front page: a heading, "See all", and a row that scrolls sideways. */
@Composable
private fun GroupBlock(g: OpdsGroup, auth: OpdsAuth?, books: List<Book>, controller: DiscoverController) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                g.title,
                modifier = Modifier.weight(1f),
                color = t.ink,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val more = g.moreHref
            if (more != null) {
                Text(
                    "See all",
                    color = Accent.color,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { controller.navigate(more) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                )
            }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
            items(g.navigation.size) { i ->
                val nav = g.navigation[i]
                NavCard(nav, Modifier.width(220.dp)) { controller.navigate(nav.href) }
            }
            items(g.publications.size) { i ->
                val pub = g.publications[i]
                PubCard(
                    pub, auth,
                    inLibrary = controller.existingBook(pub, books) != null,
                    onClick = { controller.openPublication(pub) },
                    modifier = Modifier.width(112.dp),
                )
            }
        }
    }
}

@Composable
private fun PubCard(pub: OpdsPublication, auth: OpdsAuth?, inLibrary: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val t = pbTokens()
    Column(modifier.clickable(onClick = onClick)) {
        RemoteCover(pub.thumbnailUrl, auth, pub.title, Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text(pub.title, color = t.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (pub.authors.isNotEmpty()) {
            Text(pub.authors.joinToString(", "), color = t.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (inLibrary) {
            Text("In your library", color = Accent.color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ---- a book's page ----------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DetailContent(
    controller: DiscoverController,
    b: BrowserState,
    page: BrowserPage.DetailPage,
    books: List<Book>,
    download: DownloadState?,
    onOpenBook: (Book) -> Unit,
) {
    val t = pbTokens()
    val pub = page.publication
    val auth = b.catalog.auth
    val existing = controller.existingBook(pub, books)
    val epubs = remember(pub) { OpdsFormats.epubLinks(pub) }
    val key = controller.downloadKey(pub)
    val mine = download != null && download.key == key
    val busy = download != null
    val description = remember(pub.summary) { BookText.description(pub.summary) }
    val subjects = remember(pub.subjects) { Tags.clean(pub.subjects) }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 112.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            RemoteCover(pub.coverUrl, auth, pub.title, Modifier.width(170.dp))
            Spacer(Modifier.height(18.dp))
            Text(
                pub.title,
                color = t.ink,
                fontFamily = PbSerif,
                fontSize = 26.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
            )
            val subtitle = pub.subtitle
            if (!subtitle.isNullOrBlank()) {
                Text(subtitle, color = t.sub, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
            }
            if (pub.authors.isNotEmpty()) {
                Text(
                    pub.authors.joinToString(", "),
                    color = t.sub,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            Spacer(Modifier.height(20.dp))

            if (existing != null) {
                PbButton("Open & Read", onClick = { onOpenBook(existing) })
                if (epubs.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    DownloadButton("Download again", epubs, ghost = true, enabled = !busy) { controller.download(pub, it) }
                }
            } else if (epubs.isNotEmpty()) {
                DownloadButton("Download EPUB", epubs, ghost = false, enabled = !busy) { controller.download(pub, it) }
            }

            if (mine && download != null) {
                Spacer(Modifier.height(14.dp))
                val p = download.progress
                if (download.adding) {
                    Text("Adding to your library…", color = t.sub, fontSize = 13.sp)
                } else if (p != null) {
                    ProgressTrack(p)
                    Text("Downloading… ${(p * 100).roundToInt()}%", color = t.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                } else {
                    Text("Downloading…", color = t.sub, fontSize = 13.sp)
                }
            }

            if (epubs.isEmpty() && !page.loadingMore) {
                if (OpdsFormats.onlyOtherFormats(pub)) {
                    val others = OpdsFormats.otherFormatNames(pub).joinToString(", ").ifEmpty { "another format" }
                    PbNote("Paperback can only open EPUB books for now. This one is offered as $others.")
                } else {
                    PbNote("This catalog doesn't list a free download for this book.")
                }
            }
            if (page.loadingMore) {
                Text("Loading details…", color = t.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
            } else if (page.detailFailed) {
                PbNote("The full details couldn't be loaded, so this shows what the list had.")
            }

            if (description.isNotEmpty()) {
                Column(Modifier.fillMaxWidth()) {
                    SectionLabel("About this book")
                    Text(description, color = t.ink, fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.padding(horizontal = 4.dp))
                }
            }

            val rows = listOf(
                "Publisher" to pub.publisher,
                "Published" to pub.published?.let { shortDate(it) },
                "Language" to pub.languages.joinToString(", ").ifEmpty { null },
                "Identifier" to pub.identifier,
            ).filter { !it.second.isNullOrBlank() }
            if (rows.isNotEmpty()) {
                Column(Modifier.fillMaxWidth()) {
                    SectionLabel("Details")
                    PbCard {
                        rows.forEachIndexed { i, row ->
                            if (i > 0) CardDivider()
                            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 13.dp)) {
                                Text(row.first, color = t.setSub, fontSize = 15.sp, modifier = Modifier.width(96.dp))
                                Text(
                                    row.second.orEmpty(),
                                    color = t.ink,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }
                }
            }

            if (subjects.isNotEmpty()) {
                Column(Modifier.fillMaxWidth()) {
                    SectionLabel("Genres")
                    FlowRow(
                        modifier = Modifier.padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        subjects.forEach { s -> TagChip(s) }
                    }
                }
            }
        }
    }
}

private fun shortDate(raw: String): String =
    if (Regex("^\\d{4}-\\d{2}-\\d{2}.*").matches(raw)) raw.take(10) else raw

/** The big download button; when the book has several EPUBs, a little arrow opens the list to choose one. */
@Composable
private fun DownloadButton(label: String, links: List<OpdsLink>, ghost: Boolean, enabled: Boolean, onPick: (OpdsLink) -> Unit) {
    val t = pbTokens()
    var menu by remember { mutableStateOf(false) }
    val fg = if (ghost) t.ink else t.bg
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(26.dp))
            .background(if (ghost) t.card else t.ink),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.weight(1f).fillMaxHeight().clickable(enabled = enabled) { onPick(links.first()) },
            contentAlignment = Alignment.Center,
        ) {
            Text(label, color = fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
        if (links.size > 1) {
            Box(Modifier.width(1.dp).height(24.dp).background(fg.copy(alpha = 0.25f)))
            Box {
                Box(
                    Modifier.width(52.dp).fillMaxHeight().clickable(enabled = enabled) { menu = true },
                    contentAlignment = Alignment.Center,
                ) {
                    PbIcon(
                        PbIconName.CaretRight,
                        modifier = Modifier.rotate(90f),
                        size = 18.dp,
                        tint = fg,
                        contentDescription = "Choose a format",
                    )
                }
                PbMenu(expanded = menu, onDismiss = { menu = false }) {
                    links.forEach { l ->
                        DropdownMenuItem(text = { Text(OpdsFormats.label(l)) }, onClick = { menu = false; onPick(l) })
                    }
                }
            }
        }
    }
}

// ---- empty library ----------------------------------------------------------------------------

/** Shown on Home and Library when there are no books yet: import from the phone, or go and find some. */
@Composable
fun LibraryEmpty(onImport: () -> Unit, onDiscover: () -> Unit, modifier: Modifier = Modifier) {
    val t = pbTokens()
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Your library is empty", color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Add EPUB or PDF books from your phone, or find free ones online.",
            color = t.sub,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        PbButton("Import books", onImport)
        PbButton("Discover free books", onDiscover, ghost = true)
    }
}
