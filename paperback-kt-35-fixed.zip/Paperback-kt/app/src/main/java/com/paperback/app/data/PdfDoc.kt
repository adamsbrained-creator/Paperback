package com.paperback.app.data

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

/**
 * What a quick look at a page found: whether it is [text] on white paper, and for a picture page the part of the
 * page that actually has something on it, as fractions of the page (0..1) from the left / top / right / bottom.
 */
class PageLook(val text: Boolean, val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val cropped: Boolean get() = left > 0f || top > 0f || right < 1f || bottom < 1f

    companion object {
        val Whole = PageLook(true, 0f, 0f, 1f, 1f)
    }
}

/**
 * A PDF opened with Android's own [PdfRenderer] (no extra library). The renderer can only have one page open at a
 * time, so every call takes [lock]. Pages are drawn to bitmaps; there is no text, search or outline from this API.
 */
class PdfDoc private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
) {
    val pageCount: Int = renderer.pageCount

    private val lock = Mutex()
    private val sizes = HashMap<Int, Pair<Int, Int>>()

    /** Set once the file is closed. Anything that still asks for a page after that gets a blank answer, not a crash. */
    @Volatile
    private var closed = false

    /** The page's size in points (width, height). Only the proportions matter. */
    suspend fun pageSize(index: Int): Pair<Int, Int> = withContext(Dispatchers.IO) {
        lock.withLock {
            sizes[index] ?: run {
                if (closed) return@withLock 1 to 1
                val page = renderer.openPage(index)
                val size = try {
                    page.width.coerceAtLeast(1) to page.height.coerceAtLeast(1)
                } finally {
                    page.close()
                }
                sizes[index] = size
                size
            }
        }
    }

    /** Draws page [index] (0-based) into a new bitmap of exactly [width] x [height] pixels, on white. */
    suspend fun render(index: Int, width: Int, height: Int): Bitmap = withContext(Dispatchers.IO) {
        lock.withLock {
            if (closed) return@withLock Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            val bmp = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            val page = renderer.openPage(index)
            try {
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            } finally {
                page.close()
            }
            bmp
        }
    }

    /**
     * Closes the file once any page being drawn right now is finished. Closing in the middle of a draw either leaked
     * the renderer or made the draw fail, which is what used to happen when you left the viewer while a page was loading.
     */
    fun close() {
        closer.launch {
            lock.withLock {
                if (!closed) {
                    closed = true
                    runCatching { renderer.close() }
                    runCatching { pfd.close() }
                }
            }
        }
    }

    companion object {
        private val closer = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        /** Opens [file], or returns null if it isn't a readable PDF (damaged, empty, or password-protected). */
        fun open(file: File): PdfDoc? {
            var pfd: ParcelFileDescriptor? = null
            return try {
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                if (renderer.pageCount <= 0) {
                    renderer.close()
                    pfd.close()
                    null
                } else {
                    PdfDoc(pfd, renderer)
                }
            } catch (e: Exception) {
                runCatching { pfd?.close() }
                null
            }
        }

        /**
         * Guesses whether a rendered page is "text on white paper" (true) or a picture (false), by sampling pixels:
         * mostly white and almost no colour means text. Dark and sepia page colours are only applied to such pages,
         * so illustrations and photos look the same in every theme instead of turning into negatives.
         */
        fun looksLikeText(bmp: Bitmap): Boolean {
            val w = bmp.width
            val h = bmp.height
            if (w < 2 || h < 2) return true
            val stepX = (w / 60).coerceAtLeast(1)
            val stepY = (h / 80).coerceAtLeast(1)
            var total = 0
            var paper = 0
            var colored = 0
            var y = 0
            while (y < h) {
                var x = 0
                while (x < w) {
                    val p = bmp.getPixel(x, y)
                    val r = Color.red(p)
                    val g = Color.green(p)
                    val b = Color.blue(p)
                    val hi = maxOf(r, g, b)
                    val lo = minOf(r, g, b)
                    if (lo >= 225) paper++
                    if (hi - lo > 40) colored++
                    total++
                    x += stepX
                }
                y += stepY
            }
            if (total == 0) return true
            return paper.toFloat() / total >= 0.5f && colored.toFloat() / total <= 0.05f
        }

        /**
         * Looks at a small render of a page. A text page is left whole. On a picture page the white margins around
         * the picture are found so the viewer can show just the picture (otherwise a white sheet floats on the Dark
         * or Sepia background). Nothing is cut when the page is mostly empty or already full.
         */
        fun analyze(bmp: Bitmap): PageLook {
            if (looksLikeText(bmp)) return PageLook.Whole
            val w = bmp.width
            val h = bmp.height
            if (w < 8 || h < 8) return PageLook(false, 0f, 0f, 1f, 1f)
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            val rows = IntArray(h)
            val cols = IntArray(w)
            for (y in 0 until h) {
                for (x in 0 until w) {
                    val p = px[y * w + x]
                    if (minOf(Color.red(p), Color.green(p), Color.blue(p)) < 235) {
                        rows[y]++
                        cols[x]++
                    }
                }
            }
            // A line counts when at least a few pixels on it have something other than paper.
            val need = 3
            val top = rows.indexOfFirst { it >= need }
            val bottom = rows.indexOfLast { it >= need }
            val left = cols.indexOfFirst { it >= need }
            val right = cols.indexOfLast { it >= need }
            if (top < 0 || left < 0 || bottom <= top || right <= left) return PageLook(false, 0f, 0f, 1f, 1f)
            val l = (left - 1).coerceAtLeast(0).toFloat() / w
            val t = (top - 1).coerceAtLeast(0).toFloat() / h
            val r = (right + 2).coerceAtMost(w).toFloat() / w
            val b = (bottom + 2).coerceAtMost(h).toFloat() / h
            // A few stray marks on an empty page: don't zoom in on them.
            if (r - l < 0.35f || b - t < 0.35f) return PageLook(false, 0f, 0f, 1f, 1f)
            // Barely any margin: leave it.
            if (r - l > 0.97f && b - t > 0.97f) return PageLook(false, 0f, 0f, 1f, 1f)
            return PageLook(false, l, t, r, b)
        }

        /** True when the file starts with "%PDF-" (PDF files may begin with a few stray bytes, so look a little in). */
        fun looksLikePdf(file: File): Boolean = runCatching {
            FileInputStream(file).use { input ->
                val head = ByteArray(1024)
                val n = input.read(head)
                n >= 5 && String(head, 0, n, Charsets.ISO_8859_1).contains("%PDF-")
            }
        }.getOrDefault(false)

        /** A readable title from a file name: "my_book-v2.pdf" -> "my book v2". */
        fun titleFromFileName(name: String): String =
            name.substringBeforeLast('.')
                .replace('_', ' ')
                .replace(Regex("\\s+"), " ")
                .trim()
                .ifEmpty { "Untitled" }
    }
}
