package com.paperback.app.catalog;

import java.util.Collections;
import java.util.List;

/** One book (a "work") from the online catalog: what a shelf or search result needs. Immutable. */
public final class CatalogBook {
    /** The catalog's id for the work, e.g. "OL45804W". */
    public final String id;
    public final String title;
    /** Authors joined with ", ", or "". */
    public final String author;
    /** First publication year, 0 = unknown. */
    public final int year;
    /** Open Library cover id, 0 = no cover. */
    public final int coverId;
    /** Average rating 0..5, 0 = none. */
    public final double rating;
    public final int ratingCount;
    public final int editions;
    /** How many Open Library members have marked it read or want to read: a popularity signal. */
    public final int readers;
    public final List<String> subjects;

    public CatalogBook(String id, String title, String author, int year, int coverId, double rating,
                       int ratingCount, int editions, int readers, List<String> subjects) {
        this.id = id;
        this.title = title;
        this.author = author == null ? "" : author;
        this.year = year;
        this.coverId = coverId;
        this.rating = rating;
        this.ratingCount = ratingCount;
        this.editions = editions;
        this.readers = readers;
        this.subjects = subjects == null ? Collections.<String>emptyList() : subjects;
    }

    /** The first author, "" if none. */
    public String firstAuthor() {
        int i = author.indexOf(',');
        return (i < 0 ? author : author.substring(0, i)).trim();
    }
}
