package com.paperback.app.reflow;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/**
 * Turns the characters of a PDF into a book: lines, paragraphs, headings, pictures, chapters.
 *
 * It knows nothing about how the characters were read, so it can be tested on any PDF. Feed it each page with
 * {@link #addPage(PageData)}, then call {@link #build()}.
 *
 * The rules, in short:
 *  - characters on the same baseline form a line; a gap wider than about a fifth of the font size is a space;
 *  - the most common font size is the body text; bigger or bold, isolated lines are headings;
 *  - a line starts a new paragraph when it is indented, when there is extra space above it, or when the line
 *    before it stopped short of the right edge;
 *  - the same short text in the top or bottom margin of several pages is a running header or footer, and a page
 *    number; both are dropped;
 *  - a word split by a hyphen at the end of a line is joined again.
 */
public final class Reflow {

    // ---------------------------------------------------------------------------------------------
    // results

    /** One file of the finished book. */
    public static final class Section {
        public final List<Block> blocks = new ArrayList<Block>();
        public String file;
    }

    /** A line of the table of contents. */
    public static final class NavEntry {
        public int level;
        public String title;
        public Section section;
        public String anchor;
        public final List<NavEntry> children = new ArrayList<NavEntry>();
    }

    public static final class Result {
        public final List<Section> sections = new ArrayList<Section>();
        public final List<NavEntry> nav = new ArrayList<NavEntry>();
        /** "he", "ar", "ja", "ko", "zh", or null when it can't be told from the letters. */
        public String language;
        public int pages;
        public int headings;
        public int paragraphs;
        public int images;
    }

    // ---------------------------------------------------------------------------------------------
    // internal model

    private static final class Line {
        int page;
        float pageW;
        float pageH;
        float x0;
        float x1;
        float y;
        float size;
        boolean bold;
        List<Run> runs = new ArrayList<Run>();
        String text = "";
        boolean removed;
        boolean note;
        // set once the page has been measured
        float margin;
        float right;
        boolean justified;
        float gapBefore = 1e9f;
        float gapAfter = 1e9f;
        // headings: 0 none, 1 by size, 2 by style
        int headingKind;
        int level;
    }

    private static final class PageLines {
        int index;
        float w;
        float h;
        List<Line> lines = new ArrayList<Line>();
        List<PlacedImage> images = new ArrayList<PlacedImage>();
        float margin = Float.NaN;
        float right = Float.NaN;
        boolean justified;
        boolean measured;
    }

    private static final class Para {
        List<Run> runs = new ArrayList<Run>();
        boolean bullet;
        Line last;
        List<Float> x1s = new ArrayList<Float>();
        float maxX1 = -1e9f;
    }

    private final List<PageLines> pages = new ArrayList<PageLines>();
    private long textChars;

    // global measures
    private float body = 10f;
    private float leading = 12f;
    private float gMargin = 0f;
    private boolean gJustified;

    // ---------------------------------------------------------------------------------------------
    // step 1: characters -> lines

    public void addPage(PageData p) {
        PageLines pl = new PageLines();
        pl.index = pages.size();
        pl.w = p.width;
        pl.h = p.height;
        pl.lines = buildLines(p, pl.index);
        pl.images = new ArrayList<PlacedImage>(p.images);
        for (Line l : pl.lines) textChars += l.text.length();
        pages.add(pl);
    }

    public int pageCount() {
        return pages.size();
    }

    public long textLength() {
        return textChars;
    }

    private static final Comparator<Glyph> BY_Y = new Comparator<Glyph>() {
        @Override
        public int compare(Glyph a, Glyph b) {
            int c = Float.compare(a.y, b.y);
            return c != 0 ? c : Float.compare(a.x, b.x);
        }
    };
    private static final Comparator<Glyph> BY_X = new Comparator<Glyph>() {
        @Override
        public int compare(Glyph a, Glyph b) {
            return Float.compare(a.x, b.x);
        }
    };
    private static final Comparator<Line> LINE_BY_Y = new Comparator<Line>() {
        @Override
        public int compare(Line a, Line b) {
            int c = Float.compare(a.y, b.y);
            return c != 0 ? c : Float.compare(a.x0, b.x0);
        }
    };

    private List<Line> buildLines(PageData p, int pageIndex) {
        List<Glyph> gs = new ArrayList<Glyph>(p.glyphs.size());
        for (Glyph g : p.glyphs) {
            if (g == null || g.text == null || g.text.length() == 0) continue;
            if (!(g.size > 0.5f) || Float.isNaN(g.x) || Float.isNaN(g.y) || Float.isNaN(g.w)) continue;
            gs.add(g);
        }
        List<Line> out = new ArrayList<Line>();
        if (gs.isEmpty()) return out;

        float med = medianSize(gs);
        List<List<Glyph>> caps = takeDropCaps(gs, med);
        Collections.sort(gs, BY_Y);
        float split = 0.45f * med;
        List<Glyph> cur = new ArrayList<Glyph>();
        float lastY = gs.get(0).y;
        for (Glyph g : gs) {
            if (!cur.isEmpty() && g.y - lastY > split) {
                emitCluster(cur, p, pageIndex, med, out);
                cur = new ArrayList<Glyph>();
            }
            cur.add(g);
            lastY = g.y;
        }
        if (!cur.isEmpty()) emitCluster(cur, p, pageIndex, med, out);
        Collections.sort(out, LINE_BY_Y);
        for (List<Glyph> cap : caps) {
            if (!attachDropCap(cap, out, med)) {
                Collections.sort(cap, BY_X);
                addLine(cap, p, pageIndex, med, out);   // a lone big letter that is not a drop cap
            }
        }
        if (!caps.isEmpty()) Collections.sort(out, LINE_BY_Y);
        return out;
    }

    /**
     * Pulls out a big first letter (one or two characters much bigger than the text). Its baseline is level with
     * one of the lines beside it, so left in place it would be glued into the middle of that line.
     */
    private static List<List<Glyph>> takeDropCaps(List<Glyph> gs, float med) {
        List<List<Glyph>> groups = new ArrayList<List<Glyph>>();
        List<Glyph> big = new ArrayList<Glyph>();
        for (Glyph g : gs) if (!isBlank(g.text) && g.size >= 1.7f * med) big.add(g);
        if (big.isEmpty() || big.size() > 6) return groups;
        Collections.sort(big, BY_Y);
        List<Glyph> cur = new ArrayList<Glyph>();
        for (Glyph g : big) {
            if (!cur.isEmpty() && g.y - cur.get(cur.size() - 1).y > 0.45f * g.size) {
                groups.add(cur);
                cur = new ArrayList<Glyph>();
            }
            cur.add(g);
        }
        groups.add(cur);
        List<List<Glyph>> keep = new ArrayList<List<Glyph>>();
        for (List<Glyph> grp : groups) {
            if (grp.size() <= 2) {
                keep.add(grp);
                gs.removeAll(grp);
            }
        }
        return keep;
    }

    private boolean attachDropCap(List<Glyph> grp, List<Line> lines, float med) {
        Collections.sort(grp, BY_X);
        StringBuilder t = new StringBuilder();
        float x0 = Float.MAX_VALUE;
        float x1 = -Float.MAX_VALUE;
        float size = 0;
        for (Glyph g : grp) {
            t.append(clean(g.text));
            x0 = Math.min(x0, g.x);
            x1 = Math.max(x1, g.x + g.w);
            size = Math.max(size, g.size);
        }
        String cap = t.toString().trim();
        if (cap.length() == 0) return true;
        char c0 = cap.charAt(0);
        if (!Character.isLetter(c0) && c0 != '\u201C' && c0 != '"') return false;
        float y = grp.get(0).y;
        Line host = null;
        for (Line l : lines) {
            if (l.y < y - 0.85f * size || l.y > y + 0.2f * med) continue;
            if (l.x0 < x1 - 0.3f * med || l.x0 - x1 > 0.8f * size) continue;
            if (host == null || l.y < host.y) host = l;
        }
        if (host == null) return false;
        // the lines wrapped around the letter share its indent
        for (Line l : lines) {
            if (l.y >= host.y - 0.1f && l.y <= y + 0.2f * med && l.x0 >= x1 - 0.3f * med && l.x0 - x1 <= 0.8f * size) l.x0 = x0;
        }
        Run first = host.runs.get(0);
        if (!first.bold && !first.italic) first.text = cap + first.text;
        else host.runs.add(0, new Run(cap, false, false));
        host.text = cap + host.text;
        host.x0 = x0;
        return true;
    }

    private void emitCluster(List<Glyph> cluster, PageData p, int pageIndex, float med, List<Line> out) {
        Collections.sort(cluster, BY_X);
        float yy = medianY(cluster);
        boolean band = yy < 0.11f * p.height || yy > 0.89f * p.height;
        if (!band) {
            addLine(cluster, p, pageIndex, med, out);
            return;
        }
        // In the top and bottom margins a wide gap separates a header's left, middle and right parts.
        List<Glyph> seg = new ArrayList<Glyph>();
        Glyph prev = null;
        for (Glyph g : cluster) {
            if (prev != null && !isBlank(g.text) && g.x - (prev.x + prev.w) > 5f * med && !seg.isEmpty()) {
                addLine(seg, p, pageIndex, med, out);
                seg = new ArrayList<Glyph>();
            }
            seg.add(g);
            if (!isBlank(g.text)) prev = g;
        }
        if (!seg.isEmpty()) addLine(seg, p, pageIndex, med, out);
    }

    private void addLine(List<Glyph> seg, PageData p, int pageIndex, float med, List<Line> out) {
        Line l = makeLine(seg, p, pageIndex);
        if (l != null) out.add(l);
    }

    private Line makeLine(List<Glyph> seg, PageData p, int pageIndex) {
        // Letter-spaced text ("C H A P T E R") has gaps between every letter; find out first.
        List<Float> gaps = new ArrayList<Float>();
        Glyph pv = null;
        float sizeSum = 0;
        int single = 0;
        int solid = 0;
        for (Glyph g : seg) {
            if (isBlank(g.text)) continue;
            if (pv != null) gaps.add(g.x - (pv.x + pv.w));
            pv = g;
            sizeSum += g.size;
            solid++;
            if (clean(g.text).length() == 1) single++;
        }
        if (pv == null) return null;
        float avgSize = sizeSum / Math.max(1, seg.size());
        boolean letterSpaced = false;
        float lsThreshold = 0;
        // (recognised text comes a word at a time, and the gaps between words are not letter spacing)
        if (gaps.size() >= 7 && single >= 0.8f * solid) {
            Collections.sort(gaps);
            float median = gaps.get(gaps.size() / 2);
            int big = 0;
            for (float gp : gaps) if (gp > 0.18f * avgSize) big++;
            if (median > 0.12f * avgSize && big >= 0.75f * gaps.size()) {
                letterSpaced = true;
                lsThreshold = median * 1.7f;
            }
        }

        // dominant size and baseline first, so raised small characters can be told from the rest
        Map<Integer, Integer> sizeVotes = new HashMap<Integer, Integer>();
        for (Glyph g : seg) {
            if (isBlank(g.text)) continue;
            int key = Math.round(g.size * 4f);
            Integer v = sizeVotes.get(key);
            sizeVotes.put(key, (v == null ? 0 : v) + clean(g.text).length());
        }
        int bestKey = 0;
        int bestVotes = -1;
        for (Map.Entry<Integer, Integer> e : sizeVotes.entrySet()) {
            if (e.getValue() > bestVotes || (e.getValue() == bestVotes && e.getKey() > bestKey)) {
                bestVotes = e.getValue();
                bestKey = e.getKey();
            }
        }
        float dom = bestKey / 4f;
        List<Float> baseYs = new ArrayList<Float>();
        for (Glyph g : seg) if (!isBlank(g.text) && g.size >= 0.9f * dom) baseYs.add(g.y);
        Collections.sort(baseYs);
        float baseline = baseYs.isEmpty() ? seg.get(0).y : baseYs.get(baseYs.size() / 2);

        Line l = new Line();
        l.page = pageIndex;
        l.pageW = p.width;
        l.pageH = p.height;
        l.x0 = Float.MAX_VALUE;
        l.x1 = -Float.MAX_VALUE;
        StringBuilder plain = new StringBuilder();
        List<Float> ys = new ArrayList<Float>();
        int nonSpace = 0;
        int boldChars = 0;
        boolean pending = false;
        Glyph prev = null;

        for (Glyph g : seg) {
            String t = clean(g.text);
            if (t.length() == 0) continue;
            if (isBlank(t)) {
                if (!letterSpaced) pending = true;
                continue;
            }
            if (prev != null) {
                if (t.equals(prev.text) && Math.abs(g.x - prev.x) < 0.15f * g.size && Math.abs(g.y - prev.y) < 0.15f * g.size) {
                    continue; // the same character drawn twice (fake bold)
                }
                float gap = g.x - (prev.x + prev.w);
                float th = letterSpaced ? lsThreshold : 0.18f * g.size;
                if (gap > th) pending = true;
            }
            boolean sup = g.size <= 0.78f * dom && baseline - g.y >= 0.2f * g.size;
            addText(l.runs, plain, t, g.bold, g.italic, sup, pending && plain.length() > 0);
            pending = false;
            prev = g;
            if (g.x < l.x0) l.x0 = g.x;
            if (g.x + g.w > l.x1) l.x1 = g.x + g.w;
            if (!sup) ys.add(g.y);
            nonSpace += t.length();
            if (g.bold) boldChars += t.length();
        }
        if (nonSpace == 0) return null;
        if (ys.isEmpty()) ys.add(baseline);

        Collections.sort(ys);
        l.y = ys.get(ys.size() / 2);
        l.size = dom;
        l.bold = boldChars * 100 >= 90 * nonSpace;
        l.text = plain.toString().trim();
        if (l.text.length() == 0) return null;
        trimRuns(l.runs);
        return l;
    }

    /** Adds text to the runs of a line. A space between two styles goes on the plain side. */
    private static void addText(List<Run> runs, StringBuilder plain, String t, boolean bold, boolean italic, boolean sup, boolean space) {
        if (runs.isEmpty()) {
            runs.add(new Run(t, bold, italic, sup));
            plain.append(t);
            return;
        }
        Run last = runs.get(runs.size() - 1);
        boolean same = last.bold == bold && last.italic == italic && last.sup == sup;
        if (same) {
            last.text = last.text + (space ? " " : "") + t;
        } else if (space && (bold || italic) && !sup && !(last.bold || last.italic || last.sup)) {
            last.text = last.text + " ";
            runs.add(new Run(t, bold, italic, sup));
        } else if (space && !last.sup && !sup && !(bold || italic) && (last.bold || last.italic)) {
            runs.add(new Run(" " + t, bold, italic, sup));
        } else {
            if (space) last.text = last.text + (last.sup ? "" : " ");
            runs.add(new Run(t, bold, italic, sup));
        }
        if (space) plain.append(' ');
        plain.append(t);
    }

    private static void trimRuns(List<Run> runs) {
        while (!runs.isEmpty() && runs.get(0).text.trim().length() == 0) runs.remove(0);
        while (!runs.isEmpty() && runs.get(runs.size() - 1).text.trim().length() == 0) runs.remove(runs.size() - 1);
        if (!runs.isEmpty()) {
            Run f = runs.get(0);
            f.text = ltrim(f.text);
            Run e = runs.get(runs.size() - 1);
            e.text = rtrim(e.text);
        }
    }

    private static String ltrim(String s) {
        int i = 0;
        while (i < s.length() && s.charAt(i) == ' ') i++;
        return s.substring(i);
    }

    private static String rtrim(String s) {
        int i = s.length();
        while (i > 0 && s.charAt(i - 1) == ' ') i--;
        return s.substring(0, i);
    }

    private static float medianSize(List<Glyph> gs) {
        List<Float> sizes = new ArrayList<Float>(gs.size());
        for (Glyph g : gs) if (!isBlank(g.text)) sizes.add(g.size);
        if (sizes.isEmpty()) return 10f;
        Collections.sort(sizes);
        return sizes.get(sizes.size() / 2);
    }

    private static float medianY(List<Glyph> gs) {
        List<Float> ys = new ArrayList<Float>(gs.size());
        for (Glyph g : gs) ys.add(g.y);
        Collections.sort(ys);
        return ys.get(ys.size() / 2);
    }

    private static boolean isBlank(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!(c == ' ' || c == ' ' || c == '\t' || c == ' ' || c == ' ' || c == ' ' || c == ' '
                    || c == ' ' || c == ' ' || c == '　')) return false;
        }
        return true;
    }

    /** Ligatures to letters, odd spaces to a plain space, invisible characters dropped. */
    static String clean(String s) {
        StringBuilder b = null;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            String rep = null;
            switch (c) {
                case 'ﬀ': rep = "ff"; break;
                case 'ﬁ': rep = "fi"; break;
                case 'ﬂ': rep = "fl"; break;
                case 'ﬃ': rep = "ffi"; break;
                case 'ﬄ': rep = "ffl"; break;
                case 'ﬅ':
                case 'ﬆ': rep = "st"; break;
                case ' ':
                case ' ':
                case ' ':
                case ' ':
                case ' ':
                case ' ':
                case ' ':
                case '　': rep = " "; break;
                case '​':
                case '‌':
                case '‍':
                case '﻿':
                case '⁠':
                case '￿':
                case '￾': rep = ""; break;
                default:
                    if (c < 0x20) rep = (c == '\t' || c == '\n' || c == '\r') ? " " : "";
            }
            if (rep != null && b == null) {
                b = new StringBuilder(s.length() + 4);
                b.append(s, 0, i);
            }
            if (b != null) {
                if (rep != null) b.append(rep);
                else b.append(c);
            }
        }
        return b == null ? s : b.toString();
    }

    // ---------------------------------------------------------------------------------------------
    // step 2: measure the book

    public Result build() throws ReflowException {
        if (pages.isEmpty()) throw new ReflowException("This PDF has no pages.");
        if (textChars < Math.max(60, pages.size() * 25L)) {
            throw new NoTextException();
        }

        measureBodySize();
        measureLeading();
        removeHeadersAndFooters();
        removeSlotLines();
        measurePages();
        markNotes();
        findHeadings();
        return assemble();
    }

    private void measureBodySize() {
        Map<Integer, Long> votes = new HashMap<Integer, Long>();
        for (PageLines pl : pages) {
            for (Line l : pl.lines) {
                int key = Math.round(l.size * 2f);
                Long v = votes.get(key);
                votes.put(key, (v == null ? 0 : v) + l.text.length());
            }
        }
        long best = -1;
        int bestKey = 20;
        for (Map.Entry<Integer, Long> e : votes.entrySet()) {
            if (e.getValue() > best || (e.getValue() == best && e.getKey() < bestKey)) {
                best = e.getValue();
                bestKey = e.getKey();
            }
        }
        body = bestKey / 2f;
        if (body < 4f) body = 4f;
    }

    /** The usual distance between two lines of body text: the smallest spacing that happens a lot. */
    private void measureLeading() {
        Map<Integer, Integer> leadVotes = new HashMap<Integer, Integer>();
        for (PageLines pl : pages) {
            for (int i = 1; i < pl.lines.size(); i++) {
                Line a = pl.lines.get(i - 1);
                Line b = pl.lines.get(i);
                if (a.removed || b.removed) continue;
                float dy = b.y - a.y;
                if (isBodyLine(a) && isBodyLine(b) && dy >= 0.9f * body && dy <= 2.2f * body) {
                    int k = Math.round(dy * 4f);
                    Integer v = leadVotes.get(k);
                    leadVotes.put(k, (v == null ? 0 : v) + 1);
                }
            }
        }
        int maxLead = 0;
        for (int v : leadVotes.values()) maxLead = Math.max(maxLead, v);
        int bk = -1;
        for (Map.Entry<Integer, Integer> e : leadVotes.entrySet()) {
            if (e.getValue() >= 0.4f * maxLead && (bk < 0 || e.getKey() < bk)) bk = e.getKey();
        }
        leading = bk > 0 ? bk / 4f : body * 1.2f;
    }

    private boolean isBodyLine(Line l) {
        return !l.removed && Math.abs(l.size - body) <= 0.12f * body && l.text.length() >= 3;
    }

    // ---- running headers, footers and page numbers

    private static boolean isPageNumber(String t) {
        String s = t.trim();
        if (s.length() == 0 || s.length() > 16) return false;
        String low = s.toLowerCase();
        if (low.matches("(page\\s*|p\\.\\s*)?\\d{1,5}(\\s*(/|of)\\s*\\d{1,5})?")) return true;
        if (low.matches("[-–—−~\\s]*\\d{1,5}[-–—−~\\s]*")) return true;
        if (low.length() <= 7 && low.matches("(?=[ivxlcdm]+$)m{0,3}(cm|cd|d?c{0,3})(xc|xl|l?x{0,3})(ix|iv|v?i{0,3})")) return true;
        return false;
    }

    /**
     * What a running header says, without a page number standing at either end and without spaces or punctuation,
     * so "Being and Time 41" and "Beingand Time 43" (as text recognition reads it) are the same header. Digits inside
     * a word still count, as "#", so labels such as "uni2204" and "uni2205" stay apart from each other.
     */
    private static String headerKey(String t) {
        String[] tokens = t.trim().split("\\s+");
        int from = 0;
        int to = tokens.length;
        if (to - from > 1 && tokens[from].matches("\\d{1,5}")) from++;
        if (to - from > 1 && tokens[to - 1].matches("\\d{1,5}")) to--;
        StringBuilder b = new StringBuilder();
        for (int k = from; k < to; k++) {
            String tok = tokens[k];
            for (int i = 0; i < tok.length(); i++) {
                char c = tok.charAt(i);
                if (Character.isDigit(c)) {
                    if (b.length() == 0 || b.charAt(b.length() - 1) != '#') b.append('#');
                } else {
                    b.append(Character.toLowerCase(c));
                }
            }
        }
        return b.toString();
    }

    private void removeHeadersAndFooters() {
        Map<String, List<Integer>> seen = new HashMap<String, List<Integer>>();
        for (PageLines pl : pages) {
            for (Line l : pl.lines) {
                boolean top = l.y < 0.11f * pl.h;
                boolean bottom = l.y > 0.89f * pl.h;
                if (isPageNumber(l.text) && (l.y < 0.2f * pl.h || l.y > 0.8f * pl.h) && l.size <= body * 1.12f) {
                    l.removed = true;
                    continue;
                }
                if (!top && !bottom) continue;
                if (l.size > body * 1.12f) continue;
                String key = headerKey(l.text);
                if (key.length() < 3) continue;
                List<Integer> where = seen.get(key);
                if (where == null) {
                    where = new ArrayList<Integer>();
                    seen.put(key, where);
                }
                where.add(pl.index);
            }
        }
        if (pages.size() < 3) return;
        Map<String, Boolean> drop = new HashMap<String, Boolean>();
        for (Map.Entry<String, List<Integer>> e : seen.entrySet()) {
            List<Integer> where = e.getValue();
            if (where.size() < 3) continue;
            // a real running header shows on neighbouring pages (every page, or every other page)
            int near = 0;
            for (int i = 0; i < where.size(); i++) {
                int pg = where.get(i);
                boolean has = false;
                for (int j = 0; j < where.size(); j++) {
                    if (i != j && Math.abs(where.get(j) - pg) <= 2) {
                        has = true;
                        break;
                    }
                }
                if (has) near++;
            }
            if (near * 2 >= where.size()) drop.put(e.getKey(), true);
        }
        if (drop.isEmpty()) return;
        for (PageLines pl : pages) {
            for (Line l : pl.lines) {
                boolean top = l.y < 0.11f * pl.h;
                boolean bottom = l.y > 0.89f * pl.h;
                if (!top && !bottom) continue;
                if (l.size > body * 1.12f) continue;
                if (drop.containsKey(headerKey(l.text))) l.removed = true;
            }
        }
    }

    // ---- margins, justified or not, line spacing

    private void measurePages() {
        Map<Integer, Integer> marginVotes = new HashMap<Integer, Integer>();
        int justifiedPages = 0;
        int measuredPages = 0;

        for (PageLines pl : pages) {
            List<Line> bl = new ArrayList<Line>();
            for (Line l : pl.lines) if (isBodyLine(l)) bl.add(l);
            if (bl.size() < 4) continue;
            Map<Integer, Integer> mv = new HashMap<Integer, Integer>();
            for (Line l : bl) {
                int k = Math.round(l.x0 / 2f);
                Integer v = mv.get(k);
                mv.put(k, (v == null ? 0 : v) + 1);
            }
            int bestK = 0;
            int bestV = -1;
            for (Map.Entry<Integer, Integer> e : mv.entrySet()) {
                if (e.getValue() > bestV || (e.getValue() == bestV && e.getKey() < bestK)) {
                    bestV = e.getValue();
                    bestK = e.getKey();
                }
            }
            pl.margin = bestK * 2f;
            List<Float> xs = new ArrayList<Float>();
            for (Line l : bl) xs.add(l.x1);
            Collections.sort(xs);
            pl.right = xs.get((int) Math.min(xs.size() - 1, Math.floor(xs.size() * 0.85)));
            float tw = Math.max(1f, pl.right - pl.margin);
            int flush = 0;
            for (Line l : bl) if (l.x1 >= pl.right - 0.015f * tw) flush++;
            pl.justified = flush >= 0.45f * bl.size();
            pl.measured = true;
            measuredPages++;
            if (pl.justified) justifiedPages++;
            Integer v = marginVotes.get(bestK);
            marginVotes.put(bestK, (v == null ? 0 : v) + 1);
        }

        int bestK = 0;
        int bestV = -1;
        for (Map.Entry<Integer, Integer> e : marginVotes.entrySet()) {
            if (e.getValue() > bestV) {
                bestV = e.getValue();
                bestK = e.getKey();
            }
        }
        gMargin = bestV < 0 ? 0f : bestK * 2f;
        gJustified = measuredPages > 0 && justifiedPages * 2 >= measuredPages;

        float gRight = 0;
        for (PageLines pl : pages) if (pl.measured) gRight = Math.max(gRight, pl.right);
        for (PageLines pl : pages) {
            if (!pl.measured) {
                pl.margin = gMargin;
                pl.right = gRight > 0 ? gRight : pl.w - gMargin;
                pl.justified = gJustified;
            }
            Line prev = null;
            for (Line l : pl.lines) {
                l.margin = pl.margin;
                l.right = pl.right;
                l.justified = pl.justified;
                if (l.removed) continue;
                if (prev != null) {
                    float dy = l.y - prev.y;
                    l.gapBefore = dy;
                    prev.gapAfter = dy;
                }
                prev = l;
            }
        }
    }

    /**
     * A header or footer in a layout with big margins sits far from the page edge, so "the top 11%" misses it.
     * What gives it away: the first line of a page, set apart from the text below by a clear gap, at the same
     * height on many pages (and the same for the last line and the gap above it).
     */
    private void removeSlotLines() {
        if (pages.size() < 4) return;
        List<Line> tops = new ArrayList<Line>();
        List<Line> bottoms = new ArrayList<Line>();
        for (PageLines pl : pages) {
            List<Line> live = new ArrayList<Line>();
            for (Line l : pl.lines) if (!l.removed) live.add(l);
            if (live.size() < 3) continue;
            Line first = live.get(0);
            if (first.size <= 1.12f * body && live.get(1).y - first.y >= 1.6f * leading) tops.add(first);
            Line last = live.get(live.size() - 1);
            if (last.size <= 1.12f * body && last.y - live.get(live.size() - 2).y >= 1.6f * leading) bottoms.add(last);
        }
        List<Float> topSlots = repeatedSlots(tops);
        List<Float> bottomSlots = repeatedSlots(bottoms);
        if (topSlots.isEmpty() && bottomSlots.isEmpty()) return;
        // the same slots on the sparse pages too (the last page of a chapter has little else on it)
        for (PageLines pl : pages) {
            Line first = null;
            Line last = null;
            for (Line l : pl.lines) {
                if (l.removed) continue;
                if (first == null) first = l;
                last = l;
            }
            if (first != null && first.size <= 1.12f * body && inSlot(first.y, topSlots)) first.removed = true;
            if (last != null && last != first && last.size <= 1.12f * body && inSlot(last.y, bottomSlots)) last.removed = true;
        }
    }

    /** How far apart two lines can sit on different pages and still be in the same slot (scans wobble a little). */
    private float slotTolerance() {
        return Math.max(1.5f, 0.35f * body);
    }

    private boolean inSlot(float y, List<Float> slots) {
        for (float s : slots) if (Math.abs(s - y) <= slotTolerance()) return true;
        return false;
    }

    /** Heights at which at least 40% of the pages (and four) have such a line. */
    private List<Float> repeatedSlots(List<Line> candidates) {
        List<Float> out = new ArrayList<Float>();
        int need = Math.max(4, (int) Math.ceil(0.4f * pages.size()));
        for (Line c : candidates) {
            int same = 0;
            for (Line o : candidates) if (Math.abs(o.y - c.y) <= slotTolerance()) same++;
            if (same >= need && !inSlot(c.y, out)) out.add(c.y);
        }
        return out;
    }

    // ---- footnotes: small text near the bottom of a page that has normal text above it

    private void markNotes() {
        for (PageLines pl : pages) {
            int normal = 0;
            for (Line l : pl.lines) if (!l.removed && l.size >= 0.93f * body) normal++;
            if (normal < 3) continue;
            for (Line l : pl.lines) {
                if (!l.removed && l.size <= 0.88f * body && l.y > 0.6f * pl.h && l.text.length() >= 2 && !isCaption(l, pl)) l.note = true;
            }
        }
    }

    /** Small text right under a picture is its caption, not a footnote. */
    private boolean isCaption(Line l, PageLines pl) {
        for (PlacedImage im : pl.images) {
            float bottom = im.y + im.h;
            if (l.y >= bottom - 2f && l.y - bottom <= 2.2f * body + l.size) return true;
        }
        return false;
    }

    // ---- headings

    private static boolean endsWithPeriod(String t) {
        String s = t.trim();
        if (s.length() == 0) return false;
        char c = s.charAt(s.length() - 1);
        return c == '.' || c == ',' || c == ';';
    }

    private void findHeadings() {
        List<Float> sizes = new ArrayList<Float>();
        for (PageLines pl : pages) {
            for (Line l : pl.lines) {
                if (l.removed || l.note) continue;
                int n = l.text.length();
                if (n > 140) continue;
                boolean isolated = l.gapBefore > leading * 1.25f || l.gapAfter > leading * 1.25f;
                if (l.size >= body * 1.15f) {
                    l.headingKind = 1;
                } else if (l.size >= body * 0.95f && isolated && n <= 90 && !endsWithPeriod(l.text)) {
                    if (l.bold) l.headingKind = 2;
                    else if (n <= 60 && isMostlyUpper(l.text)) l.headingKind = 2;
                }
                if (l.headingKind == 1) {
                    float rs = Math.round(l.size * 2f) / 2f;
                    if (!sizes.contains(rs)) sizes.add(rs);
                }
            }
        }
        Collections.sort(sizes, Collections.reverseOrder());
        for (PageLines pl : pages) {
            for (Line l : pl.lines) {
                if (l.headingKind == 1) {
                    float rs = Math.round(l.size * 2f) / 2f;
                    l.level = Math.min(4, sizes.indexOf(rs) + 1);
                } else if (l.headingKind == 2) {
                    l.level = Math.min(4, sizes.size() + 1);
                }
            }
        }
    }

    private static boolean isMostlyUpper(String t) {
        int letters = 0;
        int upper = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (Character.isLetter(c)) {
                letters++;
                if (Character.isUpperCase(c)) upper++;
            }
        }
        return letters >= 4 && upper >= 0.85f * letters;
    }

    // ---------------------------------------------------------------------------------------------
    // step 3: lines -> blocks

    private static final class Item {
        final Line line;
        final PlacedImage image;
        final float key;

        Item(Line line, PlacedImage image, float key) {
            this.line = line;
            this.image = image;
            this.key = key;
        }
    }

    private List<Block> blocks;
    private Para cur;
    private List<Block> pendingNotes;
    private int headingCounter;

    private Result assemble() {
        blocks = new ArrayList<Block>();
        pendingNotes = new ArrayList<Block>();
        cur = null;
        headingCounter = 0;

        Map<String, Integer> imageUse = new HashMap<String, Integer>();
        for (PageLines pl : pages) {
            for (PlacedImage im : pl.images) {
                Integer v = imageUse.get(im.key);
                imageUse.put(im.key, (v == null ? 0 : v) + 1);
            }
        }

        Line prev = null;
        Line headingLine = null;
        Block headingBlock = null;
        int imageCount = 0;

        for (PageLines pl : pages) {
            List<Item> items = new ArrayList<Item>();
            List<Line> notes = new ArrayList<Line>();
            int bodyLines = 0;
            for (Line l : pl.lines) {
                if (l.removed) continue;
                if (l.note) notes.add(l);
                else {
                    items.add(new Item(l, null, l.y));
                    bodyLines++;
                }
            }
            for (PlacedImage im : pl.images) {
                if (!keepImage(im, pl, bodyLines, imageUse.get(im.key))) continue;
                items.add(new Item(null, im, im.y + im.h / 2f));
            }
            Collections.sort(items, new Comparator<Item>() {
                @Override
                public int compare(Item a, Item b) {
                    return Float.compare(a.key, b.key);
                }
            });

            for (Item it : items) {
                if (it.image != null) {
                    flushPara();
                    headingLine = null;
                    Block b = new Block(Block.IMAGE);
                    b.image = it.image;
                    blocks.add(b);
                    imageCount++;
                    prev = null;
                    continue;
                }
                Line l = it.line;

                if (isSceneBreak(l.text)) {
                    flushPara();
                    headingLine = null;
                    if (hasSymbol(l.text)) blocks.add(new Block(Block.RULE));
                    prev = null;
                    continue;
                }

                if (l.headingKind != 0) {
                    flushPara();
                    boolean join = headingLine != null && headingBlock != null && headingLine.page == l.page
                            && headingLine.headingKind == l.headingKind && Math.abs(headingLine.size - l.size) < 0.6f
                            && l.y - headingLine.y < 1.7f * l.size && headingLine.level == l.level;
                    if (join) {
                        joinText(headingBlock.runs, l.runs);
                    } else {
                        Block h = new Block(Block.HEADING);
                        h.level = l.level;
                        h.id = "h" + (++headingCounter);
                        for (Run r : l.runs) h.runs.add(new Run(r.text, false, false));
                        blocks.add(h);
                        headingBlock = h;
                    }
                    headingLine = l;
                    prev = null;
                    continue;
                }
                headingLine = null;

                boolean bullet = isBullet(l.text);
                if (cur == null || startsParagraph(cur, prev, l, bullet)) {
                    flushPara();
                    cur = new Para();
                    cur.bullet = bullet;
                    List<Run> rs = l.runs;
                    if (bullet) rs = stripBullet(rs);
                    for (Run r : rs) cur.runs.add(r.with(r.text));
                } else {
                    joinText(cur.runs, l.runs);
                }
                cur.last = l;
                cur.x1s.add(l.x1);
                if (l.x1 > cur.maxX1) cur.maxX1 = l.x1;
                prev = l;
            }

            // footnotes of this page
            if (!notes.isEmpty()) {
                List<Block> nb = buildNotes(notes);
                if (cur == null) blocks.addAll(nb);
                else pendingNotes.addAll(nb);
            }
        }
        flushPara();
        blocks.addAll(pendingNotes);
        pendingNotes.clear();

        Result r = split(blocks);
        r.pages = pages.size();
        r.images = imageCount;
        int paras = 0;
        int heads = 0;
        for (Block b : blocks) {
            if (b.kind == Block.PARA || b.kind == Block.BULLET) paras++;
            if (b.kind == Block.HEADING) heads++;
        }
        r.paragraphs = paras;
        r.headings = heads;
        r.language = detectLanguage(blocks);
        return r;
    }

    private boolean keepImage(PlacedImage im, PageLines pl, int bodyLines, Integer uses) {
        if (im.w < 28f || im.h < 28f || im.w * im.h < 1200f) return false;
        if (im.pxW > 0 && im.pxH > 0 && (long) im.pxW * im.pxH < 3000L) return false;
        float area = im.w * im.h;
        float pageArea = Math.max(1f, pl.w * pl.h);
        if (uses != null && uses >= 3 && area < 0.25f * pageArea) return false;      // a logo or rule on every page
        if (area >= 0.8f * pageArea && bodyLines >= 4) return false;                   // a page background behind the text
        return true;
    }

    private void flushPara() {
        if (cur != null) {
            Block b = new Block(cur.bullet ? Block.BULLET : Block.PARA);
            b.runs.addAll(cur.runs);
            if (b.plainText().length() > 0) blocks.add(b);
            cur = null;
        }
        if (!pendingNotes.isEmpty()) {
            blocks.addAll(pendingNotes);
            pendingNotes.clear();
        }
    }

    private boolean startsParagraph(Para para, Line prev, Line l, boolean bullet) {
        if (prev == null) return true;
        if (bullet) return true;
        if (isDashStart(l.text)) return true;
        boolean samePage = prev.page == l.page;
        float em = body;
        if (samePage) {
            float dy = l.y - prev.y;
            if (dy > leading * 1.22f) return true;
            if (Math.abs(prev.size - l.size) > 0.12f * body) return true;
        }
        float ind = l.x0 - l.margin;
        float pind = prev.x0 - prev.margin;
        if (ind > 0.7f * em && ind - pind > 0.6f * em) return true;
        if (pind - ind > 0.7f * em && endsSentence(prev.text)) return true;
        float tw = Math.max(1f, prev.right - prev.margin);
        if (prev.text.endsWith("-") || prev.text.endsWith("\u00AD")) return false;
        if (pind > 0.7f * em && ind > 0.7f * em) {
            // inside an indented block (a quotation): its right edge is its own, not the page's
            if (prev.x1 >= para.maxX1 - 0.02f * tw) return false;
            int flush = 0;
            for (float x : para.x1s) if (x >= para.maxX1 - 0.02f * tw) flush++;
            if (flush >= 2) return true;                       // a justified block whose last line ended
            return prev.x1 < para.maxX1 - 0.25f * tw && endsSentence(prev.text);
        }
        if (prev.justified) {
            if (prev.x1 < prev.right - 0.07f * tw) return true;
        } else {
            // Ragged text: a sentence ending well short of the edge. Over a page break there is no spacing to go by,
            // so a smaller shortfall counts.
            if (prev.x1 < prev.right - (samePage ? 0.25f : 0.10f) * tw && endsSentence(prev.text)) return true;
        }
        return false;
    }

    private static boolean endsSentence(String t) {
        int i = t.length() - 1;
        while (i >= 0) {
            char c = t.charAt(i);
            if (c == '"' || c == '\'' || c == '”' || c == '’' || c == '»' || c == ')' || c == ']' || c == ' ') i--;
            else break;
        }
        if (i < 0) return false;
        char c = t.charAt(i);
        return c == '.' || c == '?' || c == '!' || c == '…' || c == '。';
    }

    private static boolean isBullet(String t) {
        if (t.length() < 2) return false;
        char c = t.charAt(0);
        return (c == '•' || c == '◦' || c == '▪' || c == '‣' || c == '●' || c == '■' || c == '□'
                || c == '▫' || c == '·') && t.charAt(1) == ' ';
    }

    private static boolean isDashStart(String t) {
        if (t.length() < 3) return false;
        char c = t.charAt(0);
        return (c == '—' || c == '–' || c == '-') && t.charAt(1) == ' ' && Character.isLetter(t.charAt(2));
    }

    private static List<Run> stripBullet(List<Run> runs) {
        List<Run> out = new ArrayList<Run>();
        boolean first = true;
        for (Run r : runs) {
            String t = r.text;
            if (first) {
                t = ltrim(t.substring(1));
                first = false;
            }
            if (t.length() > 0) out.add(r.with(t));
        }
        return out;
    }

    private static boolean isSceneBreak(String t) {
        String s = t.trim();
        if (s.length() == 0 || s.length() > 15) return false;
        for (int i = 0; i < s.length(); i++) {
            if ("*•·◆◇~⁂✱✻♦◊§#—–-_=. ".indexOf(s.charAt(i)) < 0) return false;
        }
        return true;
    }

    private static boolean hasSymbol(String t) {
        String s = t.trim();
        if (s.length() >= 3) return true;
        for (int i = 0; i < s.length(); i++) {
            if ("*•◆◇~⁂✱✻♦◊§#".indexOf(s.charAt(i)) >= 0) return true;
        }
        return false;
    }

    // ---- joining lines

    private static final String[] COMPOUND_PREFIXES = {
        "self", "non", "ex", "well", "ill", "half", "all", "cross", "quasi", "vice", "ultra", "so", "mid",
    };

    /** Adds the next line to a paragraph: a space between lines, or no space (and no hyphen) inside a split word. */
    private static void joinText(List<Run> into, List<Run> next) {
        if (next.isEmpty()) return;
        if (into.isEmpty()) {
            for (Run r : next) into.add(r.with(r.text));
            return;
        }
        Run last = into.get(into.size() - 1);
        String tail = last.text;
        String head = next.get(0).text;
        String sep = " ";
        if (tail.endsWith("­")) {
            last.text = tail.substring(0, tail.length() - 1);
            sep = "";
        } else if (tail.endsWith("-") || tail.endsWith("‐")) {
            boolean letterBefore = tail.length() >= 2 && Character.isLetter(tail.charAt(tail.length() - 2));
            boolean lowerAfter = head.length() > 0 && Character.isLowerCase(head.charAt(0));
            if (letterBefore && lowerAfter && !endsWithCompoundPrefix(tail.substring(0, tail.length() - 1))) {
                last.text = tail.substring(0, tail.length() - 1);
            }
            sep = "";
        } else if (tail.endsWith(" ") || head.startsWith(" ")) {
            sep = "";
        }
        boolean first = true;
        for (Run r : next) {
            String t = r.text;
            Run l2 = into.get(into.size() - 1);
            if (first && sep.length() > 0) {
                if (l2.sameStyle(r)) {
                    l2.text = l2.text + sep + t;
                } else if ((r.bold || r.italic) && !r.sup && !(l2.bold || l2.italic || l2.sup)) {
                    l2.text = l2.text + sep;      // the space goes on the plain side of a style change
                    into.add(r.with(t));
                } else if (r.sup) {
                    into.add(r.with(t));
                } else {
                    into.add(r.with(sep + t));
                }
            } else {
                if (l2.sameStyle(r)) l2.text = l2.text + t;
                else into.add(r.with(t));
            }
            first = false;
        }
    }

    private static boolean endsWithCompoundPrefix(String s) {
        int i = s.length();
        while (i > 0 && Character.isLetter(s.charAt(i - 1))) i--;
        String word = s.substring(i).toLowerCase();
        for (String p : COMPOUND_PREFIXES) if (word.equals(p)) return true;
        return false;
    }

    // ---- footnotes

    private List<Block> buildNotes(List<Line> notes) {
        List<Block> out = new ArrayList<Block>();
        Block cur = null;
        Line prev = null;
        for (Line l : notes) {
            boolean marker = l.text.matches("^(\\d{1,3}|[*†‡§])(\\s|[.)]).*");
            boolean startNew = cur == null || marker || (prev != null && l.y - prev.y > leading * 1.3f);
            if (startNew) {
                cur = new Block(Block.NOTE);
                for (Run r : l.runs) cur.runs.add(r.with(r.text));
                out.add(cur);
            } else {
                joinText(cur.runs, l.runs);
            }
            prev = l;
        }
        return out;
    }

    // ---------------------------------------------------------------------------------------------
    // step 4: blocks -> chapters and a table of contents

    private static final int MAX_SECTION_CHARS = 120000;

    private Result split(List<Block> all) {
        Result res = new Result();

        // Headings that sit one after another ("Chapter 3", then "A Quiet Argument") are one title.
        List<int[]> groups = new ArrayList<int[]>();      // {first index, last index, level}
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).kind != Block.HEADING) continue;
            int j = i;
            int level = all.get(i).level;
            while (j + 1 < all.size() && all.get(j + 1).kind == Block.HEADING && all.get(j + 1).level <= level + 1) {
                j++;
                level = Math.min(level, all.get(j).level);
            }
            groups.add(new int[] {i, j, level});
            i = j;
        }

        int[] count = new int[6];
        for (int[] g : groups) count[g[2]]++;
        int splitLevel = 0;
        for (int lv = 1; lv <= 3 && splitLevel == 0; lv++) if (count[lv] >= 3) splitLevel = lv;
        for (int lv = 1; lv <= 3 && splitLevel == 0; lv++) if (count[lv] >= 2) splitLevel = lv;

        Map<Integer, int[]> groupAt = new HashMap<Integer, int[]>();
        for (int[] g : groups) groupAt.put(g[0], g);

        List<Section> sections = new ArrayList<Section>();
        Section current = new Section();
        sections.add(current);
        int chars = 0;
        int maxNav = splitLevel == 0 ? 2 : Math.min(4, splitLevel + 1);
        List<NavEntry> stack = new ArrayList<NavEntry>();

        for (int i = 0; i < all.size(); i++) {
            Block b = all.get(i);
            int[] g = groupAt.get(i);
            boolean start = g != null && splitLevel > 0 && g[2] <= splitLevel;
            if (start && !current.blocks.isEmpty()) {
                current = new Section();
                sections.add(current);
                chars = 0;
            } else if (!start && chars > MAX_SECTION_CHARS && (b.kind == Block.PARA || b.kind == Block.HEADING)) {
                current = new Section();
                sections.add(current);
                chars = 0;
            }
            if (g != null && g[2] <= maxNav) {
                StringBuilder title = new StringBuilder();
                for (int k = g[0]; k <= g[1]; k++) {
                    String t = all.get(k).plainText();
                    if (t.length() == 0) continue;
                    if (title.length() > 0) title.append(" \u2014 ");
                    title.append(t);
                }
                NavEntry e = new NavEntry();
                e.level = g[2];
                e.title = title.toString();
                e.section = current;
                e.anchor = b.id;
                while (!stack.isEmpty() && stack.get(stack.size() - 1).level >= e.level) stack.remove(stack.size() - 1);
                if (stack.isEmpty()) res.nav.add(e);
                else stack.get(stack.size() - 1).children.add(e);
                stack.add(e);
            }
            current.blocks.add(b);
            chars += blockLength(b);
        }
        if (sections.size() > 1 && sections.get(0).blocks.isEmpty()) sections.remove(0);
        res.sections.addAll(sections);

        if (res.nav.isEmpty()) {
            // no headings: one entry per file
            int n = 1;
            for (Section s : res.sections) {
                NavEntry e = new NavEntry();
                e.level = 1;
                e.title = res.sections.size() == 1 ? "Text" : "Part " + n;
                e.section = s;
                res.nav.add(e);
                n++;
            }
        } else {
            // text before the first heading gets its own entry at the front
            Section first = res.sections.get(0);
            NavEntry firstEntry = res.nav.get(0);
            if (firstEntry.section != first) {
                NavEntry e = new NavEntry();
                e.level = 1;
                e.title = "Beginning";
                e.section = first;
                res.nav.add(0, e);
            }
        }
        return res;
    }

    private static int blockLength(Block b) {
        int n = 0;
        for (Run r : b.runs) n += r.text.length();
        return b.kind == Block.IMAGE ? n + 400 : n;
    }

    // ---- language

    private static String detectLanguage(List<Block> all) {
        int latin = 0;
        int hebrew = 0;
        int arabic = 0;
        int kana = 0;
        int hangul = 0;
        int han = 0;
        int seen = 0;
        for (Block b : all) {
            if (seen > 20000) break;
            for (Run r : b.runs) {
                for (int i = 0; i < r.text.length(); i++) {
                    char c = r.text.charAt(i);
                    if (!Character.isLetter(c)) continue;
                    seen++;
                    if (c >= 0x0590 && c <= 0x05FF) hebrew++;
                    else if ((c >= 0x0600 && c <= 0x06FF) || (c >= 0x0750 && c <= 0x077F)) arabic++;
                    else if (c >= 0x3040 && c <= 0x30FF) kana++;
                    else if (c >= 0xAC00 && c <= 0xD7AF) hangul++;
                    else if (c >= 0x4E00 && c <= 0x9FFF) han++;
                    else latin++;
                }
            }
        }
        int total = latin + hebrew + arabic + kana + hangul + han;
        if (total == 0) return null;
        if (hebrew * 2 > total) return "he";
        if (arabic * 2 > total) return "ar";
        if (kana * 10 > total) return "ja";
        if (hangul * 2 > total) return "ko";
        if (han * 2 > total) return "zh";
        return null;
    }
}
