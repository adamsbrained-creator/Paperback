package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

/** The pop-up menu in the app's look (same as the Library's long-press menu). */
@Composable
fun PbMenu(expanded: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(22.dp),
        containerColor = pbTokens().menuBg,
        tonalElevation = 0.dp,
        shadowElevation = 12.dp,
        content = content,
    )
}

/** A pill that opens a pop-up menu: coral when [active] (something other than the default is chosen). */
@Composable
fun MenuPill(label: String, active: Boolean = false, modifier: Modifier = Modifier, menu: @Composable (close: () -> Unit) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        TogglePill(label, active) { open = true }
        PbMenu(expanded = open, onDismiss = { open = false }) {
            menu { open = false }
        }
    }
}

/** A small rounded tag (a genre). Tappable when [onClick] is given. */
@Composable
fun TagChip(text: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val t = pbTokens()
    val base = modifier
        .widthIn(max = 300.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(t.card)
    Text(
        text,
        color = t.ink,
        fontSize = 13.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = (if (onClick != null) base.clickable(onClick = onClick) else base).padding(horizontal = 12.dp, vertical = 7.dp),
    )
}

/**
 * A page of names with how many books each has: Genres, Authors. A filter field shows once there are many.
 * Tap a row to see those books.
 */
@Composable
fun NameCountScreen(
    label: String,
    items: List<Pair<String, Int>>,
    emptyText: String,
    filterHint: String,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpen: (String) -> Unit,
) {
    val t = pbTokens()
    var query by rememberSaveable { mutableStateOf("") }
    val shown = remember(items, query) {
        val q = query.trim()
        if (q.isEmpty()) items else items.filter { it.first.contains(q, ignoreCase = true) }
    }

    PbListPage(label, headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(12.dp))
        if (items.isEmpty()) {
            PbNote(emptyText)
        } else {
            if (items.size > 8) {
                PbField(value = query, onValueChange = { query = it }, placeholder = filterHint, leading = PbIconName.Search, onClear = { query = "" })
                Spacer(Modifier.height(12.dp))
            }
            if (shown.isEmpty()) {
                Text("Nothing matches.", color = t.setSub, modifier = Modifier.padding(vertical = 8.dp))
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 112.dp)) {
                    item {
                        PbCard {
                            shown.forEachIndexed { i, (name, count) ->
                                if (i > 0) CardDivider()
                                Row(
                                    Modifier.fillMaxWidth().clickable { onOpen(name) }.padding(horizontal = 18.dp, vertical = 15.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        name,
                                        modifier = Modifier.weight(1f),
                                        color = t.ink,
                                        fontFamily = PbSerif,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text("$count", color = t.setSub, fontSize = 14.sp, modifier = Modifier.padding(start = 12.dp, end = 10.dp))
                                    PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub, strokeWidth = 2f)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
