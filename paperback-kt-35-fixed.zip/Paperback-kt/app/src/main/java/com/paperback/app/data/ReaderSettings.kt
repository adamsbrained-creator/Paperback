package com.paperback.app.data

import android.content.Context
import org.readium.r2.navigator.epub.EpubPreferences
import org.readium.r2.navigator.preferences.FontFamily
import org.readium.r2.navigator.preferences.TextAlign
import org.readium.r2.navigator.preferences.Color as ReadiumColor
import org.readium.r2.navigator.preferences.Theme
import com.paperback.app.reader.ReaderThemes

/**
 * How the page is laid out. While [custom] is off the book keeps its own fonts, spacing and alignment
 * (that is what Readium calls publisher styles); turning it on applies [fontFamily], [lineSpacing], [justify], [paragraphSpacing] and [indent].
 * The Readest look is [ReaderLook.readest]: Readest's own defaults (sans, line height 1.4, left aligned, 0.6 between paragraphs, no indent).
 * [margins] and [brightness] work either way. [brightness] below zero means "follow the phone".
 */
data class ReaderLook(
    val custom: Boolean = false,
    /** 0 = serif, 1 = sans, 2 = mono */
    val fontFamily: Int = 0,
    val lineSpacing: Float = 1.5f,
    val margins: Float = 1.0f,
    val justify: Boolean = true,
    val brightness: Float = -1f,
    /** Space between paragraphs, in lines of text (Readium's rem). Readest uses 0.6. */
    val paragraphSpacing: Float = 0.6f,
    /** First-line indent in em. Readest uses 0. */
    val indent: Float = 0f,
    /** Room above and below the text for the chapter name and the counters: 1 = Readest's, 0 = as little as possible. */
    val verticalSpace: Float = 1.0f,
) {
    companion object {
        /** Readest's defaults on a phone, keeping the phone's brightness choice. */
        fun readest(brightness: Float) = ReaderLook(
            custom = true, fontFamily = 1, lineSpacing = 1.4f, margins = 1.0f, justify = false,
            brightness = brightness, paragraphSpacing = 0.6f, indent = 0f, verticalSpace = 1.0f,
        )
    }
}

/** The reader choices Paperback remembers. */
class ReaderSettings(context: Context) {
    private val sp = context.getSharedPreferences("reader", Context.MODE_PRIVATE)

    var fontSize: Double
        get() = sp.getFloat("fontSize", 1.0f).toDouble()
        set(v) = sp.edit().putFloat("fontSize", v.toFloat()).apply()

    /** The page colour (see [ReaderThemes]); -1, the default, follows the phone: white in the light theme, black in the dark one. */
    var theme: Int
        get() = sp.getInt("theme", ReaderThemes.AUTO).let { if (it in 0..5) it else ReaderThemes.AUTO }
        set(v) = sp.edit().putInt("theme", v).apply()

    /** The reader's bottom controls: 0 = compact card, 1 = quick settings, 2 = icon tiles. */
    var chromeStyle: Int
        get() = sp.getInt("chromeStyle", 0).coerceIn(0, 2)
        set(v) = sp.edit().putInt("chromeStyle", v).apply()

    /** PDF viewer: true turns pages right to left (manga). */
    var pdfRtl: Boolean
        get() = sp.getBoolean("pdfRtl", false)
        set(v) = sp.edit().putBoolean("pdfRtl", v).apply()

    var look: ReaderLook
        get() {
            val d = ReaderLook()
            return ReaderLook(
                custom = sp.getBoolean("custom", d.custom),
                fontFamily = sp.getInt("fontFamily", d.fontFamily).coerceIn(0, 2),
                lineSpacing = sp.getFloat("lineSpacing", d.lineSpacing).coerceIn(1.0f, 2.2f),
                margins = sp.getFloat("margins", d.margins).coerceIn(0.5f, 2.5f),
                justify = sp.getBoolean("justify", d.justify),
                brightness = sp.getFloat("brightness", d.brightness),
                paragraphSpacing = sp.getFloat("paragraphSpacing", d.paragraphSpacing).coerceIn(0f, 2f),
                indent = sp.getFloat("indent", d.indent).coerceIn(0f, 3f),
                verticalSpace = sp.getFloat("verticalSpace", d.verticalSpace).coerceIn(0f, 1.5f),
            )
        }
        set(v) {
            sp.edit()
                .putBoolean("custom", v.custom)
                .putInt("fontFamily", v.fontFamily)
                .putFloat("lineSpacing", v.lineSpacing)
                .putFloat("margins", v.margins)
                .putBoolean("justify", v.justify)
                .putFloat("brightness", v.brightness)
                .putFloat("paragraphSpacing", v.paragraphSpacing)
                .putFloat("indent", v.indent)
                .putFloat("verticalSpace", v.verticalSpace)
                .apply()
        }

    /** [systemDark] is the phone's theme, which decides the page colour while [theme] is Auto. */
    fun toEpubPreferences(systemDark: Boolean = false): EpubPreferences {
        val l = look
        val page = ReaderThemes.resolve(theme, systemDark)
        return EpubPreferences(
            fontSize = fontSize,
            theme = when (page) {
                1 -> Theme.SEPIA
                2, 4, 5 -> Theme.DARK
                else -> Theme.LIGHT
            },
            // Sage, Slate and Dark are Readium's light or dark theme with their own paper and ink colours.
            backgroundColor = when (page) {
                3 -> ReadiumColor(0xFFD6E3D3.toInt())
                4 -> ReadiumColor(0xFF4A4F57.toInt())
                5 -> ReadiumColor(0xFF1C1C1C.toInt())
                else -> null
            },
            textColor = when (page) {
                3 -> ReadiumColor(0xFF22332A.toInt())
                4 -> ReadiumColor(0xFFECEFF3.toInt())
                5 -> ReadiumColor(0xFFE8E8E8.toInt())
                else -> null
            },
            // 100% is Readest's side margin: 2.5% of the width plus 8 dp (about 18 dp on a phone) against Readium's own 20 dp.
            pageMargins = l.margins * READEST_SIDE,
            publisherStyles = if (l.custom) false else null,
            fontFamily = if (l.custom) {
                when (l.fontFamily) {
                    1 -> FontFamily.SANS_SERIF
                    2 -> FontFamily.MONOSPACE
                    else -> FontFamily.SERIF
                }
            } else null,
            lineHeight = if (l.custom) l.lineSpacing.toDouble() else null,
            textAlign = if (l.custom) (if (l.justify) TextAlign.JUSTIFY else TextAlign.START) else null,
            paragraphSpacing = if (l.custom) l.paragraphSpacing.toDouble() else null,
            paragraphIndent = if (l.custom) l.indent.toDouble() else null,
            hyphens = if (l.custom) true else null,
        )
    }
}

/** Readest's side margin (about 18.3 dp on a 411 dp wide phone) divided by Readium's default page margin of 20 dp. */
private const val READEST_SIDE = 0.915
