package com.paperback.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.BookEdits
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.theme.pbTokens

/**
 * Change what Paperback knows about a book: cover, title and author, description, your own page count and the
 * page you are on, the colour of its spine and its place on the shelf (the Library's "My order" sort).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditBookScreen(
    book: Book,
    shelfPlace: Int,
    shelfCount: Int,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onPickCover: () -> Unit,
    onSave: (BookEdits) -> Unit,
) {
    val t = pbTokens()
    var title by remember(book.id) { mutableStateOf(book.title) }
    var author by remember(book.id) { mutableStateOf(book.author) }
    var description by remember(book.id) { mutableStateOf(book.description) }
    var publisher by remember(book.id) { mutableStateOf(book.publisher) }
    var published by remember(book.id) { mutableStateOf(book.published) }
    var genres by remember(book.id) { mutableStateOf(book.tags.joinToString(", ")) }
    var language by remember(book.id) { mutableStateOf(book.language) }
    var pages by remember(book.id) { mutableStateOf(if (book.customPages > 0) book.customPages.toString() else "") }
    var page by remember(book.id) { mutableStateOf(if (book.currentPage > 0) book.currentPage.toString() else "") }
    var spine by remember(book.id) { mutableIntStateOf(book.spineColor) }
    var place by remember(book.id) { mutableStateOf(if (book.shelfOrder > 0) shelfPlace.toString() else "") }

    val customN = pages.toIntOrNull() ?: 0
    val total = if (customN > 0) customN else book.totalPositions
    val pageN = page.toIntOrNull()
    val pageError = when {
        page.isNotBlank() && pageN == null -> "Numbers only."
        pageN != null && total > 0 && pageN > total -> "That is more than the $total pages of this book."
        else -> null
    }
    val canSave = title.isNotBlank() && pageError == null

    PbPage("Edit book", headerSize, onMenu, onSearch, headerGap = 8.dp) {
        // ---- cover
        Row(verticalAlignment = Alignment.CenterVertically) {
            BookCover(book, Modifier.width(96.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("Cover", color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("Pick any picture from your phone.", color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
                ActionPill("Change cover", onClick = onPickCover)
            }
        }

        // ---- pages: the one that matters most
        SectionLabel("Pages")
        PbField(
            pages,
            { pages = it.filter { c -> c.isDigit() }.take(5) },
            if (book.totalPositions > 0) "Pages in this book (file: ${book.totalPositions})" else "Pages in this book",
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )
        PbNote(
            "Paperback counts pages in the file, which is often not the number in the paper book or in other apps. " +
                "Type your own count and pages, progress and time left use it. Leave it empty to use the file's.",
        )
        Spacer(Modifier.height(10.dp))
        PbField(
            page,
            { page = it.filter { c -> c.isDigit() }.take(5) },
            "The page you are on",
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )
        if (pageError != null) {
            Text(pageError, color = DangerRed, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, top = 6.dp))
        }

        // ---- details
        SectionLabel("Details")
        PbField(title, { title = it }, "Title")
        Spacer(Modifier.height(10.dp))
        PbField(author, { author = it }, "Author")
        Spacer(Modifier.height(10.dp))
        PbField(genres, { genres = it }, "Genres, separated by commas")
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { PbField(publisher, { publisher = it }, "Publisher") }
            Box(Modifier.weight(1f)) { PbField(published, { published = it }, "Published") }
        }
        Spacer(Modifier.height(10.dp))
        PbField(language, { language = it.take(12) }, "Language (en, ru...)")
        Spacer(Modifier.height(10.dp))
        PbField(description, { description = it }, "Description", singleLine = false, minLines = 4)

        // ---- shelf
        SectionLabel("On the shelf")
        Text("Spine colour", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, bottom = 10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .height(36.dp)
                    .clip(CircleShape)
                    .background(if (spine == 0) MaterialTheme.colorScheme.primary else t.card)
                    .clickable { spine = 0 }
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Auto", color = if (spine == 0) MaterialTheme.colorScheme.onPrimary else t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
            SPINE_COLORS.forEach { c ->
                val argb = c.toArgb()
                val on = spine == argb
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(c)
                        .then(if (on) Modifier.border(BorderStroke(3.dp, MaterialTheme.colorScheme.primary), CircleShape) else Modifier.border(BorderStroke(1.dp, t.rule), CircleShape))
                        .clickable { spine = argb },
                )
            }
        }
        PbNote("Auto picks a colour from the book. The Library shows the spines on shelves when its View is Shelves.")
        Spacer(Modifier.height(16.dp))
        PbField(
            place,
            { place = it.filter { c -> c.isDigit() }.take(4) },
            if (shelfCount > 0) "Place in My order (1 to $shelfCount)" else "Place in My order",
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )
        PbNote(
            if (book.shelfOrder > 0) "In Library, Sort: My order shows this book number $shelfPlace. Type another number to move it; the others make room."
            else "Not placed yet. In Library, Sort: My order puts the books you placed first, in your order, then the rest. Type 1 for the very first spot.",
        )

        Spacer(Modifier.height(28.dp))
        PbButton(
            "Save",
            enabled = canSave,
            onClick = {
                val tags = genres.split(',').map { it.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }
                val placeN = place.toIntOrNull()?.takeIf { it > 0 }
                onSave(
                    BookEdits(
                        title = title,
                        author = author,
                        description = description,
                        publisher = publisher,
                        published = published,
                        tags = tags,
                        language = language,
                        customPages = customN,
                        currentPage = if (pageN != null && pageN != book.currentPage) pageN else if (page.isBlank() && book.currentPage > 0) 0 else null,
                        spineColor = spine,
                        shelfPosition = if (placeN != null && placeN != (if (book.shelfOrder > 0) shelfPlace else -1)) placeN else null,
                    ),
                )
            },
        )
        Spacer(Modifier.height(24.dp))
    }
}
