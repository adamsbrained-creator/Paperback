package com.paperback.app.reflow;

import java.io.File;

/** A picture found on a PDF page, already saved to [file] (jpg or png). Position is in points, top-left origin. */
public final class PlacedImage {
    public final File file;
    /** Same value for the same picture drawn again (a logo on every page). */
    public final String key;
    public final float x;
    public final float y;
    public final float w;
    public final float h;
    public final int pxW;
    public final int pxH;

    public PlacedImage(File file, String key, float x, float y, float w, float h, int pxW, int pxH) {
        this.file = file;
        this.key = key;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.pxW = pxW;
        this.pxH = pxH;
    }
}
