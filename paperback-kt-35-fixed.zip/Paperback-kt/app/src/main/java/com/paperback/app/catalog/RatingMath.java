package com.paperback.app.catalog;

import java.util.Locale;

/**
 * The maths behind the rating bar. A rating is kept on a 0..10 scale (so halves of a star on a 5-star bar are
 * whole numbers there); the bar always draws five stars, and the number beside it is shown on a 5 or a 10 scale.
 */
public final class RatingMath {
    private RatingMath() {}

    /** Where a touch at [x] (px from the left of the first star) lands on the 0..5 star scale. */
    public static double starsAt(double x, double star, double gap) {
        if (x <= 0) return 0;
        double step = star + gap;
        if (x >= 5 * step - gap) return 5;
        int i = (int) Math.floor(x / step);
        if (i < 0) i = 0;
        if (i > 4) i = 4;
        double frac = (x - i * step) / star;
        if (frac < 0) frac = 0;
        if (frac > 1) frac = 1;
        return i + frac;
    }

    /**
     * A touch turned into a rating on the 0..10 scale, snapped to the chosen step: [scale] is 5 or 10 (what the
     * number shows) and [perUnit] how many steps fit in 1 (1 = whole, 2 = halves, 4 = quarters).
     */
    public static double fromTouch(double x, double star, double gap, int scale, int perUnit) {
        double r10 = starsAt(x, star, gap) * 2.0;
        return snap(r10, scale, perUnit);
    }

    /** Snaps a 0..10 rating to the step of the chosen scale. */
    public static double snap(double r10, int scale, int perUnit) {
        if (perUnit < 1) perUnit = 1;
        double shown = r10 * scale / 10.0;
        double snapped = Math.round(shown * perUnit) / (double) perUnit;
        if (snapped < 0) snapped = 0;
        if (snapped > scale) snapped = scale;
        return snapped * 10.0 / scale;
    }

    /** The number to show for a 0..10 rating on the chosen scale: "4.75", "9.5", "4". */
    public static String format(double r10, int scale) {
        double shown = r10 * scale / 10.0;
        String s = String.format(Locale.ROOT, "%.2f", shown);
        if (s.indexOf('.') >= 0) {
            while (s.endsWith("0")) s = s.substring(0, s.length() - 1);
            if (s.endsWith(".")) s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    /** Stars filled on a 5-star bar. */
    public static double stars(double r10) {
        return Math.max(0, Math.min(5, r10 / 2.0));
    }

    /** The whole-star rating other parts of the app (taste, sorting buttons) use: 0 = not rated, 1..5. */
    public static int wholeStars(double r10) {
        if (r10 <= 0) return 0;
        return Math.max(1, Math.min(5, (int) Math.round(r10 / 2.0)));
    }
}
