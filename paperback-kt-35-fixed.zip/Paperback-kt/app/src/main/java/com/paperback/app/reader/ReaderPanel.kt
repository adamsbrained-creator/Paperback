package com.paperback.app.reader

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Bookmark
import com.paperback.app.data.Highlight
import com.paperback.app.data.HighlightColors
import com.paperback.app.ui.DangerRed
import com.paperback.app.ui.PbDialog
import com.paperback.app.ui.PbField
import com.paperback.app.ui.QuietAction
import com.paperback.app.ui.theme.PbSerif
import org.readium.r2.shared.publication.Locator

/** What the note dialog is editing: a new highlight (highlightId == null) or an existing one. */
data class NoteEditorState(
    val highlightId: String?,
    val locator: Locator?,
    val quote: String,
    val note: String,
    val color: Int,
)

/** One line of the book's table of contents. [depth] is how deeply it is nested (0 = top level). */
data class TocEntry(val title: String, val depth: Int, val locatorJson: String, val href: String)

/** One match of an in-book search, with a little of the text around it. */
data class SearchHit(
    val locatorJson: String,
    val before: String,
    val hit: String,
    val after: String,
    val chapter: String?,
    val progress: Float,
)

/** What the search screen shows. [done] is true once the search has gone through the whole book (or hit the cap). */
data class SearchUi(
    val query: String = "",
    val hits: List<SearchHit> = emptyList(),
    val running: Boolean = false,
    val done: Boolean = false,
    val capped: Boolean = false,
    val error: String? = null,
)

/** Full-screen Contents, bookmarks and notes of this book. Tap one to jump there. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderPanel(
    themeIndex: Int,
    initialTab: Int,
    toc: List<TocEntry>,
    currentHref: String?,
    bookmarks: List<Bookmark>,
    highlights: List<Highlight>,
    onGo: (String) -> Unit,
    onDeleteBookmark: (Bookmark) -> Unit,
    onDeleteHighlight: (Highlight) -> Unit,
    onClose: () -> Unit,
) {
    val c = readerColors(themeIndex)
    // 0 = Contents, 1 = Bookmarks, 2 = Notes
    var tab by remember { mutableIntStateOf(initialTab) }
    BackHandler(onBack = onClose)

    Column(
        Modifier
            .fillMaxSize()
            .background(c.page)
            // swallow touches so nothing reaches the book underneath
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
            .windowInsetsPadding(WindowInsets.systemBarsIgnoringVisibility)
            .padding(horizontal = 20.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Contents & notes",
                modifier = Modifier.weight(1f),
                color = c.ink,
                fontFamily = PbSerif,
                fontSize = 24.sp,
                fontWeight = FontWeight.Medium,
            )
            Pill(c, "Done", onClick = onClose)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(c, "Contents", selected = tab == 0) { tab = 0 }
            Pill(c, "Bookmarks (${bookmarks.size})", selected = tab == 1) { tab = 1 }
            Pill(c, "Notes (${highlights.size})", selected = tab == 2) { tab = 2 }
        }
        Spacer(Modifier.height(12.dp))

        if (tab == 0) {
            if (toc.isEmpty()) {
                Empty(c, "This book has no table of contents.")
            } else {
                val here = currentHref?.substringBefore('#')
                val currentIndex = toc.indexOfLast { it.href.substringBefore('#') == here }
                val listState = rememberLazyListState(initialFirstVisibleItemIndex = (currentIndex - 2).coerceAtLeast(0))
                LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    itemsIndexed(toc) { i, entry ->
                        val isHere = i == currentIndex
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onGo(entry.locatorJson) }
                                .padding(start = (entry.depth.coerceAtMost(4) * 18).dp, top = 13.dp, bottom = 13.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                entry.title,
                                modifier = Modifier.weight(1f),
                                color = if (isHere) MaterialTheme.colorScheme.primary else c.ink,
                                fontSize = if (entry.depth == 0) 16.sp else 15.sp,
                                fontWeight = if (isHere || entry.depth == 0) FontWeight.Medium else FontWeight.Normal,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (isHere) {
                                Spacer(Modifier.width(10.dp))
                                Box(Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                            }
                        }
                    }
                }
            }
        } else if (tab == 1) {
            if (bookmarks.isEmpty()) {
                Empty(c, "No bookmarks yet. Tap the bookmark button at the top of a page.")
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(bookmarks, key = { it.id }) { b ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onGo(b.locatorJson) }.padding(vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                "Page ${b.position} · ${(b.progress * 100).toInt().coerceIn(0, 100)}%",
                                modifier = Modifier.weight(1f),
                                color = c.ink,
                                fontSize = 16.sp,
                            )
                            QuietAction("Remove", onClick = { onDeleteBookmark(b) }, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                        }
                    }
                }
            }
        } else {
            if (highlights.isEmpty()) {
                Empty(c, "No notes yet. Select some text and choose Highlight or Note.")
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(highlights, key = { it.id }) { h ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onGo(h.locatorJson) }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            Box(Modifier.width(4.dp).height(56.dp).clip(RoundedCornerShape(2.dp)).background(Color(h.color)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    h.text.ifBlank { "(no text)" },
                                    color = c.ink,
                                    fontSize = 15.sp,
                                    maxLines = 4,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                if (h.note.isNotBlank()) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(h.note, color = c.ink.copy(alpha = 0.75f), fontSize = 14.sp, fontStyle = FontStyle.Italic)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("${(h.progress * 100).toInt().coerceIn(0, 100)}% into the book", color = c.ink.copy(alpha = 0.5f), fontSize = 12.sp)
                            }
                            QuietAction("Remove", onClick = { onDeleteHighlight(h) }, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Empty(c: ReaderColors, text: String) {
    Text(text, color = c.ink.copy(alpha = 0.6f), fontSize = 15.sp, modifier = Modifier.padding(vertical = 24.dp))
}

@Composable
fun NoteEditorDialog(
    state: NoteEditorState,
    themeIndex: Int,
    onSave: (note: String, color: Int) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    val c = readerColors(themeIndex)
    var note by remember(state) { mutableStateOf(state.note) }
    var color by remember(state) { mutableIntStateOf(state.color) }

    PbDialog(
        title = if (state.highlightId == null) "New note" else "Highlight",
        onDismiss = onDismiss,
        container = c.card,
        ink = c.ink,
    ) {
        if (state.quote.isNotBlank()) {
            Text(
                "\u201C${state.quote}\u201D",
                color = c.ink,
                fontFamily = PbSerif,
                fontStyle = FontStyle.Italic,
                fontSize = 16.sp,
                lineHeight = 23.sp,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(16.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HighlightColors.all.forEach { argb ->
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(argb))
                        .then(if (argb == color) Modifier.border(3.dp, c.ink, CircleShape) else Modifier)
                        .clickable { color = argb },
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        PbField(
            value = note,
            onValueChange = { note = it },
            placeholder = "Add a note",
            singleLine = false,
            minLines = 3,
            container = c.chip,
            ink = c.ink,
        )
        Row(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (onDelete != null) {
                Box(
                    Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(25.dp)).background(c.ink.copy(alpha = 0.08f)).clickable(onClick = onDelete),
                    contentAlignment = Alignment.Center,
                ) { Text("Delete", color = DangerRed, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            } else {
                Box(
                    Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(25.dp)).background(c.ink.copy(alpha = 0.08f)).clickable(onClick = onDismiss),
                    contentAlignment = Alignment.Center,
                ) { Text("Cancel", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            }
            Box(
                Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(25.dp)).background(c.ink).clickable { onSave(note.trim(), color) },
                contentAlignment = Alignment.Center,
            ) { Text("Save", color = c.card, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}
