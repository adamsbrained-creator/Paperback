package com.paperback.app.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import com.paperback.app.R

/**
 * Settings -> App style -> App icon. Each style is an <activity-alias> in the manifest with its own launcher icon;
 * switching icons means enabling one alias and disabling the other.
 */
enum class IconStyle(val label: String, val note: String, val alias: String, val enabledByDefault: Boolean, val preview: Int) {
    Glassy("Glassy", "Frosted pages, soft light", "com.paperback.app.IconGlassy", true, R.drawable.icon_preview_glassy),
    Flat("Flat", "One solid colour", "com.paperback.app.IconFlat", false, R.drawable.icon_preview_flat),
}

object AppIcon {
    /** Makes [style] the launcher icon. The new one is switched on first, so the app never disappears from the launcher. */
    fun apply(context: Context, style: IconStyle) {
        val pm = context.packageManager
        val order = IconStyle.values().sortedBy { if (it == style) 0 else 1 }
        for (s in order) {
            val component = ComponentName(context.packageName, s.alias)
            val wanted = if (s == style) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            val now = pm.getComponentEnabledSetting(component)
            val isOn = when (now) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> s.enabledByDefault
                else -> false
            }
            if (isOn != (s == style)) {
                runCatching { pm.setComponentEnabledSetting(component, wanted, PackageManager.DONT_KILL_APP) }
            }
        }
    }
}
