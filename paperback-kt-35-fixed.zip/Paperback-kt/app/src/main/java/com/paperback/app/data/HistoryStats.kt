package com.paperback.app.data

import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

/*
 * Everything the Stats -> History page shows: a calendar of the reading days of one month, and that month's
 * sessions grouped by day, newest first. A port of the TypeScript app's historyStats.ts. Pure functions.
 * A "session" is the same as on the Activity page (logged rows of one book less than 10 minutes apart, merged).
 */

class CalendarDay(
    val day: Int,
    val date: LocalDate,
    /** Sessions that started on this day. */
    val sessions: Int,
    val isToday: Boolean,
    val inFuture: Boolean,
)

class DayGroup(
    val date: LocalDate,
    /** "19 Oct · Monday" */
    val label: String,
    /** Newest first. */
    val sessions: List<Session>,
)

class MonthView(
    val month: YearMonth,
    /** "October 2026" */
    val title: String,
    /** Empty slots before the 1st (the week starts on Monday). */
    val blanks: Int,
    val days: List<CalendarDay>,
    val sessionCount: Int,
    val pageCount: Int,
    val seconds: Long,
    /** Days with reading, newest first. */
    val groups: List<DayGroup>,
)

/** The first month with any reading, or the current month when there is none. */
fun firstMonth(rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): YearMonth {
    val now = YearMonth.from(today)
    val first = rows.minOfOrNull { it.startMs } ?: return now
    val m = YearMonth.from(dateOf(first, zone))
    return if (m.isAfter(now)) now else m
}

fun monthView(rows: List<ReadingSession>, ym: YearMonth, today: LocalDate, zone: ZoneId): MonthView {
    val inMonth = rows.filter { YearMonth.from(dateOf(it.startMs, zone)) == ym }
    val sessions = buildSessions(inMonth)

    val byDay = HashMap<LocalDate, MutableList<Session>>()
    for (s in sessions) byDay.getOrPut(dateOf(s.startMs, zone)) { ArrayList() }.add(s)

    val days = (1..ym.lengthOfMonth()).map { d ->
        val date = ym.atDay(d)
        CalendarDay(d, date, byDay[date]?.size ?: 0, date == today, date.isAfter(today))
    }
    val groups = byDay.entries
        .sortedByDescending { it.key }
        .map { e ->
            val date = e.key
            DayGroup(
                date = date,
                label = "${date.dayOfMonth} ${StatNames.MONTHS_SHORT[date.monthValue - 1]} \u00B7 ${StatNames.WEEKDAYS[StatNames.weekdayIndex(date)]}",
                sessions = e.value.sortedByDescending { it.startMs },
            )
        }
    return MonthView(
        month = ym,
        title = "${StatNames.MONTHS[ym.monthValue - 1]} ${ym.year}",
        blanks = ym.atDay(1).dayOfWeek.value - 1,
        days = days,
        sessionCount = sessions.size,
        pageCount = sessions.sumOf { it.pages },
        seconds = sessions.sumOf { it.seconds },
        groups = groups,
    )
}

/** "9:41" for the time a session started. */
fun formatClock(ms: Long, zone: ZoneId): String {
    val t = java.time.Instant.ofEpochMilli(ms).atZone(zone)
    return "%d:%02d".format(t.hour, t.minute)
}

/** A stable colour slot (0..3: pink, yellow, blue, mint) for a book, so its sessions always look alike. */
fun accentIndex(key: String): Int {
    var h = 0L
    for (c in key) h = (h * 31 + c.code) and 0xFFFFFFFFL
    return (h % 4).toInt()
}
