package com.paperback.app.catalog;

import java.text.Normalizer;
import java.util.Locale;

/** Titles reduced to their letters, so "The Hobbit, or There and Back Again" can be matched to "The hobbit". */
public final class TitleKey {
    private TitleKey() {}

    public static String of(String title) {
        if (title == null) return "";
        String s = Normalizer.normalize(title, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        s = s.toLowerCase(Locale.ROOT);
        // drop a subtitle: "Dune: Deluxe Edition", "The Hobbit, or There and Back Again", "Title (Series #2)"
        int cut = s.length();
        for (String sep : new String[] {":", " - ", " (", ", or ", " / "}) {
            int i = s.indexOf(sep);
            if (i > 2 && i < cut) cut = i;
        }
        s = s.substring(0, cut);
        s = s.replaceAll("^(the|a|an) ", "");
        return s.replaceAll("[^a-z0-9]+", "");
    }

    /** Same book: equal keys. Short keys (under 4 letters) must match exactly as well. */
    public static boolean same(String a, String b) {
        String ka = of(a), kb = of(b);
        return !ka.isEmpty() && ka.equals(kb);
    }
}
