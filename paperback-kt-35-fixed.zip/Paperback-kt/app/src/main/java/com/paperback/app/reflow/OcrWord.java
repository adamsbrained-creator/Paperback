package com.paperback.app.reflow;

/** One recognised word and the box it sits in, in pixels of the image that was read (origin top left). */
public final class OcrWord {
    public final String text;
    public final int left;
    public final int top;
    public final int right;
    public final int bottom;

    public OcrWord(String text, int left, int top, int right, int bottom) {
        this.text = text;
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    public int width() {
        return right - left;
    }

    public int height() {
        return bottom - top;
    }
}
