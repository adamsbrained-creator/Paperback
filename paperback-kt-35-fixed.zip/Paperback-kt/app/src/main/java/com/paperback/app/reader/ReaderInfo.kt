package com.paperback.app.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The page frame, copied from Readest (TypeScript Paperback): the text stays 64 dp clear of the top of the screen and 44 dp (its
 * marginBottomPx) clear of the bottom, whatever the phone's bars do. The chapter name sits in the top strip and the page counters in the
 * bottom one, like Readest's header and footer. The sides follow Readest too (see ReaderSettings.toEpubPreferences).
 */
val ReaderTopFrame: Dp = 64.dp
val ReaderBottomFrame: Dp = 44.dp

/**
 * The page frame at the reader's "Top and bottom space" setting ([space]: 1 = Readest's 64 dp and 44 dp, 0 = just a thin strip, 20 dp,
 * that still holds the chapter name and the counters, so the text fills as much of the screen as it can).
 */
fun readerTopFrame(space: Float): Dp = (20f + (ReaderTopFrame.value - 20f) * space).dp
fun readerBottomFrame(space: Float): Dp = (20f + (ReaderBottomFrame.value - 20f) * space).dp

/**
 * The small, quiet text around the page, as in Readest: the chapter name at the top; "N pages left in chapter"
 * at the bottom left and "position / total" at the bottom right. "Pages left" counts real screens, so it drops
 * by one for each page you turn; the counter counts fixed pieces of text, so it can move by more than one.
 * Hidden while the reader's controls are showing (they cover this strip).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderMarginInfo(
    themeIndex: Int,
    hidden: Boolean,
    chapter: String,
    pagesLeft: Int,
    position: Int,
    totalPositions: Int,
    space: Float = 1f,
) {
    val c = readerColors(themeIndex)
    val topFrame = readerTopFrame(space)
    val bottomFrame = readerBottomFrame(space)
    val color = c.ink.copy(alpha = 0.55f)
    AnimatedVisibility(visible = !hidden, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .height(topFrame)
                    .padding(start = 18.dp, end = 18.dp, bottom = ((topFrame - 16.dp) / 2).coerceIn(0.dp, 8.dp)),
                contentAlignment = Alignment.BottomStart,
            ) {
                if (chapter.isNotBlank()) {
                    Text(chapter, color = color, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(bottomFrame)
                    .padding(start = 18.dp, end = 18.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                Text(
                    if (pagesLeft > 0) "$pagesLeft ${if (pagesLeft == 1) "page" else "pages"} left in chapter" else "",
                    modifier = Modifier.weight(1f),
                    color = color,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (position > 0 && totalPositions > 0) {
                    Text("$position / $totalPositions", color = color, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}
