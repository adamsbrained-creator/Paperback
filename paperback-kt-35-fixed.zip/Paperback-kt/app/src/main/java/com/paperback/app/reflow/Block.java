package com.paperback.app.reflow;

import java.util.ArrayList;
import java.util.List;

/** One piece of the finished book: a paragraph, a heading, a picture, a scene break, a footnote or a bullet. */
public final class Block {
    public static final int PARA = 0;
    public static final int HEADING = 1;
    public static final int IMAGE = 2;
    public static final int RULE = 3;
    public static final int NOTE = 4;
    public static final int BULLET = 5;

    public final int kind;
    public int level;           // headings: 1 (biggest) to 4
    public String id;           // headings: anchor name
    public final List<Run> runs = new ArrayList<Run>();
    public PlacedImage image;

    public Block(int kind) {
        this.kind = kind;
    }

    public String plainText() {
        StringBuilder b = new StringBuilder();
        for (Run r : runs) b.append(r.text);
        return b.toString().trim();
    }
}
