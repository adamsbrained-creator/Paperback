package com.paperback.app.reflow;

/** A stretch of text with one style. */
public final class Run {
    public String text;
    public boolean bold;
    public boolean italic;
    /** Raised small text: a footnote mark, the "th" of 4th. */
    public boolean sup;

    public Run(String text, boolean bold, boolean italic) {
        this.text = text;
        this.bold = bold;
        this.italic = italic;
    }

    public Run(String text, boolean bold, boolean italic, boolean sup) {
        this(text, bold, italic);
        this.sup = sup;
    }

    /** A copy with other text. */
    public Run with(String newText) {
        return new Run(newText, bold, italic, sup);
    }

    public boolean sameStyle(Run o) {
        return bold == o.bold && italic == o.italic && sup == o.sup;
    }
}
