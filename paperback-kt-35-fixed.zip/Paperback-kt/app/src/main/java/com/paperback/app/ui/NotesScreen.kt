package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.Bookmark
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.Highlight
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

/**
 * Every highlight, note and bookmark, across all books (or just one book). Tap one to open the book there.
 * [initialTab]: 0 = notes, 1 = bookmarks (the menu's "Bookmarks" opens this page on the second tab).
 */
@Composable
fun NotesScreen(
    books: List<Book>,
    highlights: List<Highlight>,
    bookmarks: List<Bookmark>,
    onlyBookId: String?,
    initialTab: Int,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenAt: (Book, String) -> Unit,
    onDeleteHighlight: (Highlight) -> Unit,
    onDeleteBookmark: (Bookmark) -> Unit,
    onShare: (String) -> Unit,
    /** For one book's page: its journal is a third tab next to the notes and the bookmarks. */
    journal: String = "",
    onSaveJournal: ((String) -> Unit)? = null,
) {
    val t = pbTokens()
    var tab by rememberSaveable(initialTab) { mutableStateOf(initialTab) }
    var query by rememberSaveable { mutableStateOf("") }
    var confirmRemove by remember { mutableStateOf<Highlight?>(null) }
    val byId = remember(books) { books.associateBy { it.id } }
    val scoped = remember(onlyBookId, books) { books.firstOrNull { it.id == onlyBookId } }

    val shownHighlights = remember(highlights, query, onlyBookId) {
        val q = query.trim()
        highlights.filter { h ->
            (onlyBookId == null || h.bookId == onlyBookId) &&
                (q.isEmpty() || h.text.contains(q, ignoreCase = true) || h.note.contains(q, ignoreCase = true))
        }
    }
    val shownBookmarks = remember(bookmarks, onlyBookId) {
        bookmarks.filter { onlyBookId == null || it.bookId == onlyBookId }
    }

    PbListPage(scoped?.title ?: "Notes", headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(14.dp))
        PbSegmented(
            options = buildList<Pair<Int, String>> {
                add(0 to "Notes (${shownHighlights.size})")
                add(1 to "Bookmarks (${shownBookmarks.size})")
                if (onSaveJournal != null) add(2 to "Journal")
            },
            selected = tab,
            onSelect = { tab = it },
        )
        Spacer(Modifier.height(12.dp))

        if (tab == 0) {
            PbField(query, { query = it }, "Search your notes", leading = PbIconName.Search, onClear = { query = "" })
            if (shownHighlights.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.End) {
                    ActionPill("Share notes", onClick = { onShare(buildNotesMarkdown(byId, shownHighlights)) })
                }
            }
            Spacer(Modifier.height(10.dp))
            if (shownHighlights.isEmpty()) {
                PbNote(
                    if (highlights.isEmpty()) "No notes yet. In the reader, select some text and choose Highlight or Note."
                    else "Nothing matches.",
                )
            } else {
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 112.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(shownHighlights, key = { it.id }) { h ->
                        val book = byId[h.bookId]
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(t.card)
                                .clickable(enabled = book != null) { book?.let { onOpenAt(it, h.locatorJson) } }
                                .padding(start = 18.dp, end = 12.dp, top = 14.dp, bottom = 16.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).clip(CircleShape).background(Color(h.color)))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    if (onlyBookId == null) (book?.title ?: "Removed book") else "Highlight",
                                    modifier = Modifier.weight(1f),
                                    color = t.setSub,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                QuietAction("Remove", onClick = { confirmRemove = h })
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                h.text.ifBlank { "(no text)" },
                                modifier = Modifier.padding(end = 6.dp),
                                color = t.ink,
                                fontFamily = PbSerif,
                                fontSize = 16.sp,
                                lineHeight = 23.sp,
                                maxLines = 6,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (h.note.isNotBlank()) {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    h.note,
                                    modifier = Modifier.padding(end = 6.dp),
                                    color = t.setSub,
                                    fontSize = 14.sp,
                                    lineHeight = 20.sp,
                                    fontStyle = FontStyle.Italic,
                                )
                            }
                        }
                    }
                }
            }
        } else if (tab == 2 && onSaveJournal != null) {
            var text by remember(journal) { mutableStateOf(journal) }
            PbField(
                value = text,
                onValueChange = { text = it },
                placeholder = "Your thoughts on this book",
                singleLine = false,
                minLines = 8,
            )
            if (text.trim() != journal.trim()) {
                Spacer(Modifier.height(10.dp))
                PbButton("Save journal", onClick = { onSaveJournal(text.trim()) })
            }
        } else {
            if (shownBookmarks.isEmpty()) {
                PbNote("No bookmarks yet. Tap the bookmark button at the top of a page in the reader.")
            } else {
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 112.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(shownBookmarks, key = { it.id }) { b ->
                        val book = byId[b.bookId]
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(t.card)
                                .clickable(enabled = book != null) { book?.let { onOpenAt(it, b.locatorJson) } }
                                .padding(start = 18.dp, end = 12.dp, top = 14.dp, bottom = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            PbIcon(PbIconName.Bookmark, size = 20.dp, tint = MaterialThemePrimary(), filled = true)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (onlyBookId == null) (book?.title ?: "Removed book") else "Page ${b.position}",
                                    color = t.ink,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    if (onlyBookId == null) "Page ${b.position} \u00B7 ${(b.progress * 100).toInt().coerceIn(0, 100)}%"
                                    else "${(b.progress * 100).toInt().coerceIn(0, 100)}% into the book",
                                    color = t.setSub,
                                    fontSize = 13.sp,
                                )
                            }
                            QuietAction("Remove", onClick = { onDeleteBookmark(b) })
                        }
                    }
                }
            }
        }
    }

    confirmRemove?.let { h ->
        PbConfirmDialog(
            title = "Remove this highlight?",
            message = if (h.note.isNotBlank()) "Its note is deleted with it." else "The passage stays in the book; only the highlight goes.",
            confirm = "Remove",
            onConfirm = {
                confirmRemove = null
                onDeleteHighlight(h)
            },
            onDismiss = { confirmRemove = null },
        )
    }
}

@Composable
private fun MaterialThemePrimary() = androidx.compose.material3.MaterialTheme.colorScheme.primary

/** Notes as Markdown, grouped by book, ready to paste into any notes app. */
private fun buildNotesMarkdown(books: Map<String, Book>, highlights: List<Highlight>): String = buildString {
    highlights.groupBy { it.bookId }.forEach { (bookId, list) ->
        val book = books[bookId]
        append("## ").append(book?.title ?: "Removed book").append('\n')
        if (book != null && book.author.isNotBlank()) append("*").append(book.author).append("*\n")
        append('\n')
        list.sortedBy { it.progress }.forEach { h ->
            append("> ").append(h.text.replace("\n", " ")).append("\n\n")
            if (h.note.isNotBlank()) append(h.note).append("\n\n")
        }
    }
}
