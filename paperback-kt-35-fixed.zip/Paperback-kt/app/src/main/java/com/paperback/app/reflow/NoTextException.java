package com.paperback.app.reflow;

/** The PDF is made of pictures of pages (a scan) and has no text of its own. Text recognition can still read it. */
public final class NoTextException extends ReflowException {
    private static final long serialVersionUID = 1L;

    public NoTextException() {
        super("This PDF has almost no text in it. It is probably scanned pages, which can't be reflowed without text recognition.");
    }
}
