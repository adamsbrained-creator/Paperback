package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.HeatCell
import com.paperback.app.data.timeOfDayIndex
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** The soft accent colours used for time of day and the session-length bars. */
object StatsAccent {
    val Blue = Color(0xFF6CB4FF)
    val Yellow = Color(0xFFFFD24D)
    val Mint = Color(0xFF7BD88F)
    val Pink = Color(0xFFF28BB0)

    /** Morning, Afternoon, Evening, Night. */
    val TimeOfDay = listOf(Blue, Yellow, Mint, Pink)
}

private val CHART_HEIGHT = 170.dp

/**
 * The hero chart: one bar per day, month, year... Tap or drag to pick a bar ([onSelect]). Bars that reach the goal
 * are a softer coral, the picked one is solid coral, bars still in the future are a faint stub.
 * [goal] is in the same unit as [values] (or null for no goal line).
 */
@Composable
fun ActivityBarChart(
    values: List<Float?>,
    labels: List<String>,
    selected: Int,
    curIdx: Int,
    goal: Float?,
    goalLabel: String,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val coral = MaterialTheme.colorScheme.primary
    val n = values.size.coerceAtLeast(1)
    val top = max(1f, max(values.filterNotNull().maxOrNull() ?: 0f, goal ?: 0f)) * 1.1f

    Column(modifier) {
        Box(Modifier.fillMaxWidth().height(CHART_HEIGHT)) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .pointerInput(n) {
                        detectTapGestures { o -> onSelect((o.x / size.width * n).toInt().coerceIn(0, n - 1)) }
                    }
                    .pointerInput(n) {
                        detectHorizontalDragGestures { change, _ ->
                            onSelect((change.position.x / size.width * n).toInt().coerceIn(0, n - 1))
                        }
                    },
            ) {
                val slot = size.width / n
                val barW = min(slot * 0.62f, 40.dp.toPx())
                val radius = min(barW / 2f, 8.dp.toPx())
                val stub = 3.dp.toPx()

                // soft column behind the picked bar
                if (selected in 0 until n) {
                    drawRoundRect(
                        coral.copy(alpha = 0.10f),
                        Offset(slot * selected, 0f),
                        Size(slot, size.height),
                        CornerRadius(8.dp.toPx()),
                    )
                }
                values.forEachIndexed { i, v ->
                    val cx = slot * i + slot / 2f
                    val h = if (v == null) 0f else v / top * size.height
                    val barH = max(stub, h)
                    val color = when {
                        v == null -> t.ink.copy(alpha = 0.06f)
                        i == selected -> coral
                        goal != null && v >= goal -> coral.copy(alpha = 0.5f)
                        v <= 0f -> t.ink.copy(alpha = 0.08f)
                        else -> t.ink.copy(alpha = 0.18f)
                    }
                    drawRoundRect(
                        color,
                        Offset(cx - barW / 2f, size.height - barH),
                        Size(barW, barH),
                        CornerRadius(radius),
                    )
                }
                if (goal != null) {
                    val y = size.height - goal / top * size.height
                    drawLine(
                        t.ink.copy(alpha = 0.35f),
                        Offset(0f, y),
                        Offset(size.width, y),
                        strokeWidth = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 9f)),
                    )
                }
            }
            if (goal != null) {
                Text(
                    goalLabel,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(y = CHART_HEIGHT * (1f - goal / top) - 17.dp),
                    color = t.setSub,
                    fontSize = 11.sp,
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            labels.forEachIndexed { i, l ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text(
                        l,
                        modifier = Modifier.wrapContentWidth(unbounded = true),
                        color = if (i == selected) coral else t.setSub,
                        fontSize = 11.sp,
                        fontWeight = if (i == curIdx || i == selected) FontWeight.SemiBold else FontWeight.Normal,
                        softWrap = false,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}

/** The half-circle daily goal gauge, with the minutes read today in the middle. */
@Composable
fun GoalGauge(fraction: Float, readMinutes: Int, goalMinutes: Int, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val coral = MaterialTheme.colorScheme.primary
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val h = maxWidth * (184f / 322f)
        val sideGap = maxWidth * (20f / 322f)
        Box(Modifier.fillMaxWidth().height(h)) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = size.width * 20f / 322f
                val r = size.width * 120f / 322f
                val cx = size.width / 2f
                val cy = size.height * 165f / 184f
                val topLeft = Offset(cx - r, cy - r)
                val arc = Size(2 * r, 2 * r)
                drawArc(t.ink.copy(alpha = 0.08f), 180f, 180f, false, topLeft, arc, style = Stroke(sw, cap = StrokeCap.Round))
                if (fraction > 0f) {
                    drawArc(coral, 180f, 180f * fraction.coerceIn(0f, 1f), false, topLeft, arc, style = Stroke(sw, cap = StrokeCap.Round))
                } else {
                    drawCircle(coral, sw / 2f, Offset(cx - r, cy))
                }
            }
            Column(
                Modifier.align(Alignment.BottomCenter).padding(bottom = h * 0.10f),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("$readMinutes", color = t.ink, fontFamily = PbSerif, fontSize = 40.sp, fontWeight = FontWeight.Medium)
                Text("of $goalMinutes min today", color = t.setSub, fontSize = 13.sp)
            }
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = sideGap)) {
                Text("0", color = t.setSub, fontSize = 11.sp, modifier = Modifier.weight(1f))
                Text("${goalMinutes}m", color = t.setSub, fontSize = 11.sp)
            }
        }
    }
}

/** A tiny line chart with a dot on the latest value. */
@Composable
fun Sparkline(values: List<Int>, color: Color, modifier: Modifier = Modifier) {
    if (values.size < 2) return
    Canvas(modifier.size(width = 110.dp, height = 52.dp)) {
        val lo = values.min()
        val hi = values.max()
        val span = max(1, hi - lo).toFloat()
        val padX = 5.dp.toPx()
        val padY = 8.dp.toPx()
        val pts = values.mapIndexed { i, v ->
            Offset(
                padX + i.toFloat() / (values.size - 1) * (size.width - 2 * padX),
                size.height - padY - (v - lo) / span * (size.height - 2 * padY),
            )
        }
        val path = Path()
        pts.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
        drawPath(path, color, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(color, 5.dp.toPx(), pts.last())
    }
}

/**
 * The reading rhythm grid: [cells] are weeks (columns) of seven days (Monday first). Darker coral = more time.
 * Tap a day to pick it ([onPick]); [selected] gets an outline and today a thin ring.
 */
@Composable
fun Heatmap(
    cells: List<List<HeatCell>>,
    today: LocalDate,
    selected: LocalDate?,
    onPick: (HeatCell) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val coral = MaterialTheme.colorScheme.primary
    val cols = cells.size.coerceAtLeast(1)
    val gap = 3.dp
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val cell: Dp = (maxWidth - gap * (cols - 1)) / cols
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(cell * 7 + gap * 6)
                .pointerInput(cells) {
                    detectTapGestures { o ->
                        val step = (size.width.toFloat() + gap.toPx()) / cols
                        val c = (o.x / step).toInt()
                        val r = (o.y / step).toInt()
                        val cell2 = cells.getOrNull(c)?.getOrNull(r)
                        if (cell2 != null && !cell2.inFuture) onPick(cell2)
                    }
                },
        ) {
            val g = gap.toPx()
            val s = (size.width - g * (cols - 1)) / cols
            cells.forEachIndexed { c, week ->
                week.forEachIndexed { r, cellData ->
                    val x = c * (s + g)
                    val y = r * (s + g)
                    val color = when {
                        cellData.inFuture -> t.ink.copy(alpha = 0.03f)
                        cellData.level == 0 -> t.ink.copy(alpha = 0.07f)
                        cellData.level == 1 -> coral.copy(alpha = 0.30f)
                        cellData.level == 2 -> coral.copy(alpha = 0.50f)
                        cellData.level == 3 -> coral.copy(alpha = 0.75f)
                        else -> coral
                    }
                    drawRoundRect(color, Offset(x, y), Size(s, s), CornerRadius(s * 0.28f))
                    if (cellData.date == today) {
                        drawRoundRect(t.ink, Offset(x, y), Size(s, s), CornerRadius(s * 0.28f), style = Stroke(1.5.dp.toPx()))
                    }
                    if (selected != null && cellData.date == selected) {
                        drawRoundRect(coral, Offset(x - 1.5f, y - 1.5f), Size(s + 3f, s + 3f), CornerRadius(s * 0.32f), style = Stroke(2.dp.toPx()))
                    }
                }
            }
        }
    }
}

private const val CLOCK_R0 = 30f
private const val CLOCK_RMAX = 66f

/**
 * The 24-hour reading clock: midnight at the top, one stalk per hour, longer = more. Colours show the time of day.
 * Tap an hour to pick it ([onSelect]; tapping outside clears it).
 */
@Composable
fun HourClock(
    byHour: List<Int>,
    peakHour: Int,
    selectedHour: Int?,
    onSelect: (Int?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = pbTokens()
    val topValue = max(1, byHour.maxOrNull() ?: 0)
    Box(modifier) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(byHour) {
                    detectTapGestures { o ->
                        val scale = size.width / 220f
                        val dx = o.x - size.width / 2f
                        val dy = o.y - size.height / 2f
                        val rr = hypot(dx, dy) / scale
                        if (rr < CLOCK_R0 - 10f || rr > 104f) {
                            onSelect(null)
                        } else {
                            val deg = (Math.toDegrees(atan2(dx.toDouble(), -dy.toDouble())) + 360.0) % 360.0
                            onSelect((deg / 15.0).toInt().coerceIn(0, 23))
                        }
                    }
                },
        ) {
            val scale = size.width / 220f
            val c = Offset(size.width / 2f, size.height / 2f)
            val faint = t.ink.copy(alpha = 0.10f)
            for (rad in listOf(30f, 60f, 90f)) {
                drawCircle(faint, rad * scale, c, style = Stroke(1.dp.toPx()))
            }
            drawLine(faint, Offset(c.x, c.y - 96f * scale), Offset(c.x, c.y + 96f * scale), strokeWidth = 1.dp.toPx())
            drawLine(faint, Offset(c.x - 96f * scale, c.y), Offset(c.x + 96f * scale, c.y), strokeWidth = 1.dp.toPx())

            if (selectedHour != null) {
                drawArc(
                    t.ink.copy(alpha = 0.08f),
                    startAngle = selectedHour * 15f - 90f,
                    sweepAngle = 15f,
                    useCenter = true,
                    topLeft = Offset(c.x - 100f * scale, c.y - 100f * scale),
                    size = Size(200f * scale, 200f * scale),
                )
            }
            for (h in 0 until 24) {
                val v = byHour.getOrElse(h) { 0 }
                if (v <= 0) continue
                val angle = Math.toRadians(h * 15.0 + 7.5)
                val len = CLOCK_R0 + v.toFloat() / topValue * (CLOCK_RMAX - CLOCK_R0)
                val color = StatsAccent.TimeOfDay[timeOfDayIndex(h)]
                val start = Offset(c.x + (CLOCK_R0 * scale) * sin(angle).toFloat(), c.y - (CLOCK_R0 * scale) * cos(angle).toFloat())
                val end = Offset(c.x + (len * scale) * sin(angle).toFloat(), c.y - (len * scale) * cos(angle).toFloat())
                drawLine(color, start, end, strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                val dot = (if (h == peakHour) 8f else 5f + v.toFloat() / topValue * 3f) * scale
                drawCircle(color, dot, end)
            }
            drawCircle(t.ink, 5f * scale, c)
        }
        Text("00", Modifier.align(Alignment.TopCenter), color = t.setSub, fontSize = 10.sp)
        Text("06", Modifier.align(Alignment.CenterEnd), color = t.setSub, fontSize = 10.sp)
        Text("12", Modifier.align(Alignment.BottomCenter), color = t.setSub, fontSize = 10.sp)
        Text("18", Modifier.align(Alignment.CenterStart), color = t.setSub, fontSize = 10.sp)
    }
}
