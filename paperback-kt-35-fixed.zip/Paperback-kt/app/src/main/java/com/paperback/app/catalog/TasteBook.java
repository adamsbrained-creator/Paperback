package com.paperback.app.catalog;

import java.util.Collections;
import java.util.List;

/** What the recommender needs to know about one of your books. */
public final class TasteBook {
    public final String title;
    public final String author;
    public final List<String> tags;
    /** Your rating, 0 = none. */
    public final int rating;
    /** 0..1 */
    public final double progress;
    public final boolean finished;
    public final boolean favorite;

    public TasteBook(String title, String author, List<String> tags, int rating, double progress,
                     boolean finished, boolean favorite) {
        this.title = title == null ? "" : title;
        this.author = author == null ? "" : author;
        this.tags = tags == null ? Collections.<String>emptyList() : tags;
        this.rating = rating;
        this.progress = progress;
        this.finished = finished;
        this.favorite = favorite;
    }
}
