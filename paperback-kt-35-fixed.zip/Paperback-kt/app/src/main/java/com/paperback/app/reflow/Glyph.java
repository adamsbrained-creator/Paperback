package com.paperback.app.reflow;

/**
 * One character as it sits on a PDF page. Coordinates are in points with the origin at the top left of the page,
 * so [y] grows downwards and is the text's baseline.
 */
public final class Glyph {
    public final String text;
    public final float x;
    public final float y;
    public final float w;
    public final float size;
    public final boolean bold;
    public final boolean italic;

    public Glyph(String text, float x, float y, float w, float size, boolean bold, boolean italic) {
        this.text = text;
        this.x = x;
        this.y = y;
        this.w = w;
        this.size = size;
        this.bold = bold;
        this.italic = italic;
    }
}
