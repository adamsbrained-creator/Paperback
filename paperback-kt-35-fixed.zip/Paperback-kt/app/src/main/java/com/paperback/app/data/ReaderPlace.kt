package com.paperback.app.data

import java.net.URLDecoder
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** One line of the contents, reduced to what the reader's header and footer need: its title and which file of the book it starts in. */
class TocRef(val title: String, val resource: Int)

/**
 * Where you are inside a chapter, in the way Readest's footer counts it: "pages left in chapter" counts real
 * screens (it drops by one for every page you turn), while the "2 / 196" counter counts fixed-size chunks of
 * text (Readium "positions"), so it can jump by two for one turn. Plain Kotlin so it can be tested on its own.
 */
object ReaderPlace {
    /**
     * The contents entry you are in: the one that starts latest at or before [resource] (the file you are reading).
     * If several entries start in that same file, the first of them. -1 when the contents has nothing before here.
     */
    fun chapterIndex(toc: List<TocRef>, resource: Int): Int {
        var found = -1
        for ((i, e) in toc.withIndex()) {
            if (e.resource < 0 || e.resource > resource) continue
            if (found < 0 || e.resource > toc[found].resource) found = i
        }
        return found
    }

    /** The first file after the chapter (the next entry that starts in a later file), or [resourceCount] for the last chapter. */
    fun chapterEnd(toc: List<TocRef>, chapter: Int, resourceCount: Int): Int {
        val start = toc[chapter].resource
        return toc.filter { it.resource > start }.minOfOrNull { it.resource } ?: resourceCount
    }

    /** Which screen of the file you are on (0 = the first), from Readium's 0..1 progression through the file. */
    fun screenIndex(progression: Double, screens: Int): Int =
        if (screens <= 0) 0 else (progression * screens).roundToInt().coerceIn(0, screens - 1)

    /** How many screens of the file [resource] there are, per position, applied to the files that come after it in the chapter. */
    fun pagesLeft(screens: Int, screenIndex: Int, positionsHere: Int, positionsAfter: Int): Int {
        if (screens <= 0) return 0
        val here = screens - screenIndex.coerceIn(0, screens - 1) // the screen you are on counts, like in Readest
        val perPosition = if (positionsHere > 0) screens.toDouble() / positionsHere else 0.0
        return max(1, here + (positionsAfter * perPosition).roundToInt())
    }

    /** Positions in the files after [resource] up to (not including) [end]. */
    fun positionsAfter(positionsPerResource: List<Int>, resource: Int, end: Int): Int {
        var sum = 0
        for (r in (resource + 1) until minOf(end, positionsPerResource.size)) sum += positionsPerResource[r]
        return sum
    }
}

/**
 * The "25 / 136" counter, worked out like Readest does: the book is cut into small locations (1500 bytes, exactly Readest's size) of the
 * (unpacked) book text, and the counter says which location the top of your page is in. A page usually holds more
 * than one location, so the counter can jump by 2 or more per page turn. (Readium's own "positions" are cut by
 * the packed size, which makes them much longer, so the counter would stand still for several pages.)
 * [sizes] is the unpacked size in bytes of every file of the book, in reading order.
 */
class LocationCounter(sizes: List<Long>, private val perLocation: Int = SIZE_PER_LOCATION) {
    private val sizes = sizes.map { max(0L, it) }
    private val before = LongArray(this.sizes.size + 1).also { for (i in this.sizes.indices) it[i + 1] = it[i] + this.sizes[i] }

    /** How many locations the whole book has. */
    val total: Int = max(1, ceil(before.last().toDouble() / perLocation).toInt())

    /** The location (1 = the first) at [progression] (0..1) of the file [resource]; 0 when the file is unknown. */
    fun current(resource: Int, progression: Double): Int {
        if (resource !in sizes.indices || before.last() <= 0L) return 0
        val bytes = before[resource] + (progression.coerceIn(0.0, 1.0) * sizes[resource]).toLong()
        return min(total, (bytes / perLocation).toInt() + 1)
    }

    companion object {
        /** Readest's own size, so the numbers match what Readest shows for the same book. A page usually holds a little more than one, so the counter moves by 1 most of the time and by 2 now and then. */
        const val SIZE_PER_LOCATION = 1500
    }
}

object EpubSizes {
    private fun decode(s: String): String = runCatching { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") }.getOrDefault(s)

    /**
     * The unpacked size of the file [href] (as Readium names it) from a table of zip entry names to sizes.
     * Tries the exact name first, then without a leading slash, then a name that ends the same way. null if not found.
     */
    fun sizeOf(entries: Map<String, Long>, href: String): Long? {
        val h = decode(href.substringBefore('#')).trimStart('/')
        entries[h]?.let { return it }
        entries.entries.firstOrNull { it.key.endsWith("/$h") }?.let { return it.value }
        entries.entries.firstOrNull { h.endsWith("/" + it.key) }?.let { return it.value }
        return null
    }
}
