package com.paperback.app.ui

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Lets a whole screen be swiped sideways: right for [onSwipeRight] (usually Back), left for [onSwipeLeft].
 * Anything inside that scrolls or drags sideways (sliders, charts, a row of covers, the rating stars) takes the
 * swipe first, so those keep working; only a free horizontal swipe of about 80 dp counts.
 */
@Composable
fun SwipeHost(
    enabled: Boolean,
    onSwipeRight: (() -> Unit)?,
    onSwipeLeft: (() -> Unit)?,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val right by rememberUpdatedState(onSwipeRight)
    val left by rememberUpdatedState(onSwipeLeft)
    Box(
        modifier.pointerInput(enabled) {
            if (!enabled) return@pointerInput
            val threshold = 80.dp.toPx()
            var total = 0f
            detectHorizontalDragGestures(
                onDragStart = { total = 0f },
                onDragCancel = { total = 0f },
                onDragEnd = {
                    if (total > threshold) right?.invoke() else if (total < -threshold) left?.invoke()
                    total = 0f
                },
                onHorizontalDrag = { _, amount -> total += amount },
            )
        },
        content = content,
    )
}
