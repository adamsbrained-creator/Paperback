package com.paperback.app.catalog;

/**
 * Pages of a book. The file has its own count of "positions" (what the reader saves); you may set your own
 * page count (the number printed in the paper book, or your other app's). Everything you see is in the
 * count that applies; what is stored for resuming stays in positions.
 */
public final class PageMath {
    private PageMath() {}

    /** The page count that applies: yours if you set one, else the file's. */
    public static int total(int customPages, int totalPositions) {
        return customPages > 0 ? customPages : totalPositions;
    }

    /** The page you are on, in the count that applies. 0 = not started. */
    public static int current(int customPages, int totalPositions, int position, double progress, boolean finished) {
        if (customPages <= 0) return Math.max(0, position);
        if (finished) return customPages;
        if (progress <= 0 && position <= 0) return 0;
        long p = Math.round(progress * customPages);
        if (p < 1) p = 1;
        if (p > customPages) p = customPages;
        return (int) p;
    }

    /** 0..1 for a page in the count that applies. */
    public static double progressForPage(int page, int total) {
        if (total <= 0 || page <= 0) return 0;
        return Math.min(1.0, page / (double) total);
    }

    /** The reader's own position (1..totalPositions) that matches [page]; page itself when the book has no count. */
    public static int positionFor(int page, int total, int totalPositions) {
        if (page <= 0) return 0;
        if (totalPositions <= 0) return page;
        if (total <= 0 || total == totalPositions) return Math.min(page, totalPositions);
        long p = Math.round(page / (double) total * totalPositions);
        if (p < 1) p = 1;
        if (p > totalPositions) p = totalPositions;
        return (int) p;
    }
}
