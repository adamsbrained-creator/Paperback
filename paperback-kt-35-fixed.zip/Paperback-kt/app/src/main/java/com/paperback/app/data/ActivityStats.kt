package com.paperback.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/*
 * Everything the Stats -> Activity page computes, as plain functions (no Android, no UI, no clock: they all take
 * `today`). A port of the TypeScript app's activityStats.ts and statsAggregate.ts.
 *
 * One difference in the data: the TypeScript app logged every page visit, this app logs reading sessions
 * (when you started, seconds read, pages turned). So "sessions" are rows merged when they are the same book
 * within 10 minutes of each other, and "pages" is the pages you turned (not distinct pages).
 * Days and hours use the phone's time zone.
 */

enum class Period { Week, Month, Year, All }

object StatNames {
    val MONTHS = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
    )
    val MONTHS_SHORT = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    /** Sunday first, to match [weekdayIndex]. */
    val WEEKDAYS = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    val WEEKDAYS_SHORT = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    val INITIALS = listOf("S", "M", "T", "W", "T", "F", "S")
    val WEEKDAYS_MON_FIRST = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

    /** Sunday = 0 ... Saturday = 6. */
    fun weekdayIndex(d: LocalDate): Int = d.dayOfWeek.value % 7
}

internal fun dateOf(ms: Long, zone: ZoneId): LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()

private fun daysBetween(a: LocalDate, b: LocalDate): Int = ChronoUnit.DAYS.between(a, b).toInt()

// ---- periods ------------------------------------------------------------------------------

/** Which window the hero chart shows. Only the part that belongs to the chosen period is used. */
data class Anchor(
    /** Week: the last of the seven days. */
    val weekEnd: LocalDate,
    val month: YearMonth,
    val year: Int,
)

fun currentAnchor(today: LocalDate) = Anchor(today, YearMonth.from(today), today.year)

data class PeriodInfo(
    val period: Period,
    val start: LocalDate,
    /** Last day of the window (can be after today for a running month or year). */
    val end: LocalDate,
    val isCurrent: Boolean,
    /** "last 7 days" · "7 – 13 Oct" · "October" · "2026" · "all time" */
    val label: String,
    /** Between the pager arrows: "7 – 13 Oct" · "October 2026" · "2026". Empty for all time. */
    val pagerLabel: String,
    /** "last week" · "the week before" · "September" · "2025" */
    val vsName: String,
    /** One short label per bar. */
    val labels: List<String>,
    val count: Int,
    /** The running bar (today / this month / this year), or -1. */
    val curIdx: Int,
    /** All time: the first bar's year. */
    val firstYear: Int,
)

/** "7 – 13 Oct", or "28 Dec – 3 Jan 2026" when the week crosses a month or year. */
fun weekRangeLabel(end: LocalDate): String {
    val s = end.minusDays(6)
    val e = "${end.dayOfMonth} ${StatNames.MONTHS_SHORT[end.monthValue - 1]}"
    if (s.monthValue == end.monthValue && s.year == end.year) return "${s.dayOfMonth} \u2013 $e"
    val sp = "${s.dayOfMonth} ${StatNames.MONTHS_SHORT[s.monthValue - 1]}"
    return "$sp \u2013 $e" + if (s.year != end.year) " ${end.year}" else ""
}

/** The first year with any reading (for All time), or this year when there is none. */
fun firstReadingYear(rows: List<ReadingSession>, today: LocalDate, zone: ZoneId): Int {
    val first = rows.minOfOrNull { it.startMs } ?: return today.year
    return min(dateOf(first, zone).year, today.year)
}

fun periodInfo(period: Period, anchor: Anchor, today: LocalDate, firstYear: Int): PeriodInfo = when (period) {
    Period.Week -> {
        val end = if (anchor.weekEnd.isAfter(today)) today else anchor.weekEnd
        val isCurrent = end == today
        PeriodInfo(
            period = period, start = end.minusDays(6), end = end, isCurrent = isCurrent,
            label = if (isCurrent) "last 7 days" else weekRangeLabel(end),
            pagerLabel = weekRangeLabel(end),
            vsName = if (isCurrent) "last week" else "the week before",
            labels = (0 until 7).map { StatNames.INITIALS[StatNames.weekdayIndex(end.minusDays((6 - it).toLong()))] },
            count = 7, curIdx = if (isCurrent) 6 else -1, firstYear = firstYear,
        )
    }
    Period.Month -> {
        val ym = anchor.month
        val n = ym.lengthOfMonth()
        val isCurrent = ym == YearMonth.from(today)
        PeriodInfo(
            period = period, start = ym.atDay(1), end = ym.atEndOfMonth(), isCurrent = isCurrent,
            label = StatNames.MONTHS[ym.monthValue - 1] + if (ym.year == today.year) "" else " ${ym.year}",
            pagerLabel = "${StatNames.MONTHS[ym.monthValue - 1]} ${ym.year}",
            vsName = StatNames.MONTHS[(ym.monthValue + 10) % 12],
            labels = (0 until n).map { if (it % 7 == 0) (it + 1).toString() else "" },
            count = n, curIdx = if (isCurrent) today.dayOfMonth - 1 else -1, firstYear = firstYear,
        )
    }
    Period.Year -> {
        val y = anchor.year
        val isCurrent = y == today.year
        PeriodInfo(
            period = period, start = LocalDate.of(y, 1, 1), end = LocalDate.of(y, 12, 31), isCurrent = isCurrent,
            label = y.toString(), pagerLabel = y.toString(), vsName = (y - 1).toString(),
            labels = "JFMAMJJASOND".map { it.toString() },
            count = 12, curIdx = if (isCurrent) today.monthValue - 1 else -1, firstYear = firstYear,
        )
    }
    Period.All -> {
        // One bar per year, at least two so the chart is not a single block.
        val first = min(firstYear, today.year - 1)
        val years = today.year - first + 1
        PeriodInfo(
            period = period, start = LocalDate.of(first, 1, 1), end = LocalDate.of(today.year, 12, 31), isCurrent = true,
            label = "all time", pagerLabel = "", vsName = "",
            labels = (0 until years).map { (first + it).toString() },
            count = years, curIdx = years - 1, firstYear = first,
        )
    }
}

/** The anchor one step earlier (-1) or later (+1); never later than the current period. */
fun shiftAnchor(period: Period, a: Anchor, dir: Int, today: LocalDate): Anchor = when (period) {
    Period.Week -> {
        val next = a.weekEnd.plusDays(7L * dir)
        a.copy(weekEnd = if (next.isAfter(today)) today else next)
    }
    Period.Month -> {
        val cap = YearMonth.from(today)
        val next = a.month.plusMonths(dir.toLong())
        a.copy(month = if (next.isAfter(cap)) cap else next)
    }
    Period.Year -> a.copy(year = min(a.year + dir, today.year))
    Period.All -> a
}

// ---- sessions and totals ------------------------------------------------------------------

/** A reading sitting: logged rows of the same book, close together, merged. */
data class Session(
    val bookId: String,
    val startMs: Long,
    val endMs: Long,
    val seconds: Long,
    val pages: Int,
    /** First and last page (reader position) of the session, 0 = not known. */
    val fromPos: Int = 0,
    val toPos: Int = 0,
)

/** Two rows of the same book closer than this belong to one session. */
private const val SESSION_GAP_MS = 10 * 60 * 1000L

fun buildSessions(rows: List<ReadingSession>): List<Session> {
    val out = ArrayList<Session>()
    var cur: Session? = null
    for (r in rows.sortedBy { it.startMs }) {
        if (r.seconds <= 0 && r.pages <= 0) continue
        val end = r.startMs + r.seconds * 1000L
        val c = cur
        if (c != null && c.bookId == r.bookId && r.startMs - c.endMs <= SESSION_GAP_MS) {
            val from = when {
                c.fromPos == 0 -> r.fromPos
                r.fromPos == 0 -> c.fromPos
                else -> min(c.fromPos, r.fromPos)
            }
            val merged = c.copy(
                endMs = max(c.endMs, end),
                seconds = c.seconds + r.seconds,
                pages = c.pages + r.pages,
                fromPos = from,
                toPos = max(c.toPos, r.toPos),
            )
            out[out.lastIndex] = merged
            cur = merged
        } else {
            val s = Session(r.bookId, r.startMs, end, r.seconds.toLong(), r.pages, r.fromPos, r.toPos)
            out.add(s)
            cur = s
        }
    }
    return out
}

data class Summary(
    val seconds: Long,
    val pages: Int,
    val books: Int,
    val sessions: Int,
    val avgSessionSeconds: Long,
    val pagesPerHour: Int,
)

fun computeSummary(rows: List<ReadingSession>, sessions: List<Session>): Summary {
    var seconds = 0L
    var pages = 0
    val books = HashSet<String>()
    for (r in rows) {
        if (r.seconds <= 0 && r.pages <= 0) continue
        seconds += r.seconds
        pages += r.pages
        books.add(r.bookId)
    }
    val n = sessions.size
    return Summary(
        seconds = seconds,
        pages = pages,
        books = books.size,
        sessions = n,
        avgSessionSeconds = if (n > 0) (seconds.toDouble() / n).roundToLong() else 0L,
        pagesPerHour = if (seconds > 0) ((pages.toDouble() / seconds) * 3600).roundToInt() else 0,
    )
}

// ---- bars and totals for a period ---------------------------------------------------------

class PeriodData(
    val info: PeriodInfo,
    /** Seconds and pages per bar; null for bars that are still in the future. */
    val seconds: List<Long?>,
    val pages: List<Int?>,
    val totalSeconds: Long,
    val totalPages: Int,
    /** The logged rows inside the window. */
    val rows: List<ReadingSession>,
    val summary: Summary,
    val sessions: List<Session>,
)

private fun bucketIndex(info: PeriodInfo, d: LocalDate): Int = when (info.period) {
    Period.Week -> daysBetween(info.start, d)
    Period.Month -> d.dayOfMonth - 1
    Period.Year -> d.monthValue - 1
    Period.All -> d.year - info.firstYear
}

/** The date a bar of the hero chart stands for. */
fun barDate(info: PeriodInfo, i: Int): LocalDate = when (info.period) {
    Period.Week -> info.start.plusDays(i.toLong())
    Period.Month -> info.start.plusDays(i.toLong())
    Period.Year -> LocalDate.of(info.start.year, i + 1, 1)
    Period.All -> LocalDate.of(info.firstYear + i, 1, 1)
}

/** What the chart's readout says for one bar: "Mon", "12 Oct", "Mar", "2026". */
fun barName(info: PeriodInfo, i: Int): String {
    val d = barDate(info, i)
    return when (info.period) {
        Period.Week -> StatNames.WEEKDAYS[StatNames.weekdayIndex(d)].take(3)
        Period.Month -> "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"
        Period.Year -> StatNames.MONTHS_SHORT[d.monthValue - 1]
        Period.All -> d.year.toString()
    }
}

fun periodData(all: List<ReadingSession>, info: PeriodInfo, today: LocalDate, zone: ZoneId): PeriodData {
    val inWindow = all.filter { r ->
        info.period == Period.All || dateOf(r.startMs, zone).let { !it.isBefore(info.start) && !it.isAfter(info.end) }
    }
    val secs = LongArray(info.count)
    val pgs = IntArray(info.count)
    for (r in inWindow) {
        if (r.seconds <= 0 && r.pages <= 0) continue
        val i = bucketIndex(info, dateOf(r.startMs, zone))
        if (i < 0 || i >= info.count) continue
        secs[i] += r.seconds.toLong()
        pgs[i] += r.pages
    }
    // A bar is "future" when it starts after today.
    val seconds: List<Long?> = (0 until info.count).map { i -> if (barDate(info, i).isAfter(today)) null else secs[i] }
    val pages: List<Int?> = (0 until info.count).map { i -> if (seconds[i] == null) null else pgs[i] }
    val sessions = buildSessions(inWindow)
    return PeriodData(
        info = info,
        seconds = seconds,
        pages = pages,
        totalSeconds = seconds.sumOf { it ?: 0L },
        totalPages = pages.sumOf { it ?: 0 },
        rows = inWindow,
        summary = computeSummary(inWindow, sessions),
        sessions = sessions,
    )
}

/** Whole-number percent change, or null when there is nothing to compare with. */
fun pctDelta(cur: Long, prev: Long): Int? = if (prev > 0) (((cur - prev).toDouble() / prev) * 100).roundToInt() else null

/** "+3", "\u22122", "0". */
fun signed(n: Int): String = when {
    n > 0 -> "+$n"
    n < 0 -> "\u2212${abs(n)}"
    else -> "0"
}

fun formatCount(n: Int): String = "%,d".format(n)

// ---- the detail tiles ---------------------------------------------------------------------

data class DayTotal(val date: LocalDate, val seconds: Long)

data class Details(
    val pace: Int, // pages per hour
    val avgSessionSeconds: Long,
    val sessions: Int,
    val longest: Session?,
    val bestDay: DayTotal?,
    val avgPerDaySeconds: Long,
)

fun computeDetails(data: PeriodData, today: LocalDate, zone: ZoneId): Details {
    val info = data.info
    val longest = data.sessions.maxByOrNull { it.seconds }
    val byDay = Stats.secondsByDay(data.rows, zone)
    var best: DayTotal? = null
    var first: LocalDate? = null
    for ((d, s) in byDay) {
        val b = best
        if (b == null || s > b.seconds) best = DayTotal(d, s)
        val f = first
        if (f == null || d.isBefore(f)) first = d
    }
    // Days that have passed so far in the window (all time: since the first day with reading).
    val winStart = if (info.period == Period.All) (first ?: today) else info.start
    val winEnd = if (info.end.isAfter(today)) today else info.end
    val days = max(1L, ChronoUnit.DAYS.between(winStart, winEnd) + 1)
    return Details(
        pace = data.summary.pagesPerHour,
        avgSessionSeconds = data.summary.avgSessionSeconds,
        sessions = data.summary.sessions,
        longest = longest,
        bestDay = best,
        avgPerDaySeconds = (data.summary.seconds.toDouble() / days).roundToLong(),
    )
}

fun timeOfDayName(hour: Int): String = when {
    hour in 5..11 -> "Morning"
    hour in 12..16 -> "Afternoon"
    hour in 17..21 -> "Evening"
    else -> "Night"
}

/** 0 Morning, 1 Afternoon, 2 Evening, 3 Night. */
fun timeOfDayIndex(hour: Int): Int = when {
    hour in 5..11 -> 0
    hour in 12..16 -> 1
    hour in 17..21 -> 2
    else -> 3
}

/** "Sat 10 Oct" · "3 Sep" · "3 Sep 2026" · "Saturday", depending on the period. */
fun dateLabel(period: Period, d: LocalDate): String {
    val dm = "${d.dayOfMonth} ${StatNames.MONTHS_SHORT[d.monthValue - 1]}"
    return when (period) {
        Period.Week -> StatNames.WEEKDAYS[StatNames.weekdayIndex(d)]
        Period.Month -> "${StatNames.WEEKDAYS_SHORT[StatNames.weekdayIndex(d)]} $dm"
        Period.Year -> dm
        Period.All -> "$dm ${d.year}"
    }
}

/** The longest session's "when": "Saturday evening" for a week, otherwise the date. */
fun sessionWhen(period: Period, s: Session, zone: ZoneId): String {
    val dt = Instant.ofEpochMilli(s.startMs).atZone(zone)
    return if (period == Period.Week) {
        "${StatNames.WEEKDAYS[StatNames.weekdayIndex(dt.toLocalDate())]} ${timeOfDayName(dt.hour).lowercase()}"
    } else {
        dateLabel(period, dt.toLocalDate())
    }
}

// ---- the daily goal over the last seven days ----------------------------------------------

data class GoalDay(val date: LocalDate, val initial: String, val met: Boolean, val isToday: Boolean)

fun goalWeek(byDay: Map<LocalDate, Long>, goalMinutes: Int, today: LocalDate): List<GoalDay> =
    (6 downTo 0).map { i ->
        val d = today.minusDays(i.toLong())
        GoalDay(d, StatNames.INITIALS[StatNames.weekdayIndex(d)], (byDay[d] ?: 0L) >= goalMinutes * 60L, i == 0)
    }

data class BestAction(val title: String, val text: String)

/** One short suggestion for today, from the goal, the streak and what has been read so far. */
fun nextBestAction(todaySeconds: Long, goalMinutes: Int, streak: Int, longestStreak: Int): BestAction {
    val readMin = (todaySeconds / 60).toInt()
    val left = max(0, goalMinutes - readMin)
    return when {
        left == 0 -> BestAction(
            "Daily goal reached",
            if (streak > 1) "$streak days in a row. See you tomorrow." else "Nice work today. See you tomorrow.",
        )
        todaySeconds >= 60 -> BestAction(
            "$left min to today's goal",
            "Read $left more ${if (left == 1) "minute" else "minutes"} to reach $goalMinutes.",
        )
        streak > 0 -> BestAction("Keep your $streak-day streak", "Read $goalMinutes minutes today to keep it going.")
        longestStreak > 0 -> BestAction(
            "Start a new streak",
            "Your best is $longestStreak ${if (longestStreak == 1) "day" else "days"}. Read $goalMinutes minutes today.",
        )
        else -> BestAction("Light your first streak day", "Read $goalMinutes minutes today to start a streak.")
    }
}

/** Pages per hour for each bar that has reading in it, oldest first (the last [max] of them). */
fun paceSeries(data: PeriodData, maxPoints: Int = 12): List<Int> {
    val out = ArrayList<Int>()
    data.seconds.forEachIndexed { i, s ->
        val p = data.pages[i]
        if (s != null && s > 0 && p != null && p > 0) out.add(((p.toDouble() / s) * 3600).roundToInt())
    }
    return out.takeLast(maxPoints)
}

// ---- the rhythm heatmap -------------------------------------------------------------------

class HeatCell(val date: LocalDate, val seconds: Long, val level: Int, val inFuture: Boolean)

private fun levelOf(seconds: Long): Int {
    val minutes = seconds / 60.0
    return when {
        minutes < 1 -> 0
        minutes < 15 -> 1
        minutes < 30 -> 2
        minutes < 60 -> 3
        else -> 4
    }
}

/** [weeks] columns of 7 rows (Monday to Sunday); the last column is the current week. */
fun buildHeatmap(byDay: Map<LocalDate, Long>, today: LocalDate, weeks: Int = 18): List<List<HeatCell>> {
    val lastMonday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val firstMonday = lastMonday.minusDays(7L * (weeks - 1))
    return (0 until weeks).map { w ->
        (0 until 7).map { d ->
            val date = firstMonday.plusDays((w * 7 + d).toLong())
            val seconds = byDay[date] ?: 0L
            val future = date.isAfter(today)
            HeatCell(date, seconds, if (future) 0 else levelOf(seconds), future)
        }
    }
}

// ---- reading patterns (last 90 days) ------------------------------------------------------

enum class PatternMetric { Sessions, Pages }

const val PATTERN_DAYS = 90

data class NamedCount(val name: String, val value: Int)

class Patterns(
    val total: Int,
    val byHour: List<Int>, // 24
    val byTime: List<NamedCount>, // Morning, Afternoon, Evening, Night
    val byWeekday: List<NamedCount>, // Monday first
    val topTime: NamedCount,
    val topWeekday: NamedCount,
    val peakHour: Int,
    /** Compares the per-day average of Mon-Fri with Sat-Sun (15% apart or more wins). */
    val weekPart: String, // "weekdays" | "weekends" | "all week"
)

fun readingPatterns(rows: List<ReadingSession>, metric: PatternMetric, today: LocalDate, zone: ZoneId): Patterns {
    val from = today.minusDays((PATTERN_DAYS - 1).toLong())
    val recent = rows.filter { !dateOf(it.startMs, zone).isBefore(from) }
    // One entry per counted session, or per page turned, at the time it started.
    val points = ArrayList<Pair<Long, Int>>()
    if (metric == PatternMetric.Sessions) {
        for (s in buildSessions(recent)) points.add(s.startMs to 1)
    } else {
        for (r in recent) if (r.pages > 0) points.add(r.startMs to r.pages)
    }

    val byHour = IntArray(24)
    val time = IntArray(4)
    val weekday = IntArray(7) // Monday first
    var total = 0
    for ((ms, w) in points) {
        val dt = Instant.ofEpochMilli(ms).atZone(zone)
        byHour[dt.hour] += w
        time[timeOfDayIndex(dt.hour)] += w
        weekday[dt.dayOfWeek.value - 1] += w
        total += w
    }

    val timeNames = listOf("Morning", "Afternoon", "Evening", "Night")
    val byTime = timeNames.mapIndexed { i, n -> NamedCount(n, time[i]) }
    val byWeekday = StatNames.WEEKDAYS_MON_FIRST.mapIndexed { i, n -> NamedCount(n, weekday[i]) }
    fun top(list: List<NamedCount>): NamedCount = list.reduce { b, x -> if (x.value > b.value) x else b }
    val peakHour = byHour.indices.maxByOrNull { byHour[it] } ?: 0

    val wd = weekday.take(5).sum() / 5.0
    val we = weekday.drop(5).sum() / 2.0
    val weekPart = when {
        wd > we * 1.15 -> "weekdays"
        we > wd * 1.15 -> "weekends"
        else -> "all week"
    }
    return Patterns(total, byHour.toList(), byTime, byWeekday, top(byTime), top(byWeekday), peakHour, weekPart)
}

// ---- most read, finished, and lifetime totals ---------------------------------------------

class TopBook(val bookId: String, val seconds: Long, val share: Float)

fun topBooks(rows: List<ReadingSession>, limit: Int = 5): List<TopBook> {
    val map = HashMap<String, Long>()
    var total = 0L
    for (r in rows) {
        if (r.seconds <= 0) continue
        total += r.seconds
        map[r.bookId] = (map[r.bookId] ?: 0L) + r.seconds
    }
    return map.entries
        .sortedByDescending { it.value }
        .take(limit)
        .map { TopBook(it.key, it.value, if (total > 0) it.value.toFloat() / total else 0f) }
}

/** The day a finished book counts for: the saved finish date, else when it was last opened (or added). */
fun finishedDate(b: Book, zone: ZoneId): LocalDate =
    dateOf(if (b.finishedAt > 0) b.finishedAt else max(b.lastOpenedAt, b.addedAt), zone)

fun finishedBetween(books: List<Book>, start: LocalDate, end: LocalDate, zone: ZoneId): Int =
    books.count { b -> b.finished && finishedDate(b, zone).let { !it.isBefore(start) && !it.isAfter(end) } }

class Lifetime(
    val seconds: Long,
    val pages: Int,
    val sessions: Int,
    val booksRead: Int,
    val finished: Int,
    val activeDays: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val longestSession: Session?,
    val bestDay: DayTotal?,
    val avgPerActiveDaySeconds: Long,
    val firstDay: LocalDate?,
)

fun lifetime(rows: List<ReadingSession>, books: List<Book>, today: LocalDate, zone: ZoneId): Lifetime {
    val sessions = buildSessions(rows)
    val summary = computeSummary(rows, sessions)
    val byDay = Stats.secondsByDay(rows, zone)
    val active = byDay.filterValues { it >= 60L }
    val current = Stats.currentStreak(byDay, today)
    var best: DayTotal? = null
    for ((d, s) in byDay) {
        val b = best
        if (b == null || s > b.seconds) best = DayTotal(d, s)
    }
    return Lifetime(
        seconds = summary.seconds,
        pages = summary.pages,
        sessions = summary.sessions,
        booksRead = summary.books,
        finished = books.count { it.finished },
        activeDays = active.size,
        currentStreak = current,
        longestStreak = max(Stats.longestStreak(byDay), current),
        longestSession = sessions.maxByOrNull { it.seconds },
        bestDay = best,
        avgPerActiveDaySeconds = if (active.isNotEmpty()) (active.values.sum().toDouble() / active.size).roundToLong() else 0L,
        firstDay = byDay.keys.minOrNull(),
    )
}
