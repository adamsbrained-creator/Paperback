package com.paperback.app.catalog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Puts catalog books in the order you are likely to want them, and says why. */
public final class Ranker {
    private Ranker() {}

    public static final class Pick {
        public final CatalogBook book;
        public final String reason;
        public final double score;

        Pick(CatalogBook book, String reason, double score) {
            this.book = book;
            this.reason = reason;
            this.score = score;
        }
    }

    public static List<Pick> rank(List<CatalogBook> candidates, Taste taste, int limit) {
        List<Pick> scored = new ArrayList<Pick>();
        Set<String> seenTitles = new HashSet<String>();
        for (CatalogBook c : candidates) {
            if (c.title == null || c.title.trim().isEmpty()) continue;
            if (taste.owns(c.title)) continue;
            if (taste.dislikesAuthor(c.firstAuthor())) continue;
            if (!seenTitles.add(TitleKey.of(c.title))) continue;
            Pick p = score(c, taste);
            if (p != null) scored.add(p);
        }
        Collections.sort(scored, new Comparator<Pick>() {
            @Override public int compare(Pick a, Pick b) {
                return Double.compare(b.score, a.score);
            }
        });
        // at most two books by the same author, so one favourite does not fill the row
        Map<String, Integer> perAuthor = new HashMap<String, Integer>();
        List<Pick> out = new ArrayList<Pick>();
        for (Pick p : scored) {
            String a = p.book.firstAuthor().toLowerCase(Locale.ROOT);
            int n = perAuthor.containsKey(a) ? perAuthor.get(a) : 0;
            if (!a.isEmpty() && n >= 2) continue;
            perAuthor.put(a, n + 1);
            out.add(p);
            if (out.size() >= limit) break;
        }
        return out;
    }

    static Pick score(CatalogBook c, Taste taste) {
        double subj = 0.0;
        Taste.Signal bestSubject = null;
        double bestSubjectContribution = 0.0;
        List<Double> positives = new ArrayList<Double>();
        for (String s : Subjects.clean(c.subjects, 30)) {
            Taste.Signal sig = taste.subject(s);
            if (sig == null) continue;
            double w = sig.weight;
            if (w > 0) {
                positives.add(w);
                if (w > bestSubjectContribution && !Subjects.isGeneric(s)) {
                    bestSubjectContribution = w;
                    bestSubject = sig;
                }
            } else {
                subj += w; // subjects of books you did not like count against it
            }
        }
        Collections.sort(positives, Collections.reverseOrder());
        for (int i = 0; i < positives.size() && i < 4; i++) subj += positives.get(i) / (1.0 + 0.5 * i);

        double auth = 0.0;
        Taste.Signal authorSig = taste.author(c.firstAuthor());
        if (authorSig != null && authorSig.weight > 0) auth = 1.2 * Math.min(authorSig.weight, 6.0);

        if (subj <= 0.0 && auth <= 0.0) return null; // nothing ties it to what you read

        double pop = 0.25 * Math.log10(1 + c.ratingCount) + 0.2 * Math.log10(1 + c.editions) + 0.15 * Math.log10(1 + c.readers);
        double quality = c.ratingCount >= 5 ? (c.rating - 3.6) * 0.8 : 0.0;
        double cover = c.coverId > 0 ? 0.3 : -0.6;
        double total = subj + auth + pop + quality + cover;

        String reason;
        if (authorSig != null && auth >= bestSubjectContribution * 1.5 && auth > 0) {
            reason = "More by " + c.firstAuthor();
        } else if (bestSubject != null) {
            reason = bestSubject.bestBook >= 2.0 && !bestSubject.because.isEmpty()
                ? "Because you liked " + bestSubject.because
                : "You read a lot of " + bestSubject.name;
        } else if (authorSig != null) {
            reason = "More by " + c.firstAuthor();
        } else {
            reason = "Popular with readers like you";
        }
        return new Pick(c, reason, total);
    }
}
