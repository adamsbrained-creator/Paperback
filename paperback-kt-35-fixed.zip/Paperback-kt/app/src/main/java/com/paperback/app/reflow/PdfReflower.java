package com.paperback.app.reflow;

import android.content.Context;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.io.MemoryUsageSetting;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CancellationException;

/** The whole job: a PDF file in, an EPUB file out. Runs on the calling thread, so call it from a background one. */
public final class PdfReflower {

    public interface Progress {
        /** Called as pages are read. Return false to cancel. */
        boolean update(int page, int total);
    }

    private PdfReflower() {
    }

    /**
     * @param workDir an empty-or-new folder for the pictures taken out of the PDF; deleted when done
     * @param meta    title, author and the rest for the new book; [Meta.author] is filled from the PDF when blank
     * @throws NoTextException    the PDF is a scan, with no text of its own (text recognition can still read it)
     * @throws ReflowException    the PDF can't be reflowed (locked, damaged); the message is fit to show
     * @throws CancellationException if [progress] returned false
     */
    public static void convert(Context context, File pdf, File out, File workDir, EpubWriter.Meta meta, Progress progress)
            throws IOException, ReflowException {
        PDFBoxResourceLoader.init(context.getApplicationContext());
        File images = new File(workDir, "images");
        if (!images.exists() && !images.mkdirs()) throw new IOException("Can't create " + images);
        PDDocument doc = null;
        try {
            try {
                doc = PDDocument.load(pdf, MemoryUsageSetting.setupTempFileOnly());
            } catch (IOException e) {
                if (e.getClass().getSimpleName().contains("InvalidPassword")) {
                    throw new ReflowException("This PDF is password-protected, so it can't be reflowed.");
                }
                throw new ReflowException("Couldn't read this PDF.");
            }
            int total = doc.getNumberOfPages();
            if (total == 0) throw new ReflowException("This PDF has no pages.");

            if (meta.author == null || meta.author.trim().length() == 0) {
                PDDocumentInformation info = doc.getDocumentInformation();
                if (info != null && info.getAuthor() != null) meta.author = info.getAuthor().trim();
            }

            PdfBoxExtractor extractor = new PdfBoxExtractor(images);
            if (looksScanned(doc, extractor, total)) throw new NoTextException();
            Reflow reflow = new Reflow();
            for (int i = 0; i < total; i++) {
                if (progress != null && !progress.update(i, total)) throw new CancellationException("cancelled");
                PageData pd;
                try {
                    pd = extractor.extract(doc, i);
                } catch (IOException e) {
                    pd = new PageData(i, 595f, 842f);   // an unreadable page is left blank
                } catch (RuntimeException e) {
                    pd = new PageData(i, 595f, 842f);
                }
                reflow.addPage(pd);
            }
            if (progress != null && !progress.update(total, total)) throw new CancellationException("cancelled");

            Reflow.Result result = reflow.build();
            EpubWriter.write(result, meta, out);
        } finally {
            if (doc != null) {
                try {
                    doc.close();
                } catch (IOException ignored) {
                }
            }
            deleteTree(workDir);
        }
    }

    /**
     * Looks at a dozen pages spread through the book (text only, without decoding any pictures) and says whether
     * most of them have no text. A scan is found out in a second instead of after decoding every page.
     */
    private static boolean looksScanned(PDDocument doc, PdfBoxExtractor extractor, int total) {
        int samples = Math.min(12, total);
        int withText = 0;
        int looked = 0;
        for (int k = 0; k < samples; k++) {
            int index = Math.min(total - 1, (int) ((k + 0.5) * total / samples));
            try {
                PageData pd = extractor.extract(doc, index, false);
                looked++;
                if (pd.glyphs.size() >= 80) withText++;
            } catch (IOException e) {
                looked++;
            } catch (RuntimeException e) {
                looked++;
            }
        }
        return looked > 0 && withText * 4 < looked;
    }

    /**
     * The other half of the job for a scan: [pages] were read by text recognition (at [dpi] pixels per inch), and
     * this builds the book from them the same way as from a PDF with text.
     *
     * @throws ReflowException nothing readable was found
     */
    public static void convertRecognised(List<OcrPage> pages, float dpi, File out, EpubWriter.Meta meta)
            throws IOException, ReflowException {
        List<PageData> converted = OcrPages.convert(pages, dpi);
        Reflow reflow = new Reflow();
        for (PageData pd : converted) reflow.addPage(pd);
        Reflow.Result result;
        try {
            result = reflow.build();
        } catch (NoTextException e) {
            throw new ReflowException("No text could be read from these pages. The scan may be too faint or too small.");
        }
        EpubWriter.write(result, meta, out);
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }
}
