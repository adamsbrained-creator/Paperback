package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Anchor
import com.paperback.app.data.Period
import com.paperback.app.data.StatNames
import com.paperback.app.data.weekRangeLabel
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate
import java.time.YearMonth

/**
 * Jump to any week, month or year instead of paging one at a time. Week: tap the day the seven days end on.
 * Month: pick a month of a year. Year: pick a year. Dates after today are greyed out.
 */
@Composable
fun PeriodPickerDialog(
    period: Period,
    anchor: Anchor,
    today: LocalDate,
    firstYear: Int,
    onCancel: () -> Unit,
    onOk: (Anchor) -> Unit,
) {
    val t = pbTokens()
    var weekEnd by remember { mutableStateOf(if (anchor.weekEnd.isAfter(today)) today else anchor.weekEnd) }
    var viewMonth by remember { mutableStateOf(YearMonth.from(weekEnd)) }
    var pickMonth by remember { mutableStateOf(anchor.month) }
    var viewYear by remember { mutableIntStateOf(anchor.month.year) }
    var pickYear by remember { mutableIntStateOf(anchor.year) }
    var yearPage by remember { mutableIntStateOf(anchor.year - Math.floorMod(anchor.year - firstYear, 12)) }

    PbDialog(
        title = when (period) {
            Period.Week -> "Pick a week"
            Period.Month -> "Pick a month"
            else -> "Pick a year"
        },
        onDismiss = onCancel,
    ) {
        when (period) {
            Period.Week -> {
                PickerHeader(
                    title = "${StatNames.MONTHS[viewMonth.monthValue - 1]} ${viewMonth.year}",
                    canPrev = true,
                    canNext = viewMonth.isBefore(YearMonth.from(today)),
                    onPrev = { viewMonth = viewMonth.minusMonths(1) },
                    onNext = { viewMonth = viewMonth.plusMonths(1) },
                )
                Row(Modifier.fillMaxWidth()) {
                    for (i in listOf("M", "T", "W", "T", "F", "S", "S")) {
                        Text(i, Modifier.weight(1f), color = t.setSub, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
                Spacer(Modifier.height(4.dp))
                val offset = viewMonth.atDay(1).dayOfWeek.value - 1
                val cells: List<LocalDate?> = List(offset) { null } + (1..viewMonth.lengthOfMonth()).map { viewMonth.atDay(it) }
                val rows = cells.chunked(7)
                val rangeStart = weekEnd.minusDays(6)
                rows.forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        for (col in 0 until 7) {
                            val d = row.getOrNull(col)
                            Box(Modifier.weight(1f).height(40.dp), contentAlignment = Alignment.Center) {
                                if (d != null) {
                                    val future = d.isAfter(today)
                                    val isEdge = d == weekEnd || d == rangeStart
                                    val inRange = !d.isBefore(rangeStart) && !d.isAfter(weekEnd)
                                    Box(
                                        Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    isEdge -> MaterialTheme.colorScheme.primary
                                                    inRange -> MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                                                    else -> Color.Transparent
                                                },
                                            )
                                            .then(if (d == today && !isEdge) Modifier.border(1.5.dp, t.ink, CircleShape) else Modifier)
                                            .alpha(if (future) 0.3f else 1f)
                                            .clickable(enabled = !future) { weekEnd = d },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Text(
                                            "${d.dayOfMonth}",
                                            color = if (isEdge) Color.White else t.ink,
                                            fontSize = 14.sp,
                                            fontWeight = if (isEdge) FontWeight.SemiBold else FontWeight.Normal,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Seven days ending ${weekEnd.dayOfMonth} ${StatNames.MONTHS_SHORT[weekEnd.monthValue - 1]}", color = t.setSub, fontSize = 13.sp)
                Text(weekRangeLabel(weekEnd), color = t.ink, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            }

            Period.Month -> {
                PickerHeader(
                    title = "$viewYear",
                    canPrev = viewYear > firstYear,
                    canNext = viewYear < today.year,
                    onPrev = { viewYear -= 1 },
                    onNext = { viewYear += 1 },
                )
                Spacer(Modifier.height(6.dp))
                (0 until 4).forEach { r ->
                    Row(Modifier.fillMaxWidth().padding3(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (0 until 3).forEach { c ->
                            val m = r * 3 + c + 1
                            val ym = YearMonth.of(viewYear, m)
                            val future = ym.isAfter(YearMonth.from(today))
                            PickCell(
                                text = StatNames.MONTHS_SHORT[m - 1],
                                selected = ym == pickMonth,
                                enabled = !future,
                                modifier = Modifier.weight(1f),
                            ) { pickMonth = ym }
                        }
                    }
                }
            }

            else -> {
                val last = yearPage + 11
                PickerHeader(
                    title = "$yearPage \u2013 $last",
                    canPrev = yearPage > firstYear,
                    canNext = last < today.year,
                    onPrev = { yearPage -= 12 },
                    onNext = { yearPage += 12 },
                )
                Spacer(Modifier.height(6.dp))
                (0 until 4).forEach { r ->
                    Row(Modifier.fillMaxWidth().padding3(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (0 until 3).forEach { c ->
                            val y = yearPage + r * 3 + c
                            PickCell(
                                text = "$y",
                                selected = y == pickYear,
                                enabled = y <= today.year && y >= firstYear,
                                modifier = Modifier.weight(1f),
                            ) { pickYear = y }
                        }
                    }
                }
            }
        }
        PbDialogButtons(
            confirm = "OK",
            onConfirm = {
                onOk(
                    when (period) {
                        Period.Week -> anchor.copy(weekEnd = weekEnd)
                        Period.Month -> anchor.copy(month = pickMonth)
                        else -> anchor.copy(year = pickYear)
                    },
                )
            },
            onCancel = onCancel,
        )
    }
}

private fun Modifier.padding3(): Modifier = this.then(Modifier.padding(vertical = 3.dp))

@Composable
private fun PickerHeader(title: String, canPrev: Boolean, canNext: Boolean, onPrev: () -> Unit, onNext: () -> Unit) {
    val t = pbTokens()
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        ArrowButton(left = true, enabled = canPrev, onClick = onPrev)
        Text(
            title,
            modifier = Modifier.weight(1f),
            color = t.ink,
            fontFamily = PbSerif,
            fontSize = 20.sp,
            fontWeight = FontWeight.Medium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        ArrowButton(left = false, enabled = canNext, onClick = onNext)
    }
}

/** A round previous / next button. Used by the picker and the hero chart's pager. */
@Composable
fun ArrowButton(left: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val t = pbTokens()
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(t.ink.copy(alpha = 0.07f))
            .alpha(if (enabled) 1f else 0.3f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        PbIcon(
            if (left) PbIconName.CaretLeft else PbIconName.CaretRight,
            size = 20.dp,
            tint = t.ink,
            strokeWidth = 2.2f,
            contentDescription = if (left) "Earlier" else "Later",
        )
    }
}

@Composable
private fun PickCell(text: String, selected: Boolean, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = pbTokens()
    Box(
        modifier
            .height(46.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else t.ink.copy(alpha = 0.07f))
            .alpha(if (enabled) 1f else 0.3f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Color.White else t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}
