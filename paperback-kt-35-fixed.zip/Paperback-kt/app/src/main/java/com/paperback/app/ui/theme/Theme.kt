package com.paperback.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

/** Paperback's look: white page, soft grey cards, ink text, coral accent (same values as the TypeScript app). */
val Coral = Color(0xFFF46B4E)

/**
 * The accent colour the user picked (Settings → Appearance). It is app-wide state: anything that reads [color] while
 * drawing is redrawn when it changes. Coral until chosen otherwise.
 */
object Accent {
    var color by mutableStateOf(Coral)

    /** The colour for text and icons that sit on the accent: dark on a light accent, white on a dark one. */
    fun onAccent(c: Color = color): Color = if (c.luminance() > 0.55f) Color(0xFF111111) else Color.White
}

/**
 * Titles use a serif and everything else a sans. The TypeScript app used Newsreader and Outfit; to get
 * them back, drop the .ttf files into app/src/main/res/font/ and point these two at them.
 */
val PbSerif: FontFamily = FontFamily.Serif
val PbSans: FontFamily = FontFamily.SansSerif

private val LightColors = lightColorScheme(
    primary = Coral,
    onPrimary = Color.White,
    secondary = Color(0xFF111111),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF3F3F3),
    onSecondaryContainer = Color(0xFF111111),
    background = Color.White,
    onBackground = Color(0xFF111111),
    surface = Color.White,
    onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFF3F3F3),
    onSurfaceVariant = Color(0xFF6B6B6B),
    outline = Color(0xFFDDDDDD),
)

private val DarkColors = darkColorScheme(
    primary = Coral,
    onPrimary = Color.White,
    secondary = Color(0xFFF5F5F5),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF1F1F1F),
    onSecondaryContainer = Color(0xFFF5F5F5),
    background = Color.Black,
    onBackground = Color(0xFFF5F5F5),
    surface = Color.Black,
    onSurface = Color(0xFFF5F5F5),
    surfaceVariant = Color(0xFF161616),
    onSurfaceVariant = Color(0xFF9A9A9A),
    outline = Color(0xFF2A2A2A),
)

/** True while the dark look is showing (it can differ from the phone's setting: Settings → Appearance). */
val LocalPbDark = staticCompositionLocalOf { false }

/**
 * The extra colours from the TypeScript app's CSS (--pb-*, --set-*, --as-*, --menu-*) that the Material
 * scheme has no slot for. Values are copied from styles/paperback.css.
 */
@Immutable
class PbTokens(
    val bg: Color,
    val card: Color,
    val ink: Color,
    val sub: Color,
    val setSub: Color,
    val rule: Color,
    val goalCard: Color,
    val asTrack: Color,
    val asOn: Color,
    val asOnInk: Color,
    val asEdge: Color,
    val asBadge: Color,
    val asSelBg: Color,
    val asSelInk: Color,
    val menuBg: Color,
    val menuOn: Color,
    val scrim: Color,
)

private val LightTokens = PbTokens(
    bg = Color(0xFFFFFFFF), card = Color(0xFFF3F3F3), ink = Color(0xFF111111), sub = Color(0xFF6B6B6B),
    setSub = Color(0xFF5F5F5F), rule = Color(0xFFE0E0E0), goalCard = Color(0xFF111111),
    asTrack = Color(0xFFE7E7E7), asOn = Color(0xFFFFFFFF), asOnInk = Color(0xFF161616), asEdge = Color(0xFFECECEC),
    asBadge = Color(0xFFF0F0F0), asSelBg = Color(0xFFFDE4DD), asSelInk = Color(0xFFB23A22),
    menuBg = Color(0xFFFFFFFF), menuOn = Color(0xFFF3F3F3), scrim = Color(0x73161616),
)

private val DarkTokens = PbTokens(
    bg = Color(0xFF000000), card = Color(0xFF161616), ink = Color(0xFFF5F5F5), sub = Color(0xFF9A9A9A),
    setSub = Color(0xFF9A9A9A), rule = Color(0xFF2A2A2A), goalCard = Color(0xFF1F1F1F),
    asTrack = Color(0xFF0B0B0B), asOn = Color(0xFF2C2C2C), asOnInk = Color(0xFFF5F5F5), asEdge = Color(0xFF2A2A2A),
    asBadge = Color(0xFF1F1F1F), asSelBg = Color(0x2EF46B4E), asSelInk = Color(0xFFF98A72),
    menuBg = Color(0xFF1C1C1C), menuOn = Color(0xFF2C2C2C), scrim = Color(0x73161616),
)

/** The tokens with the "selected" tint and ink following the accent colour. */
private fun PbTokens.withAccent(accent: Color, dark: Boolean) = PbTokens(
    bg = bg, card = card, ink = ink, sub = sub, setSub = setSub, rule = rule, goalCard = goalCard, asTrack = asTrack,
    asOn = asOn, asOnInk = asOnInk, asEdge = asEdge, asBadge = asBadge,
    asSelBg = accent.copy(alpha = if (dark) 0.18f else 0.14f),
    asSelInk = if (dark) lerp(accent, Color.White, 0.25f) else lerp(accent, Color.Black, 0.35f),
    menuBg = menuBg, menuOn = menuOn, scrim = scrim,
)

@Composable
fun pbTokens(): PbTokens {
    val dark = LocalPbDark.current
    val accent = Accent.color
    return remember(dark, accent) { (if (dark) DarkTokens else LightTokens).withAccent(accent, dark) }
}

@Composable
fun PaperbackTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalPbDark provides dark) {
        val accent = Accent.color
        val scheme = remember(dark, accent) {
            (if (dark) DarkColors else LightColors).copy(primary = accent, onPrimary = Accent.onAccent(accent))
        }
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
