package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.ReadingSession
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

// A book's reading history: one card for each time you read (counted by the reader, the timer, or added by hand).

private val DATE_TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy · HH:mm", Locale.getDefault())

fun entryDate(startMs: Long): String = Instant.ofEpochMilli(startMs).atZone(ZoneId.systemDefault()).format(DATE_TIME)

/** "20 min", "1 h 05 min", "40 s". */
fun entryDuration(seconds: Int): String = when {
    seconds < 60 -> "$seconds s"
    seconds < 3600 -> "${(seconds + 30) / 60} min"
    else -> "${seconds / 3600} h ${((seconds % 3600) / 60).toString().padStart(2, '0')} min"
}

private fun pagesLabel(s: ReadingSession): String = when {
    s.fromPos > 0 && s.toPos >= s.fromPos && s.toPos > s.fromPos -> "Pages ${s.fromPos}–${s.toPos}"
    s.pages > 0 -> "${s.pages} ${if (s.pages == 1) "page" else "pages"}"
    else -> "No pages noted"
}

private fun minPerPage(s: ReadingSession): String? =
    if (s.pages > 0 && s.seconds > 0) "%.1f min/page".format(s.seconds / 60.0 / s.pages) else null

@Composable
fun EntryCard(entry: ReadingSession, onClick: () -> Unit) {
    val t = pbTokens()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(entryDate(entry.startMs), color = t.setSub, fontSize = 13.sp, modifier = Modifier.weight(1f))
            minPerPage(entry)?.let { Text(it, color = t.setSub, fontSize = 13.sp) }
        }
        Text(
            if (entry.manual) "Set by you" else "Counted automatically",
            color = if (entry.manual) MaterialTheme.colorScheme.primary else t.setSub,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 2.dp),
        )
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(pagesLabel(entry), color = t.ink, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            if (entry.pages > 0) {
                Text(
                    "+ ${entry.pages}",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(entryDuration(entry.seconds), color = t.ink, fontSize = 14.sp)
    }
}

/** The history block of the book page: how many entries and your pace, then the entries, newest first. */
@Composable
fun ReadingHistory(entries: List<ReadingSession>, onEdit: (ReadingSession) -> Unit) {
    val t = pbTokens()
    var all by remember { mutableStateOf(false) }
    val sorted = remember(entries) { entries.filter { it.seconds > 0 || it.pages > 0 }.sortedByDescending { it.startMs } }
    if (sorted.isEmpty()) {
        Text(
            "No entries yet. Reading in Paperback is counted for you. Set a timer or add an entry to use your own time and pages instead, or for paper books and other apps.",
            color = t.setSub,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        return
    }
    val pages = sorted.sumOf { it.pages }
    val seconds = sorted.sumOf { it.seconds.toLong() }
    val pace = if (pages > 0 && seconds > 0) "  ·  ~%.1f min/page".format(seconds / 60.0 / pages) else ""
    Text(
        "${sorted.size} ${if (sorted.size == 1) "entry" else "entries"}$pace",
        color = t.setSub,
        fontSize = 14.sp,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
    )
    Spacer(Modifier.height(10.dp))
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        (if (all) sorted else sorted.take(5)).forEach { e -> EntryCard(e) { onEdit(e) } }
    }
    if (sorted.size > 5) {
        Text(
            if (all) "Show fewer" else "Show all ${sorted.size}",
            color = MaterialTheme.colorScheme.primary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(12.dp)).clickable { all = !all }.padding(horizontal = 4.dp, vertical = 8.dp),
        )
    }
}

/** Two buttons side by side: the timer and a hand-made entry. */
@Composable
fun ReadingActions(timerRunning: Boolean, onTimer: () -> Unit, onAdd: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.weight(1f)) { PbButton(if (timerRunning) "Timer running" else "Timer", onClick = onTimer) }
        Box(Modifier.weight(1f)) { PbButton("Add entry", onClick = onAdd, ghost = true) }
    }
}
