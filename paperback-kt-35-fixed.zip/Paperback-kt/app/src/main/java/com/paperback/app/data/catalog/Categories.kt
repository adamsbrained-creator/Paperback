package com.paperback.app.data.catalog

/** A genre tile on the search page. [slug] is Open Library's subject page name. */
class Category(val name: String, val slug: String)

object Categories {
    val all: List<Category> = listOf(
        Category("Fantasy", "fantasy"),
        Category("Science fiction", "science_fiction"),
        Category("Mystery", "mystery_and_detective_stories"),
        Category("Thriller", "thriller"),
        Category("Romance", "romance"),
        Category("Historical fiction", "historical_fiction"),
        Category("Horror", "horror"),
        Category("Classics", "classic_literature"),
        Category("Young adult", "young_adult_fiction"),
        Category("Biography", "biography"),
        Category("History", "history"),
        Category("Science", "science"),
        Category("Philosophy", "philosophy"),
        Category("Psychology", "psychology"),
        Category("Business", "business"),
        Category("Self-help", "self-help"),
        Category("Poetry", "poetry"),
        Category("Humor", "humor"),
        Category("Travel", "travel"),
        Category("Art", "art"),
    )

    fun bySlug(slug: String): Category? = all.firstOrNull { it.slug == slug }
}
