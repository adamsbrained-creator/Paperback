package com.paperback.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The reading timer. It is one stopwatch for one book at a time, with an optional target ("30 minutes").
 * It works from clock times (when it started, what was counted before), so it keeps counting while the
 * screen is off or Paperback is closed, and it is remembered across restarts.
 */
data class TimerState(
    val bookId: String = "",
    /** Wanted reading time in seconds, 0 = no target. */
    val targetSec: Int = 0,
    /** Milliseconds counted before the current run. */
    val countedMs: Long = 0L,
    /** When the current run began (clock time), 0 = paused or not started. */
    val runningSince: Long = 0L,
) {
    val running: Boolean get() = runningSince > 0L
    val active: Boolean get() = bookId.isNotEmpty() && (running || countedMs > 0L)
    fun elapsedMs(now: Long): Long = countedMs + if (running) (now - runningSince).coerceAtLeast(0L) else 0L
}

class ReadingTimer(context: Context) {
    private val sp = context.getSharedPreferences("timer", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(
        TimerState(
            bookId = sp.getString("bookId", "").orEmpty(),
            targetSec = sp.getInt("target", 0),
            countedMs = sp.getLong("counted", 0L),
            runningSince = sp.getLong("since", 0L),
        ),
    )
    val state: StateFlow<TimerState> = _state.asStateFlow()

    private fun set(s: TimerState) {
        _state.value = s
        sp.edit()
            .putString("bookId", s.bookId)
            .putInt("target", s.targetSec)
            .putLong("counted", s.countedMs)
            .putLong("since", s.runningSince)
            .apply()
    }

    /** Points the timer at [bookId] if it is not counting anything for another book. Returns false when it is. */
    fun use(bookId: String): Boolean {
        val s = _state.value
        if (s.bookId == bookId) return true
        if (s.active) return false
        set(TimerState(bookId = bookId, targetSec = s.targetSec))
        return true
    }

    fun start(now: Long) {
        val s = _state.value
        if (s.bookId.isNotEmpty() && !s.running) set(s.copy(runningSince = now))
    }

    fun pause(now: Long) {
        val s = _state.value
        if (s.running) set(s.copy(countedMs = s.elapsedMs(now), runningSince = 0L))
    }

    fun reset() {
        val s = _state.value
        set(TimerState(bookId = s.bookId, targetSec = s.targetSec))
    }

    /** After the entry is saved: forget the book too. */
    fun clear() = set(TimerState())

    fun setTarget(seconds: Int) {
        set(_state.value.copy(targetSec = seconds.coerceIn(0, 24 * 3600)))
    }
}
