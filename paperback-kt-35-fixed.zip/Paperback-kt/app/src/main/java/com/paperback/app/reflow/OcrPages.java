package com.paperback.app.reflow;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Turns what text recognition found on scanned pages into the same [PageData] a PDF with real text gives, so the
 * rest of the conversion (paragraphs, headings, headers and footers, footnotes) works unchanged.
 *
 * Recognition gives words and boxes but not fonts. Sizes are worked out from the height of each line, then lines
 * of nearly the usual height are set to exactly the usual height, so the small differences that come from which
 * letters happen to be on a line don't look like different font sizes.
 */
public final class OcrPages {
    private OcrPages() {
    }

    /** Words that have no letter or digit in them but are still real text. */
    private static final String KEEP_SYMBOLS = "—–-&§*•†‡¶";

    /**
     * @param pages the recognised pages, in reading order
     * @param dpi   how many pixels per inch the pictures had; only sets the scale of the sizes
     */
    public static List<PageData> convert(List<OcrPage> pages, float dpi) {
        float pt = 72f / Math.max(50f, dpi);
        List<List<Prepared>> prepared = new ArrayList<List<Prepared>>();
        for (OcrPage p : pages) {
            List<Prepared> ps = new ArrayList<Prepared>();
            float tilt = pageTilt(p);
            for (OcrLine l : p.lines) {
                Prepared pr = prepare(l, tilt, p.width);
                if (pr != null) ps.add(pr);
            }
            dropMarginNumbers(p, ps);
            prepared.add(ps);
        }
        float[] usual = usualHeights(prepared);

        List<PageData> out = new ArrayList<PageData>();
        for (int i = 0; i < pages.size(); i++) {
            OcrPage p = pages.get(i);
            float ppt = p.dpi > 0 ? 72f / p.dpi : pt;
            PageData pd = new PageData(i, p.width * ppt, p.height * ppt);
            List<Prepared> ordered = new ArrayList<Prepared>(prepared.get(i));
            Collections.sort(ordered, new Comparator<Prepared>() {
                @Override
                public int compare(Prepared a, Prepared b) {
                    return Float.compare(a.baseline, b.baseline);
                }
            });
            float pitch = linePitch(ordered);
            for (int li = 0; li < ordered.size(); li++) {
                Prepared pr = ordered.get(li);
                float h = pr.height;
                if (usual[i] > 0) {
                    if (Math.abs(h - usual[i]) <= SNAP * usual[i]) {
                        h = usual[i];
                    } else if (pr.words.size() < 4 && h >= 0.85f * usual[i] && h <= 1.28f * usual[i]) {
                        // one or two words (the end of a paragraph): a tail on a letter can fool the baseline, and a
                        // heading would be clearly bigger than this
                        h = usual[i];
                    } else if (pr.words.size() >= 8 && h >= 0.85f * usual[i] && h <= 1.3f * usual[i]) {
                        // a long line of ordinary text with one oversized box in it (a blot, a bracket)
                        h = usual[i];
                    } else if (pr.words.size() < 4 && h > 1.28f * usual[i] && h <= 1.7f * usual[i] && li > 0
                            && ordered.get(li - 1).words.size() >= 4 && pitch > 0
                            && pr.baseline - ordered.get(li - 1).baseline <= 1.6f * pitch) {
                        // the same, when it follows a line of text closely, as the last line of a paragraph does
                        h = usual[i];
                    }
                }
                float size = Math.max(1f, h * ppt);
                float baseline = pr.baseline * ppt;
                Glyph prev = null;
                for (OcrWord w : pr.words) {
                    float x = w.left * ppt;
                    float wd = Math.max(0.1f, w.width() * ppt);
                    if (prev != null) {
                        float gx = prev.x + prev.w;
                        pd.glyphs.add(new Glyph(" ", gx, baseline, Math.max(0.1f, x - gx), size, false, false));
                    }
                    Glyph g = new Glyph(w.text, x, baseline, wd, size, false, false);
                    pd.glyphs.add(g);
                    prev = g;
                }
            }
            out.add(pd);
        }
        return out;
    }

    /** The tallest letters rise about three quarters of the font size above the baseline. */
    private static final float RISE_TO_SIZE = 1.33f;
    private static final float SNAP = 0.14f;

    private static final class Prepared {
        final List<OcrWord> words = new ArrayList<OcrWord>();
        float height;
        float baseline;
    }

    private static Prepared prepare(OcrLine line, float pageTilt, int pageWidth) {
        Prepared pr = new Prepared();
        // each long line is levelled by its own slope when that is close to the page's (pages are rarely flat)
        float tilt = pageTilt;
        float own = lineTilt(line, pageWidth);
        if (!Float.isNaN(own) && Math.abs(own - pageTilt) <= 0.02f) tilt = own;
        double mid = 0;
        int cnt = 0;
        for (OcrWord w : line.words) {
            if (w == null || w.width() <= 0) continue;
            mid += 0.5 * (w.left + w.right);
            cnt++;
        }
        mid = cnt == 0 ? 0 : mid / cnt;
        for (OcrWord w : line.words) {
            if (w == null || w.text == null) continue;
            String t = w.text.trim();
            if (t.length() == 0 || w.width() <= 0 || w.height() <= 0) continue;
            if (!hasLetterOrDigit(t) && !(t.length() <= 2 && KEEP_SYMBOLS.indexOf(t.charAt(0)) >= 0)) continue;
            // a crooked scan: lines run uphill or downhill, so every word is moved back level
            int lift = Math.round((float) (tilt * (0.5 * (w.left + w.right) - mid)));
            pr.words.add(new OcrWord(t, w.left, w.top - lift, w.right, w.bottom - lift));
        }
        if (pr.words.isEmpty()) return null;

        int n = pr.words.size();
        float[] bottoms = new float[n];
        for (int i = 0; i < n; i++) {
            bottoms[i] = pr.words.get(i).bottom;
        }
        java.util.Arrays.sort(bottoms);
        // The baseline: words without a tail below the line end on it, so look at the higher end of the bottoms.
        pr.baseline = bottoms[(int) Math.floor(0.15f * (n - 1))];
        // The size comes from how far the tall letters rise above the baseline. Nearly every line has some, and unlike
        // the whole box this doesn't depend on whether a g or a y happens to be on the line. The tops of the highest
        // fifth of the words are skipped, because one blot or accent can stretch a single word's box.
        float[] rises = new float[n];
        for (int i = 0; i < n; i++) rises[i] = pr.baseline - pr.words.get(i).top;
        java.util.Arrays.sort(rises);
        float rise = rises[n - 1 - n / 5];
        pr.height = Math.max(1f, rise) * RISE_TO_SIZE;
        return pr;
    }

    /**
     * Some editions print the page numbers of an older edition in the margin, level with a line of text. They would
     * be glued onto that line, so numbers standing clear of the text block on the right (or the left) are dropped.
     */
    private static void dropMarginNumbers(OcrPage page, List<Prepared> lines) {
        List<Float> rights = new ArrayList<Float>();
        List<Float> lefts = new ArrayList<Float>();
        for (Prepared pr : lines) {
            if (pr.words.size() < 4) continue;
            rights.add((float) pr.words.get(pr.words.size() - 1).right);
            lefts.add((float) pr.words.get(0).left);
        }
        if (rights.size() < 8) return;
        Collections.sort(rights);
        Collections.sort(lefts);
        float right = rights.get((int) (0.9f * (rights.size() - 1)));
        float left = lefts.get((int) (0.1f * (lefts.size() - 1)));
        float em = 0.9f * medianHeight(lines);
        for (int i = lines.size() - 1; i >= 0; i--) {
            Prepared pr = lines.get(i);
            for (int k = pr.words.size() - 1; k >= 0; k--) {
                OcrWord w = pr.words.get(k);
                if (!isNumber(w.text)) continue;
                boolean farRight = w.left > right + 0.8f * em && k == pr.words.size() - 1;
                boolean farLeft = w.right < left - 0.8f * em && k == 0;
                if (farRight || farLeft) pr.words.remove(k);   // (a page number at the foot sits inside the text block)
            }
            if (pr.words.isEmpty()) lines.remove(i);
        }
    }

    /**
     * The usual line height of each page. Every page's own middle value is taken, then middle values that are within
     * 5% of each other are made one, so a book with the same type on every page gets one size, and a book with two
     * sizes of type (small print up front, larger in the main text) keeps both.
     */
    private static float[] usualHeights(List<List<Prepared>> prepared) {
        int n = prepared.size();
        float[] own = new float[n];
        List<Float> all = new ArrayList<Float>();
        for (int i = 0; i < n; i++) {
            List<Prepared> ps = prepared.get(i);
            if (ps.size() < 5) continue;
            own[i] = medianHeight(ps);
            all.add(own[i]);
        }
        float[] out = new float[n];
        if (all.isEmpty()) return out;
        Collections.sort(all);
        List<float[]> clusters = new ArrayList<float[]>();   // {value, pages}
        int start = 0;
        while (start < all.size()) {
            int end = start;
            while (end < all.size() && all.get(end) <= 1.05f * all.get(start)) end++;
            clusters.add(new float[]{all.get(start + (end - start) / 2), end - start});
            start = end;
        }
        float[] common = clusters.get(0);
        for (float[] c : clusters) if (c[1] > common[1]) common = c;
        for (int i = 0; i < n; i++) {
            if (own[i] <= 0) {
                out[i] = common[0];
                continue;
            }
            float best = own[i];
            float bestDist = Float.MAX_VALUE;
            for (float[] c : clusters) {
                float d = Math.abs(c[0] - own[i]);
                if (d < bestDist) {
                    bestDist = d;
                    best = c[0];
                }
            }
            out[i] = bestDist <= 0.06f * own[i] ? best : own[i];
        }
        return out;
    }

    /**
     * How much the lines of a scanned page run downhill (positive) or uphill, as rise over run. Found from the
     * long lines: each one gets a straight line fitted through its words, and the middle value of those is taken.
     */
    private static float pageTilt(OcrPage page) {
        List<Float> slopes = new ArrayList<Float>();
        for (OcrLine l : page.lines) {
            float t = lineTilt(l, page.width);
            if (!Float.isNaN(t)) slopes.add(t);
        }
        if (slopes.size() < 5) return 0f;
        Collections.sort(slopes);
        float m = slopes.get(slopes.size() / 2);
        if (Math.abs(m) < 0.002f || Math.abs(m) > 0.1f) return 0f;
        return m;
    }

    /** The slope of one long line of text (rise over run), or NaN if it has too few words to tell. */
    private static float lineTilt(OcrLine l, int pageWidth) {
        if (l.words.size() < 6) return Float.NaN;
        double sx = 0, sy = 0, sxx = 0, sxy = 0;
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE;
        int used = 0;
        for (OcrWord w : l.words) {
            if (w == null || w.width() <= 0) continue;
            double x = 0.5 * (w.left + w.right);
            double y = 0.5 * (w.top + w.bottom);
            sx += x;
            sy += y;
            sxx += x * x;
            sxy += x * y;
            used++;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
        }
        if (used < 6 || maxX - minX < 0.4 * pageWidth) return Float.NaN;
        double den = used * sxx - sx * sx;
        if (den <= 0) return Float.NaN;
        return (float) ((used * sxy - sx * sy) / den);
    }

    /** The usual distance between two neighbouring lines of text on a page. */
    private static float linePitch(List<Prepared> sorted) {
        List<Float> d = new ArrayList<Float>();
        for (int i = 1; i < sorted.size(); i++) {
            Prepared a = sorted.get(i - 1);
            Prepared b = sorted.get(i);
            if (a.words.size() < 4 || b.words.size() < 4) continue;
            float gap = b.baseline - a.baseline;
            if (gap > 0.5f * a.height) d.add(gap);
        }
        if (d.size() < 3) return 0f;
        Collections.sort(d);
        return d.get(d.size() / 2);
    }

    private static float medianHeight(List<Prepared> lines) {
        List<Float> hs = new ArrayList<Float>();
        for (Prepared pr : lines) hs.add(pr.height);
        Collections.sort(hs);
        return hs.isEmpty() ? 10f : hs.get(hs.size() / 2);
    }

    private static boolean isNumber(String t) {
        if (t.length() == 0 || t.length() > 4) return false;
        for (int i = 0; i < t.length(); i++) if (!Character.isDigit(t.charAt(i))) return false;
        return true;
    }

    private static boolean hasLetterOrDigit(String t) {
        for (int i = 0; i < t.length(); i++) if (Character.isLetterOrDigit(t.charAt(i))) return true;
        return false;
    }
}
