package com.paperback.app.data.catalog

import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.Ranker
import com.paperback.app.catalog.Taste
import com.paperback.app.catalog.TasteBook
import com.paperback.app.data.AppPrefs
import com.paperback.app.data.Book
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Something that is loading, has loaded, or could not be loaded. */
sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    class Ready<T>(val value: T) : Load<T>
    class Failed(val message: String) : Load<Nothing>
}

/** A page of catalog books for the "see all" screen; [reasons] (book id -> why) is filled for "For you". */
class CatalogList(val title: String, val books: List<CatalogBook>, val reasons: Map<String, String> = emptyMap())

/**
 * Everything behind the online side of Search: trending books, recommendations built from your own library,
 * category lists, catalog search and book details. Lives in the view model so what has been loaded survives
 * leaving the page. Nothing is fetched while the online catalog is switched off.
 */
class CatalogController(
    private val scope: CoroutineScope,
    private val api: CatalogApi,
    private val prefs: AppPrefs,
    private val library: () -> List<Book>,
) {
    val enabled: StateFlow<Boolean> = prefs.catalogOnline
    fun setEnabled(on: Boolean) = prefs.setCatalogOnline(on)

    private val _trending = MutableStateFlow<Load<List<CatalogBook>>>(Load.Loading)
    val trending: StateFlow<Load<List<CatalogBook>>> = _trending.asStateFlow()

    private val _forYou = MutableStateFlow<Load<List<Ranker.Pick>>>(Load.Loading)
    val forYou: StateFlow<Load<List<Ranker.Pick>>> = _forYou.asStateFlow()

    /** The reason for each recommended book, by id, for the book page and the "see all" list. */
    private val reasons = ConcurrentHashMap<String, String>()

    /** Books seen on any screen, so a book page can open from just its id. */
    private val known = ConcurrentHashMap<String, CatalogBook>()

    private val gate = Semaphore(2)
    private var trendingAt = 0L
    private var forYouAt = 0L
    private var forYouSignature = ""
    private var job: Job? = null

    fun find(id: String): CatalogBook? = known[id]
    fun reasonFor(id: String): String? = reasons[id]

    fun remember(list: List<CatalogBook>) {
        for (b in list) known.putIfAbsent(b.id, b)
    }

    private suspend fun <T> online(block: () -> T): T = withContext(Dispatchers.IO) { gate.withPermit { block() } }

    private fun message(e: Exception): String =
        if (e is java.io.IOException) "Couldn't reach the online catalog. Check your connection and try again."
        else "The online catalog sent something Paperback couldn't read."

    /** Loads what the search page shows (once an hour, or again when your taste changed). Safe to call often. */
    fun refresh(force: Boolean = false) {
        if (!enabled.value) return
        val now = System.currentTimeMillis()
        val taste = tasteOf(library())
        val sig = taste.signature()
        val trendingStale = force || _trending.value !is Load.Ready || now - trendingAt > HOUR
        val forYouStale = force || _forYou.value !is Load.Ready || sig != forYouSignature || now - forYouAt > 6 * HOUR
        if (!trendingStale && !forYouStale) return
        if (job?.isActive == true && !force) return
        job?.cancel()
        job = scope.launch {
            if (trendingStale) {
                if (_trending.value !is Load.Ready) _trending.value = Load.Loading
                try {
                    val list = online { api.trending() }
                    remember(list)
                    _trending.value = Load.Ready(list)
                    trendingAt = System.currentTimeMillis()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (_trending.value !is Load.Ready) _trending.value = Load.Failed(message(e))
                }
            }
            if (forYouStale) loadForYou(taste, sig)
        }
    }

    private suspend fun loadForYou(taste: Taste, sig: String) {
        if (taste.isEmpty()) {
            _forYou.value = Load.Ready(emptyList())
            forYouSignature = sig
            return
        }
        if (_forYou.value !is Load.Ready) _forYou.value = Load.Loading
        try {
            val candidates = ArrayList<CatalogBook>()
            var failures = 0
            val queries: List<() -> List<CatalogBook>> =
                taste.likedSubjects(3).map { s -> { api.bySubject(s.name, 20) } } +
                    taste.likedAuthors(2).map { a -> { api.byAuthor(a.name, 12) } }
            for (q in queries) {
                try {
                    candidates += online { q() }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failures++
                }
            }
            if (candidates.isEmpty() && failures > 0) {
                if (_forYou.value !is Load.Ready) _forYou.value = Load.Failed("Couldn't reach the online catalog. Check your connection and try again.")
                return
            }
            val picks = Ranker.rank(candidates, taste, 20)
            remember(picks.map { it.book })
            for (p in picks) reasons[p.book.id] = p.reason
            _forYou.value = Load.Ready(picks)
            forYouSignature = sig
            forYouAt = System.currentTimeMillis()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (_forYou.value !is Load.Ready) _forYou.value = Load.Failed(message(e))
        }
    }

    // ---- one-off requests for screens ---------------------------------------------------------------

    suspend fun search(query: String): Result<List<CatalogBook>> = attempt {
        online { api.search(query.trim(), 20) }.also { remember(it) }
    }

    suspend fun details(book: CatalogBook): Result<CatalogDetails> = attempt { online { api.details(book) } }

    /** Books for the "see all" page. [kind] is "trending", "foryou", "cat" (value = subject slug), "subject" or "author". */
    suspend fun list(kind: String, value: String): Result<CatalogList> = attempt {
        when (kind) {
            "trending" -> {
                val have = trending.value
                val l = if (have is Load.Ready) have.value else online { api.trending() }.also { remember(it) }
                CatalogList("Trending this week", l)
            }
            "foryou" -> {
                val have = forYou.value
                val picks = if (have is Load.Ready) have.value else emptyList()
                CatalogList("For you", picks.map { it.book }, picks.associate { it.book.id to it.reason })
            }
            "cat" -> {
                val cat = Categories.bySlug(value)
                val name = cat?.name ?: value
                var l = online { api.subject(value, 40) }
                if (l.isEmpty()) l = online { api.bySubject(name, 40) }
                remember(l)
                CatalogList(name, l)
            }
            "author" -> CatalogList(value, online { api.byAuthor(value, 40) }.also { remember(it) })
            else -> CatalogList(value, online { api.bySubject(value, 40) }.also { remember(it) })
        }
    }

    private suspend fun <T> attempt(block: suspend () -> T): Result<T> =
        try {
            Result.success(block())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(IllegalStateException(message(e)))
        }

    companion object {
        private const val HOUR = 3_600_000L

        fun tasteOf(books: List<Book>): Taste = Taste.of(
            books.map {
                TasteBook(it.title, it.author, it.tags, it.rating, it.progress.toDouble(), it.finished, it.favorite)
            },
        )
    }
}
