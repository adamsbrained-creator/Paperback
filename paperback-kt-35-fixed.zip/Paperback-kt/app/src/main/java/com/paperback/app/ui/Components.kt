package com.paperback.app.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.layout
import com.paperback.app.ui.theme.pbTokens
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.ui.theme.PbSerif
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private object CoverCache {
    private val cache = LruCache<String, ImageBitmap>(40)

    fun peek(path: String?): ImageBitmap? = path?.let { cache.get(it) }

    fun load(path: String?): ImageBitmap? {
        if (path == null) return null
        cache.get(path)?.let { return it }
        val bmp = BitmapFactory.decodeFile(path)?.asImageBitmap() ?: return null
        cache.put(path, bmp)
        return bmp
    }
}

@Composable
fun BookCover(book: Book, modifier: Modifier = Modifier) {
    val bitmap by produceState(initialValue = CoverCache.peek(book.coverPath), book.coverPath) {
        value = withContext(Dispatchers.IO) { CoverCache.load(book.coverPath) }
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .aspectRatio(2f / 3f)
            .shadow(6.dp, shape)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val b = bitmap
        if (b != null) {
            Image(bitmap = b, contentDescription = book.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(
                book.title,
                modifier = Modifier.padding(10.dp),
                fontFamily = PbSerif,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                maxLines = 5,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun ProgressTrack(fraction: Float, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.outline),
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.primary),
        )
    }
}

@Composable
fun Eyebrow(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier,
        color = pbTokens().setSub,
        fontSize = 12.sp,
        letterSpacing = 0.14.em,
        fontWeight = FontWeight.Medium,
    )
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .background(pbTokens().card)
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Column {
            Text(label, color = pbTokens().setSub, fontSize = 13.sp)
            Text(value, fontFamily = PbSerif, fontSize = 26.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ---- tab icons drawn by hand (no icon-pack dependency) ---------------------------------------

@Composable
fun LibraryGlyph(color: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val gap = this.size.width * 0.12f
        val s = (this.size.width - gap * 3) / 2f
        val r = CornerRadius(s * 0.22f)
        for (row in 0..1) for (col in 0..1) {
            drawRoundRect(color, Offset(gap + col * (s + gap), gap + row * (s + gap)), Size(s, s), r)
        }
    }
}

@Composable
fun StatsGlyph(color: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val bar = w * 0.22f
        val r = CornerRadius(bar / 2)
        listOf(0.45f, 0.8f, 0.6f).forEachIndexed { i, frac ->
            val left = w * 0.1f + i * (bar + w * 0.12f)
            drawRoundRect(color, Offset(left, h * (0.9f - frac * 0.8f)), Size(bar, h * frac * 0.8f), r)
        }
    }
}

@Composable
fun BookmarkGlyph(filled: Boolean, color: Color, size: Dp = 22.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val path = Path().apply {
            moveTo(w * 0.24f, h * 0.10f)
            lineTo(w * 0.76f, h * 0.10f)
            lineTo(w * 0.76f, h * 0.90f)
            lineTo(w * 0.50f, h * 0.68f)
            lineTo(w * 0.24f, h * 0.90f)
            close()
        }
        if (filled) drawPath(path, color)
        else drawPath(path, color, style = Stroke(width = w * 0.09f, join = StrokeJoin.Round))
    }
}

@Composable
fun ListGlyph(color: Color, size: Dp = 22.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val thick = h * 0.1f
        val r = CornerRadius(thick / 2)
        listOf(0.25f, 0.5f, 0.75f).forEach { y ->
            drawRoundRect(color, Offset(w * 0.15f, h * y - thick / 2), Size(w * 0.7f, thick), r)
        }
    }
}

/** A rounded on/off chip: coral when on, the card colour when off. Give it `Modifier.weight(1f)` to share a row evenly. */
@Composable
fun TogglePill(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = pbTokens()
    Box(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else t.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else t.ink,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
        )
    }
}

/**
 * Lets a row of content run to both screen edges even though its parent has horizontal padding: the content is
 * measured [by] wider on each side and moved back. Give the row `contentPadding` of the same size so the first and
 * last items still line up with the page margin.
 */
fun Modifier.fullBleed(by: androidx.compose.ui.unit.Dp): Modifier = this.layout { measurable, constraints ->
    val extra = by.roundToPx()
    val width = if (constraints.hasBoundedWidth) constraints.maxWidth + extra * 2 else constraints.maxWidth
    val placeable = measurable.measure(constraints.copy(minWidth = width, maxWidth = width))
    layout(constraints.maxWidth.coerceAtMost(placeable.width), placeable.height) {
        placeable.place(-extra, 0)
    }
}

/** Today's reading against the daily goal: a small ring and "8 of 30 min". Same card as the other Home tiles. */
@Composable
fun GoalRingTile(secondsToday: Long, goalMinutes: Int, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val minutes = (secondsToday / 60L).toInt()
    val fraction = (secondsToday / 60f / goalMinutes.coerceAtLeast(1)).coerceIn(0f, 1f)
    val coral = MaterialTheme.colorScheme.primary
    Row(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .background(t.card)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(46.dp)) {
                val stroke = 6.dp.toPx()
                val inset = stroke / 2f
                val arc = Size(size.width - stroke, size.height - stroke)
                drawArc(t.rule, 0f, 360f, false, topLeft = Offset(inset, inset), size = arc, style = Stroke(width = stroke))
                if (fraction > 0f) {
                    drawArc(coral, -90f, 360f * fraction, false, topLeft = Offset(inset, inset), size = arc, style = Stroke(width = stroke, cap = StrokeCap.Round))
                } else {
                    drawCircle(coral, radius = stroke / 2f, center = Offset(size.width / 2f, inset))
                }
            }
            Text("${Math.round(fraction * 100f)}", color = t.ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Column {
            Text("Daily goal", color = t.setSub, fontSize = 13.sp)
            Text("$minutes of $goalMinutes min", color = t.ink, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        }
    }
}
