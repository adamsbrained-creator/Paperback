package com.paperback.app.data

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.paperback.app.reflow.OcrLine
import com.paperback.app.reflow.OcrPage
import com.paperback.app.reflow.OcrWord
import com.paperback.app.reflow.Spread
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Reads a scanned PDF (pages that are pictures) with Google's on-device text recognition, so it can be reflowed.
 * Each PDF page is drawn at about 230 dpi. A page that is two book pages side by side (a scanned spread) is cut at
 * the fold and each half is read on its own. Nothing leaves the phone.
 */
object ReflowOcr {
    private const val DPI = 230f
    private const val MAX_SIDE = 3400f

    /**
     * @param onProgress (pages done, total pages)
     * @return the recognised pages in reading order, or null if the PDF can't be opened
     */
    suspend fun read(pdf: File, onProgress: (Int, Int) -> Unit): List<OcrPage>? {
        val doc = PdfDoc.open(pdf) ?: return null
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val total = doc.pageCount
            val out = ArrayList<OcrPage>(total * 2)
            for (i in 0 until total) {
                coroutineContext.ensureActive()
                onProgress(i, total)
                val (wPt, hPt) = doc.pageSize(i)
                var scale = DPI / 72f
                val longest = maxOf(wPt, hPt) * scale
                if (longest > MAX_SIDE) scale *= MAX_SIDE / longest
                val bmp = doc.render(i, (wPt * scale).toInt().coerceAtLeast(1), (hPt * scale).toInt().coerceAtLeast(1))
                val dpi = scale * 72f
                try {
                    for (half in halves(bmp)) {
                        coroutineContext.ensureActive()
                        try {
                            out.add(recognise(recognizer, half, dpi))
                        } finally {
                            if (half !== bmp) half.recycle()
                        }
                    }
                } finally {
                    bmp.recycle()
                }
            }
            onProgress(total, total)
            return out
        } finally {
            recognizer.close()
            doc.close()
        }
    }

    /** The page as it is, or its two halves if it is a spread (wide, with an empty strip down the middle). */
    private fun halves(bmp: Bitmap): List<Bitmap> {
        if (bmp.width < bmp.height * 1.2f) return listOf(bmp)
        val cut = gutter(bmp)
        if (cut <= 0 || cut >= bmp.width) return listOf(bmp)
        return listOf(
            Bitmap.createBitmap(bmp, 0, 0, cut, bmp.height),
            Bitmap.createBitmap(bmp, cut, 0, bmp.width - cut, bmp.height),
        )
    }

    /** Where to cut a spread, in pixels of [bmp], or -1. Works on a shrunken copy: it only needs to find the empty strip. */
    private fun gutter(bmp: Bitmap): Int {
        val step = 6
        val w = (bmp.width / step).coerceAtLeast(1)
        val h = (bmp.height / step).coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(bmp, w, h, true)
        try {
            val px = IntArray(w * h)
            small.getPixels(px, 0, w, 0, 0, w, h)
            val ink = IntArray(w)
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    val p = px[row + x]
                    val lum = (Color.red(p) * 3 + Color.green(p) * 6 + Color.blue(p)) / 10
                    if (lum < 200) ink[x]++
                }
            }
            val cut = Spread.findGutter(ink)
            return if (cut < 0) -1 else (cut * (bmp.width.toFloat() / w)).toInt()
        } finally {
            if (small !== bmp) small.recycle()
        }
    }

    private suspend fun recognise(recognizer: TextRecognizer, bmp: Bitmap, dpi: Float): OcrPage {
        val text = suspendCancellableCoroutine<Text> { cont ->
            recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resumeWithException(it) }
        }
        val page = OcrPage(bmp.width, bmp.height)
        page.dpi = dpi
        for (block in text.textBlocks) {
            for (line in block.lines) {
                val words = line.elements.mapNotNull { e ->
                    val r = e.boundingBox ?: return@mapNotNull null
                    OcrWord(e.text, r.left, r.top, r.right, r.bottom)
                }.sortedBy { it.left }
                if (words.isEmpty()) continue
                val l = OcrLine()
                words.forEach { l.add(it) }
                page.lines.add(l)
            }
        }
        return page
    }
}
