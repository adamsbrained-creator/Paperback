package com.paperback.app.catalog;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Keeps the reader's own counting and what you set yourself (timer, hand-made entries) from adding up twice.
 * A "span" is one reading session: a book, when it started, when it ended, and whether you set it yourself.
 * Where a span you set overlaps a span the reader counted for the same book, yours wins and the counted one is
 * left out of the stats (it stays stored, so deleting your entry brings it back).
 */
public final class Coverage {
    /** The reader flushes a bit before or after a timer starts and stops, so overlaps get this much slack. */
    public static final long SLACK_MS = 60_000L;

    private Coverage() {}

    public static final class Span {
        public final long id;
        public final String bookId;
        public final long startMs;
        public final long endMs;
        public final boolean manual;
        public final int fromPos;
        public final int toPos;

        public Span(long id, String bookId, long startMs, long endMs, boolean manual, int fromPos, int toPos) {
            this.id = id;
            this.bookId = bookId;
            this.startMs = startMs;
            this.endMs = Math.max(endMs, startMs);
            this.manual = manual;
            this.fromPos = fromPos;
            this.toPos = toPos;
        }
    }

    private static boolean overlaps(Span auto, String bookId, long startMs, long endMs) {
        if (!auto.bookId.equals(bookId)) return false;
        return auto.startMs < endMs + SLACK_MS && auto.endMs > startMs - SLACK_MS;
    }

    /** Ids of the reader-counted spans that one of your own spans for the same book takes over. */
    public static Set<Long> covered(List<Span> spans) {
        Set<Long> out = new HashSet<>();
        for (Span m : spans) {
            if (!m.manual) continue;
            for (Span a : spans) {
                if (a.manual || out.contains(a.id)) continue;
                if (overlaps(a, m.bookId, m.startMs, m.endMs)) out.add(a.id);
            }
        }
        return out;
    }

    /**
     * The first and last page the reader counted for [bookId] between [startMs] and [endMs], as {from, to},
     * or null when it counted none. {@code ignoreId} is an entry of yours that is being edited.
     */
    public static int[] pagesCounted(List<Span> spans, String bookId, long startMs, long endMs, long ignoreId) {
        int from = Integer.MAX_VALUE;
        int to = 0;
        long end = Math.max(endMs, startMs);
        List<Span> hit = new ArrayList<>();
        for (Span a : spans) {
            if (a.manual || a.id == ignoreId) continue;
            if (overlaps(a, bookId, startMs, end)) hit.add(a);
        }
        for (Span a : hit) {
            if (a.fromPos > 0 && a.toPos > a.fromPos) {
                from = Math.min(from, a.fromPos);
                to = Math.max(to, a.toPos);
            }
        }
        if (to <= 0 || from == Integer.MAX_VALUE) return null;
        return new int[] {from, to};
    }
}
