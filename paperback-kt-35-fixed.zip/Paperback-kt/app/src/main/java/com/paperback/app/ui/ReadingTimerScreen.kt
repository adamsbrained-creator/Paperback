package com.paperback.app.ui

import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.data.Book
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingTimer
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import kotlinx.coroutines.delay

private fun clock(totalSeconds: Long): String {
    val s = totalSeconds.coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

private val PRESETS = listOf(15, 30, 60)

/**
 * The reading timer for one book: counts up, with an optional target. It keeps counting with the screen off.
 * [otherTitle] is set when the timer is busy with a different book.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReadingTimerScreen(
    book: Book,
    timer: ReadingTimer,
    otherTitle: String?,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onFinish: (seconds: Int, startMs: Long) -> Unit,
    onOpenOther: () -> Unit,
) {
    val t = pbTokens()
    val st by timer.state.collectAsStateWithLifecycle()
    LaunchedEffect(book.id) { timer.use(book.id) }

    val mine = st.bookId == book.id
    val now by produceState(System.currentTimeMillis(), st.running, st.countedMs) {
        value = System.currentTimeMillis()
        while (st.running) {
            delay(250)
            value = System.currentTimeMillis()
        }
    }
    val elapsedSec = if (mine) st.elapsedMs(now) / 1000 else 0L
    val target = st.targetSec

    // keep the screen on while it counts, and buzz once when the target is reached (while this page is open)
    val view = LocalView.current
    DisposableEffect(st.running) {
        view.keepScreenOn = st.running
        onDispose { view.keepScreenOn = false }
    }
    val context = LocalContext.current
    LaunchedEffect(st.running, st.runningSince, target) {
        if (mine && st.running && target > 0) {
            val left = target * 1000L - st.elapsedMs(System.currentTimeMillis())
            if (left > 0) {
                delay(left)
                runCatching {
                    context.getSystemService(Vibrator::class.java)
                        ?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1))
                }
            }
        }
    }

    var custom by remember { mutableStateOf(false) }

    PbPage("Reading timer", headerSize, onMenu, onSearch, headerGap = 8.dp) {
        Text(book.title, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = t.setSub, fontSize = 15.sp, maxLines = 1)

        if (otherTitle != null && !mine) {
            Spacer(Modifier.height(24.dp))
            NoteCard(
                "The timer is counting your reading of “$otherTitle”. Finish or reset that one first.",
                title = "Timer in use",
                action = "Go to it",
                onAction = onOpenOther,
            )
            return@PbPage
        }

        Spacer(Modifier.height(40.dp))
        Text(
            clock(elapsedSec),
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            color = t.ink,
            fontSize = 56.sp,
            fontWeight = FontWeight.SemiBold,
            style = androidx.compose.ui.text.TextStyle(fontFeatureSettings = "tnum"),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            when {
                target <= 0 -> if (st.running) "Counting" else if (elapsedSec > 0) "Paused" else "No time limit"
                elapsedSec >= target -> "Time’s up · +${entryDuration((elapsedSec - target).toInt())}"
                else -> "${entryDuration((target - elapsedSec).toInt())} left of ${entryDuration(target)}"
            },
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            color = if (target > 0 && elapsedSec >= target) androidx.compose.material3.MaterialTheme.colorScheme.primary else t.setSub,
            fontSize = 15.sp,
        )

        Spacer(Modifier.height(28.dp))
        FlowRow(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            PRESETS.forEach { m ->
                TogglePill("$m min", target == m * 60) { timer.setTarget(if (target == m * 60) 0 else m * 60) }
            }
            val isCustom = target > 0 && target / 60 !in PRESETS || (target > 0 && target % 60 != 0)
            TogglePill(if (isCustom) "${target / 60} min" else "Custom", isCustom) { custom = true }
        }
        Text(
            "Tap the chosen time again for no limit.",
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            textAlign = TextAlign.Center,
            color = t.setSub,
            fontSize = 12.sp,
        )

        Spacer(Modifier.height(28.dp))
        PbButton(
            when {
                st.running -> "Pause"
                elapsedSec > 0 -> "Resume"
                else -> "Start"
            },
            onClick = { if (st.running) timer.pause(System.currentTimeMillis()) else timer.start(System.currentTimeMillis()) },
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { PbButton("Reset", onClick = { timer.reset() }, ghost = true, enabled = elapsedSec > 0) }
            Box(Modifier.weight(1f)) {
                PbButton(
                    "Finish & save",
                    onClick = {
                        val end = System.currentTimeMillis()
                        val ms = st.elapsedMs(end)
                        timer.pause(end)
                        onFinish((ms / 1000).toInt(), end - ms)
                    },
                    ghost = true,
                    enabled = elapsedSec > 0,
                )
            }
        }

        Spacer(Modifier.height(28.dp))
        Text(
            "Reading inside Paperback is counted for you, so you don’t need this for that. Use the timer for paper books or other apps. When you save a timer, its time and pages replace what the reader counted for this book in the same minutes, so nothing is counted twice. The timer keeps counting when the screen is off; the buzz at the end only works while this page is open.",
            color = t.setSub,
            fontSize = 13.sp,
            lineHeight = 19.sp,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }

    if (custom) {
        var text by remember { mutableStateOf(if (target > 0) (target / 60).toString() else "") }
        PbDialog("Timer length", onDismiss = { custom = false }) {
            PbField(
                value = text,
                onValueChange = { v -> text = v.filter { it.isDigit() }.take(3) },
                placeholder = "Minutes",
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
            PbDialogButtons(
                confirm = "Set",
                onConfirm = {
                    timer.setTarget((text.toIntOrNull() ?: 0) * 60)
                    custom = false
                },
                onCancel = { custom = false },
                danger = false,
            )
        }
    }
}
