package com.paperback.app.reflow;

/** Finds the fold between the two pages of a scanned two-page spread. */
public final class Spread {
    private Spread() {
    }

    /**
     * @param ink how many dark pixels each pixel column of the (possibly shrunken) picture has
     * @return the column where the picture should be cut in two, or -1 if it looks like a single page
     */
    public static int findGutter(int[] ink) {
        int n = ink.length;
        if (n < 40) return -1;
        int win = Math.max(1, n / 100);
        float[] s = smooth(ink, win);

        int lo = (int) (0.36f * n);
        int hi = (int) (0.64f * n);
        float min = Float.MAX_VALUE;
        for (int i = lo; i <= hi; i++) if (s[i] < min) min = s[i];

        // how much ink a column of text normally has: the average over the columns that have any, on both sides
        double sum = 0;
        int cnt = 0;
        for (int i = (int) (0.08f * n); i < (int) (0.92f * n); i++) {
            if (i >= lo && i <= hi) continue;
            if (s[i] > 0) {
                sum += s[i];
                cnt++;
            }
        }
        if (cnt < n / 10) return -1;
        float typical = (float) (sum / cnt);
        if (typical <= 0) return -1;
        if (min > 0.12f * typical) return -1;      // no clear empty strip: one page

        // the longest strip of (nearly) empty columns in the middle, cut through its centre
        float limit = min + 0.04f * typical;
        int bestStart = -1;
        int bestLen = 0;
        int i = lo;
        while (i <= hi) {
            if (s[i] <= limit) {
                int j = i;
                while (j <= hi && s[j] <= limit) j++;
                if (j - i > bestLen) {
                    bestLen = j - i;
                    bestStart = i;
                }
                i = j;
            } else {
                i++;
            }
        }
        if (bestStart < 0 || bestLen < Math.max(2, n / 60)) return -1;
        int cut = bestStart + bestLen / 2;

        // both halves must have something on them, or it is one page with a wide margin
        long left = 0;
        long right = 0;
        for (int k = 0; k < n; k++) {
            if (k < cut) left += ink[k];
            else right += ink[k];
        }
        long total = left + right;
        if (total <= 0) return -1;
        if (left < 0.04 * total || right < 0.04 * total) {
            // a spread with a blank page (as in book scans) still counts; the cut is the same
            if (bestLen < n / 12) return -1;
        }
        return cut;
    }

    private static float[] smooth(int[] a, int win) {
        int n = a.length;
        float[] out = new float[n];
        long run = 0;
        int half = win / 2;
        long[] pre = new long[n + 1];
        for (int i = 0; i < n; i++) pre[i + 1] = pre[i] + a[i];
        for (int i = 0; i < n; i++) {
            int from = Math.max(0, i - half);
            int to = Math.min(n, i - half + win);
            if (to <= from) to = Math.min(n, from + 1);
            run = pre[to] - pre[from];
            out[i] = (float) run / (to - from);
        }
        return out;
    }
}
