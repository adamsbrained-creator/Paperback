package com.paperback.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.layout
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.ui.theme.Accent
import com.paperback.app.ui.theme.LocalPbDark
import com.paperback.app.ui.theme.pbTokens

// Books standing on wooden shelves: each book is a spine (title running down it) and a row of spines stands on a plank.

val SPINE_COLORS = listOf(
    Color(0xFF1B2347), // navy
    Color(0xFF2A4B7C), // steel blue
    Color(0xFFD62F3A), // red
    Color(0xFF3B82F6), // bright blue
    Color(0xFFF6B93B), // amber
    Color(0xFFF2C4A0), // peach
    Color(0xFF2E7D5B), // green
    Color(0xFF6B3FA0), // plum
    Color(0xFF1F8A8A), // teal
    Color(0xFF3A3A3C), // charcoal
    Color(0xFF8C3B2F), // brick
    Color(0xFFE8D9B5), // cream
)

private class SpineLook(val bg: Color, val ink: Color, val w: Dp, val h: Dp)

/** A book's spine is always the same: colour and height come from its id, width from its length. */
private fun spineLook(book: Book): SpineLook {
    val r = book.id.hashCode() and 0x7fffffff
    // a colour you chose wins; otherwise one comes from the id
    val bg = if (book.spineColor != 0) Color(book.spineColor) else SPINE_COLORS[r % SPINE_COLORS.size]
    val ink = if (bg.luminance() > 0.5f) Color(0xFF1A1A1A) else Color.White
    val pages = book.pageCount
    val w = ((if (pages > 0) 28 + pages / 22 else 40) + (r / 7) % 8).coerceIn(34, 58)
    val h = 146 + (r / 13) % 34
    return SpineLook(bg, ink, w.dp, h.dp)
}

fun spineWidth(book: Book): Dp = spineLook(book).w

private val GAP = 5.dp
private val LEAN_SPACE = 14.dp

/** Splits [books] into shelves that each fit in [width]. */
fun packShelves(books: List<Book>, width: Dp, leanId: String? = null): List<List<Book>> {
    val rows = ArrayList<List<Book>>()
    var cur = ArrayList<Book>()
    var used = 0f
    for (b in books) {
        val w = spineWidth(b).value + if (b.id == leanId) LEAN_SPACE.value else 0f
        val need = if (cur.isEmpty()) w else used + GAP.value + w
        if (cur.isNotEmpty() && need > width.value) {
            rows.add(cur)
            cur = arrayListOf(b)
            used = w
        } else {
            cur.add(b)
            used = need
        }
    }
    if (cur.isNotEmpty()) rows.add(cur)
    return rows
}

/** Text turned a quarter turn clockwise so it reads down the spine. */
private fun Modifier.vertical(): Modifier = layout { measurable, constraints ->
    val p = measurable.measure(Constraints(maxWidth = constraints.maxHeight))
    layout(p.height, p.width) {
        p.placeWithLayer(p.height, 0) {
            rotationZ = 90f
            transformOrigin = TransformOrigin(0f, 0f)
        }
    }
}

@Composable
private fun VerticalText(text: String, color: Color, size: TextUnit, weight: FontWeight, lines: Int, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.vertical(),
        color = color,
        fontSize = size,
        lineHeight = size * 1.15f,
        fontWeight = weight,
        maxLines = lines,
        overflow = TextOverflow.Ellipsis,
    )
}

/** One book standing up. [lean] tips it over onto the next book (used for the book being read now). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Spine(
    book: Book,
    modifier: Modifier = Modifier,
    lean: Boolean = false,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
) {
    val look = remember(book.id, book.pageCount, book.spineColor) { spineLook(book) }
    val accent = Accent.color
    Box(
        modifier
            .width(look.w)
            .height(look.h)
            .graphicsLayer {
                if (lean) {
                    rotationZ = 8f
                    transformOrigin = TransformOrigin(1f, 1f)
                }
            }
            .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
            .background(look.bg)
            .drawBehind {
                // a little light on the left edge and shade on the right, and two thin bands near the top
                drawRect(
                    Brush.horizontalGradient(
                        0f to Color.White.copy(alpha = 0.16f),
                        0.3f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.22f),
                    ),
                )
                val band = look.ink.copy(alpha = 0.22f)
                drawRect(band, Offset(0f, 15.dp.toPx()), Size(size.width, 1.dp.toPx()))
                drawRect(band, Offset(0f, 18.dp.toPx()), Size(size.width, 1.dp.toPx()))
            }
            .semantics(mergeDescendants = true) {
                contentDescription = if (book.author.isBlank()) book.title else "${book.title}, ${book.author}"
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        val wide = look.w >= 50.dp
        val hasAuthor = book.author.isNotBlank()
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 26.dp, bottom = if (hasAuthor) 64.dp else 14.dp)
                .fillMaxHeight(),
            contentAlignment = Alignment.TopCenter,
        ) {
            VerticalText(book.title, look.ink, if (wide) 15.sp else 14.sp, FontWeight.SemiBold, if (wide) 2 else 1)
        }
        if (hasAuthor) {
            VerticalText(
                book.author,
                look.ink.copy(alpha = 0.78f),
                9.sp,
                FontWeight.Normal,
                1,
                Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp).heightIn(max = 46.dp),
            )
        }
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 3.dp)
                .size(7.dp)
                .border(1.5.dp, look.ink.copy(alpha = 0.7f), CircleShape),
        )
        if (book.isReading) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(book.progress.coerceIn(0.04f, 1f))
                    .height(4.dp)
                    .background(accent),
            )
        }
    }
}

/** The plank the books stand on: oak with a lit top edge and a few lines of grain. */
@Composable
fun Plank(modifier: Modifier = Modifier) {
    val dark = LocalPbDark.current
    val top = if (dark) Color(0xFF8A6A40) else Color(0xFFDDB06A)
    val bottom = if (dark) Color(0xFF5E4527) else Color(0xFFBC8A47)
    val grain = if (dark) Color(0x33000000) else Color(0x40774A1A)
    Box(
        modifier
            .fillMaxWidth()
            .height(13.dp)
            .shadow(5.dp, RoundedCornerShape(2.dp), ambientColor = Color.Black, spotColor = Color.Black)
            .clip(RoundedCornerShape(2.dp))
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .drawBehind {
                drawRect(Color.White.copy(alpha = 0.35f), Offset.Zero, Size(size.width, 1.dp.toPx()))
                drawRect(Color.Black.copy(alpha = 0.25f), Offset(0f, size.height - 1.dp.toPx()), Size(size.width, 1.dp.toPx()))
                // grain: a few long, slightly wavy lines
                val seeds = listOf(0.30f to 0.0f, 0.55f to 0.35f, 0.75f to 0.7f)
                seeds.forEachIndexed { i, (y, phase) ->
                    val path = Path()
                    val yy = size.height * y
                    path.moveTo(0f, yy)
                    var x = 0f
                    val step = size.width / 6f
                    var up = (i % 2 == 0)
                    while (x < size.width) {
                        val nx = x + step * (0.8f + phase * 0.5f)
                        path.quadraticTo((x + nx) / 2f, yy + (if (up) -1.5f else 1.5f) * density, nx, yy)
                        up = !up
                        x = nx
                    }
                    drawPath(path, grain, style = Stroke(width = 1.dp.toPx()))
                }
            },
    )
}

/**
 * One shelf: the [books] standing on a plank. [menu] adds a long-press menu to every spine.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShelfRow(
    books: List<Book>,
    leanId: String?,
    onClick: (Book) -> Unit,
    modifier: Modifier = Modifier,
    menu: (@Composable ColumnScope.(Book, () -> Unit) -> Unit)? = null,
) {
    var menuId by remember { mutableStateOf<String?>(null) }
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(GAP),
            verticalAlignment = Alignment.Bottom,
        ) {
            books.forEach { b ->
                val lean = b.id == leanId
                Box(Modifier.padding(end = if (lean) LEAN_SPACE else 0.dp)) {
                    Spine(
                        b,
                        lean = lean,
                        onClick = { onClick(b) },
                        onLongClick = if (menu != null) ({ menuId = b.id }) else null,
                    )
                    if (menu != null && menuId == b.id) {
                        DropdownMenu(
                            expanded = true,
                            onDismissRequest = { menuId = null },
                            shape = RoundedCornerShape(22.dp),
                            containerColor = pbTokens().menuBg,
                            tonalElevation = 0.dp,
                            shadowElevation = 12.dp,
                        ) { menu.invoke(this, b) { menuId = null } }
                    }
                }
            }
        }
        Plank()
    }
}

/**
 * Books on shelves that wrap to the width available, at most [maxRows] of them (all of them if null).
 * For Home, where a shelf or two shows what is recent or recommended.
 */
@Composable
fun BookShelf(
    books: List<Book>,
    leanId: String?,
    onClick: (Book) -> Unit,
    modifier: Modifier = Modifier,
    maxRows: Int? = null,
) {
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val rows = remember(books, maxWidth, leanId) {
            packShelves(books, maxWidth - 4.dp, leanId).let { if (maxRows != null) it.take(maxRows) else it }
        }
        Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
            rows.forEach { ShelfRow(it, leanId, onClick) }
        }
    }
}
