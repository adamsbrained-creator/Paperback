package com.paperback.app.catalog;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Cleaning of the "subject" lists that catalogs attach to books. */
public final class Subjects {
    private Subjects() {}

    private static final String[] JUNK = {
        "accessible book", "protected daisy", "in library", "lending library", "overdrive", "large type",
        "open library", "internet archive", "reading level", "long now", "nyt:", "new york times",
        "bestseller", "award", "specimens", "series:", "collection", "translations into", "fiction, general",
        "english language", "american literature", "english literature", "literature", "texts", "popular works",
        "reference", "study and teaching", "ebook", "e-book", "audiobook", "juvenile literature",
    };

    /** Subjects too broad to say anything about taste. They count, but little. */
    private static final Set<String> GENERIC = new LinkedHashSet<String>();
    static {
        for (String s : new String[] {"fiction", "nonfiction", "non-fiction", "general", "history", "novel", "novels",
            "biography", "science", "social science", "art", "adult", "juvenile fiction", "life", "man-woman relationships"}) {
            GENERIC.add(s);
        }
    }

    public static boolean isJunk(String subject) {
        if (subject == null) return true;
        String s = subject.trim().toLowerCase(Locale.ROOT);
        if (s.length() < 3 || s.length() > 40) return true;
        if (s.indexOf(':') >= 0 && !s.startsWith("subject")) return true;
        int digits = 0;
        for (int i = 0; i < s.length(); i++) if (Character.isDigit(s.charAt(i))) digits++;
        if (digits * 3 > s.length()) return true;
        for (String j : JUNK) if (s.contains(j)) return true;
        return false;
    }

    public static boolean isGeneric(String subject) {
        return subject != null && GENERIC.contains(subject.trim().toLowerCase(Locale.ROOT));
    }

    /** Lower-cased key for comparing subjects. */
    public static String key(String subject) {
        return subject == null ? "" : subject.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    /** The useful subjects of a book, in their own spelling, each once, at most [max]. */
    public static List<String> clean(List<String> raw, int max) {
        List<String> out = new ArrayList<String>();
        Set<String> seen = new LinkedHashSet<String>();
        if (raw == null) return out;
        for (String s : raw) {
            if (isJunk(s)) continue;
            String k = key(s);
            if (!seen.add(k)) continue;
            String t = s.trim();
            out.add(Character.toUpperCase(t.charAt(0)) + t.substring(1));
            if (out.size() >= max) break;
        }
        return out;
    }
}
