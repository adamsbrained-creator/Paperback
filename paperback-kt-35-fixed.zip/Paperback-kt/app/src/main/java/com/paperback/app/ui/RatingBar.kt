package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.catalog.RatingMath
import com.paperback.app.ui.theme.pbTokens
import kotlin.math.cos
import kotlin.math.sin

/**
 * Five stars you can slide a finger over. The stars fill smoothly while you drag and the rating snaps to the
 * step you chose (whole, half or quarter) on a 5 or 10 scale; it is saved when the finger lifts. Tap the rating
 * you already have to clear it, or slide to the far left.
 * [rating10] is the rating on a 0..10 scale; [onRate] gets the same scale.
 */
@Composable
fun RatingBar(
    rating10: Float,
    scale: Int,
    perUnit: Int,
    onRate: (Double) -> Unit,
    modifier: Modifier = Modifier,
    starSize: Dp = 26.dp,
    gap: Dp = 5.dp,
) {
    val t = pbTokens()
    val accent = MaterialTheme.colorScheme.primary
    val haptic = LocalHapticFeedback.current
    val rate by rememberUpdatedState(onRate)
    val current by rememberUpdatedState(rating10)
    var live by remember { mutableStateOf<Double?>(null) }
    val shown = live ?: rating10.toDouble()
    val barWidth = starSize * 5 + gap * 4

    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Canvas(
            Modifier
                .width(barWidth)
                .height(44.dp)
                .pointerInput(scale, perUnit, starSize, gap) {
                    val s = starSize.toPx()
                    val g = gap.toPx()
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        down.consume()
                        val start = current.toDouble()
                        var last = RatingMath.fromTouch(down.position.x.toDouble(), s.toDouble(), g.toDouble(), scale, perUnit)
                        var moved = false
                        live = last
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        drag(down.id) { pointer ->
                            pointer.consume()
                            val v = RatingMath.fromTouch(pointer.position.x.toDouble(), s.toDouble(), g.toDouble(), scale, perUnit)
                            if (v != last) {
                                last = v
                                moved = true
                                live = v
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                        }
                        // a tap on the rating you already have takes it away
                        val result = if (!moved && last == start && start > 0.0) 0.0 else last
                        live = result
                        if (result != start) rate(result)
                        live = null
                    }
                },
        ) {
            val s = starSize.toPx()
            val g = gap.toPx()
            val star = starPath(s)
            val filledStars = RatingMath.stars(shown)
            val outline = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            val top = (size.height - s) / 2f
            for (i in 0 until 5) {
                val left = i * (s + g)
                val f = (filledStars - i).coerceIn(0.0, 1.0).toFloat()
                translate(left, top) {
                    if (f > 0f) {
                        clipRect(left = 0f, top = 0f, right = s * f, bottom = s) {
                            drawPath(star, accent, style = Fill)
                        }
                    }
                    drawPath(star, accent, style = outline)
                }
            }
        }
        Spacer(Modifier.width(12.dp))
        Row(Modifier.widthIn(min = 60.dp), verticalAlignment = Alignment.Bottom) {
            if (shown > 0.0) {
                Text(RatingMath.format(shown, scale), color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text(" / $scale", color = t.setSub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 3.dp))
            } else {
                Text("Rate it", color = t.setSub, fontSize = 14.sp)
            }
        }
    }
}

/** A five-point star that fits a square of [size] px. */
private fun starPath(size: Float): Path {
    val r = size / 2f
    val inner = r * 0.46f
    val path = Path()
    for (i in 0 until 10) {
        val radius = if (i % 2 == 0) r else inner
        val angle = Math.toRadians(-90.0 + i * 36.0)
        val x = r + (radius * cos(angle)).toFloat()
        val y = r + 0.06f * size + (radius * sin(angle)).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}
