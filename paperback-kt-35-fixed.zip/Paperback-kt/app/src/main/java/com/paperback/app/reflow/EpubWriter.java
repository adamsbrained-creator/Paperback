package com.paperback.app.reflow;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Writes a {@link Reflow.Result} as an EPUB 3 file. The output is the same for the same input (fixed dates), so
 * converting the same PDF twice gives the same file and the library's duplicate check can tell.
 */
public final class EpubWriter {

    public static final class Meta {
        public String title = "Untitled";
        public String author = "";
        public String language = "en";
        public String identifier = "paperback";
        /** A JPEG of the cover, or null. */
        public File cover;
    }

    private static final Charset UTF8 = Charset.forName("UTF-8");

    private EpubWriter() {
    }

    public static void write(Reflow.Result r, Meta meta, File out) throws IOException {
        String lang = r.language != null ? r.language : meta.language;
        if (lang == null || lang.trim().length() == 0) lang = "en";

        // file names
        int n = 1;
        for (Reflow.Section s : r.sections) {
            s.file = String.format("text/c%03d.xhtml", n++);
        }
        Map<String, String> imageNames = new LinkedHashMap<String, String>();
        Map<String, File> imageFiles = new HashMap<String, File>();
        int imageNo = 1;
        for (Reflow.Section s : r.sections) {
            for (Block b : s.blocks) {
                if (b.kind != Block.IMAGE || b.image == null) continue;
                String key = b.image.key;
                if (!imageNames.containsKey(key)) {
                    String ext = extensionOf(b.image.file);
                    imageNames.put(key, "images/i" + (imageNo++) + "." + ext);
                    imageFiles.put(key, b.image.file);
                }
            }
        }

        File tmp = new File(out.getPath() + ".part");
        ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)));
        try {
            zip.setLevel(6);
            long fixed = new GregorianCalendar(2000, 0, 1, 0, 0, 0).getTimeInMillis();

            // the mimetype entry comes first and is stored, not compressed
            byte[] mime = "application/epub+zip".getBytes(UTF8);
            ZipEntry me = new ZipEntry("mimetype");
            me.setMethod(ZipEntry.STORED);
            me.setSize(mime.length);
            me.setCompressedSize(mime.length);
            CRC32 crc = new CRC32();
            crc.update(mime);
            me.setCrc(crc.getValue());
            me.setTime(fixed);
            zip.putNextEntry(me);
            zip.write(mime);
            zip.closeEntry();

            putText(zip, "META-INF/container.xml", fixed,
                    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                            + "<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\">\n"
                            + "  <rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles>\n"
                            + "</container>\n");

            putText(zip, "OEBPS/style.css", fixed, CSS);

            int headingsSeen = 0;
            for (Reflow.Section s : r.sections) {
                putText(zip, "OEBPS/" + s.file, fixed, sectionXhtml(s, meta, lang, imageNames));
            }

            for (Map.Entry<String, String> e : imageNames.entrySet()) {
                putFile(zip, "OEBPS/" + e.getValue(), fixed, imageFiles.get(e.getKey()));
            }
            String coverName = null;
            if (meta.cover != null && meta.cover.exists()) {
                coverName = "images/cover.jpg";
                putFile(zip, "OEBPS/" + coverName, fixed, meta.cover);
            }

            putText(zip, "OEBPS/nav.xhtml", fixed, navXhtml(r, meta, lang));
            putText(zip, "OEBPS/content.opf", fixed, opf(r, meta, lang, imageNames, coverName));
        } finally {
            try {
                zip.close();
            } catch (IOException ignored) {
            }
        }
        if (out.exists() && !out.delete()) throw new IOException("Can't replace " + out);
        if (!tmp.renameTo(out)) throw new IOException("Can't write " + out);
    }

    // ---------------------------------------------------------------------------------------------

    private static final String CSS =
            "body { margin: 0; line-height: 1.45; }\n"
                    + "h1, h2, h3, h4 { font-weight: bold; line-height: 1.25; margin: 1.6em 0 0.6em; page-break-after: avoid; break-after: avoid; }\n"
                    + "h1 { font-size: 1.6em; }\n"
                    + "h2 { font-size: 1.3em; }\n"
                    + "h3 { font-size: 1.15em; }\n"
                    + "h4 { font-size: 1em; }\n"
                    + "p { margin: 0 0 0.85em; }\n"
                    + "p.note { font-size: 0.85em; margin: 0 0 0.5em; opacity: 0.85; }\n"
                    + "hr { border: 0; height: 1.2em; margin: 1.2em 0; text-align: center; }\n"
                    + "hr:after { content: \"* * *\"; letter-spacing: 0.3em; }\n"
                    + "ul { margin: 0 0 0.85em; padding-left: 1.4em; }\n"
                    + "li { margin: 0 0 0.3em; }\n"
                    + ".img { text-align: center; margin: 1em 0; }\n"
                    + "img { max-width: 100%; height: auto; }\n";

    private static String sectionXhtml(Reflow.Section s, Meta meta, String lang, Map<String, String> imageNames) {
        StringBuilder b = new StringBuilder(8192);
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        b.append("<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\" lang=\"")
                .append(esc(lang)).append("\" xml:lang=\"").append(esc(lang)).append("\">\n");
        b.append("<head><meta charset=\"utf-8\"/><title>").append(esc(meta.title))
                .append("</title><link rel=\"stylesheet\" type=\"text/css\" href=\"../style.css\"/></head>\n<body>\n");
        boolean inList = false;
        for (Block blk : s.blocks) {
            if (blk.kind != Block.BULLET && inList) {
                b.append("</ul>\n");
                inList = false;
            }
            switch (blk.kind) {
                case Block.HEADING: {
                    int lv = Math.max(1, Math.min(4, blk.level));
                    b.append("<h").append(lv).append(" id=\"").append(blk.id).append("\">");
                    appendRuns(b, blk.runs, false);
                    b.append("</h").append(lv).append(">\n");
                    break;
                }
                case Block.PARA:
                    b.append("<p>");
                    appendRuns(b, blk.runs, true);
                    b.append("</p>\n");
                    break;
                case Block.NOTE:
                    b.append("<p class=\"note\">");
                    appendRuns(b, blk.runs, true);
                    b.append("</p>\n");
                    break;
                case Block.BULLET:
                    if (!inList) {
                        b.append("<ul>\n");
                        inList = true;
                    }
                    b.append("<li>");
                    appendRuns(b, blk.runs, true);
                    b.append("</li>\n");
                    break;
                case Block.RULE:
                    b.append("<hr/>\n");
                    break;
                case Block.IMAGE: {
                    String name = blk.image == null ? null : imageNames.get(blk.image.key);
                    if (name != null) {
                        b.append("<div class=\"img\"><img src=\"../").append(name).append("\" alt=\"\"/></div>\n");
                    }
                    break;
                }
                default:
                    break;
            }
        }
        if (inList) b.append("</ul>\n");
        b.append("</body>\n</html>\n");
        return b.toString();
    }

    private static void appendRuns(StringBuilder b, List<Run> runs, boolean styled) {
        // trim the ends of the paragraph
        for (int i = 0; i < runs.size(); i++) {
            Run r = runs.get(i);
            String t = r.text;
            if (i == 0) t = ltrim(t);
            if (i == runs.size() - 1) t = rtrim(t);
            if (t.length() == 0) continue;
            boolean em = styled && r.italic;
            boolean strong = styled && r.bold;
            boolean sup = styled && r.sup;
            if (strong) b.append("<strong>");
            if (em) b.append("<em>");
            if (sup) b.append("<sup>");
            b.append(esc(t));
            if (sup) b.append("</sup>");
            if (em) b.append("</em>");
            if (strong) b.append("</strong>");
        }
    }

    private static String navXhtml(Reflow.Result r, Meta meta, String lang) {
        StringBuilder b = new StringBuilder();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        b.append("<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\" lang=\"")
                .append(esc(lang)).append("\" xml:lang=\"").append(esc(lang)).append("\">\n");
        b.append("<head><meta charset=\"utf-8\"/><title>Contents</title></head>\n<body>\n");
        b.append("<nav epub:type=\"toc\" id=\"toc\"><h1>Contents</h1>\n");
        appendNav(b, r.nav);
        b.append("</nav>\n</body>\n</html>\n");
        return b.toString();
    }

    private static void appendNav(StringBuilder b, List<Reflow.NavEntry> list) {
        b.append("<ol>\n");
        for (Reflow.NavEntry e : list) {
            b.append("<li><a href=\"").append(e.section.file);
            if (e.anchor != null) b.append('#').append(e.anchor);
            b.append("\">").append(esc(e.title.length() == 0 ? "Untitled" : e.title)).append("</a>");
            if (!e.children.isEmpty()) {
                b.append('\n');
                appendNav(b, e.children);
            }
            b.append("</li>\n");
        }
        b.append("</ol>\n");
    }

    private static String opf(Reflow.Result r, Meta meta, String lang, Map<String, String> imageNames, String coverName) {
        StringBuilder b = new StringBuilder();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        b.append("<package xmlns=\"http://www.idpf.org/2007/opf\" version=\"3.0\" unique-identifier=\"bookid\" xml:lang=\"")
                .append(esc(lang)).append("\">\n");
        b.append("<metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\">\n");
        b.append("<dc:identifier id=\"bookid\">").append(esc(meta.identifier)).append("</dc:identifier>\n");
        b.append("<dc:title>").append(esc(meta.title)).append("</dc:title>\n");
        b.append("<dc:language>").append(esc(lang)).append("</dc:language>\n");
        if (meta.author != null && meta.author.trim().length() > 0) {
            b.append("<dc:creator>").append(esc(meta.author.trim())).append("</dc:creator>\n");
        }
        b.append("<meta property=\"dcterms:modified\">2000-01-01T00:00:00Z</meta>\n");
        if (coverName != null) b.append("<meta name=\"cover\" content=\"cover-image\"/>\n");
        b.append("</metadata>\n<manifest>\n");
        b.append("<item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/>\n");
        b.append("<item id=\"css\" href=\"style.css\" media-type=\"text/css\"/>\n");
        int i = 1;
        for (Reflow.Section s : r.sections) {
            b.append("<item id=\"s").append(i++).append("\" href=\"").append(s.file).append("\" media-type=\"application/xhtml+xml\"/>\n");
        }
        int k = 1;
        for (String name : imageNames.values()) {
            b.append("<item id=\"img").append(k++).append("\" href=\"").append(name).append("\" media-type=\"")
                    .append(mediaType(name)).append("\"/>\n");
        }
        if (coverName != null) {
            b.append("<item id=\"cover-image\" href=\"").append(coverName)
                    .append("\" media-type=\"image/jpeg\" properties=\"cover-image\"/>\n");
        }
        b.append("</manifest>\n<spine>\n");
        for (int j = 1; j < i; j++) b.append("<itemref idref=\"s").append(j).append("\"/>\n");
        b.append("</spine>\n</package>\n");
        return b.toString();
    }

    // ---------------------------------------------------------------------------------------------

    private static void putText(ZipOutputStream zip, String name, long time, String text) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(time);
        zip.putNextEntry(e);
        zip.write(text.getBytes(UTF8));
        zip.closeEntry();
    }

    private static void putFile(ZipOutputStream zip, String name, long time, File f) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(time);
        zip.putNextEntry(e);
        InputStream in = new FileInputStream(f);
        try {
            byte[] buf = new byte[32 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) zip.write(buf, 0, n);
        } finally {
            in.close();
        }
        zip.closeEntry();
    }

    private static String extensionOf(File f) {
        String n = f.getName().toLowerCase();
        int dot = n.lastIndexOf('.');
        String ext = dot < 0 ? "jpg" : n.substring(dot + 1);
        if (ext.equals("jpeg")) ext = "jpg";
        return ext.equals("png") ? "png" : "jpg";
    }

    private static String mediaType(String name) {
        return name.endsWith(".png") ? "image/png" : "image/jpeg";
    }

    private static String ltrim(String s) {
        int i = 0;
        while (i < s.length() && s.charAt(i) == ' ') i++;
        return s.substring(i);
    }

    private static String rtrim(String s) {
        int i = s.length();
        while (i > 0 && s.charAt(i - 1) == ' ') i--;
        return s.substring(0, i);
    }

    /** XML-escapes text and drops characters XML can't hold. */
    static String esc(String s) {
        StringBuilder b = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '&') b.append("&amp;");
            else if (c == '<') b.append("&lt;");
            else if (c == '>') b.append("&gt;");
            else if (c == '"') b.append("&quot;");
            else if (c == '­') continue;
            else if (c == 0x9 || c == 0xA || c == 0xD || (c >= 0x20 && c <= 0xD7FF) || (c >= 0xE000 && c <= 0xFFFD)) b.append(c);
            else if (Character.isHighSurrogate(c) && i + 1 < s.length() && Character.isLowSurrogate(s.charAt(i + 1))) {
                b.append(c).append(s.charAt(i + 1));
                i++;
            }
        }
        return b.toString();
    }
}
