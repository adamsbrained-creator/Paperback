package com.paperback.app.reflow;

import java.util.ArrayList;
import java.util.List;

/** What text recognition found on one page image: the image's size in pixels and the lines of text on it. */
public final class OcrPage {
    public final int width;
    public final int height;
    /** Pixels per inch of this picture, or 0 to use the one given to [OcrPages.convert]. */
    public float dpi;
    public final List<OcrLine> lines = new ArrayList<OcrLine>();

    public OcrPage(int width, int height) {
        this.width = width;
        this.height = height;
    }
}
