package com.paperback.app.catalog;

import java.util.regex.Pattern;

/** Tidies a book description from the catalog into plain paragraphs. */
public final class Describe {
    private Describe() {}

    private static final Pattern LINK = Pattern.compile("\\[([^\\]]+)\\]\\((?:[^)]*)\\)");
    private static final Pattern REF = Pattern.compile("\\[([^\\]]+)\\]\\[\\d*\\]");
    private static final Pattern REF_LINE = Pattern.compile("(?m)^\\s*\\[\\d+\\]:\\s*\\S+.*$");
    private static final Pattern TAGS = Pattern.compile("<[^>]+>");
    private static final Pattern RULE = Pattern.compile("(?m)^\\s*-{4,}\\s*$");

    public static String clean(String raw) {
        if (raw == null) return "";
        String s = raw.replace("\r\n", "\n").replace('\r', '\n');
        // Open Library descriptions often continue after a rule with "Contains:", "Also contained in" or a source note
        java.util.regex.Matcher m = RULE.matcher(s);
        if (m.find() && m.start() > 40) s = s.substring(0, m.start());
        s = REF_LINE.matcher(s).replaceAll("");
        s = LINK.matcher(s).replaceAll("$1");
        s = REF.matcher(s).replaceAll("$1");
        s = s.replaceAll("(?i)<br\\s*/?>", "\n").replaceAll("(?i)</p>", "\n\n");
        s = TAGS.matcher(s).replaceAll("");
        s = s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ");
        s = s.replace("**", "").replace("__", "");
        s = s.replaceAll("(?m)[ \\t]+$", "").replaceAll("\\n{3,}", "\n\n").trim();
        // "([source][1])" and "(source)" tails left by the link removal
        s = s.replaceAll("\\s*\\(\\s*\\[?source\\]?\\s*\\)\\s*$", "").trim();
        return s;
    }
}
