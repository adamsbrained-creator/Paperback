package com.paperback.app.data

import android.content.Context
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.catalog.CatalogApi
import com.paperback.app.data.opds.OpdsHttp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

/** What the lookup of one book found. */
enum class EnrichOutcome { Found, NotFound, Offline, Disabled }

/**
 * Finds books kept without a file (from a Bookshelf import or "Add without a file") in the online catalog, the same
 * way Search would, and fills in their cover, genres, description, year and page count. Nothing you entered is
 * replaced. A book that was looked up and not found is not tried again for a few days.
 */
class LogOnlyEnricher(
    context: Context,
    private val api: CatalogApi,
    private val http: OpdsHttp,
    private val repo: Repository,
    private val prefs: AppPrefs,
) {
    private val tried = context.getSharedPreferences("enrich", Context.MODE_PRIVATE)
    private val lock = Mutex()

    /** Looks up every file-less book that has no cover yet. Returns how many were filled in. */
    suspend fun run(): Int = lock.withLock {
        var found = 0
        val now = System.currentTimeMillis()
        for (b in repo.books.value.filter { !it.hasFile && it.coverPath == null }) {
            if (now - tried.getLong(b.id, 0L) < RETRY_MS) continue
            when (lookup(b)) {
                EnrichOutcome.Found -> found++
                EnrichOutcome.NotFound -> {}
                EnrichOutcome.Offline, EnrichOutcome.Disabled -> return@withLock found
            }
        }
        found
    }

    /** The same for one book, when asked for by hand. */
    suspend fun one(book: Book): EnrichOutcome = lock.withLock { lookup(book) }

    private suspend fun lookup(b: Book): EnrichOutcome = withContext(Dispatchers.IO) {
        if (!prefs.catalogOnline.value) return@withContext EnrichOutcome.Disabled
        try {
            val first = pick(b, api.search((b.title + " " + b.author.substringBefore(',')).trim(), 10))
            val hit = first ?: pick(b, api.search(b.title, 10))
            tried.edit().putLong(b.id, System.currentTimeMillis()).apply()
            if (hit == null) return@withContext EnrichOutcome.NotFound
            val details = runCatching { api.details(hit) }.getOrNull()
            val cover = CatalogApi.coverUrl(hit, "L")?.let { runCatching { http.getBytes(it, null) }.getOrNull() }
            repo.applyCatalog(b.id, hit, details, cover)
            EnrichOutcome.Found
        } catch (e: IOException) {
            EnrichOutcome.Offline
        } catch (e: Exception) {
            EnrichOutcome.NotFound
        }
    }

    /** The result with the same title (a subtitle or "Rita Hayworth and ..." prefix is allowed) and the same author. */
    private fun pick(b: Book, results: List<CatalogBook>): CatalogBook? {
        val key = TitleKey.of(b.title)
        if (key.length < 3) return null
        val surname = b.author.substringBefore(',').trim().substringAfterLast(' ').lowercase()
        val matches = results.filter { r ->
            val rk = TitleKey.of(r.title)
            val titleOk = rk == key || (key.length >= 6 && rk.length >= 6 && (rk.contains(key) || key.contains(rk)))
            val authorOk = surname.isEmpty() || r.author.lowercase().contains(surname)
            titleOk && authorOk
        }
        val exact = matches.filter { TitleKey.of(it.title) == key }
        val pool = exact.ifEmpty { matches }
        return pool.firstOrNull { it.coverId > 0 } ?: pool.firstOrNull()
    }

    private companion object {
        const val RETRY_MS = 3L * 24 * 60 * 60 * 1000
    }
}
