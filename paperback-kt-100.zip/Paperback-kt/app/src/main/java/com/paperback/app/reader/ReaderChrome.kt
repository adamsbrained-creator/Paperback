package com.paperback.app.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.ReaderLook
import com.paperback.app.data.Stats
import com.paperback.app.ui.PbIcon
import com.paperback.app.ui.PbIconName
import com.paperback.app.ui.PbSlider
import com.paperback.app.ui.theme.PbSerif

/** The reader's controls follow the page theme (light / sepia / dark), not the phone's theme. */
class ReaderColors(val card: Color, val ink: Color, val chip: Color, val page: Color)

/** The colours of an already resolved page colour (see [ReaderThemes.resolve]). */
fun readerColors(themeIndex: Int): ReaderColors = ReaderThemes.colors(themeIndex)

/**
 * The reader's controls, drawn over the Readium page. Everything is transparent except the two bars,
 * so taps anywhere else fall through to the book underneath.
 *
 * The bars are positioned with the *ignoring visibility* insets: the reader keeps the phone's status and
 * navigation bars hidden, and using the plain insets made the header jump whenever they appeared.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderChrome(
    title: String,
    visible: Boolean,
    position: Int,
    totalPositions: Int,
    shownPosition: Int,
    shownTotal: Int,
    progress: Float,
    secondsPerPage: Double?,
    fontSize: Double,
    /** The page colour being drawn (never Auto). */
    themeIndex: Int,
    /** What the reader picked: a colour, or -1 for Auto (follow the phone). */
    themeChoice: Int,
    brightness: Float,
    /** 0 = compact card, 1 = quick settings, 2 = icon tiles, 3 = settings panel. */
    style: Int,
    bookmarked: Boolean,
    onBack: () -> Unit,
    onToggleBookmark: () -> Unit,
    onOpenPanel: () -> Unit,
    onOpenContents: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenLook: () -> Unit,
    onSeek: (Float) -> Unit,
    onFontSize: (Double) -> Unit,
    onTheme: (Int) -> Unit,
    onBrightness: (Float) -> Unit,
    scrolled: Boolean = false,
    invertImages: Boolean = false,
    onSetScrolled: (Boolean) -> Unit = {},
    onSetInvertImages: (Boolean) -> Unit = {},
    autoScroll: Boolean = false,
    onToggleAutoScroll: () -> Unit = {},
    /** Starts reading aloud (the headphones button). */
    onListen: () -> Unit = {},
    /** Used by the settings panel (style 3): the saved look, a way to change it, and an exact font size. */
    look: ReaderLook = ReaderLook(),
    onLook: (ReaderLook) -> Unit = {},
    onSetFontSize: (Double) -> Unit = {},
) {
    val c = readerColors(themeIndex)
    var menuOpen by remember { mutableStateOf(false) }
    // Panel style (3): where the settings sheet starts, so the page can sit above it in a rounded card like the reference.
    var sheetTop by remember { mutableFloatStateOf(0f) }
    val statusTop = WindowInsets.statusBarsIgnoringVisibility.getTop(LocalDensity.current).toFloat()

    Box(Modifier.fillMaxSize()) {
        // Panel style: a soft sheet over the whole screen with a rounded window cut out, so the book shows through as a card.
        AnimatedVisibility(
            visible = visible && style == 3,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize(),
        ) {
            val sheet = c.card
            Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
                drawRect(sheet)
                val margin = 16.dp.toPx()
                val top = statusTop + 68.dp.toPx()
                val bottom = sheetTop - 10.dp.toPx()
                if (bottom - top > 60.dp.toPx()) {
                    val corner = CornerRadius(28.dp.toPx())
                    val topLeft = Offset(margin, top)
                    val box = Size(size.width - margin * 2, bottom - top)
                    drawRoundRect(Color.Black, topLeft, box, corner, blendMode = BlendMode.Clear)
                    // the first lines fade out at the top edge of the card, as in the reference
                    val shape = Path().apply { addRoundRect(RoundRect(topLeft.x, topLeft.y, topLeft.x + box.width, topLeft.y + box.height, corner)) }
                    clipPath(shape) {
                        drawRect(
                            brush = Brush.verticalGradient(listOf(c.page, Color.Transparent), startY = top, endY = top + 44.dp.toPx()),
                            topLeft = topLeft,
                            size = Size(box.width, 44.dp.toPx()),
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundButton(c, onBack) {
                    PbIcon(PbIconName.CaretLeft, size = 22.dp, tint = c.ink, strokeWidth = 2.2f, contentDescription = "Back")
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    text = title,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(c.card)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    color = c.ink,
                    fontFamily = PbSerif,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.width(10.dp))
                RoundButton(c, onToggleBookmark) {
                    PbIcon(
                        PbIconName.Bookmark,
                        size = 22.dp,
                        tint = if (bookmarked) MaterialTheme.colorScheme.primary else c.ink,
                        filled = bookmarked,
                        contentDescription = "Bookmark",
                    )
                }
                Spacer(Modifier.width(10.dp))
                Box {
                    RoundButton(c, { menuOpen = true }) { PbIcon(PbIconName.MenuLines, size = 22.dp, tint = c.ink, contentDescription = "Menu") }
                    DropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        modifier = Modifier.background(c.card),
                    ) {
                        @Composable
                        fun item(label: String, checked: Boolean? = null, enabled: Boolean = true, onClick: () -> Unit) {
                            DropdownMenuItem(
                                enabled = enabled,
                                text = { Text(label, color = if (enabled) c.ink else c.ink.copy(alpha = 0.4f), fontSize = 15.sp) },
                                trailingIcon = { if (checked != null) Text(if (checked) "On" else "Off", color = c.ink.copy(alpha = 0.55f), fontSize = 12.sp) },
                                onClick = {
                                    menuOpen = false
                                    onClick()
                                },
                            )
                        }
                        item("Contents") { onOpenContents() }
                        item("Bookmarks and notes") { onOpenPanel() }
                        item("Search in book") { onOpenSearch() }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(c.ink.copy(alpha = 0.1f)))
                        item("Scrolled mode", scrolled) { onSetScrolled(!scrolled) }
                        item("Auto scroll", autoScroll, enabled = scrolled) { onToggleAutoScroll() }
                        item("Invert images in dark mode", invertImages) { onSetInvertImages(!invertImages) }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(c.ink.copy(alpha = 0.1f)))
                        item("Reader settings") { onOpenLook() }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomStart),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .padding(16.dp)
                    .onGloballyPositioned { if (style == 3) sheetTop = it.positionInRoot().y }
                    .clip(RoundedCornerShape(28.dp))
                    .background(if (style == 3) Color.Transparent else c.card)
                    .padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                // The Panel style (3) has no page line: like the reference, it is only the settings.
                if (style != 3) {
                    val left = if (secondsPerPage != null && totalPositions > 0) {
                        Stats.duration(((totalPositions - position).coerceAtLeast(0) * secondsPerPage).toLong()) + " left"
                    } else null
                    val label = buildString {
                        if (shownTotal > 0) append("Page $shownPosition of $shownTotal · ")
                        append("${(progress * 100).toInt().coerceIn(0, 100)}%")
                        if (left != null) append(" · $left")
                    }
                    Text(label, color = c.ink, fontSize = 14.sp)

                    var drag by remember { mutableStateOf<Float?>(null) }
                    PbSlider(
                        value = drag ?: progress.coerceIn(0f, 1f),
                        onValueChange = { drag = it },
                        onValueChangeFinished = {
                            drag?.let(onSeek)
                            drag = null
                        },
                        trackColor = c.ink.copy(alpha = 0.15f),
                        modifier = Modifier.padding(vertical = 2.dp),
                    )

                }

                val q = QuickControls(
                    c = c,
                    fontSize = fontSize,
                    themeChoice = themeChoice,
                    brightness = brightness,
                    onFontSize = onFontSize,
                    onTheme = onTheme,
                    onBrightness = onBrightness,
                    onContents = onOpenContents,
                    onSearch = onOpenSearch,
                    onSettings = onOpenLook,
                    onListen = onListen,
                )
                when (style) {
                    1 -> QuickSettingsBody(q)
                    2 -> IconTilesBody(q)
                    3 -> {
                        Column(
                            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            PbIcon(PbIconName.CaretDown, size = 14.dp, tint = c.ink.copy(alpha = 0.3f), strokeWidth = 2.4f)
                            Text("Reader Settings", color = c.ink.copy(alpha = 0.55f), fontSize = 12.sp)
                        }
                        ReaderPanelBody(
                            c = c,
                            themeChoice = themeChoice,
                            fontSize = fontSize,
                            brightness = brightness,
                            look = look,
                            onTheme = onTheme,
                            onSetFontSize = onSetFontSize,
                            onBrightness = onBrightness,
                            onLook = onLook,
                            onListen = onListen,
                            onSearch = onOpenSearch,
                            onContents = onOpenContents,
                            onAdvanced = onOpenLook,
                        )
                    }
                    else -> CompactBody(q)
                }
            }
        }
    }
}

@Composable
internal fun RoundButton(c: ReaderColors, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(c.card).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
fun Pill(c: ReaderColors, text: String, selected: Boolean = false, modifier: Modifier = Modifier, container: Color? = null, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primary else container ?: c.chip
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else c.ink
    Text(
        text = text,
        color = fg,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = modifier.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
    )
}

// ---- the three layouts of the bottom card ------------------------------------------------------

/** Everything the three layouts of the bottom card need. */
private class QuickControls(
    val c: ReaderColors,
    val fontSize: Double,
    val themeChoice: Int,
    val brightness: Float,
    val onFontSize: (Double) -> Unit,
    val onTheme: (Int) -> Unit,
    val onBrightness: (Float) -> Unit,
    val onContents: () -> Unit,
    val onSearch: () -> Unit,
    val onSettings: () -> Unit,
    val onListen: () -> Unit,
)

/** A pill with an icon in front of its text (or just the text when [icon] is null). */
@Composable
private fun IconPill(c: ReaderColors, icon: PbIconName?, text: String, onClick: () -> Unit) {
    Row(
        Modifier
            .heightIn(min = 40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(c.chip)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (icon != null) PbIcon(icon, size = 18.dp, tint = c.ink)
        Text(text, color = c.ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** A square-ish button: icon above a small label. */
@Composable
private fun Tile(c: ReaderColors, icon: PbIconName, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(c.chip)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        PbIcon(icon, size = 22.dp, tint = c.ink)
        Text(label, color = c.ink.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 1)
    }
}

/** A, 100%, A+ as it always was. */
@Composable
private fun FontStepper(q: QuickControls) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Pill(q.c, "A\u2212") { q.onFontSize(-0.1) }
        Spacer(Modifier.width(8.dp))
        Text("${(q.fontSize * 100).toInt()}%", color = q.c.ink, fontSize = 13.sp)
        Spacer(Modifier.width(8.dp))
        Pill(q.c, "A+") { q.onFontSize(0.1) }
    }
}

/** One circle in the current page colour. Tap it and the other colours (and Auto) open above it. */
@Composable
private fun ThemeCircle(q: QuickControls) {
    var open by remember { mutableStateOf(false) }
    Box {
        ThemeDot(
            fill = q.c.page,
            selected = true,
            size = 44.dp,
            description = "Page color: ${ReaderThemes.name(q.themeChoice)}",
            edge = q.c.ink.copy(alpha = 0.25f),
        ) { open = !open }
        if (open) {
            AnchoredPopup(onDismiss = { open = false }) {
                ThemeMenu(q.c, q.themeChoice) {
                    open = false
                    q.onTheme(it)
                }
            }
        }
    }
}

/** [anchor] is drawn in a Box; while open, the brightness slider floats above it. */
@Composable
private fun BrightnessAnchor(q: QuickControls, modifier: Modifier = Modifier, anchor: @Composable (toggle: () -> Unit) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        anchor { open = !open }
        if (open) {
            AnchoredPopup(onDismiss = { open = false }) {
                BrightnessMenu(q.c, q.brightness, q.onBrightness)
            }
        }
    }
}

@Composable
private fun SettingsLink(onClick: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .padding(top = 4.dp)
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Reader settings", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(4.dp))
        PbIcon(PbIconName.CaretRight, size = 14.dp, tint = accent, strokeWidth = 2.4f)
    }
}

/** The default: text size and the colour circle, then Chapters, Search and Brightness, then a link to all settings. */
@Composable
private fun CompactBody(q: QuickControls) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        FontStepper(q)
        ThemeCircle(q)
    }
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconPill(q.c, PbIconName.Chapters, "Chapters", q.onContents)
        IconPill(q.c, PbIconName.Search, "Search", q.onSearch)
        BrightnessAnchor(q) { toggle ->
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(q.c.chip).clickable(onClick = toggle),
                contentAlignment = Alignment.Center,
            ) { PbIcon(PbIconName.Sun, size = 18.dp, tint = q.c.ink, contentDescription = "Brightness") }
        }
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(q.c.chip).clickable(onClick = q.onListen),
            contentAlignment = Alignment.Center,
        ) { PbIcon(PbIconName.Headphones, size = 18.dp, tint = q.c.ink, contentDescription = "Read aloud") }
    }
    SettingsLink(q.onSettings)
}

/** Text size and colour, a brightness slider in place, and three pills. */
@Composable
private fun QuickSettingsBody(q: QuickControls) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        FontStepper(q)
        ThemeCircle(q)
    }
    val auto = q.brightness < 0f
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        PbIcon(PbIconName.Sun, size = 20.dp, tint = q.c.ink, contentDescription = "Brightness")
        Spacer(Modifier.width(12.dp))
        PbSlider(
            value = if (auto) 0.5f else q.brightness,
            onValueChange = { q.onBrightness(it.coerceIn(0.05f, 1f)) },
            valueRange = 0.05f..1f,
            trackColor = q.c.ink.copy(alpha = 0.15f),
            modifier = Modifier.weight(1f),
        )
        Spacer(Modifier.width(8.dp))
        Pill(q.c, "Auto", selected = auto) { q.onBrightness(-1f) }
    }
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconPill(q.c, null, "Chapters", q.onContents)
        IconPill(q.c, null, "Search", q.onSearch)
        IconPill(q.c, null, "Settings", q.onSettings)
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(q.c.chip).clickable(onClick = q.onListen),
            contentAlignment = Alignment.Center,
        ) { PbIcon(PbIconName.Headphones, size = 18.dp, tint = q.c.ink, contentDescription = "Read aloud") }
    }
}

/** Every colour in a row, then five tiles: Chapters, Search, Brightness, Listen and Settings. */
@Composable
private fun IconTilesBody(q: QuickControls) {
    val edge = q.c.ink.copy(alpha = 0.25f)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        ThemeDot(Color.Unspecified, q.themeChoice < 0, 36.dp, "Auto, matches your phone", edge, split = true) { q.onTheme(ReaderThemes.AUTO) }
        ReaderThemes.menuOrder.forEach { i ->
            ThemeDot(ReaderThemes.colors(i).page, q.themeChoice == i, 36.dp, ReaderThemes.name(i), edge) { q.onTheme(i) }
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Tile(q.c, PbIconName.Chapters, "Chapters", Modifier.weight(1f), q.onContents)
        Tile(q.c, PbIconName.Search, "Search", Modifier.weight(1f), q.onSearch)
        BrightnessAnchor(q, Modifier.weight(1f)) { toggle ->
            Tile(q.c, PbIconName.Sun, "Brightness", Modifier.fillMaxWidth(), toggle)
        }
        Tile(q.c, PbIconName.Headphones, "Listen", Modifier.weight(1f), q.onListen)
        Tile(q.c, PbIconName.Settings, "Settings", Modifier.weight(1f), q.onSettings)
    }
}
