package com.paperback.app.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Height of the strip above and below the page that holds the chapter name and the page counters. */
val ReaderBand: Dp = 24.dp

/**
 * The small, quiet text around the page, as in Readest: the chapter name at the top; "N pages left in chapter"
 * at the bottom left and "position / total" at the bottom right. "Pages left" counts real screens, so it drops
 * by one for each page you turn; the counter counts fixed pieces of text, so it can move by more than one.
 * Hidden while the reader's controls are showing (they cover this strip).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderMarginInfo(
    themeIndex: Int,
    hidden: Boolean,
    chapter: String,
    pagesLeft: Int,
    position: Int,
    totalPositions: Int,
) {
    val c = readerColors(themeIndex)
    val color = c.ink.copy(alpha = 0.55f)
    AnimatedVisibility(visible = !hidden, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBarsIgnoringVisibility)
                    .height(ReaderBand)
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (chapter.isNotBlank()) {
                    Text(chapter, color = color, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBarsIgnoringVisibility)
                    .height(ReaderBand)
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (pagesLeft > 0) "$pagesLeft ${if (pagesLeft == 1) "page" else "pages"} left in chapter" else "",
                    modifier = Modifier.weight(1f),
                    color = color,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (position > 0 && totalPositions > 0) {
                    Text("$position / $totalPositions", color = color, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}
