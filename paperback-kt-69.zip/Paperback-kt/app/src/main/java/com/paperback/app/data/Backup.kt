package com.paperback.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** What a backup file holds, as shown on the Backup & restore screen. */
data class BackupCounts(val books: Int, val bookmarks: Int, val highlights: Int, val sessions: Int, val collections: Int = 0) {
    fun describe(): String {
        fun n(count: Int, one: String, many: String) = "$count ${if (count == 1) one else many}"
        return listOf(
            n(books, "book", "books"),
            n(bookmarks, "bookmark", "bookmarks"),
            n(highlights, "highlight", "highlights"),
            n(sessions, "reading session", "reading sessions"),
            n(collections, "collection", "collections"),
        ).joinToString(", ")
    }
}

/** A backup file that was read and checked, waiting for the person to confirm the restore. */
data class PendingBackup(val json: String, val exportedAt: String, val counts: BackupCounts)

/**
 * Backup of everything Paperback adds to your books: progress, favorites, ratings, bookmarks, highlights,
 * notes, reading history, goals and look. The book files themselves are not inside; books are matched by
 * their hash, so a restore fills in the ones that are in your library.
 */
object Backup {
    private const val APP = "paperback"
    private const val VERSION = 1

    fun filename(today: LocalDate = LocalDate.now()): String =
        "paperback-backup-" + today.format(DateTimeFormatter.ISO_LOCAL_DATE) + ".json"

    fun currentCounts(db: PaperbackDb): BackupCounts {
        val books = db.allBooks()
        return BackupCounts(
            books = books.size,
            bookmarks = books.sumOf { db.bookmarksFor(it.id).size },
            highlights = books.sumOf { db.highlightsFor(it.id).size },
            sessions = db.allSessions().size,
            collections = db.allCollections().size,
        )
    }

    fun build(db: PaperbackDb, prefs: AppPrefs, reader: ReaderSettings, wishlist: Wishlist? = null): String {
        val root = JSONObject()
        root.put("app", APP)
        root.put("platform", "kotlin")
        root.put("version", VERSION)
        root.put("exportedAt", Instant.now().toString())

        val g = prefs.goals.value
        root.put(
            "goals",
            JSONObject()
                .put("booksPerYear", g.booksPerYear)
                .put("pagesPerDay", g.pagesPerDay)
                .put("minutesPerDay", g.minutesPerDay)
                .put("streakDays", g.streakDays)
                .put("weeklyMinutes", g.weeklyMinutes)
                .put("monthlyMinutes", g.monthlyMinutes)
                .put("monthlyBooks", g.monthlyBooks)
                .put("tinyMinutes", g.tinyMinutes)
                .put("restDays", g.restDays),
        )
        root.put(
            "settings",
            JSONObject()
                .put("headerSize", prefs.headerSize.value.name)
                .put("navStyle", prefs.navStyle.value.name)
                .put("moreStyle", prefs.moreStyle.value.name)
                .put("goalStyle", prefs.goalStyle.value.name)
                .put("iconStyle", prefs.iconStyle.value.name)
                .put("libraryShelf", prefs.libraryShelf.value)
                .put("rhythmCalendar", prefs.rhythmCalendar.value)
                .apply { HomeSection.values().forEach { put(it.prefKey, (prefs.homeViews.value[it] ?: it.default).name) } }
                .put("catalogOnline", prefs.catalogOnline.value)
                .put("homeRecommendations", prefs.showRecommendations.value)
                .put("openBookPage", prefs.openBookPage.value)
                .put("swipeBack", prefs.swipeBack.value)
                .put("swipeTabs", prefs.swipeTabs.value)
                .put("ratingScale", prefs.ratingScale.value)
                .put("ratingSteps", prefs.ratingSteps.value)
                .put("recapRemind", prefs.recapRemind.value)
                .put("accent", prefs.accent.value)
                .put("themeMode", prefs.themeMode.value.name)
                .put("readerFontSize", reader.fontSize)
                .put("readerTheme", reader.theme),
        )

        root.put("recapsGenerated", JSONArray(prefs.recapGenerated.value.toList()))
        root.put("statsLayout", prefs.statsLayout.value)

        val books = db.allBooks()
        val booksJson = JSONArray()
        val bookmarksJson = JSONArray()
        val highlightsJson = JSONArray()
        for (b in books) {
            booksJson.put(
                JSONObject()
                    .put("id", b.id)
                    .put("title", b.title)
                    .put("author", b.author)
                    .put("favorite", b.favorite)
                    .put("finished", b.finished)
                    .put("rating", b.rating)
                    .put("rating10", b.rating10.toDouble())
                    .put("customPages", b.customPages)
                    .put("spineColor", b.spineColor)
                    .put("shelfOrder", b.shelfOrder)
                    .put("progress", b.progress.toDouble())
                    .put("position", b.position)
                    .put("lastOpenedAt", b.lastOpenedAt)
                    .put("finishedAt", b.finishedAt)
                    .put("journal", b.journal)
                    .put("startedAt", b.startedAt)
                    .put("ratedAt", b.ratedAt)
                    .put("status", b.status)
                    .put("statusAt", b.statusAt)
                    .put("droppedPct", b.droppedPct)
                    .put("source", b.source)
                    .put("format", b.format)
                    .put("series", b.series)
                    .put("seriesNo", b.seriesNo.toDouble())
                    .put("words", b.words)
                    .put("locator", b.locatorJson ?: JSONObject.NULL),
            )
            for (m in db.bookmarksFor(b.id)) {
                bookmarksJson.put(
                    JSONObject()
                        .put("id", m.id)
                        .put("bookId", m.bookId)
                        .put("locator", m.locatorJson)
                        .put("position", m.position)
                        .put("progress", m.progress.toDouble())
                        .put("createdAt", m.createdAt),
                )
            }
            for (h in db.highlightsFor(b.id)) {
                highlightsJson.put(
                    JSONObject()
                        .put("id", h.id)
                        .put("bookId", h.bookId)
                        .put("locator", h.locatorJson)
                        .put("text", h.text)
                        .put("note", h.note)
                        .put("color", h.color)
                        .put("progress", h.progress.toDouble())
                        .put("createdAt", h.createdAt),
                )
            }
        }
        if (wishlist != null) root.put("wantToRead", wishlist.toJson())
        root.put("books", booksJson)
        root.put("bookmarks", bookmarksJson)
        root.put("highlights", highlightsJson)

        val sessionsJson = JSONArray()
        for (s in db.allSessions()) {
            sessionsJson.put(
                JSONObject()
                    .put("bookId", s.bookId)
                    .put("startMs", s.startMs)
                    .put("seconds", s.seconds)
                    .put("pages", s.pages)
                    .put("fromPos", s.fromPos)
                    .put("toPos", s.toPos)
                    .put("manual", s.manual)
                    .put("kind", s.kind)
                    .put("chapters", s.chapters)
                    .put("breaks", s.breaks)
                    .put("place", s.place)
                    .put("mood", s.mood)
                    .put("look", s.look),
            )
        }
        root.put("sessions", sessionsJson)

        // every finished reading of a book (re-reads are extra rows) and the daily goal of each day
        val readingsJson = JSONArray()
        for (r in db.allReadings()) {
            readingsJson.put(
                JSONObject()
                    .put("bookId", r.bookId)
                    .put("startedAt", r.startedAt)
                    .put("finishedAt", r.finishedAt)
                    .put("rating10", r.rating10.toDouble()),
            )
        }
        root.put("readings", readingsJson)
        val goalDaysJson = JSONArray()
        for ((day, minutes) in db.goalDays()) goalDaysJson.put(JSONObject().put("day", day).put("minutes", minutes))
        root.put("goalDays", goalDaysJson)

        val members = db.collectionMembers()
        val collectionsJson = JSONArray()
        for (c in db.allCollections()) {
            collectionsJson.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name)
                    .put("createdAt", c.createdAt)
                    .put("books", JSONArray((members[c.id] ?: emptySet()).toList())),
            )
        }
        root.put("collections", collectionsJson)

        return root.toString(2)
    }

    /** Checks that [text] is a Paperback backup. Returns the pending restore, or an error message. */
    fun parse(text: String): Result<PendingBackup> = runCatching {
        val root = JSONObject(text)
        require(root.optString("app") == APP) { "That is not a Paperback backup file." }
        PendingBackup(
            json = text,
            exportedAt = root.optString("exportedAt", ""),
            counts = BackupCounts(
                books = root.optJSONArray("books")?.length() ?: 0,
                bookmarks = root.optJSONArray("bookmarks")?.length() ?: 0,
                highlights = root.optJSONArray("highlights")?.length() ?: 0,
                sessions = root.optJSONArray("sessions")?.length() ?: 0,
                collections = root.optJSONArray("collections")?.length() ?: 0,
            ),
        )
    }.recoverCatching { e ->
        throw IllegalArgumentException(
            if (e is IllegalArgumentException) e.message else "That file could not be read as a Paperback backup.",
        )
    }

    /** Applies a backup to the books that are in the library. Returns how many books were matched. */
    fun restore(pending: PendingBackup, db: PaperbackDb, prefs: AppPrefs, reader: ReaderSettings, wishlist: Wishlist? = null): Int {
        val root = JSONObject(pending.json)
        wishlist?.merge(root.optJSONArray("wantToRead"))

        root.optJSONObject("goals")?.let { g ->
            val d = Goals.DEFAULT
            prefs.setGoals(
                Goals(
                    booksPerYear = g.optInt("booksPerYear", d.booksPerYear),
                    pagesPerDay = g.optInt("pagesPerDay", d.pagesPerDay),
                    minutesPerDay = g.optInt("minutesPerDay", d.minutesPerDay),
                    streakDays = g.optInt("streakDays", d.streakDays),
                    // older backups have none of these: the defaults apply
                    weeklyMinutes = g.optInt("weeklyMinutes", d.weeklyMinutes),
                    monthlyMinutes = g.optInt("monthlyMinutes", d.monthlyMinutes),
                    monthlyBooks = g.optInt("monthlyBooks", d.monthlyBooks),
                    tinyMinutes = g.optInt("tinyMinutes", d.tinyMinutes),
                    restDays = g.optInt("restDays", d.restDays),
                ),
            )
        }
        root.optJSONObject("settings")?.let { s ->
            HeaderSize.values().firstOrNull { it.name == s.optString("headerSize") }?.let { prefs.setHeaderSize(it) }
            if (s.has("accent")) prefs.setAccent(s.optInt("accent", prefs.accent.value))
            NavStyle.values().firstOrNull { it.name == s.optString("navStyle") }?.let { prefs.setNavStyle(it) }
            MoreStyle.values().firstOrNull { it.name == s.optString("moreStyle") }?.let { prefs.setMoreStyle(it) }
            GoalStyle.values().firstOrNull { it.name == s.optString("goalStyle") }?.let { prefs.setGoalStyle(it) }
            IconStyle.values().firstOrNull { it.name == s.optString("iconStyle") }?.let { prefs.setIconStyle(it) }
            if (s.has("libraryShelf")) prefs.setLibraryShelf(s.optBoolean("libraryShelf", true))
            if (s.has("rhythmCalendar")) prefs.setRhythmCalendar(s.optBoolean("rhythmCalendar", false))
            HomeSection.values().forEach { sec ->
                HomeView.values().firstOrNull { it.name == s.optString(sec.prefKey) }?.let { prefs.setHomeView(sec, it) }
            }
            if (s.has("catalogOnline")) prefs.setCatalogOnline(s.optBoolean("catalogOnline", true))
            if (s.has("homeRecommendations")) prefs.setShowRecommendations(s.optBoolean("homeRecommendations", true))
            if (s.has("openBookPage")) prefs.setOpenBookPage(s.optBoolean("openBookPage", true))
            if (s.has("swipeBack")) prefs.setSwipeBack(s.optBoolean("swipeBack", true))
            if (s.has("swipeTabs")) prefs.setSwipeTabs(s.optBoolean("swipeTabs", false))
            if (s.has("ratingScale")) prefs.setRatingScale(s.optInt("ratingScale", 5))
            if (s.has("ratingSteps")) prefs.setRatingSteps(s.optInt("ratingSteps", 2))
            if (s.has("recapRemind")) prefs.setRecapRemind(s.optBoolean("recapRemind", true))
            ThemeMode.values().firstOrNull { it.name == s.optString("themeMode") }?.let { prefs.setThemeMode(it) }
            if (s.has("readerFontSize")) reader.fontSize = s.optDouble("readerFontSize", reader.fontSize).coerceIn(0.6, 2.5)
            if (s.has("readerTheme")) reader.theme = s.optInt("readerTheme", reader.theme).coerceIn(-1, 5)
        }

        if (root.has("statsLayout")) prefs.setStatsLayout(root.optString("statsLayout", ""))
        root.optJSONArray("recapsGenerated")?.let { arr ->
            prefs.addRecapGenerated((0 until arr.length()).map { arr.optString(it) }.filter { it.isNotEmpty() })
        }

        val inLibrary = db.allBooks().associateBy { it.id }.toMutableMap()
        var matched = 0

        // Books marked "noFile" are log-only: read elsewhere (another app, paper) and kept here for stats,
        // ratings and notes. They are created if missing, with no file, so they can't be opened.
        root.optJSONArray("books")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id.isEmpty() || id in inLibrary || !o.optBoolean("noFile", false)) continue
                val tags = o.optJSONArray("tags")?.let { t -> (0 until t.length()).map { t.optString(it) }.filter { it.isNotBlank() } } ?: emptyList()
                val book = Book(
                    id = id, title = o.optString("title"), author = o.optString("author"),
                    language = o.optString("language"), filePath = "", coverPath = null,
                    addedAt = o.optLong("addedAt", System.currentTimeMillis()), lastOpenedAt = 0L,
                    progress = 0f, position = 0, totalPositions = 0, locatorJson = null,
                    finished = false, favorite = false, rating = 0,
                    tags = tags, publisher = o.optString("publisher"), published = o.optString("published"),
                    metaRead = true,
                )
                if (db.insertBook(book)) inLibrary[id] = book
            }
        }

        root.optJSONArray("books")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                val existing = inLibrary[id] ?: continue
                matched++
                db.setFlag(id, "favorite", o.optBoolean("favorite", existing.favorite))
                db.setFinished(id, o.optBoolean("finished", existing.finished), record = false)
                // The real finish date, when the backup knows it (older backups wrote it but restore ignored it).
                val finishedAt = o.optLong("finishedAt", 0L)
                if (finishedAt > 0L && o.optBoolean("finished", existing.finished)) db.setFinishedAt(id, finishedAt)
                if (o.has("rating10")) db.setRating10(id, o.optDouble("rating10", existing.rating10.toDouble()))
                else db.setRating(id, o.optInt("rating", existing.rating))
                // setting the rating stamps today; the backup's own day (or the one already stored) wins
                db.setRatedAt(id, o.optLong("ratedAt", existing.ratedAt))
                if (o.has("customPages")) db.setCustomPages(id, o.optInt("customPages", 0))
                if (o.has("spineColor")) db.setSpineColor(id, o.optInt("spineColor", 0))
                if (o.has("journal")) db.setJournal(id, o.optString("journal", existing.journal))
                restoreFacts(db, id, o, existing)
                o.optString("coverUrl").takeIf { it.startsWith("http") && !existing.hasFile }?.let { prefs.setCoverHint(id, it) }
                val locator = if (o.isNull("locator")) null else o.optString("locator").takeIf { it.isNotEmpty() }
                // Only move reading progress forward: a restore must never undo reading done since the backup.
                val progress = o.optDouble("progress", 0.0).toFloat()
                if (locator != null && progress > existing.progress) {
                    db.updateProgress(
                        id = id,
                        locatorJson = locator,
                        progress = progress,
                        position = o.optInt("position", existing.position),
                        openedAt = maxOf(existing.lastOpenedAt, o.optLong("lastOpenedAt", 0L)),
                    )
                }
            }
        }

        root.optJSONArray("bookmarks")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val bookId = o.optString("bookId")
                if (bookId !in inLibrary) continue
                db.insertBookmark(
                    Bookmark(
                        id = o.optString("id"),
                        bookId = bookId,
                        locatorJson = o.optString("locator"),
                        position = o.optInt("position", 0),
                        progress = o.optDouble("progress", 0.0).toFloat(),
                        createdAt = o.optLong("createdAt", 0L),
                    ),
                )
            }
        }

        root.optJSONArray("highlights")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val bookId = o.optString("bookId")
                if (bookId !in inLibrary) continue
                db.insertHighlight(
                    Highlight(
                        id = o.optString("id"),
                        bookId = bookId,
                        locatorJson = o.optString("locator"),
                        text = o.optString("text"),
                        note = o.optString("note"),
                        color = o.optInt("color", HighlightColors.DEFAULT),
                        progress = o.optDouble("progress", 0.0).toFloat(),
                        createdAt = o.optLong("createdAt", 0L),
                    ),
                )
            }
        }

        // Collections: created again if missing, with the books of the backup that are in the library.
        root.optJSONArray("collections")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id.isEmpty()) continue
                db.upsertCollection(BookCollection(id, o.optString("name"), o.optLong("createdAt", 0L)))
                o.optJSONArray("books")?.let { ids ->
                    for (j in 0 until ids.length()) {
                        val bookId = ids.optString(j)
                        if (bookId in inLibrary) db.setMember(id, bookId, true)
                    }
                }
            }
        }

        // Reading history is kept even for books that are no longer in the library, like the database does.
        // A session that is already stored (same book and start time) is not added twice.
        val have = db.allSessions().map { it.bookId to it.startMs }.toHashSet()
        root.optJSONArray("sessions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val bookId = o.optString("bookId")
                val startMs = o.optLong("startMs", 0L)
                if (bookId.isEmpty() || startMs <= 0L || (bookId to startMs) in have) continue
                val manual = o.optBoolean("manual", false)
                val kind = o.optInt("kind", if (manual) SessionKind.LOGGED else SessionKind.READ).coerceIn(0, 2)
                val newId = db.insertSession(
                    bookId, startMs, o.optInt("seconds", 0), o.optInt("pages", 0), o.optInt("fromPos", 0), o.optInt("toPos", 0),
                    manual, kind, o.optInt("chapters", 0), o.optInt("breaks", 0), o.optString("look", ""),
                )
                val place = o.optInt("place", 0)
                val mood = o.optInt("mood", 0)
                if (newId > 0L && (place > 0 || mood > 0)) db.setSessionContext(newId, place, mood)
                have.add(bookId to startMs)
            }
        }

        // Every finished reading (re-reads included), and the daily goal of each past day. Neither is added twice.
        root.optJSONArray("readings")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val bookId = o.optString("bookId")
                val finishedAt = o.optLong("finishedAt", 0L)
                if (bookId.isEmpty() || finishedAt <= 0L) continue
                db.insertReading(bookId, o.optLong("startedAt", 0L), finishedAt, o.optDouble("rating10", 0.0))
            }
        }
        root.optJSONArray("goalDays")?.let { arr ->
            val known = db.goalDays()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val day = o.optLong("day", Long.MIN_VALUE)
                if (day == Long.MIN_VALUE || day in known) continue
                db.recordGoalDay(day, o.optInt("minutes", 0))
            }
        }

        // A finished book from an older backup has no reading yet: give it one, with the dates we know.
        val haveReading = db.allReadings().map { it.bookId }.toHashSet()
        for (b in db.allBooks()) {
            if (b.finished && b.id !in haveReading) {
                db.insertReading(b.id, b.startedAt, finishedAtMs(b), b.rating10.toDouble())
            }
        }

        // A book without a file has no reader to remember its place, so it stays where its entries reach
        // (a finished book is all the way). Only ever forward.
        val bySession = db.allSessions().groupBy { it.bookId }
        for (b in db.allBooks()) {
            if (b.hasFile) continue
            val total = b.pageCount
            val reach = bySession[b.id]?.maxOfOrNull { it.toPos } ?: 0
            val page = if (b.finished) total else if (total > 0) minOf(reach, total) else 0
            if (page <= 0) continue
            val progress = com.paperback.app.catalog.PageMath.progressForPage(page, total).toFloat()
            if (progress > b.progress) db.setPlace(b.id, progress, com.paperback.app.catalog.PageMath.positionFor(page, total, 0))
        }

        return matched
    }

    /**
     * The newer per-book facts: start date, paused / dropped, source, format, series and word count. Reads the names
     * this app writes, plus a few common spellings from other apps' exports (a Bookshelf file converted to this format),
     * so those books arrive with their data. A date already stored is only ever moved earlier.
     */
    private fun restoreFacts(db: PaperbackDb, id: String, o: JSONObject, existing: Book) {
        fun firstString(vararg keys: String): String? = keys.firstNotNullOfOrNull { k -> if (o.has(k) && !o.isNull(k)) o.optString(k).takeIf { it.isNotBlank() } else null }
        fun firstLong(vararg keys: String): Long = keys.firstNotNullOfOrNull { k -> if (o.has(k) && !o.isNull(k)) o.optLong(k, 0L).takeIf { it > 0L } else null } ?: 0L

        val started = firstLong("startedAt", "started", "startDate", "dateStarted")
        if (started > 0L && (existing.startedAt <= 0L || started < existing.startedAt)) db.setStartedAt(id, started)

        if (o.has("status")) {
            val st = o.optInt("status", 0).coerceIn(0, 2)
            if (st != existing.status) db.setStatus(id, st, o.optLong("statusAt", System.currentTimeMillis()), o.optInt("droppedPct", existing.percent))
        } else if (o.optBoolean("abandoned", false) || o.optBoolean("dropped", false)) {
            db.setStatus(id, 2, o.optLong("statusAt", System.currentTimeMillis()), existing.percent)
        }

        db.setBookFacts(
            id,
            source = firstString("source", "origin"),
            format = firstString("format", "bookFormat", "edition"),
            series = firstString("series", "seriesName"),
            seriesNo = firstString("seriesNo", "seriesNumber", "seriesIndex", "seriesPosition")?.toFloatOrNull(),
            words = firstString("words", "wordCount")?.toIntOrNull(),
        )
    }

    /** "Made 22 Oct 2026" for the confirm card. */
    fun madeOn(exportedAt: String): String? = runCatching {
        val d = Instant.parse(exportedAt).atZone(ZoneId.systemDefault()).toLocalDate()
        d.format(DateTimeFormatter.ofPattern("d MMM yyyy"))
    }.getOrNull()
}
