package com.paperback.app.data.opds

import java.net.URI
import java.net.URLEncoder

/** Address handling for OPDS: resolving relative links, expanding search templates. Plain Kotlin, no Android classes. */
object OpdsUrl {
    private const val KEEP = "-._~:/?#@!$&'()*+,;=%"

    /** Percent-encodes anything that may not appear in an address (spaces, braces, non-ASCII), keeping existing %XX. */
    fun escape(s: String): String {
        val sb = StringBuilder(s.length + 8)
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            val len = Character.charCount(cp)
            val ch = s[i]
            if (len == 1 && ((ch.code < 128 && ch.isLetterOrDigit()) || ch in KEEP)) {
                sb.append(ch)
            } else {
                for (b in String(Character.toChars(cp)).toByteArray(Charsets.UTF_8)) {
                    sb.append('%').append("%02X".format(b.toInt() and 0xFF))
                }
            }
            i += len
        }
        return sb.toString()
    }

    fun hostOf(url: String): String? =
        try {
            URI(escape(url)).host?.lowercase()
        } catch (e: Exception) {
            null
        }

    fun isHttp(url: String): Boolean = url.startsWith("http://", true) || url.startsWith("https://", true)

    /**
     * Makes [href] absolute against [base]. Template braces (`{searchTerms}`) are kept, and a plain-http link to the
     * same host as an https feed is upgraded to https (some catalogs only answer on https but still publish http links).
     */
    fun resolve(href: String, base: String): String {
        val h = href.trim()
        if (h.isEmpty()) return ""
        val hadBrace = h.contains('{')
        return try {
            var b = escape(base.substringBefore('#'))
            // "https://host" with no path would resolve "book" to "https://hostbook"; give it a root path.
            val m = Regex("^([a-zA-Z][a-zA-Z0-9+.-]*://[^/?#]+)(.*)$").find(b)
            if (m != null && !m.groupValues[2].startsWith("/")) b = m.groupValues[1] + "/" + m.groupValues[2]
            // Java's resolver drops the last path segment for a query-only link ("?page=2"); RFC 3986 keeps it.
            var out = if (h.startsWith("?")) b.substringBefore('?') + escape(h) else URI(b).resolve(URI(escape(h))).toString()
            if (hadBrace) {
                out = out.replace("%7B", "{", true).replace("%7D", "}", true)
            }
            upgrade(out, base)
        } catch (e: Exception) {
            h
        }
    }

    private fun upgrade(resolved: String, base: String): String {
        if (base.startsWith("https://", true) && resolved.startsWith("http://", true)) {
            val a = hostOf(resolved)
            if (a != null && a == hostOf(base)) return "https://" + resolved.substring(7)
        }
        return resolved
    }

    /** Percent-encodes search words (a space becomes %20, not +). */
    fun encode(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private val textVars = listOf("searchTerms", "query", "q")

    /**
     * Fills a search address with the words typed. Handles OpenSearch (`...?q={searchTerms}`, optional `{searchTerms?}`)
     * and OPDS 2 URI templates (`/search{?query}`).
     */
    fun expandSearch(template: String, terms: String): String {
        val normalized = template.replace("%7B", "{", true).replace("%7D", "}", true)
        val enc = encode(terms.trim())
        return Regex("\\{([^}]*)\\}").replace(normalized) { m ->
            val expr = m.groupValues[1].trim()
            val out = if (expr.startsWith("?") || expr.startsWith("&")) {
                val vars = expr.substring(1).split(',').map { it.trim().removeSuffix("*") }.filter { it.isNotEmpty() }
                val v = vars.firstOrNull { it in textVars } ?: vars.firstOrNull()
                if (v == null) "" else "${expr[0]}$v=$enc"
            } else {
                val name = expr.removeSuffix("?").removePrefix("+").substringAfter(':')
                when {
                    name in textVars -> enc
                    name == "startPage" || name == "startIndex" -> "1"
                    name == "count" -> "20"
                    else -> ""
                }
            }
            out
        }
    }
}

/** Turns the HTML or text a feed uses for a description into plain paragraphs. */
object OpdsText {
    private val realTag = Regex("<[a-zA-Z/!]")
    private val escapedTag = Regex("&lt;/?[a-zA-Z]")

    fun plain(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var s: String = raw
        // Some aggregators escape an already escaped summary, so the markup arrives as text ("&lt;p&gt;").
        if (escapedTag.containsMatchIn(s) && !realTag.containsMatchIn(s)) s = MiniXml.decode(s)
        s = s.replace(Regex("(?i)<br\\s*/?>"), "\n")
            .replace(Regex("(?i)<li[^>]*>"), "\n• ")
            .replace(Regex("(?i)</(p|div|li|ul|ol|h[1-6]|blockquote|tr|table)>"), "\n\n")
            .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), "")
            .replace(Regex("<[^>]+>"), "")
        s = MiniXml.decode(s).replace('\u00A0', ' ')
        return s.lines()
            .joinToString("\n") { it.trim().replace(Regex("[ \t]+"), " ") }
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }
}

/** Which download links are usable, and which one to offer first. Paperback reads EPUB only for now. */
object OpdsFormats {
    private val epubHref = Regex("\\.epub\\d?(?:[.?#/]|$)", RegexOption.IGNORE_CASE)
    private val epubTitle = Regex("\\bepub\\d?\\b", RegexOption.IGNORE_CASE)

    private fun mediaType(link: OpdsLink): String =
        (link.type ?: "").substringBefore(';').trim().lowercase()

    fun isEpub(link: OpdsLink): Boolean {
        val m = mediaType(link)
        if (m == "application/epub+zip") return true
        // A feed may leave the type out, or say "octet-stream"; fall back to the address and the label.
        if (m.isEmpty() || m == "application/octet-stream") {
            val path = link.href.substringBefore('?').substringBefore('#')
            if (epubHref.containsMatchIn(link.href) || path.endsWith(".epub", true)) return true
            if (link.title != null && epubTitle.containsMatchIn(link.title)) return true
        }
        return false
    }

    /** 0 = EPUB 3 ("advanced" EPUB), 1 = EPUB. Lower is better. */
    fun tier(link: OpdsLink): Int {
        val params = (link.type ?: "").substringAfter(';', "")
        val version = Regex("version\\s*=\\s*\"?([0-9.]+)").find(params)?.groupValues?.get(1)
        if (version != null && version.startsWith("3")) return 0
        val title = (link.title ?: "").lowercase()
        if (title.contains("advanced") || title.contains("epub3") || title.contains("epub 3")) return 0
        if (Regex("\\.epub3(?:[.?#/]|$)", RegexOption.IGNORE_CASE).containsMatchIn(link.href)) return 0
        return 1
    }

    /** Every EPUB the person could download, best first (feed order kept inside a tier). */
    fun epubLinks(pub: OpdsPublication): List<OpdsLink> =
        pub.links.filter { it.isDirectAcquisition && isEpub(it) }.sortedBy { tier(it) }

    /** True when the book is offered, but only in formats Paperback cannot open. */
    fun onlyOtherFormats(pub: OpdsPublication): Boolean =
        epubLinks(pub).isEmpty() && pub.links.any { it.isAcquisition }

    /** A short name for a menu entry: the feed's own label if there is one. */
    fun label(link: OpdsLink): String {
        val t = link.title?.trim().orEmpty()
        if (t.isNotEmpty()) return t
        return if (tier(link) == 0) "EPUB 3" else "EPUB"
    }

    /** Other formats named by the feed, for the "not available" hint (e.g. "PDF, MOBI"). */
    fun otherFormatNames(pub: OpdsPublication): List<String> =
        pub.links.filter { it.isAcquisition && !isEpub(it) }.mapNotNull { l ->
            val m = mediaType(l)
            when {
                m.contains("pdf") -> "PDF"
                m.contains("mobi") || m.contains("mobipocket") -> "MOBI"
                m.contains("amazon") || m.contains("kindle") || m.contains("azw") -> "Kindle"
                m.contains("comicbook") || m.contains("cbz") -> "CBZ"
                m.contains("fictionbook") || m.contains("fb2") -> "FB2"
                m.contains("html") -> "Web page"
                else -> l.href.substringBefore('?').substringAfterLast('.', "").uppercase().takeIf { it.length in 2..5 }
            }
        }.distinct()
}
