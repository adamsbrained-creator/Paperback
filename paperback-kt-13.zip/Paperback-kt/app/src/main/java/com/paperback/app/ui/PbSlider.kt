package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import com.paperback.app.ui.theme.Coral

/**
 * Paperback's slider: a slim rounded track, coral fill and a round coral handle, instead of Material's stock one.
 * Tap anywhere on it or drag. [onValueChangeFinished] fires when the finger lifts.
 */
@Composable
fun PbSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    trackColor: Color,
    modifier: Modifier = Modifier,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    fillColor: Color = Coral,
    onValueChangeFinished: (() -> Unit)? = null,
) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    val change by rememberUpdatedState(onValueChange)
    val finished by rememberUpdatedState(onValueChangeFinished)
    val span = (valueRange.endInclusive - valueRange.start).takeIf { it > 0f } ?: 1f
    val fraction = ((value - valueRange.start) / span).coerceIn(0f, 1f)

    Box(
        modifier
            .fillMaxWidth()
            .height(36.dp)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(valueRange) {
                val edge = 10.dp.toPx() // the handle's radius: the ends of the track stop here
                fun toValue(x: Float): Float {
                    val usable = (widthPx - 2f * edge).coerceAtLeast(1f)
                    val f = ((x - edge) / usable).coerceIn(0f, 1f)
                    return valueRange.start + f * span
                }
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    change(toValue(down.position.x))
                    drag(down.id) { pointer ->
                        pointer.consume()
                        change(toValue(pointer.position.x))
                    }
                    finished?.invoke()
                }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val edge = 10.dp.toPx()
            val trackH = 6.dp.toPx()
            val cy = size.height / 2f
            val left = edge
            val usable = (size.width - 2f * edge).coerceAtLeast(1f)
            val x = left + usable * fraction
            drawRoundRect(
                color = trackColor,
                topLeft = Offset(left, cy - trackH / 2f),
                size = Size(usable, trackH),
                cornerRadius = CornerRadius(trackH / 2f),
            )
            if (x > left) {
                drawRoundRect(
                    color = fillColor,
                    topLeft = Offset(left, cy - trackH / 2f),
                    size = Size(x - left, trackH),
                    cornerRadius = CornerRadius(trackH / 2f),
                )
            }
            drawCircle(fillColor, radius = edge, center = Offset(x, cy))
        }
    }
}
