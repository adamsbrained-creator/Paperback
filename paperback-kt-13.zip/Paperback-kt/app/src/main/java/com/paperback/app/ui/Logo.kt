package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private val LogoCoral = Color(0xFFF2674A)

/**
 * Paperback logo, option A: "Bookmark p" (components/paperback/Logo.tsx). The letter p, with its stem cut
 * like a ribbon bookmark, on a 64 x 64 grid.
 */
@Composable
fun LogoMark(size: Dp, color: Color = Color.White, modifier: Modifier = Modifier) {
    val stem = remember { PathParser().parsePathString("M17 6H27V58L22 51L17 58Z").toPath() }
    Canvas(modifier.size(size)) {
        scale(this.size.width / 64f, pivot = Offset.Zero) {
            translate(left = -5f, top = 0f) {
                drawPath(stem, color, style = Fill)
                drawCircle(color, radius = 15f, center = Offset(37f, 26f), style = Stroke(width = 10f))
            }
        }
    }
}

/** The app icon: the white mark on a coral rounded square. */
@Composable
fun LogoTile(size: Dp = 120.dp, radius: Dp = size * 0.225f, markSize: Dp = size * 0.633f, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier
            .size(size)
            .shadow(14.dp, shape, ambientColor = Color(0x52F2674A), spotColor = Color(0x52F2674A))
            .clip(shape)
            .background(LogoCoral)
            .semantics { contentDescription = "Paperback" },
        contentAlignment = Alignment.Center,
    ) {
        LogoMark(markSize)
    }
}
