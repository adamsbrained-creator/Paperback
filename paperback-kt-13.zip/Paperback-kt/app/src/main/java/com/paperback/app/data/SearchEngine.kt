package com.paperback.app.data

import java.text.Normalizer

/**
 * The matching behind the Search page. Pure functions, no Android.
 *
 * Search ignores capitals and accents ("garcia" finds "García") and every word you type has to match
 * (so "dune herbert" finds Dune by Frank Herbert). Folding is done one character at a time, so the folded
 * text is always exactly as long as the original and match positions can be used to highlight it.
 */
object Search {
    fun fold(s: String): String {
        val out = StringBuilder(s.length)
        for (c in s) {
            val decomposed = Normalizer.normalize(c.toString(), Normalizer.Form.NFD)
            out.append((if (decomposed.isNotEmpty()) decomposed[0] else c).lowercaseChar())
        }
        return out.toString()
    }

    /** The words of a query, folded. Empty when there is nothing to search for. */
    fun tokens(query: String): List<String> =
        fold(query).split(' ', '\t', '\n').filter { it.isNotBlank() }

    fun matches(text: String, tokens: List<String>): Boolean {
        if (tokens.isEmpty()) return false
        val f = fold(text)
        return tokens.all { it in f }
    }

    /** Where the words occur in [text] (touching or overlapping spots merged), for highlighting. */
    fun ranges(text: String, tokens: List<String>): List<IntRange> {
        if (tokens.isEmpty()) return emptyList()
        val f = fold(text)
        val found = mutableListOf<IntRange>()
        for (t in tokens) {
            var i = f.indexOf(t)
            while (i >= 0) {
                found += i until i + t.length
                i = f.indexOf(t, i + t.length)
            }
        }
        val out = mutableListOf<IntRange>()
        for (r in found.sortedBy { it.first }) {
            val last = out.lastOrNull()
            if (last != null && r.first <= last.last + 1) {
                out[out.lastIndex] = last.first..maxOf(last.last, r.last)
            } else {
                out += r
            }
        }
        return out
    }

    /** A short piece of [text] around the first match, with "…" where it was cut. */
    fun snippet(text: String, tokens: List<String>, before: Int = 50, after: Int = 140): String {
        val flat = text.replace(Regex("\\s+"), " ").trim()
        val first = ranges(flat, tokens).firstOrNull()?.first ?: 0
        val start = (first - before).coerceAtLeast(0)
        val end = minOf(flat.length, start + before + after)
        return (if (start > 0) "\u2026" else "") + flat.substring(start, end) + (if (end < flat.length) "\u2026" else "")
    }

    class BookHit(val book: Book, val score: Int, val viaJournal: Boolean)

    /** Books whose title, author, genres or journal match, best first. */
    fun books(books: List<Book>, tokens: List<String>): List<BookHit> {
        if (tokens.isEmpty()) return emptyList()
        val hits = mutableListOf<BookHit>()
        for (b in books) {
            val title = fold(b.title)
            val author = fold(b.author)
            val journal = fold(b.journal)
            val tags = fold(b.tags.joinToString(" "))
            val inTitle = tokens.all { it in title }
            val inTitleOrAuthor = tokens.all { it in title || it in author }
            val inTags = tokens.all { it in title || it in author || it in tags }
            val inAnything = tokens.all { it in title || it in author || it in tags || it in journal }
            val score = when {
                inTitle -> 300 + if (title.startsWith(tokens.first())) 100 else 0
                inTitleOrAuthor -> 200
                inTags -> 150
                inAnything -> 100
                else -> 0
            }
            if (score > 0) hits += BookHit(b, score, viaJournal = score == 100)
        }
        return hits.sortedWith(compareByDescending<BookHit> { it.score }.thenBy { it.book.title.lowercase() })
    }

    /** Highlights and notes whose passage or note text matches, newest first (the list is already newest first). */
    fun notes(highlights: List<Highlight>, tokens: List<String>): List<Highlight> =
        if (tokens.isEmpty()) emptyList() else highlights.filter { matches(it.text + " " + it.note, tokens) }
}
