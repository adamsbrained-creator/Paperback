package com.paperback.app.data

import kotlin.math.max
import kotlin.math.roundToInt

/** One line of the contents, reduced to what the reader's header and footer need: its title and which file of the book it starts in. */
class TocRef(val title: String, val resource: Int)

/**
 * Where you are inside a chapter, in the way Readest's footer counts it: "pages left in chapter" counts real
 * screens (it drops by one for every page you turn), while the "2 / 196" counter counts fixed-size chunks of
 * text (Readium "positions"), so it can jump by two for one turn. Plain Kotlin so it can be tested on its own.
 */
object ReaderPlace {
    /**
     * The contents entry you are in: the one that starts latest at or before [resource] (the file you are reading).
     * If several entries start in that same file, the first of them. -1 when the contents has nothing before here.
     */
    fun chapterIndex(toc: List<TocRef>, resource: Int): Int {
        var found = -1
        for ((i, e) in toc.withIndex()) {
            if (e.resource < 0 || e.resource > resource) continue
            if (found < 0 || e.resource > toc[found].resource) found = i
        }
        return found
    }

    /** The first file after the chapter (the next entry that starts in a later file), or [resourceCount] for the last chapter. */
    fun chapterEnd(toc: List<TocRef>, chapter: Int, resourceCount: Int): Int {
        val start = toc[chapter].resource
        return toc.filter { it.resource > start }.minOfOrNull { it.resource } ?: resourceCount
    }

    /** Which screen of the file you are on (0 = the first), from Readium's 0..1 progression through the file. */
    fun screenIndex(progression: Double, screens: Int): Int =
        if (screens <= 0) 0 else (progression * screens).roundToInt().coerceIn(0, screens - 1)

    /** How many screens of the file [resource] there are, per position, applied to the files that come after it in the chapter. */
    fun pagesLeft(screens: Int, screenIndex: Int, positionsHere: Int, positionsAfter: Int): Int {
        if (screens <= 0) return 0
        val here = screens - screenIndex.coerceIn(0, screens - 1) // the screen you are on counts, like in Readest
        val perPosition = if (positionsHere > 0) screens.toDouble() / positionsHere else 0.0
        return max(1, here + (positionsAfter * perPosition).roundToInt())
    }

    /** Positions in the files after [resource] up to (not including) [end]. */
    fun positionsAfter(positionsPerResource: List<Int>, resource: Int, end: Int): Int {
        var sum = 0
        for (r in (resource + 1) until minOf(end, positionsPerResource.size)) sum += positionsPerResource[r]
        return sum
    }
}
