package com.paperback.app.data

import android.content.Context

/** The last few things you searched for, kept on the phone. */
class SearchHistory(context: Context) {
    private val sp = context.getSharedPreferences("search", Context.MODE_PRIVATE)

    fun recent(): List<String> =
        sp.getString("recent", "").orEmpty().split('\n').filter { it.isNotBlank() }

    /** Remembers [query] at the top of the list and returns the new list. Very short searches are ignored. */
    fun add(query: String): List<String> {
        val q = query.trim().replace('\n', ' ')
        if (q.length < 2) return recent()
        val next = (listOf(q) + recent().filterNot { it.equals(q, ignoreCase = true) }).take(MAX)
        sp.edit().putString("recent", next.joinToString("\n")).apply()
        return next
    }

    fun clear() {
        sp.edit().remove("recent").apply()
    }

    private companion object {
        const val MAX = 8
    }
}
