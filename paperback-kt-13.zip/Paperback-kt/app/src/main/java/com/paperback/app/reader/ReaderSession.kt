package com.paperback.app.reader

import com.paperback.app.data.Book
import org.readium.r2.navigator.epub.EpubNavigatorFactory
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.Publication

/** What the PDF viewer needs: the book and the page (1-based) to open on. */
class PdfSession(val book: Book, val startPage: Int)

/** Everything ReaderActivity needs, prepared before it starts (the Readium fragment factory must exist in onCreate). */
class ReaderSession(
    val book: Book,
    val publication: Publication,
    val navigatorFactory: EpubNavigatorFactory,
    val initialLocator: Locator?,
    val totalPositions: Int,
)
