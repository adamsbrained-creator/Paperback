package com.paperback.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.paperback.app.data.HeaderSize

/**
 * Like [PbPage], but for screens that scroll a long list themselves (a lazy list can't sit inside PbPage's
 * scrolling column). Same header, same 560 dp width. Give the list `Modifier.weight(1f)` and bottom padding
 * of about 112 dp so the last row clears the round menu button.
 */
@Composable
fun PbListPage(
    label: String,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier
                .widthIn(max = 560.dp)
                .fillMaxSize()
                .padding(horizontal = 20.dp),
        ) {
            PageHeader(label = label, size = headerSize, onMenu = onMenu, onSearch = onSearch)
            content()
        }
    }
}
