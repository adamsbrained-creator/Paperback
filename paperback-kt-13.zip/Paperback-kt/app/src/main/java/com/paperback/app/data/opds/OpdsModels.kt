package com.paperback.app.data.opds

/** Link relations from the OPDS spec that Discover looks for. */
object Rel {
    const val ACQUISITION = "http://opds-spec.org/acquisition"
    const val OPEN_ACCESS = "http://opds-spec.org/acquisition/open-access"
    const val FACET = "http://opds-spec.org/facet"
    const val GROUP = "http://opds-spec.org/group"
    val COVER = listOf("http://opds-spec.org/image", "http://opds-spec.org/cover", "x-stanza-cover-image")
    val THUMBNAIL = listOf("http://opds-spec.org/image/thumbnail", "http://opds-spec.org/thumbnail", "x-stanza-cover-image-thumbnail")
}

/** One link. [href] is already absolute (the parser resolves it against the address the feed came from). */
data class OpdsLink(
    val href: String,
    val rels: List<String> = emptyList(),
    val type: String? = null,
    val title: String? = null,
    val templated: Boolean = false,
    val count: Int? = null,
    val active: Boolean = false,
    val facetGroup: String? = null,
    /** Media types named by `indirectAcquisition` (a download that goes through another document first). */
    val indirect: List<String> = emptyList(),
) {
    fun hasRel(rel: String): Boolean = rels.contains(rel)
    val isAcquisition: Boolean get() = rels.any { it.startsWith(Rel.ACQUISITION) }
    val isCover: Boolean get() = rels.any { it in Rel.COVER }
    val isThumbnail: Boolean get() = rels.any { it in Rel.THUMBNAIL }
    val isImage: Boolean get() = isCover || isThumbnail

    /** An acquisition we can simply download: free ("open access") or plain. Buying, borrowing and samples are not. */
    val isDirectAcquisition: Boolean
        get() = rels.any { it == Rel.ACQUISITION || it == Rel.OPEN_ACCESS || it == "http://opds-spec.org/acquisition/" }
}

data class OpdsPublication(
    val id: String?,
    val title: String,
    val subtitle: String? = null,
    val authors: List<String> = emptyList(),
    /** Raw description as the feed gave it (may hold HTML). Use [OpdsText.plain] to show it. */
    val summary: String? = null,
    val publisher: String? = null,
    val published: String? = null,
    val updated: String? = null,
    val languages: List<String> = emptyList(),
    val identifier: String? = null,
    val subjects: List<String> = emptyList(),
    val links: List<OpdsLink> = emptyList(),
    val images: List<OpdsLink> = emptyList(),
) {
    val acquisitionLinks: List<OpdsLink> get() = links.filter { it.isAcquisition }

    /** The cover to show: full size first, then the thumbnail, then any image. */
    val coverUrl: String?
        get() = (images.firstOrNull { it.isCover } ?: images.firstOrNull { it.isThumbnail } ?: images.firstOrNull())?.href

    /** The small picture for grids: thumbnail first. */
    val thumbnailUrl: String?
        get() = (images.firstOrNull { it.isThumbnail } ?: images.firstOrNull { it.isCover } ?: images.firstOrNull())?.href

    /**
     * Where the full record of this book can be fetched, when the feed only lists a summary. Either the entry's own
     * document (`rel="self"`) or, for catalogs like Project Gutenberg whose lists link every book to its own page, the
     * link to that page.
     */
    val detailLink: OpdsLink?
        get() {
            links.firstOrNull { l ->
                l.hasRel("self") && l.type?.let { it.contains("opds-publication+json") || (it.contains("atom+xml") && it.contains("entry")) } == true
            }?.let { return it }
            if (acquisitionLinks.isNotEmpty()) return null
            return links.firstOrNull { l ->
                !l.isImage && !l.isAcquisition && !l.hasRel("self") && !l.hasRel("search") &&
                    l.type?.let { it.contains("opds") || it.contains("atom+xml") } == true
            }
        }
}

data class OpdsNav(val title: String, val href: String, val summary: String?, val count: Int?)

data class OpdsGroup(
    val title: String,
    val moreHref: String?,
    val navigation: List<OpdsNav>,
    val publications: List<OpdsPublication>,
)

data class OpdsFacet(val title: String?, val links: List<OpdsLink>)

data class OpdsFeed(
    val title: String?,
    val subtitle: String?,
    val links: List<OpdsLink>,
    val navigation: List<OpdsNav>,
    val publications: List<OpdsPublication>,
    val groups: List<OpdsGroup>,
    val facets: List<OpdsFacet>,
) {
    /** The first / previous / next / last page links of a long list. */
    fun page(rel: String): OpdsLink? = links.firstOrNull { it.hasRel(rel) }

    val searchLink: OpdsLink?
        get() = links.firstOrNull { l ->
            l.hasRel("search") && l.type?.let {
                it.contains("opensearchdescription") || it.contains("atom+xml") || (it.contains("opds+json") && l.templated)
            } == true
        }

    val isEmpty: Boolean get() = navigation.isEmpty() && publications.isEmpty() && groups.isEmpty()
}

data class OpdsSearchTemplate(val type: String?, val template: String)

/** What a downloaded OPDS document turned out to be. */
sealed interface OpdsDoc {
    data class Feed(val feed: OpdsFeed) : OpdsDoc
    data class Entry(val publication: OpdsPublication) : OpdsDoc
    data class OpenSearch(val templates: List<OpdsSearchTemplate>) : OpdsDoc

    /** A normal web page that says where its OPDS feed is. */
    data class Redirect(val href: String) : OpdsDoc
}
