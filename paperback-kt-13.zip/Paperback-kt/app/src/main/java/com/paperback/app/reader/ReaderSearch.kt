package com.paperback.app.reader

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsIgnoringVisibility
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.ui.PbField
import com.paperback.app.ui.PbIconName
import com.paperback.app.ui.theme.PbSerif

private val Spaces = Regex("\\s+")

/** Search inside the open book: type, press search on the keyboard, tap a result to jump to it. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderSearchPanel(
    themeIndex: Int,
    ui: SearchUi,
    onQuery: (String) -> Unit,
    onSubmit: () -> Unit,
    onGo: (SearchHit) -> Unit,
    onClose: () -> Unit,
) {
    val c = readerColors(themeIndex)
    val focus = LocalFocusManager.current
    val requester = remember { FocusRequester() }
    BackHandler(onBack = onClose)
    LaunchedEffect(Unit) { if (ui.query.isBlank()) runCatching { requester.requestFocus() } }

    Column(
        Modifier
            .fillMaxSize()
            .background(c.page)
            // swallow touches so nothing reaches the book underneath
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
            .windowInsetsPadding(WindowInsets.systemBarsIgnoringVisibility)
            .imePadding()
            .padding(horizontal = 20.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Search in book",
                modifier = Modifier.weight(1f),
                color = c.ink,
                fontFamily = PbSerif,
                fontSize = 24.sp,
                fontWeight = FontWeight.Medium,
            )
            Pill(c, "Done", onClick = onClose)
        }
        PbField(
            value = ui.query,
            onValueChange = onQuery,
            placeholder = "Search this book",
            modifier = Modifier.focusRequester(requester),
            leading = PbIconName.Search,
            onClear = { onQuery("") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focus.clearFocus()
                onSubmit()
            }),
            container = c.chip,
            ink = c.ink,
        )
        Spacer(Modifier.height(10.dp))

        val status = when {
            ui.error != null -> ui.error
            ui.running -> if (ui.hits.isEmpty()) "Searching…" else "Searching… ${ui.hits.size} so far"
            ui.done && ui.hits.isEmpty() -> "Nothing found for “${ui.query.trim()}”."
            ui.done && ui.capped -> "Showing the first ${ui.hits.size} matches. Try a longer search."
            ui.done -> "${ui.hits.size} ${if (ui.hits.size == 1) "match" else "matches"}"
            else -> "Type at least two letters, then press search."
        }
        Text(status.orEmpty(), color = c.ink.copy(alpha = 0.6f), fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))

        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(ui.hits) { _, hit ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            focus.clearFocus()
                            onGo(hit)
                        }
                        .padding(vertical = 12.dp),
                ) {
                    val where = buildString {
                        if (!hit.chapter.isNullOrBlank()) append(hit.chapter).append(" · ")
                        append("${(hit.progress * 100).toInt().coerceIn(0, 100)}% into the book")
                    }
                    Text(where, color = c.ink.copy(alpha = 0.5f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        buildAnnotatedString {
                            append("…" + hit.before.replace(Spaces, " ").takeLast(70).trimStart())
                            withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)) {
                                append(hit.hit.replace(Spaces, " "))
                            }
                            append(hit.after.replace(Spaces, " ").take(90).trimEnd() + "…")
                        },
                        color = c.ink,
                        fontSize = 15.sp,
                        lineHeight = 21.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}
