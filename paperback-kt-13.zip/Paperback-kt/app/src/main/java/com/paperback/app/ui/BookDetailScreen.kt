package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.BookCollection
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/** One book: rating, favorite / finished, time read, collections, notes, journal. Reached from Library (long-press -> Details) or Home. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookDetailScreen(
    book: Book,
    sessions: List<ReadingSession>,
    collections: List<BookCollection>,
    membership: Map<String, Set<String>>,
    noteCount: Int,
    bookmarkCount: Int,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onRead: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleFinished: () -> Unit,
    onRate: (Int) -> Unit,
    onSaveJournal: (String) -> Unit,
    onToggleCollection: (BookCollection) -> Unit,
    onOpenNotes: () -> Unit,
    onRemove: () -> Unit,
    similar: List<Book>,
    onOpenBook: (Book) -> Unit,
    onOpenTag: (String) -> Unit,
    onOpenAuthor: (String) -> Unit,
) {
    val t = pbTokens()
    val mine = remember(sessions, book.id) { sessions.filter { it.bookId == book.id } }
    val seconds = mine.sumOf { it.seconds.toLong() }
    var journal by remember(book.id, book.journal) { mutableStateOf(book.journal) }
    var confirmRemove by remember { mutableStateOf(false) }
    var descOpen by remember(book.id) { mutableStateOf(false) }
    val added = remember(book.addedAt) {
        Instant.ofEpochMilli(book.addedAt).atZone(ZoneId.systemDefault()).toLocalDate()
            .format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
    }

    PbPage("Book", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            BookCover(book, Modifier.width(176.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text(
            book.title,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            color = t.ink,
            fontFamily = PbSerif,
            fontSize = 26.sp,
            lineHeight = 32.sp,
            fontWeight = FontWeight.Medium,
        )
        if (book.author.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                book.author,
                modifier = Modifier.fillMaxWidth().clickable { onOpenAuthor(book.author) },
                textAlign = TextAlign.Center,
                color = t.setSub,
                fontSize = 16.sp,
            )
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            (1..5).forEach { i ->
                Text(
                    if (i <= book.rating) "\u2605" else "\u2606",
                    fontSize = 32.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable { onRate(if (book.rating == i) 0 else i) }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        PbButton(
            when {
                book.isReading -> "Resume reading"
                book.finished -> "Read again"
                else -> "Start reading"
            },
            onClick = onRead,
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TogglePill("Favorite", book.favorite, Modifier.weight(1f), onToggleFavorite)
            TogglePill("Finished", book.finished, Modifier.weight(1f), onToggleFinished)
        }

        if (book.tags.isNotEmpty()) {
            SectionLabel("Genres")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                book.tags.forEach { tag -> TagChip(tag) { onOpenTag(tag) } }
            }
        }

        if (book.description.isNotBlank()) {
            SectionLabel("About this book")
            val long = book.description.length > 260
            Text(
                book.description,
                color = t.ink,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                maxLines = if (descOpen || !long) Int.MAX_VALUE else 5,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            if (long) {
                Text(
                    if (descOpen) "Show less" else "Read more",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { descOpen = !descOpen }.padding(horizontal = 4.dp, vertical = 8.dp),
                )
            }
        }

        SectionLabel("This book")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Progress", "${book.percent}%", Modifier.weight(1f))
            StatTile("Time read", Stats.duration(seconds), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(
                "Page",
                if (book.totalPositions > 0) "${book.position} / ${book.totalPositions}" else "\u2014",
                Modifier.weight(1f),
            )
            StatTile("Sessions", "${mine.size}", Modifier.weight(1f))
        }

        SectionLabel("Collections")
        if (collections.isEmpty()) {
            PbNote("No collections yet. Make one from the menu \u2192 Collections.")
        } else {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                collections.forEach { c ->
                    TogglePill(c.name, membership[c.id]?.contains(book.id) == true) { onToggleCollection(c) }
                }
            }
        }

        SetGroup(
            "NOTES",
            listOf(
                SetRowDef(PbIconName.Bookmark, "Notes & bookmarks", "${noteCount + bookmarkCount}", onOpenNotes),
            ),
        )

        SectionLabel("Journal")
        PbField(
            value = journal,
            onValueChange = { journal = it },
            placeholder = "Your thoughts on this book",
            singleLine = false,
            minLines = 4,
        )
        if (journal != book.journal) {
            Spacer(Modifier.height(10.dp))
            PbButton("Save journal", onClick = { onSaveJournal(journal.trim()) })
        }

        SectionLabel("About")
        PbCard {
            InfoRow("Added", added)
            if (book.language.isNotBlank()) {
                CardDivider(18.dp)
                InfoRow("Language", book.language.uppercase())
            }
            if (book.totalPositions > 0) {
                CardDivider(18.dp)
                InfoRow("Length", "${book.totalPositions} pages")
            }
            if (book.publisher.isNotBlank()) {
                CardDivider(18.dp)
                InfoRow("Publisher", book.publisher)
            }
            if (book.published.isNotBlank()) {
                CardDivider(18.dp)
                InfoRow("Published", book.published)
            }
        }

        if (similar.isNotEmpty()) {
            SectionLabel("Similar in your library")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
                items(similar, key = { it.id }) { b ->
                    Column(Modifier.width(96.dp).clickable { onOpenBook(b) }) {
                        BookCover(b)
                        Spacer(Modifier.height(6.dp))
                        Text(b.title, color = t.ink, fontSize = 12.sp, lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        Spacer(Modifier.height(28.dp))
        PbButton("Remove from library", onClick = { confirmRemove = true }, ghost = true, destructive = true)
    }

    if (confirmRemove) {
        PbConfirmDialog(
            title = "Remove this book?",
            message = "The book file is deleted from Paperback. Your reading history stays in your stats.",
            confirm = "Remove",
            onConfirm = {
                confirmRemove = false
                onRemove()
            },
            onDismiss = { confirmRemove = false },
        )
    }
}
