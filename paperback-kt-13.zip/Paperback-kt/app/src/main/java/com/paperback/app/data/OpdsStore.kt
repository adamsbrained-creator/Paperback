package com.paperback.app.data

import android.content.Context
import com.paperback.app.data.opds.OpdsAuth
import com.paperback.app.data.opds.OpdsUrl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** An online catalog (OPDS feed) that Discover can open. */
data class Catalog(
    val id: String,
    val name: String,
    val url: String,
    val note: String,
    val username: String = "",
    val password: String = "",
    val builtIn: Boolean = false,
) {
    /** The login to send, or null when the catalog is open. */
    val auth: OpdsAuth? get() = if (username.isNotEmpty() || password.isNotEmpty()) OpdsAuth(username, password) else null
}

/**
 * The catalogs Discover lists: two free public-domain libraries that are always there (the same presets the
 * TypeScript app showed), plus the person's own (Calibre, Kavita, a library server...), kept on this device.
 * Also remembers which downloaded book came from which catalog entry, so the book page can say "Open & Read".
 */
class OpdsStore(context: Context) {
    private val sp = context.getSharedPreferences("opds", Context.MODE_PRIVATE)
    private val sources = context.getSharedPreferences("opds_sources", Context.MODE_PRIVATE)

    private val presets = listOf(
        Catalog(
            id = "paperback-gutenberg", name = "Project Gutenberg", url = "https://www.gutenberg.org/ebooks.opds/",
            note = "Over 70,000 free classics", builtIn = true,
        ),
        Catalog(
            id = "paperback-standard", name = "Standard Ebooks", url = "https://standardebooks.org/feeds/opds",
            note = "Carefully formatted public-domain books", builtIn = true,
        ),
    )

    private var mine: List<Catalog> = load()
    private val _catalogs = MutableStateFlow(combine())
    val catalogs: StateFlow<List<Catalog>> = _catalogs.asStateFlow()

    private fun combine(): List<Catalog> {
        val urls = mine.map { it.url }.toSet()
        return mine + presets.filter { it.url !in urls }
    }

    private fun load(): List<Catalog> {
        val text = sp.getString("catalogs", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(text)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Catalog(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    url = o.getString("url"),
                    note = o.optString("note", "Your catalog"),
                    username = o.optString("username", ""),
                    password = o.optString("password", ""),
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun save() {
        val arr = JSONArray()
        mine.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id).put("name", c.name).put("url", c.url).put("note", c.note)
                    .put("username", c.username).put("password", c.password),
            )
        }
        sp.edit().putString("catalogs", arr.toString()).apply()
        _catalogs.value = combine()
    }

    /** Adds a catalog, or changes the one with [id]. Returns an error message, or null when it was saved. */
    fun upsert(id: String?, name: String, address: String, username: String, password: String): String? {
        val url = normalizeAddress(address) ?: return "That does not look like a web address."
        val cleanName = name.trim().ifEmpty { OpdsUrl.hostOf(url) ?: "My catalog" }
        if (id == null && (mine + presets).any { it.url == url }) return "That catalog is already in the list."
        val entry = Catalog(
            id = id ?: ("my-" + UUID.randomUUID().toString().take(8)),
            name = cleanName, url = url, note = "Your catalog",
            username = username.trim(), password = password,
        )
        mine = if (id == null) mine + entry else mine.map { if (it.id == id) entry else it }
        save()
        return null
    }

    fun remove(id: String) {
        mine = mine.filter { it.id != id }
        save()
    }

    /** "books.local:8083/opds" -> "http://books.local:8083/opds"; names on the home network (no dots, .local, numbers) use http, the rest https. */
    fun normalizeAddress(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty()) return null
        if (!s.contains("://")) {
            val host = s.substringBefore('/').substringBefore(':')
            val local = !host.contains('.') || host.endsWith(".local") || Regex("^[0-9.]+$").matches(host)
            s = (if (local) "http://" else "https://") + s
        }
        if (!OpdsUrl.isHttp(s)) return null
        val host = OpdsUrl.hostOf(s)
        return if (host.isNullOrEmpty()) null else s
    }

    // ---- which downloaded book came from where -----------------------------------------------

    fun rememberSource(catalogId: String, keys: List<String>, bookId: String) {
        val e = sources.edit()
        keys.filter { it.isNotBlank() }.forEach { e.putString("$catalogId|$it", bookId) }
        e.apply()
    }

    fun findSource(catalogId: String, keys: List<String>): String? =
        keys.filter { it.isNotBlank() }.firstNotNullOfOrNull { sources.getString("$catalogId|$it", null) }
}
