package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.Goals
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.LocalPbDark
import com.paperback.app.ui.theme.pbTokens
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private class Accent(val color: Color)

@Composable
private fun accent(name: String): Accent {
    val dark = LocalPbDark.current
    return Accent(
        when (name) {
            "blue" -> if (dark) Color(0xFF7C9CFF) else Color(0xFF5B7DF5)
            "yellow" -> if (dark) Color(0xFFFFD666) else Color(0xFFD99A06)
            "pink" -> if (dark) Color(0xFFFF7EB6) else Color(0xFFEC4F92)
            else -> if (dark) Color(0xFF5CF2B0) else Color(0xFF10B981)
        },
    )
}

@Composable
private fun GoalRow(title: String, value: String, fraction: Float, color: Color) {
    val t = pbTokens()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Text(title, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Box(Modifier.padding(top = 14.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(9.dp)).background(t.ink.copy(alpha = 0.08f))) {
            val f = fraction.coerceIn(0f, 1f)
            if (f > 0f) Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(9.dp)).background(color))
        }
    }
}

@Composable
private fun NumberField(value: String, onChange: (String) -> Unit) {
    val t = pbTokens()
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .width(96.dp)
            .height(46.dp)
            .clip(shape)
            .background(t.ink.copy(alpha = 0.06f))
            .border(1.dp, t.ink.copy(alpha = 0.07f), shape),
        contentAlignment = Alignment.Center,
    ) {
        BasicTextField(
            value = value,
            onValueChange = { text -> onChange(text.filter { ch -> ch.isDigit() }.take(5)) },
            singleLine = true,
            textStyle = TextStyle(color = t.ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            cursorBrush = SolidColor(t.ink),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
        )
    }
}

private class GoalField(val label: String, val unit: String)

private val FIELDS = listOf(
    GoalField("Books this year", "books"),
    GoalField("Pages per day", "pages"),
    GoalField("Minutes per day", "min"),
    GoalField("Reading streak", "days"),
)

/** The books-goal pace line: finished against what a straight line through the year predicts (booksPace in statsAggregate.ts). */
private fun paceLabel(finished: Int, goal: Int): String {
    val zone = ZoneId.systemDefault()
    val year = LocalDate.now().year
    val start = LocalDate.of(year, 1, 1).atStartOfDay(zone).toInstant().toEpochMilli()
    val end = LocalDate.of(year + 1, 1, 1).atStartOfDay(zone).toInstant().toEpochMilli()
    val elapsed = (System.currentTimeMillis() - start).toDouble() / (end - start).toDouble()
    val expected = Math.floor(goal * elapsed).toInt()
    val delta = finished - expected
    val left = (goal - finished).coerceAtLeast(0)
    val status = if (delta >= 0) "on pace" else "${-delta} behind"
    return "$left to go · $status"
}

/** Reading goals: this year's books, today's pages and minutes, the streak, and editing them. */
@Composable
fun GoalsScreen(
    headerSize: HeaderSize,
    goals: Goals,
    books: List<Book>,
    sessions: List<ReadingSession>,
    onSave: (Goals) -> Unit,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val t = pbTokens()
    val mint = accent("mint").color
    val blue = accent("blue").color
    val yellow = accent("yellow").color
    val pink = accent("pink").color

    val today = LocalDate.now()
    val zone = ZoneId.systemDefault()
    val todays = sessions.filter { Instant.ofEpochMilli(it.startMs).atZone(zone).toLocalDate() == today }
    val pagesToday = todays.sumOf { it.pages }
    val secondsToday = todays.sumOf { it.seconds.toLong() }
    val byDay = Stats.secondsByDay(sessions)
    val streak = Stats.currentStreak(byDay, today)
    // A finished book counts for the year it was finished (books finished before that date was saved use when they were last opened).
    val finished = Stats.booksFinishedInYear(books, today.year, zone)
    val booksFraction = (finished.toFloat() / goals.booksPerYear).coerceIn(0f, 1f)

    var draft by remember { mutableStateOf<List<String>?>(null) }

    PbPage("Reading goals", headerSize, onMenu, onSearch, headerGap = 16.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Box(Modifier.size(104.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(104.dp)) {
                        val stroke = 11f * (this.size.width / 104f)
                        val inset = stroke / 2f
                        drawArc(
                            color = t.ink.copy(alpha = 0.08f), startAngle = 0f, sweepAngle = 360f, useCenter = false,
                            topLeft = Offset(inset, inset), size = Size(this.size.width - stroke, this.size.height - stroke),
                            style = Stroke(width = stroke),
                        )
                        if (booksFraction > 0f) {
                            drawArc(
                                color = mint, startAngle = -90f, sweepAngle = 360f * booksFraction, useCenter = false,
                                topLeft = Offset(inset, inset), size = Size(this.size.width - stroke, this.size.height - stroke),
                                style = Stroke(width = stroke, cap = StrokeCap.Round),
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$finished/${goals.booksPerYear}", color = t.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("books", color = t.sub, fontSize = 11.sp)
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text("${today.year} goal", color = t.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (finished >= goals.booksPerYear) "Goal reached" else paceLabel(finished, goals.booksPerYear),
                        modifier = Modifier.padding(top = 4.dp),
                        color = t.sub,
                        fontSize = 14.sp,
                    )
                }
            }

            GoalRow("Pages per day", "$pagesToday / ${goals.pagesPerDay}", pagesToday.toFloat() / goals.pagesPerDay, blue)
            GoalRow(
                "Minutes today",
                "${Stats.duration(secondsToday)} / ${goals.minutesPerDay}m",
                secondsToday / 60f / goals.minutesPerDay,
                yellow,
            )
            GoalRow("Reading streak", "$streak / ${goals.streakDays} days", streak.toFloat() / goals.streakDays, pink)
            GoalRow("Finish by Dec 31", "${Math.round(booksFraction * 100f)}%", booksFraction, mint)

            val d = draft
            if (d != null) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(t.card).padding(18.dp)) {
                    FIELDS.forEachIndexed { i, f ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column {
                                Text(f.label, color = t.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                Text(f.unit, color = t.sub, fontSize = 13.sp)
                            }
                            NumberField(d[i]) { text -> draft = d.toMutableList().also { it[i] = text } }
                        }
                    }
                    Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PbButton("Save goals", {
                            // An empty or zero box keeps the goal it had before.
                            fun n(i: Int, old: Int): Int = d[i].toIntOrNull()?.takeIf { it > 0 } ?: old
                            onSave(
                                Goals(
                                    booksPerYear = n(0, goals.booksPerYear),
                                    pagesPerDay = n(1, goals.pagesPerDay),
                                    minutesPerDay = n(2, goals.minutesPerDay),
                                    streakDays = n(3, goals.streakDays),
                                ),
                            )
                            draft = null
                        })
                        PbButton("Cancel", { draft = null }, ghost = true)
                    }
                }
            } else {
                PbButton("Edit goals", {
                    draft = listOf(
                        goals.booksPerYear.toString(),
                        goals.pagesPerDay.toString(),
                        goals.minutesPerDay.toString(),
                        goals.streakDays.toString(),
                    )
                })
            }
        }
    }
}
