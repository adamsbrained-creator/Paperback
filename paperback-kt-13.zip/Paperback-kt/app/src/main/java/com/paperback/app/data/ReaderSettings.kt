package com.paperback.app.data

import android.content.Context
import org.readium.r2.navigator.epub.EpubPreferences
import org.readium.r2.navigator.preferences.FontFamily
import org.readium.r2.navigator.preferences.TextAlign
import org.readium.r2.navigator.preferences.Theme

/**
 * How the page is laid out. While [custom] is off the book keeps its own fonts, spacing and alignment
 * (that is what Readium calls publisher styles); turning it on applies [fontFamily], [lineSpacing] and [justify].
 * [margins] and [brightness] work either way. [brightness] below zero means "follow the phone".
 */
data class ReaderLook(
    val custom: Boolean = false,
    /** 0 = serif, 1 = sans, 2 = mono */
    val fontFamily: Int = 0,
    val lineSpacing: Float = 1.5f,
    val margins: Float = 1.0f,
    val justify: Boolean = true,
    val brightness: Float = -1f,
)

/** The reader choices Paperback remembers. */
class ReaderSettings(context: Context) {
    private val sp = context.getSharedPreferences("reader", Context.MODE_PRIVATE)

    var fontSize: Double
        get() = sp.getFloat("fontSize", 1.0f).toDouble()
        set(v) = sp.edit().putFloat("fontSize", v.toFloat()).apply()

    /** 0 = light, 1 = sepia, 2 = dark */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** PDF viewer: true turns pages right to left (manga). */
    var pdfRtl: Boolean
        get() = sp.getBoolean("pdfRtl", false)
        set(v) = sp.edit().putBoolean("pdfRtl", v).apply()

    var look: ReaderLook
        get() {
            val d = ReaderLook()
            return ReaderLook(
                custom = sp.getBoolean("custom", d.custom),
                fontFamily = sp.getInt("fontFamily", d.fontFamily).coerceIn(0, 2),
                lineSpacing = sp.getFloat("lineSpacing", d.lineSpacing).coerceIn(1.0f, 2.2f),
                margins = sp.getFloat("margins", d.margins).coerceIn(0.5f, 2.5f),
                justify = sp.getBoolean("justify", d.justify),
                brightness = sp.getFloat("brightness", d.brightness),
            )
        }
        set(v) {
            sp.edit()
                .putBoolean("custom", v.custom)
                .putInt("fontFamily", v.fontFamily)
                .putFloat("lineSpacing", v.lineSpacing)
                .putFloat("margins", v.margins)
                .putBoolean("justify", v.justify)
                .putFloat("brightness", v.brightness)
                .apply()
        }

    fun toEpubPreferences(): EpubPreferences {
        val l = look
        return EpubPreferences(
            fontSize = fontSize,
            theme = when (theme) {
                1 -> Theme.SEPIA
                2 -> Theme.DARK
                else -> Theme.LIGHT
            },
            pageMargins = if (l.margins != 1.0f) l.margins.toDouble() else null,
            publisherStyles = if (l.custom) false else null,
            fontFamily = if (l.custom) {
                when (l.fontFamily) {
                    1 -> FontFamily.SANS_SERIF
                    2 -> FontFamily.MONOSPACE
                    else -> FontFamily.SERIF
                }
            } else null,
            lineHeight = if (l.custom) l.lineSpacing.toDouble() else null,
            textAlign = if (l.custom) (if (l.justify) TextAlign.JUSTIFY else TextAlign.START) else null,
        )
    }
}
