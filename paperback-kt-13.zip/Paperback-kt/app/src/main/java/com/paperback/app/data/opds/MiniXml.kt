package com.paperback.app.data.opds

/**
 * One element of a parsed XML document. Names and attribute names have their namespace prefix removed
 * (`dc:language` becomes `language`, `opds:facetGroup` becomes `facetGroup`), which is all OPDS needs.
 */
class XmlNode(val name: String, val attrs: Map<String, String>) {
    val children = ArrayList<XmlNode>()

    /** The text written directly inside this element (not inside its children), entities decoded. */
    val text = StringBuilder()

    /** The raw XML between the start and end tag, for `<content type="xhtml">`. */
    var inner: String = ""

    fun child(name: String): XmlNode? = children.firstOrNull { it.name == name }
    fun all(name: String): List<XmlNode> = children.filter { it.name == name }
    fun attr(name: String): String? = attrs[name]
    fun textOf(name: String): String? = child(name)?.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
}

/**
 * A small, forgiving XML reader. Feeds from home-made catalog servers are often not perfectly well formed
 * (junk after the last tag, stray byte-order marks, a wrong content type), and the browser-style parser the
 * TypeScript app used tolerated all of that, so this one does too: unknown entities are kept as written,
 * unclosed tags are closed by the next matching end tag, and anything after the root element is ignored.
 */
object MiniXml {
    fun parse(source: String): XmlNode? {
        val s = source
        val n = s.length
        var i = 0
        var root: XmlNode? = null
        val stack = ArrayList<XmlNode>()
        val innerStart = ArrayList<Int>()

        while (i < n) {
            val lt = s.indexOf('<', i)
            if (lt < 0) {
                if (stack.isNotEmpty()) stack.last().text.append(decode(s.substring(i)))
                break
            }
            if (lt > i && stack.isNotEmpty()) stack.last().text.append(decode(s.substring(i, lt)))
            i = lt

            when {
                s.startsWith("<!--", i) -> {
                    val end = s.indexOf("-->", i + 4)
                    i = if (end < 0) n else end + 3
                }
                s.startsWith("<![CDATA[", i) -> {
                    val end = s.indexOf("]]>", i + 9)
                    val body = if (end < 0) s.substring(i + 9) else s.substring(i + 9, end)
                    if (stack.isNotEmpty()) stack.last().text.append(body)
                    i = if (end < 0) n else end + 3
                }
                s.startsWith("<?", i) -> {
                    val end = s.indexOf("?>", i + 2)
                    i = if (end < 0) n else end + 2
                }
                s.startsWith("<!", i) -> {
                    // <!DOCTYPE ...>, possibly with an [internal subset]
                    var depth = 0
                    var j = i + 2
                    while (j < n) {
                        val c = s[j]
                        if (c == '[') depth++
                        else if (c == ']') depth--
                        else if (c == '>' && depth <= 0) break
                        j++
                    }
                    i = j + 1
                }
                s.startsWith("</", i) -> {
                    val end = s.indexOf('>', i + 2)
                    val raw = if (end < 0) s.substring(i + 2) else s.substring(i + 2, end)
                    val name = local(raw.trim())
                    // Close the nearest open element with this name; ignore a stray end tag.
                    var k = stack.size - 1
                    while (k >= 0 && stack[k].name != name) k--
                    if (k >= 0) {
                        while (stack.size - 1 >= k) {
                            val node = stack.removeAt(stack.size - 1)
                            val start = innerStart.removeAt(innerStart.size - 1)
                            if (stack.size == k) node.inner = if (start <= i) s.substring(start, i) else ""
                        }
                        if (stack.isEmpty() && root != null) return root
                    }
                    i = if (end < 0) n else end + 1
                }
                else -> {
                    val tag = readTag(s, i)
                    if (tag == null) {
                        i++
                        continue
                    }
                    val node = XmlNode(tag.name, tag.attrs)
                    if (stack.isEmpty()) {
                        if (root == null) root = node else return root
                    } else {
                        stack.last().children.add(node)
                    }
                    if (tag.selfClosing) {
                        if (stack.isEmpty()) return root
                    } else {
                        stack.add(node)
                        innerStart.add(tag.end)
                    }
                    i = tag.end
                }
            }
        }
        return root
    }

    private class Tag(val name: String, val attrs: Map<String, String>, val selfClosing: Boolean, val end: Int)

    private fun readTag(s: String, start: Int): Tag? {
        val n = s.length
        var i = start + 1
        val nameStart = i
        while (i < n && !s[i].isWhitespace() && s[i] != '>' && s[i] != '/') i++
        if (i == nameStart) return null
        val name = local(s.substring(nameStart, i))
        val attrs = LinkedHashMap<String, String>()
        var selfClosing = false
        while (i < n) {
            while (i < n && s[i].isWhitespace()) i++
            if (i >= n) break
            val c = s[i]
            if (c == '>') {
                i++
                break
            }
            if (c == '/') {
                selfClosing = true
                i++
                continue
            }
            val aStart = i
            while (i < n && !s[i].isWhitespace() && s[i] != '=' && s[i] != '>' && s[i] != '/') i++
            val aName = s.substring(aStart, i)
            while (i < n && s[i].isWhitespace()) i++
            var value = ""
            if (i < n && s[i] == '=') {
                i++
                while (i < n && s[i].isWhitespace()) i++
                if (i < n && (s[i] == '"' || s[i] == '\'')) {
                    val q = s[i]
                    val close = s.indexOf(q, i + 1)
                    val stop = if (close < 0) n else close
                    value = decode(s.substring(i + 1, stop))
                    i = if (close < 0) n else close + 1
                } else {
                    val vStart = i
                    while (i < n && !s[i].isWhitespace() && s[i] != '>') i++
                    value = decode(s.substring(vStart, i))
                }
            }
            if (aName.isNotEmpty() && aName != "xmlns" && !aName.startsWith("xmlns:")) {
                val key = local(aName)
                // The first one wins, so `xml:base` never shadows a plain `base`.
                if (!attrs.containsKey(key)) attrs[key] = value
            }
        }
        return Tag(name, attrs, selfClosing, i)
    }

    private fun local(name: String): String = name.substringAfter(':')

    private val named = mapOf(
        "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ",
        "ndash" to "–", "mdash" to "—", "lsquo" to "‘", "rsquo" to "’",
        "ldquo" to "“", "rdquo" to "”", "hellip" to "…", "copy" to "©",
    )

    /** Replaces &amp; &#39; &#x27; and the few named entities catalogs use; anything else stays as written. */
    fun decode(raw: String): String {
        if (raw.indexOf('&') < 0) return raw
        val sb = StringBuilder(raw.length)
        var i = 0
        while (i < raw.length) {
            val c = raw[i]
            if (c != '&') {
                sb.append(c)
                i++
                continue
            }
            val semi = raw.indexOf(';', i + 1)
            if (semi < 0 || semi - i > 10) {
                sb.append(c)
                i++
                continue
            }
            val body = raw.substring(i + 1, semi)
            val rep: String? = when {
                body.startsWith("#x") || body.startsWith("#X") ->
                    body.substring(2).toIntOrNull(16)?.let { codePoint(it) }
                body.startsWith("#") -> body.substring(1).toIntOrNull()?.let { codePoint(it) }
                else -> named[body]
            }
            if (rep == null) {
                sb.append(c)
                i++
            } else {
                sb.append(rep)
                i = semi + 1
            }
        }
        return sb.toString()
    }

    private fun codePoint(cp: Int): String? =
        if (cp in 1..0x10FFFF && cp !in 0xD800..0xDFFF) String(Character.toChars(cp)) else null
}
