package com.paperback.app.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Reading statistics, ported from Paperback's statsAggregate.ts. Pure functions, easy to test. */
object Stats {
    /** A day counts toward a streak after this many seconds of reading. */
    private const val STREAK_MIN_SECONDS = 60L

    fun secondsByDay(sessions: List<ReadingSession>, zone: ZoneId = ZoneId.systemDefault()): Map<LocalDate, Long> =
        sessions
            .groupBy { Instant.ofEpochMilli(it.startMs).atZone(zone).toLocalDate() }
            .mapValues { (_, list) -> list.sumOf { it.seconds.toLong() } }

    fun currentStreak(byDay: Map<LocalDate, Long>, today: LocalDate): Int {
        var day = if ((byDay[today] ?: 0L) >= STREAK_MIN_SECONDS) today else today.minusDays(1)
        var n = 0
        while ((byDay[day] ?: 0L) >= STREAK_MIN_SECONDS) {
            n++
            day = day.minusDays(1)
        }
        return n
    }

    fun longestStreak(byDay: Map<LocalDate, Long>): Int {
        val days = byDay.filterValues { it >= STREAK_MIN_SECONDS }.keys.sorted()
        var best = 0
        var run = 0
        var prev: LocalDate? = null
        for (d in days) {
            run = if (prev != null && prev.plusDays(1) == d) run + 1 else 1
            if (run > best) best = run
            prev = d
        }
        return best
    }

    /** The last [n] days ending today, oldest first. */
    fun lastDays(byDay: Map<LocalDate, Long>, today: LocalDate, n: Int): List<Pair<LocalDate, Long>> =
        (0 until n).map { i ->
            val d = today.minusDays((n - 1 - i).toLong())
            d to (byDay[d] ?: 0L)
        }

    fun secondsByBook(sessions: List<ReadingSession>): Map<String, Long> =
        sessions.groupBy { it.bookId }.mapValues { (_, list) -> list.sumOf { it.seconds.toLong() } }

    /** Average seconds per page (Readium position), or null until there is enough data. */
    fun paceSecondsPerPosition(sessions: List<ReadingSession>): Double? {
        val pages = sessions.sumOf { it.pages }
        val seconds = sessions.sumOf { it.seconds.toLong() }
        if (pages < 20 || seconds < 300) return null
        return (seconds.toDouble() / pages).coerceIn(5.0, 600.0)
    }

    fun timeLeftSeconds(book: Book, pace: Double?): Long? {
        if (pace == null || book.totalPositions <= 0) return null
        val left = (book.totalPositions - book.position).coerceAtLeast(0)
        return (left * pace).toLong()
    }

    fun duration(seconds: Long): String {
        val minutes = (seconds + 30) / 60
        return when {
            minutes <= 0 -> "0m"
            minutes < 60 -> "${minutes}m"
            else -> "${minutes / 60}h ${(minutes % 60).toString().padStart(2, '0')}m"
        }
    }

    /** Books finished in [year]. Books without a saved finish date fall back to when they were last opened (or added). */
    fun booksFinishedInYear(books: List<Book>, year: Int, zone: ZoneId = ZoneId.systemDefault()): Int =
        books.count { b ->
            b.finished && Instant.ofEpochMilli(if (b.finishedAt > 0) b.finishedAt else maxOf(b.lastOpenedAt, b.addedAt))
                .atZone(zone).year == year
        }
}
