package com.paperback.app.data.opds

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/** A catalog's login. Sent only to the catalog's own host, never to a server it redirects to. */
data class OpdsAuth(val username: String, val password: String)

/** The server answered, but not with success. [status] is the HTTP code. */
class OpdsHttpException(val status: Int, message: String) : IOException(message)

class OpdsResponse(val url: String, val contentType: String?, val text: String)

/**
 * The little web client Discover uses (java.net only, so it also runs on a plain JVM for tests).
 * Follows redirects itself (including http -> https, which HttpURLConnection will not do), identifies the app,
 * and logs in with Basic or Digest (Calibre's content server uses Digest) when a catalog has a username.
 */
class OpdsHttp(private val userAgent: String = "Paperback/2.0 (Android; ebook reader)") {
    private class Opened(val conn: HttpURLConnection, val url: String)

    /** Auth style learned per host, so later requests skip the first "401 Unauthorized" round trip. */
    private val learnedBasic: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    fun getText(url: String, auth: OpdsAuth?): OpdsResponse {
        val opened = execute(url, auth, "application/atom+xml, application/opds+json, application/xml;q=0.9, */*;q=0.5")
        try {
            val type = opened.conn.contentType
            val bytes = readLimited(opened.conn.inputStream, MAX_TEXT)
                ?: throw IOException("The catalog sent more data than expected.")
            return OpdsResponse(opened.url, type, String(bytes, charsetOf(type)))
        } finally {
            opened.conn.disconnect()
        }
    }

    /** Fetches a picture. Returns null when it is missing or too large; a cover is never worth an error message. */
    fun getBytes(url: String, auth: OpdsAuth?, limit: Int = MAX_IMAGE): ByteArray? {
        return try {
            val opened = execute(url, auth, "image/*,*/*;q=0.5")
            try {
                readLimited(opened.conn.inputStream, limit)
            } finally {
                opened.conn.disconnect()
            }
        } catch (e: IOException) {
            null
        }
    }

    /** Saves a download to [dest]. [onProgress] gets (bytes so far, total or -1). Returns the final content type. */
    fun download(url: String, auth: OpdsAuth?, dest: File, onProgress: (Long, Long) -> Unit): String? {
        val opened = execute(url, auth, "application/epub+zip, application/octet-stream, */*;q=0.5")
        try {
            val type = opened.conn.contentType
            if (type != null && type.lowercase().startsWith("text/html")) {
                throw IOException("The server sent a web page instead of a book.")
            }
            val total = opened.conn.contentLengthLong
            var done = 0L
            var lastReport = 0L
            opened.conn.inputStream.use { input ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.nanoTime()
                        if (now - lastReport > 100_000_000L) {
                            lastReport = now
                            onProgress(done, total)
                        }
                    }
                }
            }
            onProgress(done, if (total > 0) total else done)
            return type
        } finally {
            opened.conn.disconnect()
        }
    }

    // ---- requests ---------------------------------------------------------------------------

    private fun execute(startUrl: String, auth: OpdsAuth?, accept: String): Opened {
        var url = startUrl
        val authHost = OpdsUrl.hostOf(startUrl)
        var digestChallenge: String? = null
        var triedDigest = false
        var triedBasic = false
        var hops = 0
        var retried = false

        while (true) {
            if (hops++ > MAX_HOPS) throw IOException("Too many redirects.")
            if (!OpdsUrl.isHttp(url)) throw IOException("Unsupported address: $url")
            val conn = URI(OpdsUrl.escape(url)).toURL().openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", userAgent)
            conn.setRequestProperty("Accept", accept)

            val host = OpdsUrl.hostOf(url)
            val login: OpdsAuth? = if (auth != null && host != null && host == authHost) auth else null
            val mayAuth = login != null
            if (login != null) {
                val challenge = digestChallenge
                if (challenge != null) {
                    conn.setRequestProperty("Authorization", digestHeader(challenge, login, "GET", requestUri(url)))
                } else if (host in learnedBasic || triedBasic) {
                    conn.setRequestProperty("Authorization", basicHeader(login))
                }
            }

            val code = try {
                conn.responseCode
            } catch (e: IOException) {
                conn.disconnect()
                throw e
            }

            when (code) {
                in 200..299 -> return Opened(conn, url)
                301, 302, 303, 307, 308 -> {
                    val location = conn.getHeaderField("Location")
                    conn.disconnect()
                    if (location.isNullOrBlank()) throw IOException("The server redirected without saying where.")
                    url = OpdsUrl.resolve(location, url)
                }
                401 -> {
                    val challenge = conn.getHeaderField("WWW-Authenticate") ?: ""
                    conn.disconnect()
                    if (auth == null || !mayAuth) throw OpdsHttpException(401, "This catalog needs a username and password.")
                    when {
                        challenge.startsWith("Digest", true) && !triedDigest -> {
                            triedDigest = true
                            digestChallenge = challenge
                        }
                        !challenge.startsWith("Digest", true) && !triedBasic -> {
                            triedBasic = true
                            host?.let { learnedBasic.add(it) }
                        }
                        else -> throw OpdsHttpException(401, "The username or password was not accepted.")
                    }
                }
                // Busy or rate-limiting servers (Project Gutenberg does this when pages are opened quickly):
                // wait a moment and ask once more before giving up.
                403, 429, 502, 503, 504 -> {
                    val wait = conn.getHeaderField("Retry-After")?.trim()?.toLongOrNull()?.coerceIn(1L, 4L) ?: 1L
                    val message = conn.responseMessage ?: ""
                    conn.disconnect()
                    if (retried) throw OpdsHttpException(code, "The catalog answered $code $message".trim())
                    retried = true
                    try {
                        Thread.sleep(wait * 1000L + 300L)
                    } catch (e: InterruptedException) {
                        throw IOException("Cancelled")
                    }
                }
                else -> {
                    val message = conn.responseMessage ?: ""
                    conn.disconnect()
                    throw OpdsHttpException(code, "The catalog answered $code $message".trim())
                }
            }
        }
    }

    private fun requestUri(url: String): String {
        val u = URI(OpdsUrl.escape(url)).toURL()
        val path = if (u.path.isNullOrEmpty()) "/" else u.path
        return if (u.query != null) "$path?${u.query}" else path
    }

    // ---- reading ----------------------------------------------------------------------------

    private fun readLimited(input: InputStream, limit: Int): ByteArray? {
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val n = stream.read(buf)
                if (n < 0) break
                total += n
                if (total > limit) return null
                out.write(buf, 0, n)
            }
            return out.toByteArray()
        }
    }

    private fun charsetOf(contentType: String?): java.nio.charset.Charset {
        val name = contentType?.let { Regex("charset\\s*=\\s*\"?([A-Za-z0-9_\\-]+)", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }
        return try {
            if (name != null) java.nio.charset.Charset.forName(name) else Charsets.UTF_8
        } catch (e: Exception) {
            Charsets.UTF_8
        }
    }

    companion object {
        private const val MAX_HOPS = 8
        private const val MAX_TEXT = 20 * 1024 * 1024
        const val MAX_IMAGE = 8 * 1024 * 1024

        fun basicHeader(auth: OpdsAuth): String =
            "Basic " + Base64.getEncoder().encodeToString("${auth.username}:${auth.password}".toByteArray(Charsets.UTF_8))

        private fun md5(s: String): String =
            MessageDigest.getInstance("MD5").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

        /** RFC 2617 / 7616 Digest answer to a `WWW-Authenticate: Digest ...` challenge (MD5, qop=auth). */
        fun digestHeader(challenge: String, auth: OpdsAuth, method: String, uri: String, cnonceOverride: String? = null): String {
            val params = HashMap<String, String>()
            Regex("(\\w+)\\s*=\\s*(?:\"([^\"]*)\"|([^,\\s]*))").findAll(challenge.substringAfter(' ')).forEach {
                params[it.groupValues[1].lowercase()] = it.groupValues[2].ifEmpty { it.groupValues[3] }
            }
            val realm = params["realm"] ?: ""
            val nonce = params["nonce"] ?: ""
            val opaque = params["opaque"]
            val algorithm = params["algorithm"] ?: "MD5"
            val qop = params["qop"]?.split(',')?.map { it.trim() }?.firstOrNull { it == "auth" }
            val cnonce = cnonceOverride ?: ByteArray(8).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
            val nc = "00000001"

            var ha1 = md5("${auth.username}:$realm:${auth.password}")
            if (algorithm.equals("MD5-sess", true)) ha1 = md5("$ha1:$nonce:$cnonce")
            val ha2 = md5("$method:$uri")
            val response = if (qop != null) md5("$ha1:$nonce:$nc:$cnonce:$qop:$ha2") else md5("$ha1:$nonce:$ha2")

            return buildString {
                append("Digest username=\"${auth.username}\", realm=\"$realm\", nonce=\"$nonce\", uri=\"$uri\", response=\"$response\"")
                if (opaque != null) append(", opaque=\"$opaque\"")
                append(", algorithm=$algorithm")
                if (qop != null) append(", qop=$qop, nc=$nc, cnonce=\"$cnonce\"")
            }
        }
    }
}
