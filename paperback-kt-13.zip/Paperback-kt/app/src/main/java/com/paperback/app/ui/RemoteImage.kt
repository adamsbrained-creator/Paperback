package com.paperback.app.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.PaperbackApp
import com.paperback.app.data.opds.OpdsAuth
import com.paperback.app.data.opds.OpdsHttp
import com.paperback.app.ui.theme.PbSerif
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

/**
 * Catalog pictures: fetched with the catalog's login, kept on disk (so scrolling back is instant, even offline)
 * and in a small memory cache. At most four are downloaded at a time.
 */
private object RemoteImages {
    private val memory = object : LruCache<String, ImageBitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }
    private val gate = Semaphore(4)

    fun peek(url: String?): ImageBitmap? = url?.let { memory.get(it) }

    suspend fun load(url: String, auth: OpdsAuth?, http: OpdsHttp, cacheDir: File): ImageBitmap? {
        memory.get(url)?.let { return it }
        return gate.withPermit { fetch(url, auth, http, cacheDir) }
    }

    private suspend fun fetch(url: String, auth: OpdsAuth?, http: OpdsHttp, cacheDir: File): ImageBitmap? =
        withContext(Dispatchers.IO) {
            memory.get(url) ?: run {
                val file = File(File(cacheDir, "opds-img").apply { mkdirs() }, sha1(url))
                val onDisk: ByteArray? =
                    if (file.exists() && file.length() > 0) runCatching { file.readBytes() }.getOrNull() else null
                val bytes: ByteArray? = onDisk ?: http.getBytes(url, auth)?.also { fresh ->
                    runCatching { file.writeBytes(fresh) }
                }
                val bmp = bytes?.let { decode(it) }
                if (bmp != null) memory.put(url, bmp)
                bmp
            }
        }

    /** Decodes at roughly 500 px wide at most, so a grid of covers stays light. */
    private fun decode(bytes: ByteArray): ImageBitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 500) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)?.asImageBitmap()
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}

/** A book cover loaded from a web address, drawn like [BookCover] (rounded, shadowed, title if there is no picture). */
@Composable
fun RemoteCover(url: String?, auth: OpdsAuth?, title: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current.applicationContext
    val graph = remember { (context as PaperbackApp).graph }
    val bitmap by produceState(initialValue = RemoteImages.peek(url), url) {
        value = if (url == null) null else RemoteImages.load(url, auth, graph.opdsHttp, context.cacheDir)
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .aspectRatio(28f / 41f)
            .shadow(6.dp, shape)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val b = bitmap
        if (b != null) {
            Image(bitmap = b, contentDescription = title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(
                title,
                modifier = Modifier.padding(10.dp),
                fontFamily = PbSerif,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                maxLines = 5,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
