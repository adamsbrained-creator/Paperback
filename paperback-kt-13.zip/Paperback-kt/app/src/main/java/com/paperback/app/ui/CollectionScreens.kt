package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.BookCollection
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.Search
import com.paperback.app.ui.theme.PbSerif
import com.paperback.app.ui.theme.pbTokens

@Composable
fun CollectionsScreen(
    collections: List<BookCollection>,
    membership: Map<String, Set<String>>,
    books: List<Book>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpen: (BookCollection) -> Unit,
    onCreate: (String) -> Unit,
) {
    val t = pbTokens()
    var creating by remember { mutableStateOf(false) }

    PbListPage("Collections", headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(12.dp))
        PbButton("New collection", onClick = { creating = true })
        Spacer(Modifier.height(16.dp))
        if (collections.isEmpty()) {
            PbNote("No collections yet. Make one, like \u201CTo read in winter\u201D, then add books to it.")
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 112.dp)) {
                item {
                    PbCard {
                        collections.forEachIndexed { i, c ->
                            if (i > 0) CardDivider(startInset = 80.dp)
                            val ids = membership[c.id].orEmpty()
                            val first = books.firstOrNull { it.id in ids }
                            Row(
                                Modifier.fillMaxWidth().clickable { onOpen(c) }.padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                if (first != null) {
                                    BookCover(first, Modifier.width(44.dp))
                                } else {
                                    Box(
                                        Modifier.size(width = 44.dp, height = 66.dp).clip(RoundedCornerShape(10.dp)).background(t.bg),
                                        contentAlignment = Alignment.Center,
                                    ) { PbIcon(PbIconName.Collections, size = 22.dp, tint = t.setSub) }
                                }
                                Spacer(Modifier.width(16.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        c.name, color = t.ink, fontFamily = PbSerif, fontSize = 18.sp, fontWeight = FontWeight.Medium,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    )
                                    Text("${ids.size} ${if (ids.size == 1) "book" else "books"}", color = t.setSub, fontSize = 14.sp)
                                }
                                PbIcon(PbIconName.CaretRight, size = 18.dp, tint = t.setSub, strokeWidth = 2f)
                            }
                        }
                    }
                }
            }
        }
    }

    if (creating) {
        NameDialog(
            title = "New collection",
            initial = "",
            confirmLabel = "Create",
            onConfirm = { creating = false; onCreate(it) },
            onDismiss = { creating = false },
        )
    }
}

@Composable
fun CollectionDetailScreen(
    collection: BookCollection,
    allBooks: List<Book>,
    memberIds: Set<String>,
    headerSize: HeaderSize,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenBook: (Book) -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onSetMember: (Book, Boolean) -> Unit,
) {
    var renaming by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val members = remember(allBooks, memberIds) { allBooks.filter { it.id in memberIds } }

    PbListPage(collection.name, headerSize, onMenu, onSearch) {
        Spacer(Modifier.height(12.dp))
        PbButton("Add books", onClick = { adding = true })
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionPill("Rename", onClick = { renaming = true })
            ActionPill("Delete", onClick = { confirmDelete = true }, danger = true)
        }
        if (members.isEmpty()) {
            Spacer(Modifier.height(8.dp))
            PbNote("This collection is empty. Tap Add books to fill it.")
        } else {
            CoverGrid(members, onOpenBook, Modifier.weight(1f))
        }
    }

    if (renaming) {
        NameDialog(
            title = "Rename collection",
            initial = collection.name,
            confirmLabel = "Save",
            onConfirm = { renaming = false; onRename(it) },
            onDismiss = { renaming = false },
        )
    }

    if (adding) {
        AddBooksDialog(allBooks, memberIds, onSetMember, onDone = { adding = false })
    }

    if (confirmDelete) {
        PbConfirmDialog(
            title = "Delete this collection?",
            message = "The books stay in your library.",
            confirm = "Delete",
            onConfirm = { confirmDelete = false; onDelete() },
            onDismiss = { confirmDelete = false },
        )
    }
}

/** Pick books for a collection: search box, a cover and title for each, a round tick on the ones that are in. */
@Composable
private fun AddBooksDialog(
    allBooks: List<Book>,
    memberIds: Set<String>,
    onSetMember: (Book, Boolean) -> Unit,
    onDone: () -> Unit,
) {
    val t = pbTokens()
    var query by remember { mutableStateOf("") }
    val tokens = remember(query) { Search.tokens(query) }
    val shown = remember(allBooks, tokens) {
        if (tokens.isEmpty()) allBooks else allBooks.filter { Search.matches(it.title + " " + it.author, tokens) }
    }

    PbDialog("Add books", onDismiss = onDone) {
        if (allBooks.isEmpty()) {
            Text("Your library is empty.", color = t.setSub)
        } else {
            PbField(query, { query = it }, "Search your books", leading = PbIconName.Search, onClear = { query = "" })
            Spacer(Modifier.height(8.dp))
            if (shown.isEmpty()) {
                Text("Nothing matches.", color = t.setSub, modifier = Modifier.padding(vertical = 12.dp))
            } else {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(shown, key = { it.id }) { b ->
                        val inIt = b.id in memberIds
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { onSetMember(b, !inIt) }
                                .padding(horizontal = 6.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            BookCover(b, Modifier.width(38.dp))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(b.title, color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                if (b.author.isNotBlank()) {
                                    Text(b.author, color = t.setSub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            SelectDot(inIt)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        PbButton("Done", onClick = onDone)
    }
}

/** Covers in rows of three, scrolling. Used by collections and the shelf pages (Favorites, Finished...). */
@Composable
fun CoverGrid(books: List<Book>, onOpen: (Book) -> Unit, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val rows = remember(books) { books.chunked(3) }
    LazyColumn(modifier, contentPadding = PaddingValues(top = 16.dp, bottom = 112.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
        items(rows, key = { row -> row.first().id }) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { b ->
                    Column(Modifier.weight(1f).clickable { onOpen(b) }) {
                        BookCover(b)
                        Spacer(Modifier.height(8.dp))
                        Text(b.title, color = t.ink, fontSize = 13.sp, lineHeight = 17.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (b.author.isNotBlank()) {
                            Text(b.author, color = t.setSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (b.isReading) {
                            Spacer(Modifier.height(6.dp))
                            ProgressTrack(b.progress, height = 4.dp)
                        } else if (b.finished) {
                            Text("Finished", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    PbDialog(title, onDismiss) {
        PbField(
            value = name,
            onValueChange = { name = it },
            placeholder = "Name",
            modifier = Modifier.focusRequester(focus),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { if (name.isNotBlank()) onConfirm(name.trim()) }),
        )
        PbDialogButtons(
            confirm = confirmLabel,
            onConfirm = { onConfirm(name.trim()) },
            onCancel = onDismiss,
            enabled = name.isNotBlank(),
        )
    }
}
