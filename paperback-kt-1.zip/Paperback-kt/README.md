# Paperback 2 (Kotlin)

Paperback rebuilt natively: Kotlin, Jetpack Compose, and the Readium toolkit for EPUB (instead of Readest).
Android only. Package id `com.paperback.app`, so it installs next to the old TypeScript Paperback.

## What works in this first step
- Import EPUBs (copied into the app, deduplicated by file hash, cover and page count read from the book)
- Home (continue reading, today, streak, recently read), Library (search, filters, favorite / finished / remove), Stats (today, week, streaks, last 7 days, most read)
- Reader: page turns by tapping the screen edges, tap the middle for controls (slider, font size, light / sepia / dark), position saved on every page turn
- Reading time and pages counted per session (idle time is capped, like Readest)

## Not done yet (in the old app, planned in this order)
PDF and comics, highlights and notes, bookmarks, collections, ratings screen, wishlist, dictionary, read aloud, goals and milestones,
backup / restore, Discover (OPDS), Outfit and Newsreader fonts.

## Layout
- `app/src/main/java/com/paperback/app/data` database, import, stats maths (`Stats.kt` is the port of statsAggregate.ts)
- `.../reader` ReaderActivity (hosts Readium's fragment), the controls overlay, reading-time tracker
- `.../ui` Home, Library, Stats screens and the theme (same coral / black / white as before)

## Building
Upload the zip next to `.github/workflows/apk-kotlin-from-one-zip.yml` and run the workflow. Versions are in `gradle/libs.versions.toml`.
If Gradle can't find a version, change it there.
