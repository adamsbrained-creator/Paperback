package com.paperback.app.reader

/**
 * Counts reading time without counting idle time: every page turn credits the time since the previous
 * one, but never more than [capSeconds] (same idea as Readest's per-page cap). Pure logic, no Android.
 */
class ReadingTracker(private val capSeconds: Long = 180) {
    class Flush(val startMs: Long, val seconds: Int, val pages: Int)

    private var sessionStart = 0L
    private var lastTick = 0L
    private var seconds = 0L
    private var pages = 0
    private var lastPosition = -1

    fun resume(now: Long) {
        if (sessionStart == 0L) sessionStart = now
        lastTick = now
    }

    fun onPosition(now: Long, position: Int) {
        credit(now)
        // Small forward steps are pages read; jumps (slider, table of contents) are not.
        if (lastPosition in 0 until position && position - lastPosition <= 3) pages += position - lastPosition
        lastPosition = position
    }

    /** Call when the reader goes to the background. Returns what to save, or null if nothing happened. */
    fun pause(now: Long): Flush? {
        credit(now)
        lastTick = 0L
        if (seconds <= 0L && pages <= 0) return null
        val out = Flush(sessionStart, seconds.toInt(), pages)
        sessionStart = 0L
        seconds = 0L
        pages = 0
        return out
    }

    private fun credit(now: Long) {
        if (lastTick > 0L) seconds += ((now - lastTick) / 1000).coerceIn(0L, capSeconds)
        lastTick = now
    }
}
