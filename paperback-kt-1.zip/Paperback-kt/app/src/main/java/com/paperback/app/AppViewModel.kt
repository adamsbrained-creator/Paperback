package com.paperback.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.paperback.app.data.Book
import com.paperback.app.data.ImportOutcome
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val graph = (app as PaperbackApp).graph

    val books = graph.repo.books
    val sessions = graph.repo.sessions

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch { graph.repo.refresh() }
    }

    fun consumeMessage() {
        _message.value = null
    }

    fun importBooks(uris: List<Uri>) {
        viewModelScope.launch {
            _busy.value = true
            var added = 0
            val problems = mutableListOf<String>()
            for (uri in uris) {
                when (val r = graph.repo.importBook(uri)) {
                    is ImportOutcome.Added -> added++
                    is ImportOutcome.Duplicate -> problems += "${r.name} is already in your library"
                    is ImportOutcome.Unsupported -> problems += "${r.name}: only EPUB for now"
                    is ImportOutcome.Failed -> problems += "Couldn't read ${r.name}"
                }
            }
            _busy.value = false
            _message.value = buildString {
                if (added > 0) append(if (added == 1) "Added 1 book" else "Added $added books")
                if (problems.isNotEmpty()) {
                    if (isNotEmpty()) append(". ")
                    append(problems.first())
                    if (problems.size > 1) append(" (+${problems.size - 1} more)")
                }
            }.ifEmpty { null }
        }
    }

    /** Prepares the reader, then calls [onReady] so the screen can start ReaderActivity. */
    fun open(book: Book, onReady: () -> Unit) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            val ok = graph.openReader(book)
            _busy.value = false
            if (ok) onReady() else _message.value = "Couldn't open ${book.title}"
        }
    }

    fun toggleFavorite(book: Book) {
        viewModelScope.launch { graph.repo.setFavorite(book.id, !book.favorite) }
    }

    fun toggleFinished(book: Book) {
        viewModelScope.launch { graph.repo.setFinished(book.id, !book.finished) }
    }

    fun remove(book: Book) {
        viewModelScope.launch { graph.repo.remove(book) }
    }
}
