package com.paperback.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.paperback.app.reader.ReaderActivity
import com.paperback.app.ui.PaperbackRoot
import com.paperback.app.ui.theme.PaperbackTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val pickBooks =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.importBooks(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PaperbackTheme {
                PaperbackRoot(
                    vm = vm,
                    // "*/*": some file pickers don't label .epub files as application/epub+zip.
                    onPickBooks = { pickBooks.launch(arrayOf("*/*")) },
                    onOpenReader = { startActivity(Intent(this, ReaderActivity::class.java)) },
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.refresh() // picks up progress and reading time saved by the reader
    }
}
