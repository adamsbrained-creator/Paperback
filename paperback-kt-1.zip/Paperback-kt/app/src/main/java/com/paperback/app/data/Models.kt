package com.paperback.app.data

data class Book(
    val id: String,              // SHA-256 of the file
    val title: String,
    val author: String,
    val language: String,
    val filePath: String,
    val coverPath: String?,
    val addedAt: Long,
    val lastOpenedAt: Long,      // 0 = never opened
    val progress: Float,         // 0..1 across the whole book
    val position: Int,           // Readium "position" (about one page), 0 = unread
    val totalPositions: Int,
    val locatorJson: String?,    // where to resume
    val finished: Boolean,
    val favorite: Boolean,
    val rating: Int,             // 0..5
) {
    val isReading: Boolean get() = !finished && (progress > 0f || position > 1)
    val percent: Int get() = (progress * 100).toInt().coerceIn(0, 100)
}

data class ReadingSession(
    val id: Long,
    val bookId: String,
    val startMs: Long,
    val seconds: Int,
    val pages: Int,
)
