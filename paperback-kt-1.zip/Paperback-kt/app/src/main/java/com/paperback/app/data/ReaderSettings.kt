package com.paperback.app.data

import android.content.Context
import org.readium.r2.navigator.epub.EpubPreferences
import org.readium.r2.navigator.preferences.Theme

/** The few reader choices Paperback remembers. More (fonts, margins, scroll mode) come later. */
class ReaderSettings(context: Context) {
    private val sp = context.getSharedPreferences("reader", Context.MODE_PRIVATE)

    var fontSize: Double
        get() = sp.getFloat("fontSize", 1.0f).toDouble()
        set(v) = sp.edit().putFloat("fontSize", v.toFloat()).apply()

    /** 0 = light, 1 = sepia, 2 = dark */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    fun toEpubPreferences(): EpubPreferences = EpubPreferences(
        fontSize = fontSize,
        theme = when (theme) {
            1 -> Theme.SEPIA
            2 -> Theme.DARK
            else -> Theme.LIGHT
        },
    )
}
