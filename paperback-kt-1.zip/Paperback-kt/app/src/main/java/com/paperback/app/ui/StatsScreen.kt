package com.paperback.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun StatsScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    modifier: Modifier = Modifier,
) {
    val today = LocalDate.now()
    val byDay = remember(sessions) { Stats.secondsByDay(sessions) }
    val week = remember(byDay) { Stats.lastDays(byDay, today, 7) }
    val weekTotal = week.sumOf { it.second }
    val allTime = remember(sessions) { sessions.sumOf { it.seconds.toLong() } }
    val perBook = remember(sessions) { Stats.secondsByBook(sessions) }
    val top = remember(books, perBook) {
        books.filter { (perBook[it.id] ?: 0L) > 0L }.sortedByDescending { perBook[it.id] ?: 0L }.take(5)
    }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Text("Stats", fontFamily = PbSerif, fontSize = 30.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(20.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Today", Stats.duration(byDay[today] ?: 0L), Modifier.weight(1f))
            StatTile("This week", Stats.duration(weekTotal), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Streak", "${Stats.currentStreak(byDay, today)} d", Modifier.weight(1f))
            StatTile("Best streak", "${Stats.longestStreak(byDay)} d", Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("All time", Stats.duration(allTime), Modifier.weight(1f))
            StatTile("Finished", "${books.count { it.finished }}", Modifier.weight(1f))
        }

        Spacer(Modifier.height(28.dp))
        Eyebrow("Last 7 days")
        Spacer(Modifier.height(12.dp))
        WeekChart(week)

        if (top.isNotEmpty()) {
            Spacer(Modifier.height(28.dp))
            Eyebrow("Most read")
            Spacer(Modifier.height(12.dp))
            top.forEach { book ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    BookCover(book, Modifier.width(44.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(book.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (book.author.isNotBlank()) {
                            Text(book.author, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Text(Stats.duration(perBook[book.id] ?: 0L), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun WeekChart(days: List<Pair<LocalDate, Long>>) {
    val max = (days.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(60L)
    val barArea = 120
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        days.forEachIndexed { i, (date, seconds) ->
            val isToday = i == days.lastIndex
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.height(barArea.dp).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    val h = if (seconds <= 0L) 4 else (4 + (barArea - 4) * (seconds.toFloat() / max)).toInt()
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(h.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isToday) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline,
                            ),
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(2),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
