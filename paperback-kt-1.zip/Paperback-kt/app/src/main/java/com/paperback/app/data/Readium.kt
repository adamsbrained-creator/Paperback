package com.paperback.app.data

import android.content.Context
import org.readium.r2.shared.publication.Publication
import org.readium.r2.shared.util.*
import org.readium.r2.shared.util.asset.AssetRetriever
import org.readium.r2.shared.util.http.DefaultHttpClient
import org.readium.r2.streamer.PublicationOpener
import org.readium.r2.streamer.parser.DefaultPublicationParser
import java.io.File

/** The only place that knows how Readium opens a book. */
class Readium(context: Context) {
    private val httpClient = DefaultHttpClient()
    private val assetRetriever = AssetRetriever(
        contentResolver = context.contentResolver,
        httpClient = httpClient,
    )
    private val opener = PublicationOpener(
        publicationParser = DefaultPublicationParser(
            context,
            httpClient = httpClient,
            assetRetriever = assetRetriever,
            pdfFactory = null, // PDF support is a later step (readium-adapter-pdfium)
        ),
    )

    /** Opens a book file, or returns null if Readium can't read it. */
    suspend fun open(file: File): Publication? {
        val asset = assetRetriever.retrieve(file.toUrl()).getOrElse { return null }
        return opener.open(asset, allowUserInteraction = false).getOrElse { return null }
    }
}
