package com.paperback.app.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Book
import com.paperback.app.ui.theme.PbSerif
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private object CoverCache {
    private val cache = LruCache<String, ImageBitmap>(40)

    fun peek(path: String?): ImageBitmap? = path?.let { cache.get(it) }

    fun load(path: String?): ImageBitmap? {
        if (path == null) return null
        cache.get(path)?.let { return it }
        val bmp = BitmapFactory.decodeFile(path)?.asImageBitmap() ?: return null
        cache.put(path, bmp)
        return bmp
    }
}

@Composable
fun BookCover(book: Book, modifier: Modifier = Modifier) {
    val bitmap by produceState(initialValue = CoverCache.peek(book.coverPath), book.coverPath) {
        value = withContext(Dispatchers.IO) { CoverCache.load(book.coverPath) }
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .aspectRatio(2f / 3f)
            .shadow(6.dp, shape)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val b = bitmap
        if (b != null) {
            Image(bitmap = b, contentDescription = book.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(
                book.title,
                modifier = Modifier.padding(10.dp),
                fontFamily = PbSerif,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                maxLines = 5,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun ProgressTrack(fraction: Float, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.outline),
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.primary),
        )
    }
}

@Composable
fun Eyebrow(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 12.sp,
        letterSpacing = 1.2.sp,
        fontWeight = FontWeight.Medium,
    )
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp),
    ) {
        Column {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Text(value, fontFamily = PbSerif, fontSize = 26.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ---- tab icons drawn by hand (no icon-pack dependency) ---------------------------------------

@Composable
fun LibraryGlyph(color: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val gap = this.size.width * 0.12f
        val s = (this.size.width - gap * 3) / 2f
        val r = CornerRadius(s * 0.22f)
        for (row in 0..1) for (col in 0..1) {
            drawRoundRect(color, Offset(gap + col * (s + gap), gap + row * (s + gap)), Size(s, s), r)
        }
    }
}

@Composable
fun StatsGlyph(color: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val bar = w * 0.22f
        val r = CornerRadius(bar / 2)
        listOf(0.45f, 0.8f, 0.6f).forEachIndexed { i, frac ->
            val left = w * 0.1f + i * (bar + w * 0.12f)
            drawRoundRect(color, Offset(left, h * (0.9f - frac * 0.8f)), Size(bar, h * frac * 0.8f), r)
        }
    }
}
