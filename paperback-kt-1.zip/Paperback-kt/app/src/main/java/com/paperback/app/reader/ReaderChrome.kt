package com.paperback.app.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PbSerif

/**
 * The reader's controls, drawn over the Readium page. Everything is transparent except the two bars,
 * so taps anywhere else fall through to the book underneath.
 */
@Composable
fun ReaderChrome(
    title: String,
    visible: Boolean,
    position: Int,
    totalPositions: Int,
    progress: Float,
    secondsPerPage: Double?,
    fontSize: Double,
    themeIndex: Int,
    onBack: () -> Unit,
    onSeek: (Float) -> Unit,
    onFontSize: (Double) -> Unit,
    onTheme: (Int) -> Unit,
) {
    val card = MaterialTheme.colorScheme.surfaceVariant
    val ink = MaterialTheme.colorScheme.onSurface

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(card).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ink)
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    text = title,
                    modifier = Modifier.clip(RoundedCornerShape(22.dp)).background(card).padding(horizontal = 16.dp, vertical = 10.dp),
                    color = ink,
                    fontFamily = PbSerif,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomStart),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(card)
                    .padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                val left = if (secondsPerPage != null && totalPositions > 0) {
                    Stats.duration(((totalPositions - position).coerceAtLeast(0) * secondsPerPage).toLong()) + " left"
                } else null
                val label = buildString {
                    if (totalPositions > 0) append("Page $position of $totalPositions · ")
                    append("${(progress * 100).toInt().coerceIn(0, 100)}%")
                    if (left != null) append(" · $left")
                }
                Text(label, color = ink, fontSize = 14.sp)

                var drag by remember { mutableStateOf<Float?>(null) }
                Slider(
                    value = drag ?: progress.coerceIn(0f, 1f),
                    onValueChange = { drag = it },
                    onValueChangeFinished = {
                        drag?.let(onSeek)
                        drag = null
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                    ),
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Pill("A−") { onFontSize(-0.1) }
                        Spacer(Modifier.width(8.dp))
                        Text("${(fontSize * 100).toInt()}%", color = ink, fontSize = 13.sp)
                        Spacer(Modifier.width(8.dp))
                        Pill("A+") { onFontSize(0.1) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        listOf("Light", "Sepia", "Dark").forEachIndexed { i, name ->
                            if (i > 0) Spacer(Modifier.width(6.dp))
                            Pill(name, selected = themeIndex == i) { onTheme(i) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Pill(text: String, selected: Boolean = false, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.background
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Text(
        text = text,
        color = fg,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
    )
}
