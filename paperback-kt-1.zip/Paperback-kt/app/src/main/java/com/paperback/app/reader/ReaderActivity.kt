package com.paperback.app.reader

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commitNow
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.paperback.app.PaperbackApp
import com.paperback.app.R
import com.paperback.app.data.Stats
import com.paperback.app.ui.theme.PaperbackTheme
import kotlinx.coroutines.launch
import org.readium.r2.navigator.epub.EpubNavigatorFragment
import org.readium.r2.navigator.input.InputListener
import org.readium.r2.navigator.input.TapEvent
import org.readium.r2.navigator.util.DirectionalNavigationAdapter
import org.readium.r2.shared.publication.Locator
import org.readium.r2.shared.publication.services.locateProgression

class ReaderActivity : FragmentActivity() {

    private val graph get() = (application as PaperbackApp).graph

    private var session: ReaderSession? = null
    private var navigator: EpubNavigatorFragment? = null
    private val tracker = ReadingTracker()

    private val chromeVisible = mutableStateOf(false)
    private val locatorState = mutableStateOf<Locator?>(null)
    private val fontSizeState = mutableDoubleStateOf(1.0)
    private val themeState = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        val s = graph.readerSession
        if (s == null) {
            // The app was killed and Android is restoring this screen with nothing to show. The Readium
            // fragment still needs *a* factory to be restored, so give it a dummy one and leave.
            supportFragmentManager.fragmentFactory = EpubNavigatorFragment.createDummyFactory()
            super.onCreate(null)
            finish()
            return
        }
        session = s
        fontSizeState.doubleValue = graph.settings.fontSize
        themeState.intValue = graph.settings.theme

        // IMPORTANT: the factory has to be set before super.onCreate().
        supportFragmentManager.fragmentFactory = s.navigatorFactory.createFragmentFactory(
            initialLocator = s.initialLocator,
            initialPreferences = graph.settings.toEpubPreferences(),
        )
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_reader)

        if (savedInstanceState == null) {
            supportFragmentManager.commitNow {
                add(R.id.navigator_container, EpubNavigatorFragment::class.java, Bundle(), NAV_TAG)
            }
        }
        val nav = supportFragmentManager.findFragmentByTag(NAV_TAG) as EpubNavigatorFragment
        navigator = nav

        // Tap near the left/right edge turns the page; tap in the middle shows or hides the controls.
        nav.addInputListener(DirectionalNavigationAdapter(nav))
        nav.addInputListener(
            object : InputListener {
                override fun onTap(event: TapEvent): Boolean {
                    setChrome(!chromeVisible.value)
                    return true
                }
            },
        )

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                nav.currentLocator.collect { onLocator(s, it) }
            }
        }

        val pace = Stats.paceSecondsPerPosition(graph.repo.sessions.value)

        findViewById<ComposeView>(R.id.chrome).setContent {
            PaperbackTheme {
                ReaderChrome(
                    title = s.book.title,
                    visible = chromeVisible.value,
                    position = locatorState.value?.locations?.position ?: s.book.position,
                    totalPositions = s.totalPositions,
                    progress = (locatorState.value?.locations?.totalProgression ?: s.book.progress.toDouble()).toFloat(),
                    secondsPerPage = pace,
                    fontSize = fontSizeState.doubleValue,
                    themeIndex = themeState.intValue,
                    onBack = { finish() },
                    onSeek = { fraction ->
                        s.publication.locateProgression(fraction.toDouble())?.let { nav.go(it) }
                    },
                    onFontSize = { delta -> changeFontSize(delta) },
                    onTheme = { index -> changeTheme(index) },
                )
            }
        }

        setChrome(false)
    }

    private fun onLocator(s: ReaderSession, locator: Locator) {
        locatorState.value = locator
        tracker.onPosition(System.currentTimeMillis(), locator.locations.position ?: 0)
        graph.appScope.launch { graph.repo.saveProgress(s.book.id, locator) }
    }

    private fun changeFontSize(delta: Double) {
        val next = (fontSizeState.doubleValue + delta).coerceIn(0.6, 2.5)
        fontSizeState.doubleValue = next
        graph.settings.fontSize = next
        navigator?.submitPreferences(graph.settings.toEpubPreferences())
    }

    private fun changeTheme(index: Int) {
        themeState.intValue = index
        graph.settings.theme = index
        navigator?.submitPreferences(graph.settings.toEpubPreferences())
    }

    private fun setChrome(visible: Boolean) {
        chromeVisible.value = visible
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (visible) controller.show(WindowInsetsCompat.Type.systemBars()) else controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        tracker.resume(System.currentTimeMillis())
    }

    override fun onPause() {
        super.onPause()
        val s = session ?: return
        tracker.pause(System.currentTimeMillis())?.let { flush ->
            // appScope, not lifecycleScope: this has to finish even if the activity is going away.
            graph.appScope.launch { graph.repo.addSession(s.book.id, flush.startMs, flush.seconds, flush.pages) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing && session != null) graph.closeReader()
    }

    private companion object {
        const val NAV_TAG = "navigator"
    }
}
