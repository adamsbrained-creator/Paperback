# Paperback 2 (Kotlin)

Paperback rebuilt natively: Kotlin, Jetpack Compose, and the Readium toolkit for EPUB (instead of Readest).
Android only. Package id `com.paperback.app`, so it installs next to the old TypeScript Paperback.

## What works in this first step
- Import EPUBs (copied into the app, deduplicated by file hash, cover and page count read from the book)
- Home (continue reading, today, streak, recently read), Library (search, filters, favorite / finished / remove), Stats (today, week, streaks, last 7 days, most read)
- Reader: page turns by tapping the screen edges, tap the middle for controls (slider, font size, light / sepia / dark), position saved on every page turn
- Reading time and pages counted per session (idle time is capped, like Readest)

### Added in round 2
- Bookmarks: bookmark button at the top of the reader, list in the notes panel
- Highlights and notes: select text, choose Highlight or Note; tap a highlight to edit it (note, colour, delete)
- Panel (button next to the bookmark) lists all bookmarks and notes of the book; tap one to jump there
- Reader controls now follow the page theme (light / sepia / dark)
- Fixed: the reader header jumped and lagged when the controls toggled. The phone's status and navigation bars now stay hidden
  for the whole reading session (swipe from the edge to peek), so nothing resizes when you tap the page

### Added in round 3: Settings (copied from the TypeScript app)
- **Settings page** exactly as in `app/(paperback)/settings/page.tsx`: daily-goal card (ring, minutes today, Edit), then READING (Reading goals, Reading stats, Reader defaults), LOOK (Appearance, App style), LIBRARY (Library & import, Backup & restore) and About, with the round menu button at the bottom right
- **Page header** in the three sizes (Compact / Regular / Large) on every screen, with the menu and search buttons; Library shows its book-count chip
- **Menu**: the pop-up card above the round button (Home, Library, Discover, Collections, Bookmarks, Stats, Settings, More) and the **More** page (menu -> More): five group cards (Reading, Your notes, Shelves, Get books, App), one open at a time, plus a "Find a page" field. Settings -> App style -> More page switches it to **Bento** (a big Currently reading tile, small tiles, notes grid, shelf spines on a plank, Discover and Import, then the app pages as a list). The choice is saved and goes into backups. Pages that are not built yet say "Soon"
- **App style** (header size with a live sample of each), **About** (logo tile, Credits, Open-source licenses), **Appearance** (Light / Dark / Match system), **Reading goals** (books this year, pages, minutes, streak, editable)
- **Reader defaults** (font size and page colors) and **Library & import**, both real, not placeholders
- **Backup & restore**: one JSON file with progress, favorites, ratings, bookmarks, highlights, reading history, goals and settings. Restore matches books by hash and never moves reading progress backwards
- The icons are the TypeScript app's own SVG paths (`PbIcons.kt`), so they are identical
- Navigation is now a small back stack in `PaperbackRoot.kt` (Back returns; tabs replace each other)

Not copied yet: Appearance's **Home layout** (Pile) and **Navigation** style (dock, header switch, off), because the Kotlin Home and tab bar have only one layout.
Outfit is not bundled yet (the font could not be downloaded); text uses the system sans. To add it, put Outfit-Regular/Medium/SemiBold.ttf in `app/src/main/res/font/` and point `PbSans` in `ui/theme/Theme.kt` at them.

### Added in step 4 (built on step 3)
- **Book page**: Library long-press -> Details, or tap the title on Home. Rating (stars), Favorite / Finished, progress, time read, page, sessions, collections, link to the book's notes, journal, remove
- **Collections** (menu -> Collections): create, rename, delete, add and remove books; a book's page can also toggle its collections
- **Notes & highlights** and **Bookmarks** (menu -> More): every highlight, note and bookmark across all books, search, tap to open the book at that spot, remove, share notes as Markdown. Bookmarks opens on the second tab
- **Shelf pages** (menu -> More): Currently reading, Recently read, Finished, Favorites. Tap a cover for the book page
- **Finish date**: finishing a book now saves the date, so "books this year" in Reading goals is exact (older finished books still use the date they were last opened)
- **Backup** now also keeps journals, finish dates and collections (older backups still restore)
- Database upgrades in place (version 3): journal, finish date, collections. Existing libraries and history are kept

### Added in step 5
- **Global search** (the search button in every page header, or menu -> More -> Search): books by title, author or journal, your notes and highlights, collections, and the app's own pages (type "backup", "goals", "theme"...). Ignores capitals and accents; every word you type must match; matches are shown in coral
- Tap a book for its page, a note to open the book at that passage, a collection or page to go there. Back returns to the same search
- Recent searches are remembered (Clear removes them)

### Step 6: polish (no new features)
- One set of building blocks (`ui/PbKit.kt`): dialog, filled text field, rounded cards, segmented switch, round select mark, action pills. Every page and dialog from steps 4 and 5 now uses them instead of Material's stock look
- Dialogs (Add books, new / rename collection, delete, remove book, reader note editor) are rounded cards with a serif title and pill buttons. Add books has a search box, covers, and round ticks
- Text fields are filled with the card colour, no outline. Library search and filters use them too (filters are the coral pills, not Material chips)
- Book page: sections use the Settings label style, Notes & bookmarks is a Settings-style row, About is a card, Remove is a red pill button
- Collections list is one card with covers and carets; Notes are cards (serif quote, colour dot); Search results are cards
- Shelf pages and collection grids show author and reading progress like the Library
- Library's long-press menu, the snackbar and the reader's buttons use the app's colours and icons

### Step 7: Discover (free books from the internet)
- **Discover** (menu -> Discover, More -> Get books, or "Discover free books" on an empty Home / Library / Import page). Lists the catalogs: **Project Gutenberg** and **Standard Ebooks** are always there; **Add a catalog** takes any OPDS address (Calibre, Kavita, COPS, a library server...). Your own catalogs can be edited or removed from the dots menu; they are stored on this device only
- Private catalogs: add a username and password (Basic and Digest login are both handled; Calibre's content server uses Digest). The password is only ever sent to that catalog's own address
- Browsing like the old app: the toolbar has Back, Home (the catalog's first page), a search box (when the catalog has search), a Filters menu (when the page has filters) and Close. Pages show navigation cards, shelves that scroll sideways ("See all"), book grids and First / Previous / Next / Last. Back goes back one page at a time and the scroll position of each page is remembered
- **Book page**: cover, title, authors, **Download EPUB** (a small arrow next to it lists the other EPUB versions when a book has several, e.g. Standard Ebooks' advanced EPUB), description, details and subjects. A book you already have shows **Open & Read** (and Download again); it is recognised by where it came from, or by its title if you added it by hand
- Downloads go straight into the Library (same duplicate check and cover reading as Import) with a progress bar. Only **EPUB** is downloaded; if a book is offered only as PDF / MOBI the page says so
- Covers are fetched with the catalog's login and kept in the app's cache, so a page you have seen opens instantly
- The app now asks for the **Internet** permission, and allows plain `http://` so catalogs on your home network (Calibre at `192.168...`) work
- Not done: OPDS pagination "infinite scroll", catalogs that need a web sign-in page (OAuth), buying or borrowing books

### Step 8: reading essentials + polish
- **Contents**: the book's table of contents, nested chapters indented, the chapter you are in marked in coral. Reader controls -> **Contents** (also the first tab of the top-right panel). Tap a chapter to go there
- **Search in the book**: reader controls -> **Search**. Type, press search on the keyboard, tap a match to jump to it (the match is marked on the page). Up to 200 matches
- **Text settings** (reader controls -> **Text**): a sheet that sits over the page so you see changes live. Font size, page colors, **margins**, **layout** (the book's own, or Custom: **font** serif / sans / mono, **line spacing**, **left or justified**) and **brightness** (own slider for the reader, or "Auto" to follow the phone)
- Margins and layout are also in **Settings -> Reader defaults**, with a live sample
- Sliders are now Paperback's own (slim track, round coral handle) in the reader and in Reader defaults
- Fixed icons: Appearance, App style, Backup and Reader were drawn wrong (compact SVG arc flags); the paths now use spaced flags
- Library: round coral "+" import button; dark theme no longer has a purple tint on Material's selected colours

### Step 9: PDF
- **Import PDFs** the same way as EPUBs (Import, Library "+", Settings -> Library & import). A PDF is recognised by its content, so a file with a wrong name still works. The cover is the first page, the title is the file name (no author: a PDF's own details can't be read here)
- **PDF reader** (its own screen, drawn with Android's built-in PdfRenderer, no extra library): one page at a time, fitted to the screen. Swipe or tap the left / right edge to turn the page, tap the middle for the controls. **Pinch** or **double-tap** to zoom (up to 5x, sharper copy of the page once you stop), drag to move the zoomed page
- Controls: back, bookmark, bookmarks list, page slider ("Go to page" while dragging), time left, and **View**: page colors (Light, Sepia, Dark), **Right to left** page turning for manga, brightness
- Same as for EPUB: position saved on every page turn (and it resumes there), reading time and pages counted, bookmarks, finished at the last page, progress in Home / Library / Stats, included in Backup
- Comics: a comic saved as a PDF works the same way (use "Right to left" for manga). CBZ / CBR files are not supported yet
- Not possible with this approach: selecting text, highlights and notes, searching inside the PDF, and a table of contents. Scanned and text PDFs both display, but the text can't be reflowed (zoom in instead)

### Step 10: PDF fixes
- Fixed: zooming a PDF page (pinch or double-tap) made the page disappear. Two causes: lifting the fingers while zoomed produced an invalid position, and the sharper zoomed copy could be bigger than the phone's graphics limit (4096 px) and then was not drawn
- Fixed: Dark (and Sepia) turned pictures into negatives. The viewer now checks each page: a page that is mostly white with almost no color is "text" and gets the Dark / Sepia colors; a page with pictures or color is shown as it is in every theme (on the Dark or Sepia background). A page that mixes a large color picture with text is treated as a picture page

### Step 11: PDF picture pages without the white sheet
- On a picture page (a page that is not mostly text) the viewer now finds the white margins around the picture and shows just the picture, so in Dark and Sepia there is no white sheet floating on the dark / sepia background. The picture is also a little bigger. This applies in every theme
- Text pages are shown whole. Nothing is cut when the page is nearly empty (a few stray marks) or already has no real margin
- Colors of pictures are never changed by the theme (this was already so in kt-10)

### Step 12: Genres, authors and recommendations (and Discover fixes)
- **Paperback now reads each book's genres / tags, description, publisher and date** (from the EPUB itself, and for Discover downloads also from the catalog). Books you already had are read once, in the background, after the update. PDFs have none of these. Messy subject lines are cleaned: "England -- Fiction" becomes the tags *England* and *Fiction*; codes like "LoCC: ..." and words like "Text" are dropped
- **Genres page** and **Authors page** (menu -> More, or search): every genre / author with its number of books, a filter field once there are many, tap one to see its books
- **Book page**: genre chips (tap one to see that genre), description with Read more, Publisher and Published in About, tap the author to see their books, and a **Similar in your library** row
- **Library**: a Sort menu (Recently added, Recently read, Title, Author, Rating, Progress) and a Genre filter; the Library search also finds genres
- **Home**: **Recommended for you**, with "Like <book>". Books you have not started, ranked by how much they resemble the books you rated 4-5, favorited, or finished (rated 1-2 count for nothing). It appears once you have rated, favorited or finished a book that has genres
- **Search** finds books by genre too, and lists matching Authors and Genres
- **Discover**: the book page shows a cleaned Genres list and a short description (Project Gutenberg's long catalogue record is cut to its Summary)
- Discover fixes: Project Gutenberg lists show covers and authors and open the book directly (no duplicate page); "No records found" is no longer tappable; a page that fails with "403 / busy" is retried once; pages you opened in the last 10 minutes load instantly from a cache
- Database version 4 (new columns; nothing is lost)

### Step 13: Chapter name and "pages left" around the page (EPUB reader)
- The reader now shows, always and quietly, like Readest: the **chapter name** above the page (top left), **"N pages left in chapter"** below it (bottom left) and **"position / total"** (bottom right, for example "2 / 196"). They hide while the controls are showing
- The two numbers count different things on purpose, as in Readest: "pages left" counts real screens (it drops by exactly 1 per page turn; the page you are on counts, so the last page says "1 page left"), while "2 / 196" counts Readium's fixed pieces of text, so one page turn can move it by 2 or more
- "Pages left" is measured on the page on screen (how many screens wide the chapter's file is), and re-measured after text size, margin, font or theme changes. For a chapter that continues into the next files it adds those files' length, estimated from the position counts. If a book's contents put several chapters in one file, the chapter ends where the next file starts
- The page area now has a 32 dp strip above and below it (plus the phone's status / navigation bar space) to hold this text; the strip takes the page colour of the theme
- The controls card still shows "Page X of Y . % . time left" as before

### Step 14: The "25 / 136" counter now counts like Readest
- Fixed: the counter stood still for 2-3 page turns (it showed the same number on several pages). Readium's "positions" are cut by the *packed* size of the book (about 1 per 3000 characters of text), so a page held less than one. The counter now uses Readest's way: the book is cut into pieces of 1500 bytes of its *unpacked* text (sizes read from the EPUB file itself), and the counter is the piece your page starts in. A page usually holds one or more pieces, so the number moves on every turn and sometimes jumps by 2
- The total ("/ 136") is that piece count, so it is larger than before and stays the same whatever the text size
- "Page X of Y" in the controls card shows the same two numbers (the "time left" there still uses the old position count)
- If a book's sizes can't be read, the counter falls back to Readium's positions as before

### Step 15: Reflow a PDF as an EPUB
- Open a PDF's book page and tap **Reflow as EPUB**. It reads the PDF's text and builds a new book called "Title (EPUB)" in your Library. The PDF is not touched, and its progress, bookmarks and stats stay with it. The copy is a normal EPUB, so Contents, search, notes, text size, fonts, margins, line spacing and the Light / Sepia / Dark pages all work
- A progress bar shows "Reading page N of M" with a Cancel button. One conversion runs at a time, and it keeps going if you leave the page. Converting the same PDF twice finds the first copy instead of adding another
- What it does: joins lines into paragraphs (first-line indents, extra space above, a short last line), joins words split by a hyphen at the end of a line, finds chapter and section headings (bigger or bold, standing alone) and builds the Contents from them, removes running headers, footers and page numbers, keeps italics and bold, raised footnote marks, bullet lists and scene breaks, puts footnotes after the paragraph they belong to, merges a big drop-cap letter back into its word, and keeps pictures where they were. The cover is the PDF's cover
- Limits: a **scanned PDF has no text**; from step 17 it is read with text recognition instead. **Two-column pages, tables and maths** come out in a jumbled or flat order. Footnotes are placed after the paragraph, not at the page bottom. Comics and picture books have nothing to reflow
- The converter itself (`app/src/main/java/com/paperback/app/reflow`) is plain Java so it can be tested without a phone. It was checked on generated novels, a one-sentence-per-paragraph PDF, drop caps, bullets, footnotes, a double-spaced typescript, a scan, and a real LaTeX-typeset book. Reading the PDF itself uses the PDFBox for Android library (`com.tom-roush:pdfbox-android`, about 5 MB more in the app)

### Step 16: Polish and bug fixes (no new features)
Bugs fixed
- **PDF viewer could crash when you left it while a page was still drawing.** The file was closed under the drawing page. It now waits for the page to finish, and a page asked for after that gets a blank answer instead of an error
- **A PDF page that can't be drawn** (a damaged page, or not enough memory for a big zoomed bitmap) now shows "Couldn't draw page N" instead of crashing or staying blank
- A tiny crash-in-waiting in the PDF page crop (an empty drawing range) is closed
- **Deleting a highlight on the Notes page now asks first**, because its note goes with it
- "Remove" buttons (Notes, bookmarks list, reader panel, PDF bookmarks) have a proper 44 dp tap target; the small pills (filters, Rename / Delete, Share) are 44 dp tall instead of 40

Look
- **Home**: "Resume reading" is the same black pill as every other main button (it was coral and Material's own). "Read today" is now the **daily goal ring** ("8 of 30 min") like the Settings card
- **Home**: the Recently read and Recommended rows now run to the screen edges and their shadows are no longer cut off at the bottom
- Home, Library and Stats use the same 560 dp page width as every other page (matters on tablets, folded phones and landscape)

### Step 17: Reflow scanned PDFs (text recognition)
- **"Reflow as EPUB" now works on scans.** When the PDF has no text of its own (found by looking at a dozen pages, so it takes a second), every page is drawn as a picture and read with Google's on-device text recognition (ML Kit, the bundled Latin model, nothing leaves the phone). The result goes through the same paragraph, heading, footnote and running-header logic as a PDF with text
- **Two-page spreads are split.** A scan where each PDF page shows two book pages side by side is cut at the fold and the left page is read before the right
- **Crooked scans are straightened** before the sizes are measured, so a slightly tilted page doesn't turn body lines into headings. Page numbers printed in the margin beside the text (older-edition numbers) are dropped
- While it reads, the card says "Recognising text on page N of M" and the screen stays on. Expect a few minutes for a few hundred pages, and keep Paperback open
- Limits: **italics and bold are not seen** (so italic subheadings read as normal paragraphs), small recognition mistakes happen (a letter swapped, a Greek word turned to nonsense), the language is Latin script only (English, French, German, Spanish and so on, not Greek, Cyrillic, Arabic or Chinese), footnotes on a scan are only recognised when their print is clearly smaller, and two-column or table pages stay jumbled
- The app is about 4 MB bigger per processor type for the recognition model
- New plain-Java pieces in `reflow`: `Spread` (finds the fold), `OcrPages` (words and boxes to the page model: straightening, line sizes, margin numbers), `NoTextException`; `data/ReflowOcr.kt` draws the pages and calls ML Kit. The Java part was tested on 126 half-pages of a real scanned book using Tesseract as the recogniser in the sandbox; the ML Kit call itself could not be run there

### Step 18: Smaller app
- The app was 41 MB, mostly because the text recognition model is packed once for every processor type. Now **only arm64-v8a** is packed (every phone from the last ten years). An emulator or an old 32-bit phone needs `paperback.abis=arm64-v8a,armeabi-v7a,x86_64` in `gradle.properties`
- **R8 and resource shrinking are on** for the release build: unused code and resources are removed and the rest is renamed, which also helps start-up. The rules are in `app/proguard-rules.pro`. If a build ever crashes at launch or when opening a book, put `paperback.minify=false` in `gradle.properties` to turn it off again

### Step 19: Navigation choice
- **Settings → App style → Navigation**: **Bar** (as before) or **Clean**. Clean has no bar at the bottom, so the screen is just the page; Home, Library, Stats, Settings and everything else open from the menu button in the top corner. The choice is kept on the phone and is part of the backup
- **Header** on the same page: the "Header size" card is gone; tap any of the four samples to choose it. The fourth, **Buttons only**, has the menu and search buttons and no "paperback" wordmark
- **Accent colour** (Settings → Appearance): eight ready-made colours (Coral, Teal, Amber, Violet, Green, Pink, Blue, Lime) as round swatches, and a rainbow swatch that opens two sliders (hue, then shade) for your own. It recolours buttons, progress, the bar, highlights and links across the app at once, and is saved and included in backups. The app icon and logo stay coral
- **The bar now has Settings** as a fourth item (gear icon). Settings is now a main screen like Home, Library and Stats, so the bar stays visible on it and Back from it leaves the app, as from the other three

### Step 20: Bookshelves
- **Library** shows your books as spines standing on wooden shelves: the title runs down the spine, the author is small at the foot, thicker books are wider, and a thin accent line at the bottom of a spine shows how far you are. Tap to open, long-press for Details / Favorites / Finished / Remove, as with the covers. Favorites get their own shelf on top when you aren't searching or filtering
- **View: Shelves / Covers** (next to Sort and Genre) switches between the shelves and the old grid of covers; the choice is kept and is part of the backup
- **Home**: Continue reading and Today are unchanged. Favorites, Recently read and Recommended for you are now shelves (the book you read last leans on the others). Recommended books open their details page
- Spine colours and heights come from the book itself, so a book always looks the same. The wood is warm in light mode and darker in dark mode
- Header, navigation, Settings and everything else are as in kt-19

### Step 21: The reader counter jumps more often
- The "25 / 136" counter used to move by exactly 1 on most page turns and jump only about once in 10 pages, because a page of English text is only a little more than one 1500-byte piece. The pieces are now **750 bytes** (half of Readest's), so a page holds about two and the counter moves by 2 on most turns, sometimes 1 or 3. The total is about twice as large as before and still does not change with text size
- Want it jumping even more, or less? It is one number: `SIZE_PER_LOCATION` in `data/ReaderPlace.kt` (smaller = bigger jumps)

### Step 22: Stats -> Activity
The Stats tab is now the Activity page from the TypeScript app, in the Kotlin look. It replaces the old Stats tiles; everything those showed is in here.
- **Daily goal**: half-circle gauge with the minutes read today, "N min to go" / "Goal reached", streak, goal met (of the last 7 days), this week's total, and a tick for each of the last 7 days. Tap it to open Reading goals
- **Next best action**: one suggestion for today (keep your streak, N minutes to go, start a streak...)
- **Reading chart**: Week / Month / Year / All time, Time or Pages, a big total with the change against the previous period, a bar chart you can tap or drag (the picked bar is read out above it), a dashed goal line for time in week and month, and arrows to go back and forward. Tap the label between the arrows to jump to any week, month or year
- **Details**: reading pace (pages per hour, with a trend line and the change), sessions (with the change), books finished in the period
- **Session length**: average session, longest session (and when), best day, average a day, each against your daily goal
- **Reading rhythm**: an 18-week calendar, darker = more reading. Tap a day for its time
- **When you read** (last 90 days): by session or by pages. A 24-hour clock (tap an hour), your most active time of day, best weekday, peak hour, counts for morning / afternoon / evening / night, and a bar for each weekday
- **Most read**: your top books for the chosen period with their share of the time. Tap one for its page
- **All time**: reading time, pages, sessions, books read, books finished, days read, current and longest streak, longest session, best day, average on days read, reading since
- Sessions are logged rows of the same book less than 10 minutes apart, merged. Days and hours use the phone's time zone
- Not in this step (they are separate pages in the original): Books, History, Insights, Milestones

### Step 23: Online catalog and a smarter Search
Search is now also a way to find books to read next. The books come from **Open Library** (free, no account, no key); when it has no description or rating, **Google Books** fills in. Nothing can be downloaded from these pages: they only tell you about books, and you add the files yourself.
- **Search page, before you type**: Recent searches, then **For you** (recommendations), **Trending this week**, and **Explore by category** (20 genres). "View all" opens a grid
- **For you** is worked out on the phone from your library: what you finished, rated (5 and 4 stars count most, 1 and 2 count against), favorited and started, by genre and by author. Books you own are left out, authors you rated low are not suggested, and no author fills more than two spots. Each book says why ("Because you liked Dune", "More by Frank Herbert", "You read a lot of Fantasy"). Only a few genre and author names are sent, as search words. It is refreshed when your taste changes, or after six hours
- The keyboard no longer opens by itself on an empty Search page (it would cover these sections); tap the field to type. With the catalog off it opens as before
- **Typing a search** shows your own results first (books, notes, collections, pages as before) and then **Online catalog** results with cover, year and rating. The catalog is asked once you pause typing
- **Catalog book page**: cover, title, author (tap for more by them), star rating and number of ratings, year, how many have read it / want to read it, description (Read more), genres (tap to browse), **More by the author**, **More in this genre**. If you own it, it says so and opens your copy; if not, it says where to get it and links to the Open Library page
- **Privacy**: the whole thing can be turned off (the card shown when it is off, or the link at the bottom of the page). Answers are kept on the phone (trending 6 h, categories 24 h, searches 12 h, book pages 7 days) so pages open fast and still work offline. About describes this. Turning it off is part of the backup
- `catalog/` (Java, tested on a computer with sample data): `Taste`, `Ranker`, `Subjects`, `TitleKey`, `Describe`. `data/catalog/`: `CatalogApi` (requests and parsing), `CatalogController`, `Categories`. `ui/`: `ExploreSection`, `CatalogBookScreen`, `CatalogBrowseScreen`, `CatalogUi`
- Not in this step: a "Want to read" list (saving catalog books to come back to) and showing recommendations on Home

### Step 24: Want to read, and recommendations on Home
- **Want to read** (the old "Wishlist"): open any book in the online catalog and tap **Want to read** to save it. The list is under Menu, More, Shelves, as a row at the top of the Search page, and on Home. Long-press a book on the list to take it off. A book leaves the list by itself when you add a copy to your library (matched by title). The list stays on the phone and is part of the backup (it is kept even if the online catalog is off)
- **Home** has two new rows at the bottom: **Want to read** and **Books you might like** (the same recommendations as "For you" on Search, with the reason under each cover; shown only while the online catalog is on). "View all" opens the full list
- Everything else is as in kt-23

### Step 25: Book page first, reading timer and entries
- **Tapping a book opens its page** (Library, Home). From there: Start / Resume reading. If you prefer the old way, **Settings → App style → Tapping a book → The reader**. The choice is part of the backup. Long-press in Library and tapping a book on shelf pages still open the page too
- **Entries** on the book page (Reading time): every time you read is one card with the date and time, the pages (for example "Pages 76–102" and "+ 27"), the time and your pace in min/page. Reading in the reader is added automatically as before, and now remembers the first and last page. Tap an entry to change it; **Add entry** makes one by hand (date, time, from page, to page, minutes, with 15 m / 30 m / 45 m / 1 h buttons). Pages are the numbers shown in the reader (25 / 136). Everything feeds Activity and the goals like any other reading. Backups include the page numbers
- **Timer**: counts up for one book at a time, with an optional target (15 / 30 / 60 minutes or your own; tap the chosen time again for no limit). It keeps counting with the screen off and after a restart (it works from clock times). A buzz marks the target, but only while the timer page is open. **Finish & save** opens the entry with the time filled in so you can add the pages. **Reset** starts over. The reader already counts your reading in Paperback, so the timer is for paper books or other apps
- Database version 5 (two new columns on sessions); older installs update by themselves and keep their history
- Not done: showing the running timer outside the book page, and a notification when the target is reached with the app closed

### Step 28: Stats -> History
- The Stats tab now has a row of pages at the top: **Activity** and **History** (Books, Insights and Milestones will join it)
- **History** is the month view from the TypeScript app: a calendar of the days you read (a day with reading is tinted, the picked day is solid coral, today is ringed) with the month's totals (sessions, pages, time), and arrows to go back and forward from your first month to this one
- Under the calendar, that month's sessions **day by day, newest first**: each card has the book's cover, title, "Pages 107\u2013137" and the start time, and the time read and pages on the right. Tap a card to open the book. Eight sessions show first, with a "more sessions" button
- Tap a day on the calendar to jump to its sessions
- **Activity links to History**: "View sessions" under the chart opens History on the picked bar's day or month, and a picked day in the Reading rhythm calendar has a "View sessions" button
- Page ranges use the new reading entries (from page / to page); sessions of the same book less than 10 minutes apart are merged into one card, as on the Activity page
- Sessions of a book you removed still show, as "Removed book"

## Not done yet (in the old app, planned in this order)
CBZ / CBR comics, PDF text and notes, journal page, dictionary and saved words, read aloud, milestones, Outfit and Newsreader fonts.

## Layout
- `app/src/main/java/com/paperback/app/data` database, import, stats maths (`Stats.kt` is the port of statsAggregate.ts)
- `.../reader` ReaderActivity (hosts Readium's fragment), the controls overlay, reading-time tracker
- `.../data/opds` the OPDS reader for Discover (XML / JSON parsing, web client with login), `DiscoverController.kt` and `OpdsStore.kt` (catalog list)
- `.../ui` Home, Library, Stats, book page, collections, notes, shelf pages, Discover, settings pages, menu, and the theme (same coral / black / white as before)

## Building
Upload the zip next to `.github/workflows/apk-kotlin-from-one-zip.yml` and run the workflow. Versions are in `gradle/libs.versions.toml`.
If Gradle can't find a version, change it there.

### Step 26: The reader looks like Readest's
- **Page counter**: the "57 / 193" counter is cut into **1500-byte** pieces of the book text, Readest's own size, so a book shows about the same total as in Readest. A page holds a little more than one piece, so the number moves by 1 on most page turns and by 2 now and then (`SIZE_PER_LOCATION` in `data/ReaderPlace.kt`; kt-21 had 750)
- **Page frame, copied from the TypeScript Paperback**: the text stays 64 dp from the top of the screen and 44 dp from the bottom (Readest's 44 dp margins plus its header band), and the chapter name and the counters sit in those two strips like Readest's header and footer (`ReaderTopFrame`, `ReaderBottomFrame` in `reader/ReaderInfo.kt`). The phone's bars no longer add to it. The side margin is Readest's too: the reader's **Margins 100%** now means Readest's side margin (2.5% of the width + 8 dp, about 18 dp), where it used to mean Readium's 20 dp
- **Readest look**: the reader's Look panel has a new **Readest** button next to Book's own and Custom. It sets Readest's own defaults from its source code: sans font, line spacing 1.4, left aligned, 0.6 between paragraphs, no first-line indent, hyphenation on, Margins 100%. Custom also has two new sliders for the paragraph spacing and the first-line indent (Readest's values are the starting ones), and hyphenation is on in Custom (`ReaderLook.readest` in `data/ReaderSettings.kt`)
- **Build fixes**: the build stopped on five compile errors that came with kt-25: the accent picker's colors (`Color.hsl` is not in this Compose version, so `AccentPicker.kt` has its own `hslColor`), the gauge's side gap in `ActivityCharts.kt`, the "Peak hour" stat (`SideStat` sub is optional now), the Library "View" pill (`MenuPill` active is optional now) and a stray comma in `EntryScreen.kt`
- The version name says alpha26; the internal build number is 30 so a phone that has kt-29 accepts the update

### Step 27: reading by itself, or by what you set
Reading in Paperback's reader is still counted for you. A timer or a hand-made entry now **takes over** that stretch of time, so the two never add up twice and you can use both without them conflicting.
- **How it works**: every session knows who made it, counted by the reader or set by you (timer, Add entry, or an entry you edit). Where one of yours overlaps the reader's own count for the same book (a minute of slack on each side), yours is used for the stats, the book page, the goals and the reading pace, and the reader's count for those minutes is left out. It is only hidden, not deleted: delete your entry and the reader's count is back
- **Pages**: after a timer, the pages the reader counted in that time are already filled in on the entry (From / To), and when you change the date, time or minutes, a line says "Paperback's reader counted pages 12–31 in this time. Tap to use them." You can type your own pages instead; yours are the ones used
- **Entry cards** say "Counted automatically" or "Set by you". Opening a counted one and saving makes it yours
- **Where**: `catalog/Coverage.java` (the overlap rule, tested), `Repository.sessions` (what the stats read, reader count left out where you took over) and `Repository.rawSessions` (everything, for the entry editor); the database is version 6 with a `source` column, and backups carry it (`manual`)
- Entries you made with kt-25/26 count as reader-counted until you open and save them once, because the database could not tell them apart
- The version name says alpha27; the internal build number is 31

### Step 29: the book page, polished
- **Progress follows your entries and the timer**: saving an entry (or a timer) with pages moves the book forward the same way reading it does: the percent, the page, "Resume reading" (which now opens at that page), and the book is marked finished when you reach the last page. It never moves backwards, so adding an old entry later changes nothing. To correct the page, use Edit on the book
- **Rating bar**: five small stars you can **slide a finger over**; they fill smoothly while you move and give a tick at each step, and the rating is saved when you lift the finger (that is what removes the lag). Tap the rating you already have to clear it, or slide to the far left. Settings → App style has **Rating scale** (out of 5 or out of 10) and **Rating steps** (whole, halves, quarters), so 4.75 or 7.5 / 10 both work. Old whole-star ratings are kept (a 4 is 8 on the 10 scale underneath), and the Library sort by rating uses the exact value. The maths is in `catalog/RatingMath.java`
- **Page layout**: the cover, title and author, the rating, the big Start / Resume button, then one row: **Finished**, a **star** (favorite, filled when on), a **notes** icon (with the count of notes and bookmarks) and an **edit** pencil. The notes icon opens the book's Notes with three tabs: Notes, Bookmarks and **Journal** (the journal moved here from the page)
- **Progress page**: a card on the book's page (percent, page, time read, a bar) opens it. It holds *This book* (progress, time read, page, sessions), the Timer and Add entry buttons and the reading history, that used to fill the second half of the page. After saving an entry you come back to it
- **Edit book** (the pencil): change the **cover** (any picture from the phone), title, author, genres, publisher, date, language and description; set **your own page count** (it is used for pages, progress, time left, the entry screen and the spine width, and the file's count stays underneath for resuming) and **the page you are on**; choose the **spine colour** and the book's **place on the shelf**. The place is used by a new Library sort, **My order**: the books you placed come first in your order, the rest after, newest first. Typing a number moves the book there and the others make room (`catalog/PageMath.java` has the page maths)
- Backups carry the exact rating, your page count and the spine colour. The database is version 7
- If your other app counts more pages than Paperback does (Paperback counts a book in the file's own pieces), open Edit and type its page count once; entries with those page numbers then add up the right way

### Step 30: gestures
- **Back now works everywhere**: with the menu-only navigation (App style → Navigation → Clean), the phone's swipe-from-the-edge used to close the app, because every main page replaced the one before it. Now Home, Library, Stats and Settings keep a history: Back (or the edge swipe) goes to the page you came from, and only closes the app from the first one. With the bottom bar, Back from a main page returns to Home first
- **Back animation**: the phone's own back preview (Android 14 and later) is turned on, so the page slides away under your finger while you swipe from the edge (`enableOnBackInvokedCallback`)
- **Swipe to go back** (App style, on by default): swipe right anywhere on a page that has somewhere to go back to. A slider, a chart, the rating stars or a row of covers that scrolls sideways keep their own swipe; only a free horizontal swipe of about 80 dp counts (`ui/SwipeHost.kt`). Inside a catalog it goes back one catalog page first, like Back does
- **Swipe between main pages** (App style, off by default): swipe left or right on Home, Library, Stats or Settings to move to the next or previous one
- Both switches are in backups

### Step 31: Top and bottom space
- The reader's Look panel has a new slider, **Top and bottom space**. 100% is Readest's frame (64 dp above the text, 44 dp below); move it down to give the text more of the screen. At 0% only a thin 20 dp strip is left at each edge, just enough for the chapter name and the page counters. Up to 150% gives more room. The Readest button sets it back to 100% (`ReaderLook.verticalSpace`, `readerTopFrame` and `readerBottomFrame` in `reader/ReaderInfo.kt`)

### Step 32: new app icon (Glassy and Flat)
- **New icon**: the open book with a bookmark ribbon, replacing the old purple placeholder. Two looks of the same drawing: **Glassy** (frosted pages, soft light, the default) and **Flat** (one solid colour, no shadows or gradients)
- **Choose it** in Settings → App style → **App icon** (two tiles with a preview; the chosen one says "Selected"). The launcher can take a few seconds to show the change. About shows the chosen icon, and the choice is kept in backups
- **Book size**: the book is 38 dp wide inside the 72 dp the launcher shows (about half), well inside the 66 dp safe circle, so it stays small on every mask shape (circle, squircle, rounded square). It is a single number: `android:inset="25%"` in `mipmap-anydpi-v26/ic_launcher.xml` and `ic_launcher_flat.xml` (30% = smaller book, 20% = bigger). Keep both files the same
- **Themed icon** (Android 13+): both icons have a one-colour layer (`ic_launcher_mono.png`), so they follow the wallpaper colours when "Themed icons" is on
- **How the switch works**: `MainActivity` is no longer the launcher entry itself; two `<activity-alias>` entries (`.IconGlassy`, `.IconFlat`) are, and `data/AppIcon.kt` enables one and disables the other. The saved choice is re-applied at every start (`PaperbackApp`)
- Installing over the old app: the home-screen shortcut points at the old entry, so if the icon is gone from the home screen after the update, drag it out of the app drawer once
- Colours: Flat background `ic_launcher_flat_bg` in `values/colors.xml`; the Glassy background is `drawable-nodpi/ic_launcher_bg.png`

### Step 33: separate Top, Bottom and Header sliders
- The single "Top and bottom space" slider is gone. The reader's Look panel (and Settings → Reader defaults) now has three sliders in dp, 1 dp per step, 0 to 160: **Top space** (screen top to first line of text, default 64), **Bottom space** (last line to screen bottom, default 44) and **Header (chapter name) position** (screen top to the chapter name, default 40). At 0 the text runs to the very edge
- The header no longer depends on the text frame, so it can sit anywhere, even over the text area if you want
- Old saved settings are converted once from the previous 0-150% slider (`ReaderLook.topSpace`, `bottomSpace`, `headerSpace` in `data/ReaderSettings.kt`; `ReaderMarginInfo` in `reader/ReaderInfo.kt`; `applyBand` in `reader/ReaderActivity.kt`)

### Step 34: choose the text at the bottom of the page
- The Look panel has a new **Bottom of the page** row with three toggles: **Pages left** ("4 pages left"), **Percent** ("98.8%", whole book) and **Page / total** ("492 / 496"). Any mix works, or all off. Pages left and Percent share the bottom left, separated by a dot; Page / total stays bottom right. Default is Pages left + Page / total, as before (`ReaderLook.footerItems` in `data/ReaderSettings.kt`, `ReaderMarginInfo` in `reader/ReaderInfo.kt`)

### Step 35: reader settings in folders, and more of them
- Under Font size and Page colors, the reader settings are now four folders; tap a title to open it, only one is open at a time (Settings → Reader defaults uses the same folders)
  - **Page**: side margins, top space, bottom space, columns (Auto or One)
  - **Text**: layout (Book's own / Custom / Readest); with Custom also font, **font weight**, line spacing (now in 0.05 steps), paragraph spacing, first-line indent, **letter spacing**, **word spacing**, alignment and a **hyphenation** switch
  - **Header and footer**: chapter name on/off, header position, **header text size**, the bottom texts (pages left / percent / page of total) and **bottom text size**
  - **Display**: brightness (reader only) and **Keep screen on**
- New values live in `ReaderLook` / `ReaderSettings` (`data/ReaderSettings.kt`); font weight, letter spacing, word spacing and columns are only sent to Readium when changed from normal, so the default look is unchanged. The folders are in `reader/ReaderLookControls.kt`

### Step 36: Stats -> Milestones
- The Stats row now has **Activity, Milestones, History**. Milestones is the page from the TypeScript app (`MilestonesView.tsx`, `TierSheet.tsx`, `milestonesStats.ts`) in the Kotlin look: grey cards, serif numbers, the same four soft accents (mint, blue, yellow, pink) as the other Stats pages
- **Next up** card: the milestone closest to its next tier, with the five tier badges (tick when unlocked, number for the one being worked on, dashed when locked), "8 sessions to go", the bar, and an estimate from the last 90 days ("about 6 weeks"). Tap it to open that milestone's tiers
- **Progress · 10**: Books Read, Pages Read, Reading Sessions, Reading Hours, Words Saved, Books Rated, Quotes Saved, Longest Streak, Epic Books (500+ pages), Notes Written; each with five tiers, a ring and tier pips. Tap a card for its **tier sheet** (value, bar, the five tiers with the date each was unlocked, and a button to where the numbers come from)
- **Timeline · N**: every tier unlocked plus Books Added (10, 25, 50, 100, 250), First Book Added / Finished, First Saved Quote and Longest Book Read, one card per month, newest first, with All / Books / Reading / Notes filters
- **Everything opens something**: a finished-book tier or entry opens the book; a quote or note opens that book's notes; a pages, sessions, hours or streak tier opens **History on that day**; Epic Books and Books Rated open a shelf of those books; Books Read opens Finished; Words Saved goes to the dictionary (Coming soon). Unlocked tiers in the sheet are tappable too
- Differences from the TypeScript app: pages are pages turned in your sessions (like Activity), notes and quotes come from highlights (a highlight with your own text is a note), ratings have no date, and saved words stay at 0 until the dictionary is built (`MilestonesScreen(savedWords = ...)` is ready for it)
- Code: `data/MilestonesStats.kt` (pure functions), `ui/MilestonesScreen.kt`, new icons in `ui/PbIcons.kt`, the page row in `ui/StatsScreen.kt`, the `Shelf:epic` / `Shelf:rated` routes in `ui/PaperbackRoot.kt`

### Step 37: more reader options from the TypeScript Paperback, and the menu button
- The **≡ button in the reader's top bar** is now a menu, like the one in the TypeScript version: Contents, Bookmarks and notes, Search in book, **Scrolled mode** (on/off), **Invert images in dark mode** (on/off) and **Reader settings** (opens the settings sheet, with the page still visible behind it)
- Reader settings has a new **Behavior** folder: scrolled mode, tap to turn pages (with "both sides go forward" and "swap tap sides"), **volume keys turn pages**, **swipe along the left edge for brightness**, invert images in dark mode, keep screen on
- **Page** folder: columns Auto / One / Two, **reading direction** (from the book / left to right / right to left), **vertical writing**, **screen orientation** (Auto / Portrait / Landscape)
- **Header and footer** folder: the bottom of the page can now also show **time left**, **clock** (follows the phone's 12 or 24 hour setting), **battery** and a thin **progress line** along the bottom edge, next to pages left, percent and page / total
- Not done (the TypeScript version has them, Readium has no equivalent): paging animation, minimum font size, custom fonts, paragraph mode, speed reading, auto scroll, e-ink mode, gamepad and custom page-turner keys, pull-down to bookmark, quick actions. Code: `data/ReaderSettings.kt`, `reader/ReaderLookControls.kt`, `reader/ReaderInfo.kt`, `reader/ReaderChrome.kt` (menu), `reader/ReaderActivity.kt` (taps, volume keys, brightness strip, orientation)

### Step 38: paging animation (from the TypeScript version)
- Reader settings → Behavior: **Paging animation** (on by default) and **Animation style**: **Push** (both pages move together as one strip) or **Slide** (the old page slides away over the new one, which stays still). The TypeScript version's third style, Page Curl, is not done yet (it needs its own 3D renderer there)
- With the animation on, tapping an edge or pressing a volume key glides to the next page; off, they jump. Swiping always follows your finger, as the page view always does
- The style is set on the page view Readium uses, found at runtime (`applyPageStyle` in `reader/ReaderActivity.kt`); if a Readium update changes that view the style is simply ignored and pages turn as before. Slide does not apply to right-to-left books

### Step 39: auto scroll and pull down to bookmark (from the TypeScript version)
- **Auto scroll**: ≡ menu → *Auto scroll* (needs Scrolled mode, greyed out otherwise). The page scrolls slowly and steadily, 20 dp per second at 100%; the speed is a setting (*Auto scroll speed*, 25 to 500%, in Reader settings → Behavior). Small controls appear at the bottom (slower, faster, pause, stop). A tap on the page pauses and resumes instead of showing the controls. At the end of a chapter it goes on to the next one, at the end of the book it stops. It also stops when you leave scrolled mode or leave the reader (`setAutoScroll` in `reader/ReaderActivity.kt`)
- **Pull down to bookmark** (Behavior, on by default): drag down from the top edge of the page. A bookmark ribbon follows your finger (with the same damping as the TypeScript version: 18 dp to start, 100 to trigger); let go past the line to add or remove the bookmark. The strip it listens in is the top margin of the page (at least 48 dp); taps there still work, but a sideways swipe that starts in that strip does not turn the page

### Step 40: build fix
- The build failed because this Readium version has no `goLeft` / `goRight`. Tapping an edge now works out forward or back itself (left edge = previous page in a left-to-right book, next page in a right-to-left one; "swap tap sides" and "both sides go forward" still apply) and uses `goForward` / `goBackward` (`handleTap` in `reader/ReaderActivity.kt`)

### Step 41: selection tools, quick action and copy to notebook (from the TypeScript version)
- Reader settings → new **Selection** folder
  - **Tools in the menu over selected text** (like "Customize Toolbar"): Highlight, Note, Copy, Dictionary, Search, Speak, Share. Default is Highlight and Note, as before
  - **Quick action**: None, Dictionary, Search, Speak or Share. It runs by itself as soon as text is selected (as soon as the selection menu appears, so it works on the word you long-press; if you then drag the handles to a longer text, use the menu item for that)
  - **Copy to notebook**: the Copy tool also saves the copied text as a highlight in this book's notes
- Dictionary hands the text to any dictionary or translate app on the phone that accepts selected text (a web search if there is none). Search opens the in-book search with the text filled in. Speak reads it with the phone's own voice. Share opens the share sheet. (`selectionCallback` and `runSelectionAction` in `reader/ReaderActivity.kt`)

### Step 42: custom fonts (from the TypeScript version's Manage Fonts)
- Reader settings → Text (with Custom layout) has a new **More fonts** row under Font: **+ Import font** (pick a .ttf, .otf, .woff or .woff2 file; it is copied into the app), every imported font as a button (a button's name is the file name), and six fonts that come with Android (Condensed, Light, Medium, Casual, Cursive, Serif mono). Picking Serif, Sans or Mono goes back to the normal choice. **Remove …** deletes an imported font
- The reading engine can only serve fonts it was built with, so an imported font is handed to each page itself: when a page opens, `injectFont` in `reader/ReaderActivity.kt` adds the font to the page (as a FontFace) and the screens are counted again. Fonts are stored in `files/fonts` (`data/ReaderFonts.kt`); the choice is `ReaderLook.fontName`
- Android's own fonts depend on the phone (some phones do not have all six); the import route works on every phone

### Step 43: build fix
- Pull down to bookmark: `positionChange()` needed its import (`androidx.compose.ui.input.pointer.positionChange`) in `reader/ReaderActivity.kt`

### Step 44: Stats -> Books
- The Stats row is now **Activity, Milestones, Books, History**. Books is the page from the TypeScript app (`BooksView.tsx`, `booksStats.ts`) in the Kotlin look: grey cards, serif numbers, the same four soft accents
- **Library** card: how many books, with the three newest covers fanned out on the right. Tap it for the Library
- **Four tiles**: *Finished* (opens the Finished shelf), *Reading* (opens the books you are reading), *Longest read* (pages of the longest finished book and its title; opens that book) and *Languages* (how many, named; opens the books by language). A tile with nothing behind it (0 finished, no longest read) is not tappable and has no arrow
- **Reading progress**: up to six books you are reading, furthest along first, each with its percentage and bar (tap for the book), "Open shelf" for the whole shelf and "and N more" when there are more than six
- **Authors**: up to 14 chips with the number of books when it is more than one (tap for that author's books) and a "+N" chip that opens the list of all authors. "A; B", "A & B" and "A and B" count as two authors (a book by two authors now shows up under both)
- **Ratings**: "2 of 5 rated · average 4.5" with the stars; tap for the books by rating
- New **sectioned shelf** page (`ui/ShelfSections.kt`): *Languages* (a section per language, biggest first, "Language not set" last), *Ratings* (5 stars down to 1, then "Not rated yet" with finished books first) and *Epic books* (longest first). Covers in rows of three, a small pill on the cover ("4★"), the book's status under it. The routes `Shelf:langs`, `Shelf:rated` and `Shelf:epic` open it; the Milestones page's Epic Books and Books Rated now open the same sectioned shelves
- Differences from the TypeScript app: ratings are stored on the book here, the page count is the book's own (or the one you set), and "newest" is the book last opened or added
- Code: `data/BooksStats.kt` (pure functions), `ui/BooksScreen.kt`, `ui/ShelfSections.kt`, the page row in `ui/StatsScreen.kt`, the `Shelf` route in `ui/PaperbackRoot.kt`; `Authors.has` in `data/BookMeta.kt` understands several authors

### Step 45: Stats -> Insights
- The Stats row is now **Activity, Milestones, Books, History, Insights**: every page of the TypeScript Stats screen is in the app. Insights is `InsightsView.tsx` / `insightsStats.ts` in the Kotlin look
- **This month so far**: "You've read 3h 20m this month." or "You're reading 12% more than October." (green when up, pink when down), a bar for this month and one for the same days of last month, and the note that says so. Tap it for History today
- **Consistency**: a ring with the percentage of the last 30 days you read (at least a minute), "4 of 30 days", your streak and best streak. Tap it for History
- **Reading speed**: pages per hour over the last 60 days (a dash until there are ten minutes of reading), the fastest month, and six monthly bars (the fastest one bright, months with too little reading flat). **Tap a month** to open it in History
- **Your records**: Best day, Longest session, Best week (Monday to Sunday) and Most pages a day. Each opens History on that day (the week opens on its Monday)
- **When you'll finish**: up to four books in progress with cover, pages left, reading time left and "about 3 weeks" (from the pace on that book once it has ten minutes of reading, else your overall pace, and how many days a week you read). Tap one for the book
- **Books in 2026**: finished against your yearly goal (Goals page), a bar with a dotted mark where a straight line through the year would be today, "3 behind the line" and "5 by December at this rate". Tap it for the books you finished this year (the shelf `Shelf:done-2026`, also new)
- Pages are the pages turned in your sessions, as on the Activity page. Reading speed and the forecast use the same numbers, so they only show once there is enough reading
- Code: `data/InsightsStats.kt` (pure functions), `ui/InsightsScreen.kt`, the page row in `ui/StatsScreen.kt`, `done-YEAR` in `buildShelf` (`data/BooksStats.kt`); the Books page's tiles are shared with it (`ui/BooksScreen.kt`)

### Step 46: Read aloud (text to speech)
- **Listen** in the reader: a headphones button in the bottom card (a round button in Compact and Quick, a "Listen" tile in Tiles). It reads the book from the page you are on, marks the sentence (and, word by word, the word) on the page and turns the pages by itself
- **Mini player** over the page: cover, book, chapter, elapsed and remaining time, previous / play / next, stop, and a thin progress line. "Minimal" style (Settings → Read aloud → Player) shows speed, paragraph and sentence steps, play and time left. Tap it to open the **player sheet**
- **Player sheet**: the chapter as a list of sentences (the one being said in a card; tap any sentence to read from there), **A− / A+** for the sentence size, a scrubber with time, then pause-after-sentence, previous / next paragraph, previous / next sentence, play, and **A-B loop** (tap once to set the start, again to set the end, again to clear). Tiles under it: **Speed** (0.5-3.0×), **Voice** and **Sleep timer** (end of chapter, or 1 minute to 8 hours), and **Offline Audio** ("3 of 14 downloaded"; download or delete a chapter or all of them)
- **Voices**: the Edge neural voices (296, grouped by the book's language, with Multilingual / Expressive tags) and the phone's own voices (work offline). The voice is remembered per language; if the internet fails the app falls back to a phone voice
- **Back to Read Aloud**: if you turn the page yourself, following pauses and a button brings you back to the sentence being read
- **Screen off**: reading continues with the screen off or in another app, with a media notification (play / pause, previous, next, stop) and lock-screen controls; it pauses when headphones are pulled out or another app takes the sound. Listening time while the reader is not on screen is added to your reading time and the book's progress follows the voice
- **Settings → Read aloud** (also found by Search): speed, pause after each sentence, highlight by word or sentence, highlight or underline and its colour, player style, what the lock screen shows (sentence / paragraph / chapter), and the audio kept on the phone (on/off, size limit, clear)
- Not ported yet: custom OpenAI-style voice services, paired audiobook narration, RSVP / paragraph mode, the CarPlay controls, and the strikethrough / squiggly / outline marker styles
- New permissions in the manifest: foreground service (media playback), notifications (Android 13+: asked the first time you press Listen; reading aloud works without it, only the controls are missing), wake lock; and `<queries>` for the phone's TTS engines
- Code: everything is in `tts/`: `TtsText.kt` (cuts a chapter into sentences the page can find), `EdgeSpeech.kt` (the Edge voice protocol), `TtsSpeakers.kt` (Edge and phone voices, audio cache), `TtsSession.kt` (the reading loop, timer, loop, downloads), `TtsService.kt` (notification), `TtsUi.kt` (mini player and sheet), `TtsSettingsScreen.kt`. Hooks: `reader/ReaderActivity.kt` (implements `TtsHost`), `reader/ReaderChrome.kt` (the button), `Dest.ReadAloud` in `ui/MenuSheet.kt` and `ui/PaperbackRoot.kt`
- The version name is alpha33; the internal build number is 37
- Starting Read aloud turns Auto scroll off, and the selection menu's "Speak" pauses it first
