package com.paperback.app.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.cancellation.CancellationException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** One sentence to say. [voice] decides the engine: ids that start with "sys:" are the phone's own voices, the rest are Edge's. */
class SpeakRequest(val text: String, val lang: String, val voice: TtsVoice)

/** Characters [start, end) of the request's text that are being said right now. */
class WordSpan(val start: Int, val end: Int)

/** The engine could not say the sentence. [permanent]: trying again will not help (skip it). */
class SpeakException(message: String, val permanent: Boolean = false) : Exception(message)

interface Speaker {
    /** Says the sentence and returns when it is finished. Cancelling the coroutine stops the sound. */
    suspend fun speak(req: SpeakRequest, rate: Float, onStart: () -> Unit, onWord: (WordSpan) -> Unit)
    fun pause()
    fun resume()
    fun setRate(rate: Float)
    fun prefetch(reqs: List<SpeakRequest>) {}
    fun release()
}

const val SYSTEM_PREFIX = "sys:"

// ---- the audio cache --------------------------------------------------------------------------------

/**
 * Edge audio kept on the phone, one MP3 and one list of word times per sentence. Everything played is kept (up to the size limit
 * in settings, oldest first) so reading the same page again needs no internet. "Offline audio" for a chapter downloads all of its
 * sentences and writes their names to a ".keys" file; those files are never swept away.
 */
class TtsAudioCache(context: Context) {
    private val root = File(context.filesDir, "tts_audio").also { it.mkdirs() }
    private val keysDir = File(root, "keys").also { it.mkdirs() }
    private var storesSinceSweep = 0

    fun key(req: SpeakRequest): String = key(req.voice.id, req.text)

    fun key(voiceId: String, text: String): String =
        MessageDigest.getInstance("SHA-1").digest("$voiceId|$text".toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    fun audioFile(key: String) = File(root, "$key.mp3")
    private fun wordsFile(key: String) = File(root, "$key.wb")

    fun has(key: String): Boolean = audioFile(key).let { it.exists() && it.length() > 0 }

    class Entry(val file: File, val boundaries: List<WordBoundary>)

    fun load(key: String): Entry? {
        val f = audioFile(key)
        if (!f.exists() || f.length() == 0L) return null
        f.setLastModified(System.currentTimeMillis())
        val words = runCatching {
            wordsFile(key).readLines().mapNotNull { line ->
                val p = line.split('\t', limit = 3)
                if (p.size < 3) null else WordBoundary(p[0].toDouble(), p[1].toDouble(), p[2])
            }
        }.getOrDefault(emptyList())
        return Entry(f, words)
    }

    fun store(key: String, audio: EdgeAudio, budgetMb: Int): Entry {
        val f = audioFile(key)
        val tmp = File(root, "$key.part")
        tmp.writeBytes(audio.bytes)
        tmp.renameTo(f)
        wordsFile(key).writeText(audio.boundaries.joinToString("\n") { "${it.startSec}\t${it.durationSec}\t${it.text.replace('\t', ' ').replace('\n', ' ')}" })
        if (++storesSinceSweep >= 25) {
            storesSinceSweep = 0
            sweep(budgetMb)
        }
        return Entry(f, audio.boundaries)
    }

    fun discard(key: String) {
        if (key in protectedKeys()) return
        audioFile(key).delete()
        wordsFile(key).delete()
    }

    fun protectedKeys(): Set<String> {
        val out = HashSet<String>()
        keysDir.listFiles()?.forEach { f -> runCatching { out += f.readLines().filter { it.isNotBlank() } } }
        return out
    }

    /** Deletes the oldest unprotected audio until the folder fits in [budgetMb]. */
    fun sweep(budgetMb: Int) {
        val keep = protectedKeys()
        val files = root.listFiles { f -> f.isFile && (f.name.endsWith(".mp3") || f.name.endsWith(".wb")) } ?: return
        var total = files.sumOf { it.length() }
        val limit = budgetMb * 1024L * 1024L
        if (total <= limit) return
        for (f in files.filter { it.name.substringBeforeLast('.') !in keep }.sortedBy { it.lastModified() }) {
            total -= f.length()
            f.delete()
            if (total <= limit) break
        }
    }

    fun sizeBytes(): Long = root.listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L

    /** Deletes all audio that is not part of a downloaded chapter. */
    fun clearLive() {
        val keep = protectedKeys()
        root.listFiles { f -> f.isFile && f.name.substringBeforeLast('.') !in keep }?.forEach { it.delete() }
    }

    // ---- downloaded chapters ----

    private fun keysFile(bookId: String, voiceId: String, chapter: Int) =
        File(keysDir, "${bookId.take(16)}_${voiceId.replace(Regex("[^A-Za-z0-9-]"), "_")}_$chapter.keys")

    fun markDownloading(bookId: String, voiceId: String, chapter: Int, keys: List<String>) {
        keysFile(bookId, voiceId, chapter).writeText(keys.joinToString("\n"))
    }

    fun downloadedKeys(bookId: String, voiceId: String, chapter: Int): List<String>? =
        keysFile(bookId, voiceId, chapter).takeIf { it.exists() }?.readLines()?.filter { it.isNotBlank() }

    fun deleteDownload(bookId: String, voiceId: String, chapter: Int) {
        val f = keysFile(bookId, voiceId, chapter)
        val keys = if (f.exists()) f.readLines().filter { it.isNotBlank() } else emptyList()
        f.delete()
        val still = protectedKeys()
        for (k in keys) if (k !in still) { audioFile(k).delete(); wordsFile(k).delete() }
    }
}

// ---- Edge voices --------------------------------------------------------------------------------------

/** Plays Edge's neural voices: each sentence is fetched as MP3 (several ahead of time), cached, and played with MediaPlayer. */
class EdgeSpeaker(
    private val cache: TtsAudioCache,
    private val cacheEnabled: () -> Boolean,
    private val cacheBudgetMb: () -> Int,
) : Speaker {
    private val job = kotlinx.coroutines.SupervisorJob()
    private val scope = CoroutineScope(job + Dispatchers.Main)
    private val gate = Semaphore(3)
    private val inflight = ConcurrentHashMap<String, Deferred<TtsAudioCache.Entry>>()
    private val main = Handler(Looper.getMainLooper())

    private var player: MediaPlayer? = null
    private var paused = false
    private var rate = 1f
    private var onStartPending: (() -> Unit)? = null

    /** Gets a sentence's audio from the cache or from Edge. Several callers asking for the same sentence share one request. */
    fun fetch(req: SpeakRequest): Deferred<TtsAudioCache.Entry> {
        val k = cache.key(req)
        inflight[k]?.let { if (!it.isCancelled) return it }
        val d = scope.async(Dispatchers.IO) {
            cache.load(k) ?: gate.withPermit {
                val audio = synthesize(req)
                cache.store(k, audio, cacheBudgetMb())
            }
        }
        inflight[k] = d
        d.invokeOnCompletion { inflight.remove(k, d) }
        return d
    }

    private suspend fun synthesize(req: SpeakRequest): EdgeAudio {
        var last: Exception? = null
        for (attempt in 1..3) {
            try {
                return withContext(Dispatchers.IO) {
                    coroutineScope {
                        val ws = AtomicReference<WebSocketClient?>(null)
                        val watcher = launch { try { awaitCancellation() } finally { ws.get()?.close() } }
                        try {
                            EdgeSpeech.synthesize(req.voice.lang, req.text, req.voice.id, onOpen = { ws.set(it) })
                        } finally {
                            watcher.cancel()
                        }
                    }
                }
            } catch (e: EdgeSpeech.NoAudioException) {
                throw SpeakException("Nothing to say here.", permanent = true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                last = e
                if (attempt < 3) delay(400L * attempt)
            } catch (e: Exception) {
                last = e
                break
            }
        }
        throw SpeakException(last?.message ?: "The Edge voice could not be reached.")
    }

    override fun prefetch(reqs: List<SpeakRequest>) {
        val wanted = reqs.map { cache.key(it) }.toSet()
        for ((k, d) in inflight) if (k !in wanted && !d.isCompleted) d.cancel()
        for (r in reqs) if (!cache.has(cache.key(r))) fetch(r)
    }

    /** Used by the chapter download: fetches and caches without playing. */
    suspend fun download(req: SpeakRequest) {
        val k = cache.key(req)
        if (cache.has(k)) return
        gate.withPermit {
            if (cache.has(k)) return
            val audio = synthesize(req)
            cache.store(k, audio, Int.MAX_VALUE)
        }
    }

    override suspend fun speak(req: SpeakRequest, rate: Float, onStart: () -> Unit, onWord: (WordSpan) -> Unit) {
        this.rate = rate
        var entry: TtsAudioCache.Entry? = null
        var tries = 0
        while (entry == null) {
            try {
                entry = fetch(req).await()
            } catch (e: CancellationException) {
                // either we were cancelled (rethrow) or a preload for another place cancelled this fetch (ask again)
                if (!kotlin.coroutines.coroutineContext[kotlinx.coroutines.Job]!!.isActive) throw e
                if (++tries > 3) throw SpeakException("The audio request kept being cancelled.")
            }
        }
        try {
            play(entry, req, onStart, onWord)
        } finally {
            if (!cacheEnabled()) cache.discard(cache.key(req))
        }
    }

    private suspend fun play(entry: TtsAudioCache.Entry, req: SpeakRequest, onStart: () -> Unit, onWord: (WordSpan) -> Unit) {
        val words = TtsAlign.words(req.text, entry.boundaries)
        val endSec = TtsAlign.speechEndSec(entry.boundaries)
        suspendCancellableCoroutine<Unit> { cont ->
            val mp = MediaPlayer()
            player = mp
            var started = false
            var finished = false
            var lastWord = -1
            lateinit var poll: Runnable

            fun finish(error: Throwable? = null) {
                if (finished) return
                finished = true
                main.removeCallbacks(poll)
                runCatching { mp.release() }
                if (player === mp) player = null
                if (!cont.isActive) return
                if (error != null) cont.resumeWithException(error) else cont.resume(Unit)
            }

            poll = Runnable {
                if (finished) return@Runnable
                if (started) {
                    val pos = runCatching { mp.currentPosition / 1000.0 }.getOrDefault(0.0)
                    if (words.isNotEmpty()) {
                        val i = TtsAlign.indexAt(words, pos + 0.03)
                        if (i >= 0 && i != lastWord) {
                            lastWord = i
                            onWord(WordSpan(words[i].start, words[i].end))
                        }
                    }
                    if (endSec != null && pos >= endSec && !paused) {
                        finish()
                        return@Runnable
                    }
                }
                main.postDelayed(poll, 40)
            }

            try {
                mp.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                )
                mp.setDataSource(entry.file.path)
                mp.setOnPreparedListener {
                    if (finished) return@setOnPreparedListener
                    started = true
                    if (paused) onStartPending = onStart
                    if (!paused) {
                        mp.start()
                        applySpeed(mp)
                        onStart()
                    }
                }
                mp.setOnCompletionListener { finish() }
                mp.setOnErrorListener { _, what, _ ->
                    // a damaged cached file: remove it so the next try fetches it again
                    cache.discard(cache.key(req))
                    finish(SpeakException("The audio could not be played ($what)."))
                    true
                }
                mp.prepareAsync()
                main.post(poll)
            } catch (e: Exception) {
                finish(SpeakException(e.message ?: "The audio could not be played."))
            }
            cont.invokeOnCancellation {
                finished = true
                main.removeCallbacks(poll)
                runCatching { mp.release() }
                if (player === mp) player = null
            }
        }
    }

    private fun applySpeed(mp: MediaPlayer) {
        try {
            mp.playbackParams = PlaybackParams().setSpeed(rate)
        } catch (e: Exception) {
            // some phones refuse speeds above 2x: use the highest they accept
            runCatching { mp.playbackParams = PlaybackParams().setSpeed(minOf(rate, 2f)) }
        }
    }

    override fun pause() {
        paused = true
        player?.let { p -> runCatching { if (p.isPlaying) p.pause() } }
    }

    override fun resume() {
        paused = false
        player?.let { p ->
            runCatching {
                if (!p.isPlaying) {
                    p.start()
                    applySpeed(p)
                    onStartPending?.invoke()
                    onStartPending = null
                }
            }
        }
    }

    override fun setRate(rate: Float) {
        this.rate = rate
        player?.let { p -> if (!paused) runCatching { if (p.isPlaying) applySpeed(p) } }
    }

    override fun release() {
        paused = false
        player?.let { runCatching { it.release() } }
        player = null
        job.cancel()
    }
}

// ---- the phone's own voices ---------------------------------------------------------------------------

/** Android's built-in text-to-speech. Works without internet. The phone's engine reports the word being said, when it can. */
class SystemSpeaker(private val context: Context) : Speaker {
    private var tts: TextToSpeech? = null
    private var ready: CompletableDeferred<Boolean>? = null
    private val main = Handler(Looper.getMainLooper())
    private var counter = 0
    private var paused = false
    private var gate: CompletableDeferred<Unit>? = null
    private var rate = 1f

    private class Cb(val started: () -> Unit, val done: () -> Unit, val stopped: () -> Unit, val error: (Int) -> Unit, val onWord: (WordSpan) -> Unit)

    private val callbacks = ConcurrentHashMap<String, Cb>()

    /** Starts the phone's speech engine (once). False if there is none. */
    suspend fun ensure(): Boolean {
        ready?.let { return it.await() }
        val d = CompletableDeferred<Boolean>()
        ready = d
        tts = TextToSpeech(context.applicationContext) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                t.setOnUtteranceProgressListener(
                    object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) { callbacks[utteranceId]?.let { cb -> main.post { cb.started() } } }
                        override fun onDone(utteranceId: String?) { callbacks.remove(utteranceId)?.done?.invoke() }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { callbacks.remove(utteranceId)?.error?.invoke(-1) }
                        override fun onError(utteranceId: String?, errorCode: Int) { callbacks.remove(utteranceId)?.error?.invoke(errorCode) }
                        override fun onStop(utteranceId: String?, interrupted: Boolean) { callbacks.remove(utteranceId)?.stopped?.invoke() }
                        override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                            val cb = callbacks[utteranceId] ?: return
                            main.post { cb.onWord(WordSpan(start, end)) }
                        }
                    },
                )
                d.complete(true)
            } else {
                d.complete(false)
            }
        }
        return d.await()
    }

    /** The voices installed on the phone for [lang] (two letters), best first. */
    fun voices(lang: String): List<TtsVoice> {
        val t = tts ?: return emptyList()
        val want = TtsPrefs.lang2(lang)
        val list = runCatching { t.voices }.getOrNull().orEmpty()
            .filter { it.locale.language.equals(want, true) && !it.features.contains("notInstalled") }
            .sortedWith(compareBy({ it.isNetworkConnectionRequired }, { it.name }))
        return list.mapIndexed { i, v ->
            val where = v.locale.getDisplayCountry(Locale.ENGLISH).ifBlank { v.locale.toLanguageTag() }
            TtsVoice(SYSTEM_PREFIX + v.name, "Voice ${i + 1} · $where" + if (v.isNetworkConnectionRequired) " (online)" else "", v.locale.toLanguageTag(), null, offline = !v.isNetworkConnectionRequired)
        }
    }

    override suspend fun speak(req: SpeakRequest, rate: Float, onStart: () -> Unit, onWord: (WordSpan) -> Unit) {
        this.rate = rate
        if (!ensure()) throw SpeakException("The phone has no speech engine installed.")
        val t = tts ?: throw SpeakException("The phone has no speech engine installed.")
        while (true) {
            gate?.takeIf { paused }?.await()
            if (!speakOnce(t, req, onStart, onWord)) continue // stopped by pause: wait, then say it again from its start
            return
        }
    }

    /** True when the sentence was said to the end, false when a pause cut it off. */
    private suspend fun speakOnce(t: TextToSpeech, req: SpeakRequest, onStart: () -> Unit, onWord: (WordSpan) -> Unit): Boolean =
        suspendCancellableCoroutine { cont ->
            val id = "pb" + (counter++)
            callbacks[id] = Cb(
                started = onStart,
                done = { if (cont.isActive) cont.resume(true) },
                stopped = { if (cont.isActive) cont.resume(false) },
                error = { code -> if (cont.isActive) cont.resumeWithException(SpeakException("The phone's voice failed (error $code).")) },
                onWord = onWord,
            )
            val name = req.voice.id.removePrefix(SYSTEM_PREFIX)
            val chosen = runCatching { t.voices }.getOrNull()?.firstOrNull { it.name == name }
            if (chosen != null) t.voice = chosen else t.language = Locale.forLanguageTag(req.lang)
            t.setSpeechRate(rate)
            val r = t.speak(req.text, TextToSpeech.QUEUE_FLUSH, Bundle(), id)
            if (r != TextToSpeech.SUCCESS) {
                callbacks.remove(id)
                cont.resumeWithException(SpeakException("The phone's voice could not start."))
            }
            cont.invokeOnCancellation {
                callbacks.remove(id)
                runCatching { t.stop() }
            }
        }

    override fun pause() {
        if (paused) return
        paused = true
        gate = CompletableDeferred()
        runCatching { tts?.stop() }
    }

    override fun resume() {
        if (!paused) return
        paused = false
        gate?.complete(Unit)
        gate = null
    }

    override fun setRate(rate: Float) {
        this.rate = rate // takes effect from the next sentence
    }

    override fun release() {
        callbacks.clear()
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        tts = null
        ready = null
    }
}
