package com.paperback.app.tts

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.paperback.app.ui.AsCard
import com.paperback.app.data.HeaderSize
import com.paperback.app.ui.PbNote
import com.paperback.app.ui.PbPage
import com.paperback.app.ui.PbSlider
import com.paperback.app.ui.Segmented
import com.paperback.app.ui.theme.pbTokens
import kotlin.math.roundToInt

/**
 * Settings → Read aloud (the TypeScript app's TTSPanel and the audio cache section): speed, how the spoken
 * text is marked on the page, the player's look, what the lock screen shows and how much audio is kept.
 */
@Composable
fun TtsSettingsScreen(headerSize: HeaderSize, onMenu: () -> Unit, onSearch: () -> Unit) {
    val t = pbTokens()
    val context = LocalContext.current
    val p = TtsHub.prefs(context)
    val cache = remember { TtsAudioCache(context.applicationContext) }
    var bytes by remember { mutableLongStateOf(cache.sizeBytes()) }

    PbPage("Read aloud", headerSize, onMenu, onSearch) {
        Text(
            "Have the book read to you with natural voices. Start it with the headphones button in the reader.",
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 18.dp),
            color = t.setSub, fontSize = 15.sp, lineHeight = 21.75.sp,
        )
        AsCard("Speed", "${TtsPrefs.formatRate(p.rate)} — also changed in the player.") {
            PbSlider(
                value = p.rate,
                onValueChange = { p.setRate(it) },
                valueRange = TtsPrefs.SPEED_MIN..TtsPrefs.SPEED_MAX,
                trackColor = t.ink.copy(alpha = 0.15f),
            )
        }
        AsCard("Pause after each sentence", "A short stop after every sentence, so you can follow along slowly.") {
            Segmented(listOf(true to "On", false to "Off"), p.pauseAfterSentence) { p.setPauseAfterSentence(it) }
        }
        AsCard("Highlight", "What is marked on the page while it is read.") {
            Segmented(listOf("word" to "Word by word", "sentence" to "Sentence"), p.granularity) { p.setGranularity(it) }
        }
        AsCard("Marker style", "") {
            Segmented(listOf("highlight" to "Highlight", "underline" to "Underline"), p.style) { p.setStyle(it) }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.padding(horizontal = 2.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (color in TtsPrefs.QUICK_COLORS) {
                    val on = p.color == color
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(color))
                            .then(if (on) Modifier.border(3.dp, t.ink, CircleShape) else Modifier)
                            .clickable { p.setColor(color) },
                    )
                }
            }
        }
        AsCard("Player", "The bar that appears over the page while reading aloud.") {
            Segmented(listOf("full" to "Full", "minimal" to "Minimal"), p.playerStyle) { p.setPlayerStyle(it) }
        }
        AsCard("Lock screen", "What the notification shows, and how often it changes.") {
            Segmented(
                listOf("sentence" to "Sentence", "paragraph" to "Paragraph", "chapter" to "Chapter"),
                p.mediaMetadata,
            ) { p.setMediaMetadata(it) }
        }
        AsCard("Keep audio", "Sentences you listened to stay on the phone, so hearing them again costs no data.") {
            Segmented(listOf(true to "On", false to "Off"), p.cacheEnabled) { p.setCacheEnabled(it) }
            if (p.cacheEnabled) {
                Spacer(Modifier.height(14.dp))
                Text("Up to ${p.cacheBudgetMb} MB", color = t.ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                PbSlider(
                    value = p.cacheBudgetMb.toFloat(),
                    onValueChange = { p.setCacheBudgetMb(((it / 50f).roundToInt() * 50).coerceIn(50, 2000)) },
                    valueRange = 50f..2000f,
                    trackColor = t.ink.copy(alpha = 0.15f),
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Clear saved audio  ·  ${"%.1f".format(java.util.Locale.US, bytes / 1_048_576.0)} MB",
                color = t.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(t.bg)
                    .clickable {
                        cache.clearLive()
                        bytes = cache.sizeBytes()
                    }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }
        PbNote("Chapters you download for offline listening are not removed by this.")
    }
}
