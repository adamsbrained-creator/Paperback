package com.paperback.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.paperback.app.data.Backup
import com.paperback.app.data.BackupCounts
import com.paperback.app.data.Book
import com.paperback.app.data.BookCollection
import com.paperback.app.data.Bookmark
import com.paperback.app.data.DiscoverController
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.Goals
import com.paperback.app.data.HeaderSize
import com.paperback.app.data.NavStyle
import com.paperback.app.data.Highlight
import com.paperback.app.data.ImportOutcome
import com.paperback.app.data.PendingBackup
import com.paperback.app.data.ReflowOutcome
import com.paperback.app.data.ReaderSettings
import com.paperback.app.data.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A PDF being turned into an EPUB: [page] of [total] read so far. */
data class ReflowState(val bookId: String, val page: Int, val total: Int, val ocr: Boolean = false)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val graph = (app as PaperbackApp).graph

    val books = graph.repo.books
    val sessions = graph.repo.sessions
    val collections = graph.repo.collections
    val membership = graph.repo.membership
    val allHighlights = graph.repo.allHighlights
    val allBookmarks = graph.repo.allBookmarks

    /** Everything behind the Discover pages (catalogs, browsing, downloads). Lives here so a half-browsed catalog survives leaving the page. */
    val discover = DiscoverController(
        scope = viewModelScope,
        appScope = graph.appScope,
        http = graph.opdsHttp,
        store = graph.opdsStore,
        repo = graph.repo,
        cacheDir = app.cacheDir,
        say = { text -> say(text) },
    )

    /** The online side of Search: trending, recommendations, categories, book details. */
    val catalog = CatalogController(
        scope = viewModelScope,
        api = graph.catalogApi,
        prefs = graph.prefs,
        library = { books.value },
    )

    // ---- app look and goals (Settings) ----------------------------------------------------

    val headerSize: StateFlow<HeaderSize> = graph.prefs.headerSize
    val navStyle: StateFlow<NavStyle> = graph.prefs.navStyle
    val libraryShelf: StateFlow<Boolean> = graph.prefs.libraryShelf
    val accent: StateFlow<Int> = graph.prefs.accent
    val themeMode: StateFlow<ThemeMode> = graph.prefs.themeMode
    val goals: StateFlow<Goals> = graph.prefs.goals
    val readerSettings: ReaderSettings get() = graph.settings

    // ---- search ---------------------------------------------------------------------------

    private val _recentSearches = MutableStateFlow(graph.searchHistory.recent())
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    fun addRecentSearch(query: String) {
        _recentSearches.value = graph.searchHistory.add(query)
    }

    fun clearRecentSearches() {
        graph.searchHistory.clear()
        _recentSearches.value = emptyList()
    }

    fun setHeaderSize(value: HeaderSize) = graph.prefs.setHeaderSize(value)
    fun setAccent(argb: Int) = graph.prefs.setAccent(argb)
    fun setNavStyle(value: NavStyle) = graph.prefs.setNavStyle(value)
    fun setLibraryShelf(value: Boolean) = graph.prefs.setLibraryShelf(value)
    fun setThemeMode(value: ThemeMode) = graph.prefs.setThemeMode(value)
    fun setGoals(value: Goals) = graph.prefs.setGoals(value)

    /** Shows a short message at the bottom of the screen. */
    fun say(text: String) {
        _message.value = text
    }

    // ---- backup and restore ---------------------------------------------------------------

    private val _backupCounts = MutableStateFlow<BackupCounts?>(null)
    val backupCounts: StateFlow<BackupCounts?> = _backupCounts.asStateFlow()

    private val _pendingBackup = MutableStateFlow<PendingBackup?>(null)
    val pendingBackup: StateFlow<PendingBackup?> = _pendingBackup.asStateFlow()

    fun refreshBackupCounts() {
        viewModelScope.launch {
            _backupCounts.value = withContext(Dispatchers.IO) { Backup.currentCounts(graph.db) }
        }
    }

    /** Writes the backup file the person chose in the system file picker. */
    fun saveBackup(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val json = Backup.build(graph.db, graph.prefs, graph.settings)
                    val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                        ?: error("no output stream")
                    out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                }.isSuccess
            }
            _message.value = if (ok) "Backup saved." else "Could not save the backup file."
        }
    }

    /** Reads a backup file and waits for the person to confirm before anything changes. */
    fun readBackup(uri: Uri) {
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use {
                        it.readBytes().toString(Charsets.UTF_8)
                    }
                }.getOrNull()
            }
            if (text == null) {
                _pendingBackup.value = null
                _message.value = "Could not read that file."
                return@launch
            }
            Backup.parse(text).fold(
                onSuccess = { _pendingBackup.value = it },
                onFailure = {
                    _pendingBackup.value = null
                    _message.value = it.message ?: "That file could not be read as a Paperback backup."
                },
            )
        }
    }

    fun cancelBackup() {
        _pendingBackup.value = null
    }

    fun applyBackup() {
        val pending = _pendingBackup.value ?: return
        viewModelScope.launch {
            val matched = withContext(Dispatchers.IO) {
                runCatching { Backup.restore(pending, graph.db, graph.prefs, graph.settings) }.getOrNull()
            }
            _pendingBackup.value = null
            if (matched == null) {
                _message.value = "The backup could not be restored."
            } else {
                graph.repo.refresh()
                refreshBackupCounts()
                _message.value = if (matched == 1) "Backup restored for 1 book." else "Backup restored for $matched books."
            }
        }
    }

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        refresh()
        // Books added before genres existed get theirs read from the files, once, in the background.
        viewModelScope.launch { runCatching { graph.repo.backfillMeta() } }
    }

    fun refresh() {
        viewModelScope.launch { graph.repo.refresh() }
    }

    fun consumeMessage() {
        _message.value = null
    }

    fun importBooks(uris: List<Uri>) {
        viewModelScope.launch {
            _busy.value = true
            var added = 0
            val problems = mutableListOf<String>()
            for (uri in uris) {
                when (val r = graph.repo.importBook(uri)) {
                    is ImportOutcome.Added -> added++
                    is ImportOutcome.Duplicate -> problems += "${r.name} is already in your library"
                    is ImportOutcome.Unsupported -> problems += "${r.name}: only EPUB and PDF for now"
                    is ImportOutcome.Failed -> problems += "Couldn't read ${r.name}"
                }
            }
            _busy.value = false
            _message.value = buildString {
                if (added > 0) append(if (added == 1) "Added 1 book" else "Added $added books")
                if (problems.isNotEmpty()) {
                    if (isNotEmpty()) append(". ")
                    append(problems.first())
                    if (problems.size > 1) append(" (+${problems.size - 1} more)")
                }
            }.ifEmpty { null }
        }
    }

    /** Prepares the reader, then calls [onReady] so the screen can start ReaderActivity. */
    fun open(book: Book, onReady: () -> Unit, startAtJson: String? = null) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            val ok = graph.openReader(book, startAtJson)
            _busy.value = false
            if (ok) onReady() else _message.value = "Couldn't open ${book.title}"
        }
    }

    // ---- reflow a PDF as an EPUB ----------------------------------------------------------

    private val _reflow = MutableStateFlow<ReflowState?>(null)
    val reflow: StateFlow<ReflowState?> = _reflow.asStateFlow()
    private var reflowJob: Job? = null

    /** Converts [book] (a PDF) to a new EPUB book in the library. One at a time; keeps going if you leave the page. */
    fun reflowPdf(book: Book) {
        if (!book.isPdf) return
        if (reflowJob?.isActive == true) {
            _message.value = "Another book is being converted. Wait for it to finish."
            return
        }
        _reflow.value = ReflowState(book.id, 0, book.totalPositions.coerceAtLeast(1))
        reflowJob = graph.appScope.launch {
            val outcome = try {
                graph.repo.reflowPdf(book) { page, total, ocr -> _reflow.value = ReflowState(book.id, page, total, ocr) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                _reflow.value = null
                _message.value = "Conversion cancelled."
                return@launch
            }
            _reflow.value = null
            _message.value = when (outcome) {
                is ReflowOutcome.Done -> "Added \u201C${outcome.title}\u201D to your Library"
                is ReflowOutcome.Exists -> "This PDF has already been reflowed. It's in your Library."
                is ReflowOutcome.Failed -> outcome.message
            }
        }
    }

    fun cancelReflow() {
        reflowJob?.cancel()
    }

    fun toggleFavorite(book: Book) {
        viewModelScope.launch { graph.repo.setFavorite(book.id, !book.favorite) }
    }

    fun toggleFinished(book: Book) {
        viewModelScope.launch { graph.repo.setFinished(book.id, !book.finished) }
    }

    fun remove(book: Book) {
        viewModelScope.launch { graph.repo.remove(book) }
    }

    fun rate(book: Book, stars: Int) {
        viewModelScope.launch { graph.repo.setRating(book.id, stars) }
    }

    fun saveJournal(book: Book, text: String) {
        viewModelScope.launch { graph.repo.setJournal(book.id, text) }
    }

    // ---- collections ----------------------------------------------------------------------

    fun createCollection(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { graph.repo.createCollection(name) }
    }

    fun renameCollection(c: BookCollection, name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { graph.repo.renameCollection(c, name) }
    }

    fun deleteCollection(c: BookCollection) {
        viewModelScope.launch { graph.repo.deleteCollection(c.id) }
    }

    fun setMember(c: BookCollection, book: Book, member: Boolean) {
        viewModelScope.launch { graph.repo.setMember(c.id, book.id, member) }
    }

    // ---- notes ----------------------------------------------------------------------------

    fun deleteHighlight(h: Highlight) {
        viewModelScope.launch { graph.repo.deleteHighlight(h.id) }
    }

    fun deleteBookmark(b: Bookmark) {
        viewModelScope.launch { graph.repo.deleteBookmark(b.id) }
    }
}
