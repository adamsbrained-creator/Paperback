package com.paperback.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.TitleKey
import com.paperback.app.data.Book
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.catalog.Load
import com.paperback.app.ui.theme.pbTokens

/** Titles of the books you own, in the form [TitleKey] compares. */
fun ownedKeys(books: List<Book>): Set<String> = books.mapTo(HashSet()) { TitleKey.of(it.title) }

/**
 * What the Search page shows before you type: recommendations from your own taste, what is trending, and
 * categories to browse. Everything comes from the online catalog (Open Library), and nothing is asked
 * while it is switched off.
 */
@Composable
fun ExploreSection(
    catalog: CatalogController,
    books: List<Book>,
    onOpenBook: (CatalogBook) -> Unit,
    onBrowse: (kind: String, value: String) -> Unit,
) {
    val t = pbTokens()
    val on by catalog.enabled.collectAsStateWithLifecycle()
    val trending by catalog.trending.collectAsStateWithLifecycle()
    val forYou by catalog.forYou.collectAsStateWithLifecycle()
    val owned = remember(books) { ownedKeys(books) }

    LaunchedEffect(on, books) { catalog.refresh() }

    if (!on) {
        Spacer(Modifier.height(20.dp))
        NoteCard(
            title = "Explore books online",
            text = "Paperback can show trending books, recommend books like the ones you have read and rated, and tell you about any book: cover, description and rating. It asks Open Library, a free public catalog. It sends the genres and authors you like as search words, never your files, notes or reading times, and it has no books to read; you add those yourself.",
            action = "Turn on",
            onAction = { catalog.setEnabled(true) },
        )
        return
    }

    // recommendations
    when (val f = forYou) {
        is Load.Ready -> {
            val picks = f.value
            if (picks.isNotEmpty()) {
                RowHeader("For you", onAll = { onBrowse("foryou", "") })
                CatalogRow(
                    picks.take(12).map { it.book },
                    owned,
                    notes = picks.associate { it.book.id to it.reason },
                    onOpen = onOpenBook,
                )
            } else if (books.isEmpty()) {
                Spacer(Modifier.height(20.dp))
                NoteCard(
                    "Add a few books, then rate or favorite the ones you like. Recommendations appear here, worked out from your own library.",
                    title = "For you",
                )
            } else {
                Spacer(Modifier.height(20.dp))
                NoteCard(
                    "Rate a few books, or mark some as favorites or finished, and recommendations appear here. They are based on the genres and authors of the books you like.",
                    title = "For you",
                )
            }
        }
        is Load.Failed -> if (trending !is Load.Failed) {
            Spacer(Modifier.height(20.dp))
            NoteCard(f.message, title = "For you", action = "Try again", onAction = { catalog.refresh(force = true) })
        }
        Load.Loading -> if (books.isNotEmpty()) {
            RowHeader("For you")
            SkeletonRow()
        }
    }

    // trending
    when (val tr = trending) {
        is Load.Ready -> {
            if (tr.value.isNotEmpty()) {
                RowHeader("Trending this week", onAll = { onBrowse("trending", "") })
                CatalogRow(tr.value.take(14), owned, onOpen = onOpenBook)
            }
        }
        is Load.Failed -> {
            Spacer(Modifier.height(20.dp))
            NoteCard(tr.message, title = "Trending", action = "Try again", onAction = { catalog.refresh(force = true) })
        }
        Load.Loading -> {
            RowHeader("Trending this week")
            SkeletonRow()
        }
    }

    RowHeader("Explore by category")
    CategoryGrid { c -> onBrowse("cat", c.slug) }

    Column(Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 8.dp)) {
        Text(
            "Book information from Open Library. Turn the online catalog off if you'd rather Paperback stayed offline.",
            color = t.setSub,
            fontSize = 12.sp,
            lineHeight = 17.sp,
        )
        Text(
            "Turn off online catalog",
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary,
            fontSize = 13.sp,
            modifier = Modifier
                .padding(top = 6.dp)
                .clip(RoundedCornerShape(10.dp))
                .clickable { catalog.setEnabled(false) }
                .padding(vertical = 6.dp),
        )
    }
}
