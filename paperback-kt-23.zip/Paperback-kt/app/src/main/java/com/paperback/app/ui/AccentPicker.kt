package com.paperback.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.hsl
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils
import com.paperback.app.ui.theme.pbTokens

/** The ready-made accents (same set as Scrapbook), the first being Paperback's own coral. */
private val PRESETS = listOf(
    "Coral" to Color(0xFFF46B4E),
    "Teal" to Color(0xFF2FC8C4),
    "Amber" to Color(0xFFF5B03A),
    "Violet" to Color(0xFF9B87FF),
    "Green" to Color(0xFF4FC287),
    "Pink" to Color(0xFFFF84AA),
    "Blue" to Color(0xFF4A98FF),
    "Lime" to Color(0xFFBFEA45),
)

private const val SAT = 0.85f
private val RAINBOW = listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f).map { Color.hsl(it, SAT, 0.5f) }

/**
 * The accent colour: a row of round swatches, and a last rainbow one that opens two sliders (hue, then light to dark)
 * for a colour of your own. [current] is the accent as an ARGB number; [onPick] is called as it changes.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AccentPicker(current: Int, onPick: (Int) -> Unit, modifier: Modifier = Modifier) {
    val t = pbTokens()
    val argb = 0xFF000000.toInt() or current
    val matchesPreset = PRESETS.any { it.second.toArgb() == argb }
    var custom by rememberSaveable { mutableStateOf(!matchesPreset) }
    // the sliders start from the colour in use each time the custom editor opens
    val start = remember(custom) { FloatArray(3).also { ColorUtils.colorToHSL(argb, it) } }
    var hue by remember(custom) { mutableFloatStateOf(start[0]) }
    var light by remember(custom) { mutableFloatStateOf(start[2].coerceIn(0.25f, 0.75f)) }

    Column(modifier.fillMaxWidth()) {
        FlowRow(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            PRESETS.forEach { (name, color) ->
                Swatch(
                    name = name,
                    selected = !custom && color.toArgb() == argb,
                    onClick = {
                        custom = false
                        onPick(color.toArgb())
                    },
                ) { Box(Modifier.fillMaxSize().background(color)) }
            }
            Swatch(name = "Custom color", selected = custom, onClick = { custom = true }) {
                Box(Modifier.fillMaxSize().background(Brush.sweepGradient(RAINBOW)))
            }
        }
        if (custom) {
            Column(
                Modifier
                    .padding(top = 14.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(t.card)
                    .padding(horizontal = 16.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                GradientBar(
                    brush = Brush.horizontalGradient(RAINBOW),
                    fraction = hue / 360f,
                    handle = Color.hsl(hue, SAT, light),
                    description = "Hue",
                    onChange = {
                        hue = it * 360f
                        onPick(Color.hsl(hue, SAT, light).toArgb())
                    },
                )
                GradientBar(
                    brush = Brush.horizontalGradient(
                        listOf(Color.hsl(hue, SAT, 0.25f), Color.hsl(hue, SAT, 0.5f), Color.hsl(hue, SAT, 0.75f)),
                    ),
                    fraction = (light - 0.25f) / 0.5f,
                    handle = Color.hsl(hue, SAT, light),
                    description = "Shade",
                    onChange = {
                        light = 0.25f + it * 0.5f
                        onPick(Color.hsl(hue, SAT, light).toArgb())
                    },
                )
            }
        }
    }
}

/** A round swatch; the chosen one gets a ring around it. */
@Composable
private fun Swatch(name: String, selected: Boolean, onClick: () -> Unit, fill: @Composable () -> Unit) {
    val t = pbTokens()
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .selectable(selected = selected, onClick = onClick, role = Role.RadioButton)
            .semantics { contentDescription = name }
            .border(2.dp, if (selected) t.ink else Color.Transparent, CircleShape)
            .padding(4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.fillMaxSize().clip(CircleShape)) { fill() }
    }
}

/** A slim gradient bar with a round handle. Tap or drag anywhere on it; [onChange] gets 0..1. */
@Composable
private fun GradientBar(brush: Brush, fraction: Float, handle: Color, description: String, onChange: (Float) -> Unit) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    val change by rememberUpdatedState(onChange)
    Box(
        Modifier
            .fillMaxWidth()
            .height(32.dp)
            .semantics { contentDescription = description }
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(Unit) {
                val edge = 14.dp.toPx()
                fun toValue(x: Float): Float = ((x - edge) / (widthPx - 2f * edge).coerceAtLeast(1f)).coerceIn(0f, 1f)
                awaitEachGesture {
                    val down = awaitFirstDown()
                    down.consume()
                    change(toValue(down.position.x))
                    drag(down.id) { p ->
                        p.consume()
                        change(toValue(p.position.x))
                    }
                }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val edge = 14.dp.toPx()
            val barH = 14.dp.toPx()
            val cy = size.height / 2f
            drawRoundRect(
                brush = brush,
                topLeft = Offset(edge, cy - barH / 2f),
                size = androidx.compose.ui.geometry.Size(size.width - 2f * edge, barH),
                cornerRadius = CornerRadius(barH / 2f),
            )
            val x = edge + (size.width - 2f * edge) * fraction.coerceIn(0f, 1f)
            drawCircle(handle, radius = edge, center = Offset(x, cy))
            drawCircle(Color.White, radius = edge - 1.5.dp.toPx(), center = Offset(x, cy), style = Stroke(3.dp.toPx()))
        }
    }
}
