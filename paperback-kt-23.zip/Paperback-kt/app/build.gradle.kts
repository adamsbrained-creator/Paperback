import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// The workflow writes keystore.properties (keyAlias, password, storeFile) next to settings.gradle.kts.
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.paperback.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.paperback.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 23
        versionName = "2.0.0-alpha23"

        // Only the processor types listed are packed in. ML Kit's text recognition carries a big native library for
        // every type, which is most of the size of the app. Phones from the last ten years are arm64-v8a; to also run
        // on an emulator or an old 32-bit phone set paperback.abis=arm64-v8a,armeabi-v7a,x86_64 in gradle.properties.
        val abis = (project.findProperty("paperback.abis") as String? ?: "arm64-v8a").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        ndk { abiFilters += abis }
    }

    signingConfigs {
        if (keystoreProps.getProperty("storeFile") != null) {
            create("release") {
                storeFile = file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("password")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("password")
            }
        }
    }

    buildTypes {
        release {
            // R8 removes unused code and renames the rest, which makes the app smaller and faster to start. If a build
            // ever crashes because of it, set paperback.minify=false in gradle.properties to switch it off.
            val minify = (project.findProperty("paperback.minify") as String? ?: "true") == "true"
            isMinifyEnabled = minify
            isShrinkResources = minify
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true // required by Readium
    }
    buildFeatures { compose = true }
    lint {
        // A lint finding should never be what stops an APK from building.
        checkReleaseBuilds = false
        abortOnError = false
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        freeCompilerArgs.add("-opt-in=org.readium.r2.shared.ExperimentalReadiumApi")
    }
}

dependencies {
    coreLibraryDesugaring(libs.desugar)

    implementation(libs.readium.shared)
    implementation(libs.readium.streamer)
    implementation(libs.readium.navigator)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.foundation)
    implementation(libs.compose.material3)
    implementation(libs.compose.icons.core)
    implementation(libs.activity.compose)
    implementation(libs.lifecycle.runtime.compose)
    implementation(libs.lifecycle.viewmodel.compose)

    implementation(libs.core.ktx)
    implementation(libs.appcompat)
    implementation(libs.fragment.ktx)
    implementation(libs.coroutines.android)
    implementation(libs.pdfbox.android)
    implementation(libs.mlkit.text.recognition)
}
