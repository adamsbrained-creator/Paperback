#!/usr/bin/env bash
# Downloads the seven code packages Paperback builds against (foliate-js, the Tauri fork,
# and a few small libraries) at the exact versions this repo was cut from.
# Run from the repository root before `pnpm install`. Safe to run again: folders that
# are already filled are skipped. Needs only git and internet access.
set -euo pipefail
cd "$(dirname "$0")/.."

while read -r path url sha; do
  [[ -z "${path:-}" || "$path" == \#* ]] && continue
  if [[ -n "$(ls -A "$path" 2>/dev/null)" ]]; then
    echo "skip   $path (already there)"
    continue
  fi
  echo "fetch  $path @ ${sha:0:10}"
  mkdir -p "$path"
  git -C "$path" init -q
  git -C "$path" remote add origin "$url"
  git -C "$path" fetch -q --depth 1 origin "$sha"
  git -C "$path" checkout -q FETCH_HEAD
  rm -rf "$path/.git"
done < submodules.txt
