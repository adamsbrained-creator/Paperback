# Notice

Paperback is a personal ebook reader for Android. It started as a set of screens laid on top of
**Readest** (https://github.com/readest/readest, copyright its contributors) and is now a standalone copy of
that project with Readest's cloud, account, payment, AI and third-party-service code removed.

Readest is released under the GNU Affero General Public License v3.0, and so is Paperback (see `LICENSE`).
If you give the app to other people, the AGPL requires you to make the corresponding source available to them.
Keep the copyright and license notices in the files as they are.

What is still Readest's code: the reading engine, the reader, Discover, read aloud, dictionaries, the audiobooks
player and the rest of `apps/readest-app` outside the folders below. EPUB rendering is done by foliate-js; other
third-party components keep their own licenses. A few packages are downloaded at build time from Readest's
repositories (see `submodules.txt`).

What is Paperback's own: `src/app/(paperback)`, `src/components/paperback`, `src/services/paperback`,
`src/app/stats`, `src/services/statistics` (the stats parts), the Paperback styles in `src/styles/paperback-*.css`,
and the files listed in `CHANGELOG.md`.

Some Paperback files started as a Readest file of the same name (for example Discover's toolbar,
`src/app/opds/components/Navigation.tsx`) and stay under Readest's license.
