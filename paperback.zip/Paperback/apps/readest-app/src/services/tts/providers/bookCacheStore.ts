// Per-book persistent TTS cache binding (see the design doc
// .agents/plans/2026-07-13-tts-cache-sqlite-packs.md): each book gets its
// own database under Cache/tts-cache/<book_hash>/, opened lazily on the
// first synthesize of a TTS session and closed when the client shuts down.
// Every failure path degrades to "no cache": playback must never depend on
// the cache working.
//
// The store also gets a pack filesystem so fully cached sections compact
// into one MP3 pack file each: plugin-fs under AppCache on Tauri platforms,
// OPFS in the browser (where supported). Compaction runs debounced after
// manifest updates and once more at session close.

import { isTauriAppPlatform } from '@/services/environment';
import type { DatabaseService } from '@/types/database';
import type { AppService } from '@/types/system';
import type { TTSCacheEntry, TTSCacheStore } from './cache';
import { sweepTTSCaches, touchTTSCacheMeta } from './cacheSweep';
import { createOpfsPackFs } from './opfsPackFs';
import { SqliteTTSCacheStore, TTSPackFs } from './sqliteCacheStore';

const CONFIG_KEY = 'readest-tts-cache';
const DEFAULT_BUDGET_MB = 200;
const COMPACT_DEBOUNCE_MS = 30_000;
const DOWNLOADS_MARKER = 'downloads.json';

export interface TTSCacheConfig {
  enabled: boolean;
  budgetMB: number;
}

// localStorage-backed like the other TTS preferences (TTSUtils); a settings
// UI can edit the same key later.
export const getTTSCacheConfig = (): TTSCacheConfig => {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    const parsed = raw ? (JSON.parse(raw) as Partial<TTSCacheConfig>) : {};
    return {
      enabled: parsed.enabled !== false,
      budgetMB: typeof parsed.budgetMB === 'number' ? parsed.budgetMB : DEFAULT_BUDGET_MB,
    };
  } catch {
    return { enabled: true, budgetMB: DEFAULT_BUDGET_MB };
  }
};

// Applies to TTS sessions started after the change (the client reads the
// config when it is constructed).
export const setTTSCacheConfig = (config: TTSCacheConfig): void => {
  try {
    localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
  } catch {
    // Storage full or unavailable; the default config keeps applying.
  }
};

// Pack file IO under AppCache via plugin-fs (native platforms only). The
// plugin modules load lazily so the web bundle never pulls them in.
const createNativePackFs = (dir: string): TTSPackFs => ({
  async write(name, data) {
    const { writeFile, BaseDirectory } = await import('@tauri-apps/plugin-fs');
    await writeFile(`${dir}/${name}`, data, { baseDir: BaseDirectory.AppCache });
  },
  async rename(from, to) {
    const { rename, BaseDirectory } = await import('@tauri-apps/plugin-fs');
    await rename(`${dir}/${from}`, `${dir}/${to}`, {
      oldPathBaseDir: BaseDirectory.AppCache,
      newPathBaseDir: BaseDirectory.AppCache,
    });
  },
  async readRange(name, offset, length) {
    const { open, BaseDirectory, SeekMode } = await import('@tauri-apps/plugin-fs');
    const file = await open(`${dir}/${name}`, { read: true, baseDir: BaseDirectory.AppCache });
    try {
      await file.seek(offset, SeekMode.Start);
      const buffer = new Uint8Array(length);
      let read = 0;
      while (read < length) {
        const n = await file.read(buffer.subarray(read));
        if (!n) break;
        read += n;
      }
      if (read !== length) throw new Error(`short pack read: ${read}/${length}`);
      return buffer.buffer as ArrayBuffer;
    } finally {
      await file.close();
    }
  },
  async readSidecar(name) {
    try {
      const { readTextFile, BaseDirectory } = await import('@tauri-apps/plugin-fs');
      const text = await readTextFile(`${dir}/${name}`, { baseDir: BaseDirectory.AppCache });
      const parsed = JSON.parse(text);
      return parsed && Array.isArray(parsed.entries) ? parsed : null;
    } catch {
      return null;
    }
  },
  async remove(name) {
    const { remove, BaseDirectory } = await import('@tauri-apps/plugin-fs');
    await remove(`${dir}/${name}`, { baseDir: BaseDirectory.AppCache });
  },
  async list() {
    const { readDir, BaseDirectory } = await import('@tauri-apps/plugin-fs');
    const entries = await readDir(dir, { baseDir: BaseDirectory.AppCache });
    return entries.filter((entry) => entry.isFile).map((entry) => entry.name);
  },
});

// The per-book store every synthetic engine of one reader shares: each opens
// the same `cache.db`, and OPFS sync access handles are exclusive, so two
// stores on one book would fight. Entries are namespaced by provider id.
// Null when there is no app context or the user turned the cache off.
export const createBookTTSCacheStore = (
  appService: AppService | null | undefined,
  getBookHash: () => string | null,
): BookTTSCacheStore | null => {
  const cacheConfig = getTTSCacheConfig();
  if (!appService || !cacheConfig.enabled) return null;
  return new BookTTSCacheStore(appService, getBookHash, cacheConfig.budgetMB * 1024 * 1024);
};

export class BookTTSCacheStore implements TTSCacheStore {
  #appService: AppService;
  // The book key lands on the controller after construction (init()), so the
  // hash resolves lazily at first use.
  #getBookHash: () => string | null;
  #budgetBytes: number;
  #opening: Promise<{ db: DatabaseService; store: SqliteTTSCacheStore } | null> | null = null;
  #closing: Promise<void> | null = null;
  #compactTimer: ReturnType<typeof setTimeout> | null = null;
  readonly #importListeners = new Set<(keys: string[]) => void>();

  constructor(appService: AppService, getBookHash: () => string | null, budgetBytes: number) {
    this.#appService = appService;
    this.#getBookHash = getBookHash;
    this.#budgetBytes = budgetBytes;
  }

  #open() {
    if (this.#closing) return this.#closing.then(() => null);
    if (this.#opening) return this.#opening;
    const bookHash = this.#getBookHash();
    if (!bookHash) {
      // No book hash yet (the key binds to the controller on view attach):
      // the cache cannot open, so every op silently no-ops. Surfacing this
      // makes "downloads never persist" diagnosable instead of invisible.
      console.warn('TTS cache not opened: no book hash available yet');
      return Promise.resolve(null);
    }
    this.#opening = (async () => {
      try {
        const dir = `tts-cache/${bookHash}`;
        await this.#appService.createDir(dir, 'Cache', true);
        let packFs: TTSPackFs | undefined;
        if (isTauriAppPlatform()) {
          const packsDir = `${dir}/packs`;
          await this.#appService.createDir(packsDir, 'Cache', true);
          packFs = createNativePackFs(packsDir);
        } else {
          packFs = await createOpfsPackFs(`${dir}/packs`);
        }
        // 'tts-cache' has no registered migrations; the store owns its DDL.
        const db = await this.#appService.openDatabase('tts-cache', `${dir}/cache.db`, 'Cache');
        const store = new SqliteTTSCacheStore(db, { budgetBytes: this.#budgetBytes, packFs });
        // Before the pull below, so its imports reach the listeners.
        store.onImported((keys) => {
          for (const listener of this.#importListeners) listener(keys);
        });
        // Reconcile the durable marker before a cross-book sweep. A crash can
        // occur between pinning SQLite rows and writing the marker; the next
        // open repairs that gap before eviction is allowed to inspect it.
        await this.#syncDownloadMarker(bookHash, store);
        // Sweep tmp files from crashed compactions and packs whose rows were
        // evicted before the file delete landed. Concurrent-safe: only files
        // unknown to the database are touched.
        void store.gcPackFiles().catch(() => {});
        // Stamp this book as in use, then enforce the cross-book budget by
        // deleting whole least-recently-used book caches (this book exempt).
        void touchTTSCacheMeta(this.#appService, bookHash).then(() =>
          sweepTTSCaches(this.#appService, bookHash, this.#budgetBytes),
        );
        return { db, store };
      } catch (err) {
        console.warn('TTS cache unavailable for this session', err);
        return null;
      }
    })();
    return this.#opening;
  }

  onImported(listener: (keys: string[]) => void): void {
    this.#importListeners.add(listener);
  }

  async open(): Promise<void> {
    await this.#open();
  }

  async get(key: string): Promise<TTSCacheEntry | null> {
    const opened = await this.#open();
    return opened ? opened.store.get(key) : null;
  }

  async cachedKeys(keys: string[]): Promise<Set<string>> {
    const opened = await this.#open();
    return opened ? opened.store.cachedKeys(keys) : new Set();
  }

  async put(
    key: string,
    entry: TTSCacheEntry,
    meta?: { provider?: string; voice?: string },
  ): Promise<void> {
    const opened = await this.#open();
    await opened?.store.put(key, entry, meta);
  }

  async registerSectionMarks(section: number, marks: string[]): Promise<void> {
    const opened = await this.#open();
    if (!opened) return;
    await opened.store.registerSectionMarks(section, marks);
    this.#scheduleCompact();
  }

  async recordMarkKey(section: number, ordinal: number, key: string): Promise<void> {
    const opened = await this.#open();
    await opened?.store.recordMarkKey(section, ordinal, key);
  }

  async recordMarkKeys(section: number, marks: { ordinal: number; key: string }[]): Promise<void> {
    const opened = await this.#open();
    await opened?.store.recordMarkKeys(section, marks);
  }

  async beginDownloadSections(sections: number[]): Promise<void> {
    const opened = await this.#open();
    if (!opened) return;
    const bookHash = this.#getBookHash();
    if (!bookHash) return;
    // Write the eviction guard first. A crash may leave a harmless stale
    // marker, but must never leave pinned SQLite rows exposed to another
    // book's concurrent cross-cache sweep.
    await this.#appService.writeFile(
      `tts-cache/${bookHash}/${DOWNLOADS_MARKER}`,
      'Cache',
      JSON.stringify({ pinned: true }),
    );
    try {
      await opened.store.beginDownloadSections(sections);
    } catch (err) {
      await this.#syncDownloadMarker(bookHash, opened.store);
      throw err;
    }
  }

  async completeDownloadSections(sections: number[]): Promise<void> {
    const opened = await this.#open();
    if (!opened) return;
    await opened.store.completeDownloadSections(sections);
    const bookHash = this.#getBookHash();
    if (bookHash) await this.#syncDownloadMarker(bookHash, opened.store);
  }

  async cancelDownloadSections(sections: number[]): Promise<void> {
    const opened = await this.#open();
    if (!opened) return;
    await opened.store.cancelDownloadSections(sections);
    const bookHash = this.#getBookHash();
    if (bookHash) await this.#syncDownloadMarker(bookHash, opened.store);
  }

  async clearDownloads(): Promise<void> {
    const opened = await this.#open();
    if (!opened) return;
    await opened.store.clearDownloads();
    const bookHash = this.#getBookHash();
    if (bookHash) await this.#syncDownloadMarker(bookHash, opened.store);
  }

  // Immediate compaction for downloads (bypasses the debounced timer).
  async compact(): Promise<void> {
    const opened = await this.#open();
    if (!opened) return;
    await opened.store.compact();
  }

  async getSectionStatuses(): Promise<
    Map<
      number,
      { total: number; recorded: number; packed: boolean; pinned: boolean; active: boolean }
    >
  > {
    const opened = await this.#open();
    return opened ? opened.store.getSectionStatuses() : new Map();
  }

  async getSectionDurations(section: number, voice: string): Promise<Map<number, number>> {
    const opened = await this.#open();
    return opened ? opened.store.getSectionDurations(section, voice) : new Map();
  }

  async totalCacheBytes(): Promise<number> {
    const opened = await this.#open();
    return opened ? opened.store.totalCacheBytes() : 0;
  }

  async #syncDownloadMarker(bookHash: string, store: SqliteTTSCacheStore): Promise<void> {
    const path = `tts-cache/${bookHash}/${DOWNLOADS_MARKER}`;
    try {
      if (await store.hasDownloads()) {
        await this.#appService.writeFile(path, 'Cache', JSON.stringify({ pinned: true }));
      } else {
        await this.#appService.deleteFile(path, 'Cache');
      }
    } catch {
      // Marker repair is best-effort. SQLite remains authoritative and the
      // next store open will retry before launching the sweep.
    }
  }

  // Compaction is idle work: debounce it behind manifest updates so it never
  // competes with the synthesis burst at section start.
  #scheduleCompact(): void {
    if (this.#compactTimer) clearTimeout(this.#compactTimer);
    this.#compactTimer = setTimeout(() => {
      this.#compactTimer = null;
      void this.#compactNow();
    }, COMPACT_DEBOUNCE_MS);
  }

  async #compactNow(): Promise<void> {
    try {
      const opened = await this.#opening;
      if (!opened) return;
      await opened.store.compact();
    } catch (err) {
      console.warn('TTS cache compaction failed', err);
    }
  }

  close(): Promise<void> {
    if (!this.#closing) this.#closing = this.#close();
    return this.#closing;
  }

  async #close(): Promise<void> {
    if (this.#compactTimer) {
      clearTimeout(this.#compactTimer);
      this.#compactTimer = null;
    }
    const opening = this.#opening;
    this.#opening = null;
    const opened = await opening;
    if (!opened) return;
    try {
      // Session end is the natural compaction point: sections finished
      // during this session merge into packs before the database closes.
      await opened.store.compact();
      await opened.store.flush();
    } catch (err) {
      console.warn('TTS cache close housekeeping failed', err);
    } finally {
      await opened.db.close();
      const bookHash = this.#getBookHash();
      if (bookHash) await touchTTSCacheMeta(this.#appService, bookHash);
    }
  }
}

// Delete pinned offline audio when a book leaves the local library, including
// deletion paths that run without a live reader/controller (sync and purge).
// Open the existing database directly so cleanup does not trigger normal
// cache-open side effects such as a cross-book sweep.
export const clearBookTTSDownloads = async (
  appService: AppService,
  bookHash: string,
): Promise<void> => {
  const dir = `tts-cache/${bookHash}`;
  const dbPath = `${dir}/cache.db`;
  if (!(await appService.databaseExists(dbPath, 'Cache'))) {
    await appService.deleteFile(`${dir}/${DOWNLOADS_MARKER}`, 'Cache').catch(() => {});
    return;
  }

  let packFs: TTSPackFs | undefined;
  if (isTauriAppPlatform()) {
    packFs = createNativePackFs(`${dir}/packs`);
  } else {
    packFs = await createOpfsPackFs(`${dir}/packs`);
  }
  const db = await appService.openDatabase('tts-cache', dbPath, 'Cache');
  const budgetBytes = Math.max(1, getTTSCacheConfig().budgetMB * 1024 * 1024);
  const store = new SqliteTTSCacheStore(db, { budgetBytes, packFs });
  try {
    await store.clearDownloads();
    await store.flush();
  } finally {
    await db.close();
  }
  await appService.deleteFile(`${dir}/${DOWNLOADS_MARKER}`, 'Cache').catch(() => {});
};
