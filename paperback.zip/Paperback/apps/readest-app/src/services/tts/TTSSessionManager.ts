// Single-slot, hash-keyed registry for the live TTS session.
//
// A fresh TTSController (and bookKey) is created every time a book opens —
// bookKey is `${hash}-${uniqueId()}` — so sessions key by book HASH and treat
// bookKey as ephemeral. The manager owns everything that must outlive the
// reader's React hooks: the media bridge binding, the silent keep-alive, the
// sleep timer, headless progress persistence, reading-statistics capture, and
// the app-level playback state relay. It is a per-webview singleton by design
// (multi-window desktop keeps its current per-window behavior).

import env from '@/services/environment';
import { TtsStatsRecorder, type TtsStatsSession } from '@/services/statistics/ttsStatsRecorder';
import { stubTranslation as _ } from '@/utils/misc';
import { useBookDataStore } from '@/store/bookDataStore';
import { useSettingsStore } from '@/store/settingsStore';
import { eventDispatcher } from '@/utils/event';
import { releaseUnblockAudio, ttsMediaBridge, TTSMediaBridgeMeta } from './ttsMediaBridge';
import type { PlaybackSource } from '@/services/playback/playbackSource';
import type { TTSController } from './TTSController';

export type TTSSessionMeta = TTSMediaBridgeMeta;

// The manager owns any PlaybackSource; the TTS-only consumers (voice picker,
// downloader, reader hooks) narrow back through this. Kind is the only
// discriminator - never `instanceof`, which would drag the whole controller
// module into every consumer's bundle.
export const asTTSController = (source: PlaybackSource | null | undefined): TTSController | null =>
  source && source.kind === 'tts' ? (source as TTSController) : null;

// Sentinel passed to setSleepTimer()'s call sites / used as the TTSPlayerSheet
// timeout option value to mean "stop when the current chapter ends" instead
// of a fixed duration. Kept alongside the real (positive) second counts so
// the existing timeout-option picker can carry this mode without a parallel
// UI element.
export const TTS_STOP_AT_CHAPTER_END = -1;

export interface TTSSession {
  bookHash: string;
  bookKey: string;
  controller: PlaybackSource;
}

export type TTSSessionStopReason =
  | 'user'
  | 'replaced'
  | 'timeout'
  | 'ended'
  | 'error'
  | 'deleted'
  | 'quit';

export const getBookHashFromKey = (bookKey: string): string => bookKey.split('-')[0]!;

// Headless position writes hit the disk at most this often; stopActive
// flushes the final position regardless.
const PERSIST_THROTTLE_MS = 10_000;

export class TTSSessionManager extends EventTarget {
  #session: TTSSession | null = null;
  #meta: TTSSessionMeta | null = null;
  #onStateChange: ((e: Event) => void) | null = null;
  #onSessionEnded: ((e: Event) => void) | null = null;
  #onHighlightMark: ((e: Event) => void) | null = null;
  #lastRelayedState: 'playing' | 'paused' | null = null;
  #statsRecorder: TtsStatsRecorder | null = null;
  #sleepTimer: ReturnType<typeof setTimeout> | null = null;
  #sleepTimeoutSec = 0;
  #sleepFiresAt = 0;
  // "Stop at end of chapter" mode - mutually exclusive with the numeric
  // sleep timer above. A STANDING preference (unlike the numeric timer,
  // which self-clears once it fires): it keeps stopping at every chapter
  // boundary, across repeated play/stop cycles, until the user explicitly
  // switches the sleep timer to something else. Propagated onto whichever
  // TTSController is currently claimed (and onto every controller claimed
  // afterwards, including the fresh one created each time playback restarts
  // after a stop) so it survives both book switches and this stop/resume
  // cycle.
  #stopAtChapterEnd = false;
  #lastPersistAt = 0;
  #pendingLocation: string | null = null;
  #controllerTeardowns = new WeakMap<PlaybackSource, Promise<void>>();
  #bookTeardowns = new Map<string, Set<Promise<void>>>();

  claim(bookKey: string, controller: PlaybackSource, meta: TTSSessionMeta): void {
    const bookHash = getBookHashFromKey(bookKey);
    const existing = this.#session;
    if (existing && existing.bookHash !== bookHash) {
      // Starting TTS in another book replaces the single slot.
      void this.stopActive('replaced');
    } else if (existing && existing.controller !== controller) {
      // Same book restarted with a fresh controller: swap silently. The
      // manager owns the replaced controller's teardown — and must
      // unsubscribe first so the old controller's async tail can't relay.
      this.#unsubscribe(existing.controller);
      void this.#shutdownController(existing.bookHash, existing.controller);
    }
    this.#session = { bookHash, bookKey, controller };
    this.#meta = meta;
    this.#lastRelayedState = null;
    controller.stopAtChapterEnd = this.#stopAtChapterEnd;
    this.#subscribe(controller);
    void ttsMediaBridge.bind(controller, meta);
    this.#emitSessionChanged('claimed');
  }

  getSessionByHash(bookHash: string): TTSSession | null {
    return this.#session?.bookHash === bookHash ? this.#session : null;
  }

  getActiveSession(): TTSSession | null {
    return this.#session;
  }

  // The last state relayed on the tts-playback-state bus. Lets a listener that
  // mounts mid-session (opening the reader from the mini player) seed itself
  // instead of waiting for a transition that already happened.
  getPlaybackState(): 'playing' | 'paused' | null {
    return this.#lastRelayedState;
  }

  // The session survives; only the view goes away. The bridge stays bound so
  // the lock screen keeps working headless.
  detach(bookHash: string): void {
    const session = this.getSessionByHash(bookHash);
    if (!session) return;
    const wasPlaying = session.controller.state === 'playing' || !session.controller.terminated;
    session.controller.detachView();
    this.#emitSessionChanged('detached');
    // Closing a book while it keeps talking inverts years of learned
    // behavior; announce it exactly once, ever.
    if (wasPlaying) {
      try {
        if (!localStorage.getItem('readest-tts-background-announced')) {
          localStorage.setItem('readest-tts-background-announced', '1');
          eventDispatcher.dispatch('toast', {
            message: _('Reading aloud continues in the background'),
            type: 'info',
            timeout: 3000,
          });
        }
      } catch {
        // localStorage unavailable: skip the announcement.
      }
    }
  }

  // Rebind bookkeeping after the reader adopts the session under a fresh
  // bookKey (attachView itself is the caller's responsibility).
  adopt(bookKey: string, meta: TTSSessionMeta): TTSSession | null {
    const session = this.getSessionByHash(getBookHashFromKey(bookKey));
    if (!session) return null;
    session.bookKey = bookKey;
    this.#meta = meta;
    void ttsMediaBridge.bind(session.controller, meta);
    return session;
  }

  async stopActive(reason: TTSSessionStopReason = 'user'): Promise<void> {
    const session = this.#session;
    if (!session) return;
    const meta = this.#meta;
    const wasDetached = !session.controller.isViewAttached;
    // Register before dispatching synchronous events so deletion can join the
    // teardown even after the live slot is cleared below.
    const teardown = this.#shutdownController(session.bookHash, session.controller);
    this.#session = null;
    this.#meta = null;
    this.#clearSleepTimer();
    this.#unsubscribe(session.controller);
    this.#flushLocation(session);

    // UI reconciliation first; teardown is best-effort and must not gate it
    // (native shutdown can stall — see #4676).
    eventDispatcher.dispatch('tts-playback-state', {
      bookKey: session.bookKey,
      state: 'stopped',
    });
    this.#emitSessionChanged('stopped', session);
    if (reason === 'replaced' || reason === 'deleted') {
      eventDispatcher.dispatch('toast', {
        message: `${_('Stopped reading aloud')}: ${meta?.title ?? ''}`,
        type: 'info',
        timeout: 3000,
      });
    } else if (reason === 'error' && wasDetached) {
      eventDispatcher.dispatch('toast', {
        message: `${_('Read aloud stopped')}: ${meta?.title ?? ''}`,
        type: 'error',
        timeout: 5000,
      });
    }

    ttsMediaBridge.unbind();
    releaseUnblockAudio();
    // No use_background_audio(false) here: bridge.unbind() deactivates the
    // native media session, which releases the iOS audio session itself.
    await teardown;
  }

  // Stop this book if it owns the live slot, or join its teardown if another
  // caller already cleared the slot but is still closing the controller/DB.
  async stopBook(bookHash: string, reason: TTSSessionStopReason = 'user'): Promise<void> {
    for (;;) {
      if (this.getSessionByHash(bookHash)) {
        await this.stopActive(reason);
        continue;
      }
      const teardowns = [...(this.#bookTeardowns.get(bookHash) ?? [])];
      if (!teardowns.length) return;
      await Promise.all(teardowns);
    }
  }

  async stopController(
    bookHash: string,
    controller: PlaybackSource,
    reason: TTSSessionStopReason = 'user',
  ): Promise<void> {
    if (this.getSessionByHash(bookHash)?.controller === controller) {
      await this.stopActive(reason);
    } else {
      await this.#shutdownController(bookHash, controller);
    }
  }

  #shutdownController(bookHash: string, controller: PlaybackSource): Promise<void> {
    const existing = this.#controllerTeardowns.get(controller);
    if (existing) return existing;

    let teardown: Promise<void>;
    teardown = Promise.resolve()
      .then(() => controller.shutdown())
      .catch((err) => console.warn('TTS shutdown failed:', err))
      .finally(() => {
        if (this.#controllerTeardowns.get(controller) === teardown) {
          this.#controllerTeardowns.delete(controller);
        }
        const bookTeardowns = this.#bookTeardowns.get(bookHash);
        bookTeardowns?.delete(teardown);
        if (bookTeardowns?.size === 0) this.#bookTeardowns.delete(bookHash);
      });
    this.#controllerTeardowns.set(controller, teardown);
    const bookTeardowns = this.#bookTeardowns.get(bookHash) ?? new Set();
    bookTeardowns.add(teardown);
    this.#bookTeardowns.set(bookHash, bookTeardowns);
    return teardown;
  }

  // Clear the slot without tearing the controller down (the caller already
  // ran the full stop path).
  release(bookHash: string): void {
    const session = this.getSessionByHash(bookHash);
    if (!session) return;
    this.#unsubscribe(session.controller);
    this.#clearSleepTimer();
    this.#session = null;
    this.#meta = null;
    this.#emitSessionChanged('released', session);
  }

  // Sleep timer lives here so a timer armed in the reader survives unmount
  // and can actually stop a background session (a hook-local timer would
  // fire into a dead closure and orphan the audio).
  setSleepTimer(seconds: number): void {
    this.#clearSleepTimer();
    if (seconds > 0) {
      this.#setStopAtChapterEnd(false);
      this.#sleepTimeoutSec = seconds;
      this.#sleepFiresAt = Date.now() + seconds * 1000;
      this.#sleepTimer = setTimeout(() => {
        this.#sleepTimer = null;
        void this.stopActive('timeout');
      }, seconds * 1000);
    }
  }

  getSleepTimer(): { timeoutSec: number; firesAt: number } | null {
    return this.#sleepTimer
      ? { timeoutSec: this.#sleepTimeoutSec, firesAt: this.#sleepFiresAt }
      : null;
  }

  // "Stop at end of chapter" mode: the currently-playing chapter/section is
  // allowed to finish, then playback stops instead of continuing into the
  // next one - same terminal behaviour as the duration timer above, just
  // triggered by a chapter boundary instead of a clock. Mutually exclusive
  // with the numeric timer (enabling one clears the other).
  setStopAtChapterEnd(enabled: boolean): void {
    if (enabled) this.#clearSleepTimer();
    this.#setStopAtChapterEnd(enabled);
  }

  getStopAtChapterEnd(): boolean {
    return this.#stopAtChapterEnd;
  }

  #setStopAtChapterEnd(enabled: boolean): void {
    this.#stopAtChapterEnd = enabled;
    if (this.#session) {
      this.#session.controller.stopAtChapterEnd = enabled;
    }
  }

  #clearSleepTimer(): void {
    if (this.#sleepTimer) {
      clearTimeout(this.#sleepTimer);
      this.#sleepTimer = null;
    }
    this.#sleepTimeoutSec = 0;
    this.#sleepFiresAt = 0;
  }

  // Flush and drop the recorder. It owns a heartbeat interval, so it must never
  // be replaced without going through here or the orphan keeps writing.
  #releaseStatsRecorder(): void {
    const recorder = this.#statsRecorder;
    this.#statsRecorder = null;
    if (!recorder) return;
    void recorder.stop().catch((err) => console.warn('[stats] TTS stats flush failed:', err));
  }

  #subscribe(controller: PlaybackSource): void {
    // Listening is reading, so it feeds the same page_stat_data table. The
    // recorder lives here rather than in the reader because a headless session
    // (library mini player, lock screen, CarPlay) has no React tree left.
    // TTS only: the recorder reads the controller's foliate view to locate the
    // spoken page, which a non-TTS source has no equivalent of. It takes the
    // LIVE session object, never a copy - adopt() rebinds bookKey IN PLACE when
    // the reader reattaches to a background session, and a frozen key would
    // send every later progress/config lookup to the closed pane's entry.
    this.#releaseStatsRecorder();
    const session = this.#session;
    this.#statsRecorder =
      session && asTTSController(session.controller)
        ? new TtsStatsRecorder(session as TtsStatsSession)
        : null;
    this.#onStateChange = (e: Event) => {
      const { state } = (e as CustomEvent<{ state: string }>).detail;
      const session = this.#session;
      if (!session || session.controller !== controller) return;
      // 'stopped' is a TRANSIT value (every paragraph advance, chapter
      // transitions) — relaying it would flicker every follower and the
      // now-playing bar. Terminal stops arrive via tts-session-ended.
      let mapped: 'playing' | 'paused' | null = null;
      if (state === 'playing') mapped = 'playing';
      else if (state.includes('paused')) mapped = 'paused';
      if (!mapped || mapped === this.#lastRelayedState) return;
      this.#lastRelayedState = mapped;
      // Before the relay: the reading tracker stands down on this same event,
      // and the two must never bill the same wall-clock twice.
      this.#statsRecorder?.onPlaybackState(mapped);
      eventDispatcher.dispatch('tts-playback-state', { bookKey: session.bookKey, state: mapped });
    };
    this.#onSessionEnded = (e: Event) => {
      const { reason } = (e as CustomEvent<{ reason: 'ended' | 'error' }>).detail;
      void this.stopActive(reason);
    };
    this.#onHighlightMark = (e: Event) => {
      const { cfi } = (e as CustomEvent<{ cfi: string }>).detail;
      this.#statsRecorder?.onMark(cfi);
      this.#persistLocation(cfi);
    };
    controller.addEventListener('tts-state-change', this.#onStateChange);
    controller.addEventListener('tts-session-ended', this.#onSessionEnded);
    controller.addEventListener('tts-highlight-mark', this.#onHighlightMark);
  }

  #unsubscribe(controller: PlaybackSource): void {
    // Flush against the session the recorder was built for — every unbind path
    // (stop, release, same-book controller swap) runs through here, and
    // stopActive has already cleared #session by this point.
    this.#releaseStatsRecorder();
    if (this.#onStateChange) {
      controller.removeEventListener('tts-state-change', this.#onStateChange);
    }
    if (this.#onSessionEnded) {
      controller.removeEventListener('tts-session-ended', this.#onSessionEnded);
    }
    if (this.#onHighlightMark) {
      controller.removeEventListener('tts-highlight-mark', this.#onHighlightMark);
    }
    this.#onStateChange = null;
    this.#onSessionEnded = null;
    this.#onHighlightMark = null;
  }

  // Headless position persistence goes through the book CONFIG on disk:
  // clearViewState deletes the view/progress store entries (their setters
  // no-op for a closed book) and a reopen reloads config from disk, so
  // store-only writes would be lost. While a view is attached the reader
  // hook persists via its own path.
  #persistLocation(cfi: string): void {
    const session = this.#session;
    if (!session || session.controller.isViewAttached) return;
    this.#pendingLocation = cfi;
    const { getConfig, setConfig } = useBookDataStore.getState();
    const config = getConfig(session.bookKey);
    setConfig(session.bookKey, {
      viewSettings: { ...(config?.viewSettings ?? {}), ttsLocation: cfi },
    });
    const now = Date.now();
    if (now - this.#lastPersistAt >= PERSIST_THROTTLE_MS) {
      this.#lastPersistAt = now;
      this.#saveToDisk(session);
    }
  }

  #flushLocation(session: TTSSession): void {
    if (this.#pendingLocation === null) return;
    this.#pendingLocation = null;
    this.#saveToDisk(session);
  }

  #saveToDisk(session: TTSSession): void {
    try {
      const { getConfig, saveConfig } = useBookDataStore.getState();
      const config = getConfig(session.bookKey);
      if (!config) return;
      const settings = useSettingsStore.getState().settings;
      void saveConfig(env, session.bookKey, config, settings);
    } catch (err) {
      console.warn('TTS headless persistence failed:', err);
    }
  }

  #emitSessionChanged(
    reason: 'claimed' | 'detached' | 'stopped' | 'released',
    session: TTSSession | null = this.#session,
  ): void {
    this.dispatchEvent(new CustomEvent('session-changed', { detail: { session, reason } }));
  }
}

export const ttsSessionManager = new TTSSessionManager();
