export interface AudioTrack {
  index: number;
  startOffset: number; // seconds from book start
  duration: number; // seconds
  contentUrl: string; // server-relative, e.g. /api/items/<id>/file/<ino>
  mimeType: string;
  /** The audio file's name, e.g. `20686-01.mp3`. */
  title?: string;
  /** The audio file on the server; `size` in bytes. */
  metadata?: { filename?: string; size?: number };
}

export interface AudioChapter {
  id: number;
  start: number; // global seconds
  end: number; // global seconds
  title: string;
}
