'use client';

import clsx from 'clsx';
import { useEffect, useMemo, useState } from 'react';
import {
  buildMilestones,
  buildTimeline,
  commas,
  etaText,
  goalText,
  monthHeading,
  pickNextUp,
  shortDate,
  shortNum,
  tiersUnlocked,
  type MBook,
  type Milestone,
  type MilestoneInput,
  type MNote,
  type TimelineKind,
} from '@/services/statistics/milestonesStats';
import type { StatEventRow } from '@/services/statistics/statsAggregate';
import { SIcon } from './StatsIcons';
import TierSheet from './TierSheet';

type View = 'progress' | 'timeline';
type Filter = 'all' | TimelineKind;

const FILTERS: { id: Filter; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'book', label: 'Books' },
  { id: 'read', label: 'Reading' },
  { id: 'note', label: 'Notes' },
];

const INTRO_KEY = 'paperback.stats.milestonesIntro';
/** Heights (px) of the spines on the "next up" shelf, repeated. */
const SPINES = [46, 58, 50, 66, 54, 72, 48, 62, 56, 70, 52, 64, 74, 50, 60, 68, 54, 72, 58, 66, 48, 62, 56, 70, 60];
/** Past this many spines the shelf gets too crowded, so a plain bar is drawn instead. */
const MAX_SPINES = 30;

interface Props {
  events: StatEventRow[];
  books: MBook[];
  /** Highlights and notes; null while they are still being read from the books. */
  notes: MNote[] | null;
  savedWords: { word: string; addedAt: number }[];
  ratings: Record<string, number>;
  now: Date;
}

/** Stats → Milestones: lifetime achievements with five tiers each, what is next, and a timeline. */
export default function MilestonesView({ events, books, notes, savedWords, ratings, now }: Props) {
  const [view, setView] = useState<View>('progress');
  const [filter, setFilter] = useState<Filter>('all');
  const [introOpen, setIntroOpen] = useState(true);
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    try {
      if (localStorage.getItem(INTRO_KEY) === '0') setIntroOpen(false);
    } catch {
      /* keep it open */
    }
  }, []);
  const toggleIntro = () =>
    setIntroOpen((open) => {
      try {
        localStorage.setItem(INTRO_KEY, open ? '0' : '1');
      } catch {
        /* not saved */
      }
      return !open;
    });

  const input: MilestoneInput = useMemo(
    () => ({ events, books, notes: notes ?? [], savedWords, ratings, now }),
    [events, books, notes, savedWords, ratings, now],
  );
  const list = useMemo(() => buildMilestones(input), [input]);
  const timeline = useMemo(() => buildTimeline(input, list), [input, list]);
  const next = useMemo(() => pickNextUp(list), [list]);
  const { done, total } = tiersUnlocked(list);
  const open = list.find((m) => m.id === openId) ?? null;

  const shown = timeline.filter((e) => filter === 'all' || e.kind === filter);

  return (
    <div className='pbs pbs-col'>
      {/* ---------- what are milestones ---------- */}
      <section className='pbm-intro' aria-label='About milestones'>
        <button type='button' className='pbm-intro-head' aria-expanded={introOpen} aria-controls='pbm-intro-body' onClick={toggleIntro}>
          <span className='pbm-ic'>
            <SIcon name='trophy' />
          </span>
          <span className='pbm-t'>
            <b>What are milestones?</b>
            <span>
              {done} of {total} tiers unlocked
            </span>
          </span>
          <SIcon name='cd' />
        </button>
        {introOpen && (
          <p className='pbm-intro-body' id='pbm-intro-body'>
            Your <b>lifetime achievements</b> across reading, unlocked as you hit <b>tiers</b>. Unlike goals, milestones
            never reset and keep growing with every book, page and session.
          </p>
        )}
      </section>

      {/* ---------- next up ---------- */}
      {next && <NextUpCard next={next} onOpen={() => setOpenId(next.milestone.id)} />}

      {/* ---------- view switch ---------- */}
      <div className='pbm-vs' role='group' aria-label='View'>
        <button type='button' aria-pressed={view === 'progress'} onClick={() => setView('progress')}>
          Progress <small>{list.length}</small>
        </button>
        <button type='button' aria-pressed={view === 'timeline'} onClick={() => setView('timeline')}>
          Timeline <small>{timeline.length}</small>
        </button>
      </div>

      {view === 'progress' ? (
        <section className='pbm-view' aria-label='Milestone progress'>
          <div className='pbm-grid'>
            {list.map((m) => (
              <MilestoneCard key={m.id} m={m} onOpen={() => setOpenId(m.id)} />
            ))}
          </div>
        </section>
      ) : (
        <section className='pbm-view' aria-label='Timeline'>
          <div className='pbm-chips' role='group' aria-label='Filter timeline'>
            {FILTERS.map((f) => (
              <button key={f.id} type='button' className='pbm-fc' aria-pressed={filter === f.id} onClick={() => setFilter(f.id)}>
                {f.label}
              </button>
            ))}
          </div>
          {shown.length === 0 ? (
            <div className='pbm-empty'>Nothing here yet.</div>
          ) : (
            <div>
              {shown.map((e, n) => {
                const month = monthHeading(e.at, now);
                const first = n === 0 || monthHeading(shown[n - 1]!.at, now) !== month;
                const last = n === shown.length - 1 || monthHeading(shown[n + 1]!.at, now) !== month;
                return (
                  <div key={e.key}>
                    {first && <div className='pbm-mon'>{month}</div>}
                    <div className={clsx('pbm-ev', last && 'pbm-last')}>
                      <span className='pbm-ic'>
                        <SIcon name={e.icon} />
                      </span>
                      <div className='pbm-cd'>
                        <div className='pbm-l1'>
                          <h4>{e.title}</h4>
                          <time>{shortDate(e.at, now)}</time>
                        </div>
                        <p>
                          {e.sub.map((p, i) => (p.b ? <b key={i}>{p.t}</b> : <span key={i}>{p.t}</span>))}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {open && <TierSheet m={open} now={now} onClose={() => setOpenId(null)} />}
    </div>
  );
}

function MilestoneCard({ m, onOpen }: { m: Milestone; onOpen: () => void }) {
  return (
    <button
      type='button'
      className={clsx('pbm-m', m.value === 0 && 'pbm-zero')}
      aria-label={`${m.name}: ${commas(m.value)}${m.next !== null ? ` of ${commas(m.next)}` : ''}, tier ${m.unlocked} of ${m.tiers.length}. Open tiers.`}
      onClick={onOpen}
    >
      <div className='pbm-row1'>
        <span className='pbm-ic'>
          <SIcon name={m.icon} />
        </span>
        <span className='pbm-pips' aria-hidden='true'>
          {m.tiers.map((t, k) => (
            <i key={t} className={clsx(k < m.unlocked && 'pbm-on')} />
          ))}
        </span>
      </div>
      <div className='pbm-nm'>{m.short ?? m.name}</div>
      <div className='pbm-val'>
        {shortNum(m.value)}
        {m.next !== null && <small>/{shortNum(m.next)}</small>}
      </div>
      <div className='pbm-bar' aria-hidden='true'>
        <i style={{ width: `${m.pct.toFixed(1)}%` }} />
      </div>
    </button>
  );
}

function NextUpCard({ next, onOpen }: { next: NonNullable<ReturnType<typeof pickNextUp>>; onOpen: () => void }) {
  const m = next.milestone;
  const needText = commas(next.need);
  const numSize = needText.length <= 3 ? 76 : needText.length <= 5 ? 56 : 46;
  const shelf = m.id === 'books' && next.target <= MAX_SPINES;
  return (
    <button
      type='button'
      className='pbm-next'
      aria-label={`Next up: ${needText} more to ${goalText(m, next.target)}. Open tiers.`}
      onClick={onOpen}
    >
      <div className='pbm-n-top'>
        <span className='pbm-label'>Next up</span>
        <span className='pbm-tier'>
          <SIcon name='trophy' />
          Tier {next.tier} of {m.tiers.length}
        </span>
      </div>
      <div className='pbm-n-hero'>
        <span className='pbm-n-num' style={{ fontSize: numSize }}>
          {needText}
        </span>
        <span className='pbm-n-txt'>
          {m.unit} to go<span>until {goalText(m, next.target)}</span>
        </span>
      </div>
      {shelf ? (
        <div className='pbm-shelf' aria-hidden='true'>
          {Array.from({ length: next.target }, (_, i) => (
            <i
              key={i}
              className={clsx(i < m.value ? (i % 3 === 1 ? 'pbm-alt' : '') : i === m.value ? 'pbm-gap pbm-nx' : 'pbm-gap')}
              style={{ height: SPINES[i % SPINES.length] }}
            />
          ))}
        </div>
      ) : (
        <div className='pbm-bar pbm-n-bar' aria-hidden='true'>
          <i style={{ width: `${m.pct.toFixed(1)}%` }} />
        </div>
      )}
      <div className='pbm-n-foot'>
        <span>
          <b>{commas(m.value)}</b> of {commas(next.target)} {shelf ? 'on your shelf' : m.unit}
        </span>
        {next.days !== null && (
          <span className='pbm-go'>
            <SIcon name='clock' />
            {etaText(next.days)}
          </span>
        )}
      </div>
    </button>
  );
}
