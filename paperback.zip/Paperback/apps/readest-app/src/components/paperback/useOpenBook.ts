'use client';

import { useCallback } from 'react';
import { useAppRouter } from '@/components/paperback/platform';
import { navigateToReader } from '@/components/paperback/platform';
import { eventDispatcher, isAudiobook, sourceBook } from '@/components/paperback/platform';
import type { PBook } from '@/services/paperback/library';

/**
 * Opens a book (optionally at a CFI location) from a Paperback screen.
 */
export function usePaperbackOpenBook() {
  const router = useAppRouter();

  return useCallback(
    async (book: PBook, cfi?: string) => {
      const src = sourceBook(book);
      if (!src) {
        // Paperback's saved list shows before Readest's library has finished loading.
        eventDispatcher.dispatch('toast', { message: 'Your library is still loading. Try again in a moment.', type: 'info' });
        return;
      }
      if (isAudiobook(src)) {
        router.push(`/player?id=${src.hash}`);
        return;
      }
      const params = new URLSearchParams();
      if (cfi) params.set('cfi', cfi);
      navigateToReader(router, [book.hash], params.size ? params.toString() : undefined);
    },
    [router],
  );
}
