import clsx from 'clsx';
import React from 'react';
import { MdOutlineLightMode, MdOutlineDarkMode, MdOutlineSensors } from 'react-icons/md';
import { TbSunMoon } from 'react-icons/tb';
import { useTranslation } from '@/hooks/useTranslation';
import { useAtmosphereStore } from '@/store/atmosphereStore';
import { ThemeMode } from '@/styles/themes';
import { SettingLabel } from '../primitives';

interface ThemeModeSelectorProps {
  themeMode: ThemeMode;
  onThemeModeChange: (mode: ThemeMode) => void;
  /** When true, shows Ambient Mode (driven by the light sensor) as a fourth segment. */
  hasAmbientLightSensor?: boolean;
}

const ThemeModeSelector: React.FC<ThemeModeSelectorProps> = ({
  themeMode,
  onThemeModeChange,
  hasAmbientLightSensor = false,
}) => {
  const _ = useTranslation();
  const { spinDirection, shaking, toggle, toggleWithShake, deactivate } = useAtmosphereStore();

  const handleAutoClick = () => {
    deactivate();
    onThemeModeChange('auto');
  };

  const handleLightClick = () => {
    if (themeMode === 'light') {
      toggle();
    } else {
      deactivate();
      onThemeModeChange('light');
    }
  };

  const handleDarkClick = () => {
    if (themeMode === 'dark') {
      toggleWithShake();
    } else {
      deactivate();
      onThemeModeChange('dark');
    }
  };

  const handleAmbientClick = () => {
    deactivate();
    onThemeModeChange('ambient');
  };

  const segments: {
    mode: ThemeMode;
    title: string;
    onClick: () => void;
    icon: React.ReactNode;
  }[] = [
    { mode: 'auto', title: _('Auto Mode'), onClick: handleAutoClick, icon: <TbSunMoon /> },
    {
      mode: 'light',
      title: _('Light Mode'),
      onClick: handleLightClick,
      icon: (
        <span
          className={
            spinDirection === 'cw'
              ? 'animate-spin-cw'
              : spinDirection === 'ccw'
                ? 'animate-spin-ccw'
                : ''
          }
        >
          <MdOutlineLightMode />
        </span>
      ),
    },
    {
      mode: 'dark',
      title: _('Dark Mode'),
      onClick: handleDarkClick,
      icon: (
        <span className={shaking ? 'animate-shake' : ''}>
          <MdOutlineDarkMode />
        </span>
      ),
    },
  ];

  if (hasAmbientLightSensor) {
    segments.push({
      mode: 'ambient',
      title: _('Ambient Mode'),
      onClick: handleAmbientClick,
      icon: <MdOutlineSensors />,
    });
  }

  return (
    <div className='flex items-center justify-between px-4'>
      <SettingLabel>{_('Theme Mode')}</SettingLabel>
      {/* Segmented control: adjacent, equally sized radio segments share
          a single track. No `gap` between them, so there is no dead space to
          mis-tap, and each segment is a full-height rectangle instead of a
          32px icon — far easier to hit on touch screens (issue #4831). */}
      <div
        role='radiogroup'
        aria-label={_('Theme Mode')}
        className='bg-base-200 eink-bordered inline-flex items-center rounded-full p-0.5'
      >
        {segments.map(({ mode, title, onClick, icon }) => {
          const active = themeMode === mode;
          return (
            <button
              key={mode}
              type='button'
              role='radio'
              aria-checked={active}
              aria-label={title}
              title={title}
              onClick={onClick}
              className={clsx(
                'flex h-9 min-w-[2.75rem] items-center justify-center rounded-full px-3 text-lg transition-colors',
                'focus-visible:ring-base-content/15 focus-visible:outline-hidden focus-visible:ring-2',
                // e-ink: mark the active segment with a solid `eink-inverted`
                // fill (base-content bg, base-100 icon) instead of a border —
                // a bordered thumb would nest awkwardly inside the track's own
                // border. The track keeps its `eink-bordered` outline.
                active
                  ? 'bg-base-300 text-base-content eink-inverted shadow-xs'
                  : 'text-base-content/60 hover:text-base-content',
              )}
            >
              {icon}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ThemeModeSelector;
