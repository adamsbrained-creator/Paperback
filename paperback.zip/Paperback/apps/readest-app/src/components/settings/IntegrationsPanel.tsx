import React, { useEffect, useState } from 'react';
import { RiBookmark3Line, RiRssLine, RiWifiLine } from 'react-icons/ri';
import { useTranslation } from '@/hooks/useTranslation';
import { useKeyDownActions } from '@/hooks/useKeyDownActions';
import { useSettingsStore } from '@/store/settingsStore';
import { useCustomOPDSStore } from '@/store/customOPDSStore';
import { useLocalSendStore } from '@/store/localsendStore';
import { CatalogManager } from '@/app/opds/components/CatalogManager';
import { isTauriAppPlatform } from '@/services/environment';
import {
  getLocalSendAlias,
  isLocalSendEnabled,
} from '@/services/localsend/devicePrefs';
import { eventDispatcher } from '@/utils/event';
import LocalSendForm from './integrations/LocalSendForm';
import PageboundForm from './integrations/PageboundForm';
import SubPageHeader from './SubPageHeader';
import { BoxedList, NavigationRow } from './primitives';

type SubPage = 'opds' | 'localsend' | 'pagebound' | null;

/**
 * Integrations: OPDS catalogs (Discover), Nearby BookDrop and Pagebound.
 * Each row pushes the panel into an inline sub-page.
 */
const IntegrationsPanel: React.FC = () => {
  const _ = useTranslation();
  const { settings, requestedSubPage, setRequestedSubPage } = useSettingsStore();
  const opdsCatalogs = useCustomOPDSStore((s) => s.catalogs);
  const opdsCount = opdsCatalogs.filter((c) => !c.deletedAt).length;
  const localSendAlias = useLocalSendStore((s) => s.status?.alias);
  const [localSendEnabled, setLocalSendEnabledState] = useState(isLocalSendEnabled);
  const [subPage, setSubPage] = useState<SubPage>(null);

  useEffect(() => {
    const onPrefsChanged = () => setLocalSendEnabledState(isLocalSendEnabled());
    eventDispatcher.on('localsend-prefs-changed', onPrefsChanged);
    return () => eventDispatcher.off('localsend-prefs-changed', onPrefsChanged);
  }, []);

  // Android Back / Esc steps back to the list instead of closing Settings.
  useKeyDownActions({
    enabled: subPage !== null,
    onCancel: () => setSubPage(null),
  });

  // Deep link: a caller (e.g. the OPDS browser's close handler) sets
  // `requestedSubPage` before opening the dialog; drill in and clear it.
  useEffect(() => {
    if (!requestedSubPage) return;
    if (
      requestedSubPage === 'opds' ||
      requestedSubPage === 'localsend' ||
      requestedSubPage === 'pagebound'
    ) {
      setSubPage(requestedSubPage);
    }
    setRequestedSubPage(null);
  }, [requestedSubPage, setRequestedSubPage]);

  if (subPage === 'localsend')
    return (
      <div className='my-4 w-full'>
        <LocalSendForm onBack={() => setSubPage(null)} />
      </div>
    );
  if (subPage === 'pagebound')
    return (
      <div className='my-4 w-full'>
        <PageboundForm onBack={() => setSubPage(null)} />
      </div>
    );
  if (subPage === 'opds')
    return (
      <div className='my-4 w-full'>
        <SubPageHeader
          parentLabel={_('Integrations')}
          currentLabel={_('OPDS Catalogs')}
          description={_('Browse and download books from online catalogs.')}
          onBack={() => setSubPage(null)}
        />
        <CatalogManager inSubPage />
      </div>
    );

  const opdsStatus =
    opdsCount > 0 ? _('{{count}} catalog', { count: opdsCount }) : _('No catalogs');
  const localSendName = localSendAlias || getLocalSendAlias();
  const localSendStatus = !localSendEnabled
    ? _('Off')
    : localSendName
      ? _('Visible as {{name}}', { name: localSendName })
      : _('On');
  const pageboundStatus =
    settings.pagebound?.enabled && settings.pagebound.refreshToken
      ? _('Connected')
      : _('Not connected');

  return (
    <div className='my-4 w-full space-y-6'>
      <BoxedList
        title={_('Content Sources')}
        data-setting-id='settings.integrations.catalogs'
        cardClassName='overflow-hidden'
      >
        <NavigationRow
          icon={RiRssLine}
          title={_('OPDS Catalogs')}
          status={opdsStatus}
          onClick={() => setSubPage('opds')}
        />
      </BoxedList>

      {isTauriAppPlatform() && (
        <BoxedList
          title={_('Local Network')}
          data-setting-id='settings.integrations.localsend'
          cardClassName='overflow-hidden'
        >
          <NavigationRow
            icon={RiWifiLine}
            title={_('Nearby BookDrop')}
            status={localSendStatus}
            onClick={() => setSubPage('localsend')}
          />
        </BoxedList>
      )}

      {/* Pagebound's API sends no CORS headers, so only native HTTP reaches it. */}
      {isTauriAppPlatform() && (
        <BoxedList
          title={_('Reading Sync')}
          data-setting-id='settings.integrations.pagebound'
          cardClassName='overflow-hidden'
        >
          <NavigationRow
            icon={RiBookmark3Line}
            title={_('Pagebound')}
            status={pageboundStatus}
            onClick={() => setSubPage('pagebound')}
          />
        </BoxedList>
      )}
    </div>
  );
};

export default IntegrationsPanel;
