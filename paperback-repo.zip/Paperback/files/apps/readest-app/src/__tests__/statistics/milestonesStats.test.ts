import { describe, it, expect } from 'vitest';
import {
  buildMilestones,
  buildTimeline,
  etaText,
  goalText,
  hoursText,
  monthHeading,
  pickNextUp,
  shortDate,
  shortNum,
  tiersUnlocked,
  type MBook,
  type MilestoneInput,
} from '@/services/statistics/milestonesStats';
import type { StatEventRow } from '@/services/statistics/statsAggregate';

const NOW = new Date(2026, 9, 13, 12, 0);
const t = (y: number, m: number, d: number, h = 12, min = 0) => new Date(y, m - 1, d, h, min).getTime();
const at = (y: number, m: number, d: number, h = 12, min = 0) => Math.floor(t(y, m, d, h, min) / 1000);

const ev = (md5: string, page: number, startTime: number, duration = 60, totalPages = 300): StatEventRow => ({
  md5,
  title: md5.toUpperCase(),
  authors: 'A',
  page,
  startTime,
  duration,
  totalPages,
});

const book = (hash: string, title: string, over: Partial<MBook> = {}): MBook => ({
  hash,
  title,
  createdAt: t(2026, 1, 1),
  readingStatus: 'unread',
  ...over,
});
const done = (hash: string, title: string, finishedOn: number, over: Partial<MBook> = {}): MBook =>
  book(hash, title, { readingStatus: 'finished', readingStatusUpdatedAt: finishedOn, ...over });

const input = (over: Partial<MilestoneInput> = {}): MilestoneInput => ({
  events: [],
  books: [],
  notes: [],
  savedWords: [],
  ratings: {},
  now: NOW,
  ...over,
});
const get = (list: ReturnType<typeof buildMilestones>, id: string) => list.find((m) => m.id === id)!;

describe('helpers', () => {
  it('shortNum', () => {
    expect(shortNum(950)).toBe('950');
    expect(shortNum(6277)).toBe('6.3K');
    expect(shortNum(25000)).toBe('25K');
    expect(shortNum(1000)).toBe('1K');
  });

  it('hours text', () => {
    expect(hoursText(50)).toBe('2 days and 2 hours of reading');
    expect(hoursText(48)).toBe('2 days of reading');
    expect(hoursText(1)).toBe('1 hour of reading');
  });

  it('eta text', () => {
    expect(etaText(1)).toBe('about 1 day');
    expect(etaText(24)).toBe('about 3 weeks');
    expect(etaText(200)).toBe('about 7 months');
    expect(etaText(900)).toBe('over 2 years');
  });

  it('dates and headings leave the year out for this year only', () => {
    expect(shortDate(t(2026, 10, 8), NOW)).toBe('8 Oct');
    expect(shortDate(t(2025, 12, 30), NOW)).toBe('30 Dec 2025');
    expect(monthHeading(t(2026, 5, 22), NOW)).toBe('May');
    expect(monthHeading(t(2025, 5, 22), NOW)).toBe('May 2025');
  });
});

describe('buildMilestones: books', () => {
  const books = Array.from({ length: 12 }, (_, i) => done(`b${i}`, `Book ${i + 1}`, t(2026, 1, 1 + i)));
  const list = buildMilestones(input({ books }));

  it('counts finished books and dates the tiers by the finish dates', () => {
    const m = get(list, 'books');
    expect(m.value).toBe(12);
    expect(m.unlocked).toBe(1);
    expect(m.next).toBe(25);
    expect(m.dates).toEqual([t(2026, 1, 10), null, null, null, null]);
    expect(m.pct).toBeCloseTo((2 / 15) * 100, 5);
  });

  it('ignores deleted books and books that are not finished', () => {
    const l = buildMilestones(input({ books: [...books, done('x', 'Gone', t(2026, 2, 1), { deletedAt: 5 }), book('y', 'Unread')] }));
    expect(get(l, 'books').value).toBe(12);
  });

  it('a finished book with no date counts but has no date', () => {
    const undated = Array.from({ length: 10 }, (_, i) => ({ hash: `u${i}`, title: `U${i}`, readingStatus: 'finished' }) as MBook);
    const m = get(buildMilestones(input({ books: undated })), 'books');
    expect(m.unlocked).toBe(1);
    expect(m.dates[0]).toBeNull();
  });

  it('every tier unlocked → no next, 100%', () => {
    const many = Array.from({ length: 250 }, (_, i) => done(`b${i}`, `B${i}`, t(2025, 1, 1) + i));
    const m = get(buildMilestones(input({ books: many })), 'books');
    expect(m.unlocked).toBe(5);
    expect(m.next).toBeNull();
    expect(m.pct).toBe(100);
  });
});

describe('buildMilestones: reading', () => {
  // 30 days in a row, 40 distinct pages a day, 2 minutes a page → 80 minutes a day
  const events: StatEventRow[] = [];
  for (let d = 0; d < 30; d++) {
    for (let p = 0; p < 40; p++) events.push(ev('a', p + 1, at(2026, 9, 1 + d, 8, 0) + p * 120, 120));
  }
  const list = buildMilestones(input({ events }));

  it('pages: per-day distinct pages, tier dates by the day they were passed', () => {
    const m = get(list, 'pages');
    expect(m.value).toBe(1200);
    expect(m.unlocked).toBe(1);
    expect(m.dates[0]).toBe(t(2026, 9, 25, 0)); // 25 days * 40 = 1000
  });

  it('hours and sessions', () => {
    const h = get(list, 'hours');
    expect(h.value).toBe(40); // 30 days * 80 min = 40 h
    expect(h.unlocked).toBe(0);
    expect(get(list, 'ses').value).toBe(30);
  });

  it('streak: longest run and the day each length was first reached', () => {
    const s = get(list, 'streak');
    expect(s.value).toBe(30);
    expect(s.unlocked).toBe(3);
    expect(s.dates[0]).toBe(t(2026, 9, 7, 0));
    expect(s.dates[1]).toBe(t(2026, 9, 14, 0));
    expect(s.dates[2]).toBe(t(2026, 9, 30, 0));
  });

  it('recent pace counts only the last 90 days', () => {
    const old = [ev('o', 1, at(2025, 1, 1), 60)];
    const m = get(buildMilestones(input({ events: [...events, ...old] })), 'pages');
    expect(m.value).toBe(1201);
    expect(m.recent).toBe(1200);
  });
});

describe('buildMilestones: epic, words, rated, quotes, notes', () => {
  const books = [
    done('big1', 'Big One', t(2026, 3, 1)),
    done('big2', 'Big Two', t(2026, 4, 1)),
    done('big3', 'Big Three', t(2026, 5, 1)),
    done('small', 'Small', t(2026, 6, 1)),
    book('wip', 'Not finished'),
  ];
  const events = [
    ev('big1', 1, at(2026, 2, 1), 60, 570),
    ev('big2', 1, at(2026, 2, 2), 60, 500),
    ev('big3', 1, at(2026, 2, 3), 60, 800),
    ev('small', 1, at(2026, 2, 4), 60, 120),
    ev('wip', 1, at(2026, 2, 5), 60, 900),
  ];
  const notes = [
    { bookTitle: 'Big One', kind: 'highlight' as const, at: t(2026, 3, 2) },
    { bookTitle: 'Big Two', kind: 'note' as const, at: t(2026, 3, 3) },
    { bookTitle: 'Big Two', kind: 'bookmark' as const, at: t(2026, 3, 4) },
  ];
  const list = buildMilestones(
    input({
      books,
      events,
      notes,
      savedWords: [{ word: 'petrichor', addedAt: t(2026, 7, 1) }],
      ratings: { big1: 5, small: 4, ghost: 3 },
    }),
  );

  it('epic books are finished books with 500+ pages', () => {
    const m = get(list, 'epic');
    expect(m.value).toBe(3);
    expect(m.unlocked).toBe(1);
    expect(m.dates[0]).toBe(t(2026, 5, 1));
  });

  it('quotes are highlights and notes (not bookmarks); notes are the ones with text of your own', () => {
    expect(get(list, 'quotes').value).toBe(2);
    const n = get(list, 'notes');
    expect(n.value).toBe(1);
    expect(n.dates[0]).toBe(t(2026, 3, 3));
  });

  it('words and ratings', () => {
    expect(get(list, 'words').value).toBe(1);
    const r = get(list, 'rated');
    expect(r.value).toBe(2); // the rating of a book that is no longer in the library does not count
    expect(r.recent).toBeNull();
  });

  it('tiers unlocked in total', () => {
    const { done: d, total } = tiersUnlocked(list);
    expect(total).toBe(50);
    expect(d).toBe(list.reduce((n, m) => n + m.unlocked, 0));
  });
});

describe('next up', () => {
  it('picks the milestone closest to its next tier', () => {
    const books = Array.from({ length: 3 }, (_, i) => done(`b${i}`, `B${i}`, t(2026, 1, 1 + i))); // 3/10 = 30%
    const events: StatEventRow[] = [];
    for (let p = 0; p < 900; p++) events.push(ev('a', p + 1, at(2026, 10, 1, 8) + p * 5, 60)); // 900/1000 pages = 90%
    const list = buildMilestones(input({ books, events }));
    const next = pickNextUp(list)!;
    expect(next.milestone.id).toBe('pages');
    expect(next.need).toBe(100);
    expect(next.target).toBe(1000);
    expect(next.tier).toBe(1);
    expect(next.days).toBe(Math.ceil(100 / (900 / 90))); // 900 pages in the last 90 days → 10 a day
    expect(goalText(next.milestone, next.target)).toBe('1,000 Pages Read');
  });

  it('no recent pace → no estimate; nothing left → null', () => {
    const list = buildMilestones(input({ books: [done('a', 'A', t(2024, 1, 1))] }));
    expect(pickNextUp(list)!.days).toBeNull();
    expect(goalText(get(list, 'books'), 25)).toBe('25 Books Read');
    expect(goalText(get(list, 'streak'), 30)).toBe('a 30-day streak');
    expect(goalText(get(list, 'notes'), 1)).toBe('your first note');
    expect(pickNextUp(list.map((m) => ({ ...m, next: null })))).toBeNull();
  });
});

describe('buildTimeline', () => {
  const books = [
    ...Array.from({ length: 10 }, (_, i) => done(`b${i}`, `Book ${i + 1}`, t(2026, 8, 1 + i), { createdAt: t(2026, 5, 22) + i * 1000 })),
    book('e', 'Epic', { createdAt: t(2026, 5, 23) }),
  ];
  const events = [ev('b3', 1, at(2026, 8, 1), 60, 570), ev('b4', 1, at(2026, 8, 1), 60, 320)];
  const notes = [
    { bookTitle: 'Book 2', kind: 'highlight' as const, at: t(2026, 6, 1) },
    { bookTitle: 'Book 3', kind: 'note' as const, at: t(2026, 6, 13) },
  ];
  const inp = input({ books, events, notes });
  const list = buildMilestones(inp);
  const tl = buildTimeline(inp, list);
  const titles = tl.map((e) => e.title);

  it('has the tier unlocks, the firsts and the longest book, newest first', () => {
    expect(titles).toContain('10 Books Finished');
    expect(titles).toContain('First Book Added');
    expect(titles).toContain('First Book Finished');
    expect(titles).toContain('First Saved Quote');
    expect(titles).toContain('First Reading Note');
    expect(titles).toContain('Longest Book Read');
    expect(titles).toContain('10 Books Added');
    expect(titles).not.toContain('1 Notes Written');
    for (let i = 1; i < tl.length; i++) expect(tl[i - 1]!.at >= tl[i]!.at).toBe(true);
  });

  it('texts', () => {
    const fin = tl.find((e) => e.title === '10 Books Finished')!;
    expect(fin.kind).toBe('book');
    expect(fin.at).toBe(t(2026, 8, 10));
    expect(fin.sub).toEqual([{ t: 'Finished ' }, { t: '“Book 10”', b: true }]);
    const longest = tl.find((e) => e.title === 'Longest Book Read')!;
    expect(longest.sub).toEqual([{ t: 'Book 4', b: true }, { t: ' (570 pages)' }]);
    const note = tl.find((e) => e.title === 'First Reading Note')!;
    expect(note.kind).toBe('note');
    expect(note.sub).toEqual([{ t: 'Book 3', b: true }]);
  });

  it('an empty library has an empty timeline', () => {
    const e = input();
    expect(buildTimeline(e, buildMilestones(e))).toEqual([]);
  });
});
