package com.paperback.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.paperback.app.catalog.CatalogBook
import com.paperback.app.catalog.Ranker
import com.paperback.app.data.Block
import com.paperback.app.data.BlockType
import com.paperback.app.data.Book
import com.paperback.app.data.HomeCatalog
import com.paperback.app.data.HomeLayout
import com.paperback.app.data.HomePresets
import com.paperback.app.data.HomeSection
import com.paperback.app.data.HomeTitles
import com.paperback.app.data.HomeView
import com.paperback.app.data.RecapRow
import com.paperback.app.data.ReadingSession
import com.paperback.app.data.Recommendation
import com.paperback.app.data.Stats
import com.paperback.app.data.catalog.CatalogController
import com.paperback.app.data.catalog.Load
import com.paperback.app.ui.theme.pbTokens
import java.time.LocalDate

/*
 * Home is a stack of blocks (data/HomeLayout.kt). Without a layout from Customize Home it is the classic stack, with
 * the looks picked in the little menus on the section titles; with one, the layout decides what is shown, in which
 * order and how, and the menus are gone (the looks are picked in Customize Home).
 */

@Composable
fun HomeScreen(
    books: List<Book>,
    sessions: List<ReadingSession>,
    recommended: List<Recommendation>,
    goalMinutes: Int,
    tinyMinutes: Int = 0,
    /** All the goals (for the pinned stats and the suggestions), the stats pinned under Today, and how to change them. */
    goals: com.paperback.app.data.Goals = com.paperback.app.data.Goals(),
    pinned: List<com.paperback.app.data.PinnedStat> = com.paperback.app.data.DEFAULT_PINNED,
    onPinned: (List<com.paperback.app.data.PinnedStat>) -> Unit = {},
    onOpenGoals: () -> Unit = {},
    /** A pinned tile was tapped: open the Stats page that goes with it. */
    onOpenStat: (com.paperback.app.data.PinnedStat) -> Unit = {},
    onOpen: (Book) -> Unit,
    onRead: (Book) -> Unit,
    onDetails: (Book) -> Unit,
    onImport: () -> Unit,
    onDiscover: () -> Unit,
    catalog: CatalogController,
    wishlist: List<CatalogBook>,
    onOpenCatalogBook: (CatalogBook) -> Unit,
    onBrowse: (kind: String, value: String) -> Unit,
    /** How each section is drawn; a section missing from the map uses its default look. */
    homeViews: Map<HomeSection, HomeView> = emptyMap(),
    onHomeView: (HomeSection, HomeView) -> Unit = { _, _ -> },
    /** false hides "Recommended for you" and "Books you might like". */
    showRecommendations: Boolean = true,
    /** "Not interested" on a book of "Recommended for you". */
    onDismissRecommended: (Book) -> Unit = {},
    /** Which books of your library to suggest as the next read for a mood (0 = any), best first; null = no "Pick my next read". */
    pickNext: ((Int) -> List<com.paperback.app.data.Similar.NextPick>)? = null,
    /** The moods ([com.paperback.app.data.SessionMood]) you have read in for long enough to learn from. */
    pickMoods: List<Int> = emptyList(),
    /** Books you loved a long time ago and could read again. */
    rereads: List<com.paperback.app.data.Similar.Reread> = emptyList(),
    /** Last month's recap, while it waits to be opened. */
    recap: RecapRow? = null,
    onOpenRecap: () -> Unit = {},
    /** The session the optional place-and-mood question is about (null = don't ask), and what its buttons do. */
    contextSession: com.paperback.app.data.ReadingSession? = null,
    contextTitle: String = "",
    onContextSave: (sessionId: Long, place: Int, mood: Int) -> Unit = { _, _, _ -> },
    onContextDismiss: (sessionId: Long) -> Unit = {},
    onContextNever: () -> Unit = {},
    /** Records the last session broke (null = none), and the passage of the day with the title of its book. */
    records: com.paperback.app.data.SessionRecords? = null,
    onRecordsDone: (sessionId: Long) -> Unit = {},
    quote: com.paperback.app.data.Highlight? = null,
    quoteBookTitle: String = "",
    modifier: Modifier = Modifier,
    /** The Home built with Customize Home; null = the original Home, with the look menus on the section titles. */
    layout: HomeLayout? = null,
    /** Opens Customize Home (null = no "Customize Home" button under the blocks). */
    onCustomize: (() -> Unit)? = null,
    onOpenLibrary: () -> Unit = {},
    onOpenStats: () -> Unit = {},
    /** Set while Home is drawn inside Customize Home. */
    preview: HomePreview? = null,
) {
    val today = LocalDate.now()
    val pace = remember(sessions) { Stats.paceSecondsPerPosition(sessions) }

    val next = remember(books) {
        books.filter { it.isReading && it.hasFile }.maxByOrNull { it.lastOpenedAt } ?: books.firstOrNull { !it.finished && it.hasFile }
    }

    // the figures behind the pinned stats and the next best action (the hour only moves when the screen is redrawn)
    val hour = java.time.LocalTime.now().hour
    val figures = remember(sessions, books, goals, today, next, pace) {
        com.paperback.app.data.homeFigures(
            rows = sessions,
            books = books,
            goals = goals,
            today = today,
            nowMs = System.currentTimeMillis(),
            zone = java.time.ZoneId.systemDefault(),
            bookTitle = next?.title,
            bookSecondsLeft = next?.let { Stats.timeLeftSeconds(it, pace) },
            bookDeadlineMs = next?.deadlineMs ?: 0L,
        )
    }
    val actions = remember(figures, goals, today, hour) { com.paperback.app.data.nextActions(figures, goals, today, hour) }
    var editPinned by remember { mutableStateOf(false) }
    val recent = remember(books, next) {
        books.filter { it.lastOpenedAt > 0 && it.id != next?.id }.sortedByDescending { it.lastOpenedAt }.take(10)
    }

    val onlineOn by catalog.enabled.collectAsStateWithLifecycle()
    val forYou by catalog.forYou.collectAsStateWithLifecycle()
    val fresh by catalog.newFromAuthors.collectAsStateWithLifecycle()
    val stretch by catalog.stretch.collectAsStateWithLifecycle()
    val owned = remember(books) { ownedKeys(books) }
    LaunchedEffect(onlineOn, books, showRecommendations) { if (showRecommendations) catalog.refresh() }
    val fy = forYou
    val picks: List<Ranker.Pick> = if (fy is Load.Ready) fy.value else emptyList()
    // the picks that share a reason become rows of their own ("Because you liked ..."); the rest stay in one row
    val pickRows = remember(picks) { Ranker.group(picks, 3, 2) }
    val mixedPicks = remember(picks, pickRows) {
        val inRows = pickRows.flatMap { g -> g.picks.take(12).map { it.book.id } }.toSet()
        picks.filter { it.book.id !in inRows }
    }

    // "Because you liked X" with how long the book takes at your pace, when that is known
    fun withTime(note: String, b: Book): String {
        val time = com.paperback.app.data.Implicit.readTime(b.pageCount, pace) ?: return note
        return "$note \u00B7 $time"
    }
    // your Want to read list, the best fit for you first
    val wantedPicks = remember(wishlist, books, showRecommendations) {
        if (showRecommendations && wishlist.size > 1) catalog.rankWanted(wishlist) else emptyList()
    }
    val explain: (Any) -> Explanation? = { target ->
        when (target) {
            is com.paperback.app.catalog.CatalogBook -> Explanation(target.title, catalog.explain(target))
            is Book -> Explanation(target.title, com.paperback.app.data.Similar.whyLines(target, books))
            else -> null
        }
    }
    val favorites = remember(books) { books.filter { it.favorite }.sortedByDescending { it.lastOpenedAt } }

    // The Home nobody customized is the classic layout, drawn with the looks picked in the old title menus.
    val effective = layout ?: remember(homeViews) {
        HomePresets.original { type -> sectionOf(type)?.let { viewKey(homeViews[it] ?: it.default) } }
    }
    val inlineMenus = layout == null

    // does a block have anything to show right now? (an empty one is left out of Home and noted in the editor)
    fun has(block: Block): Boolean = when (block.type) {
        BlockType.Greeting, BlockType.Continue, BlockType.Today -> true
        BlockType.Alerts ->
            (block.opt("recap") && recap != null) || (block.opt("records") && records != null) || (block.opt("mood") && contextSession != null)
        BlockType.NextAction -> actions.isNotEmpty()
        BlockType.Shortcuts -> HomeCatalog.options.getValue(BlockType.Shortcuts).any { block.opt(it.key) }
        BlockType.Favorites -> favorites.isNotEmpty()
        BlockType.Recent -> recent.isNotEmpty()
        BlockType.Recommended -> showRecommendations && recommended.isNotEmpty()
        BlockType.Reread -> showRecommendations && rereads.isNotEmpty()
        BlockType.Want -> wishlist.isNotEmpty()
        BlockType.NewReleases -> showRecommendations && onlineOn && fresh.isNotEmpty()
        BlockType.Stretch -> showRecommendations && onlineOn && stretch.isNotEmpty()
        BlockType.Because -> showRecommendations && onlineOn && pickRows.isNotEmpty()
        BlockType.MightLike -> showRecommendations && onlineOn && mixedPicks.isNotEmpty()
        BlockType.Quote -> quote != null
    }

    val gap = effective.spacing.dp.dp
    val editing = preview?.onSelect != null
    val drawn = effective.visibleBlocks.filter { preview != null || has(it) }

    WithExplanations(explain) {
    CompositionLocalProvider(
        LocalHomeRound provides effective.cardDp.dp,
        LocalHomeLargeTitles provides (effective.titles == HomeTitles.Large),
    ) {
    Column(
        (if (preview == null) modifier.fillMaxSize().verticalScroll(rememberScrollState()) else modifier.fillMaxWidth())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        // in the editor the gaps are never tighter than the name tag of a picked block
        verticalArrangement = Arrangement.spacedBy(if (editing) maxOf(gap, 32.dp) else gap),
    ) {
        drawn.forEachIndexed { index, block ->
            key(block.id) {
                if (effective.dividers && index > 0) HomeDivider()
                val picker: ((HomeView) -> Unit)? = if (inlineMenus) ({ v: HomeView -> sectionOf(block.type)?.let { onHomeView(it, v) }; Unit }) else null
                val title = block.opt("title")
                val body: @Composable () -> Unit = {
                    when (block.type) {
                        BlockType.Greeting -> GreetingBlock(block.style, block.opt("date"), figures.streak, (figures.todaySeconds / 60L).toInt())
                        BlockType.Alerts -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                            if (block.opt("recap") && recap != null) RecapBanner(recap, onOpenRecap)
                            if (block.opt("records") && records != null) RecordCard(records.lines, onDone = { onRecordsDone(records.sessionId) })
                            if (block.opt("mood") && contextSession != null) {
                                SessionContextCard(
                                    bookTitle = contextTitle,
                                    minutes = (contextSession.seconds / 60).coerceAtLeast(1),
                                    onSave = { place, mood -> onContextSave(contextSession.id, place, mood) },
                                    onDismiss = { onContextDismiss(contextSession.id) },
                                    onNever = { onContextNever(); onContextDismiss(contextSession.id) },
                                )
                            }
                        }
                        BlockType.Continue -> ContinueBlock(
                            style = block.style,
                            next = next,
                            pace = pace,
                            title = title,
                            button = block.opt("button"),
                            left = block.opt("left"),
                            picker = block.opt("picker"),
                            pickNext = pickNext,
                            pickMoods = pickMoods,
                            onOpen = onOpen,
                            onRead = onRead,
                            onDetails = onDetails,
                            onImport = onImport,
                            onDiscover = onDiscover,
                        )
                        BlockType.NextAction -> NextActionCard(actions, canRead = next != null, onRead = { next?.let(onRead) }, onGoals = onOpenGoals)
                        BlockType.Today -> Column(Modifier.fillMaxWidth()) {
                            val showEdit = block.opt("edit")
                            if (title || showEdit) {
                                TodayHeader(onEdit = { editPinned = true }, showEdit = showEdit, showTitle = title)
                                Spacer(Modifier.height(12.dp))
                            }
                            val stats = pinned.ifEmpty { com.paperback.app.data.DEFAULT_PINNED }
                            when (block.style) {
                                "strip" -> PinnedStrip(stats, figures, goals, hour, onOpen = onOpenStat)
                                "ring" -> BigGoalRing(figures, goals, onClick = { onOpenStat(com.paperback.app.data.PinnedStat.GoalRing) })
                                else -> PinnedTiles(stats, figures, goals, hour, onOpen = onOpenStat)
                            }
                        }
                        BlockType.Shortcuts -> ShortcutsBlock(
                            style = block.style,
                            shown = HomeCatalog.options.getValue(BlockType.Shortcuts).filter { block.opt(it.key) }.map { it.key }.toSet(),
                            onLibrary = onOpenLibrary,
                            onStats = onOpenStats,
                            onDiscover = onDiscover,
                            onImport = onImport,
                        )
                        BlockType.Favorites -> BookSection(
                            "Favorites", HomeSection.Favorites, viewOfKey(block.style), picker, null, title,
                            favorites, onOpen, shelfRows = 1,
                        )
                        BlockType.Recent -> BookSection(
                            "Recently read", HomeSection.Recent, viewOfKey(block.style), picker, null, title,
                            recent, onOpen, shelfRows = 2,
                            // The book you had open last leans on the others, the way you leave one on a real shelf.
                            leanId = recent.firstOrNull()?.id,
                        )
                        BlockType.Recommended -> BookSection(
                            "Recommended for you", HomeSection.Recommended, viewOfKey(block.style), picker, null, title,
                            recommended.map { it.book }, onDetails, shelfRows = 1,
                            notes = if (block.opt("why")) recommended.associate { it.book.id to withTime(it.note ?: "Because you liked ${it.because.title}", it.book) } else emptyMap(),
                            onDismiss = onDismissRecommended,
                        )
                        BlockType.Reread -> BookSection(
                            "Worth reading again", HomeSection.Reread, viewOfKey(block.style), picker, null, title,
                            rereads.map { it.book }, onDetails, shelfRows = 1,
                            notes = rereads.associate { it.book.id to withTime(it.note, it.book) },
                            onDismiss = onDismissRecommended,
                        )
                        BlockType.Want -> CatalogSection(
                            "Want to read", HomeSection.WantToRead, viewOfKey(block.style), picker,
                            if (block.opt("all")) ({ onBrowse("want", "") }) else null, title,
                            (if (wantedPicks.isEmpty()) wishlist else wantedPicks.map { it.book }).take(12), owned, onOpenCatalogBook,
                            notes = wantedPicks.filter { it.reason.isNotBlank() }.associate { it.book.id to it.reason },
                        )
                        BlockType.NewReleases -> CatalogSection(
                            "New from authors you read", HomeSection.NewReleases, viewOfKey(block.style), picker, null, title,
                            fresh, owned, onOpenCatalogBook,
                            notes = fresh.associate { it.id to "New by ${it.firstAuthor()} \u00B7 ${it.year}" },
                            onDismiss = { catalog.dismiss(it) },
                        )
                        BlockType.Stretch -> CatalogSection(
                            "Try something different", HomeSection.Stretch, viewOfKey(block.style), picker, null, title,
                            stretch, owned, onOpenCatalogBook,
                            notes = stretch.associate { it.id to (catalog.reasonFor(it.id) ?: "") },
                            onDismiss = { catalog.dismiss(it) },
                        )
                        BlockType.Because -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(gap)) {
                            pickRows.forEach { g ->
                                CatalogSection(
                                    g.title, HomeSection.Because, viewOfKey(block.style), picker, null, title,
                                    g.picks.take(12).map { it.book }, owned, onOpenCatalogBook,
                                    onDismiss = { catalog.dismiss(it) },
                                )
                            }
                        }
                        BlockType.MightLike -> CatalogSection(
                            "Books you might like", HomeSection.MightLike, viewOfKey(block.style), picker,
                            if (block.opt("all")) ({ onBrowse("foryou", "") }) else null, title,
                            mixedPicks.take(10).map { it.book }, owned, onOpenCatalogBook,
                            notes = if (block.opt("why")) mixedPicks.associate { it.book.id to it.reason } else emptyMap(),
                            onDismiss = { catalog.dismiss(it) },
                        )
                        BlockType.Quote -> if (quote != null) {
                            val book = quoteBookTitle.ifEmpty { "Removed book" }
                            val chapter = com.paperback.app.data.chapterOf(quote)
                            if (block.style == "plain") QuotePlain(quote.text, quote.note, book, chapter)
                            else QuoteOfTheDayCard(quote.text, quote.note, book, null, chapter = chapter)
                        }
                    }
                }
                if (preview == null) {
                    body()
                } else {
                    val select = preview.onSelect
                    val shown: @Composable () -> Unit = if (has(block)) body else ({ EmptyBlockNote(block) })
                    if (select != null) EditableFrame(block, preview.selectedId == block.id, { select(block.id) }, shown) else shown()
                }
            }
        }

        if (preview == null) {
            if (drawn.isEmpty()) {
                Text(
                    "Nothing is switched on for Home yet.",
                    color = pbTokens().setSub,
                    fontSize = 15.sp,
                    modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
                    textAlign = TextAlign.Center,
                )
            }
            if (onCustomize != null) {
                Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
                    PbButton("Customize Home", onClick = onCustomize, ghost = true)
                }
            }
            Spacer(Modifier.height(if (onCustomize != null) 56.dp else 0.dp))
        }
        if (editPinned && preview == null) {
            PinnedStatsDialog(
                selected = pinned,
                onSave = { onPinned(it); editPinned = false },
                onCancel = { editPinned = false },
            )
        }
    }
    }
    }
}

// ---- what Home needs to turn the saved looks into the views it already had -----------------------

/** The Home section whose look menu (and saved look) a block type goes with; null for the blocks without one. */
private fun sectionOf(type: BlockType): HomeSection? = when (type) {
    BlockType.Favorites -> HomeSection.Favorites
    BlockType.Recent -> HomeSection.Recent
    BlockType.Recommended -> HomeSection.Recommended
    BlockType.Reread -> HomeSection.Reread
    BlockType.Want -> HomeSection.WantToRead
    BlockType.NewReleases -> HomeSection.NewReleases
    BlockType.Stretch -> HomeSection.Stretch
    BlockType.Because -> HomeSection.Because
    BlockType.MightLike -> HomeSection.MightLike
    else -> null
}

private fun viewKey(view: HomeView): String = when (view) {
    HomeView.Spines -> "spines"
    HomeView.ShelfCovers -> "shelf"
    HomeView.Frosted -> "frosted"
    HomeView.CoverRow -> "row"
    HomeView.Grid -> "grid"
    HomeView.List -> "list"
}

private fun viewOfKey(key: String): HomeView = when (key) {
    "spines" -> HomeView.Spines
    "shelf" -> HomeView.ShelfCovers
    "frosted" -> HomeView.Frosted
    "grid" -> HomeView.Grid
    "list" -> HomeView.List
    else -> HomeView.CoverRow
}

/** A row of the books of your library under a title. */
@Composable
private fun BookSection(
    title: String,
    section: HomeSection,
    view: HomeView,
    picker: ((HomeView) -> Unit)?,
    onAll: (() -> Unit)?,
    showTitle: Boolean,
    books: List<Book>,
    onClick: (Book) -> Unit,
    shelfRows: Int,
    leanId: String? = null,
    notes: Map<String, String> = emptyMap(),
    onDismiss: ((Book) -> Unit)? = null,
) {
    Column(Modifier.fillMaxWidth()) {
        HomeSectionHeader(title, section, view, picker, onAll, showTitle)
        HomeBooks(books, view, onClick = onClick, shelfRows = shelfRows, leanId = leanId, notes = notes, onDismiss = onDismiss)
    }
}

/** A row of books of the online catalog under a title. */
@Composable
private fun CatalogSection(
    title: String,
    section: HomeSection,
    view: HomeView,
    picker: ((HomeView) -> Unit)?,
    onAll: (() -> Unit)?,
    showTitle: Boolean,
    books: List<CatalogBook>,
    owned: Set<String>,
    onOpen: (CatalogBook) -> Unit,
    notes: Map<String, String> = emptyMap(),
    onDismiss: ((CatalogBook) -> Unit)? = null,
) {
    Column(Modifier.fillMaxWidth()) {
        HomeSectionHeader(title, section, view, picker, onAll, showTitle)
        HomeCatalogBooks(books, view, owned, onOpen = onOpen, notes = notes, onDismiss = onDismiss)
    }
}
