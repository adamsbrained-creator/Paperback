package com.paperback.app.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The strips above and below the page hold the chapter name and the page counters. They sit where the phone's (hidden) status and navigation bars
 * are, so the page text can fill the screen like Readest's: each strip is the bar plus a small gap, and never less than [ReaderMinStrip].
 */
val ReaderTopGap: Dp = 8.dp
val ReaderBottomGap: Dp = 8.dp
val ReaderMinStrip: Dp = 22.dp

/** The height of a strip: the bar it covers plus [gap], at least [ReaderMinStrip]. */
fun readerStrip(bar: Dp, gap: Dp): Dp = maxOf(bar + gap, ReaderMinStrip)

/**
 * The small, quiet text around the page, as in Readest: the chapter name at the top; "N pages left in chapter"
 * at the bottom left and "position / total" at the bottom right. "Pages left" counts real screens, so it drops
 * by one for each page you turn; the counter counts fixed pieces of text, so it can move by more than one.
 * Hidden while the reader's controls are showing (they cover this strip).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReaderMarginInfo(
    themeIndex: Int,
    hidden: Boolean,
    chapter: String,
    pagesLeft: Int,
    position: Int,
    totalPositions: Int,
) {
    val c = readerColors(themeIndex)
    val color = c.ink.copy(alpha = 0.55f)
    AnimatedVisibility(visible = !hidden, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .height(readerStrip(WindowInsets.statusBarsIgnoringVisibility.asPaddingValues().calculateTopPadding(), ReaderTopGap))
                    .padding(start = 20.dp, end = 20.dp, bottom = 2.dp),
                contentAlignment = Alignment.BottomStart,
            ) {
                if (chapter.isNotBlank()) {
                    Text(chapter, color = color, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(readerStrip(WindowInsets.navigationBarsIgnoringVisibility.asPaddingValues().calculateBottomPadding(), ReaderBottomGap))
                    .padding(start = 20.dp, end = 20.dp, bottom = 2.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                Text(
                    if (pagesLeft > 0) "$pagesLeft ${if (pagesLeft == 1) "page" else "pages"} left in chapter" else "",
                    modifier = Modifier.weight(1f),
                    color = color,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (position > 0 && totalPositions > 0) {
                    Text("$position / $totalPositions", color = color, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}
